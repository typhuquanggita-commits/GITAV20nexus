'use strict';
/**
 * BẢNG QUẢN TRỊ TỔNG — một cửa nhìn toàn hệ GITAV20nexus.
 *
 * Trang này gọi ĐÚNG MỘT lượt cho phần tổng, vì kho D1 ở bậc miễn phí
 * đếm từng lượt đọc. Hai bảng nhỏ bên trong (quan hệ gia đình và tài
 * chính) gọi thêm một lượt mỗi cái, và chỉ khi người dùng mở tới.
 *
 * Ô nào chưa có dữ liệu thì hiện chữ "chưa có", KHÔNG hiện số không.
 * Số không trông giống một phép đo, còn "chưa có" thì không.
 */
(function () {
  const CF = window.CF;
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];

  let tong = null;

  function doiMan(ten) {
    $$('.man').forEach((m) => m.classList.toggle('hien', m.id === 'man-' + ten));
    $$('.tab button').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.man === ten)));
    if (ten === 'crm') napCrm();
    if (ten === 'tai-chinh') napTaiChinh();
    if (ten === 'bao-mat') napBaoMat();
    if (ten === 'tin-hieu') napTinHieu();
  }

  /** Một ô số. Chưa có dữ liệu thì không in số 0. */
  function veO(x) {
    const so = x.coDuLieu
      ? '<div class="so">' + CF.thoat(CF.soVn(x.so)) + '</div>'
      : '<div class="so chua">chưa có</div>';
    return '<div class="the-o">' + so
      + '<div class="nhan">' + CF.thoat(x.nhan) + '</div>'
      + (x.y ? '<div class="y">' + CF.thoat(x.y) + '</div>' : '')
      + '</div>';
  }

  function veMang(ds) { return ds.map(veO).join(''); }

  async function napTong() {
    const r = await CF.can('/api/tong?soGio=24', 'bảng tổng');
    if (!r) return;
    tong = r;

    // ── Dải việc cần chú ý, đặt trên cùng vì đó là thứ cần đọc trước ──
    $('#can-chu-y').innerHTML = r.canChuY.length
      ? r.canChuY.map((v) => '<div class="viec ' + CF.thoat(v.muc) + '">'
        + '<b>' + (v.muc === 'khan' ? 'Cần xử lý ngay' : v.muc === 'luu-y' ? 'Lưu ý' : 'Nhắc')
        + '</b> ' + CF.thoat(v.viec) + '</div>').join('')
      : '<div class="viec binh-thuong"><b>Không có việc nào cần xử lý ngay.</b> '
        + 'Nhật ký kiểm toán liền mạch, không có vi phạm hiến pháp trong 24 giờ qua.</div>';

    $('#o-hoc-thuat').innerHTML = veMang(r.hocThuat.o);
    $('#noi-hoc-thuat').textContent = r.hocThuat.noiThang;

    $('#o-bo-may').innerHTML = veMang(r.boMay.o);
    $('#noi-bo-may').textContent = r.boMay.tiLeXong === null
      ? 'Chưa có việc nào được giao nên chưa đo được tỉ lệ hoàn thành.'
      : 'Tỉ lệ hoàn thành bảy ngày: ' + (r.boMay.tiLeXong * 100).toFixed(1) + '%.';

    $('#o-bo-nao').innerHTML = veMang(r.boNao.o);
    $('#noi-bo-nao').textContent = r.boNao.ghiChu
      || 'Mọi lệnh đều đi qua bộ não theo đúng năm bước: bảo mật, hiến pháp, đọc lệnh, '
        + 'giao việc, thanh tra.';
    $('#bang-loai-lenh').innerHTML = CF.bang(['Loại lệnh', 'Số lượt'],
      r.boNao.theoLoai.map((x) => [CF.thoat(x.loai), CF.soVn(x.so)]),
      'Chưa có lệnh nào trong 24 giờ qua.');

    $('#o-gia-dinh').innerHTML = veMang(r.quanHeGiaDinh.o);
    $('#noi-cay-tien').textContent = r.quanHeGiaDinh.cayTien;

    $('#o-tai-chinh').innerHTML = veMang(r.taiChinh.o);

    // ── Nền tảng ──
    const nk = r.nenTang.nhatKyKiemToan;
    $('#nen-nhat-ky').className = 'can-doi ' + (nk.lanh ? 'dat' : 'hong');
    $('#nen-nhat-ky').textContent = nk.lanh
      ? 'Nhật ký kiểm toán liền mạch · ' + CF.soVn(nk.soDong) + ' dòng. ' + (nk.khongChungMinh || '')
      : 'NHẬT KÝ ĐỨT CHUỖI: ' + nk.loi;

    const ai = r.nenTang.congAi;
    $('#nen-ai').className = 'can-doi ' + (ai.tongLuotConLai > 0 ? 'dat' : 'hong');
    $('#nen-ai').textContent = ai.soNhaCoKhoa === 0
      ? 'Chưa cắm khoá nhà cung cấp AI nào. Mọi đường cần AI sẽ báo lỗi thật, '
        + 'không bịa câu trả lời.'
      : ai.soNhaCoKhoa + ' nhà có khoá · còn ' + CF.soVn(ai.tongLuotConLai) + ' lượt trong ngày.';
    $('#bang-ai').innerHTML = CF.bang(['Nhà cung cấp', 'Có khoá', 'Đã gọi', 'Còn lại', 'Tình trạng'],
      ai.theoNha.map((n) => [CF.thoat(n.ten), n.coKhoa ? 'có' : '—',
        CF.soVn(n.daGoi), CF.soVn(n.conLai),
        '<span class="nhan-tt ' + (n.tinhTrang === 'healthy' ? 'dat'
          : n.tinhTrang === 'chua-do' ? '' : 'canh') + '">'
        + CF.thoat(n.tinhTrang) + '</span>']));

    const d = r.nenTang.khoDem;
    $('#nen-dem').textContent = 'Kho đệm: ' + CF.soVn(d.soMuc) + ' mục · '
      + CF.soVn(d.luotTrung) + ' lượt trúng · tiết kiệm ' + CF.soVn(d.theDaTietKiem) + ' thẻ'
      + (d.coL1 ? ' · có tầng KV' : ' · chưa gắn KV, chạy hai tầng');

    $('#tinh-trang-chung').textContent = {
      'binh-thuong': 'Bình thường', 'co-viec-cho': 'Có việc chờ',
      'can-xu-ly-ngay': 'Cần xử lý ngay',
    }[r.tinhTrangChung] || r.tinhTrangChung;
    $('#tinh-trang-chung').className = 'nhan-tt '
      + (r.tinhTrangChung === 'can-xu-ly-ngay' ? 'hong'
        : r.tinhTrangChung === 'co-viec-cho' ? 'canh' : 'dat');
    $('#luc-doc').textContent = 'Đọc lúc ' + CF.luc(r.luc);
  }

  async function napBaoMat() {
    const r = await CF.can('/api/bao-mat/tinh-hinh?soGio=24', 'tình hình bảo mật');
    if (!r) return;
    const l = r.lop;
    $('#noi-lop').textContent = l.noiThang;
    const ve = (ds, ten) => '<h3>' + ten + '</h3>' + CF.bang(['Mã', 'Lớp', 'Làm đủ', 'Giải thích'],
      ds.map((x) => [CF.thoat(x.ma), CF.thoat(x.ten),
        x.dayDu ? '<span class="nhan-tt dat">đủ</span>'
          : '<span class="nhan-tt canh">chưa đủ</span>',
        '<span class="rat-nho">' + CF.thoat(x.giaiThich) + '</span>']));
    $('#bang-lop').innerHTML = ve(l.phongVe, 'Mười lớp phòng vệ ngoài')
      + ve(l.tangTrong, 'Mười hai tầng trong');
    $('#bang-chan').innerHTML = CF.bang(['Lúc', 'Lớp', 'Lý do', 'Đường dẫn', 'Địa chỉ'],
      r.chanGanDay.map((c) => [CF.luc(c.luc), CF.thoat(c.lop), CF.thoat(c.lyDo),
        CF.thoat(c.duongDan || '—'), CF.thoat(c.ip || '—')]),
      'Chưa có lượt nào bị chặn trong 24 giờ qua.');
    $('#so-dang-chan').textContent = 'Đang chặn: ' + CF.soVn(r.soMucDangChan) + ' mục.';
  }

  async function napCrm() {
    const r = await CF.can('/api/tong/crm', 'bảng quan hệ gia đình');
    if (!r) return;
    $('#crm-pheu').innerHTML = CF.bang(['Chặng', 'Số gia đình'],
      r.pheu.map((p) => [CF.thoat(p.chang), CF.soVn(p.so)]),
      'Chưa có gia đình nào trong phễu.');
    $('#crm-to').innerHTML = CF.bang(['Tổ', 'Số người', 'Việc đang làm'],
      r.theoTo.map((t) => [CF.thoat(t.to), CF.soVn(t.soNguoi), CF.soVn(t.viecDangLam)]));
    $('#crm-cho-nguoi').innerHTML = CF.bang(['Loại việc', 'Số lượt chờ người duyệt'],
      r.choNguoiDuyet.map((c) => [CF.thoat(c.loai), CF.soVn(c.so)]),
      'Không có việc nào đang chờ người duyệt.');
    $('#crm-luu-y').textContent = r.luuY;
  }

  async function napTaiChinh() {
    const ky = $('#ky-tc').value || new Date().toISOString().slice(0, 7);
    const r = await CF.can('/api/tong/tai-chinh?ky=' + encodeURIComponent(ky), 'bảng tài chính');
    if (!r) return;
    $('#tc-can-doi').className = 'can-doi ' + (r.canDoi ? 'dat' : 'hong');
    $('#tc-can-doi').textContent = 'Kỳ ' + r.ky + ' · ' + r.trangThaiKy
      + ' · Nợ ' + CF.tien(r.tongPhatSinhNo) + ' · Có ' + CF.tien(r.tongPhatSinhCo)
      + (r.canDoi ? ' · cân đối' : ' · LỆCH ' + CF.tien(Math.abs(r.lech)));
    $('#tc-khoa').textContent = r.khoaDuocKhong
      ? 'Kỳ này khoá được.'
      : 'Chưa khoá được: ' + (r.viSaoChuaKhoaDuoc || 'chưa rõ');
    $('#tc-loai').innerHTML = CF.bang(['Loại chứng từ', 'Số lượng', 'Tổng tiền'],
      r.theoLoai.map((t) => [CF.thoat(t.loai), CF.soVn(t.so), CF.tien(t.tien)]),
      'Kỳ này chưa có chứng từ nào đã ghi sổ.');
  }

  async function napTinHieu() {
    const r = await CF.can('/api/tin-hieu/chi-bao', 'thư viện chỉ báo');
    if (!r) return;
    $('#th-cach-do').textContent = r.cachDo;
    $('#th-bang').innerHTML = CF.bang(['Mã', 'Chỉ báo', 'Đọc thế nào', 'Nó đo gì'],
      r.chiBao.map((c) => [CF.thoat(c.ma), CF.thoat(c.ten), CF.thoat(c.chieuDoc),
        '<span class="rat-nho">' + CF.thoat(c.y) + '</span>']));
  }

  async function doSucTienDoan() {
    $('#th-ket-qua').innerHTML = '<p class="rong">Đang đo… việc này đọc nhiều dữ liệu, '
      + 'có thể mất một lát.</p>';
    const r = await CF.can('/api/tin-hieu/suc-tien-doan?soNgay=180', 'đo sức tiên đoán');
    if (!r) { $('#th-ket-qua').innerHTML = ''; return; }
    if (!r.coDuLieu) {
      $('#th-ket-qua').innerHTML = '<p class="rong">' + CF.thoat(r.noiThang) + '</p>';
      return;
    }
    $('#th-ket-qua').innerHTML = '<p class="phu">' + CF.thoat(r.noiThang) + '</p>'
      + CF.bang(['Chỉ báo', 'IC trung bình', 'IR', 'Suy giảm', 'Dùng được'],
        r.chiBao.map((c) => [CF.thoat(c.ten),
          c.icTrungBinh === null ? '—' : c.icTrungBinh,
          c.ir === null ? '—' : c.ir,
          '<span class="rat-nho">' + CF.thoat(c.suyGiam) + '</span>',
          c.dungDuoc ? '<span class="nhan-tt dat">có</span>'
            : '<span class="nhan-tt">chưa chứng minh</span>']));
  }

  async function quetNguong() {
    $('#th-nguong').innerHTML = '<p class="rong">Đang kiểm nghiệm ngược…</p>';
    const r = await CF.can('/api/tin-hieu/quet-nguong', 'quét ngưỡng',
      { soBaiToiThieu: 60, tiLeSau: 0.85, soNgaySau: 30 });
    if (!r) { $('#th-nguong').innerHTML = ''; return; }
    const dung = r.dai.filter((x) => x.duMau);
    $('#th-nguong').innerHTML = '<p class="phu">' + CF.thoat(r.noiThang) + '</p>'
      + CF.bang(['Ngưỡng', 'Qua ngưỡng thì đạt', 'Mức nền', 'Hơn nền', 'Bỏ sót', 'Cỡ mẫu'],
        dung.map((x) => [(x.tiLe * 100).toFixed(0) + '%',
          x.chinhXacKhiQua === null ? '—' : (x.chinhXacKhiQua * 100).toFixed(1) + '%',
          x.tiLeNen === null ? '—' : (x.tiLeNen * 100).toFixed(1) + '%',
          x.honMucNen === null ? '—' : (x.honMucNen * 100).toFixed(1) + ' điểm',
          x.boSot === null ? '—' : (x.boSot * 100).toFixed(1) + '%',
          CF.soVn(x.coMau)]),
        'Chưa dải ngưỡng nào đủ mẫu để kiểm nghiệm. Cần dữ liệu làm bài thật đã.');
  }

  function batDau() {
    $('#ky-tc').value = new Date().toISOString().slice(0, 7);
    $$('.tab button').forEach((b) => b.addEventListener('click', () => doiMan(b.dataset.man)));
    $('#ky-tc').addEventListener('change', napTaiChinh);
    $('#nut-do-tien-doan').addEventListener('click', doSucTienDoan);
    $('#nut-quet-nguong').addEventListener('click', quetNguong);
    $('#nut-doc-lai').addEventListener('click', napTong);
    napTong();
    doiMan('tong-quan');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', batDau);
  } else batDau();
})();
