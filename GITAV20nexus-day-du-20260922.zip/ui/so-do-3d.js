'use strict';
/**
 * Sơ đồ tư duy ba chiều — lớp tương tác.
 *
 * XOAY BẰNG CÁCH XIN MÁY CHỦ VẼ LẠI, không xoay ở trình duyệt. Hơi ngược với
 * thói quen, nhưng có lý do: toán chiếu chỉ nằm ở MỘT chỗ, nên hình trên màn
 * hình và hình tải về in ra giấy luôn giống hệt nhau. Viết lại phép chiếu ở
 * phía trình duyệt là có hai bản, và hai bản thì sớm muộn lệch nhau.
 *
 * Mỗi lần kéo chuột KHÔNG gọi ngay: gom lại và chỉ xin vẽ khi đã dừng tay.
 * Không gom thì một cú kéo sinh ra hàng trăm lượt gọi.
 */
(function () {
  const $ = (id) => document.getElementById(id);
  const S = { doc: 0.6, ngang: 0.28, kieu: 'toan-canh', goc: '', buoc: 1, chuHet: false };
  let hen = null;

  function duongDan(dinhDang) {
    const q = new URLSearchParams({
      kieu: S.kieu, doc: S.doc.toFixed(3), ngang: S.ngang.toFixed(3),
      rong: '1100', cao: '720',
    });
    if (S.goc) q.set('goc', S.goc);
    if (S.kieu === 'quanh-mot') q.set('buoc', String(S.buoc));
    if (S.chuHet) q.set('chu', 'het');
    return `/so-do-3d/${dinhDang}?${q}`;
  }

  function veLai() {
    $('hinh').src = duongDan('hinh.svg');
    $('nutTai').href = duongDan('hinh.svg');
  }

  /** Gom các lần kéo: chỉ xin vẽ khi đã dừng tay. */
  function veLaiSau(ms) {
    clearTimeout(hen);
    hen = setTimeout(veLai, ms);
  }

  async function napSo() {
    const q = new URLSearchParams({ kieu: S.kieu });
    if (S.goc) q.set('goc', S.goc);
    if (S.kieu === 'quanh-mot') q.set('buoc', String(S.buoc));
    const r = await G.api(`/so-do-3d?${q}`);
    if (!G.can(r, 'Sơ đồ tư duy')) { $('so').textContent = ''; return; }
    const t = r.thongKe;
    $('so').innerHTML = [
      ['Dạng', t.soNut], ['Quan hệ', t.soCanh], ['Tầng', t.soTang],
    ].map(([k, v]) => `<span>${k} <b>${v}</b></span>`).join('');
    $('ghiChu').textContent = r.ghiChu || '';
  }

  async function napDsDang() {
    const r = await G.api('/so-do-3d/dang');
    if (!G.can(r, 'Danh sách dạng toán')) return;
    const o = $('goc');
    for (const d of r.dang) {
      const x = document.createElement('option');
      x.value = d.ma;
      x.textContent = `${d.ma} — ${d.ten}`;
      o.appendChild(x);
    }
  }

  function doiKieu() {
    S.kieu = $('kieu').value;
    $('oBuoc').classList.toggle('hidden', S.kieu !== 'quanh-mot');
    // Hai kiểu sau cần một dạng gốc; chưa chọn thì đừng gọi rồi báo lỗi.
    if (S.kieu !== 'toan-canh' && !S.goc) {
      $('ghiChu').textContent = 'Chọn một dạng làm gốc để xem kiểu này.';
      return;
    }
    veLai(); napSo();
  }

  // ── Kéo để xoay ──
  let dangKeo = false;
  let x0 = 0;
  let y0 = 0;
  const img = $('hinh');

  const batDau = (e) => {
    dangKeo = true;
    img.classList.add('keo');
    const p = e.touches ? e.touches[0] : e;
    x0 = p.clientX; y0 = p.clientY;
  };
  const dangDi = (e) => {
    if (!dangKeo) return;
    const p = e.touches ? e.touches[0] : e;
    S.doc += (p.clientX - x0) * 0.006;
    // Chặn lật ngược: quá nửa vòng thì hình lộn đầu và người xem mất phương hướng.
    S.ngang = Math.max(-1.2, Math.min(1.2, S.ngang + (p.clientY - y0) * 0.005));
    x0 = p.clientX; y0 = p.clientY;
    veLaiSau(110);
    e.preventDefault();
  };
  const dungLai = () => { dangKeo = false; img.classList.remove('keo'); };

  img.addEventListener('mousedown', batDau);
  window.addEventListener('mousemove', dangDi);
  window.addEventListener('mouseup', dungLai);
  img.addEventListener('touchstart', batDau, { passive: true });
  img.addEventListener('touchmove', dangDi, { passive: false });
  img.addEventListener('touchend', dungLai);

  $('kieu').addEventListener('change', doiKieu);
  $('goc').addEventListener('change', () => { S.goc = $('goc').value; veLai(); napSo(); });
  $('buoc').addEventListener('change', () => { S.buoc = +$('buoc').value; veLai(); napSo(); });
  $('nutHet').addEventListener('click', () => {
    S.chuHet = !S.chuHet;
    $('nutHet').textContent = S.chuHet ? 'Chỉ hiện tên không chồng nhau' : 'Hiện hết tên dạng';
    veLai();
  });
  $('nutThang').addEventListener('click', () => { S.doc = 0.6; S.ngang = 0.28; veLai(); });

  document.addEventListener('DOMContentLoaded', () => { napDsDang(); napSo(); veLai(); });
}());
