'use strict';
/**
 * GÓC HỌC TẬP — giao diện học viên.
 * Nguyên tắc: mỗi màn hình phải trả lời được "bây giờ em làm gì tiếp".
 */
const App = (function () {
  const { api, $, esc, tex, buocGiai, pct, stars, vn, toast, table, bar, radar, lineChart, barChart } = G;

  const S = {
    tab: 'home',
    user: null,
    learnerId: null,
    practice: null,      // phiên luyện đang mở
    placement: null,     // phiên xếp tầng đang mở
    exam: null,          // bài thi đang mở
    hintsShown: 0,
    itemStartAt: 0,
    level: 3,            // tầng hiện tại — quyết định tốc độ đọc của giọng giảng
  };

  // ── Vào / ra ─────────────────────────────────────────────────────────────

  /**
   * Hiện nút khuôn mặt CHỈ KHI máy thật sự có bộ xác thực sinh trắc học gắn
   * trong. Hiện sẵn rồi báo lỗi khi bấm là hứa một thứ không có — và người
   * dùng sẽ nhớ lời hứa hỏng ấy lâu hơn nhớ tính năng.
   */
  async function doKhuonMat() {
    const nut = G.$('nutKhuonMat');
    const ghi = G.$('ghiKhuonMat');
    if (!nut) return;
    if (await G.mayCoSinhTracHoc()) {
      nut.classList.remove('hidden');
      if (ghi) ghi.classList.remove('hidden');
    }
  }

  async function vaoBangKhuonMat() {
    const loi = G.$('loginErr');
    if (loi) loi.textContent = '';
    const ten = (G.$('lUser') && G.$('lUser').value.trim()) || null;
    const r = await G.vaoBangKhuonMat(ten);
    if (!r.ok) {
      if (loi) loi.textContent = G.noiLoiKhuonMat(r);
      return;
    }
    if (r.user.role !== 'LEARNER') {
      if (loi) loi.textContent = 'Tài khoản này không phải tài khoản học viên.';
      G.clearSession();
      return;
    }
    await enter(r.user);
  }

  async function login() {
    $('loginErr').textContent = '';
    const r = await G.login($('lUser').value.trim(), $('lPass').value);
    if (!r.ok) {
      $('loginErr').textContent = r.error === 'INVALID_CREDENTIALS' ? 'Sai tên đăng nhập hoặc mật khẩu.'
        : r.error === 'LOCKED_OUT' ? `Tài khoản đang bị khoá, thử lại sau ${r.remainMin} phút.`
          : r.error === 'ACCOUNT_DISABLED' ? 'Tài khoản đã bị khoá. Hỏi thầy cô.'
            : (r.message || r.error || 'Không đăng nhập được.');
      return;
    }
    if (r.user.role !== 'LEARNER') {
      $('loginErr').textContent = 'Tài khoản này không phải tài khoản học viên.';
      G.clearSession();
      return;
    }
    await enter(r.user);
  }

  async function enter(user) {
    S.user = user;
    S.learnerId = (user.scope?.learnerIds || [])[0] || user.id;
    $('login').classList.remove('active');
    $('main').classList.add('active');
    $('sideUser').textContent = user.fullName || user.username;
    Voice.mountPicker($('voicePick'), { division: 'MATH', limit: 80 });
    await refresh();
  }

  async function logout() {
    await G.logout();
    location.reload();
  }

  function setTab(tab) {
    S.tab = tab;
    document.querySelectorAll('#nav a').forEach((a) => a.classList.toggle('on', a.dataset.tab === tab));
    document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('hidden', t.id !== `tab-${tab}`));
    $('tabTitle').textContent = ({
      home: 'Hôm nay', practice: 'Luyện tập', roadmap: 'Lộ trình',
      progress: 'Tiến bộ', exam: 'Thi lên tầng',
    })[tab] || tab;
    ({ home: loadHome, practice: () => {}, roadmap: loadRoadmap, progress: loadProgress, exam: loadExam })[tab]?.();
  }

  async function refresh() { await loadHome(); }

  // ── Hôm nay ──────────────────────────────────────────────────────────────

  async function loadHome() {
    const [p, wk, tr] = await Promise.all([
      api(`/learner/${encodeURIComponent(S.learnerId)}/portrait`),
      api(`/roadmap/${encodeURIComponent(S.learnerId)}/this-week`),
      api(`/behavior/${encodeURIComponent(S.learnerId)}/trend`),
    ]);

    const lv = p.ok ? p.level : null;
    if (typeof lv === 'number') S.level = lv;
    $('levelPill').textContent = lv != null ? `Tầng ${p.levelCode || 'L' + lv}` : 'Chưa xếp tầng';

    const cards = [];
    cards.push(card('Tầng hiện tại', lv == null ? '—' : `L${lv}`, p.ok ? (p.levelName || '') : 'Hãy làm bài kiểm tra xếp tầng'));
    if (p.ok) {
      cards.push(card('Mức thạo trung bình', pct(p.mastery?.avgMastery ?? p.avgMastery, 0), `${p.mastery?.formsMastered ?? 0} dạng đã thạo`));
      cards.push(card('Số bài đã làm', vn(p.totalAttempts ?? p.metrics?.items ?? 0), 'tính cả bài thi'));
    }
    if (tr.ok && tr.enough) {
      cards.push(card('Xu hướng', tr.direction, tr.evidence, tr.direction === 'ĐANG LÊN' ? 'ok' : tr.direction === 'ĐANG XUỐNG' ? 'err' : ''));
    }
    $('homeCards').innerHTML = cards.join('');

    if (wk.ok) {
      $('weekBox').innerHTML = `
        <div class="muted">Tuần ${wk.week}/13 · chặng ${esc(wk.stage.name)} — ${esc(wk.stage.goal)} · còn ${wk.daysLeft} ngày</div>
        ${wk.checkpoint ? `<p class="warn">Tuần này có mốc kiểm: ${esc(wk.checkpoint.note)}</p>` : ''}
        <table><thead><tr><th>Dạng trọng tâm</th><th>Mức thạo</th><th class="num">Mục tiêu</th><th></th></tr></thead><tbody>
        ${wk.focusForms.map((f) => `<tr>
          <td>${esc(f.name)}</td>
          <td>${bar(f.currentMastery, f.reached ? 'ok' : '')} ${pct(f.currentMastery, 0)}</td>
          <td class="num">${pct(wk.targetMastery, 0)}</td>
          <td>${f.reached ? '<span class="tag ok">đạt</span>' : '<span class="tag">đang học</span>'}</td>
        </tr>`).join('')}
        </tbody></table>
        <p class="muted">Kế hoạch: ${wk.sessions} buổi × ${wk.itemsPerSession} bài.</p>`;
      $('homeHint').textContent = `Hôm nay nên làm khoảng ${wk.itemsPerSession} bài.`;
      $('sessionSize').value = wk.itemsPerSession;
    } else {
      $('weekBox').innerHTML = `<div class="muted">Chưa có lộ trình.</div>
        <button class="primary" onclick="App.makeRoadmap()">Tạo lộ trình 90 ngày cho em</button>`;
    }
  }

  function card(k, v, s, cls = '') {
    return `<div class="card ${cls}"><div class="k">${esc(k)}</div><div class="v">${esc(v)}</div><div class="s">${esc(s || '')}</div></div>`;
  }

  async function makeRoadmap() {
    const r = await api('/roadmap/generate', { learnerId: S.learnerId });
    toast(r.ok ? 'Đã tạo lộ trình 90 ngày.' : (r.error || 'Không tạo được'), r.ok ? 'ok' : 'err');
    if (r.ok) await loadHome();
  }

  // ── Xếp tầng ─────────────────────────────────────────────────────────────

  async function startPlacement() {
    const r = await api('/placement/start', { learnerId: S.learnerId });
    if (!r.ok) return toast(r.hint || r.error || 'Không mở được bài kiểm tra', 'err');
    S.placement = { sessionId: r.sessionId, item: r.item, progress: r.progress };
    setTab('practice');
    renderPlacement(r.seedReason);
  }

  function renderPlacement(note) {
    const it = S.placement.item;
    S.itemStartAt = Date.now();
    $('practiceBox').innerHTML = `
      <div class="panel">
        <h3>Bài kiểm tra xếp tầng</h3>
        ${note ? `<p class="hint">${esc(note)}</p>` : ''}
        <div class="muted">Câu ${S.placement.progress.asked}/${S.placement.progress.max} · ${esc(it.formName)} · ${stars(it.stars)}</div>
        <div class="item-card">
          <div class="stem">${tex(it.stem)}</div>
          <label>Đáp án của em<input id="ansInput" placeholder="ví dụ: x = 2 hoặc x = 3"></label>
          <div class="row">
            <button class="primary" onclick="App.answerPlacement()">Nộp câu này</button>
            <button class="ghost" onclick="App.answerPlacement(true)">Bỏ qua</button>
          </div>
        </div>
      </div>`;
    $('ansInput')?.focus();
  }

  async function answerPlacement(skip = false) {
    const ans = skip ? '' : ($('ansInput')?.value || '').trim();
    if (!skip && !ans) return toast('Nhập đáp án trước đã.', 'err');
    const grade = skip ? { correct: false } : await api('/practice/grade', { itemId: S.placement.item.id, answer: ans });
    const correct = grade.correct === null ? false : !!grade.correct;
    const r = await api('/placement/answer', {
      sessionId: S.placement.sessionId, itemId: S.placement.item.id,
      correct, ms: Date.now() - S.itemStartAt, hintsUsed: 0,
    });
    if (!r.ok) return toast(r.error || 'Lỗi', 'err');
    if (r.done) { S.placement = null; return renderPlacementResult(r); }
    S.placement.item = r.item;
    S.placement.progress = r.progress;
    renderPlacement();
  }

  function renderPlacementResult(r) {
    $('practiceBox').innerHTML = `
      <div class="panel">
        <h3>Kết quả xếp tầng</h3>
        <div class="cards">
          ${card('Tầng của em', r.placedName, `độ tin cậy ${r.confidence}`)}
          ${card('Làm đúng', `${r.correct}/${r.itemsAsked}`, pct(r.accuracy, 0))}
          ${card('Thời gian', `${Math.round(r.durationSec / 60)} phút`, `${r.itemsAsked} câu`)}
        </div>
        <h3>Hệ thống khuyên</h3>
        <ul>${r.recommendation.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>
        ${r.weaknesses.length ? `<p><b>Cần luyện thêm:</b> ${esc(r.weaknesses.join('; '))}</p>` : ''}
        ${r.strengths.length ? `<p><b>Đã vững:</b> ${esc(r.strengths.join('; '))}</p>` : ''}
        ${r.prerequisiteGaps.length ? `<p class="warn">Có ${r.prerequisiteGaps.length} lỗ hổng nền chặn đường các dạng sắp học.</p>` : ''}
        <div class="row"><button class="primary" onclick="App.makeRoadmap();App.setTab('home')">Tạo lộ trình theo kết quả này</button></div>
      </div>`;
    loadHome();
  }

  // ── Luyện tập ────────────────────────────────────────────────────────────

  async function startPractice() {
    const size = Number($('sessionSize')?.value) || 10;
    const r = await api('/practice/start', { learnerId: S.learnerId, size });
    if (!r.ok) return toast(r.hint || r.error || 'Chưa mở được phiên luyện', 'err');
    S.practice = { sessionId: r.sessionId, item: r.item, composition: r.composition, size: r.size };
    setTab('practice');
    renderItem();
  }

  function renderItem() {
    const it = S.practice.item;
    if (!it) return renderReport();
    S.hintsShown = 0;
    S.itemStartAt = Date.now();
    $('practiceBox').innerHTML = `
      <div class="panel">
        <div class="toolbar">
          <span class="pill">Câu ${it.index}/${it.total}</span>
          <span class="tag">${esc(it.sourceName)}</span>
          <span class="stars">${stars(it.stars)}</span>
          <span class="spacer"></span>
          <button class="ghost" onclick="App.finishPractice()">Dừng buổi học</button>
        </div>
        <p class="muted">${esc(it.formName)} — ${esc(it.why)}</p>
        <div class="item-card">
          <div class="stem">${tex(it.stem)}</div>
          <div class="voice-row">
            ${Voice.button(it.stem, { level: S.level, learnerId: S.learnerId })}
            <span class="muted">Nghe thầy cô đọc đề</span>
          </div>
          <label>Đáp án của em<input id="ansInput" placeholder="viết theo cách của em"></label>
          <div class="row">
            <button class="primary" onclick="App.submitAnswer()">Nộp</button>
            <button class="ghost" onclick="App.showHint()">Gợi ý</button>
          </div>
          <div id="hintBox"></div>
        </div>
      </div>`;
    $('ansInput')?.focus();
    $('ansInput')?.addEventListener('keydown', (e) => { if (e.key === 'Enter') submitAnswer(); });
  }

  function showHint() {
    const hints = S.practice.item.hints || [];
    if (S.hintsShown >= hints.length) return toast('Hết gợi ý rồi, em thử làm tiếp nhé.', '');
    const h = hints[S.hintsShown++];
    $('hintBox').innerHTML += `<p class="hint">Gợi ý ${S.hintsShown}: ${tex(h)}</p>`;
  }

  async function submitAnswer() {
    const ans = ($('ansInput')?.value || '').trim();
    if (!ans) return toast('Nhập đáp án trước đã.', 'err');
    const r = await api('/practice/answer', {
      sessionId: S.practice.sessionId, itemId: S.practice.item.itemId,
      answer: ans, ms: Date.now() - S.itemStartAt, hintsUsed: S.hintsShown,
    });
    if (!r.ok) return toast(r.error || 'Lỗi', 'err');
    if (r.pending) {
      toast('Bài này thầy cô sẽ chấm.', '');
      S.practice.item = r.next;
      return r.next ? renderItem() : renderReport();
    }
    renderFeedback(r);
  }

  function renderFeedback(r) {
    const fb = r.feedback || {};
    S.lastFeedback = fb;
    const ok = r.correct;
    $('practiceBox').innerHTML = `
      <div class="panel">
        <h3 class="${ok ? '' : 'warn'}">${ok ? 'Đúng rồi' : 'Chưa đúng'}</h3>
        <p>${esc(fb.note || '')}</p>
        ${r.grade?.reason ? `<p class="muted">${esc(r.grade.reason)}</p>` : ''}
        ${!ok && fb.traps?.length ? `<p class="warn">Chỗ hay nhầm ở dạng này: ${esc(fb.traps.join('; '))}</p>` : ''}
        ${fb.solutionSteps?.length ? `<div class="item-card"><b>Lời giải</b><ol>${buocGiai(fb).map((b) => `<li>${tex(b.viec)}`
          + (b.canCu ? `<span class="can-cu">${tex(b.canCu)}</span>` : '')
          + '</li>').join('')}</ol>
          <div class="voice-row">
            <button class="ghost" onclick="App.listenSolution()">🔊 Nghe thầy cô chữa từng bước</button>
            <span class="ai-tag">Giọng AI</span>
          </div></div>` : ''}
        ${r.adapted?.length ? `<p class="hint">${r.adapted.map(esc).join(' ')}</p>` : ''}
        ${r.done ? '' : `<div class="row"><button class="primary" onclick="App.nextItem()">Câu tiếp theo</button></div>`}
      </div>`;
    if (r.done) { S.practice.report = r; renderReport(r); return; }
    S.practice.item = r.next;
  }

  function nextItem() { renderItem(); }

  /**
   * Nghe chữa bài: đọc lần lượt từng bước, nghỉ giữa các bước cho em kịp nhìn
   * vào vở. Kịch bản do máy chủ dựng (đọc công thức, đọc số, ngắt câu), giao
   * diện chỉ phát theo — để lời đọc trên web và trên app giống hệt nhau.
   */
  async function listenSolution() {
    const fb = S.practice?.report?.feedback || S.lastFeedback || {};
    const steps = fb.solutionSteps || [];
    if (!steps.length) return toast('Bài này chưa có lời giải từng bước.', '');
    const r = await api('/voice/narrate-text', {
      text: buocGiai(fb).map((b, i) => `Bước ${i + 1}. ${b.viec}`
        + (b.canCu ? ` Căn cứ: ${b.canCu}` : '')).join(' '),
      level: S.level,
    });
    if (!r.ok) return toast('Chưa dựng được lời đọc.', 'err');
    toast('Đang đọc lời giải — bấm bất kỳ nút Nghe nào để dừng.', '');
    await Voice.playScript(r.segments, { level: S.level, learnerId: S.learnerId });
  }

  async function finishPractice() {
    const r = await api('/practice/finish', { sessionId: S.practice.sessionId });
    renderReport(r);
  }

  function renderReport(r) {
    const rep = r || S.practice?.report;
    if (!rep || !rep.ok) { $('practiceBox').innerHTML = '<div class="muted">Buổi học đã kết thúc.</div>'; return; }
    S.practice = null;
    $('practiceBox').innerHTML = `
      <div class="panel">
        <h3>Kết quả buổi học</h3>
        <div class="cards">
          ${card('Làm đúng', `${rep.correct}/${rep.answered}`, pct(rep.accuracy, 0))}
          ${card('Thời gian', `${rep.minutes} phút`, `${rep.avgSecondsPerItem}s mỗi bài`)}
          ${card('Gợi ý đã dùng', vn(rep.hintsUsed), rep.rushedCount ? `${rep.rushedCount} bài làm quá nhanh` : 'nhịp làm bài ổn')}
        </div>
        <h3>Theo từng dạng</h3>
        ${table(rep.byForm, [
      { label: 'Dạng', get: (x) => x.name || x.formCode },
      { label: 'Đúng', get: (x) => `${x.correct}/${x.done}` },
      { label: 'Tỉ lệ', html: true, get: (x) => `${bar(x.accuracy, x.accuracy >= 0.8 ? 'ok' : x.accuracy >= 0.5 ? 'warn' : 'err')} ${pct(x.accuracy, 0)}` },
    ])}
        <h3>Lời khuyên cho buổi sau</h3>
        <ul>${rep.nextAdvice.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>
        <div class="row"><button class="primary" onclick="App.setTab('home')">Về trang chính</button></div>
      </div>`;
    loadHome();
  }

  // ── Lộ trình ─────────────────────────────────────────────────────────────

  async function loadRoadmap() {
    const [rm, pg] = await Promise.all([
      api(`/roadmap/${encodeURIComponent(S.learnerId)}`),
      api(`/roadmap/${encodeURIComponent(S.learnerId)}/progress`),
    ]);
    if (!rm.ok) {
      $('rmCards').innerHTML = '';
      $('rmWeeks').innerHTML = `<div class="muted">Chưa có lộ trình.</div>
        <button class="primary" onclick="App.makeRoadmap()">Tạo lộ trình 90 ngày</button>`;
      $('rmAdjust').innerHTML = '';
      return;
    }
    const r = rm.roadmap;
    $('rmCards').innerHTML = [
      card('Đích đến', r.targetLevelName, `từ ${r.levelName}`),
      card('Tuần', `${pg.ok ? pg.week : 1}/13`, pg.ok ? `còn ${pg.weeksLeft} tuần` : ''),
      card('Nội dung đã thạo', pg.ok ? `${pg.formsMastered}/${pg.formsPlanned}` : '—', pg.ok ? pct(pg.contentProgress, 0) : '', pg.ok && pg.onTrack ? 'ok' : 'warn'),
      card('Mỗi buổi', `${r.itemsPerSession} bài`, `${r.sessionsPerWeek} buổi/tuần`),
    ].join('');
    $('rmWeeks').innerHTML = `
      <p class="muted">${esc(r.feasibility.verdict)}</p>
      ${table(r.weeks, [
      { label: 'Tuần', get: (w) => w.week },
      { label: 'Chặng', get: (w) => w.stage.name },
      { label: 'Dạng trọng tâm', get: (w) => w.focusForms.map((f) => f.name).join('; ') || '—' },
      { label: 'Mục tiêu thạo', cls: 'num', get: (w) => pct(w.targetMastery, 0) },
      { label: 'Mốc kiểm', html: true, get: (w) => (w.checkpoint ? `<span class="tag ok">${esc(w.checkpoint.kind === 'EXIT_EXAM' ? 'Thi cuối tầng' : 'Kiểm tra')}</span>` : '') },
    ])}`;
    $('rmAdjust').innerHTML = r.adjustments.length
      ? r.adjustments.map((a) => `<div class="item-card">
          <b>Tuần ${a.week} — ${esc(a.verdict)}</b>
          <div class="muted">Làm ${a.itemsDone}/${a.itemsPlanned} bài · đúng ${pct(a.accuracy, 0)}</div>
          ${a.changes.length ? `<ul>${a.changes.map((c) => `<li>${esc(c.detail)} <span class="muted">(${esc(c.reason)})</span></li>`).join('')}</ul>` : '<div class="muted">Lộ trình giữ nguyên.</div>'}
        </div>`).join('')
      : '<div class="muted">Chưa có lần chỉnh nào.</div>';
  }

  // ── Tiến bộ ──────────────────────────────────────────────────────────────

  async function loadProgress() {
    const [p, b] = await Promise.all([
      api(`/learner/${encodeURIComponent(S.learnerId)}/portrait`),
      api(`/behavior/${encodeURIComponent(S.learnerId)}`),
    ]);
    if (!p.ok) { $('radarBox').innerHTML = `<div class="muted">${esc(p.error || 'Chưa có dữ liệu')}</div>`; return; }

    const axisName = { kienThuc: 'Kiến thức', chinhXac: 'Chính xác', tocDo: 'Tốc độ', tuLuc: 'Tự lực', kienTri: 'Kiên trì', chieuSau: 'Chiều sâu' };
    const axes = {};
    for (const [k, v] of Object.entries(p.axes || {})) axes[axisName[k] || k] = v;
    $('radarBox').innerHTML = radar(axes) + `<p class="muted">Xếp hạng: ${esc(p.grade5Star || '')}</p>`;

    const parts = [];
    if (b.ok) {
      parts.push(`<p>${esc(b.summary)}</p>`);
      if (b.actions?.length) parts.push(`<b>Nên làm</b><ul>${b.actions.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>`);
      if (b.attentionSpan?.enough) {
        parts.push(`<p class="muted">Ngưỡng chú ý: ${esc(b.attentionSpan.evidence)}</p>`);
      }
    }
    $('insightBox').innerHTML = parts.join('') || '<div class="muted">Chưa đủ dữ liệu để nhận xét.</div>';

    const forms = Object.entries(p.masteryByForm || {})
      .map(([code, v]) => ({ code, name: (p.formNames || {})[code] || code, p: v }))
      .sort((a, b2) => a.p - b2.p);
    $('masteryBox').innerHTML = table(forms, [
      { label: 'Dạng', get: (x) => x.name },
      { label: 'Mức thạo', html: true, get: (x) => `${bar(x.p, x.p >= 0.85 ? 'ok' : x.p >= 0.5 ? 'warn' : 'err')} ${pct(x.p, 0)}` },
    ], 'Chưa làm bài nào.');

    $('missBox').innerHTML = table(b.misconceptions || [], [
      { label: 'Dạng', get: (x) => x.formCode },
      { label: 'Chỗ hay nhầm', get: (x) => x.trap },
      { label: 'Số lần', cls: 'num', get: (x) => x.occurrences },
    ], 'Chưa ghi nhận lỗi lặp lại nào.');
  }

  // ── Thi lên tầng ─────────────────────────────────────────────────────────

  async function loadExam() {
    const r = await api(`/promotion/${encodeURIComponent(S.learnerId)}`);
    if (!r.ok) { $('promoBox').innerHTML = `<div class="muted">${esc(r.error || '')}</div>`; return; }
    const rows = Object.entries(r.criteria).map(([k, c]) => ({
      k, label: ({
        mastery: 'Mức thạo', accuracy: 'Độ chính xác', speed: 'Tốc độ', consistency: 'Số buổi đạt',
        coverage: 'Độ phủ dạng', exitExam: 'Điểm thi cuối tầng', noRegression: 'Không tụt tầng dưới',
      })[k] || k, c,
    }));
    $('promoBox').innerHTML = `
      <p class="${r.eligible ? '' : 'warn'}"><b>${esc(r.verdict)}</b></p>
      <p class="muted">${esc(r.note)}</p>
      ${table(rows, [
      { label: 'Tiêu chí', get: (x) => x.label },
      { label: 'Đang đạt', get: (x) => (typeof x.c.value === 'boolean' ? (x.c.value ? 'có' : 'chưa') : x.c.value ?? '—') },
      { label: 'Cần đạt', get: (x) => (typeof x.c.required === 'boolean' ? 'có' : x.c.required) },
      { label: '', html: true, get: (x) => (x.c.pass ? '<span class="tag ok">đạt</span>' : '<span class="tag err">chưa</span>') },
    ])}
      ${r.todo?.length ? `<h3>Việc cần làm</h3><ul>${r.todo.map((t) => `<li>${esc(t.what || t.hint || JSON.stringify(t))}</li>`).join('')}</ul>` : ''}`;

    $('examBox').innerHTML = S.exam ? renderExamPaper() : `
      <p class="muted">Bài thi gồm nhiều câu, có giới hạn thời gian. Làm xong mới nộp.</p>
      <button class="primary" onclick="App.startExam()">Bắt đầu thi</button>`;
  }

  async function startExam() {
    const r = await api('/exam/start', { learnerId: S.learnerId });
    if (!r.ok) {
      return toast(r.hint || r.detail || r.error || 'Chưa mở được bài thi', 'err');
    }
    S.exam = r;
    S.exam.answers = {};
    $('examBox').innerHTML = renderExamPaper();
  }

  function renderExamPaper() {
    const e = S.exam;
    return `
      <div class="toolbar">
        <span class="pill">${e.size} câu</span>
        <span class="pill">${Math.round(e.timeLimitSec / 60)} phút</span>
        <span class="pill">${esc(e.levelName)}</span>
        <span class="spacer"></span>
        <button class="primary" onclick="App.submitExam()">Nộp bài</button>
      </div>
      ${e.warning ? `<p class="warn">${esc(e.warning)}</p>` : ''}
      ${e.items.map((it) => `
        <div class="item-card">
          <div class="meta"><span class="tag">Câu ${it.index}</span><span class="stars">${stars(it.stars)}</span><span class="tag">${esc(it.formName)}</span></div>
          <div class="stem">${tex(it.stem)}</div>
          <label>Đáp án<input data-item="${esc(it.itemId)}" class="examAns" placeholder="đáp án của em"></label>
        </div>`).join('')}`;
  }

  async function submitExam() {
    const e = S.exam;
    for (const el of document.querySelectorAll('.examAns')) {
      const v = el.value.trim();
      if (v) await api('/exam/answer', { examId: e.examId, itemId: el.dataset.item, answer: v, ms: 120000 });
    }
    const r = await api('/exam/submit', { examId: e.examId });
    S.exam = null;
    if (!r.ok) return toast(r.error || 'Không nộp được bài', 'err');
    $('examBox').innerHTML = `
      <h3>${r.passedExam ? 'Đạt phần thi' : 'Chưa đạt phần thi'}</h3>
      <div class="cards">
        ${card('Điểm có trọng số', pct(r.weightedScore, 0), `cần ${pct(r.requiredScore, 0)}`, r.passedExam ? 'ok' : 'err')}
        ${card('Làm đúng', `${r.correct}/${r.graded}`, pct(r.score, 0))}
        ${card('Thời gian', `${r.minutes} phút`, r.pendingManual ? `${r.pendingManual} câu chờ thầy cô chấm` : '')}
      </div>
      ${table(r.byForm, [
      { label: 'Dạng', get: (x) => x.name || x.formCode },
      { label: 'Đúng', get: (x) => `${x.correct}/${x.total}` },
      { label: 'Tỉ lệ', html: true, get: (x) => `${bar(x.accuracy, x.accuracy >= 0.8 ? 'ok' : 'warn')} ${pct(x.accuracy, 0)}` },
    ])}`;
    loadExam();
  }

  // ── Khởi động ────────────────────────────────────────────────────────────

  document.addEventListener('DOMContentLoaded', async () => {
    // Dò xem máy này có cảm biến sinh trắc học không, rồi mới hiện nút.
    doKhuonMat();
    document.querySelectorAll('#nav a').forEach((a) => a.addEventListener('click', () => setTab(a.dataset.tab)));
    $('lPass')?.addEventListener('keydown', (e) => { if (e.key === 'Enter') login(); });
    const u = G.getUser();
    if (u && G.getToken()) await enter(u);
  });

  return {
    login, logout, setTab, refresh, makeRoadmap, vaoBangKhuonMat, doKhuonMat,
    startPlacement, answerPlacement,
    startPractice, submitAnswer, showHint, nextItem, finishPractice, listenSolution,
    startExam, submitExam,
  };
})();
