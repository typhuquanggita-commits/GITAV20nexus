'use strict';
/**
 * Trang quan hệ gia đình.
 *
 * Một điều trang này CỐ Ý KHÔNG LÀM: không có chỗ nào hiện phân loại nội
 * bộ về khả năng chi trả của gia đình. Máy chủ đã bỏ cột ấy ra khỏi mọi
 * đường CRM thường, và trang này cũng không đi tìm nó ở đâu khác.
 * Đó là Điều 8 của hiến pháp vận hành.
 */
(function () {
  const CF = window.CF;
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];

  const TEN_CHANG = {
    moi: 'Mới', 'da-lien-he': 'Đã liên hệ', 'da-tu-van': 'Đã tư vấn',
    'da-test': 'Đã test', 'dang-hoc': 'Đang học', 'tam-dung': 'Tạm dừng', 'roi-di': 'Rời đi',
  };
  const TEN_VIEC = {
    'goi-dien': 'Gọi điện', 'nhan-tin': 'Nhắn tin', 'tu-van': 'Tư vấn',
    'xep-lich-test': 'Xếp lịch test', 'bao-ket-qua': 'Báo kết quả',
    'nhac-hoc-phi': 'Nhắc học phí', 'cham-soc': 'Chăm sóc', 'xu-ly-phan-nan': 'Xử lý phàn nàn',
  };

  let dangXem = null;

  function doiMan(ten) {
    $$('.man').forEach((m) => m.classList.toggle('hien', m.id === 'man-' + ten));
    $$('.tab button').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.man === ten)));
    if (ten === 'tong-quan') napTongQuan();
    if (ten === 'gia-dinh') napGiaDinh();
    if (ten === 'tro-ly') napTroLy();
  }

  async function napTongQuan() {
    const r = await CF.can('/api/crm', 'tổng quan');
    if (!r) return;
    $('#o-tong-quan').innerHTML =
      '<div class="the-o"><div class="so">' + CF.soVn(r.soTroLy) + '</div>'
      + '<div class="nhan">Trợ lý quan hệ gia đình</div>'
      + '<div class="y">Tách hẳn khỏi bộ máy chuyên môn: hai kho dữ liệu, hai bộ quyền.</div></div>'
      + '<div class="the-o"><div class="so">' + CF.soVn(r.viec.tong) + '</div>'
      + '<div class="nhan">Việc đã tạo</div>'
      + '<div class="y">' + CF.soVn(r.viec.dangCho) + ' đang chờ · '
      + CF.soVn(r.viec.choNguoiDuyet) + ' chờ người duyệt</div></div>'
      + '<div class="the-o"><div class="so">'
      + CF.soVn(r.pheu.reduce((s, x) => s + x.so, 0)) + '</div>'
      + '<div class="nhan">Gia đình trong phễu</div></div>';

    $('#ds-pheu').innerHTML = CF.bang(['Chặng', 'Số gia đình'],
      r.pheu.map((p) => ['<b>' + CF.thoat(TEN_CHANG[p.chang] || p.chang) + '</b>',
        CF.soVn(p.so)]));

    $('#ds-to').innerHTML = CF.bang(['Tổ', 'Khai', 'Thực tế', 'Việc'],
      r.to.map((t) => [CF.thoat(t.ten), CF.soVn(t.soKhai), CF.soVn(t.soThucTe),
        CF.thoat(t.viec)]));

    $('#luu-cay-tien').textContent = r.cayTien;
  }

  async function napGiaDinh() {
    const chang = $('#loc-chang').value;
    const r = await CF.can('/api/crm/gia-dinh' + (chang ? '?chang=' + encodeURIComponent(chang) : ''),
      'danh sách gia đình');
    if (!r) return;
    $('#ds-gia-dinh').innerHTML = CF.bang(
      ['Người liên hệ', 'Liên hệ', 'Tỉnh thành', 'Chặng', 'Trợ lý', ''],
      r.giaDinh.map((g) => [
        '<b>' + CF.thoat(g.tenLienHe) + '</b>',
        CF.thoat(g.dienThoai || g.email || '—'),
        CF.thoat(g.tinhThanh || '—'),
        '<span class="nhan-tt">' + CF.thoat(TEN_CHANG[g.chang] || g.chang) + '</span>',
        CF.thoat(g.troLy || '—'),
        '<button class="phu2" data-xem="' + CF.thoat(g.id) + '" type="button">Xem</button>',
      ]), 'Chưa có gia đình nào ở chặng này.');
  }

  async function xemChiTiet(id) {
    const r = await CF.can('/api/crm/gia-dinh/' + encodeURIComponent(id), 'chi tiết gia đình');
    if (!r) return;
    dangXem = r.giaDinh;
    const g = r.giaDinh;
    $('#chi-tiet').innerHTML =
      '<h2>' + CF.thoat(g.tenLienHe) + '</h2>'
      + '<p class="phu">' + CF.thoat(g.dienThoai || '') + ' ' + CF.thoat(g.email || '')
      + ' · ' + CF.thoat(g.tinhThanh || 'chưa rõ tỉnh thành')
      + ' · nguồn: ' + CF.thoat(g.nguonDen || 'chưa rõ') + '</p>'
      + '<div class="hang-nut" style="margin-bottom:14px">'
      + '<label style="max-width:230px">Chuyển chặng'
      + '<select id="chon-chang">'
      + Object.entries(TEN_CHANG).map(([m, t]) =>
        '<option value="' + m + '"' + (m === g.chang ? ' selected' : '') + '>'
        + CF.thoat(t) + '</option>').join('')
      + '</select></label>'
      + '<button class="chinh" type="button" id="nut-doi-chang">Lưu chặng</button></div>'
      + '<h3>Học viên</h3>'
      + CF.bang(['Tên', 'Quan hệ'],
        r.hocVien.map((h) => [CF.thoat(h.ten || h.userId), CF.thoat(h.quanHe)]),
        'Chưa gắn học viên nào.')
      + '<h3>Việc</h3>'
      + CF.bang(['Loại', 'Nội dung', 'Trạng thái'],
        r.viec.map((v) => [CF.thoat(TEN_VIEC[v.loai] || v.loai), CF.thoat(v.noiDung),
          '<span class="nhan-tt ' + (v.trangThai === 'xong' ? 'dat'
            : v.trangThai === 'cho-nguoi-duyet' ? 'canh' : '') + '">'
          + CF.thoat(v.trangThai) + '</span>']),
        'Chưa có việc nào.')
      + '<h3>Tương tác gần đây</h3>'
      + CF.bang(['Lúc', 'Kênh', 'Hướng', 'Tóm tắt'],
        r.tuongTac.map((t) => [CF.luc(t.luc), CF.thoat(t.kenh),
          t.huong === 'den' ? 'gia đình gọi tới' : 'mình gọi đi', CF.thoat(t.tomTat)]),
        'Chưa ghi tương tác nào.');
    $('#chi-tiet').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  async function doiChang() {
    if (!dangXem) return;
    const moi = $('#chon-chang').value;
    const r = await CF.can('/api/crm/gia-dinh/' + encodeURIComponent(dangXem.id) + '/chang',
      'chuyển chặng', { chang: moi });
    if (!r) return;
    CF.bao('Đã chuyển từ "' + (TEN_CHANG[r.tu] || r.tu) + '" sang "'
      + (TEN_CHANG[r.sang] || r.sang) + '".', 'dat');
    xemChiTiet(dangXem.id);
    napGiaDinh();
  }

  async function themGiaDinh(e) {
    e.preventDefault();
    const than = {
      tenLienHe: $('#gd-ten').value,
      dienThoai: $('#gd-dien-thoai').value || undefined,
      email: $('#gd-email').value || undefined,
      tinhThanh: $('#gd-tinh').value || undefined,
      nguonDen: $('#gd-nguon').value || undefined,
    };
    const r = await CF.can('/api/crm/gia-dinh', 'thêm gia đình', than);
    if (!r) return;
    CF.bao('Đã nhận đầu mối mới, giao cho ' + (r.troLy || 'tổ tiếp nhận') + '.', 'dat');
    e.target.reset();
    napGiaDinh();
  }

  async function themViec(e) {
    e.preventDefault();
    if (!dangXem) { CF.bao('Chọn một gia đình trước đã.', 'nhac'); return; }
    const r = await CF.can('/api/crm/viec', 'tạo việc', {
      giaDinhId: dangXem.id, loai: $('#v-loai').value, noiDung: $('#v-noi-dung').value,
    });
    if (!r) return;
    CF.bao(r.canNguoi
      ? 'Đã tạo việc. Việc này phải có người duyệt trước khi gửi ra ngoài.'
      : 'Đã tạo việc, giao cho ' + (r.troLy || 'tổ phụ trách') + '.', 'dat');
    e.target.reset();
    xemChiTiet(dangXem.id);
  }

  async function napTroLy() {
    const r = await CF.can('/api/crm/tro-ly', 'danh sách trợ lý');
    if (!r) return;
    $('#ds-tro-ly').innerHTML = CF.bang(
      ['Mã', 'Tên', 'Tổ', 'Vai', 'Mức tự chủ', 'Việc đang làm'],
      r.troLy.map((t) => [CF.thoat(t.ma), CF.thoat(t.ten), CF.thoat(t.to),
        CF.thoat(t.vai),
        t.mucTuChu === 0
          ? '<span class="nhan-tt canh">0 — luôn qua người</span>'
          : CF.soVn(t.mucTuChu),
        CF.soVn(t.viecDangLam)]));
  }

  function batDau() {
    $$('.tab button').forEach((b) => b.addEventListener('click', () => doiMan(b.dataset.man)));
    $('#ds-gia-dinh').addEventListener('click', (e) => {
      const id = e.target.dataset.xem;
      if (id) xemChiTiet(id);
    });
    $('#chi-tiet').addEventListener('click', (e) => {
      if (e.target.id === 'nut-doi-chang') doiChang();
    });
    $('#loc-chang').addEventListener('change', napGiaDinh);
    $('#form-gd').addEventListener('submit', themGiaDinh);
    $('#form-viec').addEventListener('submit', themViec);
    doiMan('tong-quan');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', batDau);
  } else batDau();
})();
