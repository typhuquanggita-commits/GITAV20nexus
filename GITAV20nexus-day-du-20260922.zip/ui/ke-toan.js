'use strict';
/**
 * Trang kế toán — ghi sổ kép.
 *
 * Điểm đáng nói của giao diện này: nó KIỂM CÂN ĐỐI NGAY TRONG LÚC GÕ.
 * Người nhập thấy tổng Nợ và tổng Có lệch nhau bao nhiêu trước khi bấm
 * lưu, thay vì bấm lưu rồi nhận một câu từ chối. Ràng buộc ở máy chủ
 * vẫn giữ nguyên — đây chỉ là nói sớm hơn, không phải thay thế.
 */
(function () {
  const CF = window.CF;
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];

  let taiKhoan = [];
  let dongBt = [];

  function doiMan(ten) {
    $$('.man').forEach((m) => m.classList.toggle('hien', m.id === 'man-' + ten));
    $$('.tab button').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.man === ten)));
    if (ten === 'so-cai') napSoCai();
    if (ten === 'can-doi') napCanDoi();
    if (ten === 'cong-no') napCongNo();
    if (ten === 'tai-khoan') veTaiKhoan();
  }

  async function napTaiKhoan() {
    const r = await CF.can('/api/ke-toan/tai-khoan', 'hệ thống tài khoản');
    if (!r) return;
    taiKhoan = r.taiKhoan;
    const chon = taiKhoan.map((t) => '<option value="' + CF.thoat(t.so) + '">'
      + CF.thoat(t.so + ' — ' + t.ten) + '</option>').join('');
    $('#tk-so-cai').innerHTML = '<option value="">— chọn tài khoản —</option>' + chon;
    window.__chonTk = chon;
    veTaiKhoan();
  }

  function veTaiKhoan() {
    if (!taiKhoan.length) return;
    const theoLoai = {};
    for (const t of taiKhoan) (theoLoai[t.loai] = theoLoai[t.loai] || []).push(t);
    const TEN = { 'tai-san': 'Tài sản', 'no-phai-tra': 'Nợ phải trả',
      'von-chu-so-huu': 'Vốn chủ sở hữu', 'doanh-thu': 'Doanh thu',
      'chi-phi': 'Chi phí', khac: 'Khác' };
    $('#ds-tai-khoan').innerHTML = Object.entries(theoLoai).map(([l, ds]) =>
      '<h3>' + CF.thoat(TEN[l] || l) + ' — ' + ds.length + ' tài khoản</h3>'
      + CF.bang(['Số hiệu', 'Tên', 'Dư thường', 'Thông tư'],
        ds.map((t) => ['<b>' + CF.thoat(t.so) + '</b>', CF.thoat(t.ten),
          CF.thoat(t.duThuong), CF.thoat(t.thongTu)]))).join('');
  }

  // ── Lập chứng từ ────────────────────────────────────────────────────

  function themDong(truoc) {
    dongBt.push(Object.assign({ tkNo: '', tkCo: '', soTien: '', dienGiai: '' }, truoc || {}));
    veDong();
  }

  function veDong() {
    const chon = window.__chonTk || '';
    $('#ds-dong').innerHTML = dongBt.map((d, i) => `
<div class="hang" data-dong="${i}" style="align-items:end;border-bottom:1px dashed var(--vien);padding-bottom:9px">
  <label>Nợ
    <select data-o="tkNo" data-i="${i}"><option value="">—</option>${chon}</select></label>
  <label>Có
    <select data-o="tkCo" data-i="${i}"><option value="">—</option>${chon}</select></label>
  <label>Số tiền (đồng)
    <input data-o="soTien" data-i="${i}" inputmode="numeric" value="${CF.thoat(d.soTien)}"></label>
  <label>Diễn giải dòng
    <input data-o="dienGiai" data-i="${i}" value="${CF.thoat(d.dienGiai)}"></label>
  <button class="phu2" data-xoa="${i}" type="button">Bỏ dòng</button>
</div>`).join('');
    for (const d of $$('#ds-dong select')) d.value = dongBt[Number(d.dataset.i)][d.dataset.o] || '';
    doCanDoi();
  }

  function doCanDoi() {
    let no = 0, co = 0, loi = null;
    for (const [i, d] of dongBt.entries()) {
      const t = String(d.soTien).replace(/[^\d-]/g, '');
      const n = Number(t);
      if (t === '') continue;
      if (!Number.isInteger(n) || n <= 0) {
        loi = 'Dòng ' + (i + 1) + ': số tiền phải là số nguyên đồng lớn hơn 0.';
        continue;
      }
      if (!d.tkNo && !d.tkCo) { loi = 'Dòng ' + (i + 1) + ': chưa chọn tài khoản nào.'; continue; }
      if (d.tkNo) no += n;
      if (d.tkCo) co += n;
    }
    const o = $('#can-doi');
    const can = no === co && no > 0 && !loi;
    o.className = 'can-doi ' + (can ? 'dat' : (no || co ? 'hong' : ''));
    o.textContent = loi
      ? loi
      : (no === 0 && co === 0
        ? 'Chưa có dòng nào có số tiền.'
        : 'Tổng Nợ ' + CF.tien(no) + '   ·   Tổng Có ' + CF.tien(co)
          + (can ? '   ·   cân đối' : '   ·   LỆCH ' + CF.tien(Math.abs(no - co))));
    $('#nut-luu').disabled = !can;
    return { no, co, can };
  }

  async function luuChungTu(e) {
    e.preventDefault();
    const { can } = doCanDoi();
    if (!can) return;
    const than = {
      loai: $('#ct-loai').value,
      ngayCt: $('#ct-ngay').value,
      dienGiai: $('#ct-dien-giai').value,
      doiTac: $('#ct-doi-tac').value || undefined,
      butToan: dongBt.filter((d) => String(d.soTien).trim() !== '').map((d) => ({
        tkNo: d.tkNo || undefined, tkCo: d.tkCo || undefined,
        soTien: Number(String(d.soTien).replace(/[^\d]/g, '')),
        dienGiai: d.dienGiai || undefined,
      })),
    };
    const ky = String(than.ngayCt).slice(0, 7);
    await CF.goi('/api/ke-toan/ky', { ky });      // mở kỳ nếu chưa có; đã có thì không sao
    const r = await CF.can('/api/ke-toan/chung-tu', 'lập chứng từ', than);
    if (!r) return;
    CF.bao('Đã lập chứng từ ' + r.soCt + ' · ' + CF.tien(r.tongTien)
      + '. Phải có người khác ghi sổ.', 'dat');
    dongBt = []; themDong(); themDong();
    $('#ct-dien-giai').value = '';
    napChoGhiSo();
  }

  async function napChoGhiSo() {
    const ky = $('#ky-can-doi').value || new Date().toISOString().slice(0, 7);
    const r = await CF.goi('/api/ke-toan/can-doi/' + encodeURIComponent(ky));
    if (r && r.dat) $('#tom-tat-ky').textContent =
      'Kỳ ' + ky + ' · ' + r.soTaiKhoan + ' tài khoản có phát sinh · '
      + (r.canDoi ? 'cân đối' : 'LỆCH ' + CF.tien(Math.abs(r.lech)));
  }

  // ── Sổ cái ──────────────────────────────────────────────────────────

  async function napSoCai() {
    const tk = $('#tk-so-cai').value;
    if (!tk) { $('#ds-so-cai').innerHTML = '<p class="rong">Chọn một tài khoản để xem sổ cái.</p>'; return; }
    const r = await CF.can('/api/ke-toan/so-cai/' + encodeURIComponent(tk), 'sổ cái');
    if (!r) return;
    $('#ds-so-cai').innerHTML =
      '<div class="o">'
      + '<div class="the-o"><div class="so">' + CF.tien(r.tongNo) + '</div><div class="nhan">Tổng Nợ</div></div>'
      + '<div class="the-o"><div class="so">' + CF.tien(r.tongCo) + '</div><div class="nhan">Tổng Có</div></div>'
      + '<div class="the-o"><div class="so">' + CF.tien(r.duCuoiKy) + '</div><div class="nhan">Dư cuối kỳ</div>'
      + '<div class="y">Dư thường bên ' + CF.thoat(r.taiKhoan.duThuong) + '</div></div>'
      + '</div>'
      + CF.bang(['Ngày', 'Số chứng từ', 'Diễn giải', 'Nợ', 'Có', 'Luỹ kế Nợ', 'Luỹ kế Có'],
        r.dong.map((d) => [CF.thoat(d.ngay), CF.thoat(d.soCt), CF.thoat(d.dienGiai),
          d.no ? CF.tien(d.no) : '', d.co ? CF.tien(d.co) : '',
          CF.tien(d.luyKeNo), CF.tien(d.luyKeCo)]),
        'Tài khoản này chưa có bút toán nào đã ghi sổ.');
  }

  // ── Cân đối phát sinh ───────────────────────────────────────────────

  async function napCanDoi() {
    const ky = $('#ky-can-doi').value || new Date().toISOString().slice(0, 7);
    const r = await CF.can('/api/ke-toan/can-doi/' + encodeURIComponent(ky), 'bảng cân đối');
    if (!r) return;
    $('#tom-can-doi').className = 'can-doi ' + (r.canDoi ? 'dat' : 'hong');
    $('#tom-can-doi').textContent =
      'Tổng phát sinh Nợ ' + CF.tien(r.tongPhatSinhNo)
      + '   ·   Tổng phát sinh Có ' + CF.tien(r.tongPhatSinhCo) + '   ·   ' + r.ghiChu;
    $('#ds-can-doi').innerHTML = CF.bang(
      ['Số hiệu', 'Tên tài khoản', 'Loại', 'Phát sinh Nợ', 'Phát sinh Có', 'Dư'],
      r.dong.map((d) => ['<b>' + CF.thoat(d.so) + '</b>', CF.thoat(d.ten), CF.thoat(d.loai),
        CF.tien(d.phatSinhNo), CF.tien(d.phatSinhCo), CF.tien(d.du)]),
      'Kỳ này chưa có chứng từ nào được ghi sổ.');
  }

  async function khoaKy() {
    const ky = $('#ky-can-doi').value;
    if (!ky) { CF.bao('Chọn kỳ trước đã.', 'nhac'); return; }
    const r = await CF.can('/api/ke-toan/ky/' + encodeURIComponent(ky) + '/khoa', 'khoá kỳ', {});
    if (!r) return;
    CF.bao('Đã khoá kỳ ' + ky + ' · tổng phát sinh ' + CF.tien(r.tongPhatSinh), 'dat');
    napCanDoi();
  }

  // ── Công nợ ─────────────────────────────────────────────────────────

  async function napCongNo() {
    const r = await CF.can('/api/ke-toan/cong-no', 'công nợ');
    if (!r) return;
    $('#tom-cong-no').textContent = 'Tổng còn phải thu: ' + CF.tien(r.tongConPhaiThu);
    $('#ds-cong-no').innerHTML = CF.bang(
      ['Học viên', 'Kỳ', 'Khoản mục', 'Phải thu', 'Đã thu', 'Còn lại', 'Hạn', 'Trạng thái'],
      r.khoan.map((k) => [CF.thoat(k.hocVien || '—'), CF.thoat(k.ky), CF.thoat(k.khoanMuc),
        CF.tien(k.soTien), CF.tien(k.daThu), '<b>' + CF.tien(k.conLai) + '</b>',
        CF.thoat(k.hanThu || '—'),
        '<span class="nhan-tt ' + (k.trangThai === 'da-thu' ? 'dat' : 'canh') + '">'
        + CF.thoat(k.trangThai) + '</span>']),
      'Không còn khoản học phí nào chờ thu.');
  }

  // ── Khởi động ───────────────────────────────────────────────────────

  function batDau() {
    $('#ct-ngay').value = new Date().toISOString().slice(0, 10);
    $('#ky-can-doi').value = new Date().toISOString().slice(0, 7);
    themDong(); themDong();

    $$('.tab button').forEach((b) => b.addEventListener('click', () => doiMan(b.dataset.man)));
    $('#form-ct').addEventListener('submit', luuChungTu);
    $('#nut-them-dong').addEventListener('click', () => themDong());
    $('#ds-dong').addEventListener('input', (e) => {
      const o = e.target.dataset.o;
      if (!o) return;
      dongBt[Number(e.target.dataset.i)][o] = e.target.value;
      doCanDoi();
    });
    $('#ds-dong').addEventListener('change', (e) => {
      const o = e.target.dataset.o;
      if (!o) return;
      dongBt[Number(e.target.dataset.i)][o] = e.target.value;
      doCanDoi();
    });
    $('#ds-dong').addEventListener('click', (e) => {
      const x = e.target.dataset.xoa;
      if (x === undefined) return;
      dongBt.splice(Number(x), 1);
      if (!dongBt.length) themDong();
      veDong();
    });
    $('#tk-so-cai').addEventListener('change', napSoCai);
    $('#ky-can-doi').addEventListener('change', () => { napCanDoi(); napChoGhiSo(); });
    $('#nut-khoa-ky').addEventListener('click', khoaKy);

    napTaiKhoan();
    napChoGhiSo();
    doiMan('lap');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', batDau);
  } else batDau();
})();
