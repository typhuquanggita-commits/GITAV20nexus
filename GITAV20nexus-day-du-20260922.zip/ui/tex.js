'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  HIỂN THỊ CÔNG THỨC TOÁN — bộ dựng LaTeX gọn, không phụ thuộc thư viện ngoài
 * ═══════════════════════════════════════════════════════════════════════════
 *  Vì sao tự viết thay vì nhúng KaTeX/MathJax:
 *   · Bản cài đặt trên máy phải chạy được khi KHÔNG có mạng.
 *   · Không nhúng mã từ CDN bên ngoài vào màn hình quản trị.
 *   · Chỉ cần đúng tập ký hiệu mà GITAV20nexus cho phép (điều A02), không cần cả
 *     TeX — nên bộ dựng nhỏ, đọc được, và kiểm thử được.
 *
 *  Phủ: \dfrac \frac \sqrt (có cả bậc n) ^{} _{} \cdot \times \div \pm
 *       \le \ge \ne \approx \in \Delta \alpha… \mathbb{} \text{} \left \right
 *       \begin{cases}…\end{cases}, \Leftrightarrow \Rightarrow \to \infty
 *
 *  Đầu vào là dữ liệu, không phải mã: mọi ký tự đều được thoát trước khi ghép
 *  vào HTML, nên đề bài do mô hình sinh ra không thể chèn thẻ vào trang.
 * ═══════════════════════════════════════════════════════════════════════════
 */

(function (global) {
  const SYMBOLS = {
    cdot: '·', times: '×', div: '÷', pm: '±', mp: '∓',
    le: '≤', leq: '≤', ge: '≥', geq: '≥', ne: '≠', neq: '≠',
    approx: '≈', equiv: '≡', sim: '∼', propto: '∝',
    in: '∈', notin: '∉', subset: '⊂', subseteq: '⊆', cup: '∪', cap: '∩', emptyset: '∅',
    infty: '∞', partial: '∂', nabla: '∇', angle: '∠', perp: '⊥', parallel: '∥',
    to: '→', rightarrow: '→', Rightarrow: '⇒', Leftrightarrow: '⇔', leftarrow: '←', mapsto: '↦',
    forall: '∀', exists: '∃', neg: '¬', land: '∧', lor: '∨',
    alpha: 'α', beta: 'β', gamma: 'γ', delta: 'δ', epsilon: 'ε', varepsilon: 'ε',
    zeta: 'ζ', eta: 'η', theta: 'θ', lambda: 'λ', mu: 'μ', nu: 'ν', xi: 'ξ',
    pi: 'π', rho: 'ρ', sigma: 'σ', tau: 'τ', phi: 'φ', varphi: 'φ', chi: 'χ', psi: 'ψ', omega: 'ω',
    Gamma: 'Γ', Delta: 'Δ', Theta: 'Θ', Lambda: 'Λ', Xi: 'Ξ', Pi: 'Π',
    Sigma: 'Σ', Phi: 'Φ', Psi: 'Ψ', Omega: 'Ω',
    sum: '∑', prod: '∏', int: '∫', lim: 'lim', ldots: '…', cdots: '⋯', dots: '…',
    quad: ' ', qquad: '  ', ',': ' ', ';': ' ', '!': '',
    ast: '∗', star: '⋆', circ: '∘', deg: '°', percent: '%',
    triangle: '△', square: '□', diamond: '◇', bigcirc: '◯',
    cong: '≅', simeq: '≃', nparallel: '∦', measuredangle: '∡',
  };

  // Lệnh chỉ điều khiển CÁCH BÀY, không sinh ra ký hiệu nào. Bộ dựng này tự
  // chọn cỡ chữ theo ngữ cảnh nên bỏ qua chúng là đúng, không phải là thiếu.
  const BO_QUA = new Set(['displaystyle', 'textstyle', 'scriptstyle', 'scriptscriptstyle',
    'limits', 'nolimits', 'left', 'right', 'mathrm', 'mathit', 'bm']);

  // Dấu đặt TRÊN ĐẦU ký hiệu: góc, vectơ, đoạn thẳng, giá trị trung bình.
  // Chương trình hình học và thống kê phổ thông dùng liên tục nhóm này, nên
  // thiếu chúng là đề bài hiện ra sai chứ không phải chỉ xấu.
  const ACCENTS = {
    widehat: '⌒', hat: '^', overline: '‾', bar: '‾',
    vec: '→', overrightarrow: '→', widetilde: '~', tilde: '~',
  };

  const BLACKBOARD = { R: 'ℝ', N: 'ℕ', Z: 'ℤ', Q: 'ℚ', C: 'ℂ', P: 'ℙ' };
  const FUNC_NAMES = new Set(['sin', 'cos', 'tan', 'cot', 'sec', 'csc', 'log', 'ln', 'lg',
    'exp', 'lim', 'max', 'min', 'gcd', 'deg', 'det', 'dim', 'arcsin', 'arccos', 'arctan']);

  const esc = (s) => String(s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

  /** Đọc phần nằm trong { } bắt đầu tại i; không có ngoặc thì lấy một ký tự. */
  function group(src, i) {
    while (src[i] === ' ') i++;
    if (src[i] !== '{') {
      if (src[i] === '\\') {
        const m = src.slice(i).match(/^\\[a-zA-Z]+/);
        if (m) return { body: m[0], next: i + m[0].length };
      }
      return { body: src[i] ?? '', next: i + 1 };
    }
    let depth = 0;
    for (let j = i; j < src.length; j++) {
      if (src[j] === '{' && src[j - 1] !== '\\') depth++;
      else if (src[j] === '}' && src[j - 1] !== '\\') {
        depth--;
        if (depth === 0) return { body: src.slice(i + 1, j), next: j + 1 };
      }
    }
    return { body: src.slice(i + 1), next: src.length };
  }

  /** Dựng một đoạn LaTeX thành HTML. */
  function render(src) {
    const s = String(src ?? '');
    let out = '';
    let i = 0;

    while (i < s.length) {
      const c = s[i];

      // ── Lệnh ──
      if (c === '\\') {
        const m = s.slice(i).match(/^\\([a-zA-Z]+|.)/);
        if (!m) { i++; continue; }
        const cmd = m[1];
        let j = i + m[0].length;

        if (cmd === 'dfrac' || cmd === 'frac' || cmd === 'tfrac') {
          const a = group(s, j);
          const b = group(s, a.next);
          out += `<span class="tex-frac"><span class="tex-num">${render(a.body)}</span>`
            + `<span class="tex-den">${render(b.body)}</span></span>`;
          i = b.next;
          continue;
        }
        if (cmd === 'sqrt') {
          let idx = null;
          let k = j;
          while (s[k] === ' ') k++;
          if (s[k] === '[') {
            const close = s.indexOf(']', k);
            idx = s.slice(k + 1, close);
            k = close + 1;
          }
          const a = group(s, k);
          out += `<span class="tex-root">${idx ? `<span class="tex-rootidx">${render(idx)}</span>` : ''}`
            + `<span class="tex-radical">√</span><span class="tex-radicand">${render(a.body)}</span></span>`;
          i = a.next;
          continue;
        }
        if (cmd === 'mathbb') {
          const a = group(s, j);
          out += `<span class="tex-bb">${BLACKBOARD[a.body.trim()] || esc(a.body)}</span>`;
          i = a.next;
          continue;
        }
        if (cmd === 'text' || cmd === 'textrm' || cmd === 'mathrm' || cmd === 'operatorname') {
          const a = group(s, j);
          out += `<span class="tex-text">${esc(a.body)}</span>`;
          i = a.next;
          continue;
        }
        if (cmd === 'left' || cmd === 'right') {
          let k = j;
          while (s[k] === ' ') k++;
          let d = s[k];
          if (d === '\\') { const mm = s.slice(k).match(/^\\[a-zA-Z]+/); d = mm ? SYMBOLS[mm[0].slice(1)] || '' : ''; k += mm ? mm[0].length : 1; }
          else k++;
          if (d === '.') d = '';
          if (d === '|') d = '|';
          out += d ? `<span class="tex-delim">${esc(d)}</span>` : '';
          i = k;
          continue;
        }
        if (cmd === 'begin' || cmd === 'end') {
          const a = group(s, j);
          const env = a.body.trim();
          if (cmd === 'begin' && (env === 'cases' || env === 'array' || env === 'matrix')) {
            const endTag = `\\end{${env}}`;
            const endAt = s.indexOf(endTag, a.next);
            const body = s.slice(a.next, endAt === -1 ? s.length : endAt);
            const rows = body.split('\\\\').map((r) => r.trim()).filter(Boolean);
            const inner = rows.map((r) => `<span class="tex-row">${r.split('&').map((cell) => `<span class="tex-cell">${render(cell)}</span>`).join('')}</span>`).join('');
            out += env === 'cases'
              ? `<span class="tex-cases"><span class="tex-brace">{</span><span class="tex-rows">${inner}</span></span>`
              : `<span class="tex-rows">${inner}</span>`;
            i = endAt === -1 ? s.length : endAt + endTag.length;
            continue;
          }
          i = a.next;
          continue;
        }
        if (BO_QUA.has(cmd) && cmd !== 'left' && cmd !== 'right') { i = j; continue; }
        if (cmd in ACCENTS) {
          const a = group(s, j);
          out += `<span class="tex-acc"><span class="tex-acc-mark">${esc(ACCENTS[cmd])}</span>`
            + `<span class="tex-acc-body">${render(a.body)}</span></span>`;
          i = a.next;
          continue;
        }
        if (FUNC_NAMES.has(cmd)) { out += `<span class="tex-fn">${cmd}</span>`; i = j; continue; }
        if (cmd in SYMBOLS) { out += `<span class="tex-op">${esc(SYMBOLS[cmd])}</span>`; i = j; continue; }
        if (cmd === '\\') { out += '<br>'; i = j; continue; }
        // "\ " là lệnh KHOẢNG TRẮNG của LaTeX, hay dùng sau dấu phẩy trong
        // mệnh đề toán: "∀x ∈ ℝ,\ x² > 0".
        if (cmd === ' ') { out += ' '; i = j; continue; }
        if ('{}%$&_#'.includes(cmd)) { out += esc(cmd); i = j; continue; }
        // Lệnh chưa hỗ trợ: hiện nguyên văn để người soạn thấy mà sửa, không nuốt mất.
        out += `<span class="tex-unknown" title="chưa hỗ trợ">\\${esc(cmd)}</span>`;
        i = j;
        continue;
      }

      // ── Chỉ số trên / dưới ──
      if (c === '^' || c === '_') {
        const a = group(s, i + 1);
        out += `<${c === '^' ? 'sup' : 'sub'} class="tex-script">${render(a.body)}</${c === '^' ? 'sup' : 'sub'}>`;
        i = a.next;
        continue;
      }

      if (c === '{' || c === '}') { i++; continue; }

      // ── Chữ cái đứng một mình là biến → in nghiêng ──
      if (/[a-zA-Z]/.test(c)) {
        let j = i;
        while (j < s.length && /[a-zA-Z]/.test(s[j])) j++;
        const word = s.slice(i, j);
        out += word.length === 1
          ? `<span class="tex-var">${esc(word)}</span>`
          : (FUNC_NAMES.has(word) ? `<span class="tex-fn">${esc(word)}</span>` : `<span class="tex-var">${esc(word)}</span>`);
        i = j;
        continue;
      }

      if (c === ' ') { out += ' '; i++; continue; }
      // Dấu trừ trong toán là U+2212, KHÔNG phải dấu nối U+002D. Hai ký tự này
      // khác nhau cả bề rộng lẫn độ cao so với dấu cộng, nên "x - 3" gõ bằng
      // dấu nối nhìn lệch hẳn khi đặt cạnh "x + 3". Đây là chỗ phân biệt một
      // trang toán trình bày đúng với một trang chỉ gõ cho có.
      if (c === '-') { out += '<span class="tex-op">−</span>'; i++; continue; }
      if (c === '+' || c === '=' || c === '<' || c === '>') {
        out += `<span class="tex-op">${esc(c)}</span>`; i++; continue;
      }
      out += esc(c);
      i++;
    }
    return out;
  }

  /**
   * Dựng một đoạn văn bản có lẫn công thức trong $…$ hoặc $$…$$.
   * Phần ngoài công thức được thoát HTML nguyên vẹn.
   */
  function renderText(text) {
    const s = String(text ?? '');
    // Chuỗi KHÔNG có cặp $…$ nhưng CÓ lệnh LaTeX thì cả chuỗi là công thức.
    // Trường "đáp án" của học liệu được lưu ở dạng đó vì nó còn phải đi vào bộ
    // kiểm chứng, nơi dấu $ chỉ làm vướng. Không có luật này thì giáo viên mở
    // bài ra nhìn thấy nguyên chuỗi "\dfrac{5}{6}" thay vì một phân số.
    if (!s.includes('$') && /\\[a-zA-Z]/.test(s)) {
      return `<span class="tex tex-inline">${render(s)}</span>`;
    }
    let out = '';
    let i = 0;
    while (i < s.length) {
      const dollar = s.indexOf('$', i);
      if (dollar === -1) { out += esc(s.slice(i)); break; }
      out += esc(s.slice(i, dollar));
      const display = s[dollar + 1] === '$';
      const open = dollar + (display ? 2 : 1);
      const closeTok = display ? '$$' : '$';
      let close = s.indexOf(closeTok, open);
      if (close === -1) { out += esc(s.slice(dollar)); break; }
      const body = s.slice(open, close);
      out += `<span class="tex ${display ? 'tex-display' : 'tex-inline'}">${render(body)}</span>`;
      i = close + closeTok.length;
    }
    return out;
  }

  const TeX = { render, renderText, esc, SYMBOLS, ACCENTS };
  if (typeof module !== 'undefined' && module.exports) module.exports = TeX;
  if (global) global.TeX = TeX;
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : null));
