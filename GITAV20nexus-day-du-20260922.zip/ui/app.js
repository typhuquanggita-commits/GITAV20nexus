/* GITAV20nexus — Trung tâm chỉ huy Super Admin (không phụ thuộc thư viện ngoài) */
'use strict';

const App = (() => {
  const S = { token: null, sessionKey: null, user: null, tab: 'overview', cache: {} };
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const n = (x, d = 0) => (x == null ? '—' : Number(x).toLocaleString('vi-VN', { maximumFractionDigits: d }));
  const pct = (x) => (x == null ? '—' : (Number(x) * 100).toFixed(1) + '%');

  async function api(path, body) {
    const opt = body
      ? { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }
      : {};
    const r = await fetch(path, opt);
    const ct = r.headers.get('content-type') || '';
    return ct.includes('json') ? r.json() : r.text();
  }

  function toast(msg, kind = '') {
    const el = document.createElement('div');
    el.className = kind;
    el.textContent = msg;
    $('toast').appendChild(el);
    setTimeout(() => el.remove(), 5000);
  }

  function table(cols, rows) {
    if (!rows || !rows.length) return '<div class="muted">Chưa có dữ liệu.</div>';
    const head = cols.map((c) => `<th class="${c.num ? 'num' : ''}">${esc(c.label)}</th>`).join('');
    const body = rows.map((r) => '<tr>' + cols.map((c) => {
      const v = typeof c.get === 'function' ? c.get(r) : r[c.key];
      return `<td class="${c.num ? 'num' : ''}">${c.raw ? (v ?? '') : esc(v)}</td>`;
    }).join('') + '</tr>').join('');
    return `<table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`;
  }

  const bar = (v, kind = '') => `<span class="bar ${kind}" style="display:inline-block;width:70px"><i style="width:${Math.max(0, Math.min(100, v * 100))}%"></i></span>`;
  const card = (k, v, s, kind = '') => `<div class="card ${kind}"><div class="k">${esc(k)}</div><div class="v">${v}</div><div class="s">${esc(s || '')}</div></div>`;

  // ── ĐĂNG NHẬP ─────────────────────────────────────────────────────────
  async function boot() {
    const st = await api('/superadmin/status');
    if (st.initialized) {
      $('loginState').textContent = `Tài khoản gốc: ${st.username} · ${st.layers} tầng bảo vệ · ${st.recoveryCodesLeft} mã khôi phục còn lại`;
      $('loginBox').classList.remove('hidden');
      $('initBox').classList.add('hidden');
    } else {
      $('loginState').textContent = 'Lần chạy đầu tiên.';
      $('initBox').classList.remove('hidden');
      $('loginBox').classList.add('hidden');
    }
    // Trang này mở được KHI CHƯA ĐĂNG NHẬP — đó là chỗ người dùng đăng nhập.
    // Nên lượt gọi này trả 401 là chuyện bình thường, không phải sự cố. Bản
    // đầu dùng thẳng layers.layers.map(...) nên 401 làm `.map` ném lỗi, và lỗi
    // ấy giết luôn phần còn lại của hàm: trang mở lên trông như bình thường
    // nhưng một nửa nội dung không bao giờ dựng, mà người dùng không thấy một
    // lời nào. Bắt được khi lái thử bằng trình duyệt thật.
    const layers = await api('/superadmin/layers');
    $('layerStrip').innerHTML = (layers && Array.isArray(layers.layers))
      ? layers.layers.map((l) => `<span title="${esc(l.name)}">${l.id}</span>`).join('')
      : '<span class="muted">Đăng nhập để xem các tầng bảo vệ.</span>';
  }

  async function initialize() {
    $('loginErr').textContent = '';
    const r = await api('/superadmin/initialize', {
      username: $('iUser').value.trim(), email: $('iEmail').value.trim(), password: $('iPass').value,
    });
    if (!r.ok) {
      $('loginErr').textContent = r.error === 'WEAK_PASSWORD'
        ? 'Mật khẩu chưa đạt: ' + (r.issues || []).join(' · ') : r.error;
      return;
    }
    $('secrets').textContent = [
      `TOTP secret : ${r.totpSecret}`,
      `otpauth URL : ${r.otpauthURL}`,
      ``,
      `Mã khôi phục (dùng 1 lần):`,
      ...r.recoveryCodes.map((c, i) => `  ${i + 1}. ${c}`),
      ``,
      `Chìa khoá phá kính: ${r.breakGlassKey}`,
      ``,
      `Mảnh giám hộ (${r.guardianPolicy}) — giao cho ${r.guardianShares.length} người khác nhau:`,
      ...r.guardianShares.map((s, i) => `  #${i + 1} ${s}`),
    ].join('\n');
    $('initBox').classList.add('hidden');
    $('secretsBox').classList.remove('hidden');
  }

  function doneSecrets() {
    $('secretsBox').classList.add('hidden');
    $('loginBox').classList.remove('hidden');
    boot();
  }

  async function login() {
    $('loginErr').textContent = '';
    const r = await api('/superadmin/login', {
      username: $('lUser').value.trim(), password: $('lPass').value,
      totpToken: $('lTotp').value.trim() || undefined,
      recoveryCode: $('lRecovery').value.trim() || undefined,
      deviceId: deviceId(),
    });
    if (!r.ok) {
      $('loginErr').textContent = `${r.error}${r.layer ? ' (chặn ở tầng ' + r.layer + ')' : ''}${r.hint ? ' — ' + r.hint : ''}`;
      return;
    }
    S.token = r.token; S.sessionKey = r.sessionKey; S.user = $('lUser').value.trim();
    $('layerStrip').innerHTML = (r.layersPassed || []).map((l) => `<span class="pass">${l}</span>`).join('');
    if (r.anomalies?.length) toast('Cảnh báo bất thường: ' + r.anomalies.join(', '), 'err');
    $('login').classList.remove('active');
    $('console').classList.add('active');
    $('sideUser').textContent = `${S.user} · ${r.mfaMethod}`;
    await refresh();
  }

  function deviceId() {
    let d = localStorage.getItem('gita_device');
    if (!d) { d = 'dev-' + Math.random().toString(36).slice(2, 12); localStorage.setItem('gita_device', d); }
    return d;
  }

  async function logout() {
    if (S.token) await api('/superadmin/logout', { token: S.token });
    S.token = null;
    $('console').classList.remove('active');
    $('login').classList.add('active');
    boot();
  }

  // ── ĐIỀU HƯỚNG ────────────────────────────────────────────────────────
  function setTab(tab) {
    S.tab = tab;
    document.querySelectorAll('#nav a').forEach((a) => a.classList.toggle('on', a.dataset.tab === tab));
    document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('hidden', t.id !== 'tab-' + tab));
    $('tabTitle').textContent = document.querySelector(`#nav a[data-tab="${tab}"]`).textContent;
    refresh();
  }

  async function refresh() {
    const fn = { overview, agents: loadAgents, mission: loadMission, curriculum: loadCurriculum, learner: () => {}, security: loadSecurity, recovery: loadRecovery, governance: loadGovernance, content: loadContent, live: loadLive, voice: loadVoice, film: loadFilm, photo: loadPhoto }[S.tab];
    try { await fn(); } catch (e) { toast('Lỗi tải dữ liệu: ' + e.message, 'err'); }
    // MỌI LƯỢT GỌI API Ở TỆP NÀY ĐỀU ĐÒI QUYỀN QUẢN TRỊ, nên lượt nào cũng có
    // thể trả 401 hoặc 403. Dùng thẳng dữ liệu mà không hỏi trước thì dòng
    // đầu tiên đọc thuộc tính của undefined sẽ ném lỗi, và lỗi ấy giết luôn
    // phần còn lại của hàm: trang trông như bình thường mà thiếu nội dung, và
    // người dùng không thấy một lời nào. G.can() dừng đúng chỗ và nói rõ lý do.
    const fleet = await api('/resilience/fleet');
    if (!G.can(fleet, 'Sức khoẻ đội hình')) return;
    $('fleetPill').textContent = `Đội hình ${pct(fleet.readiness)}`;
    $('fleetPill').className = 'pill ' + (fleet.readiness > 0.95 ? 'ok' : fleet.readiness > 0.8 ? 'warn' : 'err');
  }

  // ── XƯỞNG ẢNH ─────────────────────────────────────────────────────────
  async function loadPhoto() {
    const st = await api('/photo/status');
    if (!st.ok) { $('phCards').innerHTML = '<div class="muted">Chưa bật được xưởng ảnh.</div>'; return; }

    $('phCards').innerHTML = [
      card('Hồ sơ máy ảnh', vn(st.mayAnh.length), `${st.phim.length} giả lập phim · ${st.kieuAnh.length} kiểu ảnh`),
      card('Hậu kỳ', 'LUÔN CHẠY ĐƯỢC', `đọc ${st.dinhDangDocDuoc.join(' + ')} · không cần ffmpeg`, 'ok'),
      card('Cổng sinh ảnh', st.cong.duongDi.chon || 'chưa có', esc(st.cong.duongDi.cheDoTen), st.cong.duongDi.chon ? 'ok' : 'warn'),
      card('Đã xử lý', vn(st.stats.hauKy), `điểm trung bình ${st.stats.diemTrungBinh}/100 · ${vn(st.stats.msTrungBinh)}ms mỗi ảnh`),
      card('Trần bảo vệ', `${st.gioiHan.tranMegapixel}MP`, `tệp vào tối đa ${Math.round(st.gioiHan.tranByteVao / 1048576)}MB`),
    ].join('');

    $('phMay').innerHTML = st.mayAnh.map((m) => `<option value="${m.id}"${m.id === 'Fujifilm' ? ' selected' : ''}>${esc(m.ten)}</option>`).join('');
    $('phPhim').innerHTML = st.phim.map((f) => `<option value="${f.id}">${esc(f.ten)}</option>`).join('');
    $('phKieu').innerHTML = st.kieuAnh.map((k) => `<option value="${k.id}">${esc(k.ten)}</option>`).join('');

    $('phCameras').innerHTML = table(st.mayAnh, [
      { label: 'Hồ sơ', get: (r) => r.ten },
      { label: 'Chất màu', get: (r) => r.note },
      { label: 'Tương phản', get: (r) => r.mau.tuongPhan ?? '—' },
      { label: 'Bão hoà', get: (r) => r.mau.baoHoa ?? '—' },
      { label: 'Nhiệt độ', get: (r) => (r.mau.kelvin ? `${r.mau.kelvin}K` : '—') },
    ]);

    $('phProviders').innerHTML = table(st.cong.cong, [
      { label: 'Cổng', get: (r) => r.ten },
      { label: 'Cần mạng', get: (r) => (r.canMang ? 'có' : 'không') },
      { label: 'Trạng thái', html: true, get: (r) => (r.sanSang ? '<b class="ok">sẵn sàng</b>' : `<span class="muted">${esc(r.ly || '')}</span>`) },
      { label: 'Cách bật', get: (r) => r.sua || '—' },
      { label: 'Lưu ý', get: (r) => r.note || '' },
    ]) + `<p class="hint">Khung dựng bố cục luôn vẽ được, không cần cổng nào. Toàn bộ 8 tầng hậu kỳ cũng chạy ngay trong tiến trình.</p>`;
  }

  async function photoPrepare() {
    const r = await api('/photo/prepare', {
      moTa: $('phMoTa').value, kieuAnh: $('phKieu').value,
      mayAnh: $('phMay').value, phim: $('phPhim').value, chatLuong: $('phChat').value,
    });
    if (!r.ok) return toast(r.error || 'Không dựng được', 'err');
    $('phPrompt').innerHTML = `<b>${esc(r.boCucTen)}</b> · ${esc(r.ongKinhTen)} · ${esc(r.anhSangTen)} · `
      + `${esc(r.mayAnhTen)}${r.phim !== 'Khong' ? ' + ' + esc(r.phimTen) : ''} · đích ${r.muc.canh}px<br>`
      + `<span class="muted">Hệ thống tự thêm: ${r.daThem.map((d) => `${esc(d.phan)}=${esc(d.gia)}`).join(' · ')}</span><br>`
      + `<code style="display:block;margin-top:8px;white-space:pre-wrap;font-size:12px">${esc(r.prompt)}</code>`;
    const fr = await fetch('/photo/framing', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ moTa: $('phMoTa').value, kieuAnh: $('phKieu').value, mayAnh: $('phMay').value, phim: $('phPhim').value }),
    });
    $('phFraming').innerHTML = `<div style="margin-top:12px">${await fr.text()}</div>`;
    S.photoPrompt = r;
  }

  function _phFile() {
    const f = $('phFile').files?.[0];
    if (!f) { toast('Chọn một tệp ảnh PNG hoặc JPEG đã.', 'err'); return null; }
    return new Promise((res) => {
      const fr = new FileReader();
      fr.onload = () => res(String(fr.result).split(',')[1]);
      fr.readAsDataURL(f);
    });
  }

  async function photoEnhance() {
    const b64 = await _phFile();
    if (!b64) return;
    toast('Đang chạy 8 tầng hậu kỳ…', '');
    const r = await api('/photo/enhance', {
      anhBase64: b64, mayAnh: $('phMay').value, phim: $('phPhim').value, chatLuong: $('phChat').value, traPng: false,
    });
    if (!r.ok) return toast(`${r.error}${r.goi ? ' — ' + r.goi : ''}`, 'err');
    $('phReport').innerHTML = `<p><b>${r.rong}×${r.cao}</b> (${r.megapixel}MP) · ${vn(r.ms)}ms · `
      + `điểm <b class="${r.cham.diem >= 72 ? 'ok' : 'warn'}">${r.cham.diem}/100 ${esc(r.cham.xep)}</b> · `
      + `JPEG ${Math.round(r.byteJpeg / 1024)}KB</p>`
      + table(r.buoc, [{ label: 'Tầng', get: (x) => x.buoc }, { label: 'Đã làm gì', get: (x) => x.chiTiet }, { label: 'Kích thước', get: (x) => `${x.rong}×${x.cao}` }])
      + '<h4 style="margin:14px 0 6px;font-size:14px">Đo trước và sau</h4>'
      + table(r.soSanh.bang, [
        { label: 'Trục', get: (x) => x.truc }, { label: 'Trước', get: (x) => x.truoc }, { label: 'Sau', get: (x) => x.sau },
        { label: 'Điểm', get: (x) => `${x.diemTruoc} → ${x.diemSau}` },
      ])
      + (r.cham.loi.length ? `<h4 style="margin:14px 0 6px;font-size:14px">Còn nên chỉnh</h4>`
        + table(r.cham.loi, [{ label: 'Mức', get: (x) => x.muc }, { label: 'Trục', get: (x) => x.ten }, { label: 'Cách sửa', get: (x) => x.sua }]) : '')
      + `<img src="data:image/jpeg;base64,${r.jpegBase64}" alt="ảnh sau hậu kỳ" style="width:100%;margin-top:14px;border-radius:10px">`
      + `<p><a class="pill" href="data:image/jpeg;base64,${r.jpegBase64}" download="anh-hau-ky.jpg">Tải ảnh JPEG</a></p>`;
    toast(`Xong: ${r.cham.diem}/100.`, 'ok');
  }

  async function photoMeasure() {
    const b64 = await _phFile();
    if (!b64) return;
    const r = await api('/photo/measure', { anhBase64: b64, mayAnh: $('phMay').value, phim: $('phPhim').value });
    if (!r.ok) return toast(r.error || 'Không đo được', 'err');
    $('phReport').innerHTML = `<p>${esc(r.dang.toUpperCase())} ${r.doDuoc.rong}×${r.doDuoc.cao} · `
      + `<b class="${r.dat ? 'ok' : 'warn'}">${r.diem}/100 ${esc(r.xep)}</b> — ${esc(r.ketLuan)}</p>`
      + table(r.chiTiet, [
        { label: '', html: true, get: (x) => (x.dat ? '<b class="ok">✓</b>' : '<b class="warn">✗</b>') },
        { label: 'Trục', get: (x) => x.ten }, { label: 'Đo được', get: (x) => x.giaTri },
        { label: 'Chuẩn', get: (x) => x.chuan }, { label: 'Điểm', get: (x) => `${x.diem}/${x.toiDa}` },
      ]);
  }

  // ── LÀM PHIM ──────────────────────────────────────────────────────────
  async function loadFilm() {
    const [st, ds] = await Promise.all([api('/film/status'), api('/film/projects?limit=20')]);
    if (!st.ok) { $('fCards').innerHTML = '<div class="muted">Chưa bật được xưởng phim.</div>'; return; }

    $('fCards').innerHTML = [
      card('Dự án phim', vn(st.duAn), Object.entries(st.theoTrangThai).map(([k, v]) => `${k}: ${v}`).join(' · ') || 'chưa có'),
      card('Mô hình dựng video', vn(st.moHinh.length), `rẻ nhất $${Math.min(...st.moHinh.map((m) => m.giaMoi5Giay))}/5s`),
      card('Cổng dựng thật', st.cong.that.sanSang ? 'SẴN SÀNG' : 'CHƯA CÓ KHOÁ',
        st.cong.that.sanSang ? `đã tiêu $${st.cong.that.stats.usd}` : esc(st.cong.that.sua || ''), st.cong.that.sanSang ? 'ok' : 'warn'),
      card('Trần chi tiêu', `$${st.gioiHan.tranChiTieuUsd}`, st.cong.batBuocXacNhan ? 'bắt buộc xác nhận tay' : 'không cần xác nhận'),
      card('Bản nháp', 'LUÔN DỰNG ĐƯỢC', 'bảng phân cảnh + đường tiếng + phim nháp · $0', 'ok'),
    ].join('');

    if (ds.ok) {
      $('fProjects').innerHTML = table(ds.items, [
        { label: 'Mã', get: (r) => r.duAn },
        { label: 'Tiêu đề', get: (r) => r.tieuDe },
        { label: 'Trạng thái', get: (r) => r.trangThai },
        { label: 'Cảnh quay', get: (r) => r.canhQuay },
        { label: 'Dài', get: (r) => `${r.giay}s` },
        { label: 'Dự toán', get: (r) => `$${r.duToan.usd}` },
        { label: 'Soát', get: (r) => `${r.qc.diem}/100 ${r.qc.xep}` },
        { label: '', html: true, get: (r) => `<button class="ghost" onclick="App.filmLoad('${r.duAn}')">Mở</button>` },
      ], 'Chưa có dự án nào.');
    }
  }

  async function filmSample() {
    const r = await fetch('/film/sample-script');
    $('fKichBan').value = await r.text();
    toast('Đã nạp kịch bản mẫu.', 'ok');
  }

  function renderFilm(p) {
    S.film = p.duAn;
    $('fReport').innerHTML = `<b>${esc(p.tieuDe)}</b> · ${esc(p.theLoai)} · ${p.canh} cảnh → ${p.canhQuay} cảnh quay · `
      + `${p.giay}s (${p.phut} phút) · dự toán <b>$${p.duToan.usd}</b> · mã dự án <code>${esc(p.duAn)}</code><br>`
      + 'So sánh giá: ' + p.soSanhGia.map((x) => `${esc(x.ten)} <b>$${x.usd}</b>`).join(' · ');

    $('fChars').innerHTML = table(p.nhanVat, [
      { label: 'Nhân vật', get: (r) => r.ten },
      { label: 'Giới', get: (r) => r.gioiTinh },
      { label: 'Tuổi', get: (r) => r.tuoi ?? '—' },
      { label: 'Nét ngoại hình', get: (r) => (r.netNgoaiHinh || []).join(', ') || '(kịch bản chưa tả)' },
      { label: 'Khoá', get: (r) => r.maKhoa },
    ]);

    const q = p.qc;
    $('fQc').innerHTML = `<p><b class="${q.ok ? 'ok' : 'err'}">${q.diem}/100 — ${esc(q.xep)}</b> · `
      + `chặn ${q.chan} · nặng ${q.nang} · nhẹ ${q.nhe}</p><p class="hint">${esc(q.ketLuan)}</p>`
      + table(q.loi, [
        { label: 'Mức', get: (r) => r.muc },
        { label: 'Lỗi', get: (r) => r.loai },
        { label: 'Ở', get: (r) => r.o },
        { label: 'Vì sao', get: (r) => r.note },
        { label: 'Cách sửa', get: (r) => r.cachSua },
      ], 'Không có lỗi nào.');
  }

  async function filmPrepare() {
    const kichBan = $('fKichBan').value.trim();
    if (!kichBan) return toast('Dán kịch bản vào đã.', 'err');
    const r = await api('/film/prepare', {
      kichBan, uuTien: $('fUuTien').value, nganSachUsd: +$('fNganSach').value || null,
    });
    if (!r.ok) { $('fReport').innerHTML = `<span class="err">${esc(r.error)}${r.goi ? ' — ' + esc(r.goi) : ''}</span>`; return; }
    renderFilm(r);
    const shots = await api(`/film/projects/${r.duAn}/shots`);
    if (shots.ok) {
      $('fShots').innerHTML = table(shots.canhQuay, [
        { label: 'Mã', get: (x) => x.id },
        { label: 'Cỡ cảnh', get: (x) => x.coTen },
        { label: 'Máy', get: (x) => x.chuyenDongTen },
        { label: 'Dài', get: (x) => `${x.giay}s` },
        { label: 'Bối cảnh', get: (x) => x.boiCanh },
        { label: 'Mô hình', get: (x) => x.modelTen || '—' },
        { label: '$', get: (x) => x.giaDuTinh },
        { label: 'Nội dung', get: (x) => (x.thoai ? `“${x.thoai.loi}”` : x.moTaViet) },
        { label: 'Khung', html: true, get: (x) => `<a class="pill" href="/film/projects/${r.duAn}/storyboard/${x.id}" target="_blank">xem</a>` },
      ]);
    }
    toast(`Đã chuẩn bị ${r.canhQuay} cảnh quay. Chưa tốn đồng nào.`, 'ok');
  }

  async function filmLoad(id) {
    const r = await api(`/film/projects/${id}`);
    if (!r.ok) return toast(r.error, 'err');
    renderFilm(r);
    $('fShots').innerHTML = table(r.canhQuay || [], [
      { label: 'Mã', get: (x) => x.id },
      { label: 'Cỡ cảnh', get: (x) => x.coTen },
      { label: 'Dài', get: (x) => `${x.giay}s` },
      { label: 'Mô hình', get: (x) => x.modelTen || '—' },
      { label: 'Nội dung', get: (x) => (x.thoai ? `“${x.thoai.loi}”` : x.moTaViet) },
    ]);
    setTab('film');
  }

  async function filmDraft() {
    if (!S.film) return toast('Chuẩn bị một dự án trước đã.', 'err');
    toast('Đang dựng bản nháp (đọc toàn bộ lời thoại)…', '');
    const r = await api(`/film/projects/${S.film}/draft`, {});
    if (!r.ok) return toast(r.error || 'Không dựng được', 'err');
    $('fDraft').innerHTML = `<p>${r.khung} khung phân cảnh · đường tiếng <b>${r.tiengGiay}s</b> `
      + `(${r.cauThoai} câu thoại, độ vang ${r.doVang} LUFS) <span class="ai-tag">Giọng AI</span></p>`
      + `<audio controls src="data:audio/wav;base64,${r.duongTiengBase64}" style="width:100%"></audio>`
      + `<p class="hint">Giọng: ${r.giongNoi.map((g) => `${esc(g.nhanVat)} → ${esc(g.voiceId)}`).join(' · ')}</p>`
      + `<p><a class="pill" href="/film/projects/${S.film}/animatic" target="_blank">Mở phim nháp</a> `
      + `<a class="pill" href="/film/projects/${S.film}/soundtrack" download>Tải đường tiếng</a> `
      + `<a class="pill" href="/film/projects/${S.film}/edl" download>Tải EDL</a> `
      + `<a class="pill" href="/film/projects/${S.film}/ffmpeg" download>Tải kịch bản ghép</a></p>`;
    toast('Xong bản nháp. Chi phí $0.', 'ok');
  }

  function filmOpenAnimatic() {
    if (!S.film) return toast('Chưa có dự án nào.', 'err');
    window.open(`/film/projects/${S.film}/animatic`, '_blank');
  }

  async function filmRender() {
    if (!S.film) return toast('Chưa có dự án nào.', 'err');
    const r0 = await api(`/film/projects/${S.film}/render`, {});
    if (!r0.ok && r0.error !== 'CHƯA_XÁC_NHẬN_CHI_TIÊU') {
      $('fDraft').innerHTML += `<p class="err">${esc(r0.error)} — ${esc(r0.goi || r0.sua || '')}</p>`;
      return toast(r0.error, 'err');
    }
    if (!confirm(`Dựng phim này sẽ tốn khoảng $${r0.duToanUsd}. Tiếp tục?`)) return;
    toast('Đang dựng video thật…', '');
    const r = await api(`/film/projects/${S.film}/render`, { xacNhan: true });
    if (!r.ok) return toast(`${r.error} — ${r.goi || ''}`, 'err');
    $('fDraft').innerHTML += `<p class="ok">Đã dựng ${r.xong}/${r.xong + r.hong} cảnh · tốn $${r.usd}</p>`;
  }

  // ── GIỌNG NÓI GIẢNG VIÊN ──────────────────────────────────────────────
  async function loadVoice() {
    const [st, voices, audit] = await Promise.all([
      api('/voice/status'), api('/voice/voices?limit=500'), api('/voice/audit?limit=30'),
    ]);
    if (!st.ok) { $('vCards').innerHTML = '<div class="muted">Chưa bật được tầng giọng nói.</div>'; return; }

    const v = st.voices; const pr = st.providers; const cp = st.compliance;
    $('vCards').innerHTML = [
      card('Giọng giảng viên', vn(v.agentVoices), `${v.systemVoices} giọng hệ thống · ${pct(v.distinctRatio)} khác biệt`),
      card('Cao độ', `${v.f0Min}–${v.f0Max} Hz`, `nam ${v.byGender['nam'] || 0} · nữ ${v.byGender['nữ'] || 0}`),
      card('Bộ tổng hợp', pr.effective || '—', `${pr.providers.filter((x) => x.available).length}/${pr.providers.length} sẵn sàng`),
      card('Dấu AI', cp.watermark ? 'BẬT' : 'TẮT', cp.checklist.ok ? 'đủ 7/7 yêu cầu luật' : 'CÒN THIẾU', cp.checklist.ok ? 'ok' : 'err'),
      card('Đã đọc', vn(st.stats.synthesized), `đệm ${pct(st.cache.hitRate)} · trung bình ${vn(st.stats.avgMsPerRequest)}ms`),
    ].join('');

    $('vProviders').innerHTML = table(pr.providers, [
      { label: 'Nhà cung cấp', get: (r) => r.name },
      { label: 'Loại', get: (r) => r.kind },
      { label: 'Chính thức', get: (r) => (r.official ? 'có' : 'KHÔNG') },
      { label: 'Trạng thái', html: true, get: (r) => (r.available ? '<b class="ok">sẵn sàng</b>' : `<span class="muted">${esc(r.reason || '')}</span>`) },
      { label: 'Cần làm gì', get: (r) => r.fix || '—' },
      { label: 'Chất lượng', get: (r) => r.quality },
    ]);

    $('vLegal').innerHTML = table(cp.checklist.items, [
      { label: '#', get: (r) => r.no },
      { label: 'Yêu cầu của luật', get: (r) => r.req },
      { label: 'Phần mã đảm nhiệm', get: (r) => r.impl },
      { label: 'Đạt', html: true, get: (r) => (r.ok ? '<b class="ok">✓</b>' : '<b class="err">✗</b>') },
    ]) + `<p class="hint">Hồ sơ đồng ý: ${vn(cp.consents.total)} (còn hiệu lực ${vn(cp.consents.active)}, đã rút ${vn(cp.consents.revoked)}, `
      + `vị thành niên ${vn(cp.consents.minors)}) · nhật ký ${vn(cp.audit.entries)} mắt xích, chuỗi ${cp.audit.verified ? 'nguyên vẹn' : 'ĐÃ BỊ SỬA'} · `
      + `hạn lưu trữ ${cp.retentionDays} ngày.</p>`;

    if (voices.ok) {
      $('vVoices').innerHTML = table(voices.items.slice(0, 120), [
        { label: 'Mã giọng', get: (r) => r.voiceId },
        { label: 'Giảng viên', get: (r) => r.displayName || '—' },
        { label: 'Khối', get: (r) => r.divisionName || '—' },
        { label: 'Giới', get: (r) => r.gender },
        { label: 'Cao độ', get: (r) => `${r.params.f0} Hz` },
        { label: 'Tốc độ', get: (r) => r.params.rate },
        { label: 'Chất giọng', get: (r) => r.character },
        { label: 'Nghe', html: true, get: (r) => Voice.button('Chào em, thầy cô sẽ dạy em bài hôm nay.', { voiceId: r.voiceId }) },
      ]) + `<p class="hint">Hiện 120 giọng đầu trong tổng số ${vn(voices.total)}.</p>`;
      Voice.mountPicker($('vPick'), { limit: 500 });
    }

    renderVoicePipelines(st);
    const styles = await api('/voice/song/styles');
    if (styles.ok) {
      $('sStyle').innerHTML = styles.styles.map((x) => `<option value="${x.id}">${esc(x.name)}</option>`).join('');
      $('sRange').innerHTML = '<option value="">Giữ nguyên cao độ</option>'
        + styles.ranges.map((x) => `<option value="${x.id}">${esc(x.name)}</option>`).join('');
    }

    if (audit.ok) {
      $('vAudit').innerHTML = table(audit.entries, [
        { label: 'Thời điểm', get: (r) => new Date(r.at).toLocaleString('vi-VN') },
        { label: 'Việc', get: (r) => r.event },
        { label: 'Giọng', get: (r) => r.voiceId || '—' },
        { label: 'Bộ tổng hợp', get: (r) => r.provider || '—' },
        { label: 'Học viên', get: (r) => r.subjectId || '—' },
        { label: 'Băm', get: (r) => (r.hash || '').slice(0, 12) },
      ], 'Chưa có lần tạo giọng nào.');
    }
  }

  /** Bảng tuyến xử lý và bảng hậu kỳ. */
  function renderVoicePipelines(st) {
    const sp = st.pipelines.speech;
    $('vPipelines').innerHTML = table(sp.purposes, [
      { label: 'Mục đích', get: (r) => r.name },
      { label: 'Bộ đang dùng', get: (r) => r.effective || '—' },
      { label: 'Hậu kỳ', get: (r) => (r.studio ? r.preset : 'tắt (phát trực tiếp)') },
    ]) + `<p class="hint">Đã đọc ${vn(sp.stats.calls)} lượt · lùi bộ dự phòng ${vn(sp.stats.fellBack)} lần · `
      + `hậu kỳ tiêu ${vn(sp.stats.studioMs)}ms.</p>`
      + table(st.pipelines.singing.engines, [
        { label: 'Bộ máy hát', get: (r) => r.name },
        { label: 'Ngôn ngữ', get: (r) => (r.languages || []).join(', ') },
        { label: 'Trạng thái', html: true, get: (r) => (r.available ? '<b class="ok">sẵn sàng</b>' : `<span class="muted">${esc(r.reason || '')}</span>`) },
      ]);

    $('vStudio').innerHTML = table(st.studio.presets, [
      { label: 'Cài đặt', get: (r) => r.name },
      { label: 'Dùng cho', get: (r) => r.note },
      { label: 'Độ vang đích', get: (r) => `${r.targetLufs} LUFS` },
    ]) + `<p class="hint">Chuỗi xử lý chạy bằng JavaScript trong tiến trình (${esc(st.studio.engine)}), `
      + `không cần ffmpeg: lọc rumble → EQ → de-esser → nén song song → bão hoà hài → hồi âm → `
      + `chuẩn độ vang theo BS.1770 → giới hạn đỉnh.</p>`;
  }

  /** Kiểm bài hát trước khi dựng tiếng. */
  async function songCheck() {
    const r = await api('/voice/song/check', {
      lyrics: $('sLyrics').value, melody: $('sMelody').value,
      bpm: +$('sBpm').value, range: $('sRange').value || null,
    });
    if (!r.ok) { $('sReport').innerHTML = `<span class="err">${esc(r.error)}${r.detail ? ' — ' + esc(r.detail) : ''}</span>`; return null; }
    $('sReport').innerHTML = `${r.pitched} nốt · ${r.rests} chỗ nghỉ · ${r.seconds}s`
      + (r.transpose ? ` · dịch giọng ${r.transpose > 0 ? '+' : ''}${r.transpose} nửa cung` : '')
      + ` · lời ${r.alignment.syllables} âm tiết cho ${r.alignment.notes} nốt`
      + (r.alignment.melisma ? ` (${r.alignment.melisma} chỗ luyến)` : '')
      + (r.alignment.warning ? ` · <span class="warn">${esc(r.alignment.warning)}</span>` : ' · <b class="ok">khớp</b>');
    return r;
  }

  async function songSing() {
    const chk = await songCheck();
    if (!chk) return;
    toast('Đang dựng tiếng hát…', '');
    const r = await api('/voice/song/sing', {
      lyrics: $('sLyrics').value, melody: $('sMelody').value,
      bpm: +$('sBpm').value, range: $('sRange').value || null, style: $('sStyle').value || 'pop',
    });
    if (!r.ok) { toast(r.error || 'Không hát được', 'err'); return; }
    $('sPlayer').innerHTML = `<audio controls src="data:audio/wav;base64,${r.audioBase64}" style="width:100%;margin-top:8px"></audio>`
      + `<p class="hint">${esc(r.styleName)} · bộ máy ${esc(r.engine)} · ${(r.ms / 1000).toFixed(1)}s · `
      + `${esc(r.voiceName || r.voiceId)} · hậu kỳ ${esc(r.studio ? r.studio.presetName : 'không')} `
      + `(${r.studio ? r.studio.before.lufs + ' → ' + r.studio.after.lufs + ' LUFS' : ''}) `
      + `<span class="ai-tag">Giọng AI</span></p>`
      + table(r.sung || [], [
        { label: 'Nốt', get: (x) => x.note },
        { label: 'Âm tiết', get: (x) => x.syllable },
        { label: 'Thanh', get: (x) => x.tone || '—' },
        { label: 'Dài', get: (x) => `${x.ms}ms` },
      ]);
  }

  async function songExportMidi() {
    const r = await api('/voice/music/export-midi', { melody: $('sMelody').value, bpm: +$('sBpm').value });
    if (!r.ok) { toast(r.errors ? r.errors.join('; ') : r.error, 'err'); return; }
    const a = document.createElement('a');
    a.href = `data:audio/midi;base64,${r.midiBase64}`;
    a.download = 'giai-dieu.mid';
    a.click();
    toast(`Đã xuất ${r.notes} nốt ra tệp MIDI.`, 'ok');
  }

  /** Nghe thử một câu: soi trước xem sẽ đọc thành gì rồi mới phát. */
  async function voiceTry() {
    const text = $('vText').value.trim();
    if (!text) return toast('Gõ câu muốn nghe đã.', 'err');
    const ins = await api('/voice/inspect', { text });
    $('vInspect').innerHTML = ins.ok
      ? `Sẽ đọc là: <b>${esc(ins.spoken)}</b> — ${ins.syllables} âm tiết, ${ins.pauses} chỗ ngắt, ~${(ins.estimatedMs / 1000).toFixed(1)}s`
        + (ins.unknown.length ? ` · <span class="err">không đọc được: ${esc(ins.unknown.join(', '))}</span>` : '')
      : `<span class="err">${esc(ins.error || 'không soi được')}</span>`;
    await Voice.play(text, { voiceId: $('vPick').value || undefined });
  }

  // ── TỔNG QUAN ─────────────────────────────────────────────────────────
  async function overview() {
    const [h, cap, fleet] = await Promise.all([api('/health'), api('/agents/capacity'), api('/resilience/fleet')]);
    $('modePill').textContent = h.llm.mode;
    $('modePill').className = 'pill ' + (h.llm.mode === 'LIVE' ? 'ok' : 'warn');
    if (!G.can(h, 'Sức khoẻ hệ thống')) return;
    if (!G.can(fleet, 'Sức khoẻ đội hình')) return;
    $('ovCards').innerHTML = [
      card('Trạng thái', h.status === 'healthy' ? 'Khoẻ' : h.status, `uptime ${n(h.uptimeSec)}s`, h.status === 'healthy' ? 'ok' : 'warn'),
      card('Agent', n(h.kpi.agents), `${n(h.kpi.activeAgents)} đã làm việc`),
      card('Sẵn sàng', pct(fleet.readiness), `${n(fleet.eligible)} nhận được việc`, fleet.readiness > .95 ? 'ok' : 'warn'),
      card('Tác vụ', n(h.kpi.tasks), `thành công ${pct(h.kpi.successRate)}`),
      card('Điểm KPI', h.kpi.kpiScore, `hiệu suất ${h.kpi.efficiency}`),
      card('Chi phí', '$' + n(h.kpi.costUsd, 4), `${n(h.kpi.costPerTaskUsd, 6)}/tác vụ`),
      card('Vi phạm HP', n(h.kpi.violations), 'Hiến pháp', h.kpi.violations ? 'err' : 'ok'),
      card('Nhật ký', h.checks.auditChain === 'up' ? 'Nguyên vẹn' : 'VỠ', 'chuỗi băm', h.checks.auditChain === 'up' ? 'ok' : 'err'),
    ].join('');

    $('ovDivisions').innerHTML = table([
      { label: 'Khối', key: 'division' },
      { label: 'Tổng', key: 'total', num: true },
      { label: 'Khoẻ', key: 'healthy', num: true },
      { label: 'Cách ly', key: 'quarantined', num: true },
      { label: 'Sẵn sàng', num: true, raw: true, get: (r) => bar(r.availability, r.availability > .9 ? 'ok' : 'warn') + ' ' + pct(r.availability) },
    ], fleet.byDivision);

    const kpiRanks = await api('/agents/kpi?by=rank');
    $('ovRanks').innerHTML = table([
      { label: 'Cấp bậc', key: 'rank' },
      { label: 'Agent', key: 'agents', num: true },
      { label: 'Tác vụ', key: 'tasks', num: true },
      { label: 'Đúng', num: true, get: (r) => pct(r.successRate) },
      { label: 'KPI', num: true, raw: true, get: (r) => bar(r.kpiScore) + ' ' + r.kpiScore },
    ], (kpiRanks && kpiRanks.groups) || []);

    $('ovCapacity').innerHTML = [
      card('Đang chạy', `${n(cap.global.running)}/${n(cap.global.limit)}`, `đỉnh ${n(cap.global.peak)}`),
      card('Token/phút', n(cap.global.tokensLastMin), `trần ${n(cap.global.tokensPerMinLimit)}`),
      card('Đã nhận', n(cap.stats.admitted), `từ chối ${n(cap.stats.deniedAgent + cap.stats.deniedDivision + cap.stats.deniedGlobal + cap.stats.deniedTokens)}`),
    ].join('');
    $('ovCapacity').className = 'cards';
  }

  // ── 500 AGENT ─────────────────────────────────────────────────────────
  async function loadAgents() {
    const asg = await api('/agents/assignment');
    if (!G.can(asg, 'Bảng phân công trợ lý AI')) return;
    if (!$('fDivision').dataset.filled) {
      $('fDivision').innerHTML = '<option value="">Tất cả khối</option>' + asg.byDivision.map((d) => `<option value="${d.division}">${esc(d.name)}</option>`).join('');
      $('fRank').innerHTML = '<option value="">Tất cả cấp bậc</option>' + asg.byRank.map((r) => `<option value="${r.rank}">${esc(r.name)}</option>`).join('');
      $('fDivision').dataset.filled = '1';
    }
    $('assignTable').innerHTML = table([
      { label: 'Khối', key: 'name' },
      { label: 'Quân số', key: 'total', num: true },
      { label: 'Điều phối', num: true, get: (r) => r.ranks.PLANNER || 0 },
      { label: 'Thực thi', num: true, get: (r) => r.ranks.WORKER || 0 },
      { label: 'Thanh tra', num: true, get: (r) => r.ranks.CRITIC || 0 },
      { label: 'Huấn luyện', num: true, get: (r) => r.ranks.COACH || 0 },
      { label: 'Nghiên cứu', num: true, get: (r) => r.ranks.RESEARCHER || 0 },
      { label: 'Hộ pháp', num: true, get: (r) => r.ranks.GUARDIAN || 0 },
      { label: 'Slot', key: 'x', num: true, get: (r) => n(r.capacity.concurrent) },
      { label: 'Task/giờ', num: true, get: (r) => n(r.capacity.tasksPerHour) },
    ], asg.byDivision) + `<div class="muted" style="margin-top:8px">Tổng ${n(asg.total)} agent · ${n(asg.capacityTotals.concurrent)} slot đồng thời · ${n(asg.capacityTotals.tasksPerHour)} tác vụ/giờ danh định · bảng phân công hợp lệ: ${asg.taxonomy.ok ? 'CÓ' : 'KHÔNG'}</div>`;

    const q = new URLSearchParams({ limit: '60' });
    if ($('fDivision').value) q.set('division', $('fDivision').value);
    if ($('fRank').value) q.set('rank', $('fRank').value);
    const list = await api('/agents?' + q);
    if (!G.can(list, 'Danh sách trợ lý AI')) return;
    $('agentCount').textContent = `${n(list.total)} agent khớp bộ lọc`;
    $('agentTable').innerHTML = table([
      { label: 'Mã', key: 'id' },
      { label: 'Khối', key: 'division' },
      { label: 'Tổ', key: 'squad' },
      { label: 'Cấp bậc', key: 'rankName' },
      { label: 'Bậc mô hình', key: 'tier' },
      { label: 'Trạng thái', raw: true, get: (r) => `<span class="tag ${r.state === 'IDLE' ? 'ok' : ''}">${esc(r.state)}</span>` },
      { label: 'Đồng thời', num: true, get: (r) => r.capacity.maxConcurrent },
      { label: 'Token/phút', num: true, get: (r) => n(r.capacity.tokensPerMin) },
      { label: 'Quyền', get: (r) => r.permissions.length + ' quyền' },
    ], list.items);
  }

  // ── TỔNG ĐỘNG VIÊN ────────────────────────────────────────────────────
  async function loadMission() {
    if (!$('mKind').dataset.filled) {
      const p = await api('/mission/playbooks');
      $('mKind').innerHTML = p.playbooks.map((x) => `<option value="${x.id}">${esc(x.name)}</option>`).join('');
      $('mKind').dataset.filled = '1';
    }
  }

  function missionSpec() {
    return {
      kind: $('mKind').value,
      objective: $('mObjective').value.trim(),
      scope: { count: Number($('mCount').value) || 30 },
      maxConcurrent: Number($('mConc').value) || 24,
      useHandoff: $('mHandoff').checked,
      issuedBy: S.user || 'superadmin',
    };
  }

  async function planMission() {
    const spec = missionSpec();
    if (!spec.objective) return toast('Nhập mục tiêu nhiệm vụ', 'err');
    const p = await api('/mission/plan', spec);
    if (!p.ok) return toast(p.error, 'err');
    $('missionOut').innerHTML = `<div class="cards">
      ${card('Kịch bản', esc(p.playbook), 'khối chủ trì ' + p.leadDivision)}
      ${card('Huy động', n(p.agentsEngaged), 'agent')}
      ${card('Mảnh việc', n(p.unitsPlanned), `${p.unitsPerWorker} mảnh/người`)}
      ${card('Thực thi', n(p.workersAvailable), 'chuyên viên sẵn sàng')}
    </div>` + table([
      { label: 'Khối', key: 'divisionName' },
      { label: 'Cấp bậc', key: 'rankName' },
      { label: 'Quân số', key: 'count', num: true },
      { label: 'Nhiệm vụ', key: 'duty' },
    ], p.roster);
  }

  async function runMission() {
    const spec = missionSpec();
    if (!spec.objective) return toast('Nhập mục tiêu nhiệm vụ', 'err');
    toast('Đang phát lệnh tới toàn đội…');
    $('missionOut').innerHTML = '<div class="muted">Đang chạy…</div>';
    const r = await api('/mission/execute', spec);
    if (!r.ok) { $('missionOut').innerHTML = `<div class="err">${esc(r.error)}</div>`; return toast(r.error, 'err'); }
    toast(`Xong ${r.unitsDone}/${r.unitsPlanned} mảnh trong ${r.ms}ms`, 'ok');
    $('missionOut').innerHTML = `<div class="cards">
      ${card('Huy động', n(r.agentsEngaged), `${n(r.agentsExecuted)} agent trực tiếp làm`)}
      ${card('Hoàn thành', `${n(r.unitsDone)}/${n(r.unitsPlanned)}`, `lỗi ${n(r.unitsFailed)}`, r.unitsFailed ? 'warn' : 'ok')}
      ${card('Chồng chéo', r.noOverlap ? 'KHÔNG' : 'CÓ', `${n(r.overlapsPrevented)} lần bị chặn`, r.noOverlap ? 'ok' : 'err')}
      ${card('Nghiệm thu', r.criticScore ?? '—', `${n(r.batchesReviewed)} lô đã chấm`)}
      ${card('Vi phạm HP', n(r.constitutionViolations), 'Hiến pháp', r.constitutionViolations ? 'err' : 'ok')}
      ${card('Thời gian', n(r.ms) + 'ms', 'toàn nhiệm vụ')}
    </div>` + table([
      { label: 'Khối', key: 'division' },
      { label: 'Mảnh việc', key: 'units', num: true },
      { label: 'Xong', key: 'ok', num: true },
      { label: 'Lỗi', key: 'failed', num: true },
    ], r.byDivision) + '<h3 style="margin-top:14px;font-size:13px">Các giai đoạn</h3>' + table([
      { label: 'Giai đoạn', key: 'phase' },
      { label: 'Chi tiết', get: (x) => Object.entries(x).filter(([k]) => k !== 'phase').map(([k, v]) => `${k}=${v}`).join(' · ') },
    ], r.phases);
  }

  async function runDebate() {
    const topic = $('dTopic').value.trim();
    if (!topic) return toast('Nhập chủ đề chất vấn', 'err');
    $('debateOut').innerHTML = '<div class="muted">Đang chất vấn…</div>';
    const r = await api('/debate/run', { topic, taskType: 'math_reasoning', participants: Number($('dCount').value) || 3, rounds: 2 });
    if (!r.ok) { $('debateOut').innerHTML = `<div class="err">${esc(r.error)}</div>`; return; }
    $('debateOut').innerHTML = `<div class="cards">
      ${card('Người tham gia', r.participants.length, r.participants.join(', '))}
      ${card('Số vòng', r.rounds, r.converged ? 'đã hội tụ' : 'hết vòng', r.converged ? 'ok' : 'warn')}
      ${card('Lần sửa', r.revisions, 'sau chất vấn')}
      ${card('Chất lượng', r.quality?.weighted ?? '—', r.quality?.verdict ?? '')}
    </div><pre>${esc(String(r.finalVersion).slice(0, 2000))}</pre>`;
  }

  // ── CHƯƠNG TRÌNH ──────────────────────────────────────────────────────
  async function loadCurriculum() {
    const [h, st, bank, cov] = await Promise.all([
      api('/curriculum/hierarchy'), api('/curriculum/standards'), api('/bank/status'), api('/bank/coverage'),
    ]);
    $('curCards').innerHTML = [
      card('Khối', Object.keys(h.blocks).length, 'tiểu học → quốc tế'),
      card('Tầng', h.levels.length, 'L0 Khởi động → L9 Đỉnh cao'),
      card('Độ khó', h.difficulty.length, '1★ → 5★'),
      card('Dạng bài', h.forms.length, h.check.ok ? 'danh mục hợp lệ' : 'CÓ LỖI', h.check.ok ? 'ok' : 'err'),
      card('Học liệu', n(bank.total), `${n(bank.byStatus.PUBLISHED || 0)} đã phát hành`),
      card('Chống trùng', n(bank.duplicatesBlocked), 'bài bị chặn'),
      card('Đa dạng khung', bank.avgDiversity, '1.0 = mỗi bài một khung'),
      card('Còn thiếu', n(cov.missingItems), `${n(cov.gapCells)} ô trống`, cov.missingItems ? 'warn' : 'ok'),
    ].join('');

    $('stdTable').innerHTML = table([
      { label: 'Tầng', key: 'code' },
      { label: 'Tên', key: 'name' },
      { label: 'Mức thạo', num: true, get: (r) => r.mastery },
      { label: 'Tỉ lệ đúng', num: true, get: (r) => r.accuracy },
      { label: 'Cửa sổ', key: 'window', num: true },
      { label: 'Tốc độ ≤', num: true, get: (r) => '×' + r.speedFactor },
      { label: 'Phiên liên tiếp', key: 'consistency', num: true },
      { label: 'Độ phủ', num: true, get: (r) => r.coverage },
      { label: 'Thi chốt', num: true, get: (r) => r.exitExam },
    ], st.standards) + `<div class="muted" style="margin-top:8px">Phải đạt ĐỦ ${st.criteria.length} tiêu chí: ${st.criteria.join(' · ')}. Thiếu một là ở lại tầng.</div>`;

    $('formTable').innerHTML = table([
      { label: 'Mã dạng', key: 'code' },
      { label: 'Tên', key: 'name' },
      { label: 'Tầng', get: (r) => `L${r.levelRange[0]}–L${r.levelRange[1]}` },
      { label: 'Tiền đề', get: (r) => r.prereq.join(', ') || '—' },
      { label: 'Bẫy thường gặp', get: (r) => r.traps.join(' · ') },
      { label: 'Chuẩn (s)', key: 'norm', num: true },
    ], h.forms);

    $('coverage').innerHTML = table([
      { label: 'Dạng', key: 'formCode' },
      { label: 'Tầng', key: 'level', num: true },
      { label: 'Sao', key: 'stars', num: true },
      { label: 'Đang có', key: 'have', num: true },
      { label: 'Cần thêm', key: 'need', num: true },
    ], cov.topGaps.slice(0, 25));
  }

  // ── HỌC VIÊN ──────────────────────────────────────────────────────────
  async function registerLearner() {
    const id = $('lnId').value.trim();
    if (!id) return toast('Nhập mã học viên', 'err');
    const r = await api('/learner/register', { userId: id, fullName: $('lnName').value.trim() || id, grade: Number($('lnGrade').value) || undefined });
    toast(r.ok ? 'Đã đăng ký ' + id : r.error, r.ok ? 'ok' : 'err');
  }

  async function loadPortrait() {
    const id = $('lnId').value.trim();
    if (!id) return toast('Nhập mã học viên', 'err');
    const p = await api('/learner/' + encodeURIComponent(id) + '/portrait');
    if (!p.ok) return toast(p.error, 'err');
    const axisName = { kienThuc: 'Kiến thức', chinhXac: 'Chính xác', tocDo: 'Tốc độ', tuLuc: 'Tự lực', kienTri: 'Kiên trì', chieuSau: 'Chiều sâu' };
    $('portrait').innerHTML = `
      <div class="cards">
        ${card('Học viên', esc(p.fullName), `lớp ${p.grade ?? '—'} · ${p.block ?? '—'}`)}
        ${card('Tầng hiện tại', p.level.code, esc(p.level.name))}
        ${card('Xếp hạng', p.grade5Star + '★', 'tổng hợp ' + p.overall)}
        ${card('Lên tầng', p.promotion.ready ? 'ĐỦ ĐIỀU KIỆN' : 'CHƯA', `${Math.round(p.promotion.score * 7)}/7 tiêu chí`, p.promotion.ready ? 'ok' : 'warn')}
        ${card('Đã thạo', `${n(p.mastery.formsMastered)}/${n(p.mastery.formsTouched)}`, 'dạng bài')}
        ${card('Số ngày học', p.daysEnrolled, 'từ khi đăng ký')}
      </div>
      <div class="panel"><h3>Sáu trục năng lực</h3><div class="axes">
        ${Object.entries(p.axes).map(([k, v]) => `<div class="axis"><div class="n">${axisName[k] || k}</div><div class="p">${pct(v)}</div>${bar(v, v > .8 ? 'ok' : v > .5 ? '' : 'warn')}</div>`).join('')}
      </div></div>
      <div class="panel"><h3>Điều kiện lên tầng — 7 tiêu chí</h3>${table([
        { label: 'Tiêu chí', key: 'k' },
        { label: 'Hiện tại', key: 'v' },
        { label: 'Yêu cầu', key: 'r' },
        { label: 'Kết quả', raw: true, get: (x) => `<span class="tag ${x.p ? 'ok' : 'err'}">${x.p ? 'ĐẠT' : 'CHƯA'}</span>` },
      ], Object.entries(p.promotion.criteria).map(([k, c]) => ({ k, v: String(c.value), r: String(c.required), p: c.pass })))}
        <div class="muted" style="margin-top:8px">${esc(p.promotion.verdict)}</div></div>
      <div class="grid2">
        <div class="panel"><h3>Điểm yếu</h3>${table([
          { label: 'Dạng', key: 'formCode' }, { label: 'Tên', key: 'formName' },
          { label: 'Mức thạo', key: 'p', num: true }, { label: 'Đúng', num: true, get: (x) => pct(x.accuracy) },
        ], p.weaknesses)}</div>
        <div class="panel"><h3>Hành vi quan sát được</h3>${table([
          { label: 'Mẫu hình', key: 'name' }, { label: 'Đối ứng', key: 'advice' },
        ], p.behaviors)}</div>
      </div>
      <div class="panel"><h3>Bẫy hay mắc</h3>${table([
        { label: 'Dạng', key: 'formCode' }, { label: 'Bẫy', key: 'trap' }, { label: 'Số lần', key: 'occurrences', num: true },
      ], p.misconceptions)}</div>
      <div class="panel"><h3>Khuyến nghị</h3>${table([
        { label: 'Nguồn', key: 'source' }, { label: 'Dấu hiệu', key: 'trigger' }, { label: 'Hành động', key: 'action' },
      ], p.recommendations)}</div>`;
  }

  // ── BẢO MẬT ───────────────────────────────────────────────────────────
  async function loadSecurity() {
    const [st, layers, shield, un] = await Promise.all([
      api('/superadmin/status'), api('/superadmin/layers'), api('/resilience/status'), api('/resilience/unhealthy'),
    ]);
    // Bốn lượt gọi, cả bốn đều đòi quyền. Hỏng một lượt mà vẫn đi tiếp thì
    // dòng đầu tiên đọc thuộc tính của undefined sẽ ném lỗi và giết cả hàm —
    // mất luôn ba phần dựng được. Dừng ngay tại đây và nói rõ lý do.
    if (!G.can(st, 'Trạng thái Super Admin')) return;
    if (!G.can(layers, 'Danh sách tầng bảo vệ')) return;
    $('secCards').innerHTML = [
      card('Tầng bảo vệ', st.layers, 'Super Admin'),
      card('Mã khôi phục', st.recoveryCodesLeft, 'còn lại', st.recoveryCodesLeft > 3 ? 'ok' : 'warn'),
      card('Phá kính', st.breakGlassAvailable ? 'Còn' : 'ĐÃ DÙNG', 'một lần duy nhất', st.breakGlassAvailable ? 'ok' : 'err'),
      card('Nhóm giám hộ', st.guardianPolicy, 'khôi phục theo nhóm'),
      card('Phiên đang mở', st.activeSessions, `${st.knownDevices} thiết bị đã biết`),
      card('Lệnh đã duyệt', st.stats.commands, `từ chối ${st.stats.denied}`),
      card('Bất thường', st.stats.anomalies, 'lần phát hiện', st.stats.anomalies ? 'warn' : 'ok'),
      card('Tuổi mật khẩu', st.passwordAgeDays + ' ngày', 'nên đổi định kỳ'),
    ].join('');

    $('layerTable').innerHTML = table([
      { label: 'Tầng', key: 'id' }, { label: 'Tên', key: 'name' }, { label: 'Nhóm', key: 'kind' },
    ], layers.layers) + `<div class="muted" style="margin-top:8px">Lệnh huỷ diệt (cần step-up + chữ ký + kiểm soát kép): ${layers.destructive.join(' · ')}</div>`;

    if (!G.can(shield, 'Lá chắn chống nhiễu')) return;
    $('shieldBox').innerHTML = `<div class="cards">
      ${card('Cơ chế', shield.mechanisms, 'chạy đồng thời')}
      ${card('Luật lọc nhiễu', shield.noiseRules, `chặn ${n(shield.stats.noiseBlocked)} lần`)}
      ${card('Sẵn sàng', pct(shield.fleet.readiness), `${n(shield.fleet.eligible)}/${n(shield.fleet.total)}`, shield.fleet.readiness > .95 ? 'ok' : 'warn')}
      ${card('Cách ly', n(shield.stats.quarantined), `thả ${n(shield.stats.released)}`)}
      ${card('Treo', n(shield.stats.stallsDetected), `thu hồi ${n(shield.stats.slotsReclaimed)} chỗ`)}
      ${card('Dao động', n(shield.stats.flapsDamped), 'bị giảm chấn')}
      ${card('Áp lực ngược', n(shield.stats.backpressureRejects), 'lần từ chối sớm')}
      ${card('Tín hiệu/nhiễu', shield.fleet.signalToNoise === null ? '—' : shield.fleet.signalToNoise, 'thành công / lỗi')}
    </div>`;
    $('unhealthy').innerHTML = table([
      { label: 'Agent', key: 'agentId' }, { label: 'Khối', key: 'division' }, { label: 'Trạng thái', key: 'state' },
      { label: 'Lỗi liên tiếp', key: 'consecutiveFailures', num: true },
      { label: 'Còn cách ly (s)', num: true, get: (r) => Math.round(r.quarantinedForMs / 1000) },
    ], un.items);
  }

  async function healAll() {
    const r = await api('/resilience/heal-all', {});
    toast(`Đã chữa ${r.healed} agent`, 'ok');
    loadSecurity();
  }

  // ── KHÔI PHỤC ─────────────────────────────────────────────────────────
  async function loadRecovery() {
    const [snaps, tl] = await Promise.all([api('/snapshots'), api('/snapshots/timeline')]);
    if (!G.can(snaps, 'Danh sách ảnh chụp hệ thống')) return;
    $('snapBox').innerHTML = `<div class="cards">
      ${card('Ảnh chụp', snaps.status.count, `tự động mỗi ${snaps.status.autoIntervalMin} phút`)}
      ${card('Toàn vẹn', snaps.status.chainIntegrity === 'INTACT' ? 'Nguyên vẹn' : 'VỠ', 'chuỗi băm', snaps.status.chainIntegrity === 'INTACT' ? 'ok' : 'err')}
      ${card('Mới nhất', snaps.status.newest?.version ?? '—', snaps.status.newest?.iso?.slice(0, 19).replace('T', ' ') ?? '')}
      ${card('Dung lượng', n(Math.round(snaps.status.totalBytes / 1024)) + ' KB', 'tổng các ảnh')}
    </div>` + table([
      { label: 'Phiên bản', key: 'version' },
      { label: 'Thời điểm', get: (r) => r.iso.slice(0, 19).replace('T', ' ') },
      { label: 'Tuổi (phút)', key: 'ageMinutes', num: true },
      { label: 'Nhãn', key: 'label' },
      { label: 'Tự động', get: (r) => (r.auto ? 'có' : 'không') },
      { label: 'Băm', key: 'hash' },
    ], snaps.items);

    $('timeline').innerHTML = table([
      { label: 'Mốc', key: 'name' },
      { label: 'Thời điểm', get: (r) => r.iso.slice(0, 19).replace('T', ' ') },
      { label: 'Ảnh khả dụng', get: (r) => (r.snapshot ? `${r.snapshot.version} (${r.snapshot.iso.slice(11, 19)})` : 'chưa có') },
    ], (tl && tl.timeline) || []);
  }

  async function takeSnapshot() {
    const r = await api('/snapshots/take', { label: 'manual' });
    toast(r.ok ? `Đã chụp ${r.version}` : 'Lỗi', r.ok ? 'ok' : 'err');
    loadRecovery();
  }

  async function verifySnapshots() {
    const r = await api('/snapshots/verify');
    toast(r.ok ? `Toàn vẹn: ${r.snapshots} ảnh` : `VỠ tại ${r.brokenAt}`, r.ok ? 'ok' : 'err');
  }

  async function restore(dryRun) {
    const version = $('rVersion').value.trim();
    if (!version) return toast('Nhập phiên bản cần khôi phục', 'err');
    if (!dryRun && !confirm(`Khôi phục toàn hệ về ${version}? Hệ thống sẽ tự chụp ảnh an toàn trước.`)) return;
    const r = await api('/recovery/restore-system', { selector: { version }, dryRun, actor: S.user });
    if (!r.ok) { $('restoreOut').innerHTML = `<div class="err">${esc(r.error)}</div>`; return; }
    $('restoreOut').innerHTML = `<pre>${esc(JSON.stringify(r, null, 2).slice(0, 2500))}</pre>`;
    toast(dryRun ? 'Chạy thử xong — chưa đổi gì' : `Đã khôi phục về ${r.plan.version}`, 'ok');
  }

  // ── HIẾN PHÁP ─────────────────────────────────────────────────────────
  async function loadGovernance() {
    const [arts, heart, rep] = await Promise.all([
      api('/constitution/articles'), api('/heart/axioms'), api('/compliance/report'),
    ]);
    if (!G.can(arts, 'Hiến pháp')) return;
    if (!G.can(heart, 'Bộ tiên đề HEART')) return;
    if (!G.can(rep, 'Báo cáo tuân thủ')) return;
    $('govCards').innerHTML = [
      card('Điều luật', arts.total, Object.entries(arts.chapters).map(([c, n2]) => `${c}:${n2}`).join(' ')),
      card('HEART', Object.keys(heart.axioms).length, 'axiom + ' + heart.nesBoundaries.length + ' ranh giới NES'),
      card('Bản ghi', n(rep.totalRecords), 'nhật ký bất biến'),
      card('Toàn vẹn', rep.chainIntegrity === 'INTACT' ? 'Nguyên vẹn' : 'VỠ', 'chuỗi băm', rep.chainIntegrity === 'INTACT' ? 'ok' : 'err'),
    ].join('');
    $('artTable').innerHTML = table([
      { label: 'Điều', key: 'id' }, { label: 'Chương', key: 'ch' }, { label: 'Tiêu đề', key: 't' }, { label: 'Nội dung', key: 'c' },
    ], arts.articles);
    $('auditBox').innerHTML = table([
      { label: 'Hành động', key: 'k' }, { label: 'Số lần', key: 'v', num: true },
    ], Object.entries(rep.byAction).sort((a, b) => b[1] - a[1]).slice(0, 20).map(([k, v]) => ({ k, v })))
      + `<div class="muted" style="margin-top:8px">Cơ sở pháp lý: ${rep.legalBasis.join(' · ')}</div>`;
  }

  // ── KHỞI ĐỘNG ─────────────────────────────────────────────────────────
  // ── HỌC LIỆU ─────────────────────────────────────────────────────────────

  async function loadContent() {
    const [bank, cov, bps] = await Promise.all([
      api('/bank/status'), api('/authoring/coverage'), api('/authoring/blueprints'),
    ]);
    const byStatus = bank.byStatus || {};
    $('cntCards').innerHTML = [
      cardHtml('Bài trong kho', G.vn(bank.total ?? 0), 'mọi trạng thái'),
      cardHtml('Đã phát hành', G.vn(byStatus.PUBLISHED ?? 0), 'học viên dùng được', 'ok'),
      cardHtml('Chờ người duyệt', G.vn(byStatus.REVIEWED ?? 0), 'bài từ 4★ trở lên', (byStatus.REVIEWED ?? 0) ? 'warn' : ''),
      cardHtml('Độ phủ kho', cov.ok ? G.pct(cov.ratio, 0) : '—', cov.ok ? `${cov.filled}/${cov.slots} ô (dạng × tầng)` : '', cov.ok && cov.ratio >= 1 ? 'ok' : 'warn'),
      cardHtml('Bản thiết kế', G.vn(bps.ok ? bps.count : 0), 'ý đồ sư phạm khác nhau'),
    ].join('');

    const items = (await api('/bank/items?status=PUBLISHED&limit=1000')).items || [];
    const byLevel = {};
    const byStars = {};
    for (const it of items) {
      byLevel[`L${it.level}`] = (byLevel[`L${it.level}`] || 0) + 1;
      byStars[`${it.stars}★`] = (byStars[`${it.stars}★`] || 0) + 1;
    }
    $('cntByLevel').innerHTML = G.barChart(Object.entries(byLevel).sort().map(([k, v]) => ({ label: k, short: k, value: v })));
    $('cntByStars').innerHTML = G.barChart(Object.entries(byStars).sort().map(([k, v]) => ({ label: k, short: k, value: v })));

    $('cntThin').innerHTML = cov.ok && (cov.thin || []).length
      ? G.table(cov.thin, [
        { label: 'Ô (dạng × tầng)', get: (x) => x.slot },
        { label: 'Số bài', cls: 'num', get: (x) => x.items },
        { label: 'Cần thêm', cls: 'num', get: (x) => 3 - x.items },
      ])
      : '<div class="muted">Không có ô nào mỏng dưới 3 bài.</div>';

    $('cntBlueprints').innerHTML = bps.ok
      ? G.table(bps.items, [
        { label: 'Mã', get: (b) => b.id },
        { label: 'Dạng', get: (b) => b.formCode },
        { label: 'Ý đồ sư phạm', get: (b) => b.intent },
        { label: 'Nhắm bẫy', get: (b) => b.targetTrap },
        { label: 'Sao', cls: 'num', get: (b) => b.stars },
      ])
      : '<div class="muted">Không đọc được danh mục bản thiết kế.</div>';
  }

  // ── VẬN HÀNH THỜI GIAN THỰC ──────────────────────────────────────────────

  let liveTimer = null;

  function toggleLive(on) {
    if (liveTimer) { clearInterval(liveTimer); liveTimer = null; }
    if (on) liveTimer = setInterval(() => { if (S.tab === 'live') loadLive(); }, 5000);
  }

  async function loadLive() {
    const [health, cap, kpi, org, acc, events, sys] = await Promise.all([
      api('/health'), api('/agents/capacity'), api('/agents/kpi'),
      api('/org/status'), api('/accounts/status'), api('/events?limit=15'),
      api('/reports/system'),
    ]);
    // Bảy lượt gọi. Hỏng một là cả màn hình trực ca không dựng được, nên
    // kiểm từng cái và nói rõ cái nào hỏng — thay vì để người dùng nhìn một
    // màn hình trống không hiểu vì sao.
    //
    // Viết thẳng từng dòng chứ không gom vào một vòng lặp, dù vòng lặp ngắn
    // hơn. Lý do: bộ soi giao diện KHÔNG đọc được tên biến nằm trong vòng lặp
    // — và người đọc lướt qua tệp này cũng vậy. Cái gì máy không thấy thì
    // người cũng khó thấy.
    if (!G.can(health, 'Sức khoẻ hệ thống')) return;
    if (!G.can(cap, 'Công suất')) return;
    if (!G.can(kpi, 'Chỉ số trợ lý AI')) return;
    if (!G.can(org, 'Tổ chức')) return;
    if (!G.can(acc, 'Tài khoản')) return;

    const g = cap.global || cap.status?.global || {};
    $('liveCards').innerHTML = [
      cardHtml('Trạng thái', health.status || '—', `chạy ${Math.round((health.uptimeSec || 0) / 60)} phút`,
        health.status === 'healthy' ? 'ok' : health.status === 'degraded' ? 'warn' : 'err'),
      cardHtml('Đang chạy', `${g.inFlight ?? 0}/${g.limit ?? 0}`, `dùng ${G.pct(g.utilization ?? 0, 0)} công suất`),
      cardHtml('Tác vụ đã xong', G.vn(kpi.tasks ?? 0), `thành công ${G.pct(kpi.successRate ?? 0, 0)}`,
        (kpi.successRate ?? 1) >= 0.9 ? 'ok' : 'warn'),
      cardHtml('Người dùng', G.vn(acc.users ?? 0), `${acc.activeSessions ?? 0} phiên đang mở`),
      cardHtml('Lớp · học viên', `${org.classes ?? 0} · ${org.learners ?? 0}`, `${org.unassigned ?? 0} em chưa vào lớp`,
        (org.unassigned ?? 0) ? 'warn' : 'ok'),
      cardHtml('Bộ nhớ', `${health.memoryMB ?? '—'} MB`, `hàng đợi ${health.queue?.waiting ?? 0}`),
    ].join('');

    const divs = (cap.byDivision || []).map((d) => ({
      label: d.division, short: d.division.slice(0, 4),
      value: Math.round((d.utilization ?? 0) * 100),
    }));
    $('liveDivisions').innerHTML = divs.length
      ? G.barChart(divs, { format: (v) => `${v}%` })
      : '<div class="muted">Chưa có tải nào.</div>';

    $('liveLatency').innerHTML = G.table([
      { k: 'Độ trễ p50', v: `${kpi.p50LatencyMs ?? '—'} ms` },
      { k: 'Độ trễ p95', v: `${kpi.p95LatencyMs ?? '—'} ms` },
      { k: 'Chi phí', v: `${kpi.costUsd ?? 0} USD` },
      { k: 'Trúng cache', v: G.pct(health.cache?.hitRate ?? 0, 0) },
      { k: 'Hàng đợi chờ', v: G.vn(health.queue?.waiting ?? 0) },
      { k: 'Nhật ký bất biến', v: health.checks?.auditChain === 'up' ? 'nguyên vẹn' : 'CÓ VẤN ĐỀ' },
    ], [{ label: 'Chỉ số', get: (x) => x.k }, { label: 'Giá trị', get: (x) => x.v }]);

    $('liveSchool').innerHTML = G.table(Object.entries(org.byGrade || {}).map(([k, v]) => ({ k, v })), [
      { label: 'Khối lớp', get: (x) => x.k },
      { label: 'Số lớp', cls: 'num', get: (x) => x.v },
    ], 'Chưa có lớp nào.');

    $('liveFindings').innerHTML = sys.ok
      ? G.table(sys.findings, [
        { label: 'Mức', html: true, get: (f) => `<span class="tag ${f.severity === 'cao' ? 'err' : ''}">${esc(f.severity)}</span>` },
        { label: 'Vấn đề', get: (f) => f.what },
        { label: 'Chi tiết', get: (f) => f.detail },
        { label: 'Nên làm', get: (f) => f.action },
      ])
      : '<div class="muted">Không đọc được báo cáo hệ thống.</div>';

    $('liveEvents').innerHTML = G.table((events.items || events.events || []).slice(-15).reverse(), [
      { label: 'Lúc', get: (e) => new Date(e.at || e.ts || Date.now()).toLocaleTimeString('vi-VN') },
      { label: 'Loại', get: (e) => e.type || e.action || '—' },
      { label: 'Nội dung', get: (e) => JSON.stringify(e.payload || e.detail || {}).slice(0, 90) },
    ], 'Chưa có sự kiện.');
  }

  function cardHtml(k, v, s, cls = '') {
    return `<div class="card ${cls}"><div class="k">${esc(k)}</div><div class="v">${esc(v)}</div><div class="s">${esc(s || '')}</div></div>`;
  }

  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('#nav a').forEach((a) => a.addEventListener('click', () => setTab(a.dataset.tab)));
    boot();
  });

  return {
    initialize, doneSecrets, login, logout, refresh, setTab, voiceTry, songCheck, songSing, songExportMidi,
    filmSample, filmPrepare, filmLoad, filmDraft, filmOpenAnimatic, filmRender,
    photoPrepare, photoEnhance, photoMeasure,
    loadAgents, planMission, runMission, runDebate,
    registerLearner, loadPortrait, healAll,
    takeSnapshot, verifySnapshots, restore,
    loadContent, loadLive, toggleLive,
  };
})();
