'use strict';
/**
 * PHÒNG GIÁO VIÊN.
 * Câu hỏi mà mỗi màn hình phải trả lời: "em nào đang cần tôi, và cần gì".
 */
const App = (function () {
  const { api, $, esc, tex, buocGiai, pct, stars, vn, toast, table, bar, radar, barChart } = G;

  const S = { tab: 'classes', user: null, classes: [], classId: null, roster: [], learnerId: null };

  // ── Vào / ra ─────────────────────────────────────────────────────────────

  /**
   * Hiện nút khuôn mặt CHỈ KHI máy thật sự có bộ xác thực sinh trắc học gắn
   * trong. Hiện sẵn rồi báo lỗi khi bấm là hứa một thứ không có — và người
   * dùng sẽ nhớ lời hứa hỏng ấy lâu hơn nhớ tính năng.
   */
  async function doKhuonMat() {
    const nut = G.$('nutKhuonMat');
    const ghi = G.$('ghiKhuonMat');
    if (!nut) return;
    if (await G.mayCoSinhTracHoc()) {
      nut.classList.remove('hidden');
      if (ghi) ghi.classList.remove('hidden');
    }
  }

  async function vaoBangKhuonMat() {
    const loi = G.$('loginErr');
    if (loi) loi.textContent = '';
    const ten = (G.$('lUser') && G.$('lUser').value.trim()) || null;
    const r = await G.vaoBangKhuonMat(ten);
    if (!r.ok) {
      if (loi) loi.textContent = G.noiLoiKhuonMat(r);
      return;
    }
    if (!['TEACHER', 'ADMIN'].includes(r.user.role)) {
      if (loi) loi.textContent = 'Tài khoản này không có quyền vào phòng giáo viên.';
      G.clearSession();
      return;
    }
    await enter(r.user);
  }

  async function login() {
    $('loginErr').textContent = '';
    const r = await G.login($('lUser').value.trim(), $('lPass').value);
    if (!r.ok) {
      $('loginErr').textContent = r.error === 'INVALID_CREDENTIALS' ? 'Sai tên đăng nhập hoặc mật khẩu.'
        : r.error === 'LOCKED_OUT' ? `Tài khoản đang bị khoá, thử lại sau ${r.remainMin} phút.`
          : (r.message || r.error || 'Không đăng nhập được.');
      return;
    }
    if (!['TEACHER', 'ADMIN'].includes(r.user.role)) {
      $('loginErr').textContent = 'Tài khoản này không có quyền vào phòng giáo viên.';
      G.clearSession();
      return;
    }
    await enter(r.user);
  }

  async function enter(user) {
    S.user = user;
    $('login').classList.remove('active');
    $('main').classList.add('active');
    $('sideUser').textContent = `${user.fullName || user.username} · ${user.roleName || user.role}`;
    await loadClasses();
  }

  async function logout() { await G.logout(); location.reload(); }

  function setTab(tab) {
    S.tab = tab;
    document.querySelectorAll('#nav a').forEach((a) => a.classList.toggle('on', a.dataset.tab === tab));
    document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('hidden', t.id !== `tab-${tab}`));
    $('tabTitle').textContent = ({
      classes: 'Lớp của tôi', learner: 'Từng học viên', alerts: 'Cần chú ý',
      content: 'Học liệu', report: 'Báo cáo', import: 'Nhập danh sách',
    })[tab] || tab;
    ({ classes: loadClass, learner: loadLearner, alerts: loadAlerts, content: loadContent, report: loadReport, import: () => {} })[tab]?.();
  }

  async function refresh() { await loadClasses(); }

  // ── Lớp ──────────────────────────────────────────────────────────────────

  async function loadClasses() {
    const q = S.user.role === 'TEACHER' ? `?teacherId=${encodeURIComponent(S.user.id)}` : '';
    const r = await api(`/org/classes${q}`);
    S.classes = r.ok ? r.items : [];
    $('classPicker').innerHTML = S.classes.length
      ? S.classes.map((c) => `<option value="${esc(c.id)}">${esc(c.name)} · lớp ${c.grade} · ${c.size} em</option>`).join('')
      : '<option value="">(chưa có lớp nào)</option>';
    S.classId = S.classes[0]?.id || null;
    $('classPill').textContent = S.classId ? `${S.classes.length} lớp` : 'Chưa có lớp';
    await loadClass();
  }

  function pickClass(id) { S.classId = id; loadClass(); }

  async function loadClass() {
    if (!S.classId) {
      $('clsCards').innerHTML = '';
      $('rosterBox').innerHTML = '<div class="muted">Bạn chưa được phân công lớp nào. Liên hệ quản trị để được gán lớp.</div>';
      $('levelChart').innerHTML = '';
      $('groupBox').innerHTML = '';
      return;
    }
    const [cls, roster] = await Promise.all([
      api(`/org/classes/${encodeURIComponent(S.classId)}`),
      api(`/org/classes/${encodeURIComponent(S.classId)}/roster`),
    ]);
    if (!cls.ok) { $('rosterBox').innerHTML = `<div class="err">${esc(cls.error)}</div>`; return; }
    const c = cls.class;
    S.roster = roster.ok ? roster.items : [];

    $('clsCards').innerHTML = [
      cardOf('Sĩ số', `${c.size}/${c.capacity}`, `${esc(c.name)} · lớp ${c.grade}`),
      cardOf('Phổ trình độ', c.levelSpread ? `L${c.levelSpread.min}–L${c.levelSpread.max}` : '—',
        c.levelSpread ? `trung bình L${c.levelSpread.avg}` : 'chưa có dữ liệu'),
      cardOf('Nhóm', String((c.groups || []).length), 'chia theo tầng'),
      cardOf('Năm học', c.schoolYear, c.teacherName || ''),
    ].join('');

    const spread = c.levelSpread?.byLevel || {};
    $('levelChart').innerHTML = barChart(
      Object.entries(spread).sort().map(([k, v]) => ({ label: k, short: k, value: v })),
      { format: (v) => `${v}` },
    );

    $('rosterBox').innerHTML = table(S.roster, [
      { label: 'Họ tên', get: (x) => x.fullName },
      { label: 'Mã', get: (x) => x.id },
      { label: 'Tầng', get: (x) => `L${x.level}${x.levelName ? ' · ' + x.levelName : ''}` },
      { label: 'Nhóm', get: (x) => (x.groupIds || []).join(', ') || '—' },
      { label: '', html: true, get: (x) => `<button class="ghost" onclick="App.openLearner('${esc(x.id)}')">Xem</button>` },
    ], 'Lớp chưa có học viên nào.');

    $('groupBox').innerHTML = (c.groups || []).length
      ? table(c.groups, [
        { label: 'Nhóm', get: (g) => g.name },
        { label: 'Số em', cls: 'num', get: (g) => g.learnerIds.length },
        { label: 'Thành viên', get: (g) => g.learnerIds.map((id) => (S.roster.find((r) => r.id === id) || {}).fullName || id).join('; ') },
      ])
      : '<div class="muted">Chưa chia nhóm.</div>';

    $('learnerPicker').innerHTML = S.roster.map((x) => `<option value="${esc(x.id)}">${esc(x.fullName)}</option>`).join('')
      || '<option value="">(chưa có học viên)</option>';
    const exp = $('expLearners');
    if (exp) exp.href = `/io/export-learners?classId=${encodeURIComponent(S.classId)}`;
  }

  function cardOf(k, v, s, cls = '') {
    return `<div class="card ${cls}"><div class="k">${esc(k)}</div><div class="v">${esc(v)}</div><div class="s">${esc(s || '')}</div></div>`;
  }

  async function autoGroup() {
    if (!S.classId) return toast('Chưa chọn lớp', 'err');
    const r = await api(`/org/classes/${encodeURIComponent(S.classId)}/auto-group`, {
      maxPerGroup: Number($('groupSize').value) || 6, by: S.user.id,
    });
    toast(r.ok ? `Đã chia ${r.groups.length} nhóm theo tầng.` : (r.error || 'Không chia được'), r.ok ? 'ok' : 'err');
    if (r.ok) await loadClass();
  }

  // ── Từng học viên ────────────────────────────────────────────────────────

  function openLearner(id) { S.learnerId = id; setTab('learner'); $('learnerPicker').value = id; loadLearner(); }
  function pickLearner(id) { S.learnerId = id; loadLearner(); }

  async function loadLearner() {
    const id = S.learnerId || $('learnerPicker')?.value || S.roster[0]?.id;
    if (!id) { $('lnCards').innerHTML = '<div class="muted">Chưa chọn học viên.</div>'; return; }
    S.learnerId = id;

    const [p, b, promo] = await Promise.all([
      api(`/learner/${encodeURIComponent(id)}/portrait`),
      api(`/behavior/${encodeURIComponent(id)}`),
      api(`/promotion/${encodeURIComponent(id)}`),
    ]);

    if (!p.ok) { $('lnCards').innerHTML = `<div class="err">${esc(p.error)}</div>`; return; }
    $('lnCards').innerHTML = [
      cardOf('Tầng', `L${p.level}`, p.levelName || ''),
      cardOf('Mức thạo TB', pct(p.mastery?.avgMastery ?? 0, 0), `${p.mastery?.formsMastered ?? 0} dạng đã thạo`),
      cardOf('Số bài đã làm', vn(b.ok ? b.samples : 0), b.ok && b.trend?.enough ? b.trend.direction : ''),
      cardOf('Xếp hạng', p.grade5Star || '—', ''),
    ].join('');

    const axisName = { kienThuc: 'Kiến thức', chinhXac: 'Chính xác', tocDo: 'Tốc độ', tuLuc: 'Tự lực', kienTri: 'Kiên trì', chieuSau: 'Chiều sâu' };
    const axes = {};
    for (const [k, v] of Object.entries(p.axes || {})) axes[axisName[k] || k] = v;
    $('lnRadar').innerHTML = radar(axes);

    const parts = [];
    if (b.ok) {
      parts.push(`<p>${esc(b.summary)}</p>`);
      if (b.anomalies?.flags?.length) {
        parts.push('<b class="warn">Dấu hiệu cần thầy cô xem lại</b><ul>'
          + b.anomalies.flags.map((f) => `<li><b>${esc(f.kind.replace(/_/g, ' '))}</b>: ${esc(f.detail)} <span class="muted">${esc(f.note)}</span></li>`).join('')
          + `</ul><p class="muted">${esc(b.anomalies.disclaimer)}</p>`);
      }
      if (b.actions?.length) parts.push(`<b>Nên làm</b><ul>${b.actions.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>`);
    }
    $('lnInsight').innerHTML = parts.join('') || '<div class="muted">Chưa đủ dữ liệu.</div>';

    if (promo.ok) {
      const rows = Object.entries(promo.criteria).map(([k, c]) => ({ k, c }));
      $('lnPromo').innerHTML = `
        <p class="${promo.eligible ? '' : 'warn'}"><b>${esc(promo.verdict)}</b></p>
        ${table(rows, [
        { label: 'Tiêu chí', get: (x) => x.k },
        { label: 'Đang đạt', get: (x) => (typeof x.c.value === 'boolean' ? (x.c.value ? 'có' : 'chưa') : x.c.value ?? '—') },
        { label: 'Cần', get: (x) => (typeof x.c.required === 'boolean' ? 'có' : x.c.required) },
        { label: '', html: true, get: (x) => (x.c.pass ? '<span class="tag ok">đạt</span>' : '<span class="tag err">chưa</span>') },
      ])}
        ${promo.eligible ? `<div class="row"><button class="primary" onclick="App.promote()">Cho lên tầng</button></div>` : ''}`;
    }

    const forms = Object.entries(p.masteryByForm || {})
      .map(([code, v]) => ({ code, name: (p.formNames || {})[code] || code, p: v }))
      .sort((a, b2) => a.p - b2.p);
    $('lnMastery').innerHTML = table(forms, [
      { label: 'Dạng', get: (x) => x.name },
      { label: 'Mức thạo', html: true, get: (x) => `${bar(x.p, x.p >= 0.85 ? 'ok' : x.p >= 0.5 ? 'warn' : 'err')} ${pct(x.p, 0)}` },
    ], 'Chưa có dữ liệu học tập.');
  }

  async function promote() {
    const r = await api(`/promotion/${encodeURIComponent(S.learnerId)}`, { by: S.user.id });
    toast(r.ok ? `Đã lên ${r.levelName}.` : (r.note || r.error || 'Chưa đủ điều kiện'), r.ok ? 'ok' : 'err');
    await loadLearner();
  }

  // ── Cần chú ý ────────────────────────────────────────────────────────────

  async function loadAlerts() {
    if (!S.roster.length) { $('alertBox').innerHTML = '<div class="muted">Chưa có học viên.</div>'; return; }
    $('alertBox').innerHTML = '<div class="muted">Đang đọc dữ liệu từng em…</div>';
    const rows = [];
    for (const ln of S.roster) {
      const b = await api(`/behavior/${encodeURIComponent(ln.id)}`);
      if (!b.ok) continue;
      const issues = [];
      let severity = 0;
      if (b.trend?.enough && b.trend.direction === 'ĐANG XUỐNG') { issues.push('kết quả đang tụt'); severity += 3; }
      if (b.guessing?.enough && b.guessing.verdict.includes('CÓ')) { issues.push('có dấu hiệu đoán mò'); severity += 2; }
      if (b.attentionSpan?.enough && b.attentionSpan.accuracyDrop >= 0.2) { issues.push('đuối rõ về cuối buổi'); severity += 1; }
      for (const f of b.anomalies?.flags || []) { issues.push(f.kind.replace(/_/g, ' ').toLowerCase()); severity += 2; }
      for (const pt of b.patterns || []) { issues.push(pt.name.toLowerCase()); severity += 1; }
      if (!b.enoughData) { issues.push('chưa đủ dữ liệu để đánh giá'); severity += 0.5; }
      if (issues.length) rows.push({ ln, issues, severity, actions: (b.actions || []).slice(0, 2) });
    }
    rows.sort((a, b2) => b2.severity - a.severity);
    $('alertBox').innerHTML = rows.length
      ? table(rows, [
        { label: 'Học viên', html: true, get: (r) => `<button class="ghost" onclick="App.openLearner('${esc(r.ln.id)}')">${esc(r.ln.fullName)}</button>` },
        { label: 'Tầng', get: (r) => `L${r.ln.level}` },
        { label: 'Dấu hiệu', get: (r) => r.issues.join('; ') },
        { label: 'Nên làm', get: (r) => r.actions.join(' ') || '—' },
        { label: 'Mức', html: true, get: (r) => (r.severity >= 4 ? '<span class="tag err">cao</span>' : r.severity >= 2 ? '<span class="tag">vừa</span>' : '<span class="tag">thấp</span>') },
      ])
      : '<div class="muted">Không em nào có dấu hiệu bất thường.</div>';
  }

  // ── Học liệu ─────────────────────────────────────────────────────────────

  async function loadContent() {
    const [bank, cov, forms] = await Promise.all([
      api('/bank/status'), api('/authoring/coverage'), api('/curriculum/forms'),
    ]);
    if (bank.ok) {
      $('bankCards').innerHTML = [
        cardOf('Bài trong kho', vn(bank.total ?? bank.items ?? 0), 'mọi trạng thái'),
        cardOf('Đã phát hành', vn(bank.byStatus?.PUBLISHED ?? 0), 'học viên dùng được'),
        cardOf('Chờ duyệt', vn(bank.byStatus?.REVIEWED ?? 0), 'cần thầy cô xem'),
        cardOf('Độ phủ', cov.ok ? pct(cov.ratio, 0) : '—', cov.ok ? `${cov.filled}/${cov.slots} ô` : ''),
      ].join('');
    }

    const pending = await api('/bank/items?status=REVIEWED&limit=30');
    const items = pending.ok ? (pending.items || []) : [];
    $('pendingBox').innerHTML = items.length
      ? items.map((it) => `<div class="item-card">
          <div class="meta"><span class="tag">${esc(it.formName || it.formCode)}</span><span class="stars">${stars(it.stars)}</span><span class="tag">tầng ${it.level}</span></div>
          <div class="stem">${tex(it.stem)}</div>
          <details><summary>Lời giải và đáp án</summary>
            <ol>${buocGiai(it).map((b) => `<li>${tex(b.viec)}`
              + (b.canCu ? `<span class="can-cu">${tex(b.canCu)}</span>` : '')
              + '</li>').join('')}</ol>
            <p><b>Đáp án:</b> ${tex(it.answer)}</p>
          </details>
          <div class="row"><button class="primary" onclick="App.publish('${esc(it.id)}')">Duyệt phát hành</button></div>
        </div>`).join('')
      : '<div class="muted">Không có bài nào chờ duyệt.</div>';

    if (forms.ok) {
      $('genForm').innerHTML = (forms.items || forms.forms || [])
        .map((f) => `<option value="${esc(f.code)}">${esc(f.name)}</option>`).join('');
    }
  }

  async function publish(itemId) {
    const r = await api(`/bank/items/${encodeURIComponent(itemId)}/publish`, { by: S.user.id });
    toast(r.ok ? 'Đã phát hành.' : (r.error || 'Không phát hành được'), r.ok ? 'ok' : 'err');
    if (r.ok) await loadContent();
  }

  async function generate() {
    const r = await api('/authoring/generate', {
      formCode: $('genForm').value, level: Number($('genLevel').value),
      count: Number($('genCount').value), dryRun: true, authorId: S.user.id,
    });
    if (!r.ok) { $('genBox').innerHTML = `<div class="err">${esc(r.hint || r.error)}</div>`; return; }
    $('genBox').innerHTML = `
      <p class="muted">${esc(r.note)} Dùng ${r.blueprintsUsed}/${r.blueprintsAvailable} ý đồ sư phạm.</p>
      ${(r.items || []).map((it) => `<div class="item-card">
        <div class="meta"><span class="tag">${esc(it.blueprintId)}</span><span class="stars">${stars(it.stars)}</span></div>
        <p class="muted">${esc(it.intent)}</p>
        <div class="stem">${tex(it.stem)}</div>
        <details><summary>Lời giải</summary><ol>${buocGiai(it).map((b) => `<li>${tex(b.viec)}`
          + (b.canCu ? `<span class="can-cu">${tex(b.canCu)}</span>` : '')
          + '</li>').join('')}</ol></details>
        <p class="muted">Máy đã tự kiểm: ${esc(it.verification?.reason || '')}</p>
      </div>`).join('')}
      ${(r.rejections || []).length ? `<details><summary>${r.rejections.length} bản nháp bị loại</summary><ul>${r.rejections.map((x) => `<li>${esc(x.blueprint)}: ${esc(x.reason)}</li>`).join('')}</ul></details>` : ''}`;
  }

  // ── Báo cáo ──────────────────────────────────────────────────────────────

  async function loadReport() {
    if (!S.classId) { $('repSummary').innerHTML = '<div class="muted">Chưa chọn lớp.</div>'; return; }
    const days = Number($('repDays')?.value) || 30;
    const r = await api(`/reports/class/${encodeURIComponent(S.classId)}?days=${days}`);
    if (!r.ok) { $('repSummary').innerHTML = `<div class="err">${esc(r.error)}</div>`; return; }
    const exp = $('repExport');
    if (exp) exp.href = `/reports/export/class?id=${encodeURIComponent(S.classId)}&days=${days}`;

    $('repCards').innerHTML = [
      cardOf('Sĩ số', String(r.class.size), `${r.participation.active} em có học`),
      cardOf('Chưa học buổi nào', String(r.participation.inactive), 'cần liên hệ trước', r.participation.inactive ? 'err' : 'ok'),
      cardOf('Trung vị đúng', r.performance.median == null ? '—' : pct(r.performance.median, 0),
        r.performance.measurable ? `trên ${r.performance.measurable} em đủ số bài` : 'chưa đủ dữ liệu'),
      cardOf('Độ phân hoá', r.performance.spread == null ? '—' : `${Math.round(r.performance.spread * 100)} điểm%`,
        'khoảng giữa nhóm khá và nhóm yếu'),
    ].join('');

    $('repSummary').innerHTML = `<p>${esc(r.summary)}</p>`
      + (r.performance.note ? `<p class="warn">${esc(r.performance.note)}</p>` : '');

    $('repAttention').innerHTML = table(r.needAttention, [
      { label: 'Học viên', html: true, get: (x) => `<button class="ghost" onclick="App.openLearner('${esc(x.id)}')">${esc(x.fullName)}</button>` },
      { label: 'Số bài', cls: 'num', get: (x) => x.items },
      { label: 'Tỉ lệ đúng', get: (x) => (x.accuracy == null ? 'chưa có' : pct(x.accuracy, 0)) },
      { label: 'Xu hướng', get: (x) => x.trend },
      { label: 'Cảnh báo', cls: 'num', get: (x) => x.alerts },
    ], 'Không em nào cần chú ý đặc biệt.');

    $('repWeak').innerHTML = table(r.classWideWeakForms, [
      { label: 'Dạng', get: (x) => x.name },
      { label: 'Số em', cls: 'num', get: (x) => x.learners },
      { label: 'Tổng bài', cls: 'num', get: (x) => x.items },
      { label: 'Tỉ lệ đúng', html: true, get: (x) => `${bar(x.accuracy, 'err')} ${pct(x.accuracy, 0)}` },
    ], 'Không có dạng nào cả lớp cùng yếu.');

    $('repAll').innerHTML = table(r.learners, [
      { label: 'Họ tên', get: (x) => x.fullName },
      { label: 'Tầng', get: (x) => `L${x.level}` },
      { label: 'Số bài', cls: 'num', get: (x) => x.items },
      { label: 'Ngày học', cls: 'num', get: (x) => x.activeDays },
      { label: 'Tỉ lệ đúng', html: true, get: (x) => (x.accuracy == null ? '<span class="muted">chưa có</span>' : `${bar(x.accuracy, x.accuracy >= 0.8 ? 'ok' : x.accuracy >= 0.5 ? 'warn' : 'err')} ${pct(x.accuracy, 0)}`) },
      { label: 'Dạng đã thạo', cls: 'num', get: (x) => x.mastered },
    ]);
  }

  // ── Nhập danh sách ───────────────────────────────────────────────────────

  async function importCsv(dryRun) {
    const csv = $('csvBox').value;
    if (!csv.trim()) return toast('Dán nội dung tệp vào đã.', 'err');
    const r = await api('/io/import-learners', {
      csv, classId: S.classId, dryRun, allowUpdate: $('allowUpdate').checked, by: S.user.id,
    });
    if (!r.ok) { $('importBox').innerHTML = `<div class="err">${esc(r.error)}${r.need ? ` — thiếu cột "${esc(r.need)}"` : ''}</div>`; return; }
    $('importBox').innerHTML = `
      <p class="${r.rejected ? 'warn' : ''}"><b>${esc(r.summary)}</b></p>
      <div class="cards">
        ${cardOf('Nhận được', vn(r.accepted), `trên ${r.totalRows} dòng`, r.accepted ? 'ok' : '')}
        ${cardOf('Phải sửa', vn(r.rejected), r.rejected ? 'xem chi tiết bên dưới' : 'không có', r.rejected ? 'err' : '')}
        ${cardOf('Cảnh báo', vn(r.warnings), 'đã bỏ qua phần không hợp lệ')}
      </div>
      ${r.problems?.length ? `<h3>Dòng cần sửa</h3>${table(r.problems, [
      { label: 'Dòng', cls: 'num', get: (x) => x.line },
      { label: 'Họ tên', get: (x) => x.fullName },
      { label: 'Lý do', get: (x) => x.reason },
    ])}` : ''}
      ${r.preview?.length ? `<h3>Xem trước</h3>${table(r.preview, [
      { label: 'Dòng', cls: 'num', get: (x) => x.line },
      { label: 'Kiểu', get: (x) => x.mode },
      { label: 'Mã', get: (x) => x.id },
      { label: 'Họ tên', get: (x) => x.fullName },
      { label: 'Lớp', cls: 'num', get: (x) => x.grade },
    ])}` : ''}`;
    if (!dryRun && r.written) await loadClass();
  }

  // ── Khởi động ────────────────────────────────────────────────────────────

  document.addEventListener('DOMContentLoaded', async () => {
    // Dò xem máy này có cảm biến sinh trắc học không, rồi mới hiện nút.
    doKhuonMat();
    document.querySelectorAll('#nav a').forEach((a) => a.addEventListener('click', () => setTab(a.dataset.tab)));
    $('lPass')?.addEventListener('keydown', (e) => { if (e.key === 'Enter') login(); });
    const u = G.getUser();
    if (u && G.getToken()) await enter(u);
  });

  return {
    login, logout, setTab, refresh, vaoBangKhuonMat, doKhuonMat,
    pickClass, autoGroup, openLearner, pickLearner, loadLearner, promote,
    publish, generate, importCsv, loadReport,
  };
})();
