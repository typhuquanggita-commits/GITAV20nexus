'use strict';
/**
 * Lớp mỏng nói chuyện với tầng Cloudflare.
 *
 * Tầng ấy trả về {dat, ma, loi} chứ không phải {ok} như máy chủ Node,
 * nên cần một bộ chuyển riêng. Viết ở đây một lần để hai trang CRM và
 * kế toán không mỗi trang một kiểu bắt lỗi.
 */
(function (G) {
  const KHOA_THE = 'gita_the_cf';

  function layThe() {
    try { return localStorage.getItem(KHOA_THE) || ''; } catch (e) { return ''; }
  }
  function datThe(t) {
    try { if (t) localStorage.setItem(KHOA_THE, t); else localStorage.removeItem(KHOA_THE); }
    catch (e) { /* trình duyệt chặn kho cục bộ thì vẫn chạy được trong một phiên */ }
  }

  async function goi(duong, than, cach) {
    const o = { method: cach || (than ? 'POST' : 'GET'), headers: {} };
    if (than !== undefined && than !== null) {
      o.headers['content-type'] = 'application/json';
      o.body = JSON.stringify(than);
    }
    const t = layThe();
    if (t) o.headers.authorization = 'Bearer ' + t;
    let r, chu;
    try {
      r = await fetch(duong, o);
      chu = await r.text();
    } catch (e) {
      return { dat: false, ma: 'khong-ket-noi',
        loi: 'Không gọi được máy chủ: ' + e.message };
    }
    let d;
    try { d = JSON.parse(chu); } catch (e) {
      return { dat: false, ma: 'tra-loi-khong-phai-json',
        loi: 'Máy chủ trả về thứ không đọc được (' + r.status + ').' };
    }
    d._ma = r.status;
    return d;
  }

  /** Gọi rồi báo lỗi lên màn hình nếu hỏng. Trả về null khi hỏng. */
  async function can(duong, viec, than, cach) {
    const d = await goi(duong, than, cach);
    if (d && d.dat !== false) return d;
    bao((viec ? viec + ': ' : '') + ((d && d.loi) || 'không tải được'), 'loi');
    return null;
  }

  function bao(chu, kieu) {
    let o = document.getElementById('bao-loi');
    if (!o) {
      o = document.createElement('div');
      o.id = 'bao-loi';
      o.style.cssText = 'position:fixed;left:50%;transform:translateX(-50%);bottom:22px;z-index:99;'
        + 'max-width:min(680px,92vw);display:grid;gap:8px';
      document.body.appendChild(o);
    }
    const d = document.createElement('div');
    d.style.cssText = 'padding:12px 16px;border-radius:12px;font-size:13.5px;line-height:1.5;'
      + 'box-shadow:0 10px 30px rgba(0,0,0,.28);border:1px solid;'
      + (kieu === 'loi'
        ? 'background:#3b1418;border-color:#b3453f;color:#ffd9d4'
        : kieu === 'dat'
          ? 'background:#0f2a1c;border-color:#2f7a52;color:#c8f2da'
          : 'background:#1d2433;border-color:#3b485f;color:#dfe6f3');
    d.textContent = chu;
    o.appendChild(d);
    setTimeout(() => d.remove(), kieu === 'loi' ? 9000 : 4500);
  }

  const thoat = (s) => String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');

  const tien = (n) => Number(n || 0).toLocaleString('vi-VN') + ' ₫';
  const soVn = (n) => Number(n || 0).toLocaleString('vi-VN');
  const luc = (ms) => (ms ? new Date(Number(ms)).toLocaleString('vi-VN') : '—');

  function bang(cot, hang, trong) {
    if (!hang.length) {
      return '<p class="rong">' + thoat(trong || 'Chưa có dữ liệu nào.') + '</p>';
    }
    return '<div class="cuon"><table><thead><tr>'
      + cot.map((c) => '<th>' + thoat(c) + '</th>').join('')
      + '</tr></thead><tbody>'
      + hang.map((h) => '<tr>' + h.map((o) => '<td>' + o + '</td>').join('') + '</tr>').join('')
      + '</tbody></table></div>';
  }

  G.CF = { goi, can, bao, thoat, tien, soVn, luc, bang, layThe, datThe, KHOA_THE };
})(typeof window !== 'undefined' ? window : globalThis);
