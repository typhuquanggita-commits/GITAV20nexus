'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BÀI GIẢNG — một lệnh, ra một tệp video có tiếng
 * ═══════════════════════════════════════════════════════════════════════════
 *  Đây là chỗ bốn phần rời nhau được nối thành một đường: học liệu → khung
 *  hình → giọng đọc → tệp video.
 *
 *  Ba nguồn nội dung, xếp theo độ tin cậy giảm dần:
 *
 *   1. TỪ KHO HỌC LIỆU (mặc định, không cần mạng) — lấy đúng dạng bài trong
 *      chương trình: tên dạng, tầng, điều kiện tiên quyết, bẫy thường gặp,
 *      và các bài đã qua thẩm định toán học với lời giải từng bước. Đây là
 *      nội dung ĐÃ ĐƯỢC KIỂM, không phải mô hình bịa ra.
 *   2. TỪ KỊCH BẢN NGƯỜI DÙNG — ai có sẵn bài soạn thì đưa thẳng vào.
 *   3. TỪ MÔ HÌNH NGÔN NGỮ — chỉ khi có khoá, và ghi rõ trong siêu dữ liệu
 *      rằng nội dung do mô hình viết, cần người duyệt trước khi dạy.
 *
 *  Không có nguồn nào thì hệ thống nói thẳng, chứ không sinh bừa một bài
 *  giảng rỗng để có cái chạy.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const path = require('node:path');
const fs = require('node:fs');

const cfg = require('../config');
const { id: newId, round } = require('../utils');
const { FORM_INDEX, LEVELS } = require('../curriculum/hierarchy');
const { khungTieuDe, khungNoiDung, khungKet } = require('./slide');
const { ghiAVI } = require('../film/avi');
const { ghiJPEG } = require('../photo/jpeg');
const { ghiPNG } = require('../photo/png');
const { fromWav } = require('../voice/synth');
const { chuanHoa, kiemKyHieu } = require('../math/kyhieu');
const { thamDinh } = require('../math/thamdinh');
const { kiemVanPhong } = require('../math/vanphong');
const { soatChinhTa } = require('../lang/chinhta');
const { hopVoiLop } = require('../lang/docde');

/** Độ phân giải khung hình. */
const KHO = {
  hd: { rong: 1280, cao: 720, fps: 10 },
  'full-hd': { rong: 1920, cao: 1080, fps: 10 },
  nhap: { rong: 854, cao: 480, fps: 8 },
};

/**
 * Bỏ dấu tiếng Việt và tách thành từ. Dùng để khớp chủ đề người dùng gõ với
 * tên dạng bài trong chương trình: người ta gõ "pytago" hay "phương trình bậc
 * hai" chứ không gõ mã "M9.PT2.GIAI".
 */
function _tach(s) {
  return String(s || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/gi, 'd')
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter((t) => t.length > 1 && !TU_DEM.has(t));
}

/** Từ nối không mang nghĩa — đếm chúng vào là mọi dạng bài đều "khớp". */
const TU_DEM = new Set(['va', 'cua', 'cho', 'voi', 'trong', 'cac', 'nhung', 'mot', 'la', 'de', 'khi', 'bai', 'day', 'hoc', 'giang']);

/**
 * Đưa một dàn ý về đúng chuẩn ký hiệu toán trước khi đem dựng.
 *
 * Học liệu trong kho lưu ở dạng LaTeX (điều A02 Hiến pháp bắt buộc), còn
 * khung hình video là ảnh điểm ảnh — không dựng được LaTeX. Nếu bê thẳng
 * "\dfrac{-b+\sqrt{\Delta}}{2a}" lên màn hình thì học sinh đọc được một mớ
 * dấu gạch chéo ngược. Ở đây mọi chữ hiện lên màn hình đều được đổi sang ký
 * hiệu toán quốc tế dạng Unicode phẳng: (−b + √∆)⁄(2a).
 *
 * Lời giảng KHÔNG đổi ở đây: bộ đọc giọng nói tự bắc cầu sang LaTeX rồi đọc
 * thành lời (xem src/voice/speech-text.js). Đổi hai lần là đọc sai.
 */
function chuanHoaDanY(dan) {
  const chuY = (x) => (typeof x === 'string' ? chuanHoa(x)
    : x && typeof x === 'object' && x.chu ? { ...x, chu: chuanHoa(x.chu) } : x);
  const doan = dan.doan.map((d) => ({
    ...d,
    tieuDe: d.tieuDe ? chuanHoa(d.tieuDe) : d.tieuDe,
    phuDe: d.phuDe ? chuanHoa(d.phuDe) : d.phuDe,
    cauChot: d.cauChot ? chuanHoa(d.cauChot) : d.cauChot,
    ghiChu: d.ghiChu ? chuanHoa(d.ghiChu) : d.ghiChu,
    congThuc: d.congThuc ? chuanHoa(d.congThuc) : d.congThuc,
    cacY: d.cacY ? d.cacY.map(chuY) : d.cacY,
  }));
  return { ...dan, tieuDe: chuanHoa(dan.tieuDe), doan };
}

/**
 * Gom chữ của dàn ý, TÁCH LÀM HAI đường vì hai đường soi hai chuẩn khác nhau:
 *  · manHinh — chữ hiện lên khung hình, phải đúng chuẩn ký hiệu Unicode.
 *  · loiDoc  — lời giảng, vẫn giữ LaTeX vì bộ đọc giọng nói đọc LaTeX chuẩn
 *    hơn; soi ký hiệu ở đây là bắt lỗi oan.
 * Cả hai đều phải sạch về văn phong: học sinh vừa đọc vừa nghe.
 */
function govanBan(dan) {
  const manHinh = [];
  const loiDoc = [];
  for (const x of dan.doan) {
    if (x.tieuDe) manHinh.push(x.tieuDe);
    if (x.phuDe) manHinh.push(x.phuDe);
    for (const y of x.cacY || []) manHinh.push(typeof y === 'string' ? y : y.chu);
    if (x.congThuc) manHinh.push(x.congThuc);
    if (x.ghiChu) manHinh.push(x.ghiChu);
    if (x.cauChot) manHinh.push(x.cauChot);
    if (x.loiGiang) loiDoc.push(x.loiGiang);
  }
  return { manHinh: manHinh.filter(Boolean).join('\n'), loiDoc: loiDoc.filter(Boolean).join('\n') };
}

class BaiGiangPipeline {
  /**
   * @param {object} o {bank, voice, photo, llm, db, bus}
   */
  constructor({ bank, voice, photo = null, llm = null, db = null, bus = null } = {}) {
    this.bank = bank;
    this.voice = voice;
    this.photo = photo;
    this.llm = llm;
    this.bus = bus;
    this.repo = db ? db.collection('lessons', { indexes: ['nguon'] }) : null;
    this.baiGiang = new Map();
    if (this.repo) for (const d of this.repo.all()) this.baiGiang.set(d.id, d);
    this.stats = { dung: 0, hong: 0, khung: 0, giayTieng: 0, msTong: 0 };
  }

  /**
   * Khớp chủ đề gõ tự do → dạng bài trong chương trình.
   * Chấm theo tỉ lệ từ khoá của chủ đề xuất hiện trong tên dạng, cộng điểm
   * khi khớp nguyên cụm và khi gõ thẳng mã dạng. Hoàn toàn tất định: cùng một
   * chuỗi vào luôn cho cùng một kết quả ra, không bốc thăm, không gọi mô hình.
   */
  timDang(chuDe, { soGoiY = 5 } = {}) {
    const q = String(chuDe || '').trim();
    const tuQ = _tach(q);
    const chuanQ = tuQ.join(' ');
    const diem = [];

    for (const f of FORM_INDEX.values()) {
      const tuF = _tach(f.name);
      // Mã dạng cũng là từ khoá: "M8.PYTAGO.UNGDUNG" cho phép gõ "pytago" —
      // cách viết tắt mà giáo viên dùng hằng ngày nhưng không có trong tên dạng.
      const tuMa = _tach(f.code.replace(/\./g, ' '));
      const chuanF = tuF.join(' ');
      let d = 0;

      // Gõ thẳng mã dạng là ý định rõ ràng nhất.
      if (f.code.toLowerCase() === q.toLowerCase()) d = 100;
      else if (chuanF === chuanQ) d = 95;
      else {
        // Khớp mềm: "pytago" phải tìm ra "Pythagore", "luong giac" phải tìm
        // ra "lượng giác". Chỉ nới cho từ dài từ 4 ký tự trở lên, để "hai"
        // không kéo theo "hai mươi" rồi khớp lung tung.
        const hop = (a, b) => a === b || (a.length >= 4 && b.length >= 4 && (a.startsWith(b.slice(0, 4)) || b.startsWith(a.slice(0, 4))));
        const chung = tuQ.filter((t) => tuF.some((u) => hop(t, u)) || tuMa.some((u) => hop(t, u))).length;
        if (!chung) continue;
        // Phải phủ được cả hai phía: chủ đề "số" không được khớp 100% vào
        // "Đếm, đọc, viết số trong phạm vi 20" chỉ vì có đúng một từ.
        const chungF = tuF.filter((u) => tuQ.some((t) => hop(t, u))).length;
        const phuQ = chung / tuQ.length;
        const phuF = chungF / tuF.length;
        d = Math.round((phuQ * 0.6 + phuF * 0.4) * 90);
        if (chuanF.includes(chuanQ) || chuanQ.includes(chuanF)) d += 8;
      }
      if (d > 0) diem.push({ ma: f.code, ten: f.name, diem: Math.min(100, d), tang: f.levelRange });
    }

    // Sắp xếp phụ theo mã để hai dạng cùng điểm luôn ra cùng thứ tự.
    diem.sort((a, b) => b.diem - a.diem || a.ma.localeCompare(b.ma));
    const goiY = diem.slice(0, soGoiY);
    // Ngưỡng 45: dưới mức này là khớp vu vơ, thà nói "không tìm thấy" còn hơn
    // dựng nhầm một bài giảng khác hẳn thứ người ta hỏi.
    const khop = goiY.length && goiY[0].diem >= 45 ? goiY[0] : null;
    return { khop, goiY, tongDang: FORM_INDEX.size };
  }

  /** ── NGUỒN 1: từ kho học liệu (không cần mạng, nội dung đã thẩm định) ── */
  soanTuKho(maDang, { soBaiMau = 2 } = {}) {
    const form = FORM_INDEX.get(maDang);
    if (!form) {
      return { ok: false, error: 'KHÔNG_CÓ_DẠNG_BÀI', maDang,
        goi: `Xem danh sách dạng ở GET /curriculum/forms (${FORM_INDEX.size} dạng).` };
    }
    if (!this.bank) return { ok: false, error: 'CHƯA_GẮN_KHO_HỌC_LIỆU' };

    const bai = this.bank.query({ formCode: maDang, limit: Math.max(1, soBaiMau) });
    const tang = form.levelRange ? `Tầng ${form.levelRange[0]}–${form.levelRange[1]}` : '';
    const tenTang = form.levelRange && LEVELS[form.levelRange[0]] ? LEVELS[form.levelRange[0]].name : '';

    const doan = [];
    doan.push({
      loai: 'tieu-de',
      tieuDe: form.name,
      phuDe: `${tang}${tenTang ? ` · ${tenTang}` : ''} · Mã dạng ${form.code}`,
      loiGiang: `Bài giảng dạng ${form.name}. ${tang ? `Dạng này nằm ở ${tang.toLowerCase()}.` : ''}`,
    });

    if (form.prereq && form.prereq.length) {
      const ten = form.prereq.map((c) => FORM_INDEX.get(c)?.name || c);
      doan.push({
        loai: 'noi-dung',
        tieuDe: 'Cần nắm trước',
        cacY: ten.map((t) => `${t}`),
        loiGiang: `Trước khi vào dạng này, em cần nắm chắc: ${ten.join('; ')}.`,
      });
    }

    if (form.traps && form.traps.length) {
      doan.push({
        loai: 'noi-dung',
        tieuDe: 'Bẫy hay mắc',
        cacY: form.traps.map((t) => ({ chu: t, mau: [255, 122, 122] })),
        loiGiang: `Dạng này có ${form.traps.length} chỗ hay sai: ${form.traps.join('; ')}. Em nhớ kỹ.`,
      });
    }

    bai.forEach((b, i) => {
      doan.push({
        loai: 'noi-dung',
        tieuDe: `Bài mẫu ${i + 1}`,
        cacY: [b.stem],
        congThuc: null,
        ghiChu: `${b.stars}★ · thời gian chuẩn ${b.normSeconds || form.norm} giây`,
        loiGiang: `Bài mẫu ${i + 1}. ${b.stem}`,
      });
      (b.solutionSteps || []).forEach((s, j) => {
        doan.push({
          loai: 'noi-dung',
          tieuDe: `Bài mẫu ${i + 1} — bước ${j + 1}`,
          cacY: [s],
          loiGiang: `Bước ${j + 1}. ${s}`,
        });
      });
      if (b.answer) {
        doan.push({
          loai: 'noi-dung',
          tieuDe: `Bài mẫu ${i + 1} — đáp án`,
          cacY: [{ chu: String(b.answer), mau: [110, 231, 168] }],
          loiGiang: `Đáp án: ${b.answer}.`,
        });
      }
    });

    doan.push({
      loai: 'ket',
      cauChot: form.traps && form.traps.length
        ? `Nhớ kỹ: ${form.traps[0]}.`
        : `Luyện thêm dạng ${form.code} để thành thạo.`,
      loiGiang: form.traps && form.traps.length
        ? `Điều cần nhớ nhất: ${form.traps[0]}. Em luyện thêm cho quen tay.`
        : `Em luyện thêm dạng này cho thành thạo.`,
    });

    return {
      ok: true,
      nguon: 'kho-hoc-lieu',
      tieuDe: form.name,
      maDang: form.code,
      doan,
      soBaiMau: bai.length,
      daThamDinh: true,
      canDuyet: false,
      luuY: bai.length ? null : 'Kho chưa có bài mẫu nào cho dạng này — bài giảng chỉ có phần lý thuyết.',
    };
  }

  /** ── NGUỒN 2: từ kịch bản người dùng ──────────────────────────────────── */
  soanTuKichBan(text, { tieuDe = null } = {}) {
    const raw = String(text || '').trim();
    if (!raw) return { ok: false, error: 'KỊCH_BẢN_RỖNG' };

    // Mỗi khối cách nhau một dòng trống; dòng đầu của khối là đầu đề nếu
    // nó ngắn và không kết thúc bằng dấu câu.
    const khoi = raw.split(/\n\s*\n/).map((k) => k.trim()).filter(Boolean);
    if (!khoi.length) return { ok: false, error: 'KỊCH_BẢN_RỖNG' };

    const doan = [{
      loai: 'tieu-de',
      tieuDe: tieuDe || khoi[0].split('\n')[0].slice(0, 90),
      phuDe: 'Bài giảng soạn tay',
      loiGiang: tieuDe || khoi[0].split('\n')[0],
    }];

    for (const k of khoi) {
      const dong = k.split('\n').map((d) => d.trim()).filter(Boolean);
      const daiDau = dong[0].length;
      const coDauDe = dong.length > 1 && daiDau < 70 && !/[.!?…]$/.test(dong[0]);
      const dauDe = coDauDe ? dong[0] : '';
      const than = coDauDe ? dong.slice(1) : dong;
      doan.push({
        loai: 'noi-dung',
        tieuDe: dauDe,
        cacY: than,
        loiGiang: [dauDe, ...than].filter(Boolean).join(' '),
      });
    }

    doan.push({ loai: 'ket', cauChot: 'Hết bài.', loiGiang: 'Hết bài. Cảm ơn em đã theo dõi.' });
    return { ok: true, nguon: 'kich-ban-nguoi-dung', tieuDe: doan[0].tieuDe, doan, daThamDinh: false, canDuyet: false };
  }

  /** ── NGUỒN 3: mô hình ngôn ngữ (cần khoá) ─────────────────────────────── */
  async soanBangMoHinh(chuDe, { soDoan = 5 } = {}) {
    if (!this.llm) return { ok: false, error: 'CHƯA_GẮN_MÔ_HÌNH_NGÔN_NGỮ' };
    const co = this.llm.available().filter((p) => p !== 'mock');
    if (!co.length) {
      return {
        ok: false, error: 'CHƯA_CÓ_KHOÁ_MÔ_HÌNH',
        goi: 'Đặt GROQ_API_KEY (miễn phí tại console.groq.com/keys), hoặc dùng --dang để soạn từ kho học liệu đã thẩm định.',
      };
    }

    const prompt = `Soạn dàn ý bài giảng tiếng Việt về: "${chuDe}".
Trả về JSON thuần, không markdown:
{"tieuDe":"...","doan":[{"tieuDe":"...","y":["ý 1","ý 2"],"loiGiang":"lời giảng 25-45 từ, tự nhiên"}]}
Yêu cầu: ${soDoan} đoạn, mỗi đoạn 2-3 ý ngắn, lời giảng đọc lên nghe tự nhiên.`;

    const r = await this.llm.call({ task: 'vietnamese', prompt, maxTokens: 2000, temperature: 0.6 });
    if (!r.ok) return { ok: false, error: 'MÔ_HÌNH_KHÔNG_TRẢ_LỜI', chiTiet: r.error };

    try {
      const sach = String(r.text).replace(/```json|```/g, '').trim();
      const d = JSON.parse(sach);
      if (!d.doan || !d.doan.length) throw new Error('không có đoạn nào');
      const doan = [{ loai: 'tieu-de', tieuDe: d.tieuDe || chuDe, phuDe: 'Nội dung do mô hình soạn — cần người duyệt', loiGiang: d.tieuDe || chuDe }];
      for (const x of d.doan) {
        doan.push({ loai: 'noi-dung', tieuDe: x.tieuDe || '', cacY: x.y || [], loiGiang: x.loiGiang || x.tieuDe || '' });
      }
      doan.push({ loai: 'ket', cauChot: 'Hết bài.', loiGiang: 'Hết bài.' });
      return {
        ok: true, nguon: `mo-hinh:${r.provider}`, tieuDe: d.tieuDe || chuDe, doan,
        daThamDinh: false, canDuyet: true,
        luuY: 'Nội dung do mô hình ngôn ngữ viết. PHẢI có người duyệt trước khi đem dạy.',
      };
    } catch (e) {
      return { ok: false, error: 'MÔ_HÌNH_TRẢ_VỀ_KHÔNG_ĐỌC_ĐƯỢC', chiTiet: e.message };
    }
  }

  /** ── DỰNG: khung hình + giọng đọc + tệp video ─────────────────────────── */
  async dung(dan, {
    kho = cfg.BAIGIANG.kho, giongId = null, agentId = null, chatLuongJpeg = cfg.BAIGIANG.chatLuongJpeg,
    thuMuc = null, luuKhung = false, learnerId = null,
  } = {}) {
    if (!dan || !dan.ok) return dan || { ok: false, error: 'THIẾU_DÀN_Ý' };
    const t0 = Date.now();

    // ── Cửa ký hiệu: không một khung hình nào được mang ký hiệu sai ──
    dan = chuanHoaDanY(dan);
    const chu = govanBan(dan);
    const soat = thamDinh(chu.manHinh, { loai: 'tu-do' });
    const soatLoi = kiemVanPhong(chu.loiDoc, { loai: 'tu-do' });

    // ── Cửa ngôn ngữ: chữ đúng chính tả, và câu vừa sức lớp học ──
    // Lớp suy ra từ mã dạng (M3.… là lớp 3). Không biết lớp thì bỏ qua phép
    // đo độ đọc chứ không đoán bừa một ngưỡng.
    const lop = Number((String(dan.maDang || '').match(/^M(\d+)/) || [])[1]) || null;
    const soatChu = soatChinhTa(`${chu.manHinh}\n${chu.loiDoc}`);
    const soatDoc = lop ? hopVoiLop(chu.loiDoc, lop) : null;
    if (!soat.cap1KyHieu.ok) {
      // Đã chuẩn hoá rồi mà vẫn còn ký hiệu viết theo lối máy nghĩa là nguồn
      // nội dung hỏng ở chỗ máy chuẩn hoá không chạm tới được. Dựng tiếp là
      // đem cái sai lên màn hình cho học sinh chép, nên dừng ở đây.
      return {
        ok: false, error: 'KÝ_HIỆU_TOÁN_KHÔNG_ĐẠT',
        loi: soat.cap1KyHieu.loi,
        goi: 'Sửa nguồn nội dung theo cột "cách sửa", hoặc viết công thức bằng LaTeX ($\\dfrac{a}{b}$) để hệ thống tự dựng.',
      };
    }
    const K = KHO[kho] || KHO.hd;
    const tong = dan.doan.length;

    // 1) Giọng đọc từng đoạn — đây là thứ quyết định thời lượng mỗi khung.
    const tieng = [];
    for (let i = 0; i < tong; i++) {
      const d = dan.doan[i];
      const loi = String(d.loiGiang || d.tieuDe || '').trim();
      if (!loi) { tieng.push({ ok: false, giay: 2.0, ly: 'KHÔNG_CÓ_LỜI' }); continue; }
      const r = await this.voice.speak(loi, {
        voiceId: giongId, agentId, learnerId,
        purpose: 'giang-bai', audible: false, useCache: true,
      });
      if (!r.ok) { tieng.push({ ok: false, giay: 2.5, ly: r.error }); continue; }
      const pcm = fromWav(r.wav);
      tieng.push({ ok: true, wav: r.wav, pcm: pcm ? pcm.samples : null, sr: pcm ? pcm.sampleRate : 22050, giay: r.ms / 1000, voiceId: r.voiceId });
    }

    // 2) Khung hình — mỗi đoạn một khung, lặp đủ số khung cho hết lời đọc.
    const khungAnh = [];
    const khungJPEG = [];
    const mocThoiGian = [];
    let giayTich = 0;

    for (let i = 0; i < tong; i++) {
      const d = dan.doan[i];
      const t = tieng[i];
      const giay = Math.max(1.2, t.giay + 0.45);          // chừa khoảng thở cuối đoạn
      const soKhung = Math.max(1, Math.round(giay * K.fps));

      let anh;
      if (d.loai === 'tieu-de') {
        anh = khungTieuDe({ rong: K.rong, cao: K.cao, tieuDe: d.tieuDe, phuDe: d.phuDe || '' });
      } else if (d.loai === 'ket') {
        anh = khungKet({ rong: K.rong, cao: K.cao, cauChot: d.cauChot || 'Hết bài.' });
      } else {
        anh = khungNoiDung({
          rong: K.rong, cao: K.cao,
          tieuDe: d.tieuDe || '', cacY: d.cacY || [], congThuc: d.congThuc || null, ghiChu: d.ghiChu || null,
          tieuDeNho: dan.tieuDe, trang: i + 1, tongTrang: tong, tienDo: (i + 1) / tong,
        });
      }

      // Nén MỘT lần rồi dùng lại cho mọi khung của đoạn: khung tĩnh thì nén
      // lại y hệt nhau là phí, mà thời gian nén JPEG chiếm phần lớn khâu dựng.
      const jp = ghiJPEG(anh, { chatLuong: chatLuongJpeg });
      for (let k = 0; k < soKhung; k++) khungJPEG.push(jp);
      khungAnh.push({ doan: i + 1, anh, soKhung, byteJPEG: jp.length });

      mocThoiGian.push({
        doan: i + 1, loai: d.loai, tieuDe: d.tieuDe || d.cauChot || '',
        batDau: round(giayTich, 2), giay: round(giay, 2), soKhung,
        coTieng: t.ok, giongNoi: t.voiceId || null,
      });
      giayTich += giay;
      this.stats.khung += soKhung;
    }

    // 3) Đường tiếng: ghép theo đúng mốc, chừa khoảng lặng cho khớp khung.
    const sr = tieng.find((t) => t.ok)?.sr || 22050;
    const tongMau = Math.ceil(giayTich * sr);
    const track = new Float32Array(tongMau);
    mocThoiGian.forEach((m, i) => {
      const t = tieng[i];
      if (!t.ok || !t.pcm) return;
      const at = Math.round(m.batDau * sr);
      const n = Math.min(t.pcm.length, track.length - at);
      for (let j = 0; j < n; j++) track[at + j] += t.pcm[j];
    });

    // 4) Tệp video
    const video = ghiAVI({ khungJPEG, tieng: track, fps: K.fps, rong: K.rong, cao: K.cao, tanSo: sr });
    if (!video.ok) { this.stats.hong++; return video; }

    const ms = Date.now() - t0;
    this.stats.dung++;
    this.stats.giayTieng += giayTich;
    this.stats.msTong += ms;

    const bg = {
      id: newId('BG'),
      taoLuc: Date.now(),
      tieuDe: dan.tieuDe,
      nguon: dan.nguon,
      maDang: dan.maDang || null,
      daThamDinh: !!dan.daThamDinh,
      canDuyet: !!dan.canDuyet,
      luuY: dan.luuY || null,
      kho, rong: K.rong, cao: K.cao, fps: K.fps,
      soDoan: tong,
      soKhung: khungJPEG.length,
      giay: round(giayTich, 2),
      byte: video.byte,
      mocThoiGian,
      tiengHong: tieng.filter((t) => !t.ok).length,
      thamDinh: {
        dat: soat.dat && soatLoi.ok && soatChu.ok,
        diem: Math.min(soat.diem, soatLoi.diem, soatChu.diem, soatDoc ? soatDoc.diem : 100),
        xep: soat.xep,
        tomTat: `${soat.tomTat} · Lời giảng: ${soatLoi.ok ? 'đạt' : `${soatLoi.soLoi} lỗi`}`
          + ` · Chính tả: ${soatChu.ok ? 'đạt' : `${soatChu.soLoi} lỗi`}`
          + (soatDoc ? ` · Độ đọc lớp ${lop}: ${soatDoc.ok ? 'vừa sức' : 'quá sức'} (${soatDoc.doDo.tiengMoiCau} tiếng/câu)` : '')
          + ` · Đáp số: ${dan.daThamDinh ? 'lấy từ kho đã qua bộ xác minh toán học' : 'CHƯA có người kiểm'}`,
        canSua: [
          ...soat.cap1KyHieu.loi,
          ...soat.cap2VanPhong.loi.filter((l) => l.muc === 'LOI'),
          ...soatLoi.loi.filter((l) => l.muc === 'LOI'),
          ...soatChu.loi.filter((l) => l.muc === 'LOI'),
          ...(soatDoc ? soatDoc.loi.filter((l) => l.muc === 'LOI') : []),
        ],
        ngonNgu: {
          chinhTa: { dat: soatChu.ok, soLoi: soatChu.soLoi, soNhac: soatChu.soCanhBao },
          doDoc: soatDoc ? { lop, vuaSuc: soatDoc.ok, tiengMoiCau: soatDoc.doDo.tiengMoiCau, tran: soatDoc.nguong.toiDa } : null,
        },
      },
      ms,
    };
    this._luu(bg);
    this.bus?.safeEmit?.('lesson:built', { id: bg.id, giay: bg.giay, byte: bg.byte });

    // 5) Ghi ra đĩa nếu được yêu cầu
    let duongDan = null;
    if (thuMuc) {
      const dir = path.join(thuMuc, bg.id);
      fs.mkdirSync(dir, { recursive: true });
      duongDan = path.join(dir, 'bai-giang.avi');
      fs.writeFileSync(duongDan, video.tep);
      fs.writeFileSync(path.join(dir, 'moc-thoi-gian.json'), JSON.stringify(bg, null, 2));
      if (luuKhung) {
        const kdir = path.join(dir, 'khung');
        fs.mkdirSync(kdir, { recursive: true });
        for (const k of khungAnh) {
          fs.writeFileSync(path.join(kdir, `doan-${String(k.doan).padStart(2, '0')}.png`), ghiPNG(k.anh));
        }
      }
    }

    return { ok: true, ...bg, video: video.tep, duongDan, khungAnh: luuKhung ? khungAnh : undefined };
  }

  /** Một lệnh: chọn nguồn → soạn → dựng. */
  async tao({ maDang = null, chuDe = null, kichBan = null, nguon = 'tu-dong', ...opts } = {}) {
    let dan;
    if (maDang) dan = this.soanTuKho(maDang, opts);
    else if (kichBan) dan = this.soanTuKichBan(kichBan, opts);
    else if (chuDe) {
      // Chủ đề gõ tự do: thử kho đã thẩm định TRƯỚC. Nội dung đã có người
      // kiểm bao giờ cũng hơn nội dung mô hình vừa nghĩ ra, và lại chạy được
      // khi không có mạng lẫn khoá. Chỉ khi không dạng nào khớp mới nhờ mô hình.
      const t = nguon === 'mo-hinh' ? { khop: null, goiY: [] } : this.timDang(chuDe);
      if (t.khop) {
        dan = this.soanTuKho(t.khop.ma, opts);
        if (dan.ok) { dan.chuDeHoi = chuDe; dan.doKhop = t.khop.diem; }
      } else if (nguon === 'kho') {
        return { ok: false, error: 'KHÔNG_CÓ_DẠNG_BÀI_KHỚP', chuDe, goiY: t.goiY,
          goi: 'Gõ sát tên dạng hơn, xem GET /lesson/forms, hoặc đặt nguon="mo-hinh" nếu đã có khoá.' };
      } else {
        dan = await this.soanBangMoHinh(chuDe, opts);
        if (!dan.ok) dan.goiY = t.goiY;
      }
    } else {
      return { ok: false, error: 'THIẾU_NGUỒN_NỘI_DUNG',
        goi: 'Chọn một trong ba: maDang (từ kho đã thẩm định), kichBan (tự soạn), hoặc chuDe (cần khoá mô hình).' };
    }
    if (!dan.ok) return dan;
    return this.dung(dan, opts);
  }

  _luu(b) {
    const { video, khungAnh, ...luu } = b;
    this.baiGiang.set(b.id, luu);
    if (this.repo) this.repo.put(luu);
  }

  lay(id) {
    const b = this.baiGiang.get(id);
    return b ? { ok: true, ...b } : { ok: false, error: 'KHÔNG_TÌM_THẤY_BÀI_GIẢNG', id };
  }

  danhSach({ limit = 30 } = {}) {
    const ds = [...this.baiGiang.values()].sort((a, b) => b.taoLuc - a.taoLuc).slice(0, limit);
    return { ok: true, tong: this.baiGiang.size, items: ds };
  }

  status() {
    return {
      nguonNoiDung: [
        { id: 'kho-hoc-lieu', ten: 'Kho học liệu đã thẩm định', canMang: false, canKhoa: false, dang: FORM_INDEX.size },
        { id: 'kich-ban-nguoi-dung', ten: 'Kịch bản tự soạn', canMang: false, canKhoa: false },
        { id: 'mo-hinh', ten: 'Mô hình ngôn ngữ', canMang: true, canKhoa: true, sanSang: !!(this.llm && this.llm.available().filter((p) => p !== 'mock').length) },
      ],
      kho: Object.entries(KHO).map(([id, k]) => ({ id, ...k })),
      dinhDangXuat: 'AVI (MJPEG + PCM) — mở được bằng VLC, mpv, không cần cài gì',
      baiGiang: this.baiGiang.size,
      stats: {
        ...this.stats,
        giayTieng: round(this.stats.giayTieng, 1),
        msTrungBinh: this.stats.dung ? Math.round(this.stats.msTong / this.stats.dung) : 0,
      },
    };
  }
}

module.exports = { BaiGiangPipeline, KHO };
