'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  CHUỖI GIÁ TRỊ VÀ ĐIỂM CHẠM — gắn 500 trợ lý AI vào từng việc khách hàng làm
 * ═══════════════════════════════════════════════════════════════════════════
 *  Câu hỏi mà tệp này trả lời: trong cả hành trình của một học viên, CHỖ NÀO
 *  thật sự làm nên kết quả, và TỔ NÀO trong 500 trợ lý chịu trách nhiệm ở chỗ
 *  đó. Trả lời được câu ấy thì biết nên bồi công sức vào đâu; không trả lời
 *  được thì mọi "nâng cấp trải nghiệm" đều là đoán.
 *
 *  BA NGUYÊN TẮC, viết ra để không tự lừa mình bằng số đẹp:
 *
 *  1. CHỈ ĐO CÁI CÓ DẤU VẾT. Mỗi chặng dưới đây gắn với một loại thao tác có
 *     thật trong bộ quan sát học viên. Chặng nào hệ thống chưa ghi được dấu
 *     vết thì KHÔNG có trong chuỗi — kể cả những chặng ai cũng biết là có
 *     (nghe bạn giới thiệu, đọc trang công khai rồi đóng tab). Bịa một chặng
 *     rồi gán số cho nó là việc dễ nhất và vô dụng nhất ở đây.
 *
 *  2. KHÔNG KẾT LUẬN TỪ MẪU NHỎ. Một điểm chạm chỉ được chấm khi mỗi nhóm so
 *     sánh có tối thiểu MAU_TOI_THIEU người. Dưới ngưỡng thì trả về đúng chữ
 *     "chưa đủ căn cứ" kèm số người đang có, chứ không trả về một tỉ lệ.
 *
 *  3. SO SÁNH HAI NHÓM, KHÔNG KHOE MỘT NHÓM. "90% người xem lại bài sai thì
 *     tiến bộ" là câu vô nghĩa nếu không biết nhóm KHÔNG xem lại tiến bộ bao
 *     nhiêu. Mọi kết luận ở đây đều là HIỆU của hai nhóm, và hiệu ấy luôn đi
 *     kèm cỡ mẫu của cả hai.
 *
 *  Và một điều tệp này KHÔNG làm: không nói hiệu số đo được là quan hệ nhân
 *  quả. Người chịu xem lại bài sai vốn đã là người chăm hơn. Hiệu số nói "chỗ
 *  này đáng nhìn kỹ", không nói "làm thế này thì chắc chắn tăng".
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { round } = require('../utils');
const { DIVISIONS } = require('../agents/taxonomy');

/** Dưới ngưỡng này thì không chấm, chỉ báo là chưa đủ người. */
const MAU_TOI_THIEU = 10;

/**
 * CHUỖI GIÁ TRỊ — các chặng một học viên đi qua, theo đúng thứ tự.
 *
 *  dauVet  : thao tác chứng minh học viên ĐÃ đi qua chặng này. Không có dấu
 *            vết thì coi như chưa đi qua — không suy đoán từ chặng lân cận.
 *  to      : tổ trong 500 trợ lý chịu trách nhiệm chặng này (mã khối · tên tổ).
 *  viec    : tổ đó làm gì ở chặng này.
 *  hong    : chặng này hỏng thì khách hàng mất gì — viết để khi số tụt thì
 *            biết ngay hậu quả, không phải suy diễn lại từ đầu.
 */
const CHANG = [
  {
    id: 'mo-buoi',
    ten: 'Mở buổi học',
    dauVet: ['SESSION_START'],
    khoi: 'TUTOR', to: 'coach-1v1',
    viec: 'Chào đúng tên, nhắc đúng việc đang dở, không bắt chọn lại từ đầu.',
    hong: 'Học viên mở ứng dụng rồi đóng vì không biết hôm nay làm gì.',
  },
  {
    id: 'mo-bai',
    ten: 'Mở một bài',
    dauVet: ['ITEM_OPEN'],
    khoi: 'MATH', to: 'item-authoring',
    viec: 'Đề đọc hiểu được ngay, đúng tầng, không doạ người học ở câu đầu.',
    hong: 'Mở bài ra rồi bỏ — bài sai tầng hoặc đề viết rối.',
  },
  {
    id: 'xin-goi-y',
    ten: 'Xin gợi ý',
    dauVet: ['HINT_REQUEST'],
    khoi: 'TUTOR', to: 'socratic',
    viec: 'Gợi ý theo cấp, dẫn bằng câu hỏi, không đưa đáp án ở gợi ý đầu.',
    hong: 'Gợi ý nói luôn đáp án — học viên qua bài mà không học được gì.',
  },
  {
    id: 'nop-bai',
    ten: 'Nộp bài',
    dauVet: ['SUBMIT'],
    khoi: 'MATH', to: 'solution-writing',
    viec: 'Chấm đúng, và lời giải nói cả VIỆC LÀM lẫn CĂN CỨ.',
    hong: 'Chấm sai một lần là mất niềm tin, khó lấy lại.',
  },
  {
    id: 'xem-loi-giai',
    ten: 'Xem lời giải',
    dauVet: ['SOLUTION_PEEK'],
    khoi: 'VIETNAMESE', to: 'lang-writing',
    viec: 'Lời giải viết đúng lớp, đúng chính tả, câu ngắn đủ để đọc một hơi.',
    hong: 'Lời giải dài và rối thì học viên đọc lướt rồi tự nhủ là đã hiểu.',
  },
  {
    id: 'xem-lai-bai-sai',
    ten: 'Xem lại bài sai',
    dauVet: ['REVIEW_MISTAKE'],
    khoi: 'TUTOR', to: 'strict',
    viec: 'Đưa lại đúng bài đã sai, kèm bẫy đã mắc, không đưa bài mới.',
    hong: 'Bài sai trôi đi — học viên sẽ sai đúng chỗ đó ở kỳ thi.',
  },
  {
    id: 'bo-bai',
    ten: 'Bỏ bài giữa chừng',
    dauVet: ['SKIP'],
    khoi: 'RESEARCH', to: 'curriculum',
    viec: 'Nhận ra bài vượt tầng và hạ độ khó trước khi học viên nản.',
    hong: 'Bỏ bài thành thói quen, rồi bỏ buổi, rồi bỏ hẳn.',
    xau: true,
  },
  {
    id: 'dong-buoi',
    ten: 'Đóng buổi học tử tế',
    dauVet: ['SESSION_END'],
    khoi: 'BUSINESS', to: 'bi',
    viec: 'Chốt buổi bằng một câu nói được hôm nay học viên tiến ở đâu.',
    hong: 'Buổi học kết thúc bằng việc tắt tab — không ai nhớ mình đã làm gì.',
  },
];

const CHANG_INDEX = new Map(CHANG.map((c) => [c.id, c]));

/** Bảng chuỗi giá trị kèm tên khối trợ lý, dùng cho báo cáo và cho giao diện. */
function chuoiGiaTri() {
  return CHANG.map((c) => ({
    id: c.id,
    ten: c.ten,
    dauVet: c.dauVet.slice(),
    khoi: c.khoi,
    tenKhoi: (DIVISIONS[c.khoi] || {}).name || c.khoi,
    to: c.to,
    viec: c.viec,
    hong: c.hong,
    xau: !!c.xau,
  }));
}

// ── Đo trên dữ liệu thật ────────────────────────────────────────────────────

/** Tập học viên có dấu vết của một chặng. */
function _nguoiChamChang(telemetry, changId) {
  const c = CHANG_INDEX.get(changId);
  const ra = new Set();
  if (!c || !telemetry || !telemetry.events) return ra;
  for (const [userId, evs] of telemetry.events) {
    if (evs.some((e) => c.dauVet.includes(e.type))) ra.add(userId);
  }
  return ra;
}

/** Học viên nào có đủ bài để chấm kết quả — dưới ngưỡng thì bỏ ra ngoài. */
function _nguoiDuBai(telemetry, toiThieu) {
  const ra = [];
  if (!telemetry || !telemetry.attempts) return ra;
  for (const [userId, at] of telemetry.attempts) {
    if (at.filter((x) => !x.skipped).length >= toiThieu) ra.push(userId);
  }
  return ra;
}

const _doChinhXac = (at) => {
  const lam = at.filter((x) => !x.skipped);
  return lam.length ? lam.filter((x) => x.correct).length / lam.length : null;
};

/**
 * Đo MỘT điểm chạm: so nhóm CÓ chạm với nhóm KHÔNG chạm, trên cùng một thước
 * là độ chính xác. Trả về hiệu số kèm cỡ mẫu hai bên, hoặc nói thẳng là chưa
 * đủ căn cứ — không bao giờ trả một tỉ lệ đứng một mình.
 *
 * @param {object} telemetry  bộ quan sát học viên
 * @param {string} changId
 * @param {object} o {mauToiThieu, baiToiThieu}
 */
function doDiemCham(telemetry, changId, { mauToiThieu = MAU_TOI_THIEU, baiToiThieu = 10 } = {}) {
  const c = CHANG_INDEX.get(changId);
  if (!c) return { ok: false, error: 'KHÔNG_CÓ_CHẶNG_NÀY', changId };

  const duBai = _nguoiDuBai(telemetry, baiToiThieu);
  const daCham = _nguoiChamChang(telemetry, changId);
  const co = duBai.filter((u) => daCham.has(u));
  const khong = duBai.filter((u) => !daCham.has(u));

  const nen = {
    ok: true, changId, ten: c.ten, khoi: c.khoi, to: c.to, xau: !!c.xau,
    soNguoiCo: co.length, soNguoiKhong: khong.length,
  };
  if (co.length < mauToiThieu || khong.length < mauToiThieu) {
    return {
      ...nen, duCanCu: false, hieu: null,
      ghiChu: `Chưa đủ căn cứ: cần mỗi nhóm ${mauToiThieu} học viên có từ ${baiToiThieu} bài, `
        + `hiện có ${co.length} người chạm và ${khong.length} người không chạm.`,
    };
  }

  const tbCo = co.map((u) => _doChinhXac(telemetry.attempts.get(u))).filter((x) => x != null);
  const tbKhong = khong.map((u) => _doChinhXac(telemetry.attempts.get(u))).filter((x) => x != null);
  const tb = (a) => round(a.reduce((s, x) => s + x, 0) / a.length, 3);
  const dCo = tb(tbCo);
  const dKhong = tb(tbKhong);
  const hieu = round(dCo - dKhong, 3);

  return {
    ...nen,
    duCanCu: true,
    doChinhXacCo: dCo,
    doChinhXacKhong: dKhong,
    hieu,
    huong: hieu > 0 ? 'cao hơn' : hieu < 0 ? 'thấp hơn' : 'ngang nhau',
    ghiChu: `Nhóm có chạm đạt ${Math.round(dCo * 100)}% đúng (n=${co.length}), `
      + `nhóm không chạm đạt ${Math.round(dKhong * 100)}% (n=${khong.length}). `
      + 'Đây là hiệu số quan sát được, không phải quan hệ nhân quả.',
  };
}

/**
 * Biên bản cả chuỗi. "Điểm chạm tốt nhất" chỉ được gọi tên khi nó ĐỦ CĂN CỨ và
 * hiệu số của nó dương; chặng đánh dấu `xau` (bỏ bài) không bao giờ được coi là
 * điểm chạm tốt, dù hiệu số có ra sao.
 */
function bienBanDiemCham(telemetry, o = {}) {
  const cac = CHANG.map((c) => doDiemCham(telemetry, c.id, o));
  const chamDuoc = cac.filter((x) => x.duCanCu && !x.xau);
  const tot = chamDuoc.filter((x) => x.hieu > 0).sort((a, b) => b.hieu - a.hieu);
  const hai = cac.filter((x) => x.duCanCu && x.hieu < 0).sort((a, b) => a.hieu - b.hieu);
  const thieuCanCu = cac.filter((x) => !x.duCanCu);

  return {
    luc: Date.now(),
    soChang: CHANG.length,
    soChangDoDuoc: cac.length - thieuCanCu.length,
    chang: cac,
    totNhat: tot[0] || null,
    canXemLai: hai[0] || null,
    thieuCanCu: thieuCanCu.map((x) => ({ changId: x.changId, ten: x.ten, ghiChu: x.ghiChu })),
    ketLuan: tot.length
      ? `Điểm chạm chênh lệch lớn nhất: ${tot[0].ten} (${tot[0].khoi} · ${tot[0].to}), `
        + `hiệu ${Math.round(tot[0].hieu * 100)} điểm phần trăm độ chính xác.`
      : thieuCanCu.length === CHANG.length
        ? 'Chưa chặng nào đủ căn cứ để chấm — hệ thống chưa có đủ học viên có dấu vết.'
        : 'Không chặng nào cho hiệu số dương đủ căn cứ.',
  };
}

module.exports = {
  CHANG, MAU_TOI_THIEU, chuoiGiaTri, doDiemCham, bienBanDiemCham,
};
