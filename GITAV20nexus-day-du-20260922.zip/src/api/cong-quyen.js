'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  CỔNG QUYỀN — một lớp xác thực cho TOÀN BỘ API
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  VÌ SAO TỆP NÀY RA ĐỜI. Bản rà soát của quản trị hệ thống tìm ra một lỗ
 *  thủng nghiêm trọng: trong 300 cổng API, chỉ 5 cổng tự kiểm quyền — đúng 5
 *  cổng của phần Cây Tiền, vá riêng lúc làm phần đó. 295 cổng còn lại mở cho
 *  bất kỳ ai gọi được tới máy chủ, trong đó có:
 *
 *      POST /accounts  →  tạo được một tài khoản ADMIN, KHÔNG cần đăng nhập
 *
 *  Nghĩa là bức tường canh Cây Tiền vô giá trị: ai cũng tự đúc được chìa khoá
 *  rồi đi cửa chính. Vá từng cổng một là cách đã hỏng một lần; lần này luật
 *  nằm ở MỘT CHỖ và mọi cổng đều đi qua nó.
 *
 *  BỐN MỨC QUYỀN, xếp theo thứ bậc — mức cao làm được mọi việc của mức thấp:
 *      cong-khai  ai cũng gọi được (trang chủ, sức khoẻ, tài liệu công khai)
 *      hoc-vien   phải đăng nhập, bất kỳ vai nào
 *      giao-vien  giáo viên trở lên
 *      quan-tri   chỉ ADMIN
 *
 *  NGUYÊN TẮC ĐẶT MỨC: mặc định theo NHÓM cổng, và mặc định ấy là mức CAO.
 *  Cổng nào muốn hạ xuống công khai thì phải khai tên tường minh trong
 *  CONG_KHAI dưới đây. Làm ngược lại — mặc định mở, ai cần thì siết — chính là
 *  cách hệ thống này đã thủng: thêm một cổng mới mà quên siết thì nó mở.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const MUC = { 'cong-khai': 0, 'hoc-vien': 1, 'giao-vien': 2, 'quan-tri': 3 };

/** Vai tài khoản → mức quyền đạt được. */
const VAI_TOI_MUC = { LEARNER: 1, PARENT: 1, TEACHER: 2, ADMIN: 3 };

/**
 * Mức mặc định theo nhóm cổng. Nhóm nào không có tên ở đây thì lấy 'quan-tri'
 * — đóng chặt nhất — để một nhóm mới thêm vào không tự động mở toang.
 */
const MUC_THEO_NHOM = {
  // KHÔNG nhóm nào mặc định công khai. Bản rà soát lần đầu đặt CORE, CURRICULUM
  // và SUPERADMIN mặc định 'cong-khai', và chính mục kiểm tự viết đã bắt được
  // hậu quả: POST /chat (tốn tiền mô hình) và GET /bank/items (đề bài KÈM ĐÁP
  // ÁN, kèm cả cổng publish/retire ghi dữ liệu) mở cho bất kỳ ai. Mở theo cả
  // nhóm là mở cho cả những cổng chưa ai đọc lại.
  WEB: 'cong-khai',
  CURRICULUM: 'giao-vien',
  REPORT: 'giao-vien',
  KHAOSAT: 'hoc-vien',
  CAYTIEN: 'quan-tri',
  SUPERADMIN: 'quan-tri',
  ACCOUNTS: 'quan-tri',
  LEARNER: 'hoc-vien',
  PRACTICE: 'hoc-vien',
  EXAM: 'hoc-vien',
  PLACEMENT: 'hoc-vien',
  ROADMAP: 'hoc-vien',
  MASTERY: 'hoc-vien',
  BEHAVIOR: 'giao-vien',
  CLASSES: 'giao-vien',
  SCHOOL: 'giao-vien',
  AUTHORING: 'giao-vien',
  SCIENTIST: 'giao-vien',
  LANG: 'giao-vien',
  TEX: 'hoc-vien',
  VOICE: 'giao-vien',
  FILM: 'giao-vien',
  PHOTO: 'giao-vien',
  LESSON: 'giao-vien',
  AGENTS: 'quan-tri',
  GOVERNANCE: 'quan-tri',
  QUYTRINH: 'quan-tri',
  TRAINGHIEM: 'quan-tri',
  CHIENLUOC: 'quan-tri',
  ANTOAN: 'quan-tri',
  RESILIENCE: 'quan-tri',
  OBSERVABILITY: 'quan-tri',
  OPS: 'quan-tri',
  COMMAND: 'quan-tri',
  DATA: 'quan-tri',
  AI: 'quan-tri',
  // Quan hệ gia đình: dữ liệu khách hàng và học phí. Quản trị viên dùng hằng
  // ngày, nên mức 'quan-tri'; còn việc cấp quyền cho chính ba mươi trợ lý ấy
  // tách sang nhóm riêng, vì duyệt một lá thư khác hẳn với hạ mức tự chủ của
  // cả một ban.
  CRM: 'quan-tri',
  // Đăng ký và quản lý khuôn mặt: phải đang đăng nhập, vai nào cũng được —
  // kể cả học viên, vì chính các em là người gắn khuôn mặt vào máy của mình.
  KHUONMAT: 'hoc-vien',
  // Việc chống lừa đảo của CHÍNH MÌNH: xem máy của mình, đổi mật khẩu của
  // mình. Vai nào cũng cần, kể cả học viên.
  ANTOANVIEC: 'hoc-vien',
  // Sơ đồ tư duy ba chiều là công cụ HỌC. Dữ liệu nó vẽ là chương trình công
  // khai — không có một chữ nào về một em nhỏ cụ thể nào.
  SODO3D: 'hoc-vien',

  // Trò chuyện mở cho học viên: mọi lượt đều đi qua chín cửa, và bảng việc
  // tự nó đã chặn theo vai — một học viên hỏi việc của giáo viên thì cửa thứ
  // tư chặn, không cần hạ cả nhóm xuống.
  TROCHUYEN: 'hoc-vien',
  // Video hướng dẫn: nội dung là cách dùng màn hình, không có dữ liệu của ai.
  VIDEOHD: 'hoc-vien',
  // Tiếp thị nội dung là việc ĐIỀU HÀNH: nó thấy nhật ký trò chuyện gom lại,
  // thấy chỗ trang còn thiếu, và thấy đề xuất sửa trang. Khách không xem.
  TIEPTHI: 'quan-tri',
  // Hai cổng ĐĂNG NHẬP phải công khai. Đây chính là chỗ người dùng vào, nên
  // đòi đăng nhập ở đây là khoá mọi người ngoài cửa.
  KHUONMATVAO: 'cong-khai',
  CRMSUPER: 'quan-tri',
  CORE: 'hoc-vien',
};

/**
 * Cổng khai tường minh là CÔNG KHAI.
 *
 * Danh sách này ngắn có chủ ý, và mỗi dòng phải trả lời được câu hỏi: NGƯỜI
 * CHƯA ĐĂNG NHẬP cần cổng này để làm gì? Không trả lời được thì không vào đây.
 */
const CONG_KHAI = new Set([
  // Máy giám sát và người mới tới cần biết hệ thống còn sống và là cái gì.
  'GET /',
  'GET /api',
  'GET /health',
  // Đăng nhập bắt buộc phải mở, nếu không thì không ai vào được.
  'POST /accounts/login',
  'POST /accounts/logout',
  // Đăng nhập bằng khuôn mặt: hai cổng này là LỐI VÀO, phải mở như cổng đăng
  // nhập thường. Cả hai đều không tiết lộ tài khoản nào tồn tại.
  'POST /khuon-mat/xin-dang-nhap',
  'POST /khuon-mat/dang-nhap',
  // Két Super Admin có hệ khoá 15 tầng riêng, không dùng phiên thường. Ba cổng
  // dưới đây là cổng ĐĂNG NHẬP của chính nó; sáu cổng còn lại của nhóm
  // SUPERADMIN đều đòi vé của két nên vẫn để ở mức quản trị.
  'GET /superadmin/status',
  'POST /superadmin/login',
  'POST /superadmin/logout',
  // Khởi tạo két lần đầu: chính hàm initialize() trả ALREADY_INITIALIZED khi
  // đã có chủ, nên cổng này tự đóng sau lần dùng đầu tiên.
  'POST /superadmin/initialize',
]);

/** Cổng khai tường minh mức KHÁC mặc định của nhóm. */
const MUC_RIENG = new Map([
  // Tạo tài khoản là việc của quản trị. Đây chính là cổng đã cho phép bất kỳ
  // ai tự đúc một tài khoản ADMIN.
  ['POST /accounts', 'quan-tri'],
  ['DELETE /accounts/:id', 'quan-tri'],
  // Kho học liệu chứa ĐỀ BÀI KÈM ĐÁP ÁN, và có cả cổng ghi. Học viên đọc đề
  // qua cổng luyện tập, không qua cổng kho.
  ['GET /bank/items', 'giao-vien'],
  ['GET /bank/items/:id', 'giao-vien'],
  ['POST /bank/items/:id/publish', 'quan-tri'],
  ['POST /bank/items/:id/retire', 'quan-tri'],
  ['POST /bank/draft', 'giao-vien'],
  // Gọi mô hình ngôn ngữ là cổng TỐN TIỀN. Mở cho người lạ là mở ví.
  ['POST /chat', 'giao-vien'],
  // Sàng lọc tâm lý học đường chạm dữ liệu nhạy cảm của trẻ: phải đăng nhập.
  ['POST /khao-sat/tam-ly/cham', 'hoc-vien'],
  // Báo cáo của MỘT học viên: giáo viên trở lên.
  ['GET /reports/learner/:id', 'giao-vien'],
  // Cây giá trị là thứ GIA ĐÌNH ĐƯỢC BIẾT — nên phải mở tới mức 'hoc-vien',
  // là mức của cả LEARNER và PARENT. Ba cổng này nằm trong nhóm REPORT, mà
  // nhóm ấy mặc định 'giao-vien': để nguyên thì chính người nhà không đọc được
  // cái cây dựng cho họ. Đã soi bằng bức tường: ba cổng này không có một chữ
  // nào của bảng phân loại nội bộ.
  ['GET /cay-gia-tri', 'hoc-vien'],
  ['GET /cay-gia-tri/luoi', 'hoc-vien'],
  ['GET /cay-gia-tri/o/:tang/:cap', 'hoc-vien'],
]);

const khoa = (method, pattern) => `${String(method).toUpperCase()} ${pattern}`;

/** Mức quyền một cổng đòi hỏi. */
function mucCua(route) {
  const k = khoa(route.method, route.pattern);
  if (CONG_KHAI.has(k)) return 'cong-khai';
  if (MUC_RIENG.has(k)) return MUC_RIENG.get(k);
  return MUC_THEO_NHOM[route.group] || 'quan-tri';
}

/** Đọc một cookie theo tên. */
function docCookie(header, ten) {
  if (!header) return null;
  for (const phan of String(header).split(';')) {
    const i = phan.indexOf('=');
    if (i < 0) continue;
    if (phan.slice(0, i).trim() === ten) return decodeURIComponent(phan.slice(i + 1).trim());
  }
  return null;
}

/** Phiên đăng nhập của một yêu cầu, hoặc null. */
function phienCua(N, headers) {
  const cookie = docCookie(headers && headers.cookie, 'gita_token');
  const bearer = String((headers && headers.authorization) || '').replace(/^Bearer\s+/i, '');
  const token = cookie || bearer || null;
  if (!token || !N || !N.accounts || typeof N.accounts.session !== 'function') return null;
  return N.accounts.session(token) || null;
}

/**
 * CỬA KHỞI TẠO. Khi hệ thống CHƯA CÓ tài khoản quản trị nào thì phải tạo được
 * tài khoản quản trị đầu tiên, nếu không hệ thống mới cài sẽ tự khoá mình
 * ngoài cửa.
 *
 * Cửa này hẹp đúng một khe: chỉ cho POST /accounts, chỉ khi số tài khoản ADMIN
 * bằng 0, và mỗi lần mở đều ghi vào nhật ký kiểm toán. Mở rộng hơn một chút là
 * quay lại đúng lỗ thủng cũ.
 */
function laCuaKhoiTao(N, route, body) {
  if (khoa(route.method, route.pattern) !== 'POST /accounts') return false;
  if (String((body && body.role) || '').toUpperCase() !== 'ADMIN') return false;
  try {
    const ds = N.accounts.list({ role: 'ADMIN', limit: 1 });
    const so = ds && (ds.total != null ? ds.total : (ds.users || ds.items || []).length);
    return so === 0;
  } catch { return false; }
}

/**
 * Kiểm quyền cho một yêu cầu.
 * @returns {{ok:true, phien:object|null, muc:string, khoiTao?:boolean}
 *          | {ok:false, status:number, error:string, reason:string}}
 */
function kiemQuyen(N, route, headers, body) {
  const muc = mucCua(route);
  if (muc === 'cong-khai') return { ok: true, phien: null, muc };

  const phien = phienCua(N, headers);
  if (!phien) {
    if (laCuaKhoiTao(N, route, body)) {
      return { ok: true, phien: null, muc, khoiTao: true };
    }
    return {
      ok: false, status: 401, error: 'CHƯA_ĐĂNG_NHẬP',
      reason: 'Cổng này cần đăng nhập. Gửi kèm cookie gita_token hoặc header Authorization: Bearer <token>.',
    };
  }
  const dat = VAI_TOI_MUC[String(phien.role || '').toUpperCase()] || 0;
  if (dat < MUC[muc]) {
    return {
      ok: false, status: 403, error: 'KHÔNG_ĐỦ_QUYỀN',
      // Không nói cổng này thuộc về ai — nói ra là vẽ đường cho người dò.
      reason: 'Tài khoản hiện tại không đủ quyền cho mục này.',
    };
  }
  return { ok: true, phien, muc };
}

/** Bảng quyền của toàn bộ cổng — dùng cho rà soát và cho mục kiểm. */
function bangQuyen(routes) {
  const theoMuc = { 'cong-khai': 0, 'hoc-vien': 0, 'giao-vien': 0, 'quan-tri': 0 };
  const hang = routes.map((r) => {
    const m = mucCua(r);
    theoMuc[m]++;
    return { method: r.method, pattern: r.pattern, group: r.group, muc: m };
  });
  return { tong: routes.length, theoMuc, hang };
}

module.exports = {
  MUC, VAI_TOI_MUC, MUC_THEO_NHOM, CONG_KHAI, MUC_RIENG,
  mucCua, phienCua, kiemQuyen, bangQuyen, laCuaKhoiTao, docCookie,
};
