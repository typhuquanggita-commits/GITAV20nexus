'use strict';
/** GITAmath Nexus V20 — Logger có cấp độ, an toàn với vòng tham chiếu. */

const cfg = require('./config');

const LEVELS = { debug: 10, info: 20, ok: 20, warn: 30, error: 40, silent: 99 };
const threshold = LEVELS[cfg.LOG_LEVEL] ?? LEVELS.info;

const C = {
  gray: '\x1b[90m', red: '\x1b[31m', green: '\x1b[32m',
  yellow: '\x1b[33m', cyan: '\x1b[36m', reset: '\x1b[0m',
};
const useColor = process.stdout.isTTY && !process.env.NO_COLOR;
const paint = (c, s) => (useColor ? c + s + C.reset : s);

function safe(value) {
  if (value === undefined) return '';
  if (typeof value === 'string') return value;
  const seen = new WeakSet();
  try {
    return JSON.stringify(value, (_k, v) => {
      if (typeof v === 'bigint') return v.toString();
      if (v && typeof v === 'object') {
        if (seen.has(v)) return '[Circular]';
        seen.add(v);
      }
      return v;
    });
  } catch {
    return String(value);
  }
}

function emit(level, tag, msg, extra) {
  if (LEVELS[level] < threshold) return;
  const ts = new Date().toISOString();
  const line = `${paint(C.gray, ts)} ${tag} ${msg}${extra !== undefined ? ' ' + safe(extra) : ''}`;
  if (level === 'error') process.stderr.write(line + '\n');
  else process.stdout.write(line + '\n');
}

const L = {
  debug: (m, e) => emit('debug', paint(C.gray, '[·]'), m, e),
  info: (m, e) => emit('info', paint(C.cyan, '[i]'), m, e),
  ok: (m, e) => emit('ok', paint(C.green, '[✓]'), m, e),
  warn: (m, e) => emit('warn', paint(C.yellow, '[!]'), m, e),
  error: (m, e) => emit('error', paint(C.red, '[✗]'), m, e),
  banner: (lines) => {
    if (LEVELS.info < threshold) return;
    const width = Math.max(...lines.map((l) => l.length)) + 2;
    const bar = '═'.repeat(width);
    process.stdout.write(paint(C.cyan, `╔${bar}╗`) + '\n');
    for (const l of lines) {
      process.stdout.write(
        paint(C.cyan, '║') + ' ' + l.padEnd(width - 1) + paint(C.cyan, '║') + '\n'
      );
    }
    process.stdout.write(paint(C.cyan, `╚${bar}╝`) + '\n');
  },
};

module.exports = L;
