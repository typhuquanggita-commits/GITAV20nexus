'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  CỔNG DỰNG VIDEO — và cái chốt chặn trước khi tiêu tiền
 * ═══════════════════════════════════════════════════════════════════════════
 *  Khác hẳn phần giọng nói: ở đây KHÔNG có bản nội bộ thay thế được. Không ai
 *  dựng được cảnh phim thật bằng vài trăm dòng JavaScript, và nói ngược lại
 *  là nói dối.
 *
 *  Nên hệ thống chia rõ hai mức:
 *    · BẢN NHÁP — bảng phân cảnh + đường tiếng + phim nháp chạy được. Miễn
 *      phí, không cần khoá, đủ để duyệt nhịp phim và sửa kịch bản.
 *    · BẢN THẬT — gọi mô hình dựng video qua fal.ai. Tốn tiền thật, nên có
 *      chốt: phải có dự toán, phải dưới trần chi tiêu, phải xác nhận tay.
 *
 *  Chốt chặn nằm trong mã, không nằm trong hướng dẫn sử dụng.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const cfg = require('../config');
const L = require('../logger');
const { MODEL } = require('./models');
const { veKhung } = require('./storyboard');
const { round, sleep } = require('../utils');

/** Bản nháp: "dựng" một cảnh quay thành khung phân cảnh SVG. Luôn chạy được. */
class CongBangPhanCanh {
  constructor() {
    this.id = 'bang-phan-canh';
    this.ten = 'Bảng phân cảnh (nội bộ)';
    this.tinhTien = false;
  }

  sanSang() { return { ok: true }; }

  async dung(canhQuay, { hoSoNhanVat = [] } = {}) {
    const svg = veKhung(canhQuay, hoSoNhanVat, { rong: 960, cao: 540 });
    return {
      ok: true, cong: this.id, idCanhQuay: canhQuay.id,
      loai: 'svg', noiDung: svg, giay: canhQuay.giay, usd: 0,
      note: 'Khung phân cảnh, không phải video. Dùng để duyệt bố cục và nhịp.',
    };
  }
}

/** Cổng fal.ai — gọi thật, trả về URL video. */
class CongFal {
  constructor() {
    this.id = 'fal';
    this.ten = 'fal.ai (cổng tổng hợp mô hình video)';
    this.tinhTien = true;
    this.stats = { goi: 0, xong: 0, hong: 0, usd: 0 };
  }

  sanSang() {
    if (!cfg.FILM.falKey) return { ok: false, ly: 'THIẾU_KHOÁ', sua: 'Đặt FAL_KEY (lấy tại fal.ai)' };
    return { ok: true };
  }

  async dung(canhQuay, { anhThamChieu = null, timeoutMs = 360_000 } = {}) {
    const av = this.sanSang();
    if (!av.ok) return { ok: false, cong: this.id, idCanhQuay: canhQuay.id, loi: av.ly };
    const m = MODEL[canhQuay.model];
    if (!m) return { ok: false, cong: this.id, idCanhQuay: canhQuay.id, loi: 'CHƯA_CHỌN_MÔ_HÌNH' };

    this.stats.goi++;
    const t0 = Date.now();
    try {
      const than = {
        prompt: canhQuay.prompt,
        duration: String(Math.round(canhQuay.giay)),
        aspect_ratio: '16:9',
        resolution: '1080p',
      };
      if (anhThamChieu && m.hoTro.anhSangVideo) than.image_url = anhThamChieu;

      const gui = await fetch(`https://queue.fal.run/${m.duongDan}`, {
        method: 'POST',
        headers: { authorization: `Key ${cfg.FILM.falKey}`, 'content-type': 'application/json' },
        body: JSON.stringify(than),
        signal: AbortSignal.timeout(60_000),
      });
      if (!gui.ok) {
        const t = await gui.text();
        throw new Error(`HTTP_${gui.status}: ${t.slice(0, 160)}`);
      }
      const { request_id: rid } = await gui.json();
      if (!rid) throw new Error('KHÔNG_CÓ_MÃ_YÊU_CẦU');

      const url = await this._cho(rid, timeoutMs);
      const usd = round((canhQuay.giay / 5) * m.giaMoi5Giay, 3);
      this.stats.xong++;
      this.stats.usd = round(this.stats.usd + usd, 3);
      return {
        ok: true, cong: this.id, idCanhQuay: canhQuay.id, loai: 'video',
        url, model: m.id, modelTen: m.ten, giay: canhQuay.giay, usd,
        ms: Date.now() - t0,
      };
    } catch (e) {
      this.stats.hong++;
      L.warn(`Dựng video ${canhQuay.id} hỏng: ${e.message}`);
      return { ok: false, cong: this.id, idCanhQuay: canhQuay.id, loi: String(e.message).slice(0, 200), ms: Date.now() - t0 };
    }
  }

  async _cho(rid, timeoutMs) {
    const han = Date.now() + timeoutMs;
    while (Date.now() < han) {
      await sleep(3000);
      const r = await fetch(`https://queue.fal.run/requests/${rid}/status`, {
        headers: { authorization: `Key ${cfg.FILM.falKey}` }, signal: AbortSignal.timeout(30_000),
      });
      if (!r.ok) continue;
      const st = await r.json();
      if (st.status === 'COMPLETED') {
        const kq = await fetch(`https://queue.fal.run/requests/${rid}`, {
          headers: { authorization: `Key ${cfg.FILM.falKey}` }, signal: AbortSignal.timeout(30_000),
        });
        const d = await kq.json();
        const url = d.video?.url || d.video_url || d.output?.video?.url;
        if (!url) throw new Error('KẾT_QUẢ_KHÔNG_CÓ_URL_VIDEO');
        return url;
      }
      if (st.status === 'FAILED') throw new Error(`MÔ_HÌNH_BÁO_HỎNG: ${st.error || 'không rõ'}`);
    }
    throw new Error(`HẾT_THỜI_GIAN_CHỜ (${Math.round(timeoutMs / 1000)}s)`);
  }
}

class CongVideo {
  constructor() {
    this.nhap = new CongBangPhanCanh();
    this.that = new CongFal();
  }

  /**
   * Chốt chặn trước khi tiêu tiền. Không qua được là không gọi API nào.
   * @param {object} o {duToan, xacNhan, tranUsd}
   */
  chotChiTieu({ duToan, xacNhan = false, tranUsd = null }) {
    const tran = tranUsd != null ? Number(tranUsd) : cfg.FILM.tranChiTieuUsd;
    if (!duToan) return { ok: false, error: 'CHƯA_CÓ_DỰ_TOÁN' };
    const av = this.that.sanSang();
    if (!av.ok) {
      return { ok: false, error: 'CHƯA_CÓ_CỔNG_DỰNG_VIDEO', ly: av.ly, sua: av.sua,
        goi: 'Vẫn dựng được bản nháp: bảng phân cảnh + đường tiếng + phim nháp.' };
    }
    if (duToan.usd > tran) {
      return { ok: false, error: 'VƯỢT_TRẦN_CHI_TIÊU', duToanUsd: duToan.usd, tranUsd: tran,
        goi: 'Đổi ưu tiên sang "tiet-kiem", cắt bớt cảnh, hoặc nâng FILM_MAX_USD.' };
    }
    if (cfg.FILM.batBuocXacNhan && !xacNhan) {
      return { ok: false, error: 'CHƯA_XÁC_NHẬN_CHI_TIÊU', duToanUsd: duToan.usd, tranUsd: tran,
        goi: `Dựng phim này sẽ tốn khoảng $${duToan.usd}. Gửi lại với xacNhan=true để chạy.` };
    }
    return { ok: true, duToanUsd: duToan.usd, tranUsd: tran };
  }

  trangThai() {
    const av = this.that.sanSang();
    return {
      nhap: { id: this.nhap.id, ten: this.nhap.ten, sanSang: true, tinhTien: false },
      that: { id: this.that.id, ten: this.that.ten, sanSang: av.ok, ly: av.ly || null, sua: av.sua || null, tinhTien: true, stats: { ...this.that.stats } },
      tranChiTieuUsd: cfg.FILM.tranChiTieuUsd,
      batBuocXacNhan: cfg.FILM.batBuocXacNhan,
    };
  }
}

module.exports = { CongVideo, CongFal, CongBangPhanCanh };
