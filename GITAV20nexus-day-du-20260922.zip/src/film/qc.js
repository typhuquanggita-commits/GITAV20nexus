'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  SOÁT CHẤT LƯỢNG — soát TRƯỚC khi tiêu tiền, không phải sau khi xem phim
 * ═══════════════════════════════════════════════════════════════════════════
 *  Bản thiết kế gốc soát sau khi đã dựng xong video, và soát bằng những
 *  trường như `diemNhatQuan` mà không chỗ nào sinh ra — nên hàm luôn báo đạt.
 *
 *  Ở đây mọi phép soát đều ĐO ĐƯỢC trên dữ liệu có thật, và chạy TRƯỚC khi
 *  gọi bất kỳ API tính tiền nào. Một phim ba phút tốn vài chục đô; phát hiện
 *  "lời thoại dài hơn cảnh quay" sau khi trả tiền là mất trắng.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { soatKhoa } = require('./characters');
const { MODEL } = require('./models');
const { GIAY_TOI_DA, GIAY_TOI_THIEU } = require('./shots');
const { round, sha256 } = require('../utils');

const MUC = { chan: 'CHẶN', nang: 'NẶNG', nhe: 'NHẸ' };

/**
 * @param {object} o {kichBan, hoSoNhanVat, canhQuay, duToan, nganSachUsd}
 */
function soat({ kichBan, hoSoNhanVat, canhQuay, duToan = null, nganSachUsd = null }) {
  const loi = [];
  const them = (muc, loai, nutThat, note, cachSua, extra = {}) =>
    loi.push({ muc, loai, o: nutThat, note, cachSua, ...extra });

  // ── 1. Lời thoại có vừa cảnh quay không (đo bằng bộ phiên âm) ──
  for (const c of canhQuay) {
    if (!c.thoai || !c.doThoai) continue;
    const can = c.doThoai.giay + 1.2;           // + lấy đà và khoảng lặng
    if (can > c.giay + 0.05) {
      them(MUC.chan, 'THOẠI_TRÀN_KHỎI_CẢNH', c.id,
        `Đọc "${c.thoai.loi.slice(0, 40)}…" mất ${c.doThoai.giay}s, cảnh chỉ có ${c.giay}s.`,
        `Kéo cảnh lên ${round(can, 1)}s, hoặc cắt bớt câu thoại.`,
        { giayCan: round(can, 1), giayCo: c.giay });
    }
    if (c.doThoai.khongDocDuoc && c.doThoai.khongDocDuoc.length) {
      them(MUC.nang, 'THOẠI_CÓ_CHỮ_KHÔNG_ĐỌC_ĐƯỢC', c.id,
        `Bộ đọc tiếng Việt không phát âm được: ${c.doThoai.khongDocDuoc.slice(0, 5).join(', ')}`,
        'Viết lại bằng chữ thuần Việt, hoặc thêm phiên âm trong ngoặc.');
    }
  }

  // ── 2. Prompt có mang khoá ngoại hình của đúng nhân vật không ──
  for (const c of canhQuay) {
    if (!c.nhanVat || !c.nhanVat.length) continue;
    const r = soatKhoa(c.prompt, c.nhanVat, hoSoNhanVat);
    if (!r.ok) {
      them(MUC.chan, 'PROMPT_THIẾU_KHOÁ_NGOẠI_HÌNH', c.id,
        `Thiếu khoá của: ${r.thieu.map((x) => x.ten || x.id).join(', ')}. Sang cảnh này nhân vật sẽ thành người khác.`,
        'Dựng lại prompt qua dungPrompt() — khoá phải được chèn nguyên văn.');
    }
  }

  // ── 3. Nhân vật bị tả quá sơ sài ──
  for (const h of hoSoNhanVat) {
    if (h.soLuotThoai === 0 && !canhQuay.some((c) => (c.nhanVat || []).includes(h.id))) continue;
    if ((h.netNgoaiHinh || []).length < 2) {
      them(MUC.nang, 'NHÂN_VẬT_THIẾU_MÔ_TẢ', h.id,
        `"${h.ten}" chỉ có ${(h.netNgoaiHinh || []).length} nét ngoại hình. Mặt sẽ đổi giữa các cảnh.`,
        'Thêm vào kịch bản: tuổi, tóc, kính, trang phục, nét mặt.');
    }
  }

  // ── 4. Thời lượng cảnh quay so với mô hình đã chọn ──
  for (const c of canhQuay) {
    if (c.giay < GIAY_TOI_THIEU) {
      them(MUC.nhe, 'CẢNH_QUÁ_NGẮN', c.id,
        `${c.giay}s — dưới ${GIAY_TOI_THIEU}s người xem chưa kịp nhìn.`, 'Gộp với cảnh kế hoặc kéo dài.');
    }
    if (c.giay > GIAY_TOI_DA) {
      them(MUC.nang, 'CẢNH_QUÁ_DÀI', c.id,
        `${c.giay}s vượt trần ${GIAY_TOI_DA}s cho một cảnh quay.`, 'Dùng catCanhQuay() để tách.');
    }
    const m = MODEL[c.model];
    if (m && c.giay > m.giayToiDa) {
      them(MUC.chan, 'VƯỢT_THỜI_LƯỢNG_MÔ_HÌNH', c.id,
        `${c.giay}s nhưng ${m.ten} chỉ dựng được ${m.giayToiDa}s.`,
        'Đổi mô hình (Sora 2 dựng được 60s) hoặc cắt cảnh.');
    }
    if (!c.model) {
      them(MUC.chan, 'KHÔNG_MÔ_HÌNH_NÀO_DỰNG_ĐƯỢC', c.id, c.viChonModel || 'Không chọn được mô hình.', 'Cắt cảnh ngắn lại.');
    }
  }

  // ── 5. Hai cảnh quay trùng prompt → phim lặp hình ──
  const theoPrompt = new Map();
  for (const c of canhQuay) {
    const k = sha256(c.prompt).slice(0, 16);
    if (!theoPrompt.has(k)) theoPrompt.set(k, []);
    theoPrompt.get(k).push(c.id);
  }
  for (const [, ids] of theoPrompt) {
    if (ids.length > 1) {
      them(MUC.nhe, 'TRÙNG_PROMPT', ids.join(', '),
        `${ids.length} cảnh quay dùng prompt giống hệt nhau — phim sẽ lặp hình.`,
        'Đổi cỡ cảnh hoặc chuyển động máy cho khác nhau.');
    }
  }

  // ── 6. Nhịp phim ──
  const soThoai = canhQuay.filter((c) => c.thoai).length;
  const trungBinh = canhQuay.length ? round(canhQuay.reduce((a, c) => a + c.giay, 0) / canhQuay.length, 1) : 0;
  if (canhQuay.length >= 4 && soThoai / canhQuay.length > 0.8) {
    them(MUC.nhe, 'QUÁ_NHIỀU_CẢNH_THOẠI', 'toàn phim',
      `${soThoai}/${canhQuay.length} cảnh là người nói. Phim thành kịch truyền thanh có hình.`,
      'Thêm cảnh hành động, cảnh phản ứng, cảnh cắt sang chi tiết.');
  }
  if (trungBinh > 8) {
    them(MUC.nhe, 'NHỊP_CHẬM', 'toàn phim',
      `Cảnh quay dài trung bình ${trungBinh}s — nhịp chậm, dễ mất người xem.`,
      'Cắt nhỏ cảnh dài, xen cảnh phản ứng ngắn.');
  }

  // ── 7. Ngân sách ──
  if (duToan && nganSachUsd != null && duToan.usd > nganSachUsd) {
    them(MUC.chan, 'VƯỢT_NGÂN_SÁCH', 'toàn phim',
      `Dự toán $${duToan.usd} vượt ngân sách $${nganSachUsd}.`,
      'Đổi ưu tiên sang "tiet-kiem", hoặc cắt bớt cảnh.');
  }

  // ── 8. Cảnh báo từ khâu đọc kịch bản ──
  for (const c of (kichBan.canhBao || [])) {
    them(MUC.nhe, c.loai, `dòng ${c.dong || '?'}`, c.note, 'Sửa trong kịch bản.');
  }

  const chan = loi.filter((x) => x.muc === MUC.chan);
  const nang = loi.filter((x) => x.muc === MUC.nang);
  const nhe = loi.filter((x) => x.muc === MUC.nhe);
  const tongCheck = canhQuay.length * 4 + hoSoNhanVat.length + 4;
  const diem = round(Math.max(0, 100 - chan.length * 15 - nang.length * 6 - nhe.length * 2), 1);

  return {
    ok: chan.length === 0,
    duocDung: chan.length === 0,
    diem,
    xep: diem >= 90 ? 'TỐT' : diem >= 75 ? 'DÙNG ĐƯỢC' : diem >= 55 ? 'CẦN SỬA' : 'PHẢI SỬA',
    tong: loi.length,
    chan: chan.length, nang: nang.length, nhe: nhe.length,
    loi,
    thongKe: {
      canhQuay: canhQuay.length, canhThoai: soThoai,
      giayTrungBinh: trungBinh,
      soPhepSoat: tongCheck,
      nhanVat: hoSoNhanVat.length,
    },
    ketLuan: chan.length
      ? `KHÔNG được dựng: còn ${chan.length} lỗi chặn. Sửa xong chạy soát lại.`
      : (nang.length ? `Dựng được, nhưng còn ${nang.length} lỗi nặng nên sửa trước.` : 'Dựng được.'),
  };
}

module.exports = { soat, MUC };
