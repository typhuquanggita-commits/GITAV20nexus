'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  DANH MỤC MÔ HÌNH DỰNG VIDEO — và cách chọn cho từng cảnh quay
 * ═══════════════════════════════════════════════════════════════════════════
 *  Mỗi mô hình mạnh một kiểu. Chọn sai là vừa tốn tiền vừa ra cảnh hỏng:
 *    · cảnh có nhân vật quen thuộc → cần mô hình giữ được khuôn mặt
 *    · cảnh có lời thoại           → cần mô hình dựng được khẩu hình
 *    · cảnh thiết lập bối cảnh     → cần mô hình có chất điện ảnh
 *    · cảnh dài trên 10 giây       → phần lớn mô hình không làm được, phải cắt
 *
 *  Giá ghi ở đây là giá NIÊM YẾT của nhà cung cấp tại thời điểm viết, dùng để
 *  DỰ TOÁN trước khi bấm nút — không phải hoá đơn. Hệ thống luôn in dự toán
 *  ra trước và chờ xác nhận, vì một phim ba phút có thể tốn vài chục đô.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { round, clamp } = require('../utils');

const MODEL = {
  kling: {
    id: 'kling', ten: 'Kling 3.0', cong: 'fal',
    duongDan: 'fal-ai/kling-video/v3/pro/image-to-video',
    theManh: ['nhat_quan_nhan_vat', 'nhieu_canh', 'am_thanh_goc', '4k'],
    giayToiDa: 15, giaMoi5Giay: 0.50, diemChatLuong: 10,
    hoTro: { anhSangVideo: true, chuSangVideo: true, thamChieuNhanVat: true },
    note: 'Giữ khuôn mặt nhân vật tốt nhất trong nhóm. Ưu tiên cho cảnh có người quen.',
  },
  veo: {
    id: 'veo', ten: 'Veo 3.1', cong: 'fal', duongDan: 'fal-ai/veo3.1',
    theManh: ['dien_anh', 'am_thanh_goc', 'hien_thuc', 'thoai'],
    giayToiDa: 8, giaMoi5Giay: 2.00, diemChatLuong: 10,
    hoTro: { anhSangVideo: true, chuSangVideo: true, thamChieuNhanVat: false },
    note: 'Chất điện ảnh và khẩu hình tốt nhất, nhưng đắt gấp bốn Kling và chỉ 8 giây.',
  },
  runway: {
    id: 'runway', ten: 'Runway Gen-4.5', cong: 'fal',
    duongDan: 'fal-ai/runway-gen4.5/turbo/image-to-video',
    theManh: ['kiem_soat_goc_may', 'hieu_ung', 'chuyen_dong'],
    giayToiDa: 10, giaMoi5Giay: 2.50, diemChatLuong: 9,
    hoTro: { anhSangVideo: true, chuSangVideo: false, thamChieuNhanVat: true },
    note: 'Điều khiển máy quay chính xác nhất — dùng cho cảnh lia, theo dõi, zoom.',
  },
  sora: {
    id: 'sora', ten: 'Sora 2', cong: 'fal', duongDan: 'fal-ai/sora-2/text-to-video',
    theManh: ['ke_chuyen', 'vat_ly', 'thoi_luong_dai'],
    giayToiDa: 60, giaMoi5Giay: 0.60, diemChatLuong: 9,
    hoTro: { anhSangVideo: false, chuSangVideo: true, thamChieuNhanVat: false },
    note: 'Mô hình duy nhất dựng được cảnh dài trên 15 giây mà không phải cắt.',
  },
  wan: {
    id: 'wan', ten: 'Wan 2.5', cong: 'fal', duongDan: 'fal-ai/wan-25-preview/text-to-video',
    theManh: ['tiet_kiem', 'ma_nguon_mo', 'nhanh'],
    giayToiDa: 10, giaMoi5Giay: 0.25, diemChatLuong: 7,
    hoTro: { anhSangVideo: true, chuSangVideo: true, thamChieuNhanVat: false },
    note: 'Rẻ nhất. Dùng cho cảnh phụ, cảnh chuyển, hoặc khi dựng nháp cả phim.',
  },
  pika: {
    id: 'pika', ten: 'Pika 2.5', cong: 'fal', duongDan: 'fal-ai/pika/v2.5/pikaframes',
    theManh: ['hieu_ung_viral', 'mang_xa_hoi'],
    giayToiDa: 5, giaMoi5Giay: 0.20, diemChatLuong: 7,
    hoTro: { anhSangVideo: true, chuSangVideo: true, thamChieuNhanVat: false },
    note: 'Cảnh ngắn cho mạng xã hội. Không hợp phim kể chuyện.',
  },
};

/** Ba hướng ưu tiên khi chọn mô hình. */
const UU_TIEN = {
  'chat-luong': { name: 'Chất lượng cao nhất', phatGia: 0 },
  'can-bang': { name: 'Cân bằng chất lượng và giá', phatGia: 18 },
  'tiet-kiem': { name: 'Tiết kiệm nhất', phatGia: 60 },
};

/**
 * Chấm điểm và chọn mô hình cho MỘT cảnh quay.
 * Trả về cả bảng điểm để người dùng thấy vì sao chọn — không phải hộp đen.
 */
function chonModel(canhQuay, { uuTien = 'can-bang', chiDung = null } = {}) {
  const uu = UU_TIEN[uuTien] || UU_TIEN['can-bang'];
  const giay = canhQuay.giay || 5;
  const coNhanVat = (canhQuay.nhanVat || []).length > 0;
  const coThoai = !!canhQuay.thoai;
  const laThietLap = canhQuay.co === 'toan-canh' || canhQuay.co === 'thiet-lap';
  const coChuyenDong = canhQuay.chuyenDong && canhQuay.chuyenDong !== 'tinh';
  const daiBatThuong = giay > 12;

  const bang = [];
  for (const m of Object.values(MODEL)) {
    if (chiDung && m.id !== chiDung) continue;
    const ly = [];
    let diem = m.diemChatLuong * 10;

    if (coNhanVat && m.theManh.includes('nhat_quan_nhan_vat')) { diem += 40; ly.push('giữ được khuôn mặt nhân vật'); }
    if (coThoai && m.theManh.includes('thoai')) { diem += 28; ly.push('dựng được khẩu hình theo lời thoại'); }
    if (coThoai && m.theManh.includes('am_thanh_goc')) { diem += 12; ly.push('có âm thanh gốc'); }
    if (laThietLap && m.theManh.includes('dien_anh')) { diem += 30; ly.push('chất điện ảnh cho cảnh thiết lập'); }
    if (coChuyenDong && m.theManh.includes('kiem_soat_goc_may')) { diem += 26; ly.push('điều khiển được máy quay'); }
    if (daiBatThuong && m.theManh.includes('thoi_luong_dai')) { diem += 34; ly.push('dựng được cảnh dài'); }

    // Vượt thời lượng tối đa là loại thẳng, không phải trừ điểm cho vui.
    let loai = null;
    if (giay > m.giayToiDa) { loai = `chỉ dựng được tối đa ${m.giayToiDa} giây`; diem -= 1000; }

    const gia = round((giay / 5) * m.giaMoi5Giay, 3);
    diem -= gia * uu.phatGia;

    bang.push({ id: m.id, ten: m.ten, diem: round(diem, 1), gia, loai, vi: ly });
  }

  bang.sort((a, b) => b.diem - a.diem);
  const top = bang[0];
  if (!top || top.diem < 0) {
    return {
      ok: false, error: 'KHÔNG_MÔ_HÌNH_NÀO_DỰNG_ĐƯỢC',
      giay,
      goi: `Cảnh dài ${giay}s. Mô hình dài nhất là Sora 2 (${MODEL.sora.giayToiDa}s) — hãy cắt cảnh này nhỏ hơn.`,
      bang,
    };
  }
  return {
    ok: true,
    model: MODEL[top.id],
    diem: top.diem,
    gia: top.gia,
    vi: top.vi.length ? top.vi.join(' + ') : 'cân bằng giữa chất lượng và giá',
    bang,
  };
}

/** Dự toán cho cả danh sách cảnh quay, tách theo mô hình. */
function duToan(danhSachCanhQuay, { uuTien = 'can-bang' } = {}) {
  const theoModel = Object.create(null);
  let tong = 0;
  let giay = 0;
  const khong = [];

  for (const cq of danhSachCanhQuay) {
    const c = chonModel(cq, { uuTien });
    if (!c.ok) { khong.push({ id: cq.id, giay: cq.giay, goi: c.goi }); continue; }
    const m = c.model.id;
    theoModel[m] = theoModel[m] || { model: m, ten: c.model.ten, canhQuay: 0, giay: 0, gia: 0 };
    theoModel[m].canhQuay++;
    theoModel[m].giay += cq.giay || 5;
    theoModel[m].gia = round(theoModel[m].gia + c.gia, 3);
    tong += c.gia;
    giay += cq.giay || 5;
  }

  return {
    ok: khong.length === 0,
    uuTien, uuTienTen: (UU_TIEN[uuTien] || UU_TIEN['can-bang']).name,
    canhQuay: danhSachCanhQuay.length,
    giay: round(giay, 1),
    phut: round(giay / 60, 2),
    usd: round(tong, 2),
    theoModel: Object.values(theoModel).sort((a, b) => b.gia - a.gia),
    khongDungDuoc: khong,
  };
}

/** So sánh ba hướng ưu tiên để người dùng chọn có căn cứ. */
function soSanhUuTien(danhSachCanhQuay) {
  return Object.keys(UU_TIEN).map((u) => {
    const d = duToan(danhSachCanhQuay, { uuTien: u });
    return { uuTien: u, ten: UU_TIEN[u].name, usd: d.usd, theoModel: d.theoModel.map((x) => `${x.ten}×${x.canhQuay}`) };
  });
}

function lietKe() {
  return Object.values(MODEL).map((m) => ({
    id: m.id, ten: m.ten, theManh: m.theManh, giayToiDa: m.giayToiDa,
    giaMoi5Giay: m.giaMoi5Giay, diemChatLuong: m.diemChatLuong, note: m.note,
  }));
}

module.exports = { MODEL, UU_TIEN, chonModel, duToan, soSanhUuTien, lietKe };
