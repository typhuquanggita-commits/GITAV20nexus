'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BẢNG PHÂN CẢNH (STORYBOARD) — vẽ được ngay, không cần API nào
 * ═══════════════════════════════════════════════════════════════════════════
 *  Trước khi tiêu tiền dựng video, đạo diễn phải NHÌN THẤY phim. Bảng phân
 *  cảnh vẽ bằng SVG ngay trong tiến trình: đúng khuôn hình, đúng cỡ cảnh,
 *  đúng vị trí nhân vật, đúng tông màu theo thời điểm trong ngày, có lời
 *  thoại và thời lượng.
 *
 *  Đây không phải hình minh hoạ cho vui: nó là bản nháp phim. Xem hết bảng
 *  phân cảnh là biết nhịp có ổn không, cảnh nào thừa, chỗ nào hụt — biết
 *  trước khi trả một đồng nào cho mô hình dựng video.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { fnv1a, round } = require('../utils');

/** Tông màu theo thời điểm — cùng bảng với phần ánh sáng trong prompt. */
const TONG_MAU = {
  'Bình minh': { nen: '#f6d9c9', xa: '#e9b79a', gan: '#8c6552', troi: '#ffd9b8' },
  'Sáng sớm': { nen: '#dfe9f0', xa: '#b9cdda', gan: '#5d6f7c', troi: '#e8f2f8' },
  'Buổi sáng': { nen: '#eaf2e2', xa: '#c4d8b4', gan: '#5e7250', troi: '#f4fbea' },
  'Buổi trưa': { nen: '#f5f1dd', xa: '#ded6b0', gan: '#6f6a50', troi: '#fffdf0' },
  'Buổi chiều': { nen: '#f7e4c8', xa: '#e2c194', gan: '#7d6644', troi: '#ffeccb' },
  'Chiều muộn': { nen: '#f6d9a8', xa: '#dbab7a', gan: '#7a5a34', troi: '#ffe2ae' },
  'Hoàng hôn': { nen: '#f3c08f', xa: '#d98f5a', gan: '#6b3f28', troi: '#ffcf9c' },
  'Buổi tối': { nen: '#2b3245', xa: '#3d465e', gan: '#171b26', troi: '#39415a' },
  'Ban đêm': { nen: '#1d2230', xa: '#2c3348', gan: '#0f1219', troi: '#242b3d' },
  'Đêm khuya': { nen: '#151926', xa: '#222839', gan: '#0a0c12', troi: '#1b2032' },
};
const TONG_MAC_DINH = { nen: '#e8eaee', xa: '#c3c8d0', gan: '#5a6270', troi: '#f2f4f8' };

/** Cỡ cảnh quyết định người trong khung to đến đâu và cắt tới đâu. */
const KHUNG = {
  'thiet-lap': { caoNguoi: 0.30, doi: 0.68, catTu: 'toan-than' },
  'toan-canh': { caoNguoi: 0.42, doi: 0.64, catTu: 'toan-than' },
  'trung-canh': { caoNguoi: 0.78, doi: 0.55, catTu: 'nua-nguoi' },
  'can-canh': { caoNguoi: 1.35, doi: 0.46, catTu: 'vai' },
  'dac-ta': { caoNguoi: 2.40, doi: 0.40, catTu: 'mat' },
};

const esc = (s) => String(s ?? '')
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

/** Bóng người: hình dáng khác nhau theo tuổi và giới, vẽ tất định. */
function veNguoi(x, yChan, cao, mau, { gioiTinh = 'nam', tuoi = 30, quay = false } = {}) {
  const dauR = cao * 0.115;
  const yDau = yChan - cao + dauR;
  const vaiW = cao * (gioiTinh === 'nữ' ? 0.22 : 0.25) * (tuoi && tuoi < 14 ? 0.85 : 1);
  const than = [
    `M ${x - vaiW} ${yChan}`,
    `L ${x - vaiW * 0.92} ${yDau + dauR * 1.5}`,
    `Q ${x} ${yDau + dauR * 0.9} ${x + vaiW * 0.92} ${yDau + dauR * 1.5}`,
    `L ${x + vaiW} ${yChan} Z`,
  ].join(' ');
  const cong = tuoi >= 60 ? `<path d="M ${x - vaiW * 0.5} ${yDau + dauR * 1.9} Q ${x} ${yDau + dauR * 2.6} ${x + vaiW * 0.5} ${yDau + dauR * 1.9}" fill="none" stroke="${mau}" stroke-width="${cao * 0.012}" opacity=".5"/>` : '';
  const toc = gioiTinh === 'nữ'
    ? `<path d="M ${x - dauR * 1.05} ${yDau} a ${dauR * 1.05} ${dauR * 1.15} 0 0 1 ${dauR * 2.1} 0 l 0 ${dauR * 0.9} l -${dauR * 0.4} -${dauR * 0.35} l -${dauR * 1.3} 0 l -${dauR * 0.4} ${dauR * 0.35} Z" fill="${mau}" opacity=".85"/>`
    : '';
  return `<g${quay ? ` transform="translate(${2 * x},0) scale(-1,1)"` : ''}>`
    + `<circle cx="${x}" cy="${yDau}" r="${dauR}" fill="${mau}"/>${toc}`
    + `<path d="${than}" fill="${mau}"/>${cong}</g>`;
}

/**
 * Vẽ một khung phân cảnh.
 * @param {object} canhQuay
 * @param {Array} hoSoNhanVat
 * @param {object} o {rong, cao, soThuTu, tong}
 */
function veKhung(canhQuay, hoSoNhanVat, { rong = 640, cao = 360, soThuTu = 1, tong = 1 } = {}) {
  const tong_ = TONG_MAU[canhQuay.thoiDiem] || TONG_MAC_DINH;
  const k = KHUNG[canhQuay.co] || KHUNG['trung-canh'];
  const duoiKhung = cao * 0.80;          // dải chữ dưới khung hình
  const chanTroi = duoiKhung * k.doi;
  const h = fnv1a(canhQuay.id);

  const nguoi = (canhQuay.nhanVat || [])
    .map((id) => hoSoNhanVat.find((x) => x.id === id))
    .filter(Boolean);

  // Xếp người trong khung: một người thì lệch theo quy tắc một phần ba.
  const viTri = nguoi.length === 1 ? [h % 2 === 0 ? 0.38 : 0.62]
    : nguoi.length === 2 ? [0.33, 0.67]
      : nguoi.map((_, i) => 0.18 + (i * 0.64) / Math.max(1, nguoi.length - 1));

  const nguoiSvg = nguoi.map((n, i) => {
    const caoNguoi = duoiKhung * 0.55 * k.caoNguoi;
    const yChan = k.catTu === 'toan-than' ? chanTroi + duoiKhung * 0.30 : duoiKhung + caoNguoi * 0.05;
    return veNguoi(rong * viTri[i], yChan, caoNguoi, tong_.gan, {
      gioiTinh: n.gioiTinh, tuoi: n.tuoi, quay: nguoi.length === 2 && i === 1,
    });
  }).join('');

  const nhan = `${canhQuay.coTen} · ${canhQuay.chuyenDongTen}`;
  const loi = canhQuay.thoai ? canhQuay.thoai.loi : null;
  const loiCat = loi && loi.length > 74 ? `${loi.slice(0, 74)}…` : loi;

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${rong} ${cao}" width="${rong}" height="${cao}" role="img" aria-label="${esc(canhQuay.id)} ${esc(nhan)}">
  <defs>
    <linearGradient id="troi-${esc(canhQuay.id)}" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="${tong_.troi}"/><stop offset="100%" stop-color="${tong_.nen}"/>
    </linearGradient>
  </defs>
  <rect width="${rong}" height="${cao}" fill="#0d0f14"/>
  <rect x="0" y="0" width="${rong}" height="${duoiKhung}" fill="url(#troi-${esc(canhQuay.id)})"/>
  <rect x="0" y="${chanTroi}" width="${rong}" height="${duoiKhung - chanTroi}" fill="${tong_.xa}"/>
  <rect x="0" y="${duoiKhung - (duoiKhung - chanTroi) * 0.22}" width="${rong}" height="${(duoiKhung - chanTroi) * 0.22}" fill="${tong_.gan}" opacity=".28"/>
  ${nguoiSvg}
  <g stroke="#ffffff" stroke-width="1" opacity=".16" fill="none">
    <line x1="${rong / 3}" y1="0" x2="${rong / 3}" y2="${duoiKhung}"/>
    <line x1="${(rong * 2) / 3}" y1="0" x2="${(rong * 2) / 3}" y2="${duoiKhung}"/>
    <line x1="0" y1="${duoiKhung / 3}" x2="${rong}" y2="${duoiKhung / 3}"/>
    <line x1="0" y1="${(duoiKhung * 2) / 3}" x2="${rong}" y2="${(duoiKhung * 2) / 3}"/>
  </g>
  <rect x="0" y="${duoiKhung}" width="${rong}" height="${cao - duoiKhung}" fill="#11141c"/>
  <text x="14" y="${duoiKhung + 22}" font-family="system-ui,sans-serif" font-size="13" fill="#e6e9f0" font-weight="600">${esc(canhQuay.id)} · ${esc(nhan)}</text>
  <text x="${rong - 14}" y="${duoiKhung + 22}" text-anchor="end" font-family="system-ui,sans-serif" font-size="13" fill="#9aa3b5">${canhQuay.giay}s · ${soThuTu}/${tong}</text>
  <text x="14" y="${duoiKhung + 42}" font-family="system-ui,sans-serif" font-size="11.5" fill="#8e97a8">${esc(canhQuay.boiCanh)} · ${esc(canhQuay.thoiDiem)}${canhQuay.modelTen ? ` · ${esc(canhQuay.modelTen)}` : ''}</text>
  ${loiCat ? `<text x="14" y="${duoiKhung + 60}" font-family="system-ui,sans-serif" font-size="12" fill="#ffd9a0" font-style="italic">“${esc(loiCat)}”</text>` : ''}
</svg>`;
}

/** Vẽ cả bảng phân cảnh. */
function veBang(canhQuay, hoSoNhanVat, opts = {}) {
  return canhQuay.map((c, i) => ({
    id: c.id,
    svg: veKhung(c, hoSoNhanVat, { ...opts, soThuTu: i + 1, tong: canhQuay.length }),
  }));
}

module.exports = { veKhung, veBang, veNguoi, TONG_MAU, KHUNG };
