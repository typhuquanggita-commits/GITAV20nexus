'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  DỊCH VỤ LÀM PHIM — cửa duy nhất, và trật tự bắt buộc
 * ═══════════════════════════════════════════════════════════════════════════
 *  Một quy tắc chi phối toàn bộ: KHÔNG tiêu tiền trước khi duyệt được nhịp
 *  phim. Nên đường đi chia làm ba nấc rõ ràng, nấc sau chỉ mở khi nấc trước
 *  đạt:
 *
 *    1. chuanBi()   đọc kịch bản → hồ sơ nhân vật → phân cảnh → dự toán → soát
 *                   Không gọi API nào. Không tốn đồng nào.
 *    2. dungNhap()  đường tiếng thật + bảng phân cảnh + phim nháp xem được
 *                   Vẫn không tốn đồng nào.
 *    3. dungThat()  gọi mô hình dựng video — chỉ chạy khi soát ĐẠT, dưới trần
 *                   chi tiêu, và có xác nhận tay.
 *
 *  Toàn bộ tiếng trong phim đi qua đúng lớp pháp lý của phần giọng nói: có
 *  đóng dấu AI, có nhật ký, có công bố.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const cfg = require('../config');
const L = require('../logger');
const { id: newId, round, sha256 } = require('../utils');
const { docKichBan } = require('./screenplay');
const { dungHoSo } = require('./characters');
const { phanCanhQuay, catCanhQuay, GIAY_TOI_DA } = require('./shots');
const { duToan, soSanhUuTien, lietKe, chonModel } = require('./models');
const { soat } = require('./qc');
const { veBang } = require('./storyboard');
const A = require('./assemble');
const { CongVideo } = require('./providers');
const { DISCLOSURE } = require('../voice/compliance');

class FilmService {
  /**
   * @param {object} o
   * @param {object} o.voice  VoiceService — dựng đường tiếng và giữ lớp pháp lý
   * @param {object} [o.db]   Database để lưu dự án
   * @param {object} [o.llm]  LLMRouter — chỉ dùng để LÀM GIÀU, không bắt buộc
   * @param {object} [o.bus]  bus sự kiện
   */
  constructor({ voice, db = null, llm = null, bus = null } = {}) {
    this.voice = voice;
    this.llm = llm;
    this.bus = bus;
    this.cong = new CongVideo();
    this.repo = db ? db.collection('film_projects', { indexes: ['trangThai'] }) : null;
    this.duAn = new Map();
    if (this.repo) for (const d of this.repo.all()) this.duAn.set(d.id, d);
    this.stats = { chuanBi: 0, nhap: 0, that: 0, tuChoi: 0, usd: 0 };
  }

  /** ── NẤC 1: TIỀN KỲ — không gọi API nào ──────────────────────────────── */
  chuanBi(kichBanText, { uuTien = cfg.FILM.uuTien, phongCach = null, nganSachUsd = null, ghiDeNhanVat = {}, tuCat = true } = {}) {
    this.stats.chuanBi++;
    const kb = docKichBan(kichBanText);
    if (!kb.ok) return kb;

    const hs = dungHoSo(kb, { ghiDe: ghiDeNhanVat });
    let pc = phanCanhQuay(kb, hs.nhanVat, { uuTien, phongCach });

    // Cảnh quá dài thì cắt sẵn — để người dùng không phải tự làm việc máy làm được.
    if (tuCat) {
      const moi = [];
      let daCat = 0;
      for (const c of pc.canhQuay) {
        if (c.giay > GIAY_TOI_DA) { moi.push(...catCanhQuay(c)); daCat++; } else moi.push(c);
      }
      if (daCat) {
        // Chọn lại mô hình cho các mảnh vừa cắt.
        for (const c of moi) {
          if (!c.catTu) continue;
          const m = chonModel(c, { uuTien });
          c.model = m.ok ? m.model.id : null;
          c.modelTen = m.ok ? m.model.ten : null;
          c.giaDuTinh = m.ok ? m.gia : 0;
          c.viChonModel = m.ok ? m.vi : m.goi;
        }
        pc = { ...pc, canhQuay: moi, soCanhQuay: moi.length, daCat };
      }
    }

    const dt = duToan(pc.canhQuay, { uuTien });
    const q = soat({ kichBan: kb, hoSoNhanVat: hs.nhanVat, canhQuay: pc.canhQuay, duToan: dt, nganSachUsd });
    const giay = round(pc.canhQuay.reduce((a, c) => a + c.giay, 0), 1);

    const duAn = {
      id: newId('PHIM'),
      taoLuc: Date.now(),
      trangThai: q.ok ? 'SẴN_SÀNG_DỰNG' : 'CẦN_SỬA',
      tieuDe: kb.tieuDe,
      theLoai: kb.theLoai,
      tacGia: kb.tacGia,
      uuTien,
      kichBanHash: sha256(kichBanText).slice(0, 16),
      kichBan: kb,
      nhanVat: hs.nhanVat,
      canhQuay: pc.canhQuay,
      giay, phut: round(giay / 60, 2),
      duToan: dt,
      qc: q,
      soSanhGia: soSanhUuTien(pc.canhQuay),
      canhBaoPhanCanh: pc.canhBao,
      nhap: null,
      that: null,
    };
    if (giay > cfg.FILM.tranGiay) {
      return { ok: false, error: 'PHIM_QUÁ_DÀI', giay, tranGiay: cfg.FILM.tranGiay,
        goi: 'Cắt kịch bản thành nhiều tập, hoặc nâng FILM_MAX_SECONDS.' };
    }

    this._luu(duAn);
    this.bus?.safeEmit?.('film:prepared', { id: duAn.id, canhQuay: pc.canhQuay.length, usd: dt.usd, qc: q.diem });
    return { ok: true, ...this._tomTat(duAn), duAn: duAn.id };
  }

  /** ── NẤC 2: BẢN NHÁP — đường tiếng thật + phim nháp xem được ──────────── */
  async dungNhap(duAnId, { preset = 'phat-thanh', keoTheoTieng = true } = {}) {
    const d = this.duAn.get(duAnId);
    if (!d) return { ok: false, error: 'KHÔNG_TÌM_THẤY_DỰ_ÁN', duAn: duAnId };
    this.stats.nhap++;

    // Gán giọng cho từng nhân vật: nam/nữ theo hồ sơ, tất định theo mã nhân vật.
    for (const nv of d.nhanVat) {
      if (nv.giongNoi) continue;
      const ds = this.voice.listVoices({ gender: nv.gioiTinh, limit: 500 }).items;
      if (!ds.length) continue;
      const h = Math.abs(Number.parseInt(sha256(nv.id).slice(0, 8), 16));
      nv.giongNoi = ds[h % ds.length].voiceId;
    }

    const t0 = Date.now();
    let tieng = null;
    if (keoTheoTieng) {
      tieng = await A.dungDuongTieng(d.canhQuay, d.nhanVat, { voice: this.voice, preset });
      if (!tieng.ok) return tieng;
    }

    const bang = veBang(d.canhQuay, d.nhanVat, { rong: 960, cao: 540 });
    const html = A.dungPhimNhap({
      tieuDe: d.tieuDe, canhQuay: d.canhQuay, hoSoNhanVat: d.nhanVat,
      audioBase64: tieng ? tieng.wav.toString('base64') : null,
      duToan: d.duToan, qc: d.qc,
    });

    d.nhap = {
      luc: Date.now(), ms: Date.now() - t0,
      khung: bang.length,
      tiengGiay: tieng ? tieng.giay : 0,
      tiengByte: tieng ? tieng.wav.length : 0,
      cauThoai: tieng ? tieng.doan.length : 0,
      doVang: tieng ? tieng.master.after.lufs : null,
      giongNoi: d.nhanVat.map((n) => ({ nhanVat: n.ten, voiceId: n.giongNoi })),
    };
    d.trangThai = d.trangThai === 'CẦN_SỬA' ? 'CẦN_SỬA' : 'ĐÃ_CÓ_BẢN_NHÁP';
    this._luu(d);
    this.bus?.safeEmit?.('film:draft', { id: d.id, ms: d.nhap.ms });

    return {
      ok: true, duAn: d.id, tieuDe: d.tieuDe,
      ...d.nhap,
      bangPhanCanh: bang,
      duongTiengWav: tieng ? tieng.wav : null,
      phimNhapHtml: html,
      edl: A.dungEDL(d.canhQuay, { tieuDe: d.tieuDe }),
      ghepPhim: A.dungKichBanGhep(d.canhQuay, { tenPhim: d.id.toLowerCase(), chatLuong: cfg.FILM.chatLuong }),
      disclosure: DISCLOSURE,
    };
  }

  /** ── NẤC 3: DỰNG THẬT — có chốt chi tiêu ─────────────────────────────── */
  async dungThat(duAnId, { xacNhan = false, tranUsd = null, chiCanhQuay = null } = {}) {
    const d = this.duAn.get(duAnId);
    if (!d) return { ok: false, error: 'KHÔNG_TÌM_THẤY_DỰ_ÁN', duAn: duAnId };

    if (!d.qc.ok) {
      this.stats.tuChoi++;
      return { ok: false, error: 'CHƯA_QUA_SOÁT_CHẤT_LƯỢNG', chan: d.qc.chan,
        loi: d.qc.loi.filter((x) => x.muc === 'CHẶN'),
        goi: 'Sửa các lỗi chặn rồi chuẩn bị lại — dựng lúc này là đốt tiền vào cảnh hỏng.' };
    }

    const danhSach = chiCanhQuay ? d.canhQuay.filter((c) => chiCanhQuay.includes(c.id)) : d.canhQuay;
    if (!danhSach.length) return { ok: false, error: 'KHÔNG_CÓ_CẢNH_NÀO_ĐỂ_DỰNG' };
    const dt = duToan(danhSach, { uuTien: d.uuTien });

    const chot = this.cong.chotChiTieu({ duToan: dt, xacNhan, tranUsd });
    if (!chot.ok) { this.stats.tuChoi++; return { ...chot, duAn: d.id, duToan: dt }; }

    this.stats.that++;
    const ketQua = [];
    let usd = 0;
    for (const c of danhSach) {
      const r = await this.cong.that.dung(c);
      ketQua.push(r);
      if (r.ok) usd = round(usd + (r.usd || 0), 3);
      else L.warn(`Cảnh ${c.id} dựng hỏng: ${r.loi}`);
    }
    this.stats.usd = round(this.stats.usd + usd, 3);

    d.that = {
      luc: Date.now(), usd,
      xong: ketQua.filter((r) => r.ok).length,
      hong: ketQua.filter((r) => !r.ok).length,
      clip: ketQua.filter((r) => r.ok).map((r) => ({ canhQuay: r.idCanhQuay, url: r.url, model: r.model, usd: r.usd })),
      loi: ketQua.filter((r) => !r.ok).map((r) => ({ canhQuay: r.idCanhQuay, loi: r.loi })),
    };
    d.trangThai = d.that.hong ? 'DỰNG_THIẾU' : 'ĐÃ_DỰNG_XONG';
    this._luu(d);
    this.bus?.safeEmit?.('film:rendered', { id: d.id, usd, xong: d.that.xong, hong: d.that.hong });

    return { ok: true, duAn: d.id, ...d.that, duToan: dt, disclosure: DISCLOSURE };
  }

  /** ── Tra cứu ─────────────────────────────────────────────────────────── */
  layDuAn(id) {
    const d = this.duAn.get(id);
    return d ? { ok: true, ...d } : { ok: false, error: 'KHÔNG_TÌM_THẤY_DỰ_ÁN', duAn: id };
  }

  danhSach({ limit = 30 } = {}) {
    const ds = [...this.duAn.values()].sort((a, b) => b.taoLuc - a.taoLuc).slice(0, limit);
    return { ok: true, tong: this.duAn.size, items: ds.map((d) => this._tomTat(d)) };
  }

  xoaDuAn(id) {
    if (!this.duAn.has(id)) return { ok: false, error: 'KHÔNG_TÌM_THẤY_DỰ_ÁN', duAn: id };
    this.duAn.delete(id);
    if (this.repo) this.repo.delete(id);
    return { ok: true, duAn: id };
  }

  _tomTat(d) {
    return {
      duAn: d.id, tieuDe: d.tieuDe, theLoai: d.theLoai, trangThai: d.trangThai,
      taoLuc: d.taoLuc,
      canh: d.kichBan.canh.length, canhQuay: d.canhQuay.length,
      nhanVat: d.nhanVat.map((n) => ({ id: n.id, ten: n.ten, gioiTinh: n.gioiTinh, tuoi: n.tuoi, netNgoaiHinh: n.netNgoaiHinh, maKhoa: n.maKhoa })),
      giay: d.giay, phut: d.phut,
      duToan: d.duToan, soSanhGia: d.soSanhGia,
      qc: { ok: d.qc.ok, diem: d.qc.diem, xep: d.qc.xep, chan: d.qc.chan, nang: d.qc.nang, nhe: d.qc.nhe, ketLuan: d.qc.ketLuan, loi: d.qc.loi },
      coBanNhap: !!d.nhap, coBanThat: !!d.that,
    };
  }

  _luu(d) {
    this.duAn.set(d.id, d);
    if (this.repo) this.repo.put(d);
  }

  status() {
    const theoTrangThai = Object.create(null);
    for (const d of this.duAn.values()) theoTrangThai[d.trangThai] = (theoTrangThai[d.trangThai] || 0) + 1;
    return {
      duAn: this.duAn.size,
      theoTrangThai,
      cong: this.cong.trangThai(),
      moHinh: lietKe(),
      gioiHan: { tranGiay: cfg.FILM.tranGiay, tranChiTieuUsd: cfg.FILM.tranChiTieuUsd, chatLuong: cfg.FILM.chatLuong, uuTien: cfg.FILM.uuTien },
      lamGiauBangLLM: !!this.llm,
      stats: { ...this.stats },
    };
  }
}

module.exports = { FilmService };
