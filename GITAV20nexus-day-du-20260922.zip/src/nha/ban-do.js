'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BẢN ĐỒ LỘ TRÌNH — GITAmath V20 Nexus
 * ═══════════════════════════════════════════════════════════════════════════
 *  SỬA HƯỚNG.
 *  Bản trước dựng bản đồ theo hướng nếp nhà và giá trị gia đình. Sai hướng:
 *  đây là hệ thống dạy TOÁN và TIẾNG ANH, không phải sản phẩm tư vấn gia
 *  đình. Mọi phòng dưới đây đã được thay bằng một ĐÍCH HỌC THẬT, và mỗi đích
 *  ấy đều quy về một hệ chuẩn hoặc một chương trình có thật.
 *
 *  BA TẦNG CỦA BẢN ĐỒ.
 *    MÁI   — Chọn đích. Một đích duy nhất tại một thời điểm. Chọn xong thì cả
 *            bản đồ bên dưới xoay theo đích ấy.
 *    PHÒNG — Tám đích: hai nền tảng (Toán phổ thông, Tiếng Anh nền) và sáu
 *            hệ chuẩn hoặc hướng chuyên. Mỗi phòng là MỘT TRỤC THẲNG.
 *    NỀN   — Luyện hằng ngày. Nơi mọi đích biến thành bài làm trong hôm nay.
 *
 *  VỆ TINH LÀ NĂNG LỰC, KHÔNG PHẢI PHÒNG.
 *  Mười một vệ tinh quanh bản đồ là những NĂNG LỰC mà các phòng nuôi lên —
 *  tốc độ làm bài, đọc hiểu, phát âm, xử lý số liệu... Chúng không bấm vào
 *  được; chúng sáng lên theo việc đã làm.
 * ═══════════════════════════════════════════════════════════════════════════
 */

/** Mười một năng lực quanh bản đồ. Sáng dần theo tiến độ của phòng nuôi chúng. */
const VE_TINH = [
  { id: 'nen-tang-toan', ten: 'Nền tảng toán', phu: 'Chắc gốc từng lớp', mau: 'lam' },
  { id: 'tu-duy-logic', ten: 'Tư duy logic', phu: 'Suy luận nhiều bước', mau: 'tim' },
  { id: 'xu-ly-so-lieu', ten: 'Xử lý số liệu', phu: 'Đọc bảng và biểu đồ', mau: 'ngoc' },
  { id: 'toc-do-lam-bai', ten: 'Tốc độ làm bài', phu: 'Đủ giờ cho đề thật', mau: 'cam' },
  { id: 'doc-hieu', ten: 'Đọc hiểu', phu: 'Nắm ý và suy ra', mau: 'luc' },
  { id: 'tu-vung', ten: 'Từ vựng', phu: 'Vốn từ theo bậc', mau: 'tim' },
  { id: 'ngu-phap', ten: 'Ngữ pháp', phu: 'Viết đúng cấu trúc', mau: 'lam' },
  { id: 'phat-am', ten: 'Phát âm', phu: 'Nghe rõ và nói rõ', mau: 'hong' },
  { id: 'viet-hoc-thuat', ten: 'Viết học thuật', phu: 'Bố cục và lập luận', mau: 'ngoc' },
  { id: 'nhin-that', ten: 'Nhìn thật', phu: 'Biết mình đang ở đâu', mau: 'lam' },
  { id: 'nhip-luyen', ten: 'Nhịp luyện', phu: 'Đều đặn mỗi ngày', mau: 'luc' },
];

const VE_TINH_INDEX = new Map(VE_TINH.map((v) => [v.id, v]));

/**
 * Mười phòng.
 *   chuan : hệ chuẩn mà phòng này nhắm tới, hoặc null nếu là nền tảng
 *   mon   : toán, tiếng Anh, hay cả hai
 *   vai   : vai được phép mở
 *   nuoi  : những năng lực phòng này nuôi lên
 */
const PHONG = [
  {
    id: 'chon-dich',
    ten: 'Chọn đích',
    phu: 'Một đích tại một thời điểm',
    viTri: 'mai',
    mau: 'lam',
    chuan: null,
    mon: ['toan', 'tieng-anh'],
    // Chốt đích kéo theo cam kết thời gian và chi phí, nên đây là quyết định
    // của phụ huynh. Học viên thấy kết quả trên bản đồ nhưng không tự chốt.
    vai: ['phu-huynh'],
    moTa: 'Chốt một đích duy nhất, có mốc thời gian và có điểm mục tiêu, để cả lộ trình bên dưới quy về đó.',
    nuoi: ['nhin-that'],
  },
  {
    id: 'toan-pho-thong',
    ten: 'Toán phổ thông',
    phu: 'Lớp 1 đến lớp 12',
    viTri: 'phong',
    mau: 'lam',
    chuan: null,
    mon: ['toan'],
    vai: ['hoc-vien', 'phu-huynh'],
    moTa: 'Chắc gốc theo đúng lớp đang học, vá đúng chỗ hổng trước khi đi tiếp.',
    nuoi: ['nen-tang-toan', 'nhin-that'],
  },
  {
    id: 'tieng-anh-nen',
    ten: 'Tiếng Anh nền',
    phu: 'A1 đến C2 theo lớp',
    viTri: 'phong',
    mau: 'luc',
    chuan: null,
    mon: ['tieng-anh'],
    vai: ['hoc-vien', 'phu-huynh'],
    moTa: 'Xây bốn kỹ năng theo bậc CEFR ứng với lớp, không nhảy cóc sang luyện thi.',
    nuoi: ['tu-vung', 'ngu-phap', 'phat-am'],
  },
  {
    id: 'hsa',
    ten: 'HSA 1300',
    phu: 'Đánh giá năng lực ĐHQG Hà Nội',
    viTri: 'phong',
    mau: 'tim',
    chuan: 'hsa',
    mon: ['toan', 'tieng-anh'],
    vai: ['hoc-vien', 'phu-huynh'],
    moTa: 'Luyện phần Toán và xử lý số liệu của HSA, đo bằng chính cấu trúc đề thật.',
    nuoi: ['xu-ly-so-lieu', 'toc-do-lam-bai'],
  },
  {
    id: 'tsa',
    ten: 'TSA 100',
    phu: 'Đánh giá tư duy Bách khoa Hà Nội',
    viTri: 'phong',
    mau: 'ngoc',
    chuan: 'tsa',
    mon: ['toan', 'tieng-anh'],
    vai: ['hoc-vien', 'phu-huynh'],
    moTa: 'Luyện tư duy logic và đọc hiểu theo đúng nhịp tám mươi câu trong một trăm ba mươi phút.',
    nuoi: ['tu-duy-logic', 'doc-hieu', 'toc-do-lam-bai'],
  },
  {
    id: 'spt',
    ten: 'SPT 1200',
    phu: 'Năng lực chuyên biệt ĐHQG TP.HCM',
    viTri: 'phong',
    mau: 'cam',
    chuan: 'spt',
    mon: ['toan', 'tieng-anh'],
    vai: ['hoc-vien', 'phu-huynh'],
    moTa: 'Luyện phần Toán tư duy và phần Tiếng Anh của SPT, theo trọng số thật của từng phần.',
    nuoi: ['tu-duy-logic', 'tu-vung'],
  },
  {
    id: 'sat',
    ten: 'SAT 1600',
    phu: 'Digital SAT chuẩn College Board',
    viTri: 'phong',
    mau: 'lam',
    chuan: 'sat',
    mon: ['toan', 'tieng-anh'],
    vai: ['hoc-vien', 'phu-huynh'],
    moTa: 'Luyện Math và Reading and Writing theo dạng thích ứng hai mô-đun.',
    nuoi: ['doc-hieu', 'toc-do-lam-bai', 'ngu-phap'],
  },
  {
    id: 'ielts',
    ten: 'IELTS 9.0',
    phu: 'Bốn kỹ năng chuẩn Academic',
    viTri: 'phong',
    mau: 'hong',
    chuan: 'ielts',
    mon: ['tieng-anh'],
    vai: ['hoc-vien', 'phu-huynh'],
    moTa: 'Luyện đủ bốn kỹ năng, chấm Writing và Speaking theo đúng bốn tiêu chí chính thức.',
    nuoi: ['viet-hoc-thuat', 'phat-am', 'doc-hieu'],
  },
  {
    id: 'olympiad',
    ten: 'Olympiad',
    phu: 'Học sinh giỏi và thi quốc gia',
    viTri: 'phong',
    mau: 'tim',
    chuan: null,
    mon: ['toan'],
    vai: ['hoc-vien'],
    moTa: 'Bài năm sao nhiều điều kiện, cần đổi bài toán sang dạng khác mới giải được.',
    nuoi: ['tu-duy-logic', 'nen-tang-toan'],
  },
  {
    id: 'luyen-hang-ngay',
    ten: 'Luyện hằng ngày',
    phu: 'Biến đích thành bài của hôm nay',
    viTri: 'nen',
    mau: 'lam',
    chuan: null,
    mon: ['toan', 'tieng-anh'],
    vai: ['hoc-vien', 'phu-huynh'],
    moTa: 'Lấy đúng chỗ yếu nhất của đích đang theo và biến nó thành bài làm trong hôm nay.',
    nuoi: ['nhip-luyen', 'toc-do-lam-bai'],
  },
];

const PHONG_INDEX = new Map(PHONG.map((p) => [p.id, p]));

/** Bốn vai dùng hệ thống. Vai quyết định phòng nào mở, không quyết định nội dung. */
const VAI = [
  { id: 'hoc-vien', ten: 'Học viên', moTa: 'Người đi từng bước và tự làm được nhiều hơn mỗi ngày.' },
  { id: 'phu-huynh', ten: 'Phụ huynh', moTa: 'Người chọn đích và theo dõi tiến độ thật của con.' },
  { id: 'giao-vien', ten: 'Giáo viên', moTa: 'Người dạy phần chuyên môn, bám đúng bước hiện tại.' },
  { id: 'co-van', ten: 'Cố vấn', moTa: 'Người đồng hành, nhìn đúng chỗ học viên đang đứng.' },
];

const VAI_INDEX = new Map(VAI.map((v) => [v.id, v]));

function phongCuaVai(vaiId) {
  if (!VAI_INDEX.has(vaiId)) return [];
  return PHONG.filter((p) => p.vai.includes(vaiId));
}

function moDuoc(vaiId, phongId) {
  const p = PHONG_INDEX.get(phongId);
  return !!(p && p.vai.includes(vaiId));
}

/** Những phòng nhắm tới một hệ chuẩn — dùng để nối bản đồ với ma trận đa tầng. */
function phongTheoChuan(chuanId) {
  return PHONG.filter((p) => p.chuan === chuanId);
}

module.exports = {
  PHONG, PHONG_INDEX, VE_TINH, VE_TINH_INDEX, VAI, VAI_INDEX,
  phongCuaVai, moDuoc, phongTheoChuan,
};
