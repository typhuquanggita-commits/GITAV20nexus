'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BẢN GIAO VIỆC — MỘT BƯỚC, BỐN VAI, CÙNG MỘT NGUỒN
 * ═══════════════════════════════════════════════════════════════════════════
 *  VẤN ĐỀ PHẢI CHẶN.
 *  Khách hàng đang ở bước ba, trợ lý AI nói chuyện bước năm, người tư vấn gọi
 *  điện hỏi chuyện bước một, giáo viên AI dạy phần của bước sáu. Bốn người đều
 *  nhiệt tình và mỗi người kéo một hướng — đó là cách nhanh nhất làm khách
 *  hàng bỏ cuộc, và không ai trong bốn người thấy mình sai ở đâu.
 *
 *  CÁCH CHẶN.
 *  Cả bốn bản giao việc dưới đây đều nhận VÀO ĐÚNG MỘT THỨ: kết quả của
 *  `truc.hienThi`. Không hàm nào trong tệp này được đọc `truc-noi-dung`. Nhờ
 *  vậy bốn vai không thể lệch nhau, vì không có chỗ nào để lệch — và cũng
 *  không vai nào lộ được bước sau, vì thứ chúng nhận vào đã bị cắt sẵn.
 *
 *  Ràng buộc này không nằm ở lời hứa: kiểm thử dựng cả bốn bản ở mọi bước của
 *  mọi trục, rồi soi từng bản bằng chính phép soi rò rỉ của động cơ.
 *
 *  `chiDan` LÀ HÀNG RÀO CHO MÔ HÌNH.
 *  Trợ lý AI và giáo viên AI là mô hình sinh văn bản, nên phải có câu lệnh nói
 *  rõ: chỉ được bàn bước hiện tại; ai hỏi bước sau thì trả lời là bước sau mở
 *  khi bước này xong. Không có hàng rào ấy thì mô hình sẽ tự nhiệt tình kể
 *  trước cả lộ trình, và luật không xem trước vỡ ngay ở chỗ khó thấy nhất.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const NHAC_KHONG_XEM_TRUOC = 'Chỉ nói về bước đang làm. Nếu người dùng hỏi các bước sau, '
  + 'trả lời rằng bước sau sẽ mở ngay khi bước này xong, và không mô tả nội dung bước sau '
  + 'dù chỉ một phần.';

/** Câu mô tả thứ cần nộp, viết cho người đọc chứ không viết cho máy. */
function moTaDauRa(d) {
  if (!d) return 'một kết quả của bước này';
  if (d.kieu === 'so') return `một con số: ${d.nhan}`;
  if (d.kieu === 'anh') return `một tấm ảnh: ${d.nhan}`;
  if (d.kieu === 'dau-tich') return `một xác nhận: ${d.nhan}`;
  if (d.kieu === 'danh-sach') {
    const r = [];
    if (d.toiThieu) r.push(`ít nhất ${d.toiThieu} dòng`);
    if (d.toiDa && d.toiDa !== d.toiThieu) r.push(`nhiều nhất ${d.toiDa} dòng`);
    if (d.toiThieu && d.toiDa && d.toiThieu === d.toiDa) return `một danh sách đúng ${d.toiDa} dòng: ${d.nhan}`;
    return `một danh sách${r.length ? ` (${r.join(', ')})` : ''}: ${d.nhan}`;
  }
  const gioiHan = d.toiDa ? ` (không quá ${d.toiDa} chữ)` : '';
  return `một câu trả lời viết ra${gioiHan}: ${d.nhan}`;
}

/** Câu nói về chỗ đang đứng, dùng chung cho cả bốn vai. */
function cauViTri(v) {
  if (v.xong) return `Đã đi hết ${v.tong} bước của phòng ${v.phong ? v.phong.ten : v.trucId}.`;
  return `Đang ở bước ${v.viTri} trên ${v.tong}, còn ${v.conLai} bước nữa.`;
}

// ── Bản cho người đang đi ───────────────────────────────────────────────────

/**
 * Bản giao việc cho khách hàng. Đây là thứ hiện trên màn hình.
 * Không có phần xem trước, và cũng không có phần động viên chung chung —
 * người đang đứng trước một việc cụ thể cần biết làm gì, không cần được khen.
 */
function choNguoiDi(v) {
  if (!v) return null;
  if (v.xong || !v.hienTai) {
    return {
      vai: 'nguoi-di',
      tieuDe: `Xong phòng ${v.phong ? v.phong.ten : v.trucId}`,
      viTri: cauViTri(v),
      than: [`Đã đi đủ ${v.tong} bước. Mọi thứ đã nộp đều còn đây, mở ra xem lúc nào cũng được.`],
      canNop: null,
      xongKhi: null,
    };
  }
  const c = v.hienTai;
  return {
    vai: 'nguoi-di',
    tieuDe: c.ten,
    viTri: cauViTri(v),
    than: [c.nhiemVu, `Vì sao có bước này: ${c.viSao}`],
    canNop: moTaDauRa(c.dauRa),
    xongKhi: c.xongKhi,
    phut: c.phut,
  };
}

// ── Bản cho trợ lý AI ───────────────────────────────────────────────────────

/**
 * Bản giao việc cho trợ lý AI đồng hành.
 * Trợ lý giải thích nhiệm vụ và gỡ chỗ vướng — không làm hộ, không chấm điểm.
 */
function choTroLy(v) {
  if (!v) return null;
  const c = v.hienTai;
  const boi = `Học viên đang ở phòng ${v.phong ? v.phong.ten : v.trucId}. ${cauViTri(v)}`;
  if (v.xong || !c) {
    return {
      vai: 'tro-ly',
      boiCanh: boi,
      chiDan: [
        'Phòng này đã đi hết. Cùng người dùng nhìn lại những gì họ đã nộp.',
        'Không gợi ý phòng tiếp theo trừ khi người dùng hỏi thẳng.',
      ].join(' '),
      duocNoi: v.daQua.map((b) => b.ten),
    };
  }
  return {
    vai: 'tro-ly',
    boiCanh: boi,
    buocId: c.id,
    chiDan: [
      `Việc của người dùng ngay lúc này: ${c.nhiemVu}`,
      `Lý do có bước này: ${c.viSao}`,
      `Người dùng cần nộp ${moTaDauRa(c.dauRa)}.`,
      `Coi là xong khi: ${c.xongKhi}`,
      'Giải thích cho rõ, hỏi lại khi chưa hiểu ý người dùng, gỡ đúng chỗ họ vướng.',
      'Không viết hộ câu trả lời của người dùng — việc nộp là việc của họ.',
      NHAC_KHONG_XEM_TRUOC,
    ].join(' '),
    duocNoi: [...v.daQua.map((b) => b.ten), c.ten],
  };
}

// ── Bản cho người tư vấn ────────────────────────────────────────────────────

/**
 * Bản giao việc cho người tư vấn (cố vấn đồng hành).
 * Người tư vấn nói chuyện với cả nhà, nên cần biết nhà đang đứng đâu và nên
 * hỏi gì — chứ không cần biết trước nhà sẽ đi đâu.
 */
function choTuVan(v) {
  if (!v) return null;
  const c = v.hienTai;
  const daLam = v.daQua.length
    ? v.daQua.map((b) => `bước ${b.thuTu} ${b.ten}${b.daNop ? ` (đã nộp: ${b.daNop})` : ''}`).join('; ')
    : 'chưa có bước nào được nộp';
  if (v.xong || !c) {
    return {
      vai: 'tu-van',
      boiCanh: `Phòng ${v.phong ? v.phong.ten : v.trucId} đã xong. Học viên đã làm: ${daLam}.`,
      nenHoi: ['Điều gì trong nhà đã khác đi sau phòng này?', 'Bước nào khó nhất và vì sao?'],
      trach: 'Chỉ nhìn lại, không giục sang phòng khác.',
    };
  }
  return {
    vai: 'tu-van',
    boiCanh: `Phòng ${v.phong ? v.phong.ten : v.trucId}. ${cauViTri(v)} Học viên đã làm: ${daLam}.`,
    buocId: c.id,
    dangVuong: `Bước đang làm là "${c.ten}". Việc cần làm: ${c.nhiemVu}`,
    nenHoi: [
      `Học viên đã bắt tay vào "${c.ten}" chưa, hay còn đang cân nhắc?`,
      `Chỗ nào làm học viên dừng lại lâu nhất ở bước này?`,
      `Đã có ${c.dauRa ? c.dauRa.nhan : 'kết quả'} chưa, và con số đó nói lên điều gì?`,
    ],
    trach: `Bám đúng bước ${v.viTri}. ${NHAC_KHONG_XEM_TRUOC}`,
  };
}

// ── Bản cho giáo viên AI ────────────────────────────────────────────────────

/**
 * Bản giao việc cho giáo viên AI.
 * Giáo viên chỉ dạy KỸ NĂNG mà bước hiện tại đòi hỏi. Dạy rộng hơn là lấn sang
 * bước sau, và đó chính là chỗ lộ lộ trình mà không ai để ý.
 */
function choGiaoVien(v) {
  if (!v) return null;
  const c = v.hienTai;
  if (v.xong || !c) {
    return {
      vai: 'giao-vien',
      boiCanh: `Phòng ${v.phong ? v.phong.ten : v.trucId} đã xong.`,
      dayGi: 'Không dạy thêm. Nếu người học hỏi, cùng xem lại phần đã nộp.',
      chiDan: NHAC_KHONG_XEM_TRUOC,
    };
  }
  const kieu = c.dauRa ? c.dauRa.kieu : 'chu';
  const kyNang = {
    so: 'cách đo và ghi lại một con số cho trung thực',
    chu: 'cách viết một câu ngắn, rõ, không dùng từ chung chung',
    'danh-sach': 'cách tách một ý lớn thành từng dòng riêng, mỗi dòng một việc',
    anh: 'cách ghi lại bằng chứng bằng hình ảnh cho người khác cũng hiểu',
    'dau-tich': 'cách tự đối chiếu với điều kiện xong trước khi xác nhận',
  }[kieu] || 'cách trình bày kết quả cho rõ ràng';
  return {
    vai: 'giao-vien',
    boiCanh: `Phòng ${v.phong ? v.phong.ten : v.trucId}. ${cauViTri(v)}`,
    buocId: c.id,
    dayGi: `Chỉ dạy đúng kỹ năng bước này cần: ${kyNang}.`,
    lienHeViecThat: `Người học đang phải làm: ${c.nhiemVu}`,
    chiDan: [
      'Dạy bằng một ví dụ ngắn rồi để người học tự làm phần của họ.',
      'Không mở rộng sang kỹ năng chưa cần tới.',
      NHAC_KHONG_XEM_TRUOC,
    ].join(' '),
  };
}

/** Dựng cả bốn bản cùng lúc — dùng khi cần chứng minh bốn vai khớp nhau. */
function caBonVai(v) {
  return {
    nguoiDi: choNguoiDi(v),
    troLy: choTroLy(v),
    tuVan: choTuVan(v),
    giaoVien: choGiaoVien(v),
  };
}

module.exports = {
  choNguoiDi, choTroLy, choTuVan, choGiaoVien, caBonVai,
  moTaDauRa, cauViTri, NHAC_KHONG_XEM_TRUOC,
};
