'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  ĐỘNG CƠ TRỤC THẲNG
 * ═══════════════════════════════════════════════════════════════════════════
 *  BA LUẬT, VÀ CẢ BA ĐỀU ĐƯỢC MÁY CƯỠNG CHẾ CHỨ KHÔNG PHẢI QUY ƯỚC.
 *
 *  LUẬT 1 — MỘT ĐƯỜNG, KHÔNG NHÁNH.
 *  Không có hàm nào cho nhảy tới bước bất kỳ. Chỉ có `nop`, và `nop` đẩy đúng
 *  một bước. Người dùng không chọn đường, chỉ bước tiếp.
 *
 *  LUẬT 2 — KHÔNG XEM TRƯỚC.
 *  `hienThi` chỉ trả về những bước đã qua và bước hiện tại. Bước chưa tới
 *  không có tên, không có mô tả, không có gì ngoài số thứ tự. Đây là chỗ dễ
 *  hỏng nhất khi sửa mã về sau, nên có `soiRoRi` soi lại chính kết quả trả về
 *  và kiểm thử chạy phép soi đó ở MỌI trục tại MỌI vị trí.
 *
 *  Vì sao phải chặt tới vậy: cho xem trước là mời người ta đọc lướt hết rồi
 *  bỏ. Người đọc lướt tưởng mình đã hiểu và không làm bước nào; sau đó kết
 *  luận là hệ thống không có tác dụng. Che bước sau không phải để giấu, mà để
 *  giữ cho mỗi bước còn nguyên sức nặng lúc nó tới.
 *
 *  LUẬT 3 — QUA ĐƯỢC BƯỚC LÀ PHẢI NỘP ĐẦU RA.
 *  Không nộp thì không qua. Nhờ vậy tiến độ là thứ đo được, không phải thứ
 *  người dùng tự nhận. Và trợ lý AI luôn có vật thật để bám vào mà nói chuyện.
 *
 *  ĐƯỢC PHÉP BIẾT TRƯỚC ĐÚNG MỘT THỨ: CÒN BAO NHIÊU BƯỚC.
 *  Con số đó là tiến độ, không phải nội dung. Giấu luôn cả nó thì người đi
 *  không biết mình đang ở đoạn nào của đường, và đó mới là bỏ rơi người dùng.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { TRUC_INDEX } = require('./truc-noi-dung');
const { PHONG_INDEX } = require('./ban-do');

/** Độ dài nhỏ nhất của một chuỗi để đem đi soi rò rỉ. Ngắn hơn thì dễ trùng từ thường. */
const DAI_TOI_THIEU_KHI_SOI = 12;

// ── Trạng thái ──────────────────────────────────────────────────────────────

/**
 * Mở một trục. Trả về trạng thái ban đầu — chưa chứa nội dung bước nào.
 * @param {string} trucId
 * @param {number} luc mốc thời gian, truyền vào để kết quả tất định khi kiểm thử
 */
function batDau(trucId, luc = Date.now()) {
  const t = TRUC_INDEX.get(trucId);
  if (!t) return { ok: false, loi: 'KHONG_CO_TRUC', trucId };
  return {
    ok: true,
    trangThai: {
      trucId,
      buoc: 0,
      ketQua: {},
      batDauLuc: luc,
      capNhatLuc: luc,
      xong: false,
    },
  };
}

/** Bước hiện tại của một trạng thái, hoặc null khi đã đi hết trục. */
function buocHienTai(trangThai) {
  const t = TRUC_INDEX.get(trangThai.trucId);
  if (!t) return null;
  return t.chang[trangThai.buoc] || null;
}

// ── Nhận đầu ra ─────────────────────────────────────────────────────────────

/**
 * Kiểm đầu ra có đúng kiểu và đúng ràng buộc của bước không.
 * Trả lời bằng lý do cụ thể chứ không chỉ đúng hay sai, để giao diện nói lại
 * được cho người dùng biết còn thiếu gì.
 */
function kiemDauRa(chang, dauRa) {
  const d = chang.dauRa;
  if (dauRa === undefined || dauRa === null || dauRa === '') {
    return { dat: false, vi: `Bước này cần nộp: ${d.nhan}.` };
  }
  if (d.kieu === 'so') {
    const n = Number(dauRa);
    if (!Number.isFinite(n)) return { dat: false, vi: `${d.nhan} phải là một con số.` };
    return { dat: true, gia: n };
  }
  if (d.kieu === 'chu' || d.kieu === 'anh') {
    const s = String(dauRa).trim();
    if (!s) return { dat: false, vi: `${d.nhan} chưa có nội dung.` };
    if (d.toiDa) {
      const soChu = s.split(/\s+/).filter(Boolean).length;
      if (soChu > d.toiDa) return { dat: false, vi: `${d.nhan} dài ${soChu} chữ, vượt giới hạn ${d.toiDa} chữ.` };
    }
    return { dat: true, gia: s };
  }
  if (d.kieu === 'danh-sach') {
    const ds = Array.isArray(dauRa) ? dauRa.map((x) => String(x).trim()).filter(Boolean) : [];
    if (d.toiThieu && ds.length < d.toiThieu) {
      return { dat: false, vi: `${d.nhan} mới có ${ds.length} dòng, cần ít nhất ${d.toiThieu} dòng.` };
    }
    if (d.toiDa && ds.length > d.toiDa) {
      return { dat: false, vi: `${d.nhan} có ${ds.length} dòng, chỉ được ${d.toiDa} dòng.` };
    }
    if (!ds.length) return { dat: false, vi: `${d.nhan} chưa có dòng nào.` };
    return { dat: true, gia: ds };
  }
  if (d.kieu === 'dau-tich') {
    if (dauRa !== true) return { dat: false, vi: `${d.nhan} chưa được xác nhận.` };
    return { dat: true, gia: true };
  }
  return { dat: false, vi: 'Kiểu đầu ra không nhận ra được.' };
}

/**
 * Nộp đầu ra của bước hiện tại và đi tiếp ĐÚNG MỘT BƯỚC.
 *
 * Không có đường nào khác để tiến. Cố ý không viết hàm nhảy bước: có hàm đó
 * thì sớm muộn sẽ có chỗ gọi nó, và trục thẳng biến thành danh sách mục lục.
 */
function nop(trangThai, dauRa, luc = Date.now()) {
  const t = TRUC_INDEX.get(trangThai.trucId);
  if (!t) return { ok: false, loi: 'KHONG_CO_TRUC' };
  if (trangThai.xong) return { ok: false, loi: 'DA_XONG_TRUC' };
  const chang = t.chang[trangThai.buoc];
  if (!chang) return { ok: false, loi: 'HET_BUOC' };

  const k = kiemDauRa(chang, dauRa);
  if (!k.dat) return { ok: false, loi: 'DAU_RA_CHUA_DAT', vi: k.vi };

  const moi = {
    ...trangThai,
    ketQua: { ...trangThai.ketQua, [chang.id]: { gia: k.gia, luc } },
    buoc: trangThai.buoc + 1,
    capNhatLuc: luc,
  };
  moi.xong = moi.buoc >= t.chang.length;
  return { ok: true, trangThai: moi, vuaXong: chang.id, xongTruc: moi.xong };
}

// ── Hiển thị: chỉ tới chỗ đã đi ─────────────────────────────────────────────

/** Tóm tắt một đầu ra đã nộp, để bước đã qua hiện lại gọn gàng. */
function tomTatDauRa(gia) {
  if (Array.isArray(gia)) return `${gia.length} dòng · ${String(gia[0]).slice(0, 40)}${gia.length > 1 ? '…' : ''}`;
  if (typeof gia === 'number') return String(gia);
  if (gia === true) return 'đã xác nhận';
  return String(gia).slice(0, 60);
}

/**
 * Những gì người đi được phép nhìn thấy NGAY LÚC NÀY.
 *
 * Bước chưa tới chỉ còn lại số thứ tự. Không tên, không mô tả, không gợi ý.
 * Đây là hợp đồng của cả hệ thống: mọi nơi hiển thị đều phải lấy từ đây, không
 * ai được đọc thẳng `truc-noi-dung` rồi tự dựng màn hình.
 */
function hienThi(trangThai) {
  const t = TRUC_INDEX.get(trangThai.trucId);
  if (!t) return null;
  const phong = PHONG_INDEX.get(t.id) || null;
  const k = trangThai.buoc;
  const tong = t.chang.length;

  const daQua = t.chang.slice(0, k).map((c, i) => ({
    thuTu: i + 1,
    id: c.id,
    ten: c.ten,
    daNop: trangThai.ketQua[c.id] ? tomTatDauRa(trangThai.ketQua[c.id].gia) : null,
    luc: trangThai.ketQua[c.id]?.luc || null,
  }));

  const c = t.chang[k] || null;
  const hienTai = c ? {
    thuTu: k + 1,
    id: c.id,
    ten: c.ten,
    nhiemVu: c.nhiemVu,
    viSao: c.viSao,
    dauRa: c.dauRa,
    xongKhi: c.xongKhi,
    phut: c.phut,
  } : null;

  return {
    trucId: t.id,
    tenTruc: t.ten,
    motCau: t.motCau,
    phong: phong ? { id: phong.id, ten: phong.ten, phu: phong.phu, mau: phong.mau, viTri: phong.viTri } : null,
    tong,
    viTri: Math.min(k + 1, tong),
    daQua,
    hienTai,
    // Chỉ còn lại SỐ LƯỢNG. Đây là tiến độ, không phải nội dung.
    conLai: Math.max(0, tong - k - 1),
    xong: !!trangThai.xong,
  };
}

/** Tiến độ gọn, dùng cho bản đồ nhà và cho báo cáo. */
function tienDo(trangThai) {
  const t = TRUC_INDEX.get(trangThai.trucId);
  if (!t) return null;
  const tong = t.chang.length;
  const xong = Math.min(trangThai.buoc, tong);
  return {
    trucId: t.id,
    tong,
    daXong: xong,
    tiLe: tong ? Math.round((xong / tong) * 100) : 0,
    xongTruc: !!trangThai.xong,
  };
}

// ── Cưỡng chế luật không xem trước ──────────────────────────────────────────

/** Những chuỗi đặc trưng của một bước — dùng làm dấu vết khi soi rò rỉ. */
function dauVetCua(chang) {
  return [chang.ten, chang.nhiemVu, chang.viSao, chang.xongKhi, chang.dauRa && chang.dauRa.nhan]
    .filter((s) => typeof s === 'string' && s.length >= DAI_TOI_THIEU_KHI_SOI);
}

/**
 * Gom mọi chuỗi có trong một thứ sắp gửi ra ngoài.
 *
 * Không dùng JSON.stringify để soi: nó nhân đôi dấu gạch chéo ngược và bọc
 * dấu nháy, nên một câu có dấu nháy kép sẽ không khớp với chính nó. Soi hụt
 * kiểu đó tệ hơn không soi, vì nó cho cảm giác đã kiểm rồi.
 */
function goDauThoat(s) {
  // Chuỗi HTML đã thoát dấu thì câu gốc không còn khớp với chính nó: một câu
  // có dấu nháy kép biến thành &quot; và phép soi trượt. Gỡ lại năm thực thể
  // chuẩn trước khi so, nếu không thì soi hụt ở đúng những câu có trích dẫn.
  return String(s)
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&');
}

function gomChuoi(thu) {
  if (typeof thu === 'string') return goDauThoat(thu);
  const ra = [];
  const di = (x) => {
    if (x == null) return;
    if (typeof x === 'string') { ra.push(x); return; }
    if (typeof x === 'number' || typeof x === 'boolean') { ra.push(String(x)); return; }
    if (Array.isArray(x)) { x.forEach(di); return; }
    if (typeof x === 'object') { Object.values(x).forEach(di); }
  };
  di(thu);
  return goDauThoat(ra.join('\n'));
}

/**
 * Soi một thứ sắp gửi ra ngoài xem có lộ bước chưa tới không.
 *
 * Nhận cả đối tượng lẫn chuỗi HTML: mọi đường đi ra ngoài đều phải qua đây,
 * vì rò rỉ thường không nằm ở dữ liệu mà nằm ở chỗ ai đó tiện tay in thêm.
 *
 * @returns {{ro: boolean, buoc?: number, dauVet?: string}}
 */
function soiRoRi(thu, trucId, viTri) {
  const t = TRUC_INDEX.get(trucId);
  if (!t) return { ro: false };
  const chuoi = gomChuoi(thu);
  for (let i = viTri + 1; i < t.chang.length; i++) {
    for (const v of dauVetCua(t.chang[i])) {
      if (chuoi.includes(v)) {
        return { ro: true, buoc: i + 1, dauVet: v.slice(0, 60) };
      }
    }
  }
  return { ro: false };
}

/**
 * Soi chiều ngược lại: bước hiện tại có thật sự hiện ra không.
 *
 * Che bước sau mà che luôn bước hiện tại thì người đi không biết phải làm gì.
 * Hai phép soi này đi thành cặp, thiếu một cái là hỏng theo hướng ngược lại.
 */
function soiThieu(thu, trucId, viTri) {
  const t = TRUC_INDEX.get(trucId);
  if (!t) return { thieu: false };
  const c = t.chang[viTri];
  if (!c) return { thieu: false };
  const chuoi = gomChuoi(thu);
  if (!chuoi.includes(c.ten)) return { thieu: true, phan: 'tên bước' };
  if (!chuoi.includes(c.nhiemVu)) return { thieu: true, phan: 'nhiệm vụ' };
  return { thieu: false };
}

module.exports = {
  batDau, nop, hienThi, tienDo, buocHienTai, kiemDauRa,
  soiRoRi, soiThieu, tomTatDauRa, gomChuoi, goDauThoat,
};
