'use strict';
/**
 * OpenTelemetry GenAI semantic conventions (V20 §2.5).
 * Phát hiện 2 bất thường mà tracing thường bỏ sót: vòng lặp suy luận và bùng nổ token.
 */

const crypto = require('node:crypto');

const SPAN_TYPES = {
  AGENT_RUN: 'agent.run',
  LLM_CALL: 'gen_ai.chat',
  TOOL_CALL: 'gen_ai.tool',
  PLANNING: 'gen_ai.planning',
  REASONING: 'gen_ai.reasoning',
  RETRIEVAL: 'gen_ai.retrieval',
};

const THRESHOLDS = {
  reasoningLoopCalls: 10,
  tokenBlowup: 50000,
  slowTraceMs: 60000,
};

const rid = (n) => crypto.randomBytes(n).toString('hex');

class OTelGenAI {
  constructor({ enabled = true, maxBuffer = 5000 } = {}) {
    this.enabled = enabled;
    this.live = new Map();
    this.buffer = [];
    this.maxBuffer = maxBuffer;
    this.stats = { traces: 0, spans: 0, errors: 0 };
  }

  startTrace(name, attributes = {}) {
    if (!this.enabled) return null;
    const traceId = rid(16);
    const trace = { id: traceId, name, start: Date.now(), spans: [], attributes };
    this.live.set(traceId, trace);
    this.stats.traces++;
    return {
      traceId,
      startSpan: (type, attrs) => this._startSpan(traceId, type, attrs),
      end: (attrs) => this._endTrace(traceId, attrs),
    };
  }

  _normalize(type, attrs = {}) {
    const out = { ...attrs };
    if (type === SPAN_TYPES.LLM_CALL) {
      if (attrs.provider) out['gen_ai.system'] = attrs.provider;
      if (attrs.model) out['gen_ai.request.model'] = attrs.model;
      if (attrs.tier) out['gen_ai.request.tier'] = attrs.tier;
      if (attrs.tokensIn != null) out['gen_ai.usage.input_tokens'] = attrs.tokensIn;
      if (attrs.tokensOut != null) out['gen_ai.usage.output_tokens'] = attrs.tokensOut;
      if (attrs.temperature != null) out['gen_ai.request.temperature'] = attrs.temperature;
    }
    if (type === SPAN_TYPES.TOOL_CALL && attrs.tool) out['gen_ai.tool.name'] = attrs.tool;
    return out;
  }

  _startSpan(traceId, type, attributes = {}) {
    const trace = this.live.get(traceId);
    const spanId = rid(8);
    const span = { spanId, traceId, type, start: Date.now(), attributes: this._normalize(type, attributes) };
    if (trace) trace.spans.push(span);
    this.stats.spans++;
    return {
      spanId,
      setAttribute: (k, v) => { span.attributes[k] = v; },
      end: (attrs = {}) => {
        span.end = Date.now();
        span.durationMs = span.end - span.start;
        Object.assign(span.attributes, this._normalize(type, attrs));
        if (attrs.error) this.stats.errors++;
      },
    };
  }

  _endTrace(traceId, attributes = {}) {
    const trace = this.live.get(traceId);
    if (!trace) return null;
    trace.end = Date.now();
    trace.durationMs = trace.end - trace.start;
    Object.assign(trace.attributes, attributes);
    this.live.delete(traceId);
    this.buffer.push(trace);
    if (this.buffer.length > this.maxBuffer) this.buffer.splice(0, this.buffer.length - this.maxBuffer);
    return trace;
  }

  getTrace(traceId) {
    return this.live.get(traceId) || this.buffer.find((t) => t.id === traceId) || null;
  }

  getRecent(limit = 50) {
    return this.buffer.slice(-limit).reverse().map((t) => ({
      id: t.id, name: t.name, durationMs: t.durationMs, spans: t.spans.length, attributes: t.attributes,
    }));
  }

  detectAnomalies() {
    const out = [];
    for (const t of this.buffer.slice(-500)) {
      const llmCalls = t.spans.filter((s) => s.type === SPAN_TYPES.LLM_CALL).length;
      if (llmCalls > THRESHOLDS.reasoningLoopCalls) {
        out.push({ traceId: t.id, type: 'REASONING_LOOP', llmCalls, threshold: THRESHOLDS.reasoningLoopCalls });
      }
      const tokens = t.spans.reduce(
        (s, x) => s + (x.attributes['gen_ai.usage.input_tokens'] || 0) + (x.attributes['gen_ai.usage.output_tokens'] || 0), 0
      );
      if (tokens > THRESHOLDS.tokenBlowup) {
        out.push({ traceId: t.id, type: 'TOKEN_BLOWUP', tokens, threshold: THRESHOLDS.tokenBlowup });
      }
      if (t.durationMs > THRESHOLDS.slowTraceMs) {
        out.push({ traceId: t.id, type: 'SLOW_TRACE', durationMs: t.durationMs, threshold: THRESHOLDS.slowTraceMs });
      }
    }
    return out;
  }

  status() {
    return { ...this.stats, enabled: this.enabled, live: this.live.size, buffered: this.buffer.length, thresholds: THRESHOLDS };
  }
}

module.exports = OTelGenAI;
module.exports.SPAN_TYPES = SPAN_TYPES;
module.exports.THRESHOLDS = THRESHOLDS;
