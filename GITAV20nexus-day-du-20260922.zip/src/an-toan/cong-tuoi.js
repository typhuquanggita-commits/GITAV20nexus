'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  CỔNG TUỔI VÀ SỰ ĐỒNG Ý CỦA NGƯỜI GIÁM HỘ
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  VÌ SAO TỆP NÀY TỒN TẠI. Một bản thiết kế 1,18 triệu ký tự với 47 mô-đun —
 *  trong đó có ghép đôi bạn học với người lạ, hỏi đáp ẩn danh, lớp học ảo, sự
 *  kiện trực tuyến và học bằng giọng nói — được soi bằng máy và kết quả là:
 *  MỌI lần nhắc tới tuổi, tới cổng tuổi, tới đồng ý của người giám hộ trong
 *  cả tài liệu đều nằm gọn trong MỘT danh sách từ khoá của MỘT luật dò nội
 *  dung. Chính câu khắc phục của luật ấy viết "Thêm age gate và parental
 *  consent" — lời khuyên hệ thống đưa cho người khác, trong khi bản thân nó
 *  không có cả hai.
 *
 *  Hệ thống này lúc ấy cũng không có. Nên tệp này được viết.
 *
 *  BỐN LUẬT, CƯỠNG CHẾ BẰNG MÁY:
 *
 *    1. MẶC ĐỊNH LÀ ĐÓNG. Tính năng chưa khai mức tiếp xúc thì bị từ chối,
 *       không phải được cho qua. Giống hệt bảng phân quyền API.
 *    2. CHƯA BIẾT TUỔI là một câu trả lời, và câu trả lời ấy là KHÔNG — với
 *       những tính năng CHẠM NGƯỜI LẠ trở lên. Không có chỗ nào để đoán tuổi
 *       từ lớp học, từ cách viết, từ giọng nói.
 *
 *       Với tính năng chỉ có người trong nhà, thứ bảo vệ đứa trẻ KHÔNG phải
 *       con số tuổi mà là một người lớn xác định danh tính đứng cùng — nên ở
 *       mức ấy cổng đòi NGƯỜI PHỤ TRÁCH, không đòi tuổi.
 *    3. KHAI BÁO TUỔI KHÔNG PHẢI XÁC MINH TUỔI. Hệ thống ghi rõ mình biết
 *       tuổi bằng cách nào, và không bao giờ gọi lời khai là bằng chứng.
 *    4. ĐỒNG Ý CỦA NGƯỜI GIÁM HỘ PHẢI CÓ TÊN, CÓ LÚC, CÓ CÁCH RÚT LẠI. Một
 *       ô tích không tên không phải sự đồng ý; nó là một ô tích.
 *
 *  ĐIỀU TỆP NÀY KHÔNG LÀM: nó KHÔNG nói hệ thống đã tuân thủ pháp luật. Các
 *  ngưỡng tuổi dưới đây là CHÍNH SÁCH của hệ thống, do người dựng đặt ra, và
 *  phải được người có chuyên môn pháp lý đối chiếu với quy định còn hiệu lực.
 * ═══════════════════════════════════════════════════════════════════════════
 */

/**
 * Dải tuổi theo CHÍNH SÁCH của hệ thống.
 * Mốc 16 được chọn vì đó là mốc bảo vệ dữ liệu trẻ em mà hệ thống tự đặt cho
 * mình; nó cần người có thẩm quyền pháp lý xác nhận, và `canXacNhanPhapLy`
 * ghi lại đúng điều đó thay vì để người đọc tưởng đã xong.
 */
const DAI = [
  { ma: 'DUOI_13', tu: 0, den: 12, ten: 'Dưới 13 tuổi',
    y: 'Nhóm được bảo vệ chặt nhất. Mọi tiếp xúc với người ngoài nhà đều phải có người lớn.' },
  { ma: 'TU_13_15', tu: 13, den: 15, ten: '13–15 tuổi',
    y: 'Vẫn là trẻ em theo chính sách này. Cần đồng ý của người giám hộ cho mọi tính năng chạm người lạ.' },
  { ma: 'TU_16_17', tu: 16, den: 17, ten: '16–17 tuổi',
    y: 'Tự quyết được phần lớn việc học, nhưng chưa thành niên — vẫn phải báo người giám hộ khi có tiếp xúc công khai.' },
  { ma: 'TU_18', tu: 18, den: 200, ten: 'Từ 18 tuổi',
    y: 'Tự quyết.' },
];

const NGUONG_TRE_EM = 16;   // CHÍNH SÁCH, không phải kết luận pháp lý

/** Mức tiếp xúc của một tính năng — quyết định cổng nào phải qua. */
const MUC_TIEP_XUC = {
  KHONG: { ma: 'KHONG', thu: 0, ten: 'Không tiếp xúc ai',
    y: 'Học viên làm một mình với hệ thống. Không ai khác đọc được, không ai khác nhắn tới.' },
  TRONG_NHA: { ma: 'TRONG_NHA', thu: 1, ten: 'Chỉ người trong nhà và người phụ trách',
    y: 'Giáo viên, cố vấn, gia đình. Đều là người đã biết danh tính và có trách nhiệm.' },
  NGUOI_LA: { ma: 'NGUOI_LA', thu: 2, ten: 'Chạm tới người lạ',
    y: 'Ghép đôi bạn học, hỏi đáp ẩn danh, lớp học chung với người ngoài. Đây là chỗ nguy hiểm nhất.' },
  CONG_KHAI: { ma: 'CONG_KHAI', thu: 3, ten: 'Ra ngoài công khai',
    y: 'Nội dung học viên tạo ra bị người ngoài Internet đọc được, hoặc giọng và mặt em bị ghi lại.' },
};

/**
 * Cách hệ thống biết tuổi. Thứ tự này quan trọng: `tu-khai` KHÔNG phải bằng
 * chứng, và mọi chỗ dùng nó đều phải biết điều đó.
 */
const CACH_BIET_TUOI = {
  KHONG_BIET: { ma: 'KHONG_BIET', tinCay: 0, ten: 'Chưa biết', laBangChung: false },
  TU_KHAI: { ma: 'TU_KHAI', tinCay: 1, ten: 'Học viên tự khai', laBangChung: false,
    nhac: 'Lời khai không phải bằng chứng. Đủ để mở tính năng không tiếp xúc, KHÔNG đủ cho tính năng chạm người lạ.' },
  NGUOI_GIAM_HO_KHAI: { ma: 'NGUOI_GIAM_HO_KHAI', tinCay: 2, ten: 'Người giám hộ khai khi lập hồ sơ', laBangChung: false,
    nhac: 'Có người chịu trách nhiệm về lời khai, nhưng vẫn là lời khai.' },
  TRUONG_XAC_NHAN: { ma: 'TRUONG_XAC_NHAN', tinCay: 3, ten: 'Nhà trường hoặc tổ chức xác nhận', laBangChung: true },
};

/**
 * Sổ đăng ký tính năng. MỖI tính năng chạm tới người khác PHẢI có một dòng ở
 * đây. Tính năng không có dòng nào thì cổng TỪ CHỐI — mặc định là đóng.
 */
const TINH_NANG = [
  { ma: 'HOC_MOT_MINH', ten: 'Làm bài, luyện tập, xem lộ trình', mucTiepXuc: 'KHONG' },
  { ma: 'KHAO_SAT', ten: 'Làm bộ khảo sát', mucTiepXuc: 'TRONG_NHA',
    ghiChu: 'Sàng lọc tâm lý có luật riêng tư riêng ở src/khao-sat/kho.js.' },
  { ma: 'BAO_CAO_GIA_DINH', ten: 'Gia đình xem tiến độ của con', mucTiepXuc: 'TRONG_NHA' },
  { ma: 'HOI_TRO_LY', ten: 'Hỏi trợ lý AI chuyên môn trong buổi học', mucTiepXuc: 'TRONG_NHA',
    ghiChu: 'Không phải người lạ, nhưng câu hỏi của em được lưu — nên không xếp mức KHÔNG.' },
  // ── Những tính năng chưa dựng, khai trước để cổng chặn sẵn ────────────
  { ma: 'GHEP_BAN_HOC', ten: 'Ghép đôi bạn học', mucTiepXuc: 'NGUOI_LA', chuaDung: true,
    ghiChu: 'Ghép một đứa trẻ với một người lạ là việc nguy hiểm nhất trong mọi tính năng học tập. '
      + 'Khai sẵn ở đây để ngày ai đó dựng nó, cổng đã đứng sẵn chứ không phải dựng sau.' },
  { ma: 'HOI_DAP_AN_DANH', ten: 'Hỏi đáp ẩn danh', mucTiepXuc: 'NGUOI_LA', chuaDung: true,
    ghiChu: 'Ẩn danh bảo vệ người hỏi và cũng bảo vệ người quấy rối. Hai mặt của cùng một cơ chế.' },
  { ma: 'LOP_HOC_CHUNG', ten: 'Lớp học ảo có người ngoài', mucTiepXuc: 'NGUOI_LA', chuaDung: true },
  { ma: 'SU_KIEN_TRUC_TUYEN', ten: 'Sự kiện trực tuyến mở', mucTiepXuc: 'CONG_KHAI', chuaDung: true },
  { ma: 'HOC_BANG_GIONG', ten: 'Học bằng giọng nói có ghi âm', mucTiepXuc: 'CONG_KHAI', chuaDung: true,
    ghiChu: 'Giọng của trẻ là dữ liệu sinh trắc. Ghi lại là một việc khác hẳn với ghi lại câu trả lời.' },
  { ma: 'NOI_DUNG_HOC_VIEN_DANG', ten: 'Học viên đăng nội dung ra ngoài', mucTiepXuc: 'CONG_KHAI', chuaDung: true },
];

const TN_INDEX = new Map(TINH_NANG.map((t) => [t.ma, t]));

/** Dải tuổi của một số tuổi. */
function daiCua(tuoi) {
  if (!Number.isInteger(tuoi) || tuoi < 0 || tuoi > 200) return null;
  return DAI.find((d) => tuoi >= d.tu && tuoi <= d.den) || null;
}

/**
 * CỔNG. Trả về `{ ok }` hoặc `{ ok: false, lyDo, canGi }` — và khi từ chối thì
 * luôn nói rõ CẦN GÌ để qua, vì một cổng chỉ nói "không" là một cổng người ta
 * sẽ tìm cách đi vòng.
 *
 *   maTinhNang   mã trong sổ đăng ký
 *   tuoi         số tuổi, hoặc null khi chưa biết
 *   cachBiet     mã trong CACH_BIET_TUOI
 *   dongYGiamHo  { ten, quanHe, luc, coTheRutLai } hoặc null
 */
function choVao({ maTinhNang, tuoi = null, cachBiet = 'KHONG_BIET', dongYGiamHo = null,
  coNguoiPhuTrach = false } = {}) {
  const tn = TN_INDEX.get(String(maTinhNang || '').toUpperCase());
  // Luật 1 — mặc định là ĐÓNG.
  if (!tn) {
    return {
      ok: false,
      lyDo: `Tính năng "${maTinhNang}" chưa khai mức tiếp xúc trong sổ đăng ký cổng tuổi.`,
      canGi: 'Thêm một dòng vào TINH_NANG với mucTiepXuc đúng. Mặc định là ĐÓNG, không phải mở.',
    };
  }
  const muc = MUC_TIEP_XUC[tn.mucTiepXuc];
  const biet = CACH_BIET_TUOI[String(cachBiet || 'KHONG_BIET').toUpperCase()] || CACH_BIET_TUOI.KHONG_BIET;

  // Mức KHÔNG tiếp xúc: không cần biết tuổi.
  if (muc.thu === 0) return { ok: true, mucTiepXuc: muc.ma };

  // Mức TRONG NHÀ: cái bảo vệ đứa trẻ ở đây KHÔNG phải con số tuổi — mà là
  // việc có một người lớn xác định danh tính đứng cùng. Đòi thêm tuổi ở mức
  // này là thêm ma sát mà không thêm an toàn.
  //
  // Bản đầu của tệp này đòi tuổi cho cả mức TRONG NHÀ, và hậu quả lộ ra ngay
  // trong lượt thanh tra đầu tiên: KHÔNG một luồng nào trong hệ thống gọi nổi
  // cổng này, vì hệ thống chưa có trường tuổi. Một cái cổng không ai gọi được
  // là một cái cổng trang trí — đúng thứ bệnh mà chính tệp này được viết ra
  // để bắt ở nơi khác.
  if (muc.thu === 1) {
    if (coNguoiPhuTrach === true) return { ok: true, mucTiepXuc: muc.ma, dua: 'nguoi-phu-trach' };
    return {
      ok: false,
      lyDo: `Tính năng mức "${muc.ten}" cần có một người phụ trách xác định danh tính đứng cùng.`,
      canGi: 'Truyền coNguoiPhuTrach: true khi luồng gọi đã xác thực vai giáo viên, cố vấn hoặc gia đình. '
        + 'Ở mức này KHÔNG đòi tuổi: thứ bảo vệ đứa trẻ là người lớn có trách nhiệm, không phải con số.',
      mucTiepXuc: muc.ma,
    };
  }

  // Luật 2 — chưa biết tuổi thì câu trả lời là KHÔNG.
  const dai = daiCua(tuoi);
  if (!dai) {
    return {
      ok: false,
      lyDo: 'Chưa biết tuổi học viên.',
      canGi: `Tính năng này ở mức "${muc.ten}". Phải có tuổi trước. `
        + 'KHÔNG được đoán tuổi từ lớp đang học, từ cách viết, hay từ giọng nói.',
      mucTiepXuc: muc.ma,
    };
  }

  const laTreEm = tuoi < NGUONG_TRE_EM;

  // Luật 3 — với tính năng chạm người lạ, lời khai KHÔNG đủ.
  if (muc.thu >= 2 && !biet.laBangChung) {
    return {
      ok: false,
      lyDo: `Tuổi hiện chỉ có từ nguồn "${biet.ten}" — đây là lời khai, không phải bằng chứng.`,
      canGi: `Tính năng mức "${muc.ten}" đòi tuổi được xác nhận bởi nhà trường hoặc tổ chức. `
        + 'Mở cổng bằng lời khai là mở cho bất kỳ ai khai bất kỳ tuổi nào.',
      mucTiepXuc: muc.ma, dai: dai.ma,
    };
  }

  // Luật 4 — trẻ em chạm người lạ hoặc ra công khai: phải có đồng ý CÓ TÊN.
  if (laTreEm && muc.thu >= 2) {
    const dy = kiemDongY(dongYGiamHo);
    if (!dy.ok) {
      return {
        ok: false,
        lyDo: `Học viên ${dai.ten} dùng tính năng mức "${muc.ten}" mà ${dy.thieu}`,
        canGi: 'Cần đồng ý của người giám hộ: có TÊN, có QUAN HỆ, có LÚC đồng ý, và có đường RÚT LẠI. '
          + 'Một ô tích không tên không phải sự đồng ý; nó là một ô tích.',
        mucTiepXuc: muc.ma, dai: dai.ma,
      };
    }
  }

  // 16–17 ra công khai: chưa thành niên thì người giám hộ phải được BÁO.
  if (!laTreEm && tuoi < 18 && muc.thu >= 3) {
    const dy = kiemDongY(dongYGiamHo);
    if (!dy.ok) {
      return {
        ok: false,
        lyDo: `Học viên ${dai.ten} đưa nội dung ra công khai mà ${dy.thieu}`,
        canGi: 'Chưa thành niên ra công khai thì người giám hộ phải biết và đồng ý.',
        mucTiepXuc: muc.ma, dai: dai.ma,
      };
    }
  }

  return { ok: true, mucTiepXuc: muc.ma, dai: dai.ma, laTreEm, nguonTuoi: biet.ma };
}

/** Một sự đồng ý hợp lệ phải có đủ bốn thứ. */
function kiemDongY(d) {
  if (!d || typeof d !== 'object') return { ok: false, thieu: 'chưa có đồng ý của người giám hộ.' };
  if (!d.ten || String(d.ten).trim().length < 2) return { ok: false, thieu: 'đồng ý không có TÊN người giám hộ.' };
  if (!d.quanHe) return { ok: false, thieu: 'đồng ý không nói QUAN HỆ với học viên.' };
  if (!d.luc) return { ok: false, thieu: 'đồng ý không có thời điểm.' };
  if (d.coTheRutLai !== true) return { ok: false, thieu: 'đồng ý không có đường RÚT LẠI.' };
  return { ok: true };
}

/** Bảng tra cho người vận hành và cho mục kiểm. */
function bang() {
  const theoMuc = {};
  for (const t of TINH_NANG) theoMuc[t.mucTiepXuc] = (theoMuc[t.mucTiepXuc] || 0) + 1;
  return {
    nguongTreEm: NGUONG_TRE_EM,
    canXacNhanPhapLy: 'Ngưỡng tuổi ở đây là CHÍNH SÁCH của hệ thống, do người dựng đặt. '
      + 'Phải để người có chuyên môn pháp lý đối chiếu với quy định còn hiệu lực. '
      + 'Hệ thống KHÔNG tự kết luận mình tuân thủ.',
    dai: DAI,
    mucTiepXuc: Object.values(MUC_TIEP_XUC),
    cachBietTuoi: Object.values(CACH_BIET_TUOI),
    tinhNang: TINH_NANG,
    theoMuc,
    soChuaDung: TINH_NANG.filter((t) => t.chuaDung).length,
    nhac: 'Tính năng chưa dựng vẫn được khai sẵn ở đây, để ngày ai đó dựng nó thì cổng đã đứng sẵn — '
      + 'chứ không phải dựng cổng sau khi đã có đứa trẻ đi qua.',
  };
}

module.exports = {
  DAI, NGUONG_TRE_EM, MUC_TIEP_XUC, CACH_BIET_TUOI, TINH_NANG, TN_INDEX,
  daiCua, choVao, kiemDongY, bang,
};
