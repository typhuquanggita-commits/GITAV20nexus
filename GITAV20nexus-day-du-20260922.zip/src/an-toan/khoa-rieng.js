'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  MỖI VIỆC MỘT KHOÁ — VÀ KHOÁ PHẢI ĐƯỢC DẪN XUẤT, KHÔNG PHẢI CẮT RA
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Trong bản thiết kế được soi, khoá mã hoá bí mật của tổ chức được tạo ra
 *  như sau:
 *
 *      const keyStr = env.JWT_SECRET.slice(0, 32).padEnd(32, '0');
 *
 *  Một dòng, ba lỗi chồng lên nhau, và cả ba đều thuộc loại không ai nhận ra
 *  khi đọc lướt vì dòng ấy trông rất gọn:
 *
 *    1. DÙNG LẠI KHOÁ. Cùng một bí mật vừa ký phiên đăng nhập vừa mã hoá dữ
 *       liệu tổ chức. Lộ một nơi là mất cả hai, và hai nơi ấy có vòng đời
 *       khác nhau: khoá ký cần xoay thường xuyên, khoá mã hoá xoay thì phải
 *       giải mã lại toàn bộ dữ liệu cũ. Trói chúng vào nhau là tự khoá mình
 *       không xoay được cái nào.
 *
 *    2. CẮT THAY VÌ DẪN XUẤT. `slice(0, 32)` lấy 32 KÝ TỰ đầu làm khoá AES.
 *       Chữ và số ASCII chỉ mang khoảng 5–6 bit entropy mỗi ký tự, nên một
 *       "khoá 256 bit" như thế thực chất chỉ có chừng 160–190 bit, và toàn
 *       bộ phần entropy nằm sau ký tự thứ 32 bị vứt đi.
 *
 *    3. ĐỆM BẰNG SỐ KHÔNG. `padEnd(32, '0')` nghĩa là một bí mật ngắn — kể cả
 *       bí mật 8 ký tự ai đó gõ vội lúc dựng máy — vẫn ra một khoá "đủ dài".
 *       Hệ thống không báo gì. Đây là chỗ nguy hiểm nhất trong ba: nó biến
 *       một lỗi cấu hình thành một khoá yếu mà trông vẫn bình thường.
 *
 *  Tệp này làm ngược lại cả ba, và từ chối chứ không đệm.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const crypto = require('node:crypto');

/** Mỗi việc một mã. Thêm việc mới thì thêm vào đây, không dùng ké mã cũ. */
const VIEC = {
  VE_BIEU_MAU: { ma: 'VE_BIEU_MAU', ten: 'Ký vé chống giả mạo biểu mẫu', doDai: 32 },
  PHIEN: { ma: 'PHIEN', ten: 'Ký phiên đăng nhập', doDai: 32 },
  MA_HOA_KHO: { ma: 'MA_HOA_KHO', ten: 'Mã hoá dữ liệu lưu trữ', doDai: 32 },
  KY_TEP: { ma: 'KY_TEP', ten: 'Ký tệp xuất ra ngoài', doDai: 32 },
  MOC_XICH: { ma: 'MOC_XICH', ten: 'Móc xích nhật ký kiểm toán', doDai: 32 },
};

const DAI_TOI_THIEU = 32;     // ký tự, cho bí mật gốc khai trong môi trường

/**
 * Bí mật gốc có đủ dùng không. TỪ CHỐI chứ không đệm — đệm là biến một lỗi
 * cấu hình thành một khoá yếu mà trông vẫn bình thường.
 */
function kiemBiMatGoc(biMat) {
  const s = String(biMat || '');
  if (!s) return { ok: false, lyDo: 'Chưa khai bí mật gốc.' };
  if (s.length < DAI_TOI_THIEU) {
    return {
      ok: false,
      lyDo: `Bí mật gốc dài ${s.length} ký tự, tối thiểu ${DAI_TOI_THIEU}.`,
      camLam: 'CẤM đệm cho đủ dài. Một bí mật 8 ký tự đệm thành 32 vẫn là bí mật 8 ký tự, '
        + 'chỉ khác là bây giờ không ai nhìn ra nữa.',
    };
  }
  // Một chuỗi 32 ký tự giống nhau cũng dài 32. Đếm ký tự riêng biệt để bắt
  // những bí mật kiểu '0000…' hoặc 'aaaa…' mà phép đo độ dài cho qua.
  const rieng = new Set(s).size;
  if (rieng < 8) {
    return {
      ok: false,
      lyDo: `Bí mật gốc chỉ có ${rieng} ký tự khác nhau — quá ít biến thiên.`,
      camLam: 'Dùng một chuỗi ngẫu nhiên thật: openssl rand -base64 48',
    };
  }
  return { ok: true, doDai: s.length, kyTuRieng: rieng };
}

/**
 * Dẫn xuất khoá cho MỘT việc. Dùng HKDF-SHA256 với nhãn việc làm `info`:
 * cùng một bí mật gốc ra những khoá khác hẳn nhau cho từng việc, và từ khoá
 * của việc này KHÔNG suy ra được khoá của việc kia.
 */
function khoaCho(maViec, biMatGoc, { muoi = null } = {}) {
  const v = VIEC[String(maViec || '').toUpperCase()];
  if (!v) {
    throw new Error(`khoaCho: việc "${maViec}" chưa khai trong bảng VIEC. `
      + 'Thêm việc mới vào bảng, KHÔNG dùng ké khoá của việc khác.');
  }
  const k = kiemBiMatGoc(biMatGoc);
  if (!k.ok) throw new Error(`khoaCho: ${k.lyDo} ${k.camLam || ''}`);

  // `info` mang nhãn việc — đây là thứ tách các khoá ra khỏi nhau.
  const info = Buffer.from(`gitamath-nexus/v1/${v.ma}`, 'utf8');
  const salt = muoi ? Buffer.from(String(muoi), 'utf8') : Buffer.alloc(32, 0);
  const ra = crypto.hkdfSync('sha256', Buffer.from(String(biMatGoc), 'utf8'), salt, info, v.doDai);
  return Buffer.from(ra);
}

/**
 * Hai việc khác nhau có ra hai khoá khác nhau không — và khoá có đủ biến
 * thiên không. Mục kiểm gọi hàm này thay vì tin vào lời giải thích ở trên.
 */
function tuKiem(biMatGoc) {
  const k = kiemBiMatGoc(biMatGoc);
  if (!k.ok) return { ok: false, ...k };
  const ma = Object.keys(VIEC);
  const khoa = ma.map((m) => khoaCho(m, biMatGoc).toString('hex'));
  const rieng = new Set(khoa).size;
  const loi = [];
  if (rieng !== ma.length) loi.push('có hai việc ra cùng một khoá');
  for (let i = 0; i < khoa.length; i++) {
    if (khoa[i].length !== VIEC[ma[i]].doDai * 2) loi.push(`${ma[i]} ra khoá sai độ dài`);
    // Khoá dẫn xuất đúng thì không được chứa chuỗi con của bí mật gốc.
    if (Buffer.from(khoa[i], 'hex').toString('latin1').includes(String(biMatGoc).slice(0, 8))) {
      loi.push(`${ma[i]}: khoá chứa nguyên đoạn của bí mật gốc — đang CẮT chứ không DẪN XUẤT`);
    }
  }
  // Lặp lại phải ra đúng khoá cũ, nếu không thì không giải mã lại được gì.
  if (khoaCho(ma[0], biMatGoc).toString('hex') !== khoa[0]) loi.push('dẫn xuất không tất định');
  return { ok: loi.length === 0, soViec: ma.length, khoaRiengBiet: rieng, loi };
}

/** Bảng cho mục kiểm và cho người vận hành. */
function bang() {
  return {
    viec: Object.values(VIEC),
    daiToiThieu: DAI_TOI_THIEU,
    cachDan: 'HKDF-SHA256, nhãn việc nằm trong trường info',
    camLam: [
      'CẤM dùng một bí mật cho hai việc. Lộ một nơi là mất cả hai, và hai việc có vòng đời xoay khoá khác nhau.',
      'CẤM cắt bí mật bằng slice() để lấy khoá. Cắt là vứt phần entropy phía sau.',
      'CẤM đệm bí mật ngắn cho đủ dài. Đệm biến một lỗi cấu hình thành một khoá yếu trông vẫn bình thường.',
    ],
  };
}

module.exports = { VIEC, DAI_TOI_THIEU, kiemBiMatGoc, khoaCho, tuKiem, bang };
