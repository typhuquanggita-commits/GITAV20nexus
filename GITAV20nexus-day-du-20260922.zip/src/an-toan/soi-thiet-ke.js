'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BẢY CÂU HỎI TRƯỚC KHI DỰNG MỘT TÍNH NĂNG MỚI
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Bảy câu dưới đây không nghĩ ra từ kinh nghiệm chung. Chúng là bảy chỗ hỏng
 *  TÌM ĐƯỢC BẰNG MÁY khi soi một bản thiết kế 1,18 triệu ký tự gồm 47 mô-đun
 *  tính năng — một bản thiết kế viết rất kỹ, rất dài, và mỗi mô-đun đọc riêng
 *  đều hợp lý.
 *
 *  Đó là điều đáng chú ý nhất: cả bảy chỗ hỏng đều KHÔNG lộ ra khi đọc từng
 *  phần. Chúng chỉ lộ khi đối chiếu phần này với phần kia, hoặc khi đếm.
 *
 *  Nên bảy câu này là bảy PHÉP ĐẾM và PHÉP ĐỐI CHIẾU, không phải bảy lời
 *  khuyên. Câu nào cũng trả lời được bằng một lệnh chạy trên kho mã.
 *
 *  GHI CHÚ VỀ CÁCH VIẾT: tệp này cố ý KHÔNG viết tên đường dẫn của mô-đun
 *  quét cụm từ cấm. Bản đầu có viết, và chính bộ quét ấy bắt được — vì đường
 *  dẫn chứa nguyên một cụm nằm trong bảng cấm. Đó là lần bức tường bắt ĐÚNG,
 *  nên cách xử lý đúng là đổi chữ ở đây, không phải nới bảng cấm ở kia.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const CAU_HOI = [
  {
    thu: 1, ma: 'SOI-NEN', ten: 'Móng đã đổ chưa, hay mới vẽ tầng lầu?',
    timRaTuDau: 'Quét danh sách import và đối chiếu với danh sách định nghĩa trong bản thiết kế 47 mô-đun: '
      + '18 đường dẫn được import mà không tệp nào định nghĩa, tổng 265 chỗ gọi. Trong đó bảy mô-đun '
      + 'gánh an toàn chiếm 156 chỗ: mật mã 46, xác thực 39, xử lý lỗi 38, giới hạn tần suất 15, '
      + 'trần chi phí 10, hàng đợi 5, nhật ký 3.',
    hoiGi: 'Mọi mô-đun mà tính năng mới gọi tới có tồn tại thật không?',
    traLoiBang: 'node -e "console.log(require(\'./src/an-toan/nen-mong\').soiNenMong().ketLuan)"',
    viSaoKhongTuLo: 'Đọc bất kỳ mô-đun nào cũng thấy nó gọi assertBudget() rồi yên tâm rằng ngân sách đang '
      + 'được canh. Chỉ khi quét cả kho và so hai danh sách mới thấy assertBudget chưa từng tồn tại.',
  },
  {
    thu: 2, ma: 'SOI-TUOI', ten: 'Tính năng này có chạm tới một đứa trẻ không?',
    timRaTuDau: 'Đếm mọi lần nhắc tới tuổi, cổng tuổi, đồng ý của người giám hộ trong cả tài liệu: TẤT CẢ '
      + 'nằm gọn trong một danh sách từ khoá của một luật dò nội dung. Câu khắc phục của luật ấy viết '
      + '"Thêm age gate và parental consent" — lời khuyên đưa cho người khác, trong khi hệ thống có ghép '
      + 'đôi bạn học với người lạ, hỏi đáp ẩn danh, lớp học ảo, sự kiện mở và ghi âm giọng nói.',
    hoiGi: 'Tính năng đã khai mức tiếp xúc chưa, và cổng tuổi có chặn đúng không?',
    traLoiBang: 'node -e "console.log(require(\'./src/an-toan/cong-tuoi\').choVao({maTinhNang:\'<MÃ>\'}))"',
    viSaoKhongTuLo: 'Không ai viết "tính năng này dành cho trẻ em" vào bản thiết kế. Nó chỉ hiện ra khi '
      + 'hỏi ngược: ai là người ngồi ở đầu bên kia.',
  },
  {
    thu: 3, ma: 'SOI-KHOA', ten: 'Một bí mật có đang làm hai việc không?',
    timRaTuDau: 'Một dòng trong bản thiết kế: env.JWT_SECRET.slice(0, 32).padEnd(32, "0") — khoá ký phiên '
      + 'bị cắt 32 ký tự đầu làm khoá mã hoá dữ liệu tổ chức, và đệm số không nếu ngắn.',
    hoiGi: 'Khoá của việc này có được dẫn xuất riêng không, hay cắt ra từ khoá việc khác?',
    traLoiBang: 'node -e "console.log(require(\'./src/an-toan/khoa-rieng\').tuKiem(process.env.CSRF_SECRET||\'\'))"',
    viSaoKhongTuLo: 'Dòng ấy rất gọn và trông rất chuyên nghiệp. Ba lỗi chồng lên nhau trong một dòng: '
      + 'dùng lại khoá, cắt thay vì dẫn xuất, đệm số không.',
  },
  {
    thu: 4, ma: 'SOI-DAU', ten: 'Bộ lọc nội dung có bỏ dấu tiếng Việt không?',
    timRaTuDau: 'Luật lọc quấy rối trong bản thiết kế khớp từ khoá bằng new RegExp(kw, "gi") — khớp thẳng, '
      + 'không chuẩn hoá dấu. Viết không dấu, thêm một dấu cách, hay chèn một ký tự vô hình là đi qua.',
    hoiGi: 'Bộ lọc có chuẩn hoá về dạng không dấu trước khi khớp không?',
    traLoiBang: 'Bộ quét cụm từ cấm của hệ thống đã làm đúng việc này bằng viKey(); mọi bộ lọc mới phải dùng cùng cách.',
    viSaoKhongTuLo: 'Bộ lọc chạy đúng với mọi ví dụ trong tài liệu, vì ví dụ nào cũng viết có dấu.',
  },
  {
    thu: 5, ma: 'SOI-TU-DONG', ten: 'Máy có được tự ra một quyết định không đảo ngược được không?',
    timRaTuDau: 'Bộ chống gian lận thi: sự kiện "multiple_faces" phạt 0.50 và maxAllowed = 1, và mọi sự '
      + 'kiện mức critical đều kích hoạt tự huỷ kết quả thi. Một người nhà đi ngang qua sau lưng là đủ.',
    hoiGi: 'Quyết định nặng nhất mà máy được tự ra là gì, và có người xem lại trước khi nó có hiệu lực không?',
    traLoiBang: 'Đọc mọi nhánh mã dẫn tới trạng thái không đảo ngược được, và tìm chỗ có tên một người.',
    viSaoKhongTuLo: 'Bảng phạt trông rất cân nhắc: có mức, có ngưỡng, có hệ số. Cái thiếu không nằm trong '
      + 'bảng — nó là một người.',
  },
  {
    thu: 6, ma: 'SOI-LUI', ten: 'Lui về được không, và lui xong có mất gì không?',
    timRaTuDau: 'Kế hoạch lui của cả hệ thống 47 mô-đun gồm hai lệnh: wrangler rollback và d1 restore. '
      + 'Không nói thứ tự, không nói kiểm lại thế nào, không nói dữ liệu ghi trong lúc lui đi đâu.',
    hoiGi: 'Có quy trình lui viết ra không, và nó có nói rõ mất gì không?',
    traLoiBang: 'Đối chiếu với src/quy-trinh/so-tay.js — kịch bản trực phải nói LÀM NGAY và CẤM LÀM.',
    viSaoKhongTuLo: 'Hai lệnh ấy đúng. Chúng chỉ không đủ, và sự không đủ chỉ lộ ra lúc đang cần dùng.',
  },
  {
    thu: 7, ma: 'SOI-HUA', ten: 'Lời hứa lớn nhất của hệ thống dựa trên cái gì?',
    timRaTuDau: 'Lời hứa "$0/tháng MÃI MÃI" lặp lại ở tiêu đề của mười phiên bản. Nó dựa hoàn toàn vào '
      + 'mô-đun costGuard — chính là một trong bảy mô-đun chưa ai viết.',
    hoiGi: 'Lời hứa to nhất in trên trang đầu dựa vào mô-đun nào, và mô-đun ấy có thật không?',
    traLoiBang: 'Lần theo lời hứa xuống tới dòng mã cuối cùng thực thi nó.',
    viSaoKhongTuLo: 'Lời hứa càng lặp nhiều lần càng thành hiển nhiên, và không ai lần xuống tận đáy nữa.',
  },
];

/**
 * Soi một bản thiết kế mới bằng bảy câu. Trả về danh sách câu CHƯA trả lời —
 * vì "chưa trả lời" là trạng thái mặc định, không phải "không áp dụng".
 */
function soi({ daTraLoi = [] } = {}) {
  const xong = new Set(daTraLoi.map((x) => String(x).toUpperCase()));
  const chua = CAU_HOI.filter((c) => !xong.has(c.ma));
  return {
    tong: CAU_HOI.length,
    daTraLoi: CAU_HOI.length - chua.length,
    chuaTraLoi: chua.map((c) => ({ ma: c.ma, ten: c.ten, hoiGi: c.hoiGi })),
    ok: chua.length === 0,
    nhac: 'Câu chưa trả lời KHÔNG mặc định là "không áp dụng". Cả bảy chỗ hỏng gốc đều nằm trong những '
      + 'tính năng mà người viết chắc chắn nghĩ là không liên quan.',
  };
}

/** Bảng đầy đủ, để in ra và để mục kiểm đọc. */
function bang() {
  return {
    soCauHoi: CAU_HOI.length,
    cauHoi: CAU_HOI,
    nguonGoc: 'Bảy chỗ hỏng tìm được bằng máy khi soi một bản thiết kế 1,18 triệu ký tự, 47 mô-đun.',
    diemChung: 'Không chỗ nào lộ ra khi đọc từng phần. Chúng chỉ lộ khi ĐỐI CHIẾU phần này với phần kia, '
      + 'hoặc khi ĐẾM. Nên bảy câu này là bảy phép đếm, không phải bảy lời khuyên.',
  };
}

module.exports = { CAU_HOI, soi, bang };
