'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  CHỐNG LỪA ĐẢO — và nói rõ cái gì đã an toàn sẵn, cái gì còn phải canh
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  BẮT ĐẦU BẰNG MỘT SỰ THẬT DỄ BỊ QUÊN: đăng nhập bằng khuôn mặt (WebAuthn)
 *  TỰ NÓ đã chống được lừa đảo, và chống theo cách mà không lớp cảnh báo nào
 *  bằng được. Lý do nằm ở chỗ chữ ký được gắn chặt vào GỐC của trang:
 *
 *      Người dùng bị dẫn tới gitamath-that.vn, một bản sao giống hệt.
 *      Họ bấm đăng nhập, quét mặt như mọi ngày.
 *      Trình duyệt ký kèm gốc "gitamath-that.vn".
 *      Kẻ tấn công mang chữ ký ấy sang gitamath.vn.
 *      Máy chủ thật thấy gốc sai, TỪ CHỐI.
 *
 *  Người dùng không cần tinh ý, không cần nhìn thanh địa chỉ, không cần biết
 *  lừa đảo là gì. Máy làm thay họ. Đây là điều mật khẩu KHÔNG bao giờ làm
 *  được: mật khẩu gõ vào trang giả là trang giả có mật khẩu.
 *
 *  ── VẬY TỆP NÀY CÒN ĐỂ LÀM GÌ ─────────────────────────────────────────
 *
 *  Vì lừa đảo không chỉ nhắm vào lúc đăng nhập. Bốn đường vòng còn lại:
 *
 *  1. MẬT KHẨU VẪN CÒN ĐÓ. Hệ này giữ mật khẩu làm lối vào dự phòng — bỏ đi
 *     là khoá người dùng ra ngoài khi hỏng cảm biến. Nhưng lối dự phòng ấy
 *     chính là lối kẻ lừa đảo nhắm tới.
 *
 *  2. CHIẾM PHIÊN. Đăng nhập xong, kẻ tấn công lấy được vé phiên bằng cách
 *     khác — máy nhiễm mã độc, vé bị chép. Lúc ấy nó không cần đăng nhập nữa.
 *
 *  3. LỪA CHÍNH NGƯỜI DÙNG LÀM VIỆC NGUY HIỂM. Không cần chiếm tài khoản:
 *     chỉ cần gọi điện xưng là nhà trường và bảo họ tự đổi mật khẩu, tự gỡ
 *     khuôn mặt, tự thêm một máy lạ.
 *
 *  4. DÒ TÀI KHOẢN. Thử hàng loạt tên để biết tài khoản nào có thật, rồi
 *     nhắm vào đúng những người ấy.
 *
 *  ── BỐN LỚP CANH, MỖI LỚP CHO MỘT ĐƯỜNG VÒNG ──────────────────────────
 *
 *      Bước xác thực lại   việc nguy hiểm đòi quét mặt LẠI, dù đang đăng nhập
 *      Máy đã biết         máy lạ đăng nhập là báo động, không phải lặng lẽ
 *      Dấu hiệu tấn công   gom và chấm, không để mỗi lần một nơi
 *      Không lộ tài khoản  trả lời giống hệt nhau dù tài khoản có hay không
 *
 *  ── ĐIỀU TỆP NÀY KHÔNG LÀM ────────────────────────────────────────────
 *
 *  Nó KHÔNG chấm "điểm tin cậy" rồi tự chặn người dùng theo một con số mà
 *  không ai giải thích được. Mỗi dấu hiệu ở đây đều nói được lý do bằng một
 *  câu, và mỗi lần chặn đều chỉ ra dấu hiệu nào gây ra. Một hệ chặn người mà
 *  không nói được vì sao thì người bị chặn oan không có đường nào kêu.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const crypto = require('node:crypto');

/** Việc nguy hiểm: đòi xác thực lại dù đang đăng nhập. */
const VIEC_NGUY_HIEM = {
  'doi-mat-khau': { ten: 'Đổi mật khẩu', vi: 'Kẻ chiếm phiên đổi mật khẩu là khoá chủ nhà ra ngoài.' },
  'gan-khuon-mat': { ten: 'Gắn thêm một máy', vi: 'Gắn máy lạ là mở một cửa sau vĩnh viễn.' },
  'go-khuon-mat': { ten: 'Gỡ một máy', vi: 'Gỡ hết máy của chủ nhà là bước chuẩn bị chiếm tài khoản.' },
  'doc-tam-ly': {
    ten: 'Đọc dữ liệu sàng lọc tâm lý',
    vi: 'Đây là dữ liệu riêng tư nhất của một đứa trẻ. Lộ ra thì em ấy mang theo suốt '
      + 'những năm đi học, và không có cách nào thu lại.',
  },
  'xoa-du-lieu': {
    ten: 'Xoá dữ liệu',
    vi: 'Không lùi lại được. Ảnh chụp hệ thống lui về được tới ba mươi ngày, nhưng thứ xoá '
      + 'sau lần chụp cuối thì mất hẳn — và dữ liệu học tập của một em nhỏ không dựng lại được.',
  },
  'cap-quyen': {
    ten: 'Cấp hoặc hạ quyền',
    vi: 'Một lệnh sai ở đây lan ra toàn hệ. Tự nâng quyền mình lên quản trị là bước cuối '
      + 'của mọi vụ chiếm tài khoản — từ đó kẻ tấn công không cần lừa ai nữa.',
  },
};

/** Xác thực lại còn hiệu lực bao lâu. Năm phút: đủ làm xong việc, không đủ để quên. */
const XAC_THUC_LAI_SONG_MS = 5 * 60_000;

/** Máy lạ được nhớ bao lâu sau lần cuối dùng. */
const NHO_MAY_MS = 180 * 86_400_000;

/**
 * Dấu hiệu tấn công. Mỗi dấu hiệu mang MỘT CÂU nói rõ vì sao nó đáng ngờ —
 * không có dấu hiệu nào chỉ là một con số.
 */
const DAU_HIEU = {
  GOC_SAI: {
    nang: 3,
    ten: 'Chữ ký đến từ một gốc không phải của hệ thống',
    vi: 'Đây là dấu vết trực tiếp của một trang giả mạo. Người dùng đã quét mặt trên trang ấy, '
      + 'và chỉ có việc chữ ký gắn chặt vào gốc mới chặn được.',
    lam: 'Liên hệ người dùng ngay. Gốc ghi trong nhật ký chính là tên miền giả mạo cần báo.',
  },
  BAN_SAO_KHOA: {
    nang: 3,
    ten: 'Bộ đếm lần ký không tăng — nghi có bản sao khoá riêng',
    vi: 'Khoá riêng lẽ ra không rời khỏi con chip. Bộ đếm đứng yên nghĩa là có hai bản đang chạy.',
    lam: 'Gỡ máy ấy ngay và yêu cầu người dùng gắn lại từ máy thật của họ.',
  },
  MAY_LA: {
    nang: 1,
    ten: 'Đăng nhập từ một máy chưa từng thấy',
    vi: 'Tự nó là chuyện bình thường — người ta đổi máy. Đáng ngờ khi đi cùng dấu hiệu khác.',
    lam: 'Báo cho người dùng biết có máy mới, để chính họ nói đúng hay sai.',
  },
  DO_TAI_KHOAN: {
    nang: 2,
    ten: 'Thử nhiều tên đăng nhập khác nhau từ cùng một nơi',
    vi: 'Đây là hình dạng của việc dò xem tài khoản nào có thật, trước khi nhắm vào người cụ thể.',
    lam: 'Chặn nguồn ấy. Kiểm lại rằng câu trả lời cho tài khoản có và không có là giống hệt nhau.',
  },
  DOI_MAT_KHAU_NGAY_SAU_KHI_VAO: {
    nang: 2,
    ten: 'Đổi mật khẩu ngay sau khi vào từ máy lạ',
    vi: 'Đây là bước đầu của việc chiếm tài khoản: vào được rồi khoá chủ nhà ra ngoài.',
    lam: 'Đòi xác thực lại. Báo cho người dùng qua một kênh khác.',
  },
  GO_HET_MAY: {
    nang: 2,
    ten: 'Gỡ máy cuối cùng trong khi vừa gắn một máy khác',
    vi: 'Thay toàn bộ khoá của chủ nhà bằng khoá của mình.',
    lam: 'Đòi xác thực lại và giữ lại nhật ký cả hai việc.',
  },
  DON_DAP: {
    nang: 2,
    ten: 'Nhiều lần thử hỏng dồn trong thời gian ngắn',
    vi: 'Tốc độ ấy không phải tốc độ của người đang nhớ lại mật khẩu.',
    lam: 'Hàng rào khoá tài khoản đã chặn. Xem nguồn có đang thử nhiều tài khoản không.',
  },
};

/** Băm một thứ để nhận ra lần sau mà không giữ nguyên bản. */
function dauVan(chuoi) {
  return crypto.createHash('sha256').update(String(chuoi || '')).digest('base64url').slice(0, 22);
}

class ChongLuaDao {
  /**
   * @param {object} o
   * @param {object} o.nhatKy AuditChain
   * @param {function} o.bayGio
   */
  constructor({ nhatKy = null, bayGio = () => Date.now(), giuDauHieu = 2000 } = {}) {
    this.nhatKy = nhatKy;
    this.bayGio = bayGio;
    this.giuDauHieu = giuDauHieu;

    /** Vé đã xác thực lại: token → {luc, viec}. */
    this.xacThucLai = new Map();
    /** Máy đã biết: userId → Map(dấu vân → {lanDau, lanCuoi, soLan}). */
    this.mayDaBiet = new Map();
    /** Dấu hiệu đã ghi, mới nhất ở cuối. */
    this.dauHieu = [];
    /** Theo dõi dò tài khoản: dấu vân nguồn → {tenDaThu:Set, tuLuc}. */
    this.doTaiKhoan = new Map();

    this.dem = { xacThucLai: 0, tuChoiViecNguyHiem: 0, mayMoi: 0, dauHieu: 0 };
  }

  // ── LỚP 1: BƯỚC XÁC THỰC LẠI ───────────────────────────────────────────

  /**
   * Ghi nhận người dùng vừa xác thực lại bằng khuôn mặt.
   *
   * CHỈ NHẬN KHI ĐÃ XÁC MINH SINH TRẮC HỌC. Gõ lại mật khẩu không tính là
   * xác thực lại: kẻ đã chiếm được phiên thường cũng đã có mật khẩu, nên bắt
   * gõ lại mật khẩu chỉ làm phiền người thật mà không chặn được ai.
   */
  ghiXacThucLai(token, { bangKhuonMat = false } = {}) {
    if (!token) return { ok: false, loi: 'THIEU_VE_PHIEN' };
    if (!bangKhuonMat) {
      return {
        ok: false, loi: 'PHAI_XAC_THUC_BANG_KHUON_MAT',
        lyDo: 'Gõ lại mật khẩu không tính: kẻ đã chiếm được phiên thường cũng đã có mật khẩu.',
      };
    }
    this.xacThucLai.set(token, { luc: this.bayGio() });
    this.dem.xacThucLai++;
    return { ok: true, hieuLucToi: this.bayGio() + XAC_THUC_LAI_SONG_MS };
  }

  /**
   * Việc này có được làm không.
   * @returns {{cho:true} | {cho:false, canGi:string, vi:string}}
   */
  choLamViec(token, maViec) {
    const v = VIEC_NGUY_HIEM[maViec];
    if (!v) return { cho: true, vi: 'Việc này không nằm trong danh sách nguy hiểm.' };

    const ve = this.xacThucLai.get(token);
    if (ve && this.bayGio() - ve.luc <= XAC_THUC_LAI_SONG_MS) {
      return { cho: true, conLaiGiay: Math.round((XAC_THUC_LAI_SONG_MS - (this.bayGio() - ve.luc)) / 1000) };
    }
    if (ve) this.xacThucLai.delete(token);
    this.dem.tuChoiViecNguyHiem++;
    return {
      cho: false,
      viec: v.ten,
      vi: v.vi,
      canGi: 'Quét khuôn mặt lại để xác nhận chính bạn đang làm việc này.',
    };
  }

  /** Đăng xuất thì vé xác thực lại chết theo. */
  quenVe(token) { this.xacThucLai.delete(token); }

  // ── LỚP 2: MÁY ĐÃ BIẾT ─────────────────────────────────────────────────

  /**
   * Ghi nhận một lần đăng nhập và cho biết máy này lạ hay quen.
   *
   * KHÔNG GIỮ NGUYÊN BẢN. Chuỗi nhận dạng trình duyệt và địa chỉ mạng đều
   * băm lại — đủ để nhận ra lần sau, không đủ để dựng lại thói quen đi lại
   * của một đứa trẻ.
   */
  ghiMay(nguoiDungId, { userAgent = '', ip = '' } = {}) {
    const van = dauVan(`${userAgent}|${ip}`);
    if (!this.mayDaBiet.has(nguoiDungId)) this.mayDaBiet.set(nguoiDungId, new Map());
    const ds = this.mayDaBiet.get(nguoiDungId);
    const n = this.bayGio();

    for (const [k, m] of ds) if (n - m.lanCuoi > NHO_MAY_MS) ds.delete(k);

    if (ds.has(van)) {
      const m = ds.get(van);
      m.lanCuoi = n;
      m.soLan++;
      return { la: false, dauVan: van, soLan: m.soLan };
    }
    // Máy đầu tiên của một tài khoản mới thì không phải "lạ" — nó là máy đầu.
    const laMayDau = ds.size === 0;
    ds.set(van, { lanDau: n, lanCuoi: n, soLan: 1 });
    if (!laMayDau) this.dem.mayMoi++;
    return { la: !laMayDau, dauVan: van, soLan: 1, laMayDau };
  }

  dsMay(nguoiDungId) {
    const ds = this.mayDaBiet.get(nguoiDungId);
    if (!ds) return [];
    return [...ds.entries()].map(([van, m]) => ({ dauVan: van, ...m }))
      .sort((a, b) => b.lanCuoi - a.lanCuoi);
  }

  // ── LỚP 3: DẤU HIỆU TẤN CÔNG ───────────────────────────────────────────

  /**
   * Ghi một dấu hiệu.
   * @param {string} ma khoá trong bảng DAU_HIEU
   */
  ghiDauHieu(ma, chiTiet = {}) {
    const d = DAU_HIEU[ma];
    if (!d) throw new Error(`Dấu hiệu "${ma}" chưa khai trong bảng — mọi dấu hiệu đều phải nói được vì sao.`);
    const ban = { ma, nang: d.nang, ten: d.ten, vi: d.vi, lam: d.lam, luc: this.bayGio(), ...chiTiet };
    this.dauHieu.push(ban);
    if (this.dauHieu.length > this.giuDauHieu) this.dauHieu.shift();
    this.dem.dauHieu++;
    if (this.nhatKy) {
      Promise.resolve(this.nhatKy.record({
        actor: chiTiet.nguoiDungId || 'khong-ro',
        action: `an-toan.dau-hieu.${ma}`,
        verdict: 'DENY',
        severity: d.nang,
        detail: { ten: d.ten, ...chiTiet },
      })).catch(() => {});
    }
    return ban;
  }

  /**
   * Dò tài khoản: cùng một nguồn thử nhiều TÊN khác nhau.
   *
   * Đếm theo tên chứ không theo số lần: một người gõ sai mật khẩu mười lần
   * vẫn chỉ là một tên. Thử mười tên khác nhau mới là dò.
   */
  ghiThuTen(nguon, ten) {
    const van = dauVan(nguon);
    const n = this.bayGio();
    let g = this.doTaiKhoan.get(van);
    if (!g || n - g.tuLuc > 3600_000) { g = { tenDaThu: new Set(), tuLuc: n }; this.doTaiKhoan.set(van, g); }
    g.tenDaThu.add(String(ten || '').toLowerCase());
    if (g.tenDaThu.size >= 5) {
      return this.ghiDauHieu('DO_TAI_KHOAN', { nguonVan: van, soTenDaThu: g.tenDaThu.size });
    }
    return null;
  }

  /** Dồn dập: nhiều lần hỏng trong thời gian ngắn, tính trên một tài khoản. */
  ghiThuHong(nguoiDungId, { trongPhut = 5, nguong = 8 } = {}) {
    const n = this.bayGio();
    const gan = this.dauHieu.filter((d) => d.nguoiDungId === nguoiDungId
      && d.ma === 'THU_HONG' && n - d.luc < trongPhut * 60_000);
    // Dùng chính mảng dấu hiệu làm bộ đếm thì không cần thêm một kho nữa.
    this.dauHieu.push({ ma: 'THU_HONG', nguoiDungId, luc: n, nang: 0 });
    if (this.dauHieu.length > this.giuDauHieu) this.dauHieu.shift();
    if (gan.length + 1 >= nguong) return this.ghiDauHieu('DON_DAP', { nguoiDungId, soLan: gan.length + 1, trongPhut });
    return null;
  }

  /** Dấu hiệu gần đây, nặng trước. Bỏ dấu đếm nội bộ. */
  dauHieuGanDay({ gioiHan = 50, tuNang = 1 } = {}) {
    return this.dauHieu
      .filter((d) => d.ma !== 'THU_HONG' && d.nang >= tuNang)
      .slice(-gioiHan).reverse();
  }

  /**
   * Tóm tắt tình hình.
   *
   * KHÔNG trả về một "điểm an toàn" tổng hợp. Một con số như vậy nghe có vẻ
   * gọn nhưng không ai hành động được theo nó, và khi nó xuống thì không ai
   * biết phải sửa gì. Trả về từng nhóm dấu hiệu kèm việc nên làm.
   */
  tinhHinh() {
    const ds = this.dauHieuGanDay({ gioiHan: 500 });
    const theoMa = new Map();
    for (const d of ds) {
      const g = theoMa.get(d.ma) || { ma: d.ma, ten: d.ten, nang: d.nang, vi: d.vi, lam: d.lam, soLan: 0, ganNhat: 0 };
      g.soLan++;
      g.ganNhat = Math.max(g.ganNhat, d.luc);
      theoMa.set(d.ma, g);
    }
    const nhom = [...theoMa.values()].sort((a, b) => b.nang - a.nang || b.soLan - a.soLan);
    return {
      tongDauHieu: ds.length,
      nang: nhom.filter((g) => g.nang >= 3),
      vua: nhom.filter((g) => g.nang === 2),
      nhe: nhom.filter((g) => g.nang <= 1),
      canLamNgay: nhom.filter((g) => g.nang >= 3).map((g) => g.lam),
      ghiChu: ds.length ? null : 'Chưa ghi nhận dấu hiệu nào.',
    };
  }

  status() {
    return {
      vieceNguyHiem: Object.keys(VIEC_NGUY_HIEM).length,
      xacThucLaiSongGiay: Math.round(XAC_THUC_LAI_SONG_MS / 1000),
      veDangHieuLuc: this.xacThucLai.size,
      soNguoiCoMayDaBiet: this.mayDaBiet.size,
      dem: { ...this.dem },
      chongLuaDaoSan: 'Đăng nhập bằng khuôn mặt TỰ NÓ chống lừa đảo: chữ ký gắn chặt vào gốc trang, '
        + 'nên chữ ký ký trên trang giả không dùng được ở trang thật. Người dùng không cần tinh ý.',
      bonLopCanh: [
        'Việc nguy hiểm đòi quét mặt LẠI, dù đang đăng nhập.',
        'Máy lạ đăng nhập là báo cho người dùng, không lặng lẽ cho qua.',
        'Dấu hiệu tấn công gom về một chỗ, mỗi dấu hiệu nói được vì sao.',
        'Câu trả lời cho tài khoản có và không có là giống hệt nhau.',
      ],
    };
  }
}

module.exports = ChongLuaDao;
module.exports.VIEC_NGUY_HIEM = VIEC_NGUY_HIEM;
module.exports.DAU_HIEU = DAU_HIEU;
module.exports.XAC_THUC_LAI_SONG_MS = XAC_THUC_LAI_SONG_MS;
module.exports.dauVan = dauVan;
