'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  NHẬP / XUẤT DỮ LIỆU — CSV và JSON
 * ═══════════════════════════════════════════════════════════════════════════
 *  Nguyên tắc: KHÔNG có dòng nào bị bỏ qua im lặng.
 *  Mỗi dòng nhập vào đều nhận đúng một phán quyết — nhận, sửa rồi nhận, hay
 *  từ chối — kèm số dòng và lý do bằng tiếng Việt. Người nhập biết chính xác
 *  phải sửa dòng nào.
 *
 *  Luôn chạy được hai chế độ:
 *    · chạy thử  (dryRun)  — chỉ soát, không ghi gì
 *    · nhập thật          — ghi, và trả về đúng báo cáo như lúc chạy thử
 *
 *  CSV xuất ra có BOM UTF-8 để Excel đọc đúng tiếng Việt ngay lần mở đầu.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { viKey, round } = require('../utils');
const { blockOfGrade } = require('../curriculum/hierarchy');

const BOM = '﻿';

// ── CSV: đọc ────────────────────────────────────────────────────────────────

/** Đoán dấu phân cách: Excel bản Việt hay xuất ra dấu chấm phẩy. */
function detectDelimiter(text) {
  const line = text.split('\n').find((l) => l.trim()) || '';
  const counts = { ',': 0, ';': 0, '\t': 0 };
  let inQ = false;
  for (const ch of line) {
    if (ch === '"') inQ = !inQ;
    else if (!inQ && ch in counts) counts[ch]++;
  }
  return Object.entries(counts).sort((a, b) => b[1] - a[1])[0][1] ? Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0] : ',';
}

/** Bóc CSV theo RFC 4180: có ngoặc kép, có dấu phân cách trong ô, có xuống dòng trong ô. */
function parseCSV(text, { delimiter = null } = {}) {
  let s = String(text || '');
  if (s.startsWith(BOM)) s = s.slice(1);
  const d = delimiter || detectDelimiter(s);

  const rows = [];
  let row = [];
  let field = '';
  let inQ = false;
  let started = false;

  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (inQ) {
      if (c === '"') {
        if (s[i + 1] === '"') { field += '"'; i++; }
        else inQ = false;
      } else field += c;
      continue;
    }
    if (c === '"' && !started) { inQ = true; started = true; continue; }
    if (c === d) { row.push(field); field = ''; started = false; continue; }
    if (c === '\r') continue;
    if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; started = false; continue; }
    field += c;
    started = true;
  }
  if (field !== '' || row.length) { row.push(field); rows.push(row); }

  // Bỏ dòng trống hoàn toàn nhưng GIỮ số dòng gốc để báo lỗi cho đúng.
  const out = [];
  rows.forEach((r, i) => {
    if (r.every((x) => !String(x).trim())) return;
    out.push({ line: i + 1, cells: r.map((x) => String(x).trim()) });
  });
  return { delimiter: d, rows: out };
}

/** Ghép tiêu đề với dữ liệu, khớp tên cột không phân biệt dấu và hoa thường. */
function toRecords(parsed, aliases = {}) {
  if (!parsed.rows.length) return { ok: false, error: 'EMPTY_FILE', records: [], header: [] };
  const header = parsed.rows[0].cells;
  const keyed = header.map((h) => {
    const k = viKey(h).replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');
    return aliases[k] || k;
  });
  const records = parsed.rows.slice(1).map((r) => {
    const obj = {};
    keyed.forEach((k, i) => { if (k) obj[k] = r.cells[i] ?? ''; });
    return { line: r.line, data: obj, raw: r.cells };
  });
  return { ok: true, header, keyed, records };
}

// ── CSV: ghi ────────────────────────────────────────────────────────────────

function toCSV(rows, columns = null, { delimiter = ',', bom = true } = {}) {
  const cols = columns || [...new Set(rows.flatMap((r) => Object.keys(r)))];
  const esc = (v) => {
    if (v === null || v === undefined) return '';
    const s = Array.isArray(v) ? v.join(' | ') : (typeof v === 'object' ? JSON.stringify(v) : String(v));
    return new RegExp(`["\\n\\r${delimiter}]`).test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const head = cols.map((c) => (typeof c === 'object' ? c.label : c)).join(delimiter);
  const body = rows.map((r) => cols.map((c) => esc(typeof c === 'object' ? r[c.key] : r[c])).join(delimiter));
  return (bom ? BOM : '') + [head, ...body].join('\n') + '\n';
}

// ── Bộ chuyển đổi giá trị ───────────────────────────────────────────────────

const parseGrade = (v) => {
  const m = String(v).match(/\d{1,2}/);
  const n = m ? Number(m[0]) : NaN;
  return Number.isInteger(n) && n >= 1 && n <= 12 ? n : null;
};

const parseDate = (v) => {
  const s = String(v).trim();
  if (!s) return null;
  let m = s.match(/^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})$/);           // 05/09/2012
  if (m) return Date.UTC(+m[3], +m[2] - 1, +m[1]);
  m = s.match(/^(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})$/);               // 2012-09-05
  if (m) return Date.UTC(+m[1], +m[2] - 1, +m[3]);
  const t = Date.parse(s);
  return Number.isNaN(t) ? null : t;
};

const parsePhone = (v) => {
  const raw = String(v ?? '').trim();
  if (!raw) return '';
  const d = raw.replace(/[^\d+]/g, '');
  // Có nhập mà không ra số nào: đó là rác, phải báo chứ không được âm thầm bỏ.
  if (!d) return null;
  return /^(\+84|0)\d{8,10}$/.test(d) ? d : null;
};

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

// Tên cột chấp nhận được — người dùng đặt tiêu đề kiểu gì cũng khớp.
const LEARNER_ALIASES = {
  ma: 'id', ma_hv: 'id', ma_hoc_vien: 'id', id: 'id', stt: '_stt',
  ho_ten: 'fullName', hoten: 'fullName', ten: 'fullName', full_name: 'fullName', name: 'fullName',
  lop: 'grade', khoi: 'grade', grade: 'grade',
  ma_lop: 'classId', lop_hoc: 'classId', class_id: 'classId',
  ngay_sinh: 'dob', dob: 'dob', birthday: 'dob',
  gioi_tinh: 'gender', gender: 'gender',
  email: 'email', dien_thoai: 'phone', sdt: 'phone', phone: 'phone',
  phu_huynh: 'parentName', ten_phu_huynh: 'parentName',
  sdt_phu_huynh: 'parentPhone', dien_thoai_phu_huynh: 'parentPhone',
  ghi_chu: 'note', note: 'note',
};

class Portability {
  constructor({ learners, classes, items, users = null, org = null, audit = null }) {
    this.learners = learners;
    this.classes = classes;
    this.items = items;
    this.users = users;
    this.org = org;
    this.audit = audit;
    this.stats = { imports: 0, rowsAccepted: 0, rowsRejected: 0, exports: 0 };
  }

  // ── NHẬP HỌC VIÊN ────────────────────────────────────────────────────────

  /**
   * @param {string} csv  nội dung tệp
   * @param {object} o {classId, dryRun, by, allowUpdate}
   */
  importLearners(csv, { classId = null, dryRun = true, by = 'admin', allowUpdate = false } = {}) {
    const parsed = parseCSV(csv);
    const rec = toRecords(parsed, LEARNER_ALIASES);
    if (!rec.ok) return { ok: false, error: rec.error, hint: 'Tệp rỗng hoặc không có dòng tiêu đề' };
    if (!rec.keyed.includes('fullName')) {
      return { ok: false, error: 'MISSING_COLUMN', need: 'Họ tên', found: rec.header };
    }
    if (classId && !this.classes.has(classId)) return { ok: false, error: 'CLASS_NOT_FOUND', classId };

    const accepted = [];
    const rejected = [];
    const warnings = [];
    const seenInFile = new Map();   // khoá trùng trong chính tệp
    const cls = classId ? this.classes.get(classId) : null;
    let capacityLeft = cls ? cls.capacity - (cls.learnerIds || []).length : Infinity;

    for (const r of rec.records) {
      const d = r.data;
      const problems = [];
      const fullName = String(d.fullName || '').replace(/\s+/g, ' ').trim();
      if (!fullName) problems.push('thiếu họ tên');
      if (fullName && fullName.length < 2) problems.push('họ tên quá ngắn');
      if (fullName.length > 80) problems.push('họ tên quá dài');

      const grade = d.grade !== undefined && String(d.grade).trim() ? parseGrade(d.grade) : (cls ? cls.grade : null);
      if (d.grade && parseGrade(d.grade) === null) problems.push(`lớp "${d.grade}" không hợp lệ (1–12)`);
      if (grade === null) problems.push('thiếu lớp và không suy ra được từ lớp đích');

      let dob = null;
      if (d.dob) {
        dob = parseDate(d.dob);
        if (dob === null) problems.push(`ngày sinh "${d.dob}" không đọc được (dùng 05/09/2012 hoặc 2012-09-05)`);
        else if (dob > Date.now()) problems.push('ngày sinh ở tương lai');
      }

      if (d.email && !EMAIL_RE.test(d.email)) problems.push(`email "${d.email}" không hợp lệ`);
      let phone = '';
      if (d.phone) {
        phone = parsePhone(d.phone);
        if (phone === null) { problems.push(`số điện thoại "${d.phone}" không hợp lệ`); phone = ''; }
      }
      let parentPhone = '';
      if (d.parentPhone) {
        parentPhone = parsePhone(d.parentPhone);
        if (parentPhone === null) { warnings.push({ line: r.line, warning: `số điện thoại phụ huynh "${d.parentPhone}" không hợp lệ, đã bỏ qua` }); parentPhone = ''; }
      }

      // Khoá nhận diện: mã nếu có, không thì họ tên + ngày sinh + lớp.
      const key = d.id ? `ID:${d.id}` : `NM:${viKey(fullName)}|${dob || ''}|${grade || ''}`;
      if (seenInFile.has(key)) {
        rejected.push({ line: r.line, fullName, reason: `trùng với dòng ${seenInFile.get(key)} trong cùng tệp` });
        continue;
      }

      const existing = d.id ? this.learners.get(d.id)
        : this.learners.find((l) => viKey(l.fullName || '') === viKey(fullName) && (l.dob || null) === dob && l.grade === grade);
      if (existing && !allowUpdate) {
        rejected.push({ line: r.line, fullName, reason: `đã có trong hệ thống (${existing.id}); bật "cho phép cập nhật" nếu muốn ghi đè` });
        continue;
      }

      if (!existing && capacityLeft <= 0) {
        rejected.push({ line: r.line, fullName, reason: `lớp ${classId} đã đủ sĩ số` });
        continue;
      }

      if (problems.length) {
        rejected.push({ line: r.line, fullName: fullName || '(trống)', reason: problems.join('; ') });
        continue;
      }

      seenInFile.set(key, r.line);
      const id = existing?.id || d.id || this._nextLearnerId(grade, accepted.length);
      accepted.push({
        line: r.line,
        mode: existing ? 'cập nhật' : 'thêm mới',
        doc: {
          id,
          fullName,
          grade,
          block: blockOfGrade(grade),
          dob,
          gender: /^(nam|m|male|trai)$/i.test(String(d.gender || '').trim()) ? 'nam'
            : /^(nu|nữ|f|female|gai|gái)$/i.test(String(d.gender || '').trim()) ? 'nữ' : null,
          email: d.email || '',
          phone: phone || '',
          parentName: d.parentName || '',
          parentPhone: parentPhone || '',
          note: d.note || '',
          level: existing?.level ?? 0,
          classId: classId || existing?.classId || null,
          importedAt: Date.now(),
          importedBy: by,
        },
      });
      if (!existing) capacityLeft--;
    }

    // Ghi thật
    let written = 0;
    if (!dryRun) {
      for (const a of accepted) {
        this.learners.put(a.doc);
        if (classId && this.org) {
          const cur = this.learners.get(a.doc.id);
          if (cur.classId !== classId || !(this.classes.get(classId).learnerIds || []).includes(a.doc.id)) {
            this.org.enroll(classId, a.doc.id, by, 'nhập từ tệp');
          }
        }
        written++;
      }
      this.stats.imports++;
      this.stats.rowsAccepted += accepted.length;
      this.stats.rowsRejected += rejected.length;
      this.audit?.record({
        actor: by, action: 'import.learners', verdict: 'ALLOW', severity: 0,
        detail: { classId, accepted: accepted.length, rejected: rejected.length },
      });
    }

    return {
      ok: true,
      dryRun,
      delimiter: parsed.delimiter,
      columnsFound: rec.header,
      totalRows: rec.records.length,
      accepted: accepted.length,
      rejected: rejected.length,
      warnings: warnings.length,
      written,
      acceptRate: rec.records.length ? round(accepted.length / rec.records.length, 3) : 0,
      preview: accepted.slice(0, 10).map((a) => ({ line: a.line, mode: a.mode, id: a.doc.id, fullName: a.doc.fullName, grade: a.doc.grade })),
      problems: rejected,
      warningList: warnings,
      summary: dryRun
        ? `Chạy thử: ${accepted.length} dòng nhận được, ${rejected.length} dòng phải sửa. Chưa ghi gì.`
        : `Đã nhập ${written} học viên, từ chối ${rejected.length} dòng.`,
    };
  }

  _nextLearnerId(grade, offset = 0) {
    const n = this.learners.count() + offset + 1;
    return `HV${String(grade).padStart(2, '0')}-${String(n).padStart(5, '0')}`;
  }

  // ── XUẤT ─────────────────────────────────────────────────────────────────

  exportLearners({ classId = null, format = 'csv' } = {}) {
    const rows = (classId
      ? (this.classes.get(classId)?.learnerIds || []).map((id) => this.learners.get(id)).filter(Boolean)
      : this.learners.all())
      .sort((a, b) => String(a.fullName).localeCompare(String(b.fullName), 'vi'))
      .map((l) => ({
        ma: l.id,
        ho_ten: l.fullName,
        lop: l.grade,
        ma_lop: l.classId || '',
        tang: `L${l.level ?? 0}`,
        ngay_sinh: l.dob ? new Date(l.dob).toISOString().slice(0, 10) : '',
        gioi_tinh: l.gender || '',
        email: l.email || '',
        dien_thoai: l.phone || '',
        phu_huynh: l.parentName || '',
        sdt_phu_huynh: l.parentPhone || '',
        ghi_chu: l.note || '',
      }));
    this.stats.exports++;
    if (format === 'json') return { ok: true, format, count: rows.length, data: rows };
    // Cột cố định: tệp rỗng vẫn phải có dòng tiêu đề, nếu không người nhận
    // mở ra thấy tệp trắng và không biết phải điền gì.
    const cols = ['ma', 'ho_ten', 'lop', 'ma_lop', 'tang', 'ngay_sinh', 'gioi_tinh',
      'email', 'dien_thoai', 'phu_huynh', 'sdt_phu_huynh', 'ghi_chu'];
    return {
      ok: true, format: 'csv', count: rows.length,
      filename: classId ? `hoc-vien-${classId}.csv` : 'hoc-vien-toan-truong.csv',
      content: toCSV(rows, cols),
    };
  }

  exportItems({ formCode = null, status = null, format = 'csv' } = {}) {
    const rows = this.items.all()
      .filter((i) => (!formCode || i.formCode === formCode) && (!status || i.status === status))
      .sort((a, b) => String(a.id).localeCompare(String(b.id)))
      .map((i) => ({
        ma_bai: i.id,
        dang: i.formCode,
        do_kho: i.stars,
        tang: i.level,
        trang_thai: i.status,
        de_bai: i.stem,
        dap_an: i.answer,
        loi_giai: Array.isArray(i.solutionSteps) ? i.solutionSteps.join(' → ') : (i.solution || ''),
        bay: Array.isArray(i.traps) ? i.traps.join(' | ') : '',
        diem_chat_luong: i.quality?.weighted ?? '',
      }));
    this.stats.exports++;
    if (format === 'json') return { ok: true, format, count: rows.length, data: rows };
    return { ok: true, format: 'csv', count: rows.length, filename: 'kho-hoc-lieu.csv', content: toCSV(rows) };
  }

  /** Mẫu tệp nhập — để người dùng tải về điền, không phải tự đoán tên cột. */
  learnerTemplate() {
    return {
      ok: true,
      filename: 'mau-nhap-hoc-vien.csv',
      content: toCSV([
        { ho_ten: 'Nguyễn Văn An', lop: 9, ngay_sinh: '05/09/2012', gioi_tinh: 'Nam', phu_huynh: 'Nguyễn Văn Bình', sdt_phu_huynh: '0912345678', ghi_chu: '' },
        { ho_ten: 'Trần Thị Bình', lop: 9, ngay_sinh: '12/03/2012', gioi_tinh: 'Nữ', phu_huynh: 'Trần Văn Cường', sdt_phu_huynh: '0987654321', ghi_chu: 'Chuyển từ trường khác' },
      ], ['ho_ten', 'lop', 'ngay_sinh', 'gioi_tinh', 'email', 'dien_thoai', 'phu_huynh', 'sdt_phu_huynh', 'ghi_chu']),
      note: 'Cột bắt buộc: Họ tên. Các cột còn lại có thì tốt, không có cũng nhập được. Tên cột không phân biệt hoa thường và dấu.',
    };
  }

  status() { return { ...this.stats }; }
}

module.exports = Portability;
module.exports.parseCSV = parseCSV;
module.exports.toCSV = toCSV;
module.exports.toRecords = toRecords;
module.exports.detectDelimiter = detectDelimiter;
module.exports.LEARNER_ALIASES = LEARNER_ALIASES;
