'use strict';
/**
 * Nguyên thuỷ mật mã — chỉ dùng node:crypto, không phụ thuộc ngoài.
 * scrypt băm mật khẩu · TOTP RFC 6238 · chia sẻ bí mật M-of-N · HMAC ký lệnh.
 */

const crypto = require('node:crypto');

// ── Băm mật khẩu: scrypt (chống GPU, thay cho SHA-256 nhanh của bản cũ) ────
const SCRYPT = { N: 1 << 15, r: 8, p: 1, keylen: 64, maxmem: 96 * 1024 * 1024 };

function hashPassword(password, pepper = '') {
  const salt = crypto.randomBytes(16);
  const dk = crypto.scryptSync(String(password) + pepper, salt, SCRYPT.keylen, SCRYPT);
  return `scrypt$${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString('base64')}$${dk.toString('base64')}`;
}

function verifyPassword(password, stored, pepper = '') {
  try {
    const [algo, N, r, p, saltB64, dkB64] = String(stored).split('$');
    if (algo !== 'scrypt') return false;
    const salt = Buffer.from(saltB64, 'base64');
    const expected = Buffer.from(dkB64, 'base64');
    const dk = crypto.scryptSync(String(password) + pepper, salt, expected.length, {
      N: Number(N), r: Number(r), p: Number(p), maxmem: SCRYPT.maxmem,
    });
    return crypto.timingSafeEqual(dk, expected);
  } catch {
    return false;
  }
}

// ── TOTP (RFC 6238, HMAC-SHA1, 6 chữ số, bước 30 giây) ────────────────────
const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

function base32Encode(buf) {
  let bits = 0, value = 0, out = '';
  for (const byte of buf) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) { out += B32[(value >>> (bits - 5)) & 31]; bits -= 5; }
  }
  if (bits > 0) out += B32[(value << (5 - bits)) & 31];
  return out;
}

function base32Decode(str) {
  let bits = 0, value = 0;
  const out = [];
  for (const c of String(str).toUpperCase().replace(/=+$/, '')) {
    const idx = B32.indexOf(c);
    if (idx === -1) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) { out.push((value >>> (bits - 8)) & 255); bits -= 8; }
  }
  return Buffer.from(out);
}

function totpSecret() { return base32Encode(crypto.randomBytes(20)); }

function totpAt(secret, counter) {
  const key = base32Decode(secret);
  const buf = Buffer.alloc(8);
  buf.writeBigUInt64BE(BigInt(counter));
  const hmac = crypto.createHmac('sha1', key).update(buf).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const code = ((hmac[offset] & 0x7f) << 24) | (hmac[offset + 1] << 16) | (hmac[offset + 2] << 8) | hmac[offset + 3];
  return String(code % 1_000_000).padStart(6, '0');
}

function totpNow(secret, step = 30, at = Date.now()) {
  return totpAt(secret, Math.floor(at / 1000 / step));
}

/** Chấp nhận lệch ±window bước để bù đồng hồ lệch. */
function totpVerify(secret, token, { step = 30, window = 1, at = Date.now() } = {}) {
  const t = String(token || '').replace(/\s/g, '');
  if (!/^\d{6}$/.test(t)) return false;
  const counter = Math.floor(at / 1000 / step);
  for (let i = -window; i <= window; i++) {
    const cand = totpAt(secret, counter + i);
    if (crypto.timingSafeEqual(Buffer.from(cand), Buffer.from(t))) return true;
  }
  return false;
}

function otpauthURL(secret, { issuer = 'GITAmath', account = 'superadmin' } = {}) {
  return `otpauth://totp/${encodeURIComponent(issuer)}:${encodeURIComponent(account)}` +
    `?secret=${secret}&issuer=${encodeURIComponent(issuer)}&algorithm=SHA1&digits=6&period=30`;
}

// ── Chia sẻ bí mật M-of-N (Shamir trên GF(256)) ───────────────────────────
const EXP = new Uint8Array(512);
const LOG = new Uint8Array(256);
(function initGF() {
  let x = 1;
  for (let i = 0; i < 255; i++) {
    EXP[i] = x;
    LOG[x] = i;
    x <<= 1;                    // nhân 2 trong GF(2^8)
    if (x & 0x100) x ^= 0x11d;  // rút gọn theo đa thức nguyên thuỷ
  }
  for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255];
})();

const gmul = (a, b) => (a === 0 || b === 0 ? 0 : EXP[LOG[a] + LOG[b]]);
const gdiv = (a, b) => (a === 0 ? 0 : EXP[(LOG[a] - LOG[b] + 255) % 255]);

/** Chia secret thành n mảnh, cần m mảnh để khôi phục. */
function splitSecret(secretBuf, n, m) {
  if (m > n || m < 2 || n > 255) throw new Error('THAM_SO_CHIA_SE_KHONG_HOP_LE');
  const shares = Array.from({ length: n }, (_, i) => ({ x: i + 1, y: Buffer.alloc(secretBuf.length) }));
  for (let b = 0; b < secretBuf.length; b++) {
    const coeffs = [secretBuf[b], ...crypto.randomBytes(m - 1)];
    for (const s of shares) {
      let acc = 0;
      for (let k = coeffs.length - 1; k >= 0; k--) acc = gmul(acc, s.x) ^ coeffs[k];
      s.y[b] = acc;
    }
  }
  return shares.map((s) => `${s.x}-${s.y.toString('hex')}`);
}

/** Khôi phục secret từ ≥m mảnh (nội suy Lagrange tại x=0). */
function combineShares(shareStrings) {
  const parts = shareStrings.map((s) => {
    const [x, hex] = String(s).split('-');
    return { x: Number(x), y: Buffer.from(hex, 'hex') };
  });
  const len = parts[0].y.length;
  const out = Buffer.alloc(len);
  for (let b = 0; b < len; b++) {
    let acc = 0;
    for (let i = 0; i < parts.length; i++) {
      let num = 1, den = 1;
      for (let j = 0; j < parts.length; j++) {
        if (i === j) continue;
        num = gmul(num, parts[j].x);
        den = gmul(den, parts[i].x ^ parts[j].x);
      }
      acc ^= gmul(parts[i].y[b], gdiv(num, den));
    }
    out[b] = acc;
  }
  return out;
}

// ── Ký lệnh HMAC ───────────────────────────────────────────────────────────
function signCommand(payload, key) {
  return crypto.createHmac('sha256', key).update(JSON.stringify(payload)).digest('hex');
}

function verifyCommand(payload, signature, key) {
  const expected = signCommand(payload, key);
  try {
    return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(String(signature)));
  } catch { return false; }
}

const randomToken = (bytes = 32) => crypto.randomBytes(bytes).toString('base64url');
const sha256hex = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');

module.exports = {
  hashPassword, verifyPassword,
  totpSecret, totpNow, totpVerify, otpauthURL, base32Encode, base32Decode,
  splitSecret, combineShares,
  signCommand, verifyCommand,
  randomToken, sha256hex,
};
