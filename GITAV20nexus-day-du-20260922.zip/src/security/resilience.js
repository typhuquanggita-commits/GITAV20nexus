'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  LÁ CHẮN CHỐNG NHIỄU — giữ 500 agent chạy xuyên suốt
 * ═══════════════════════════════════════════════════════════════════════════
 *  Bảy cơ chế, chạy đồng thời:
 *   1. LỌC NHIỄU ĐẦU VÀO   chặn đầu vào độc/rác trước khi tới agent
 *   2. NGĂN KHOANG          sự cố một khối không lan sang khối khác
 *   3. CÁCH LY              agent hỏng bị đưa ra khỏi vòng phân công
 *   4. GIẢM CHẤN DAO ĐỘNG   agent lúc tốt lúc xấu bị giữ lại, không thả ra ngay
 *   5. CHÓ CANH             phát hiện agent treo, giải phóng chỗ bị kẹt
 *   6. ÁP LỰC NGƯỢC         hàng đợi quá sâu thì từ chối sớm, không sập
 *   7. TỰ CHỮA              hết thời gian phạt thì đưa agent trở lại đội hình
 * ═══════════════════════════════════════════════════════════════════════════
 */

const bus = require('../kernel/eventbus');
const L = require('../logger');
const { round, clamp, viKey } = require('../utils');

// ── 1. Lọc nhiễu đầu vào ───────────────────────────────────────────────────
const NOISE_RULES = [
  { id: 'EMPTY', test: (s) => !s || !s.trim(), reason: 'Đầu vào rỗng' },
  { id: 'TOO_SHORT', test: (s) => s.trim().length < 3, reason: 'Đầu vào quá ngắn để xử lý' },
  { id: 'TOO_LONG', test: (s) => s.length > 32000, reason: 'Đầu vào vượt giới hạn' },
  { id: 'REPEAT_CHAR', test: (s) => /(.)\1{40,}/.test(s), reason: 'Chuỗi ký tự lặp bất thường' },
  { id: 'REPEAT_TOKEN', test: (s) => { const w = s.split(/\s+/); return w.length > 20 && new Set(w).size / w.length < 0.12; }, reason: 'Lặp từ bất thường' },
  { id: 'NO_LETTERS', test: (s) => s.length > 20 && !/[\p{L}]/u.test(s), reason: 'Không có ký tự chữ' },
  { id: 'CONTROL_CHARS', test: (s) => /[\u0000-\u0008\u000B\u000C\u000E-\u001F]/.test(s), reason: 'Chứa ký tự điều khiển' },
  { id: 'ZALGO', test: (s) => (s.match(/[̀-ͯ]/g) || []).length > s.length * 0.3, reason: 'Dấu tổ hợp bất thường' },
  { id: 'BASE64_BLOB', test: (s) => /[A-Za-z0-9+/]{400,}={0,2}/.test(s), reason: 'Khối mã hoá lớn đáng ngờ' },
  { id: 'HOMOGLYPH', test: (s) => /[аоресх]{3,}/.test(s), reason: 'Ký tự nhìn giống chữ Latin (giả mạo)' },
];

const STATES = { HEALTHY: 'HEALTHY', DEGRADED: 'DEGRADED', QUARANTINED: 'QUARANTINED', STALLED: 'STALLED' };

const QUARANTINE_MS = 120_000;
const FLAP_WINDOW_MS = 300_000;
const FLAP_THRESHOLD = 4;      // đổi trạng thái 4 lần trong 5 phút = dao động
const FLAP_HOLD_MS = 600_000;
const STALL_MS = 120_000;      // nhận việc quá 2 phút không xong = treo
const DEGRADE_AFTER = 2;       // 2 lỗi liên tiếp
const QUARANTINE_AFTER = 5;    // 5 lỗi liên tiếp

class ResilienceShield {
  constructor({ agents, capacity, runtime, queue, scheduler }) {
    this.capacity = capacity;
    this.runtime = runtime;
    this.queue = queue;
    this.scheduler = scheduler;

    this.health = new Map(agents.map((a) => [a.id, {
      agentId: a.id, division: a.division, state: STATES.HEALTHY,
      consecutiveFailures: 0, totalFailures: 0, totalOk: 0,
      quarantinedUntil: 0, holdUntil: 0,
      transitions: [], inflightSince: 0, lastSeenAt: Date.now(),
    }]));

    this.stats = {
      noiseBlocked: 0, byRule: Object.create(null),
      quarantined: 0, released: 0, flapsDamped: 0,
      stallsDetected: 0, slotsReclaimed: 0, backpressureRejects: 0, healed: 0,
    };

    this._watchdog = setInterval(() => this.sweep(), 15_000);
    if (this._watchdog.unref) this._watchdog.unref();

    bus.on('agent:task_failed', ({ agentId, reason }) => this.reportFailure(agentId, reason));
    bus.on('agent:task_done', ({ agentId }) => this.reportSuccess(agentId));
  }

  // ── 1. LỌC NHIỄU ─────────────────────────────────────────────────────────
  filterInput(input) {
    const s = String(input ?? '');
    for (const r of NOISE_RULES) {
      let hit = false;
      try { hit = r.test(s); } catch { hit = false; }
      if (hit) {
        this.stats.noiseBlocked++;
        this.stats.byRule[r.id] = (this.stats.byRule[r.id] || 0) + 1;
        return { ok: false, rule: r.id, reason: r.reason };
      }
    }
    return { ok: true, signal: round(clamp(new Set(viKey(s).split(/\s+/)).size / Math.max(s.split(/\s+/).length, 1), 0, 1), 3) };
  }

  // ── 6. ÁP LỰC NGƯỢC ──────────────────────────────────────────────────────
  admissionCheck({ input, priority = 'normal' } = {}) {
    const noise = this.filterInput(input);
    if (!noise.ok) return { ok: false, error: 'NOISE_REJECTED', ...noise };

    const waiting = this.queue ? this.queue.waiting : 0;
    const cap = this.capacity.status().global;
    const load = cap.utilization;

    // Chỉ còn nhận việc critical khi hệ đang quá tải.
    if (waiting > 2000 && priority !== 'critical') {
      this.stats.backpressureRejects++;
      return { ok: false, error: 'BACKPRESSURE', waiting, hint: 'Hàng đợi quá sâu, thử lại sau' };
    }
    if (load > 0.95 && priority === 'low') {
      this.stats.backpressureRejects++;
      return { ok: false, error: 'BACKPRESSURE', load, hint: 'Tải cao, việc ưu tiên thấp bị hoãn' };
    }
    return { ok: true, waiting, load, signal: noise.signal };
  }

  // ── 3/4. CÁCH LY & GIẢM CHẤN ─────────────────────────────────────────────
  _transition(h, next, reason) {
    if (h.state === next) return;
    const now = Date.now();
    h.transitions.push({ at: now, from: h.state, to: next, reason });
    h.transitions = h.transitions.filter((t) => now - t.at <= FLAP_WINDOW_MS);
    h.state = next;

    // Dao động: đổi trạng thái quá nhiều lần trong cửa sổ → giữ lại lâu hơn
    if (h.transitions.length >= FLAP_THRESHOLD) {
      h.holdUntil = now + FLAP_HOLD_MS;
      this.stats.flapsDamped++;
      bus.safeEmit('resilience:flapping', { agentId: h.agentId, transitions: h.transitions.length });
      L.warn(`Chống nhiễu: ${h.agentId} dao động ${h.transitions.length} lần — giữ ${FLAP_HOLD_MS / 60000} phút`);
    }
  }

  /**
   * Lỗi do HỆ THỐNG TỰ ĐIỀU TIẾT, không phải do agent yếu kém.
   * Bị từ chối vì hết chỗ là backpressure đang làm đúng việc của nó. Tính đó
   * là lỗi của agent thì dưới tải cao đội hình sẽ tự cách ly chính mình —
   * đúng lúc cần đủ người nhất lại còn ít người nhất.
   */
  static THROTTLE_ERRORS = new Set([
    'CAPACITY_LIMIT', 'NO_AGENT_AVAILABLE', 'BACKPRESSURE', 'RATE_LIMIT',
    'NOISE_REJECTED', 'DUPLICATE_TASK', 'GUARDRAIL_BLOCK',
  ]);

  reportFailure(agentId, error = null) {
    if (error && ResilienceShield.THROTTLE_ERRORS.has(error)) {
      this.stats.throttleIgnored = (this.stats.throttleIgnored || 0) + 1;
      return { ok: true, ignored: true, reason: 'điều tiết tải, không tính là lỗi agent' };
    }
    const h = this.health.get(agentId);
    if (!h) return;
    h.consecutiveFailures++;
    h.totalFailures++;
    h.lastSeenAt = Date.now();
    h.inflightSince = 0;

    if (h.consecutiveFailures >= QUARANTINE_AFTER) {
      h.quarantinedUntil = Date.now() + QUARANTINE_MS;
      this.stats.quarantined++;
      this._transition(h, STATES.QUARANTINED, `${h.consecutiveFailures} lỗi liên tiếp`);
      bus.safeEmit('resilience:quarantined', { agentId, until: h.quarantinedUntil });
    } else if (h.consecutiveFailures >= DEGRADE_AFTER) {
      this._transition(h, STATES.DEGRADED, `${h.consecutiveFailures} lỗi liên tiếp`);
    }
  }

  reportSuccess(agentId) {
    const h = this.health.get(agentId);
    if (!h) return;
    h.consecutiveFailures = 0;
    h.totalOk++;
    h.lastSeenAt = Date.now();
    h.inflightSince = 0;
    if (h.state !== STATES.HEALTHY && Date.now() > h.holdUntil && Date.now() > h.quarantinedUntil) {
      this._transition(h, STATES.HEALTHY, 'hoàn thành việc thành công');
    }
  }

  markInflight(agentId) {
    const h = this.health.get(agentId);
    if (h) h.inflightSince = Date.now();
  }

  /** Agent có được nhận việc không — scheduler hỏi trước khi phân công. */
  isEligible(agentId) {
    const h = this.health.get(agentId);
    if (!h) return true;
    const now = Date.now();
    if (h.quarantinedUntil > now) return false;
    if (h.holdUntil > now) return false;
    return h.state !== STATES.STALLED;
  }

  // ── 5/7. CHÓ CANH & TỰ CHỮA ──────────────────────────────────────────────
  sweep() {
    const now = Date.now();
    let reclaimed = 0, healed = 0, stalled = 0;

    for (const h of this.health.values()) {
      // Treo: nhận việc quá lâu mà không báo xong
      if (h.inflightSince && now - h.inflightSince > STALL_MS) {
        this._transition(h, STATES.STALLED, `treo ${round((now - h.inflightSince) / 1000)}s`);
        h.inflightSince = 0;
        stalled++;
        this.stats.stallsDetected++;
        // Giải phóng chỗ bị kẹt để khối không bị nghẽn
        try { this.capacity.release(h.agentId, 0); reclaimed++; } catch { /* đã trả rồi */ }
        const agent = this.runtime?.get(h.agentId);
        if (agent) agent.state = 'IDLE';
      }

      // Hết hạn cách ly → đưa trở lại
      if (h.state === STATES.QUARANTINED && h.quarantinedUntil <= now && h.holdUntil <= now) {
        h.consecutiveFailures = 0;
        this._transition(h, STATES.HEALTHY, 'hết thời gian cách ly');
        this.stats.released++;
        healed++;
      }
      // Hết giữ do dao động
      if (h.state === STATES.STALLED && h.holdUntil <= now && h.quarantinedUntil <= now) {
        this._transition(h, STATES.HEALTHY, 'chó canh đưa trở lại');
        healed++;
      }
    }

    this.stats.slotsReclaimed += reclaimed;
    this.stats.healed += healed;
    if (stalled || healed) {
      bus.safeEmit('resilience:sweep', { stalled, healed, reclaimed });
    }
    return { stalled, healed, reclaimed };
  }

  // ── 2. NGĂN KHOANG: sức khoẻ theo khối ──────────────────────────────────
  divisionHealth() {
    const out = Object.create(null);
    for (const h of this.health.values()) {
      const d = (out[h.division] ??= { division: h.division, total: 0, healthy: 0, degraded: 0, quarantined: 0, stalled: 0 });
      d.total++;
      if (h.state === STATES.HEALTHY) d.healthy++;
      else if (h.state === STATES.DEGRADED) d.degraded++;
      else if (h.state === STATES.QUARANTINED) d.quarantined++;
      else if (h.state === STATES.STALLED) d.stalled++;
    }
    for (const d of Object.values(out)) {
      d.availability = round(d.healthy / d.total, 3);
      d.breached = d.availability < 0.5; // khối mất quá nửa đội hình
    }
    return Object.values(out);
  }

  /** Tỉ lệ đội hình sẵn sàng — chỉ số sống còn của "500 agent chạy xuyên suốt". */
  fleetReadiness() {
    const all = [...this.health.values()];
    const eligible = all.filter((h) => this.isEligible(h.agentId)).length;
    const ok = all.reduce((s, h) => s + h.totalOk, 0);
    const fail = all.reduce((s, h) => s + h.totalFailures, 0);
    return {
      total: all.length,
      eligible,
      readiness: round(eligible / all.length, 4),
      signalToNoise: fail ? round(ok / fail, 2) : (ok ? Infinity : 0),
      byState: all.reduce((m, h) => { m[h.state] = (m[h.state] || 0) + 1; return m; }, {}),
    };
  }

  /** Can thiệp tay của Super Admin. */
  quarantine(agentId, ms = QUARANTINE_MS, reason = 'thủ công') {
    const h = this.health.get(agentId);
    if (!h) return { ok: false, error: 'AGENT_NOT_FOUND' };
    h.quarantinedUntil = Date.now() + ms;
    this._transition(h, STATES.QUARANTINED, reason);
    this.stats.quarantined++;
    return { ok: true, agentId, until: h.quarantinedUntil };
  }

  release(agentId) {
    const h = this.health.get(agentId);
    if (!h) return { ok: false, error: 'AGENT_NOT_FOUND' };
    h.quarantinedUntil = 0; h.holdUntil = 0; h.consecutiveFailures = 0;
    this._transition(h, STATES.HEALTHY, 'giải phóng thủ công');
    this.stats.released++;
    return { ok: true, agentId };
  }

  healAll() {
    let n = 0;
    for (const h of this.health.values()) {
      if (h.state !== STATES.HEALTHY) {
        h.quarantinedUntil = 0; h.holdUntil = 0; h.consecutiveFailures = 0; h.inflightSince = 0;
        this._transition(h, STATES.HEALTHY, 'chữa toàn đội');
        const agent = this.runtime?.get(h.agentId);
        if (agent) agent.state = 'IDLE';
        n++;
      }
    }
    this.stats.healed += n;
    return { ok: true, healed: n };
  }

  unhealthy(limit = 30) {
    return [...this.health.values()]
      .filter((h) => h.state !== STATES.HEALTHY)
      .sort((a, b) => b.consecutiveFailures - a.consecutiveFailures)
      .slice(0, limit)
      .map((h) => ({
        agentId: h.agentId, division: h.division, state: h.state,
        consecutiveFailures: h.consecutiveFailures, totalFailures: h.totalFailures,
        quarantinedForMs: Math.max(0, h.quarantinedUntil - Date.now()),
        heldForMs: Math.max(0, h.holdUntil - Date.now()),
        recentTransitions: h.transitions.length,
      }));
  }

  stop() { clearInterval(this._watchdog); }

  status() {
    return {
      mechanisms: 7,
      noiseRules: NOISE_RULES.length,
      fleet: this.fleetReadiness(),
      byDivision: this.divisionHealth(),
      thresholds: { DEGRADE_AFTER, QUARANTINE_AFTER, QUARANTINE_MS, FLAP_THRESHOLD, FLAP_WINDOW_MS, STALL_MS },
      stats: { ...this.stats, byRule: Object.entries(this.stats.byRule).sort((a, b) => b[1] - a[1]).slice(0, 8) },
      unhealthy: this.unhealthy(10),
    };
  }
}

module.exports = ResilienceShield;
module.exports.NOISE_RULES = NOISE_RULES;
module.exports.STATES = STATES;
