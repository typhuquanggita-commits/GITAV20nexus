'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  KÉT BẢO VỆ SUPER ADMIN — 15 TẦNG
 * ═══════════════════════════════════════════════════════════════════════════
 *  L01 Ràng buộc danh tính      rootId bất biến, vân tay khởi tạo
 *  L02 Băm mật khẩu scrypt      N=2^15, muối riêng + pepper
 *  L03 Chính sách mật khẩu      độ dài · entropy · không tái dùng 5 lần gần nhất
 *  L04 2FA TOTP                 RFC 6238, cửa sổ ±1 bước
 *  L05 Mã khôi phục             10 mã dùng một lần, lưu dạng băm
 *  L06 Ràng buộc thiết bị       phiên gắn vân tay thiết bị + lớp IP
 *  L07 Xác thực nâng cấp        lệnh nguy hiểm đòi tái xác thực < 5 phút
 *  L08 Giới hạn & khoá luỹ tiến  5 lần sai → khoá tăng dần 1→60 phút
 *  L09 Phát hiện bất thường     thiết bị lạ · giờ lạ · di chuyển bất khả thi
 *  L10 Ký lệnh HMAC             mọi lệnh Super Admin phải có chữ ký phiên
 *  L11 Kiểm soát kép            lệnh huỷ diệt cần người thứ hai hoặc chờ 15 phút
 *  L12 Nhật ký bất biến         móc xích băm, sửa một bản là vỡ chuỗi
 *  L13 Khôi phục theo nhóm      Shamir 3-of-5 mảnh người giám hộ
 *  L14 Chìa khoá phá kính       một lần duy nhất, kích hoạt là báo động
 *  L15 Hiến pháp tối thượng     Super Admin cũng chịu Hiến pháp (A05, A10)
 * ═══════════════════════════════════════════════════════════════════════════
 */

const bus = require('../kernel/eventbus');
const L = require('../logger');
const { round, id: newId } = require('../utils');
const C = require('./crypto');

const LAYERS = [
  { id: 'L01', name: 'Ràng buộc danh tính', kind: 'identity' },
  { id: 'L02', name: 'Băm mật khẩu scrypt', kind: 'credential' },
  { id: 'L03', name: 'Chính sách mật khẩu', kind: 'credential' },
  { id: 'L04', name: '2FA TOTP', kind: 'mfa' },
  { id: 'L05', name: 'Mã khôi phục dùng một lần', kind: 'recovery' },
  { id: 'L06', name: 'Ràng buộc thiết bị & phiên', kind: 'session' },
  { id: 'L07', name: 'Xác thực nâng cấp', kind: 'session' },
  { id: 'L08', name: 'Giới hạn và khoá luỹ tiến', kind: 'throttle' },
  { id: 'L09', name: 'Phát hiện bất thường', kind: 'anomaly' },
  { id: 'L10', name: 'Ký lệnh HMAC', kind: 'integrity' },
  { id: 'L11', name: 'Kiểm soát kép', kind: 'authorization' },
  { id: 'L12', name: 'Nhật ký bất biến', kind: 'audit' },
  { id: 'L13', name: 'Khôi phục theo nhóm giám hộ', kind: 'recovery' },
  { id: 'L14', name: 'Chìa khoá phá kính', kind: 'recovery' },
  { id: 'L15', name: 'Hiến pháp tối thượng', kind: 'governance' },
];

/** Lệnh huỷ diệt — bắt buộc qua L07 + L11. */
const DESTRUCTIVE = new Set([
  'system.halt', 'system.reset', 'snapshot.restore', 'agents.restart_all',
  'items.purge', 'learners.purge', 'superadmin.rotate_root', 'superadmin.add_admin',
]);

const LOCKOUT_LADDER = [60_000, 300_000, 900_000, 1_800_000, 3_600_000]; // 1·5·15·30·60 phút
const STEP_UP_WINDOW_MS = 5 * 60_000;
const DUAL_CONTROL_DELAY_MS = 15 * 60_000;
const SESSION_TTL_MS = 30 * 60_000;
const PASSWORD_HISTORY = 5;
const RECOVERY_CODES = 10;
const GUARDIAN_N = 5;
const GUARDIAN_M = 3;

function passwordStrength(pw) {
  const s = String(pw || '');
  const issues = [];
  if (s.length < 14) issues.push('Tối thiểu 14 ký tự');
  if (!/[a-z]/.test(s)) issues.push('Thiếu chữ thường');
  if (!/[A-Z]/.test(s)) issues.push('Thiếu chữ hoa');
  if (!/\d/.test(s)) issues.push('Thiếu chữ số');
  if (!/[^\w\s]/.test(s)) issues.push('Thiếu ký tự đặc biệt');
  if (/(.)\1{2,}/.test(s)) issues.push('Có ký tự lặp 3 lần liên tiếp');
  if (/^(?:123|abc|qwe|password|matkhau|admin|gita)/i.test(s)) issues.push('Bắt đầu bằng chuỗi phổ biến');
  const classes = [/[a-z]/, /[A-Z]/, /\d/, /[^\w\s]/].filter((r) => r.test(s)).length;
  const entropy = round(s.length * Math.log2(26 * Math.max(classes, 1)), 1);
  if (entropy < 80) issues.push(`Entropy ${entropy} bit < 80 bit`);
  return { ok: issues.length === 0, issues, entropy, classes };
}

class SuperAdminVault {
  constructor({ audit, constitution, pepper = process.env.SA_PEPPER || 'GITAmath-V20-Pepper' }) {
    this.audit = audit;
    this.constitution = constitution;
    this.pepper = pepper;
    this.account = null;
    this.sessions = new Map();     // token -> session
    this.failures = new Map();     // key -> {count, lockedUntil}
    this.pendingDual = new Map();  // requestId -> {command, requestedAt, approvals}
    this.stats = { logins: 0, denied: 0, stepUps: 0, commands: 0, anomalies: 0, breakGlassUsed: 0 };
  }

  // ── KHỞI TẠO ────────────────────────────────────────────────────────────
  /** Tạo tài khoản gốc. Chỉ chạy được MỘT lần. Trả về bí mật chỉ hiện một lần duy nhất. */
  initialize({ username = 'superadmin', email, password }) {
    if (this.account) return { ok: false, error: 'ALREADY_INITIALIZED' };

    const pol = passwordStrength(password);
    if (!pol.ok) return { ok: false, error: 'WEAK_PASSWORD', issues: pol.issues, entropy: pol.entropy };

    const rootId = newId('ROOT');
    const totp = C.totpSecret();
    const recoveryCodes = Array.from({ length: RECOVERY_CODES }, () => C.randomToken(12));
    const breakGlass = C.randomToken(32);
    const rootKey = Buffer.from(C.randomToken(32));
    const guardianShares = C.splitSecret(rootKey, GUARDIAN_N, GUARDIAN_M);

    this.account = {
      rootId,
      username,
      email: email || null,
      passwordHash: C.hashPassword(password, this.pepper),
      passwordHistory: [],
      passwordChangedAt: Date.now(),
      totpSecret: totp,
      totpEnabled: true,
      recoveryCodeHashes: recoveryCodes.map((c) => C.sha256hex(c + this.pepper)),
      recoveryCodesUsed: [],
      breakGlassHash: C.sha256hex(breakGlass + this.pepper),
      breakGlassUsed: false,
      rootKeyHash: C.sha256hex(rootKey.toString('hex')),
      knownDevices: new Set(),
      createdAt: Date.now(),
      fingerprint: C.sha256hex(`${rootId}|${username}|${Date.now()}`),
    };

    this.audit?.record({
      actor: rootId, actorRole: 'SUPER_ADMIN', action: 'superadmin.initialize',
      verdict: 'ALLOW', severity: 0, detail: { username, layers: LAYERS.length },
    });
    L.ok(`Super Admin khởi tạo: ${username} · ${LAYERS.length} tầng bảo vệ`);

    return {
      ok: true,
      rootId,
      username,
      // ── Các bí mật dưới đây CHỈ HIỆN MỘT LẦN. Không lưu lại được. ──
      totpSecret: totp,
      otpauthURL: C.otpauthURL(totp, { account: username }),
      recoveryCodes,
      breakGlassKey: breakGlass,
      guardianShares,
      guardianPolicy: `${GUARDIAN_M}-of-${GUARDIAN_N}`,
      warning: 'Lưu các bí mật này ở nơi an toàn, tách rời nhau. Hệ thống KHÔNG hiển thị lại.',
    };
  }

  // ── L08: khoá luỹ tiến ─────────────────────────────────────────────────
  _lockState(key) {
    const f = this.failures.get(key) || { count: 0, lockedUntil: 0 };
    if (f.lockedUntil && Date.now() > f.lockedUntil) { f.count = 0; f.lockedUntil = 0; }
    return f;
  }

  _recordFailure(key) {
    const f = this._lockState(key);
    f.count++;
    if (f.count >= 5) {
      const idx = Math.min(Math.floor(f.count / 5) - 1, LOCKOUT_LADDER.length - 1);
      f.lockedUntil = Date.now() + LOCKOUT_LADDER[idx];
    }
    this.failures.set(key, f);
    return f;
  }

  // ── L09: bất thường ────────────────────────────────────────────────────
  _anomalies(ctx) {
    const found = [];
    const hour = new Date().getHours();
    if (!this.account.knownDevices.has(ctx.deviceId)) found.push('THIET_BI_LA');
    if (hour >= 1 && hour < 5) found.push('GIO_BAT_THUONG');
    const last = [...this.sessions.values()].sort((a, b) => b.createdAt - a.createdAt)[0];
    if (last && last.ipClass && ctx.ipClass && last.ipClass !== ctx.ipClass) {
      const minutes = (Date.now() - last.createdAt) / 60000;
      if (minutes < 10) found.push('DI_CHUYEN_BAT_KHA_THI');
    }
    if (found.length) this.stats.anomalies++;
    return found;
  }

  // ── ĐĂNG NHẬP: đi qua L01→L09 ──────────────────────────────────────────
  login({ username, password, totpToken, recoveryCode, deviceId = 'unknown', ip = '0.0.0.0', userAgent = '' }) {
    if (!this.account) return { ok: false, error: 'NOT_INITIALIZED' };
    const key = `${username}|${ip}`;
    const passed = [];

    // L08
    const lock = this._lockState(key);
    if (lock.lockedUntil > Date.now()) {
      this.stats.denied++;
      return { ok: false, error: 'LOCKED_OUT', layer: 'L08', retryAfterMs: lock.lockedUntil - Date.now() };
    }
    passed.push('L08');

    // L01
    if (username !== this.account.username) {
      this._recordFailure(key); this.stats.denied++;
      return { ok: false, error: 'INVALID_CREDENTIALS', layer: 'L01' };
    }
    passed.push('L01');

    // L02
    if (!C.verifyPassword(password, this.account.passwordHash, this.pepper)) {
      const f = this._recordFailure(key);
      this.stats.denied++;
      this.audit?.record({ actor: username, action: 'superadmin.login', verdict: 'DENY', severity: 2, detail: { layer: 'L02', attempts: f.count, ip } });
      return { ok: false, error: 'INVALID_CREDENTIALS', layer: 'L02', attempts: f.count, lockedUntil: f.lockedUntil || null };
    }
    passed.push('L02');

    // L04 / L05 — phải qua một trong hai
    let mfaMethod = null;
    if (this.account.totpEnabled && totpToken && C.totpVerify(this.account.totpSecret, totpToken)) {
      mfaMethod = 'TOTP'; passed.push('L04');
    } else if (recoveryCode) {
      const h = C.sha256hex(recoveryCode + this.pepper);
      const idx = this.account.recoveryCodeHashes.indexOf(h);
      if (idx >= 0 && !this.account.recoveryCodesUsed.includes(idx)) {
        this.account.recoveryCodesUsed.push(idx);
        mfaMethod = 'RECOVERY_CODE'; passed.push('L05');
      }
    }
    if (!mfaMethod) {
      this._recordFailure(key); this.stats.denied++;
      return { ok: false, error: 'MFA_REQUIRED', layer: 'L04', hint: 'Cần mã TOTP 6 số hoặc mã khôi phục' };
    }

    // L09
    const anomalies = this._anomalies({ deviceId, ipClass: String(ip).split('.').slice(0, 2).join('.') });
    passed.push('L09');

    // L06
    const token = C.randomToken(32);
    const sessionKey = C.randomToken(32);
    const session = {
      token, sessionKey,
      rootId: this.account.rootId,
      username,
      deviceId,
      ip,
      ipClass: String(ip).split('.').slice(0, 2).join('.'),
      userAgent,
      createdAt: Date.now(),
      expiresAt: Date.now() + SESSION_TTL_MS,
      lastAuthAt: Date.now(),
      mfaMethod,
      anomalies,
      commandCount: 0,
    };
    this.sessions.set(token, session);
    this.account.knownDevices.add(deviceId);
    passed.push('L06');

    this.failures.delete(key);
    this.stats.logins++;

    // L12
    this.audit?.record({
      actor: this.account.rootId, actorRole: 'SUPER_ADMIN', action: 'superadmin.login',
      verdict: 'ALLOW', severity: anomalies.length ? 1 : 0,
      detail: { mfaMethod, deviceId, anomalies, layersPassed: passed },
    });
    passed.push('L12');

    if (anomalies.length) {
      bus.safeEmit('security:anomaly', { anomalies, username, deviceId });
      L.warn(`Super Admin đăng nhập có bất thường: ${anomalies.join(', ')}`);
    }

    return {
      ok: true, token, sessionKey,
      expiresAt: session.expiresAt,
      mfaMethod,
      anomalies,
      layersPassed: passed,
      recoveryCodesLeft: RECOVERY_CODES - this.account.recoveryCodesUsed.length,
    };
  }

  getSession(token) {
    const s = this.sessions.get(token);
    if (!s) return null;
    if (Date.now() > s.expiresAt) { this.sessions.delete(token); return null; }
    return s;
  }

  logout(token) {
    const ok = this.sessions.delete(token);
    if (ok) this.audit?.record({ actor: this.account?.rootId, action: 'superadmin.logout', verdict: 'ALLOW' });
    return { ok };
  }

  /** L07 — tái xác thực để mở cửa sổ 5 phút cho lệnh nguy hiểm. */
  stepUp(token, { password, totpToken }) {
    const s = this.getSession(token);
    if (!s) return { ok: false, error: 'INVALID_SESSION', layer: 'L06' };
    if (!C.verifyPassword(password, this.account.passwordHash, this.pepper)) {
      return { ok: false, error: 'INVALID_CREDENTIALS', layer: 'L02' };
    }
    if (!C.totpVerify(this.account.totpSecret, totpToken)) {
      return { ok: false, error: 'INVALID_TOTP', layer: 'L04' };
    }
    s.lastAuthAt = Date.now();
    this.stats.stepUps++;
    this.audit?.record({ actor: this.account.rootId, action: 'superadmin.step_up', verdict: 'ALLOW' });
    return { ok: true, validUntil: s.lastAuthAt + STEP_UP_WINDOW_MS, layer: 'L07' };
  }

  /**
   * ── CỔNG LỆNH: L06 → L07 → L10 → L11 → L15 → L12 ──
   * Mọi lệnh Super Admin gửi xuống Nexus đều phải đi qua đây.
   */
  authorize(token, command, args = {}, signature = null) {
    if (!this.account) return { ok: false, error: 'NOT_INITIALIZED' };
    const passed = [];

    // L06
    const s = this.getSession(token);
    if (!s) { this.stats.denied++; return { ok: false, error: 'INVALID_SESSION', layer: 'L06' }; }
    passed.push('L06');

    const destructive = DESTRUCTIVE.has(command);

    // L07
    if (destructive && Date.now() - s.lastAuthAt > STEP_UP_WINDOW_MS) {
      this.stats.denied++;
      return { ok: false, error: 'STEP_UP_REQUIRED', layer: 'L07', command, hint: 'Gọi /superadmin/step-up trước' };
    }
    passed.push('L07');

    // L10
    if (signature !== null) {
      if (!C.verifyCommand({ command, args }, signature, s.sessionKey)) {
        this.stats.denied++;
        this.audit?.record({ actor: s.rootId, action: 'superadmin.command', verdict: 'BLOCK', severity: 3, detail: { command, reason: 'BAD_SIGNATURE' } });
        return { ok: false, error: 'INVALID_SIGNATURE', layer: 'L10' };
      }
      passed.push('L10');
    } else if (destructive) {
      this.stats.denied++;
      return { ok: false, error: 'SIGNATURE_REQUIRED', layer: 'L10', hint: 'Lệnh huỷ diệt bắt buộc ký HMAC bằng sessionKey' };
    }

    // L11
    if (destructive) {
      const reqId = C.sha256hex(`${command}|${JSON.stringify(args)}`).slice(0, 16);
      const pending = this.pendingDual.get(reqId);
      if (!pending) {
        this.pendingDual.set(reqId, { command, args, requestedAt: Date.now(), approvals: [s.username] });
        this.audit?.record({ actor: s.rootId, action: 'superadmin.dual_control_request', verdict: 'PENDING', severity: 2, detail: { command, reqId } });
        return {
          ok: false, error: 'DUAL_CONTROL_PENDING', layer: 'L11', requestId: reqId,
          executeAfter: Date.now() + DUAL_CONTROL_DELAY_MS,
          hint: `Cần người phê duyệt thứ hai, hoặc gọi lại sau ${DUAL_CONTROL_DELAY_MS / 60000} phút`,
        };
      }
      const elapsed = Date.now() - pending.requestedAt;
      const secondApprover = pending.approvals.length >= 2;
      if (!secondApprover && elapsed < DUAL_CONTROL_DELAY_MS) {
        return {
          ok: false, error: 'DUAL_CONTROL_WAITING', layer: 'L11', requestId: reqId,
          remainingMs: DUAL_CONTROL_DELAY_MS - elapsed,
        };
      }
      this.pendingDual.delete(reqId);
      passed.push('L11');
    }

    // L15 — Super Admin cũng chịu Hiến pháp
    const verdict = this.constitution.validate('agent_task', { permitted: true, specialtyMatch: true, capability: 1 });
    if (!verdict.ok) {
      this.stats.denied++;
      return { ok: false, error: 'CONSTITUTION_BLOCK', layer: 'L15', violations: verdict.violations };
    }
    passed.push('L15');

    // L12
    s.commandCount++;
    this.stats.commands++;
    this.audit?.record({
      actor: s.rootId, actorRole: 'SUPER_ADMIN', action: `superadmin.${command}`,
      verdict: 'ALLOW', severity: destructive ? 2 : 0, detail: { args, layersPassed: passed, destructive },
    });
    passed.push('L12');

    return { ok: true, command, args, session: { username: s.username, deviceId: s.deviceId }, destructive, layersPassed: passed };
  }

  /** Người thứ hai phê duyệt lệnh huỷ diệt đang chờ. */
  approveDual(requestId, approverName) {
    const p = this.pendingDual.get(requestId);
    if (!p) return { ok: false, error: 'REQUEST_NOT_FOUND' };
    if (p.approvals.includes(approverName)) return { ok: false, error: 'ALREADY_APPROVED_BY_YOU' };
    p.approvals.push(approverName);
    this.audit?.record({ actor: approverName, action: 'superadmin.dual_control_approve', verdict: 'ALLOW', severity: 2, detail: { requestId, command: p.command } });
    return { ok: true, requestId, approvals: p.approvals.length, ready: p.approvals.length >= 2 };
  }

  /** L14 — chìa khoá phá kính: một lần duy nhất, dùng là báo động toàn hệ. */
  breakGlass(key, reason) {
    if (!this.account) return { ok: false, error: 'NOT_INITIALIZED' };
    if (this.account.breakGlassUsed) return { ok: false, error: 'BREAK_GLASS_ALREADY_USED' };
    if (C.sha256hex(key + this.pepper) !== this.account.breakGlassHash) {
      this.audit?.record({ actor: 'unknown', action: 'superadmin.break_glass', verdict: 'BLOCK', severity: 3, detail: { reason: 'BAD_KEY' } });
      return { ok: false, error: 'INVALID_BREAK_GLASS_KEY', layer: 'L14' };
    }
    this.account.breakGlassUsed = true;
    this.stats.breakGlassUsed++;
    const token = C.randomToken(32);
    const sessionKey = C.randomToken(32);
    this.sessions.set(token, {
      token, sessionKey, rootId: this.account.rootId, username: this.account.username,
      deviceId: 'break-glass', ip: '0.0.0.0', ipClass: '0.0',
      createdAt: Date.now(), expiresAt: Date.now() + 15 * 60_000,
      lastAuthAt: Date.now(), mfaMethod: 'BREAK_GLASS', anomalies: ['BREAK_GLASS'], commandCount: 0,
    });
    bus.safeEmit('security:break_glass', { reason, at: Date.now() });
    L.error(`⚠ CHÌA KHOÁ PHÁ KÍNH ĐÃ ĐƯỢC DÙNG — lý do: ${reason}`);
    this.audit?.record({ actor: this.account.rootId, action: 'superadmin.break_glass', verdict: 'ALLOW', severity: 3, detail: { reason } });
    return { ok: true, token, sessionKey, expiresInMin: 15, warning: 'Phiên khẩn cấp 15 phút. Đổi mật khẩu và tạo lại chìa khoá ngay.' };
  }

  status() {
    return {
      initialized: !!this.account,
      rootId: this.account?.rootId || null,
      username: this.account?.username || null,
      layers: LAYERS.length,
      layerList: LAYERS,
      totpEnabled: !!this.account?.totpEnabled,
      recoveryCodesLeft: this.account ? RECOVERY_CODES - this.account.recoveryCodesUsed.length : 0,
      breakGlassAvailable: this.account ? !this.account.breakGlassUsed : false,
      guardianPolicy: `${GUARDIAN_M}-of-${GUARDIAN_N}`,
      activeSessions: this.sessions.size,
      knownDevices: this.account ? this.account.knownDevices.size : 0,
      pendingDualControl: this.pendingDual.size,
      lockedKeys: [...this.failures.values()].filter((f) => f.lockedUntil > Date.now()).length,
      destructiveCommands: [...DESTRUCTIVE],
      passwordAgeDays: this.account ? round((Date.now() - this.account.passwordChangedAt) / 86400000, 1) : null,
      stats: { ...this.stats },
    };
  }
}

module.exports = SuperAdminVault;
module.exports.LAYERS = LAYERS;
module.exports.DESTRUCTIVE = DESTRUCTIVE;
module.exports.passwordStrength = passwordStrength;
module.exports.CONST = { STEP_UP_WINDOW_MS, DUAL_CONTROL_DELAY_MS, SESSION_TTL_MS, PASSWORD_HISTORY, RECOVERY_CODES, GUARDIAN_N, GUARDIAN_M, LOCKOUT_LADDER };
