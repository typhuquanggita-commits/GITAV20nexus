'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  KHÔI PHỤC — mật khẩu và toàn hệ thống
 * ═══════════════════════════════════════════════════════════════════════════
 *  Bốn đường khôi phục mật khẩu, độ tin cậy giảm dần:
 *    1. TOTP + mật khẩu cũ        (người dùng còn kiểm soát đủ)
 *    2. Mã khôi phục dùng một lần (mất điện thoại)
 *    3. Nhóm giám hộ 3-of-5       (mất cả hai thứ trên)
 *    4. Chìa khoá phá kính        (thảm hoạ — báo động, dùng một lần)
 *
 *  Khôi phục hệ thống: chọn ảnh chụp theo PHIÊN BẢN hoặc THỜI ĐIỂM,
 *  kiểm tra toàn vẹn băm, khôi phục rồi tự kiểm tra sau khôi phục.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const bus = require('../kernel/eventbus');
const L = require('../logger');
const { round, id: newId } = require('../utils');
const C = require('./crypto');
const { passwordStrength, CONST } = require('./superadmin-vault');

const CHALLENGE_TTL_MS = 15 * 60_000;

const METHODS = {
  TOTP: { id: 'TOTP', trust: 0.95, name: 'TOTP + mật khẩu hiện tại' },
  RECOVERY_CODE: { id: 'RECOVERY_CODE', trust: 0.85, name: 'Mã khôi phục dùng một lần' },
  GUARDIAN_QUORUM: { id: 'GUARDIAN_QUORUM', trust: 0.90, name: `Nhóm giám hộ ${CONST.GUARDIAN_M}-of-${CONST.GUARDIAN_N}` },
  BREAK_GLASS: { id: 'BREAK_GLASS', trust: 0.60, name: 'Chìa khoá phá kính (khẩn cấp)' },
};

class RecoveryService {
  constructor({ vault, snapshots, audit, nexusRef = null }) {
    this.vault = vault;
    this.snapshots = snapshots;
    this.audit = audit;
    this.nexus = nexusRef;
    this.challenges = new Map();
    this.stats = { started: 0, completed: 0, failed: 0, systemRestores: 0, byMethod: Object.create(null) };
  }

  // ═══ KHÔI PHỤC MẬT KHẨU ═══════════════════════════════════════════════
  start({ username, method, ip = '0.0.0.0' }) {
    const acc = this.vault.account;
    if (!acc) return { ok: false, error: 'NOT_INITIALIZED' };
    if (username !== acc.username) {
      // Không tiết lộ tài khoản có tồn tại hay không.
      return { ok: true, challengeId: newId('RC'), hint: 'Nếu tài khoản tồn tại, quy trình khôi phục đã bắt đầu.' };
    }
    if (!METHODS[method]) return { ok: false, error: 'UNKNOWN_METHOD', methods: Object.keys(METHODS) };

    const ch = {
      id: newId('RC'),
      username, method, ip,
      createdAt: Date.now(),
      expiresAt: Date.now() + CHALLENGE_TTL_MS,
      shares: [],
      verified: false,
      attempts: 0,
    };
    this.challenges.set(ch.id, ch);
    this.stats.started++;
    this.stats.byMethod[method] = (this.stats.byMethod[method] || 0) + 1;

    this.audit?.record({ actor: username, action: 'recovery.start', verdict: 'PENDING', severity: 2, detail: { method, ip } });

    const need = {
      TOTP: 'Gửi { currentPassword, totpToken }',
      RECOVERY_CODE: 'Gửi { recoveryCode }',
      GUARDIAN_QUORUM: `Gửi từng mảnh qua submitShare(), đủ ${CONST.GUARDIAN_M} mảnh`,
      BREAK_GLASS: 'Gửi { breakGlassKey, reason }',
    }[method];

    return { ok: true, challengeId: ch.id, method, trust: METHODS[method].trust, expiresAt: ch.expiresAt, need };
  }

  /** Nộp một mảnh giám hộ. Đủ M mảnh thì thử ghép và đối chiếu băm khoá gốc. */
  submitShare(challengeId, share) {
    const ch = this.challenges.get(challengeId);
    if (!ch || Date.now() > ch.expiresAt) return { ok: false, error: 'CHALLENGE_EXPIRED' };
    if (ch.method !== 'GUARDIAN_QUORUM') return { ok: false, error: 'WRONG_METHOD' };
    if (ch.shares.includes(share)) return { ok: false, error: 'DUPLICATE_SHARE' };

    ch.shares.push(share);
    if (ch.shares.length < CONST.GUARDIAN_M) {
      return { ok: true, collected: ch.shares.length, need: CONST.GUARDIAN_M - ch.shares.length };
    }
    try {
      const rootKey = C.combineShares(ch.shares);
      if (C.sha256hex(rootKey.toString('hex')) !== this.vault.account.rootKeyHash) {
        ch.shares = [];
        this.stats.failed++;
        return { ok: false, error: 'SHARES_DO_NOT_RECONSTRUCT', hint: 'Sai mảnh hoặc mảnh không cùng bộ' };
      }
      ch.verified = true;
      return { ok: true, collected: ch.shares.length, verified: true, next: 'Gọi complete() với mật khẩu mới' };
    } catch (e) {
      ch.shares = [];
      this.stats.failed++;
      return { ok: false, error: 'SHARE_COMBINE_FAILED', detail: e.message };
    }
  }

  /** Hoàn tất: xác minh theo phương thức rồi đặt mật khẩu mới. */
  complete(challengeId, { newPassword, currentPassword, totpToken, recoveryCode, breakGlassKey, reason }) {
    const ch = this.challenges.get(challengeId);
    if (!ch || Date.now() > ch.expiresAt) return { ok: false, error: 'CHALLENGE_EXPIRED' };
    const acc = this.vault.account;
    ch.attempts++;
    if (ch.attempts > 5) { this.challenges.delete(challengeId); this.stats.failed++; return { ok: false, error: 'TOO_MANY_ATTEMPTS' }; }

    // ── Xác minh danh tính theo phương thức ──
    let verified = ch.verified;
    if (!verified) {
      if (ch.method === 'TOTP') {
        verified = C.verifyPassword(currentPassword, acc.passwordHash, this.vault.pepper)
          && C.totpVerify(acc.totpSecret, totpToken);
      } else if (ch.method === 'RECOVERY_CODE') {
        const h = C.sha256hex(recoveryCode + this.vault.pepper);
        const idx = acc.recoveryCodeHashes.indexOf(h);
        if (idx >= 0 && !acc.recoveryCodesUsed.includes(idx)) { acc.recoveryCodesUsed.push(idx); verified = true; }
      } else if (ch.method === 'BREAK_GLASS') {
        const r = this.vault.breakGlass(breakGlassKey, reason || 'khôi phục mật khẩu');
        verified = r.ok;
      }
    }
    if (!verified) {
      this.stats.failed++;
      this.audit?.record({ actor: ch.username, action: 'recovery.complete', verdict: 'DENY', severity: 3, detail: { method: ch.method } });
      return { ok: false, error: 'VERIFICATION_FAILED', method: ch.method, attemptsLeft: 5 - ch.attempts };
    }

    // ── Chính sách mật khẩu mới (L03) ──
    const pol = passwordStrength(newPassword);
    if (!pol.ok) return { ok: false, error: 'WEAK_PASSWORD', issues: pol.issues, entropy: pol.entropy };
    for (const old of [acc.passwordHash, ...acc.passwordHistory]) {
      if (C.verifyPassword(newPassword, old, this.vault.pepper)) {
        return { ok: false, error: 'PASSWORD_REUSED', hint: `Không được dùng lại ${CONST.PASSWORD_HISTORY} mật khẩu gần nhất` };
      }
    }

    acc.passwordHistory.unshift(acc.passwordHash);
    acc.passwordHistory = acc.passwordHistory.slice(0, CONST.PASSWORD_HISTORY);
    acc.passwordHash = C.hashPassword(newPassword, this.vault.pepper);
    acc.passwordChangedAt = Date.now();

    // Thu hồi toàn bộ phiên đang mở — bắt buộc sau khi đổi mật khẩu.
    const revoked = this.vault.sessions.size;
    this.vault.sessions.clear();
    this.challenges.delete(challengeId);
    this.stats.completed++;

    this.audit?.record({ actor: acc.rootId, action: 'recovery.complete', verdict: 'ALLOW', severity: 2, detail: { method: ch.method, sessionsRevoked: revoked } });
    bus.safeEmit('security:password_recovered', { method: ch.method });
    L.warn(`Mật khẩu Super Admin đã được đặt lại qua ${METHODS[ch.method].name}; thu hồi ${revoked} phiên`);

    return {
      ok: true, method: ch.method, sessionsRevoked: revoked,
      recoveryCodesLeft: CONST.RECOVERY_CODES - acc.recoveryCodesUsed.length,
      next: 'Đăng nhập lại và tạo bộ mã khôi phục mới nếu đã dùng gần hết',
    };
  }

  /** Cấp lại bộ mã khôi phục (huỷ bộ cũ). */
  regenerateRecoveryCodes(sessionToken) {
    const s = this.vault.getSession(sessionToken);
    if (!s) return { ok: false, error: 'INVALID_SESSION' };
    const codes = Array.from({ length: CONST.RECOVERY_CODES }, () => C.randomToken(12));
    this.vault.account.recoveryCodeHashes = codes.map((c) => C.sha256hex(c + this.vault.pepper));
    this.vault.account.recoveryCodesUsed = [];
    this.audit?.record({ actor: s.rootId, action: 'recovery.regenerate_codes', verdict: 'ALLOW', severity: 1 });
    return { ok: true, recoveryCodes: codes, warning: 'Bộ mã cũ đã bị huỷ. Lưu bộ mới ngay.' };
  }

  // ═══ KHÔI PHỤC HỆ THỐNG ═══════════════════════════════════════════════
  /**
   * Khôi phục toàn hệ về một ảnh chụp.
   * @param {object} sel {version} hoặc {at: timestamp} hoặc {snapshotId}
   */
  async restoreSystem(sel = {}, { dryRun = false, actor = 'superadmin' } = {}) {
    const snap = this.snapshots.resolve(sel);
    if (!snap) return { ok: false, error: 'SNAPSHOT_NOT_FOUND', selector: sel, available: this.snapshots.list({ limit: 10 }) };

    const integrity = this.snapshots.verify(snap.id);
    if (!integrity.ok) {
      this.audit?.record({ actor, action: 'recovery.restore_system', verdict: 'BLOCK', severity: 3, detail: { snapshotId: snap.id, reason: 'INTEGRITY_FAILED' } });
      return { ok: false, error: 'INTEGRITY_CHECK_FAILED', detail: integrity };
    }

    const plan = {
      snapshotId: snap.id,
      version: snap.version,
      takenAt: new Date(snap.at).toISOString(),
      ageMinutes: round((Date.now() - snap.at) / 60000, 1),
      label: snap.label,
      subsystems: Object.keys(snap.data),
      itemsInSnapshot: snap.summary,
      integrity,
    };
    if (dryRun) return { ok: true, dryRun: true, plan };

    // Chụp một ảnh an toàn TRƯỚC khi khôi phục, để còn đường lùi.
    const safety = await this.snapshots.take({ label: `pre-restore-${snap.version}`, auto: true });

    const applied = this.snapshots.restore(snap.id);
    this.stats.systemRestores++;

    this.audit?.record({
      actor, actorRole: 'SUPER_ADMIN', action: 'recovery.restore_system',
      verdict: 'ALLOW', severity: 3,
      detail: { restoredTo: snap.version, takenAt: plan.takenAt, safetySnapshot: safety.id },
    });
    bus.safeEmit('security:system_restored', { snapshotId: snap.id, version: snap.version });
    L.warn(`Hệ thống đã khôi phục về phiên bản ${snap.version} (${plan.takenAt}); ảnh an toàn: ${safety.id}`);

    return { ok: true, plan, applied, rollbackTo: safety.id };
  }

  status() {
    return {
      methods: Object.values(METHODS),
      activeChallenges: this.challenges.size,
      challengeTtlMin: CHALLENGE_TTL_MS / 60000,
      ...this.stats,
    };
  }
}

module.exports = RecoveryService;
module.exports.METHODS = METHODS;
