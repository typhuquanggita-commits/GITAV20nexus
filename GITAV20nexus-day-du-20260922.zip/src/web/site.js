'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  TRANG CÔNG KHAI GITA — dựng sẵn ở máy chủ, đọc được khi tắt JavaScript
 * ═══════════════════════════════════════════════════════════════════════════
 *  Ba quyết định định hình toàn bộ tệp này:
 *
 *  1. DỰNG Ở MÁY CHỦ. Công cụ tìm kiếm đọc HTML; trang trắng chờ JavaScript
 *     vẽ ra thì phải chờ vòng thu thập thứ hai, và nhiều bộ thu thập không
 *     quay lại. Mỗi trang ở đây là HTML hoàn chỉnh ngay từ byte đầu tiên.
 *
 *  2. NỘI DUNG LẤY TỪ DỮ LIỆU THẬT. Một trăm linh tư trang dạng bài không
 *     phải một trăm linh tư trang rỗng ghép từ khuôn: mỗi trang có tên dạng,
 *     tầng, điều kiện cần nắm trước, bẫy thường gặp, thời gian chuẩn và các
 *     dạng liên quan — tất cả đọc từ chương trình đang vận hành.
 *
 *  3. KHÔNG GỌI RA NGOÀI. Không phông chữ tải về, không thư viện, không mã
 *     theo dõi. Trang nhẹ, không rò dữ liệu người đọc, và không hỏng khi
 *     mạng ngoài trục trặc.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const cfg = require('../config');
const { cacBuoc } = require('../content/loi-giai');
const SEO = require('./seo');
const { FORM_INDEX, LEVELS } = require('../curriculum/hierarchy');
const { LEVEL_STANDARDS } = require('../curriculum/standards');
const { PHUONG_PHAP } = require('../math/scientist');

const esc = SEO.esc;
const lopCua = (ma) => Number((String(ma).match(/^M(\d+)/) || [])[1]) || null;
/** Viết hoa chữ đầu và thêm dấu chấm — dùng cho mục liệt kê thành câu. */
const hoaDau = (s) => {
  const t = String(s || '').trim();
  if (!t) return t;
  const ra = t[0].toLocaleUpperCase('vi') + t.slice(1);
  return /[.!?…]$/.test(ra) ? ra : `${ra}.`;
};

const khongDau = (s) => String(s).normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/gi, 'd').toLowerCase();

/** Bảng màu và cách trình bày — một tệp CSS duy nhất, nhúng thẳng. */
const CSS = `
/* ═══ HỆ THỐNG THIẾT KẾ ═══════════════════════════════════════════════════
   Trang dành cho phụ huynh và học sinh phổ thông, nên lấy nền SÁNG làm chính
   và màu ấm làm điểm nhấn — không lấy lối trình bày tối của công cụ lập trình.
   Không một phông chữ hay tệp ảnh nào tải từ ngoài: hình minh hoạ, linh vật và
   biểu đồ đều là SVG viết thẳng trong trang. */
:root{
  --nen:#f4f7fc;        /* nền trang */
  --muc:#e9eff8;        /* dải đậm hơn: chân trang, đầu bảng */
  --tam:#ffffff;        /* mặt thẻ */
  --tam2:#f2f6fc;       /* mặt thẻ chìm */
  --vien:#dde5f0;
  --vien2:#c3d1e4;
  --chu:#10203a;
  --mo:#4b5d78;
  --mo2:#6b7c96;
  --mau:#1668c9;--mau2:#4dabf7;   /* màu theo ngữ cảnh; trang lớp ghi đè */
  --nhan:#1668c9;       /* lam thương hiệu */
  --nhan-dam:#0f5099;
  --nhan-nhat:#e7f0fd;
  --cam:#e8590c;        /* cam — nút hành động, giống lối của sách vở học trò */
  --cam-dam:#c34708;
  --cam-nhat:#fdeee4;
  --ngoc:#0f9d6e;       /* ngọc — việc đã xong, đã kiểm */
  --ngoc-nhat:#e4f6ef;
  --hoa:#b8730a;        /* hổ phách — bẫy, cảnh báo */
  --hoa-nhat:#fdf3e2;
  --sen:#c8304a;
  --tim:#6741d9;
  --r1:10px;--r2:16px;--r3:22px;--r4:30px;
  --bong:0 1px 2px rgba(16,32,58,.05),0 10px 26px -16px rgba(16,32,58,.24);
  --bong2:0 2px 8px rgba(16,32,58,.07),0 30px 60px -30px rgba(16,32,58,.32);
  --bong3:0 10px 40px -14px rgba(22,104,201,.34);
  --vien-sang:inset 0 1px 0 rgba(255,255,255,1);
  /* Bóng đổ MANG MÀU của chính vật đổ bóng, không phải một mảng xám chung.
     Ánh sáng thật phản xạ màu của vật, nên bóng xám dưới một thẻ màu cam nhìn
     lập tức thấy giả. Đây là chỗ phân biệt giao diện có nghề với giao diện
     chỉ ghép sẵn. */
  --quang:0 18px 44px -20px color-mix(in srgb,var(--mau) 60%,transparent);
  --quang-manh:0 24px 60px -22px color-mix(in srgb,var(--mau) 78%,transparent);
  --kinh:color-mix(in srgb,var(--tam) 74%,transparent);
  --mo-kinh:blur(16px) saturate(1.35);
  --chuyen:180ms cubic-bezier(.2,.7,.3,1);
  --chu-he:ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;
  --chu-ma:ui-monospace,SFMono-Regular,"SF Mono",Menlo,Consolas,monospace;
}
@media (prefers-color-scheme: dark){
  :root{
    --nen:#0a1120;--muc:#060b14;--tam:#0f1829;--tam2:#131f34;
    --vien:#1e2c44;--vien2:#2b3d5c;--chu:#e8eef7;--mo:#94a5bd;--mo2:#6c7f9b;
    --mau:#4cc2ff;--mau2:#3ddba4;
    --nhan:#4cc2ff;--nhan-dam:#1f9ee0;--nhan-nhat:#10283f;
    --cam:#ff8a4c;--cam-dam:#e8712f;--cam-nhat:#2c1a10;
    --ngoc:#3ddba4;--ngoc-nhat:#0f2a22;--hoa:#ffc44d;--hoa-nhat:#2b2112;
    --sen:#ff7a8a;--tim:#a78bfa;
    --bong:0 1px 2px rgba(0,0,0,.35),0 8px 28px -12px rgba(0,0,0,.6);
    --bong2:0 2px 4px rgba(0,0,0,.4),0 24px 50px -24px rgba(0,0,0,.8);
    --bong3:0 10px 40px -14px rgba(76,194,255,.3);
    --vien-sang:inset 0 1px 0 rgba(255,255,255,.055);
    --quang:0 18px 48px -20px color-mix(in srgb,var(--mau) 52%,transparent);
    --quang-manh:0 26px 64px -22px color-mix(in srgb,var(--mau) 66%,transparent);
    --kinh:color-mix(in srgb,var(--tam) 68%,transparent);
  }
}
/* Màu riêng cho từng lớp. Học sinh nhớ lớp mình theo MÀU nhanh hơn theo số,
   nên mỗi lớp giữ một màu cố định suốt cả trang — thẻ khoá học, trang lớp,
   nhãn trong danh mục đều cùng một màu. */
.l1{--mau:#6741d9;--mau2:#9775fa}
.l2{--mau:#1668c9;--mau2:#4dabf7}
.l3{--mau:#0f9d6e;--mau2:#38d9a9}
.l4{--mau:#e8590c;--mau2:#ffa94d}
.l5{--mau:#c92a48;--mau2:#ff8787}
.l6{--mau:#0b7285;--mau2:#3bc9db}
.l7{--mau:#a5730a;--mau2:#ffd43b}
.l8{--mau:#2f9e44;--mau2:#8ce99a}
.l9{--mau:#d6336c;--mau2:#faa2c1}
.l10{--mau:#4c3bcf;--mau2:#91a7ff}
.l11{--mau:#0c8599;--mau2:#66d9e8}
.l12{--mau:#ae3ec9;--mau2:#e599f7}
.lx{--mau:#495057;--mau2:#adb5bd}

*,*::before,*::after{box-sizing:border-box}
html{-webkit-text-size-adjust:100%;scroll-behavior:smooth}
body{
  margin:0;background:var(--nen);color:var(--chu);
  font:16.5px/1.75 var(--chu-he);
  font-feature-settings:"kern" 1,"liga" 1;
  -webkit-font-smoothing:antialiased;
  background-image:
    radial-gradient(1100px 560px at 12% -12%,rgba(22,104,201,.11),transparent 58%),
    radial-gradient(900px 480px at 92% -4%,rgba(232,89,12,.09),transparent 56%),
    radial-gradient(700px 420px at 52% 42%,rgba(15,157,110,.055),transparent 62%);
  background-attachment:fixed;
}
/* Ba quầng sáng mờ trôi rất chậm phía sau nội dung. Đặt ở lớp dưới cùng và
   không nhận sự kiện chuột, nên không cản trở thao tác nào; tắt hẳn khi người
   dùng đã chọn giảm chuyển động. */
body::before{content:"";position:fixed;inset:-18%;z-index:-1;pointer-events:none;
  background:
    radial-gradient(38% 34% at 16% 22%,color-mix(in srgb,var(--nhan) 26%,transparent),transparent 70%),
    radial-gradient(34% 30% at 84% 16%,color-mix(in srgb,var(--cam) 22%,transparent),transparent 70%),
    radial-gradient(40% 36% at 62% 78%,color-mix(in srgb,var(--ngoc) 20%,transparent),transparent 70%);
  filter:blur(58px);opacity:.5;animation:troi 34s ease-in-out infinite alternate}
@keyframes troi{
  0%{transform:translate3d(0,0,0) scale(1)}
  50%{transform:translate3d(1.6%,-1.4%,0) scale(1.05)}
  100%{transform:translate3d(-1.4%,1.6%,0) scale(1.02)}
}
@media (prefers-color-scheme: dark){
  body{background-image:
    radial-gradient(1100px 560px at 12% -12%,rgba(76,194,255,.14),transparent 58%),
    radial-gradient(900px 480px at 92% -4%,rgba(255,138,76,.10),transparent 56%)}
}
a{color:var(--nhan);text-decoration:none}
a:hover{color:var(--nhan-dam)}
a:focus-visible,button:focus-visible,summary:focus-visible{outline:2px solid var(--cam);outline-offset:3px;border-radius:6px}
.bo-qua{position:absolute;left:-9999px}
.bo-qua:focus{left:10px;top:10px;background:var(--cam);color:#fff;padding:10px 16px;border-radius:var(--r1);z-index:99;font-weight:700}

/* ── Dải tiện ích và thanh đầu trang ─────────────────────────────────────── */
.dai-tien-ich{background:var(--muc);border-bottom:1px solid var(--vien);font-size:13.5px}
.dai-tien-ich .thanh{padding:7px 22px;gap:18px;justify-content:flex-end;min-height:0}
.dai-tien-ich a,.dai-tien-ich span{color:var(--mo);display:inline-flex;align-items:center;gap:6px}
.dai-tien-ich a:hover{color:var(--nhan)}
.dai-tien-ich .goi{color:var(--cam);font-weight:700}
.dai-tien-ich .trai{margin-right:auto;font-weight:600;color:var(--mo2)}
header{position:sticky;top:0;z-index:20;border-bottom:1px solid var(--vien);
  background:color-mix(in srgb,var(--tam) 92%,transparent);backdrop-filter:saturate(1.5) blur(12px)}
.thanh{max-width:1180px;margin:0 auto;padding:12px 22px;display:flex;gap:22px;align-items:center;flex-wrap:wrap}
.hieu{display:flex;align-items:center;gap:10px;font-weight:800;font-size:20px;color:var(--chu);letter-spacing:-.025em}
.hieu:hover{color:var(--chu)}
.hieu span{color:var(--nhan)}
.dau{flex:none}
header nav{display:flex;gap:3px;flex-wrap:wrap;margin-left:auto;align-items:center}
header nav a{color:var(--mo);font-size:14.5px;font-weight:600;padding:8px 11px;border-radius:9px;
  transition:background var(--chuyen),color var(--chuyen)}
header nav a:hover{color:var(--nhan);background:var(--nhan-nhat)}
header nav a[aria-current]{color:var(--nhan);background:var(--nhan-nhat)}
header nav a.chinh{background:var(--cam);color:#fff;font-weight:700;box-shadow:0 6px 16px -8px var(--cam)}
header nav a.chinh:hover{background:var(--cam-dam);color:#fff}

/* ── Menu thả xuống theo lớp ─────────────────────────────────────────────── */
.thu{position:relative}
.thu>summary{list-style:none;cursor:pointer;color:var(--mo);font-size:14.5px;font-weight:600;padding:8px 11px;
  border-radius:9px;display:inline-flex;align-items:center;gap:6px;transition:background var(--chuyen),color var(--chuyen)}
.thu>summary::-webkit-details-marker{display:none}
.thu>summary::after{content:"";width:0;height:0;border:4px solid transparent;border-top-color:currentColor;
  margin-top:3px;transition:transform var(--chuyen)}
.thu>summary:hover,.thu[open]>summary{color:var(--nhan);background:var(--nhan-nhat)}
.thu[open]>summary::after{transform:rotate(180deg);margin-top:-3px}
.bang-thu{position:absolute;top:calc(100% + 10px);left:0;z-index:30;width:344px;
  background:var(--tam);border:1px solid var(--vien2);border-radius:var(--r2);
  padding:16px 18px 18px;box-shadow:var(--bong2),var(--vien-sang)}
.tua-thu{margin:0 0 9px;font-size:11.5px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--mo2)}
.tua-thu:not(:first-child){margin-top:15px;padding-top:14px;border-top:1px solid var(--vien)}
.o-lop{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}
.o-lop a{text-align:center;padding:9px 4px;border-radius:9px;font-size:14px;font-weight:700;
  color:#fff;background:var(--mau,var(--nhan));border:0;
  transition:transform var(--chuyen),filter var(--chuyen)}
.o-lop a{background:linear-gradient(140deg,var(--mau2),var(--mau))}
.o-lop a:hover{color:#fff;transform:translateY(-2px);filter:saturate(1.15);
  box-shadow:0 10px 22px -10px color-mix(in srgb,var(--mau) 72%,transparent)}
.o-them{display:flex;flex-direction:column;gap:2px}
.o-them a{padding:8px 10px;border-radius:9px;font-size:14px;color:var(--mo);font-weight:600}
.o-them a:hover{color:var(--nhan);background:var(--nhan-nhat)}

main{max-width:1180px;margin:0 auto;padding:30px 22px 78px}
.duongmon{font-size:13.5px;color:var(--mo2);margin:0 0 20px}
.duongmon a{color:var(--mo)}

/* ── Chữ ─────────────────────────────────────────────────────────────────── */
h1{font-size:clamp(31px,4.6vw,49px);line-height:1.1;letter-spacing:-.03em;margin:0 0 16px;font-weight:800}
h2{position:relative;font-size:clamp(22px,2.7vw,30px);line-height:1.22;letter-spacing:-.022em;
  margin:56px 0 16px;font-weight:800;padding-top:18px}
/* Vạch ngắn phía trên mỗi mục: đủ để mắt biết chỗ bắt đầu mục mới mà không
   cần kẻ hết bề ngang như một đường phân cách. */
h2::before{content:"";position:absolute;top:0;left:0;width:46px;height:4px;border-radius:4px;
  background:linear-gradient(90deg,var(--mau),var(--mau2))}
main>h2:first-of-type{padding-top:18px}
h3{font-size:17.5px;line-height:1.38;margin:0 0 8px;font-weight:750;letter-spacing:-.01em}
p{margin:0 0 15px}
.lead{font-size:clamp(17px,1.75vw,20px);line-height:1.66;color:var(--mo);max-width:60ch;margin:0 0 28px}
.dat{color:var(--mo);max-width:70ch;margin:0 0 26px}
.nho{font-size:13.5px;color:var(--mo2)}
.eyebrow{display:inline-flex;align-items:center;gap:9px;font-size:12.5px;font-weight:800;letter-spacing:.1em;
  text-transform:uppercase;color:var(--cam);margin:0 0 14px}
.eyebrow::before{content:"";width:26px;height:3px;border-radius:3px;
  background:linear-gradient(90deg,var(--cam),color-mix(in srgb,var(--cam) 40%,transparent))}
ul.gon{padding-left:19px;margin:0 0 15px}ul.gon li{margin:6px 0}
ul.tick{list-style:none;padding:0;margin:0 0 15px}
ul.tick li{position:relative;padding-left:28px;margin:10px 0}
ul.tick li::before{content:"";position:absolute;left:2px;top:.6em;width:10px;height:10px;border-radius:50%;
  background:var(--ngoc);box-shadow:0 0 0 4px var(--ngoc-nhat)}

/* ── Nút ─────────────────────────────────────────────────────────────────── */
.cta{display:flex;gap:12px;flex-wrap:wrap;margin:0 0 8px;align-items:center}
.nut{position:relative;overflow:hidden;display:inline-flex;align-items:center;gap:9px;color:#fff;font-weight:750;
  padding:13px 24px;border-radius:999px;font-size:16px;border:2px solid transparent;
  background:linear-gradient(135deg,color-mix(in srgb,var(--cam) 88%,#fff),var(--cam) 52%,var(--cam-dam));
  box-shadow:0 12px 28px -14px var(--cam),inset 0 1px 0 rgba(255,255,255,.28);
  transition:transform var(--chuyen),box-shadow var(--chuyen),filter var(--chuyen)}
/* Vệt sáng lướt qua mặt nút khi rê chuột — chỉ là một dải trắng mờ nghiêng,
   không phải ảnh động, nên không tốn gì. */
.nut::after{content:"";position:absolute;inset:0;transform:translateX(-120%) skewX(-18deg);
  background:linear-gradient(90deg,transparent,rgba(255,255,255,.34),transparent);
  transition:transform 520ms cubic-bezier(.2,.7,.3,1)}
.nut:hover::after{transform:translateX(120%) skewX(-18deg)}
.nut:hover{color:#fff;transform:translateY(-2px);filter:saturate(1.08);
  box-shadow:0 18px 38px -14px var(--cam),inset 0 1px 0 rgba(255,255,255,.34)}
.nut.phu{background:var(--tam);border-color:var(--vien2);color:var(--chu);box-shadow:var(--bong)}
.nut.phu::after{display:none}
.nut.phu:hover{background:var(--nhan-nhat);border-color:var(--nhan);color:var(--nhan);
  box-shadow:0 12px 26px -16px var(--nhan)}
.nut.lam{background:linear-gradient(135deg,color-mix(in srgb,var(--nhan) 86%,#fff),var(--nhan) 52%,var(--nhan-dam));
  box-shadow:0 12px 28px -14px var(--nhan),inset 0 1px 0 rgba(255,255,255,.28)}
.nut.lam:hover{box-shadow:0 18px 38px -14px var(--nhan),inset 0 1px 0 rgba(255,255,255,.34)}

/* ── Thẻ ─────────────────────────────────────────────────────────────────── */
.luoi{display:grid;gap:18px;grid-template-columns:repeat(auto-fit,minmax(262px,1fr))}
.luoi>*{min-width:0}
.luoi.hai{grid-template-columns:repeat(auto-fit,minmax(340px,1fr))}
.the{position:relative;background:var(--tam);border:1px solid var(--vien);border-radius:var(--r2);
  padding:22px 23px;box-shadow:var(--bong),var(--vien-sang);
  transition:transform var(--chuyen),border-color var(--chuyen),box-shadow var(--chuyen)}
.the::after{content:"";position:absolute;left:0;right:0;top:0;height:2px;border-radius:var(--r2) var(--r2) 0 0;
  background:linear-gradient(90deg,transparent,color-mix(in srgb,var(--mau) 70%,transparent),transparent);
  opacity:0;transition:opacity var(--chuyen)}
.the:hover::after{opacity:1}
.the:hover{transform:translateY(-3px);border-color:color-mix(in srgb,var(--mau) 30%,var(--vien));
  box-shadow:var(--quang),var(--vien-sang)}
.the p:last-child{margin-bottom:0}
.the.nhan{border-color:color-mix(in srgb,var(--nhan) 34%,var(--vien))}
.the.nhan::before{content:"";position:absolute;left:0;top:16px;bottom:16px;width:4px;border-radius:0 4px 4px 0;
  background:linear-gradient(180deg,var(--nhan),var(--ngoc))}
a.the{display:block;color:inherit}
a.the:hover{color:inherit}
a.the h3{color:var(--chu)}
.the .ma{font:700 11.5px/1 var(--chu-ma);color:var(--nhan);letter-spacing:.06em;display:block;margin-bottom:8px;
  text-transform:uppercase}

/* Trang của một lớp mang đúng màu của lớp đó: dải trên đầu, nhãn, mã dạng và
   viền thẻ đều lấy theo --mau, nên học sinh nhận ra trang lớp mình ngay. */
main.co-mau{position:relative}
main.co-mau::before{content:"";position:absolute;left:22px;right:22px;top:-30px;height:4px;border-radius:0 0 4px 4px;
  background:linear-gradient(90deg,var(--mau),var(--mau2),var(--mau));
  box-shadow:0 8px 30px -6px color-mix(in srgb,var(--mau) 70%,transparent)}
main.co-mau .eyebrow{color:var(--mau)}
main.co-mau .the .ma{color:var(--mau)}
main.co-mau .the:hover{border-color:color-mix(in srgb,var(--mau) 45%,var(--vien))}
main.co-mau .nut.lam{background:var(--mau);box-shadow:0 10px 24px -12px var(--mau)}
main.co-mau .o-so b{background:linear-gradient(135deg,var(--mau),var(--mau2));
  -webkit-background-clip:text;background-clip:text;color:transparent}
main.co-mau .bac{border-left-color:var(--mau)}

/* ── Thẻ khoá học theo lớp ───────────────────────────────────────────────── */
.luoi-lop{display:grid;gap:16px;grid-template-columns:repeat(auto-fit,minmax(276px,1fr))}
.the-lop{display:grid;grid-template-columns:86px 1fr;align-items:stretch;overflow:hidden;
  background:var(--tam);border:1px solid var(--vien);border-radius:var(--r2);
  box-shadow:var(--bong),var(--vien-sang);color:inherit;
  transition:transform var(--chuyen),box-shadow var(--chuyen)}
.the-lop:hover{transform:translateY(-4px);color:inherit;
  border-color:color-mix(in srgb,var(--mau) 34%,var(--vien));box-shadow:var(--quang-manh),var(--vien-sang)}
.the-lop .so-lop{position:relative;overflow:hidden;display:flex;align-items:center;justify-content:center;
  background:linear-gradient(152deg,color-mix(in srgb,var(--mau2) 70%,#fff) 0%,var(--mau2) 26%,var(--mau) 74%,
    color-mix(in srgb,var(--mau) 74%,#000) 100%);
  color:#fff;font:800 40px/1 var(--chu-he);letter-spacing:-.04em;text-shadow:0 2px 12px rgba(0,0,0,.22)}
/* Vệt sáng chéo trên khối số, cho mảng màu có chiều sâu thay vì phẳng lì. */
.the-lop .so-lop::before{content:"";position:absolute;inset:-30% -60% auto -30%;height:120%;
  background:linear-gradient(180deg,rgba(255,255,255,.3),transparent 62%);transform:rotate(-14deg)}
.the-lop .than-lop{padding:16px 18px}
.the-lop h3{color:var(--mau);margin-bottom:7px}
.the-lop ul{list-style:none;padding:0;margin:0}
.the-lop li{font-size:14px;color:var(--mo);margin:4px 0;padding-left:16px;position:relative}
.the-lop li::before{content:"";position:absolute;left:2px;top:.62em;width:6px;height:6px;border-radius:50%;background:var(--mau2)}

/* ── Thẻ bộ đề ───────────────────────────────────────────────────────────── */
.luoi-de{display:grid;gap:14px;grid-template-columns:repeat(auto-fit,minmax(228px,1fr))}
.the-de{position:relative;overflow:hidden;display:flex;flex-direction:column;gap:11px;
  padding:17px 18px 15px;border-radius:var(--r2);color:inherit;
  background:linear-gradient(var(--tam),var(--tam)) padding-box,
    linear-gradient(140deg,var(--mau2),var(--mau)) border-box;
  border:1px solid transparent;box-shadow:var(--bong),var(--vien-sang);
  transition:transform var(--chuyen),box-shadow var(--chuyen)}
/* Dải màu mảnh chạy hết mép trên: đủ để mắt phân biệt từng bộ đề mà không
   nhuộm cả thẻ, vì phần chữ bên dưới vẫn phải đọc được lâu. */
.the-de::before{content:"";position:absolute;inset:0 0 auto 0;height:4px;
  background:linear-gradient(90deg,var(--mau2),var(--mau))}
.the-de:hover{transform:translateY(-4px);color:inherit;box-shadow:var(--quang-manh),var(--vien-sang)}
.the-de .ten-de{font-weight:800;font-size:16.5px;color:var(--mau);line-height:1.34}
.the-de .so-de{display:flex;flex-wrap:wrap;gap:6px;margin-top:auto}
.the-de .so-de span{font-size:12.5px;font-weight:700;padding:4px 9px;border-radius:999px;
  color:color-mix(in srgb,var(--mau) 74%,#000);
  background:color-mix(in srgb,var(--mau) 13%,transparent);
  border:1px solid color-mix(in srgb,var(--mau) 24%,transparent)}
.the-de .vao-de{font-size:13.5px;font-weight:700;color:var(--mo2)}
.the-de:hover .vao-de{color:var(--mau)}

/* ── Băng mời học thử ────────────────────────────────────────────────────── */
.bang-hieu{position:relative;overflow:hidden;border-radius:var(--r3);padding:32px 36px;margin:26px 0 0;color:#fff;
  background:linear-gradient(118deg,#1668c9 0%,#0f7ac9 26%,#0f9d6e 62%,#2f9e44 84%,#3ddba4 100%);
  background-size:220% 220%;
  box-shadow:0 26px 60px -26px rgba(15,157,110,.65),inset 0 1px 0 rgba(255,255,255,.22);
  animation:chay-mau 22s ease-in-out infinite alternate}
/* Dải màu trôi rất chậm giữa hai đầu — đủ để mảng màu không chết cứng, chậm
   tới mức không ai bị phân tâm khi đang đọc. */
@keyframes chay-mau{0%{background-position:0% 50%}100%{background-position:100% 50%}}
/* Một lớp sáng dịu ở góc trên, cho mảng màu có nguồn sáng rõ ràng. */
.bang-hieu::before{content:"";position:absolute;inset:0;pointer-events:none;
  background:radial-gradient(64% 86% at 14% 0%,rgba(255,255,255,.26),transparent 62%)}
.bang-hieu>*{position:relative}
.bang-hieu h2{margin:0 0 8px;padding-top:0;color:#fff;font-size:clamp(21px,2.6vw,29px)}
.bang-hieu h2::before{display:none}
.bang-hieu p{color:rgba(255,255,255,.93);max-width:56ch;margin:0 0 18px}
.bang-hieu .nut{background:#fff;color:var(--nhan);box-shadow:0 10px 26px -12px rgba(0,0,0,.5)}
.bang-hieu .nut:hover{background:#fff;color:var(--nhan-dam)}
.bang-hieu .nut.phu{background:transparent;border-color:rgba(255,255,255,.55);color:#fff}
.bang-hieu .nut.phu:hover{background:rgba(255,255,255,.14);color:#fff;border-color:#fff}
.bang-hieu .trang-tri{position:absolute;right:-40px;bottom:-56px;width:290px;opacity:.9;pointer-events:none}
@media(max-width:760px){.bang-hieu .trang-tri{display:none}}

/* ── Số liệu ─────────────────────────────────────────────────────────────── */
.so-lieu{display:grid;gap:16px;grid-template-columns:repeat(auto-fit,minmax(174px,1fr));margin:0 0 10px}
.o-so{position:relative;border:1px solid transparent;border-radius:var(--r2);padding:20px 21px;
  /* Viền là một dải màu thật, không phải một đường kẻ tô màu: nền vẽ tới mép
     trong, dải màu vẽ ở vành viền. */
  background:linear-gradient(var(--tam),var(--tam)) padding-box,
    linear-gradient(135deg,color-mix(in srgb,var(--nhan) 34%,var(--vien)),var(--vien) 46%,
      color-mix(in srgb,var(--ngoc) 34%,var(--vien))) border-box;
  box-shadow:var(--bong),var(--vien-sang);
  transition:transform var(--chuyen),box-shadow var(--chuyen)}
.o-so:hover{transform:translateY(-2px);box-shadow:0 18px 40px -22px color-mix(in srgb,var(--nhan) 60%,transparent)}
.o-so b{display:block;font-size:clamp(28px,3.6vw,37px);line-height:1.06;font-weight:800;letter-spacing:-.035em;
  background:linear-gradient(118deg,var(--nhan) 0%,#0f7ac9 38%,var(--ngoc) 100%);
  -webkit-background-clip:text;background-clip:text;color:transparent}
.o-so small{display:block;font-size:13px;color:var(--mo);margin-top:7px;line-height:1.5}

/* ── Nhãn ────────────────────────────────────────────────────────────────── */
.nhan-nho{display:inline-block;background:var(--nhan-nhat);border:1px solid color-mix(in srgb,var(--nhan) 22%,var(--vien));
  color:var(--nhan);border-radius:999px;padding:3px 12px;font-size:12.5px;margin:0 6px 6px 0;font-weight:700}
.nhan-nho.bay{background:var(--hoa-nhat);border-color:color-mix(in srgb,var(--hoa) 32%,var(--vien));color:var(--hoa)}
.nhan-nho.xong{background:var(--ngoc-nhat);border-color:color-mix(in srgb,var(--ngoc) 32%,var(--vien));color:var(--ngoc)}
.mon{display:inline-flex;align-items:center;gap:7px;border:1px solid var(--vien);border-radius:999px;
  padding:9px 16px;margin:0 8px 8px 0;font-size:14.5px;font-weight:600;background:var(--tam);color:var(--mo);
  transition:border-color var(--chuyen),background var(--chuyen),color var(--chuyen)}
.mon:hover{border-color:var(--nhan);background:var(--nhan-nhat);color:var(--nhan)}
.mon.dang{border-color:transparent;color:#fff;
  background:linear-gradient(135deg,color-mix(in srgb,var(--nhan) 84%,#fff),var(--nhan) 55%,var(--nhan-dam));
  box-shadow:0 10px 22px -12px var(--nhan)}
.mon.dang:hover{color:#fff}
.mon .nhan-nho{margin:0;padding:1px 8px;font-size:11.5px}

/* ── Khối trưng bày bài thật ─────────────────────────────────────────────── */
.trung-bay{position:relative;min-width:0;max-width:100%;border:1px solid transparent;border-radius:var(--r3);
  padding:24px 25px;
  background:linear-gradient(var(--kinh),var(--kinh)) padding-box,
    linear-gradient(140deg,color-mix(in srgb,var(--nhan) 46%,var(--vien)),var(--vien) 40%,
      color-mix(in srgb,var(--ngoc) 46%,var(--vien))) border-box;
  backdrop-filter:var(--mo-kinh);-webkit-backdrop-filter:var(--mo-kinh);
  box-shadow:0 26px 60px -30px color-mix(in srgb,var(--nhan) 52%,transparent),var(--vien-sang)}
.trung-bay .nhan-tren{display:flex;align-items:center;justify-content:space-between;gap:12px;
  font-size:12.5px;color:var(--mo2);margin-bottom:15px;flex-wrap:wrap;font-weight:600}
.de-bai{font-size:17.5px;line-height:1.7;margin:0 0 17px;color:var(--chu);overflow-x:auto;overflow-y:hidden}
.dong-de+.dong-de{margin-top:7px}
.dong-de.lua-chon{padding-left:18px;text-indent:-18px}
.dong-de.lua-chon:first-of-type{margin-top:13px}
.buoc{list-style:none;counter-reset:b;padding:0;margin:0}
.buoc li{counter-increment:b;position:relative;padding-left:36px;margin:12px 0;font-size:15px;color:var(--mo);
  overflow-x:auto;overflow-y:hidden}
.buoc li::before{content:counter(b);position:absolute;left:0;top:0;width:24px;height:24px;border-radius:8px;
  background:var(--nhan-nhat);border:1px solid color-mix(in srgb,var(--nhan) 25%,var(--vien));
  color:var(--nhan);font:800 12px/22px var(--chu-ma);text-align:center}
/* Căn cứ nằm dưới thao tác, lùi vào và nhạt hơn: mắt đọc thao tác trước, đọc
   căn cứ sau, đúng thứ tự người học cần. Vạch dọc bên trái để hai phần không
   dính vào nhau khi bước giải dài. */
.buoc .can-cu{display:block;margin-top:5px;padding-left:11px;font-size:13.5px;line-height:1.55;
  color:var(--mo2);border-left:2px solid color-mix(in srgb,var(--mau) 32%,var(--vien))}
.buoc .can-cu::before{content:"Căn cứ: ";font-weight:700;color:var(--mau)}
.vet{margin:16px 0 0;padding:15px 17px;border-radius:var(--r1);
  background:linear-gradient(135deg,var(--ngoc-nhat),color-mix(in srgb,var(--ngoc-nhat) 55%,transparent));
  border:1px solid color-mix(in srgb,var(--ngoc) 26%,var(--vien));
  box-shadow:inset 0 1px 0 color-mix(in srgb,var(--ngoc) 16%,transparent)}
.vet .dong{display:flex;gap:9px;align-items:flex-start;font-size:14px;margin:6px 0;color:var(--mo)}
.vet .dau-tich{color:var(--ngoc);font-weight:800;flex:none}
.vet b{color:var(--ngoc)}

/* ── Bảng ────────────────────────────────────────────────────────────────── */
/* Viền bảng vẽ bằng hai lớp nền (padding-box + border-box) để có viền chuyển sắc
   mà vẫn giữ nền đặc — cách duy nhất làm được viền gradient không cần phần tử phụ. */
.khung-bang{overflow-x:auto;border:1px solid transparent;border-radius:var(--r2);
  background:linear-gradient(var(--tam),var(--tam)) padding-box,
    linear-gradient(135deg,color-mix(in srgb,var(--nhan) 30%,var(--vien)),var(--vien) 52%,
      color-mix(in srgb,var(--ngoc) 30%,var(--vien))) border-box;
  margin:16px 0;box-shadow:var(--quang),var(--vien-sang)}
table{width:100%;border-collapse:collapse;font-size:14.5px}
caption{text-align:left;padding:13px 16px 0;color:var(--mo);font-size:13.5px}
th,td{text-align:left;padding:12px 17px;border-bottom:1px solid var(--vien);vertical-align:top}
tbody tr:last-child td{border-bottom:none}
tbody tr{transition:background var(--chuyen),box-shadow var(--chuyen)}
tbody tr:nth-child(even){background:color-mix(in srgb,var(--nhan) 4%,transparent)}
tbody td:first-child{font-weight:600}
th{color:var(--mo2);font-weight:800;font-size:11.5px;text-transform:uppercase;letter-spacing:.07em;
  border-bottom-color:var(--vien2);
  background:linear-gradient(120deg,color-mix(in srgb,var(--mau) 16%,var(--muc)),
    var(--muc) 52%,color-mix(in srgb,var(--mau2) 20%,var(--muc)))}
tbody tr:hover{background:color-mix(in srgb,var(--mau) 10%,transparent);
  box-shadow:inset 3px 0 0 var(--mau)}
/* Mỗi khối tài liệu mang màu của lớp mình, kể cả đường dẫn trong bảng. */
.khoi-tl{margin:0 0 30px}
.khoi-tl td a{color:var(--mau)}
.khoi-tl td a:hover{color:color-mix(in srgb,var(--mau) 72%,#000)}

/* ── Hỏi đáp ─────────────────────────────────────────────────────────────── */
.hoi-dap{border:1px solid var(--vien);border-radius:var(--r2);background:var(--tam);margin:0 0 12px;overflow:hidden;
  box-shadow:var(--bong),var(--vien-sang)}
.hoi-dap summary{cursor:pointer;padding:17px 20px;font-weight:700;font-size:16px;list-style:none;
  display:flex;align-items:center;justify-content:space-between;gap:14px;transition:background var(--chuyen)}
.hoi-dap summary::-webkit-details-marker{display:none}
.hoi-dap summary::after{content:"+";color:var(--cam);font-size:23px;font-weight:400;flex:none;transition:transform var(--chuyen)}
.hoi-dap[open] summary::after{transform:rotate(45deg)}
.hoi-dap summary:hover{background:var(--tam2)}
.hoi-dap .dap{padding:0 20px 18px;color:var(--mo);margin:0}

/* ── Thang tầng ──────────────────────────────────────────────────────────── */
.thang{display:grid;gap:10px;margin:16px 0}
.bac{position:relative;display:grid;grid-template-columns:54px 1fr auto;gap:16px;align-items:center;
  background:var(--tam);border:1px solid var(--vien);border-radius:var(--r1);padding:13px 17px 13px 21px;
  box-shadow:var(--bong),var(--vien-sang);overflow:hidden;
  transition:transform var(--chuyen),border-color var(--chuyen),box-shadow var(--chuyen)}
.bac::before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px;
  background:linear-gradient(180deg,var(--nhan),var(--ngoc))}
.bac:hover{transform:translateX(4px);border-color:color-mix(in srgb,var(--nhan) 30%,var(--vien));
  box-shadow:0 14px 32px -20px color-mix(in srgb,var(--nhan) 66%,transparent)}
.bac .ma-tang{font:800 14px/1 var(--chu-ma);color:var(--nhan)}
.bac b{display:block;font-size:15.5px;margin-bottom:2px}
.bac .mo-ta{font-size:13.5px;color:var(--mo)}
.bac .dem{font:700 13px/1 var(--chu-ma);color:var(--mo2);white-space:nowrap}

/* ── Nghe thử ────────────────────────────────────────────────────────────── */
.nghe{display:grid;gap:14px;grid-template-columns:repeat(auto-fit,minmax(236px,1fr))}
.o-nghe{background:var(--tam);border:1px solid var(--vien);border-radius:var(--r2);padding:16px 17px;
  box-shadow:var(--bong),var(--vien-sang)}
.o-nghe .tu{font-size:20px;font-weight:800;letter-spacing:-.015em}
.o-nghe .ipa{font:15px/1.5 var(--chu-ma);color:var(--nhan);margin:3px 0 11px}
.o-nghe audio{width:100%;height:34px;display:block}

/* ── Bố cục hai cột, hình minh hoạ, biểu đồ ──────────────────────────────── */
.doi{display:grid;gap:34px;grid-template-columns:1.02fr .98fr;align-items:center}
.doi>*{min-width:0}
.mo-dau{margin:14px 0 54px}
.tranh{width:100%;height:auto;display:block}
code{font:.88em/1.5 var(--chu-ma);background:var(--nhan-nhat);border:1px solid color-mix(in srgb,var(--nhan) 18%,var(--vien));
  border-radius:6px;padding:1.5px 7px;color:var(--nhan)}
.bieu-do{margin:16px 0 6px;padding:22px 22px 16px;background:var(--tam);border:1px solid var(--vien);
  border-radius:var(--r2);box-shadow:var(--bong),var(--vien-sang)}
.bieu-do svg{display:block;width:100%;height:auto;color:var(--chu)}

/* ── Công thức toán dựng sẵn ở máy chủ ───────────────────────────────────── */
.tex{font-family:"Cambria Math","Latin Modern Math","Times New Roman",Georgia,serif;line-height:1.6;white-space:nowrap}
.tex-display{display:block;text-align:center;margin:10px 0;font-size:1.12em}
.tex-inline{display:inline-block;vertical-align:middle}
.tex-var{font-style:italic;padding:0 .5px}
.tex-fn{font-style:normal;padding-right:2px}
.tex-op{padding:0 4px}
.tex-text{font-family:inherit;font-style:normal}
.tex-bb{font-weight:600;font-style:normal}
.tex-delim{padding:0 1px}
.tex-unknown{color:var(--sen);font-family:var(--chu-ma);font-size:.85em}
.tex-frac{display:inline-flex;flex-direction:column;vertical-align:middle;text-align:center;margin:0 3px;font-size:.96em}
.tex-frac>.tex-num{border-bottom:1.3px solid currentColor;padding:0 4px 1px}
.tex-frac>.tex-den{padding:1px 4px 0}
.tex-root{display:inline-flex;align-items:flex-start;vertical-align:middle;margin:0 1px}
.tex-root>.tex-radical{font-size:1.05em;line-height:1}
.tex-root>.tex-radicand{border-top:1.3px solid currentColor;padding:1px 3px 0;margin-left:-1px}
.tex-root>.tex-rootidx{font-size:.62em;align-self:flex-start;margin-right:-5px;margin-top:-1px}
sup.tex-script,sub.tex-script{font-size:.72em;line-height:0}
sup.tex-script{vertical-align:super}
sup.tex-script .tex-op,sub.tex-script .tex-op{padding:0}
sub.tex-script{vertical-align:sub}
.tex-acc{display:inline-flex;flex-direction:column;align-items:center;vertical-align:middle;line-height:1;margin:0 1px}
.tex-acc>.tex-acc-mark{font-size:.78em;height:.46em;line-height:.46;font-style:normal}
.tex-acc>.tex-acc-body{line-height:1.05}
.tex-cases{display:inline-flex;align-items:center;vertical-align:middle}
.tex-cases>.tex-brace{font-size:2.1em;line-height:.85;font-weight:300;margin-right:3px}
.tex-rows{display:inline-flex;flex-direction:column;gap:3px}
.tex-row{display:flex;gap:10px;white-space:nowrap}

/* ── Chân trang ──────────────────────────────────────────────────────────── */
footer{border-top:1px solid var(--vien);background:var(--muc);margin-top:70px}
footer .thanh{display:grid;gap:24px;grid-template-columns:1.5fr 1fr;align-items:start;padding:38px 22px;color:var(--mo)}
footer .thanh p{font-size:14px;margin:0 0 6px}
footer nav{display:flex;flex-direction:column;gap:8px;align-items:flex-start}
footer nav a{font-size:14px;color:var(--mo);font-weight:600}
footer nav a:hover{color:var(--nhan)}
footer nav[aria-label="Toán theo lớp"]{flex-direction:row;flex-wrap:wrap;gap:6px;grid-column:1/-1;
  padding-top:20px;border-top:1px solid var(--vien);margin-top:4px}
footer nav[aria-label="Toán theo lớp"] a{font-size:13px;padding:5px 12px;border-radius:999px;color:#fff;
  background:var(--mau,var(--nhan));font-weight:700}
footer nav[aria-label="Toán theo lớp"] a:hover{color:#fff;filter:saturate(1.2)}

/* ── Màn hình hẹp ────────────────────────────────────────────────────────── */
@media(max-width:860px){
  .doi{grid-template-columns:1fr;gap:26px}
  .doi .tranh-hero{order:-1;max-width:460px;margin:0 auto}
  footer .thanh{grid-template-columns:1fr}
  header nav{margin-left:0;width:100%}
  header nav a{padding:7px 9px;font-size:14px}
  /* Trên màn hình hẹp, ô "Học Toán" chiếm trọn một hàng để bảng thả xuống
     trải hết bề ngang, thay vì treo lơ lửng đè lên các mục bên cạnh. */
  .thu{position:static;flex:1 0 100%}
  .thu>summary{width:100%;justify-content:space-between}
  .bang-thu{position:static;width:100%;max-width:100%;margin-top:9px}
  .dai-tien-ich .trai{display:none}
}
@media(max-width:560px){
  main{padding:22px 16px 56px}
  .thanh{padding:11px 16px}
  h1{font-size:clamp(27px,7.4vw,34px)}
  .luoi,.luoi-lop{grid-template-columns:1fr}
  /* Bốn cột "Lớp 12" không lọt bề ngang điện thoại, rút còn ba. */
  .o-lop{grid-template-columns:repeat(3,1fr)}
  .so-lieu{grid-template-columns:1fr 1fr}
  .trung-bay{padding:18px 17px;border-radius:var(--r2)}
  .bang-hieu{padding:24px 22px}
  .bac{grid-template-columns:46px 1fr;row-gap:4px}
  .bac .dem{grid-column:2}
}
@media (prefers-reduced-motion: reduce){
  html{scroll-behavior:auto}
  *,body::before,.bang-hieu{animation:none!important;transition:none!important}
  .nut::after{display:none}
  .the:hover,.nut:hover,.bac:hover,.the-lop:hover,.o-lop a:hover{transform:none}
}
`.replace(/\n\s*/g, '\n');

// ── Dụng cụ dựng trang ─────────────────────────────────────────────────────

/** Dấu hiệu thương hiệu, vẽ bằng SVG nội tuyến — không tải tệp ảnh nào. */
/**
 * Linh vật. Vẽ bằng hình học cơ bản — vuông tròn tam giác — vì đó đúng là thứ
 * môn Toán dạy, và vì hình phẳng thì dựng bằng SVG được, không phải tải ảnh.
 * Tham số `id` để đặt tên riêng cho dải màu: một trang có nhiều linh vật thì
 * các dải màu không được trùng tên, nếu không trình duyệt lấy nhầm của nhau.
 */
function linhVat(cao = 30, id = 'lv') {
  return `<svg class="dau" width="${cao}" height="${cao}" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
  <defs><linearGradient id="${id}-a" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0%" stop-color="#4dabf7"/><stop offset="100%" stop-color="#0f9d6e"/></linearGradient></defs>
  <path d="M32 3 v7" stroke="#e8590c" stroke-width="3" stroke-linecap="round"/>
  <path d="M32 0.5 l2.1 4.3 4.7.7-3.4 3.3.8 4.7-4.2-2.2-4.2 2.2.8-4.7-3.4-3.3 4.7-.7z" fill="#e8590c"/>
  <rect x="8" y="12" width="48" height="44" rx="14" fill="url(#${id}-a)"/>
  <rect x="14" y="20" width="36" height="24" rx="10" fill="#fff" fill-opacity=".93"/>
  <circle cx="25" cy="31" r="4.4" fill="#10203a"/><circle cx="39" cy="31" r="4.4" fill="#10203a"/>
  <circle cx="26.6" cy="29.4" r="1.5" fill="#fff"/><circle cx="40.6" cy="29.4" r="1.5" fill="#fff"/>
  <path d="M26 38.5 q6 4.5 12 0" stroke="#10203a" stroke-width="2.4" stroke-linecap="round" fill="none"/>
  <rect x="24" y="48" width="16" height="4" rx="2" fill="#fff" fill-opacity=".5"/>
</svg>`;
}

const DAU_HIEU = linhVat(30, 'hieu');

/** Hình trang trí cho băng mời học thử: sách, thước, compa và vài hình khối. */
const TRANH_BANG = `<svg class="trang-tri" viewBox="0 0 260 200" aria-hidden="true" focusable="false">
  <g fill="#fff" fill-opacity=".16">
    <circle cx="44" cy="40" r="26"/><rect x="92" y="18" width="46" height="46" rx="10"/>
    <path d="M186 16 l26 46 h-52z"/>
  </g>
  <g fill="#fff" fill-opacity=".26">
    <rect x="20" y="96" width="118" height="86" rx="12"/>
    <rect x="150" y="118" width="86" height="64" rx="12"/>
  </g>
  <g stroke="#fff" stroke-opacity=".5" stroke-width="3" fill="none" stroke-linecap="round">
    <path d="M36 118 h86"/><path d="M36 134 h64"/><path d="M36 150 h78"/>
    <path d="M166 140 h54"/><path d="M166 158 h36"/>
  </g>
</svg>`;

/**
 * Mỗi dạng bài thuộc một môn, và không phải dạng nào cũng gắn với một lớp.
 * Dạng toán mang lớp ngay trong mã; dạng tiếng Anh và dạng liên môn thì trải
 * dài nhiều lớp nên chỉ có tầng năng lực. Trước đây phần này suy lớp bằng
 * biểu thức chỉ khớp mã "M…", nên mười tám trang hiện ra "Toán lớp null".
 */
function nhomCua(ma) {
  const lop = lopCua(ma);
  if (lop) return { mon: 'Toán', lop, nhan: `Toán lớp ${lop}`, loc: `/chuong-trinh?lop=${lop}`, tenLoc: `Lớp ${lop}` };
  if (String(ma).startsWith('E.')) return { mon: 'Tiếng Anh', lop: null, nhan: 'Tiếng Anh', loc: '/chuong-trinh?nhom=E', tenLoc: 'Tiếng Anh' };
  return { mon: 'Liên môn và tư duy', lop: null, nhan: 'Liên môn và tư duy', loc: '/chuong-trinh?nhom=X', tenLoc: 'Liên môn' };
}

/** Dựng công thức LaTeX ngay tại máy chủ, để trang đọc được khi tắt JavaScript. */
let _tex = null;
function tex(s) {
  if (!_tex) { try { _tex = require('../../ui/tex.js'); } catch { _tex = { renderText: (x) => esc(x) }; } }
  try { return _tex.renderText(String(s)); } catch { return esc(String(s)); }
}

/**
 * Lấy MỘT bài thật của một dạng để trưng ra trang công khai.
 *
 * Bài này không lấy từ kho — kho có thể chưa gieo — mà dựng thẳng từ bản thiết
 * kế, rồi cho bộ kiểm chứng giải lại ngay tại chỗ. Nhờ vậy con số hiện trên
 * trang là kết quả chạy thật, và trang nói được điều nó đang quảng cáo thay vì
 * chỉ hứa. Nhớ lại kết quả theo mã dạng vì một lần dựng trang gọi tới nhiều lần.
 */
const _mau = new Map();
function mauBai(ma) {
  if (_mau.has(ma)) return _mau.get(ma);
  let ra = null;
  try {
    const { blueprintsForForm } = require('../content/blueprint');
    const bp = blueprintsForForm(ma)[0];
    if (bp) {
      // Lấy bộ tham số ở GIỮA không gian, không lấy bộ đầu tiên: bộ đầu thường
      // rơi vào trường hợp biên và nhìn không giống một bài thi thật.
      const cac = [];
      for (const t of bp.space()) { cac.push(t); if (cac.length >= 9) break; }
      const it = bp.render(cac[Math.min(4, cac.length - 1)]);
      const MathVerifier = require('../math/verifier');
      const v = new MathVerifier({ seed: `web-${ma}` }).verifyItem(it);
      ra = { bp, it, v };
    }
  } catch { ra = null; }
  _mau.set(ma, ra);
  return ra;
}

/**
 * Đề bài giữ nguyên chỗ XUỐNG DÒNG của bản thiết kế.
 *
 * Đề một dòng thì đổ thẳng vào thẻ nào cũng đọc được. Nhưng đề đọc hiểu có một
 * đoạn văn rồi bốn phương án, đề mô tả số liệu có một bảng — nhồi tất cả vào
 * một khối thì trên màn hình chúng dính liền nhau: "…saves a tonne of material.
 * A. The sorting and rinsing…" và người đọc không tách được đâu là bài đâu là
 * phương án. Mỗi dòng của đề vì thế thành một khối riêng, và dòng nào là phương
 * án A–D thì thụt vào để nhìn ra ngay bốn lựa chọn.
 */
function deNhieuDong(s) {
  const dong = String(s || '').split('\n').map((d) => d.trim()).filter(Boolean);
  if (dong.length <= 1) return tex(String(s || ''));
  return dong.map((d) => `<div class="${/^[A-D]\.\s/.test(d) ? 'dong-de lua-chon' : 'dong-de'}">${tex(d)}</div>`).join('');
}

/** Khối trưng bày một bài thật kèm vết máy tự kiểm. */
function khoiBai(ma, { tieuDe = 'Một bài thật trong kho', gonLoiGiai = false } = {}) {
  const m = mauBai(ma);
  if (!m) return '';
  const { bp, it, v } = m;
  const buoc = cacBuoc(it).slice(0, gonLoiGiai ? 3 : 6);
  const vet = (v.checks || []).slice(0, 3);
  return `<section class="trung-bay" data-hoc-lieu="1">
  <div class="nhan-tren"><span>${esc(tieuDe)}</span><span>${esc(ma)} · ${'★'.repeat(bp.stars)}</span></div>
  <div class="de-bai">${deNhieuDong(it.stem)}</div>
  ${buoc.length ? `<ol class="buoc">${buoc.map((b) => `<li>${tex(b.viec)}`
    + (b.canCu ? `<span class="can-cu">${tex(b.canCu)}</span>` : '')
    + '</li>').join('')}</ol>` : ''}
  <div class="vet">
    <div class="dong"><span class="dau-tich">✓</span><span><b>Máy đã giải lại và khớp.</b> ${esc(v.reason || '')}</span></div>
    ${vet.map((c) => `<div class="dong"><span class="dau-tich">${c.passed ? '✓' : '✗'}</span><span>${esc(c.name)} — ${esc(String(c.detail || '').slice(0, 120))}</span></div>`).join('')}
    <div class="dong"><span class="dau-tich">✓</span><span>Nhắm đúng bẫy: <b>${esc(hoaDau(bp.targetTrap))}</b></span></div>
  </div>
</section>`;
}

/** Biểu đồ cột dựng sẵn ở máy chủ, không cần thư viện và không cần JavaScript. */
function bieuDoCot(dong, { nhan = 'Biểu đồ cột' } = {}) {
  // Hệ toạ độ lấy cỡ xấp xỉ pixel thật (1000 × 250). Nếu dùng hệ 0–100 thì khi
  // khung rộng 1000 pixel, mỗi đơn vị thành 10 pixel và cỡ chữ bị phóng to
  // gấp mười lần — đó là lý do phải chọn hệ toạ độ theo cỡ hiển thị.
  const W = 1000; const H = 260; const day = 196;
  // Mỗi cột một màu riêng thay vì cả biểu đồ chung một dải: mắt phân biệt được
  // từng khối ngay, và màu khớp với màu của lớp ở chỗ khác trên trang.
  const MAU = [['#4dabf7', '#1668c9'], ['#63e6be', '#0f9d6e'], ['#ffc078', '#e8590c'],
    ['#b197fc', '#6741d9'], ['#66d9e8', '#0b7285'], ['#ffa8a8', '#c92a48']];
  const max = Math.max(...dong.map((d) => d.gia), 1);
  const o = W / dong.length;
  const dai = dong.map((d, i) => {
    const h = Math.max(10, (d.gia / max) * (day - 34));
    const x = i * o + o * 0.24;
    const w = o * 0.52;
    const [c1, c2] = MAU[i % MAU.length];
    return `<g>
      <rect x="${x.toFixed(1)}" y="${(day - h + 6).toFixed(1)}" width="${w.toFixed(1)}" height="${h.toFixed(1)}"
        rx="8" fill="${c2}" opacity=".22" filter="url(#g-mo)"/>
      <rect x="${x.toFixed(1)}" y="${(day - h).toFixed(1)}" width="${w.toFixed(1)}" height="${h.toFixed(1)}"
        rx="8" fill="url(#g-${i})"><title>${esc(d.ten)}: ${d.gia} dạng</title></rect>
      <rect x="${(x + 3).toFixed(1)}" y="${(day - h + 3).toFixed(1)}" width="${(w - 6).toFixed(1)}" height="${Math.min(26, h / 2).toFixed(1)}"
        rx="5" fill="#fff" opacity=".17"/>
      <text x="${(x + w / 2).toFixed(1)}" y="${(day - h - 13).toFixed(1)}" text-anchor="middle"
        font-size="26" font-weight="800" fill="${c2}">${d.gia}</text>
      <text x="${(x + w / 2).toFixed(1)}" y="${(day + 30).toFixed(1)}" text-anchor="middle"
        font-size="18" fill="currentColor" opacity=".64">${esc(d.ten)}</text>
    </g>`;
  }).join('');
  const dinhNghia = dong.map((d, i) => {
    const [c1, c2] = MAU[i % MAU.length];
    return `<linearGradient id="g-${i}" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="${c1}"/><stop offset="100%" stop-color="${c2}"/></linearGradient>`;
  }).join('');
  return `<figure class="bieu-do" role="img" aria-label="${esc(nhan)}">
  <svg viewBox="0 0 ${W} ${H}" aria-hidden="true" focusable="false">
    <defs>${dinhNghia}
      <filter id="g-mo" x="-40%" y="-40%" width="180%" height="180%">
        <feGaussianBlur stdDeviation="9"/></filter></defs>
    <line x1="0" y1="${day}" x2="${W}" y2="${day}" stroke="currentColor" stroke-opacity=".16" stroke-width="1.4"/>
    ${dai}
  </svg>
</figure>`;
}

/** Thẻ nghe thử một từ tiếng Anh: phiên âm thật, tiếng đọc do máy chủ dựng. */
function oNghe(tu) {
  let ipa = '';
  try { ipa = require('../voice/en-phonemizer').phienAm(tu).ipa; } catch { ipa = ''; }
  return `<div class="o-nghe">
  <div class="tu">${esc(tu)}</div>
  <div class="ipa">${esc(ipa)}</div>
  <audio controls preload="none" src="/en/doc?text=${encodeURIComponent(tu)}&amp;nhanh=0"></audio>
</div>`;
}

// ── Trang theo lớp và trang ôn thi ──────────────────────────────────────────

/** Các dạng bài của một lớp, sắp theo tầng thấp lên cao. */
function dangCuaLop(n) {
  return [...FORM_INDEX.values()]
    .filter((f) => lopCua(f.code) === Number(n))
    .sort((a, b) => (a.levelRange[0] - b.levelRange[0]) || a.code.localeCompare(b.code));
}

/** Gộp thời gian chuẩn của cả lớp, đổi sang phút cho dễ hình dung. */
const phutCuaLop = (ds) => Math.round(ds.reduce((t, f) => t + (f.norm || 0), 0) / 60);

/**
 * Dạng của lớp dưới mà lớp này dùng lại làm bước trong lời giải.
 * Đây là thứ danh mục phẳng không nói ra được: học viên lớp 9 hổng dạng lớp 8
 * thì không phải "yếu lớp 9", mà là chưa xong lớp 8 — và chỗ hổng nằm ở đâu
 * thì bảng dưới chỉ đúng vào đó.
 */
function nenTuLopDuoi(n) {
  const ra = new Map();
  for (const f of dangCuaLop(n)) {
    for (const ma of f.prereq || []) {
      const p = FORM_INDEX.get(ma);
      if (!p || lopCua(p.code) === Number(n)) continue;
      if (!ra.has(ma)) ra.set(ma, { dang: p, dung: [] });
      ra.get(ma).dung.push(f);
    }
  }
  return [...ra.values()].sort((a, b) => b.dung.length - a.dung.length);
}

/** Dạng của lớp trên sẽ dùng lại dạng của lớp này. */
function lopTrenDungLai(n) {
  const ma = new Set(dangCuaLop(n).map((f) => f.code));
  return [...FORM_INDEX.values()]
    .filter((f) => lopCua(f.code) > Number(n) && (f.prereq || []).some((c) => ma.has(c)))
    .sort((a, b) => lopCua(a.code) - lopCua(b.code));
}

function trangLop(N, nonce = null) {
  const n = Number(N);
  if (!(n >= 1 && n <= 12)) return null;
  const ds = dangCuaLop(n);
  if (!ds.length) return null;
  const tangLo = Math.min(...ds.map((f) => f.levelRange[0]));
  const tangHi = Math.max(...ds.map((f) => f.levelRange[1]));
  const phut = phutCuaLop(ds);
  const nen = nenTuLopDuoi(n);
  const tren = lopTrenDungLai(n).slice(0, 6);
  const bay = [...new Set(ds.flatMap((f) => f.traps || []))];
  let coBanVe = 0;
  try {
    const { blueprintsForForm } = require('../content/blueprint');
    coBanVe = ds.filter((f) => blueprintsForForm(f.code).length).length;
  } catch { coBanVe = 0; }
  const coMau = ds.find((f) => mauBai(f.code));
  const cap = n <= 5 ? 'tiểu học' : n <= 9 ? 'trung học cơ sở' : 'trung học phổ thông';

  const than = `
<p class="eyebrow">Toán ${cap}</p>
<h1>Toán lớp ${n}: ${ds.length} dạng bài, học theo tầng năng lực</h1>
<p class="lead">Toàn bộ chương trình Toán lớp ${n} được chia thành ${ds.length} dạng bài rõ ràng.
Mỗi dạng có điều kiện cần nắm trước, bẫy thường gặp và thời gian làm bài chuẩn, nên học viên biết mình đang ở đâu và còn thiếu gì.</p>
<div class="cta">
  <a class="nut" href="/ui/hoc-vien.html">Học thử lớp ${n}</a>
  <a class="nut phu" href="/thi-thu">Thi thử lớp ${n}</a>
</div>

<h2>Lớp ${n} trong một cái nhìn</h2>
<div class="so-lieu">
  <div class="o-so"><b>${ds.length}</b><small>dạng bài trong chương trình lớp ${n}</small></div>
  <div class="o-so"><b>${tangLo}–${tangHi}</b><small>dải tầng năng lực các dạng này trải qua</small></div>
  <div class="o-so"><b>${phut}</b><small>phút là tổng thời gian chuẩn làm hết một lượt</small></div>
  <div class="o-so"><b>${coBanVe}</b><small>dạng đã có học liệu dựng sẵn, máy kiểm được</small></div>
</div>

${coMau ? `<h2>Một bài của lớp ${n}, dựng và kiểm ngay tại đây</h2>
<p class="dat">Bài dưới đây thuộc dạng <strong>${esc(coMau.name)}</strong>. Hệ thống dựng bài từ bản thiết kế rồi tự giải lại để đối chiếu, ngay trong lúc trang này hiện ra.</p>
${khoiBai(coMau.code, { tieuDe: `Dạng ${coMau.code}` })}` : ''}

<h2>${ds.length} dạng bài của lớp ${n}</h2>
<p class="dat">Xếp theo tầng thấp lên cao, đúng thứ tự nên học.</p>
<div class="luoi">
${ds.map((f) => `<a class="the" href="/chuong-trinh/${esc(f.code)}">
  <span class="ma">${esc(f.code)}</span>
  <h3>${esc(f.name)}</h3>
  <p class="nho">Tầng ${f.levelRange[0]}–${f.levelRange[1]} · ${f.norm} giây một bài</p>
  ${(f.traps || [])[0] ? `<p class="nho">Bẫy chính: ${esc(hoaDau(f.traps[0]))}</p>` : ''}
</a>`).join('')}
</div>

${nen.length ? `<h2>Nền từ lớp dưới mà lớp ${n} dùng lại</h2>
<p class="dat">Học viên vướng ở lớp ${n} thường không phải vì bài lớp ${n} khó, mà vì một dạng ở lớp dưới còn hổng.
Bảng dưới chỉ đúng những dạng đó và cho biết lớp ${n} dùng lại chúng ở mấy chỗ.</p>
<div class="khung-bang">
<table>
  <caption class="bo-qua">Dạng tiên quyết ở lớp dưới của chương trình lớp ${n}</caption>
  <thead><tr><th scope="col">Dạng cần nắm trước</th><th scope="col">Lớp</th><th scope="col">Lớp ${n} dùng lại ở</th></tr></thead>
  <tbody>${nen.map((x) => `<tr>
    <td><a href="/chuong-trinh/${esc(x.dang.code)}">${esc(x.dang.name)}</a></td>
    <td>${lopCua(x.dang.code)}</td>
    <td>${x.dung.map((f) => esc(f.name)).join(' · ')}</td>
  </tr>`).join('')}</tbody>
</table>
</div>` : ''}

${bay.length ? `<h2>Bẫy hay gặp ở lớp ${n}</h2>
<p class="dat">Đây là ${bay.length} chỗ mất điểm đã được khai sẵn trong chương trình. Mỗi lần học viên mắc bẫy nào, hệ thống ghi lại đúng bẫy đó để luyện lại.</p>
<ul class="tick">${bay.slice(0, 12).map((t) => `<li>${esc(hoaDau(t))}</li>`).join('')}</ul>` : ''}

${tren.length ? `<h2>Lớp trên sẽ dùng lại lớp ${n} ở đâu</h2>
<p class="dat">Học chắc lớp ${n} không phải để qua kỳ thi năm nay, mà vì những dạng dưới đây dựng thẳng trên nó.</p>
<div class="luoi">${tren.map((f) => `<a class="the" href="/chuong-trinh/${esc(f.code)}"><span class="ma">Lớp ${lopCua(f.code)}</span><h3>${esc(f.name)}</h3></a>`).join('')}</div>` : ''}

<h2>Học lớp ${n} ở đây</h2>
<div class="cta">
  <a class="nut" href="/ui/hoc-vien.html">Vào luyện tập</a>
  ${n > 1 ? `<a class="nut phu" href="/lop/${n - 1}">Xem lại lớp ${n - 1}</a>` : ''}
  ${n < 12 ? `<a class="nut phu" href="/lop/${n + 1}">Xem trước lớp ${n + 1}</a>` : ''}
  <a class="nut phu" href="/lo-trinh">Lộ trình theo tầng</a>
</div>
`;

  return khung({
    tieuDe: SEO.tieuDeVua(`Toán lớp ${n} — ${ds.length} dạng bài theo tầng`),
    moTa: SEO.moTaVua(`Chương trình Toán lớp ${n} chia thành ${ds.length} dạng bài, trải tầng ${tangLo} đến ${tangHi}, `
      + `tổng thời gian chuẩn ${phut} phút. Mỗi dạng có bẫy thường gặp và dạng cần nắm trước.`),
    duongDan: `/lop/${n}`,
    loai: 'article',
    mau: `l${n}`,
    vun: [{ ten: 'Trang chủ', duongDan: '/' }, { ten: 'Chương trình', duongDan: '/chuong-trinh' }, { ten: `Lớp ${n}`, duongDan: `/lop/${n}` }],
    than,
    nonce,
  });
}

// ── Ôn thi chuyển cấp ───────────────────────────────────────────────────────
// Danh mục ôn thi KHÔNG phải một kho bài riêng: nó là một lát cắt qua đúng
// chương trình đang vận hành, lấy các lớp liên quan rồi siết ngưỡng tầng. Làm
// như vậy thì đề ôn thi không bao giờ lệch khỏi chương trình học hằng ngày.
const ON_THI = {
  'vao-lop-6': {
    ten: 'Ôn thi vào lớp 6',
    ngan: 'vào lớp 6',
    lop: [4, 5],
    themX: true,
    tangToiThieu: 3,
    moTa: 'Kỳ thi vào lớp 6 trường chất lượng cao hỏi phần lớn kiến thức lớp 4 và lớp 5, nhưng hỏi ở tầng cao hơn bài trên lớp.',
    luu: 'Đề vào lớp 6 thường có cả phần suy luận và đọc số liệu, nên nhóm liên môn được đưa vào cùng.',
  },
  'vao-lop-10': {
    ten: 'Ôn thi vào lớp 10',
    ngan: 'vào lớp 10',
    lop: [8, 9],
    themX: false,
    tangToiThieu: 3,
    moTa: 'Đề vào lớp 10 tập trung ở lớp 9, nhưng mọi lời giải đều dựng trên nền lớp 8: phân tích đa thức, phương trình bậc nhất và tam giác đồng dạng.',
    luu: 'Phần hình học chiếm tỉ trọng lớn và là chỗ mất điểm nhiều nhất, nên các dạng hình được xếp riêng.',
  },
  'danh-gia-nang-luc': {
    ten: 'Ôn thi đánh giá năng lực',
    ngan: 'đánh giá năng lực',
    lop: [],
    themX: true,
    tangToiThieu: 3,
    moTa: 'Bài đánh giá năng lực không hỏi thuộc lòng mà hỏi cách nghĩ: suy luận nhiều bước, đọc số liệu, vận dụng công thức và đọc hiểu văn bản khoa học.',
    luu: 'Nhóm này đo thứ mà đề thi đánh giá năng lực thật sự hỏi, gồm cả việc biết dừng lại ở chỗ dữ liệu hết nói.',
  },
};

function trangOnThi(id, nonce = null) {
  const c = ON_THI[id];
  if (!c) return null;
  let ds = [...FORM_INDEX.values()].filter((f) => c.lop.includes(lopCua(f.code)));
  if (c.themX) ds = ds.concat([...FORM_INDEX.values()].filter((f) => f.code.startsWith('X.')));
  ds = ds.filter((f) => f.levelRange[1] >= c.tangToiThieu)
    .sort((a, b) => (b.levelRange[1] - a.levelRange[1]) || a.code.localeCompare(b.code));
  const phut = phutCuaLop(ds);
  const bay = [...new Set(ds.flatMap((f) => f.traps || []))];
  const coMau = ds.find((f) => mauBai(f.code));
  const chuan = LEVEL_STANDARDS.filter((s) => s.level >= c.tangToiThieu && s.level <= c.tangToiThieu + 3);

  const than = `
<p class="eyebrow">Ôn thi chuyển cấp</p>
<h1>${esc(c.ten)}: ${ds.length} dạng bài phải nắm chắc</h1>
<p class="lead">${esc(c.moTa)}</p>
<div class="cta">
  <a class="nut" href="/ui/hoc-vien.html">Bắt đầu ôn</a>
  <a class="nut phu" href="/thi-thu">Thi thử</a>
</div>

<h2>Phạm vi ôn tập</h2>
<div class="so-lieu">
  <div class="o-so"><b>${ds.length}</b><small>dạng bài nằm trong phạm vi ${esc(c.ngan)}</small></div>
  <div class="o-so"><b>${c.tangToiThieu}+</b><small>tầng tối thiểu cần đạt ở mỗi dạng</small></div>
  <div class="o-so"><b>${phut}</b><small>phút là tổng thời gian chuẩn làm hết một lượt</small></div>
  <div class="o-so"><b>${bay.length}</b><small>bẫy đã khai sẵn trên các dạng này</small></div>
</div>
<p class="dat">${esc(c.luu)}</p>

${coMau ? `<h2>Một bài trong phạm vi ôn, dựng và kiểm ngay</h2>
${khoiBai(coMau.code, { tieuDe: `Dạng ${coMau.code}` })}` : ''}

<h2>Danh mục dạng bài cần nắm chắc</h2>
<p class="dat">Xếp theo tầng cao xuống thấp: dạng đứng trên là dạng đề thi hay hỏi ở mức khó nhất.</p>
<div class="khung-bang">
<table>
  <caption class="bo-qua">Danh mục dạng bài ${esc(c.ten)}</caption>
  <thead><tr><th scope="col">Dạng bài</th><th scope="col">Thuộc</th><th scope="col">Tầng</th><th scope="col">Bẫy nhắm tới</th></tr></thead>
  <tbody>${ds.map((f) => `<tr>
    <td><a href="/chuong-trinh/${esc(f.code)}">${esc(f.name)}</a></td>
    <td>${esc(nhomCua(f.code).nhan)}</td>
    <td>${f.levelRange[0]}–${f.levelRange[1]}</td>
    <td>${esc(hoaDau((f.traps || [])[0] || 'chưa khai'))}</td>
  </tr>`).join('')}</tbody>
</table>
</div>

<h2>Thế nào là đã sẵn sàng</h2>
<p class="dat">Không đo bằng số buổi đã học mà đo bằng chuẩn của tầng. Muốn yên tâm bước vào phòng thi, mỗi dạng trong danh mục trên phải đạt các mốc sau.</p>
<div class="khung-bang">
<table>
  <caption class="bo-qua">Chuẩn tầng áp dụng cho ${esc(c.ten)}</caption>
  <thead><tr><th scope="col">Tầng</th><th scope="col">Tên tầng</th><th scope="col">Tỉ lệ đúng</th><th scope="col">Số bài tối thiểu mỗi dạng</th></tr></thead>
  <tbody>${chuan.map((s) => `<tr><td>${s.level}</td><td>${esc(s.name)}</td><td>${Math.round(s.accuracy * 100)}%</td><td>${s.minItemsPerForm}</td></tr>`).join('')}</tbody>
</table>
</div>

${bay.length ? `<h2>Những chỗ mất điểm phải chặn trước</h2>
<ul class="tick">${bay.slice(0, 14).map((t) => `<li>${esc(hoaDau(t))}</li>`).join('')}</ul>` : ''}

<h2>Bắt đầu ôn</h2>
<div class="cta">
  <a class="nut" href="/ui/hoc-vien.html">Làm bài chẩn đoán</a>
  ${c.lop.map((l) => `<a class="nut phu" href="/lop/${l}">Xem cả lớp ${l}</a>`).join('')}
</div>
`;

  return khung({
    tieuDe: SEO.tieuDeVua(`${c.ten} — ${ds.length} dạng bài trọng tâm`),
    moTa: SEO.moTaVua(`${c.ten}: ${ds.length} dạng bài trọng tâm, ${bay.length} bẫy thường gặp và chuẩn tầng cần đạt. `
      + `Tổng thời gian chuẩn ${phut} phút cho một lượt luyện hết phạm vi.`),
    duongDan: `/on-thi/${id}`,
    loai: 'article',
    vun: [{ ten: 'Trang chủ', duongDan: '/' }, { ten: 'Ôn thi', duongDan: '/on-thi/vao-lop-6' }, { ten: c.ten, duongDan: `/on-thi/${id}` }],
    than,
    nonce,
  });
}

// ── Thi thử ────────────────────────────────────────────────────────────────

function trangThiThu(nonce = null) {
  const lop = [];
  for (let n = 1; n <= 12; n++) {
    const ds = dangCuaLop(n);
    if (ds.length) lop.push({ n, so: ds.length, phut: phutCuaLop(ds) });
  }
  const than = `
<p class="eyebrow">Làm trong điều kiện thi thật</p>
<h1>Thi thử: đề trộn dạng, tính giờ, chấm ngay</h1>
<p class="lead">Thi thử không phải làm thêm bài. Đề thi thử trộn dạng theo ma trận cố định của tầng, tính giờ theo thời gian chuẩn của từng dạng,
và chấm xong thì chỉ rõ mất điểm ở bẫy nào chứ không chỉ báo số điểm.</p>

<h2>Đề thi thử khác đề luyện ở chỗ nào</h2>
<div class="luoi">
  <div class="the nhan"><span class="ma">Khác 1</span><h3>Trộn dạng, không báo trước</h3>
    <p>Đề luyện cho biết đang làm dạng nào. Đề thi thử thì không, nên học viên phải tự nhận ra dạng — đúng việc phải làm trong phòng thi.</p></div>
  <div class="the"><span class="ma">Khác 2</span><h3>Tính giờ theo thời gian chuẩn</h3>
    <p>Mỗi dạng có thời gian chuẩn riêng. Đề thi thử cộng dồn các mốc đó chứ không chia đều số phút cho số câu.</p></div>
  <div class="the"><span class="ma">Khác 3</span><h3>Loại bài vừa gặp</h3>
    <p>Bài học viên vừa làm trong kỳ ôn sẽ không xuất hiện lại trong đề thi thử, để điểm số đo năng lực chứ không đo trí nhớ ngắn hạn.</p></div>
  <div class="the"><span class="ma">Khác 4</span><h3>Chấm theo bẫy</h3>
    <p>Chấm xong không dừng ở điểm số: hệ thống chỉ ra từng câu sai rơi vào bẫy nào và dạng nào cần luyện lại trước.</p></div>
</div>

<h2>Chọn đề theo lớp</h2>
<p class="dat">Con số bên cạnh mỗi lớp là số dạng bài mà đề của lớp đó lấy câu, và tổng thời gian chuẩn nếu làm hết một lượt.</p>
<div class="luoi">
${lop.map((x) => `<a class="the" href="/lop/${x.n}"><span class="ma">Lớp ${x.n}</span>
  <h3>Đề thi thử lớp ${x.n}</h3>
  <p class="nho">${x.so} dạng bài · khoảng ${x.phut} phút một lượt đầy đủ</p></a>`).join('')}
</div>

<h2>Đề chuyển cấp</h2>
<div class="luoi">
${Object.entries(ON_THI).map(([id, c]) => `<a class="the" href="/on-thi/${esc(id)}"><span class="ma">Chuyển cấp</span>
  <h3>${esc(c.ten)}</h3><p class="nho">${esc(c.moTa.slice(0, 96))}…</p></a>`).join('')}
</div>

<h2>Vào thi thử</h2>
<div class="cta"><a class="nut" href="/ui/hoc-vien.html">Bắt đầu một đề</a><a class="nut phu" href="/lo-trinh">Xem chuẩn lên tầng</a></div>
`;
  return khung({
    tieuDe: SEO.tieuDeVua('Thi thử Toán — đề trộn dạng, tính giờ, chấm theo bẫy'),
    moTa: SEO.moTaVua('Đề thi thử trộn dạng theo ma trận của tầng, tính giờ theo thời gian chuẩn từng dạng, loại bài vừa gặp và chấm xong thì chỉ rõ mất điểm ở bẫy nào.'),
    duongDan: '/thi-thu',
    vun: [{ ten: 'Trang chủ', duongDan: '/' }, { ten: 'Thi thử', duongDan: '/thi-thu' }],
    than,
    nonce,
  });
}

/**
 * Thẻ khoá học của một lớp. Ba dòng mô tả KHÔNG phải lời quảng cáo viết sẵn mà
 * là tên ba dạng bài thật của lớp đó, lấy từ chương trình đang vận hành — đổi
 * chương trình thì thẻ đổi theo, không ai phải nhớ đi sửa lại.
 */
function theLop(n) {
  const ds = dangCuaLop(n);
  if (!ds.length) return '';
  const ba = ds.slice(0, 3).map((f) => f.name);
  return `<a class="the-lop l${n}" href="/lop/${n}">
  <span class="so-lop">${n}</span>
  <span class="than-lop">
    <h3>Toán lớp ${n}</h3>
    <ul>${ba.map((t) => `<li>${esc(t)}</li>`).join('')}</ul>
    <p class="nho">${ds.length} dạng bài · khoảng ${phutCuaLop(ds)} phút một lượt</p>
  </span>
</a>`;
}

// ── Thư viện đề thi ────────────────────────────────────────────────────────
/**
 * Trang đề thi KHÔNG liệt kê những tệp đề đã soạn sẵn nằm chờ, mà liệt kê các
 * BỘ ĐỀ dựng ra lúc học viên bấm vào. Đề dựng theo ma trận độ khó cố định,
 * phủ đủ dạng của phạm vi, và loại những bài học viên vừa luyện trong ba mươi
 * ngày gần nhất — nên hai người làm cùng một bộ đề vẫn nhận hai đề khác nhau,
 * và không ai luyện thuộc được đáp án.
 */
/**
 * Cỡ đề dùng khắp trang phải lấy từ chính hệ thống dựng đề, không chép tay.
 * Trước đây trang ghi 8, 12 hoặc 16 câu tuỳ chỗ trong khi hệ thống dựng 12 —
 * người đọc thấy một con số, làm bài lại ra con số khác.
 */
let SO_CAU_DE = 20;
try { SO_CAU_DE = require('../learner/exam').DEFAULT_SIZE || 20; } catch { SO_CAU_DE = 20; }

function thongSoDe(ds, soCau) {
  const trungBinh = ds.length ? ds.reduce((t, f) => t + (f.norm || 120), 0) / ds.length : 120;
  return {
    soCau,
    phut: Math.max(10, Math.round((trungBinh * soCau * 1.2) / 60)),
    soDang: ds.length,
  };
}

function trangDeThi(nonce = null) {
  let CHANG = [];
  let SO_CAU = 20;
  try {
    const E = require('../learner/exam');
    CHANG = E.MATRIX_BY_BAND || [];
    SO_CAU = E.DEFAULT_SIZE || 20;
  } catch { CHANG = []; }
  const BAC = [1, 2, 3, 4, 5];
  const TEN_BAC = { 1: 'Nhận biết', 2: 'Thông hiểu', 3: 'Vận dụng', 4: 'Vận dụng cao', 5: 'Thách thức' };
  const { formsForLevel } = require('../curriculum/hierarchy');

  const theoTang = LEVELS.map((l) => {
    const ds = formsForLevel(l.id);
    return { l, ...thongSoDe(ds, SO_CAU_DE) };
  }).filter((x) => x.soDang > 0);

  const theoLop = [];
  for (let n = 1; n <= 12; n++) {
    const ds = dangCuaLop(n);
    if (ds.length) theoLop.push({ n, ...thongSoDe(ds, SO_CAU_DE) });
  }

  const chuyenCap = Object.entries(ON_THI).map(([id, c]) => {
    let ds = [...FORM_INDEX.values()].filter((f) => c.lop.includes(lopCua(f.code)));
    if (c.themX) ds = ds.concat([...FORM_INDEX.values()].filter((f) => f.code.startsWith('X.')));
    ds = ds.filter((f) => f.levelRange[1] >= c.tangToiThieu);
    return { id, c, ...thongSoDe(ds, SO_CAU_DE) };
  });

  const bang = (tieuDe, dong) => `<div class="khung-bang">
<table>
  <caption class="bo-qua">${esc(tieuDe)}</caption>
  <thead><tr><th scope="col">Bộ đề</th><th scope="col">Số câu</th><th scope="col">Thời gian</th><th scope="col">Phủ dạng</th><th scope="col">Vào làm</th></tr></thead>
  <tbody>${dong.map((d) => `<tr>
    <td>${d.ten}</td>
    <td>${d.soCau} câu</td>
    <td>${d.phut} phút</td>
    <td>${d.soDang} dạng</td>
    <td><a href="/ui/hoc-vien.html">Làm đề</a></td>
  </tr>`).join('')}</tbody>
</table>
</div>`;

  const than = `
<p class="eyebrow">Thư viện đề thi</p>
<h1>Đề dựng riêng cho từng người, không phải tệp đề chép sẵn</h1>
<p class="lead">Mỗi lần bấm vào một bộ đề, hệ thống dựng một đề mới: phủ đủ dạng của phạm vi,
trộn độ khó theo đúng ma trận của chặng năng lực, và loại những bài đã làm trong ba mươi ngày gần nhất.
Hai người cùng làm một bộ đề vẫn nhận hai đề khác nhau, nên không ai luyện thuộc được đáp án.</p>

<h2>Mỗi lượt thi ${SO_CAU} câu</h2>
<p class="dat">Con số ${SO_CAU} không tuỳ tiện. Đó là số nhỏ nhất chia được cho mọi tỉ lệ trong bảng dưới đây
mà không phải làm tròn, nên đề dựng ra có đúng số câu từng bậc như bảng đã in.
Lấy ít câu hơn thì phần dư phải chia tay và cấu trúc đề lệch đi so với bảng công bố.</p>

<h2>Đề trộn theo ma trận nào</h2>
<p class="dat">Tỉ lệ cố định trong từng chặng năng lực, không đổi theo từng học viên — hai người cùng tầng
nhận đề cùng cấu trúc. Nhưng tỉ lệ KHÔNG giống nhau giữa các chặng, và đó là chủ ý:
học viên lớp một không có câu thách thức nào, còn đề tuyển chọn thì phần nhận biết co lại còn một câu.
Dùng chung một ma trận cho cả mười tầng là nói dối ở cả hai đầu.</p>
<div class="khung-bang">
<table>
  <caption class="bo-qua">Ma trận độ khó theo từng chặng năng lực</caption>
  <thead><tr><th scope="col">Chặng</th><th scope="col">Tầng</th>${BAC.map((b) => `<th scope="col">${'★'.repeat(b)} ${esc(TEN_BAC[b])}</th>`).join('')}</tr></thead>
  <tbody>${CHANG.map((c) => {
    const o = Object.fromEntries(c.rows.map((r) => [r.stars, r.share]));
    return `<tr><td>${esc(c.name)}</td><td>${c.levels[0]}–${c.levels[1]}</td>`
      + BAC.map((b) => `<td>${o[b] ? `${Math.round(o[b] * SO_CAU)} câu` : '—'}</td>`).join('')
      + '</tr>';
  }).join('')}</tbody>
</table>
</div>
${CHANG.map((c) => `<p class="nho"><b>${esc(c.name)}</b> — ${esc(c.why)}</p>`).join('')}

<h2>Đề kiểm tra theo lớp</h2>
<p class="dat">Phạm vi đúng bằng chương trình của lớp đó, không lấn sang lớp trên.</p>
<div class="luoi-de">${theoLop.map((x) => `<a class="the-de l${x.n}" href="/lop/${x.n}">
  <span class="ten-de">Đề kiểm tra Toán lớp ${x.n}</span>
  <span class="so-de"><span>${x.soCau} câu</span><span>${x.phut} phút</span><span>${x.soDang} dạng</span></span>
  <span class="vao-de">Vào làm đề →</span>
</a>`).join('')}</div>

<h2>Đề chuyển cấp</h2>
${bang('Đề chuyển cấp', chuyenCap.map((x) => ({ ...x, ten: `<a href="/on-thi/${esc(x.id)}">Đề ${esc(x.c.ngan)}</a>` })))}

<h2>Đề thi cuối tầng</h2>
<p class="dat">Đây là cửa ải lên tầng, không phải bài luyện. Thi đạt vẫn chưa chắc lên tầng:
còn phải đủ cả bảy tiêu chí, và điểm thi cao không bù được tiêu chí thiếu.</p>
${bang('Đề thi cuối tầng', theoTang.map((x) => ({ ...x, ten: `<a href="/lo-trinh">Thi cuối tầng ${x.l.id} — ${esc(x.l.name)}</a>` })))}

<h2>Bốn luật ràng buộc mọi bộ đề</h2>
<ul class="tick">
  <li>Phủ đủ dạng của phạm vi. Thiếu dạng nào thì đề ghi rõ là thiếu, không lặng lẽ bỏ qua.</li>
  <li>Trộn độ khó theo ma trận ở trên, không nhặt bài ngẫu nhiên.</li>
  <li>Loại bài đã làm trong ba mươi ngày gần nhất, nếu không thì đo trí nhớ ngắn hạn chứ không đo năng lực.</li>
  <li>Giới hạn thời gian tính từ thời gian chuẩn của từng bài, cộng thêm hai mươi phần trăm.</li>
</ul>

<div class="cta"><a class="nut" href="/ui/hoc-vien.html">Vào làm một đề</a><a class="nut phu" href="/thi-thu">Tìm hiểu cách chấm</a></div>
`;

  return khung({
    tieuDe: SEO.tieuDeVua('Thư viện đề thi — đề dựng riêng theo ma trận'),
    moTa: SEO.moTaVua('Đề kiểm tra theo lớp, đề chuyển cấp và đề thi cuối tầng. Mỗi lần làm là một đề mới: phủ đủ dạng, trộn độ khó theo ma trận cố định và loại bài vừa luyện.'),
    duongDan: '/de-thi',
    vun: [{ ten: 'Trang chủ', duongDan: '/' }, { ten: 'Đề thi', duongDan: '/de-thi' }],
    than,
    nonce,
  });
}

// ── Thư viện tài liệu ──────────────────────────────────────────────────────
/**
 * Mỗi dạng bài có một PHIẾU LUYỆN tải về được, dựng ra lúc bấm tải chứ không
 * nằm sẵn dưới dạng tệp. Phiếu gồm phần cần nắm trước, bẫy thường gặp, ví dụ
 * mẫu có lời giải và bài tự luyện — tức là một tài liệu dạy được, không phải
 * một danh sách bài tập rời.
 */
function trangTaiLieu(N, { lop = null, nonce = null } = {}) {
  // Giữ luôn số lớp của mỗi nhóm để mảng màu của lớp đó phủ xuống cả khối bảng,
  // nhờ vậy người đọc lướt trang dài vẫn biết mình đang ở lớp nào.
  const nhom = new Map();
  for (const f of FORM_INDEX.values()) {
    const g = nhomCua(f.code);
    if (lop && String(lopCua(f.code)) !== String(lop)) continue;
    if (!nhom.has(g.nhan)) nhom.set(g.nhan, { lop: g.lop, cac: [] });
    nhom.get(g.nhan).cac.push(f);
  }
  let coBanVe = () => false;
  try {
    const { blueprintsForForm } = require('../content/blueprint');
    coBanVe = (ma) => blueprintsForForm(ma).length > 0;
  } catch { coBanVe = () => false; }

  const tong = [...nhom.values()].reduce((t, v) => t + v.cac.length, 0);
  const than = `
<p class="eyebrow">Thư viện tài liệu</p>
<h1>Phiếu luyện cho từng dạng bài, tải về dạy được ngay</h1>
<p class="lead">Mỗi phiếu gồm bốn phần: dạng cần nắm trước, bẫy thường gặp, ví dụ mẫu có lời giải từng bước,
và bài tự luyện. Phiếu được dựng lúc bấm tải nên lần nào cũng có bộ bài khác, dùng lại cho lớp sau vẫn được.</p>

<h2>Lọc theo lớp</h2>
<p>${[...Array(12)].map((_, i) => {
    const n = dangCuaLop(i + 1).length;
    return n ? `<a class="mon${String(lop) === String(i + 1) ? ' dang' : ''}" href="/tai-lieu?lop=${i + 1}">Lớp ${i + 1} <span class="nhan-nho">${n}</span></a>` : '';
  }).join('')}<a class="mon${!lop ? ' dang' : ''}" href="/tai-lieu">Tất cả <span class="nhan-nho">${FORM_INDEX.size}</span></a></p>
${lop ? `<p class="nho">${tong} phiếu thuộc lớp ${esc(String(lop))}.</p>` : ''}

${[...nhom.entries()].map(([ten, { lop: nLop, cac }]) => `
<section class="khoi-tl${nLop ? ` l${nLop}` : ''}">
<h2>${esc(ten)} — ${cac.length} phiếu</h2>
<div class="khung-bang">
<table>
  <caption class="bo-qua">Phiếu luyện ${esc(ten)}</caption>
  <thead><tr><th scope="col">Phiếu luyện</th><th scope="col">Mã dạng</th><th scope="col">Tầng</th><th scope="col">Tải về</th></tr></thead>
  <tbody>${cac.map((f) => `<tr>
    <td><a href="/chuong-trinh/${esc(f.code)}">Phiếu luyện — ${esc(f.name)}</a></td>
    <td><code>${esc(f.code)}</code></td>
    <td>${f.levelRange[0]}–${f.levelRange[1]}</td>
    <td>${coBanVe(f.code)
    ? `<a href="/tai-lieu/${esc(f.code)}.md">Tải phiếu</a>`
    : '<span class="nho">chưa có học liệu</span>'}</td>
  </tr>`).join('')}</tbody>
</table>
</div>
</section>`).join('')}

<h2>Trong một phiếu có gì</h2>
<div class="luoi">
  <div class="the"><span class="ma">Phần A</span><h3>Cần nắm trước</h3><p>Liệt kê đúng những dạng tiên quyết, để người dạy biết phải lấp gì nếu lớp chưa theo kịp.</p></div>
  <div class="the"><span class="ma">Phần B</span><h3>Bẫy thường gặp</h3><p>Những chỗ mất điểm đã khai sẵn trên dạng đó, nói trước để phòng chứ không đợi sai rồi sửa.</p></div>
  <div class="the"><span class="ma">Phần C</span><h3>Ví dụ mẫu</h3><p>Bài có lời giải từng bước, mỗi bài đều đã qua bộ kiểm chứng trước khi vào phiếu.</p></div>
  <div class="the"><span class="ma">Phần D</span><h3>Bài tự luyện</h3><p>Bài cùng dạng nhưng khác tham số, kèm đáp số để người học tự đối chiếu.</p></div>
</div>
`;

  return khung({
    tieuDe: SEO.tieuDeVua(lop ? `Tài liệu Toán lớp ${lop} — phiếu luyện` : 'Thư viện phiếu luyện theo dạng bài'),
    moTa: SEO.moTaVua(lop
      ? `Phiếu luyện Toán lớp ${lop} cho từng dạng bài, gồm dạng cần nắm trước, bẫy thường gặp, ví dụ mẫu có lời giải và bài tự luyện.`
      : `Thư viện ${FORM_INDEX.size} phiếu luyện theo dạng bài, mỗi phiếu gồm dạng cần nắm trước, bẫy thường gặp, ví dụ mẫu có lời giải từng bước và bài tự luyện.`),
    duongDan: lop ? `/tai-lieu?lop=${lop}` : '/tai-lieu',
    vun: [{ ten: 'Trang chủ', duongDan: '/' }, { ten: 'Tài liệu', duongDan: '/tai-lieu' }],
    than,
    nonce,
  });
}

/** Sinh phiếu luyện dạng văn bản Markdown, tải về được. */
function taiPhieu(N, ma) {
  if (!N || !N.scientist || !FORM_INDEX.has(ma)) return null;
  const p = N.scientist.phieuHocTap(ma, { soBai: 8 });
  if (!p || !p.ok) return null;
  try { return N.scientist.phieuRaChu(p); } catch { return null; }
}

/** Khung chung của mọi trang. */
function khung({ tieuDe, moTa, duongDan, than, vun = [], jsonLd = [], loai = 'website', nonce = null, mau = null }) {
  const ld = [SEO.toChuc(), ...(vun.length ? [SEO.vunDuongDan(vun)] : []), ...jsonLd];
  const n = nonce ? ` nonce="${SEO.esc(nonce)}"` : '';
  const dd = (duongDan || '/').split('?')[0];
  const dang = (d) => (dd === d || (d !== '/' && dd.startsWith(`${d}/`)) ? ' aria-current="page"' : '');
  return `<!DOCTYPE html>
<html lang="vi">
<head>
${SEO.dungHead({ tieuDe, moTa, duongDan, loai, jsonLd: ld, nonce })}
<style${n}>${CSS}</style>
</head>
<body>
<a class="bo-qua" href="#noi-dung">Bỏ qua thanh điều hướng</a>
<div class="dai-tien-ich">
  <div class="thanh">
    <span class="trai">Học tại trường · Học tại nhà · Mọi bài luyện đều được máy giải lại trước khi phát</span>
    ${cfg.WEB.lienHe ? `<a class="goi" href="${esc(cfg.WEB.lienHe.startsWith('http') || cfg.WEB.lienHe.includes('@') ? (cfg.WEB.lienHe.includes('@') ? `mailto:${cfg.WEB.lienHe}` : cfg.WEB.lienHe) : `tel:${cfg.WEB.lienHe.replace(/\s/g, '')}`)}">${esc(cfg.WEB.lienHe)}</a>` : ''}
    <a href="/cong-cu">Hướng dẫn sử dụng</a>
    <a href="/ui/giao-vien.html">Dành cho giáo viên</a>
    <a href="/ui/cong.html">Đăng nhập</a>
  </div>
</div>
<header>
  <div class="thanh">
    <a class="hieu" href="/">${DAU_HIEU}GITA<span>math</span></a>
    <nav aria-label="Thanh điều hướng chính">
      <details class="thu">
        <summary>Học Toán</summary>
        <div class="bang-thu">
          <p class="tua-thu">Theo lớp</p>
          <div class="o-lop">${[...Array(12)].map((_, i) => `<a class="l${i + 1}" href="/lop/${i + 1}">Lớp ${i + 1}</a>`).join('')}</div>
          <p class="tua-thu">Ôn thi chuyển cấp</p>
          <div class="o-them">
            <a href="/on-thi/vao-lop-6">Vào lớp 6</a>
            <a href="/on-thi/vao-lop-10">Vào lớp 10</a>
            <a href="/on-thi/danh-gia-nang-luc">Đánh giá năng lực</a>
          </div>
          <p class="tua-thu">Ngoài môn Toán</p>
          <div class="o-them">
            <a href="/chuong-trinh?nhom=X">Liên môn và tư duy</a>
            <a href="/chuong-trinh?nhom=E">Tiếng Anh</a>
            <a href="/phuong-phap">Phương pháp học</a>
          </div>
        </div>
      </details>
      <a href="/chuong-trinh"${dang('/chuong-trinh')}>Chương trình</a>
      <a href="/de-thi"${dang('/de-thi')}>Đề thi</a>
      <a href="/tai-lieu"${dang('/tai-lieu')}>Tài liệu</a>
      <a href="/thi-thu"${dang('/thi-thu')}>Thi thử</a>
      <a href="/lo-trinh"${dang('/lo-trinh')}>Lộ trình</a>
      <a href="/cong-cu"${dang('/cong-cu')}>Công cụ</a>
      <a class="chinh" href="/ui/cong.html">Vào học</a>
    </nav>
  </div>
</header>
<main id="noi-dung"${mau ? ` class="co-mau ${mau}"` : ''}>
${vun.length > 1 ? `<p class="duongmon">${vun.map((v, i) => (i === vun.length - 1
    ? `<span aria-current="page">${esc(v.ten)}</span>`
    : `<a href="${esc(v.duongDan)}">${esc(v.ten)}</a>`)).join(' › ')}</p>` : ''}
${than}
</main>
<footer>
  <div class="thanh">
    <div>
      <p><strong>${esc(cfg.WEB.tenToChuc)}</strong></p>
      <p>${esc(cfg.WEB.moTaToChuc)}</p>
      <p class="nho">Hệ thống chạy tại máy chủ của trường. Dữ liệu học của học viên không rời khỏi máy chủ đó.</p>
    </div>
    <nav aria-label="Liên kết chân trang">
      <a href="/chuong-trinh">Chương trình</a>
      <a href="/de-thi">Đề thi</a>
      <a href="/tai-lieu">Tài liệu</a>
      <a href="/thi-thu">Thi thử</a>
      <a href="/lo-trinh">Lộ trình</a>
      <a href="/phuong-phap">Phương pháp học</a>
      <a href="/cong-cu">Công cụ</a>
      <a href="/sitemap.xml">Sơ đồ trang</a>
    </nav>
    <nav aria-label="Toán theo lớp">
      ${[...Array(12)].map((_, i) => `<a class="l${i + 1}" href="/lop/${i + 1}">Toán lớp ${i + 1}</a>`).join('')}
    </nav>
  </div>
</footer>
</body>
</html>`;
}

// ── Trang chủ ──────────────────────────────────────────────────────────────

function trangChu(N, nonce = null) {
  const soDang = FORM_INDEX.size;
  const soBai = N.bank ? N.bank.items.size : 0;
  const soTang = LEVELS.length;
  const soTro = N.agents ? N.agents.length : 0;
  let soBanVe = 0;
  try { soBanVe = require('../content/blueprint').BLUEPRINTS.length; } catch { soBanVe = 0; }

  const khoi = [
    { ten: 'Lớp 1–5', gia: [...FORM_INDEX.values()].filter((f) => (lopCua(f.code) || 0) >= 1 && (lopCua(f.code) || 0) <= 5).length },
    { ten: 'Lớp 6–9', gia: [...FORM_INDEX.values()].filter((f) => (lopCua(f.code) || 0) >= 6 && (lopCua(f.code) || 0) <= 9).length },
    { ten: 'Lớp 10–12', gia: [...FORM_INDEX.values()].filter((f) => (lopCua(f.code) || 0) >= 10).length },
    { ten: 'Liên môn', gia: [...FORM_INDEX.values()].filter((f) => f.code.startsWith('X.')).length },
    { ten: 'Tiếng Anh', gia: [...FORM_INDEX.values()].filter((f) => f.code.startsWith('E.')).length },
  ];

  const hoi = [
    { hoi: 'GITA dạy theo chương trình nào?',
      dap: `Chương trình phân tầng gồm ${soDang} dạng bài từ lớp 1 đến lớp 12, thêm nhóm liên môn và nhóm tiếng Anh. Mỗi dạng gắn với ${soTang} tầng năng lực và bảy tiêu chí lên tầng.` },
    { hoi: 'Học viên được đo tiến bộ ra sao?',
      dap: 'Mỗi lần làm bài đều được ghi lại: đúng hay sai, mất bao lâu, sai vì bẫy nào. Từ đó hệ thống dựng chân dung năng lực và lộ trình chín mươi ngày cho riêng từng người.' },
    { hoi: 'Học liệu được kiểm bằng cách nào?',
      dap: 'Mỗi bài bị thay nghiệm ngược vào đề để kiểm đáp số, rồi qua thang chấm năm chiều và ba lớp chống trùng. Bài sai đáp số không vào được kho, dù trình bày đẹp đến đâu.' },
    { hoi: 'Giáo viên dùng hệ thống vào việc gì?',
      dap: 'Giáo viên xem lớp mình phụ trách, biết ai đang hổng dạng nào, giao phiếu luyện đúng chỗ yếu và duyệt học liệu trước khi đem dạy.' },
    { hoi: 'Bài giảng có sẵn hay phải tự soạn?',
      dap: 'Gõ một chủ đề là hệ thống dựng bài giảng có hình và có tiếng từ kho học liệu đã thẩm định. Người dạy vẫn duyệt lại trước khi phát cho học viên.' },
    { hoi: 'Dữ liệu học của học viên nằm ở đâu?',
      dap: 'Toàn bộ dữ liệu nằm trên máy chủ của trường. Hệ thống chạy được khi không có mạng ra ngoài, và không có phụ thuộc nào phải tải về lúc chạy.' },
  ];

  const than = `
<div class="doi mo-dau">
  <div>
    <p class="eyebrow">Học Toán có số đo</p>
    <h1>Không dạy tràn lan. Dạy đúng chỗ học viên đang vướng.</h1>
    <p class="lead">GITA chia chương trình thành ${soDang} dạng bài và ${soTang} tầng năng lực.
    Mỗi học viên đi một lộ trình riêng, tiến bộ đo bằng số liệu thật sau từng buổi, và mọi bài luyện đều bị máy giải lại trước khi đến tay người học.</p>
    <div class="cta">
      <a class="nut" href="/ui/cong.html">Vào học ngay</a>
      <a class="nut phu" href="/chuong-trinh">Xem ${soDang} dạng bài</a>
    </div>
    <p class="nho">Chạy tại máy chủ của trường · Không phụ thuộc dịch vụ bên ngoài · Đọc được khi tắt JavaScript</p>
  </div>
  ${khoiBai('M9.PT2.GIAI', { tieuDe: 'Bài dựng ngay lúc bạn mở trang', gonLoiGiai: true })}
</div>

<div class="bang-hieu">
  ${TRANH_BANG}
  <h2>Học thử miễn phí trước khi quyết định</h2>
  <p>Làm một bài chẩn đoán ngắn, hệ thống chỉ ra ngay con đang vững chỗ nào và hổng chỗ nào,
  rồi dựng lộ trình riêng. Không cần tài khoản trả phí để xem kết quả đó.</p>
  <div class="cta">
    <a class="nut" href="/ui/hoc-vien.html">Học thử ngay</a>
    <a class="nut phu" href="/lo-trinh">Xem lộ trình học</a>
  </div>
</div>

<h2>Khoá học theo lớp</h2>
<p class="dat">Chọn đúng lớp con đang học. Ba dòng trong mỗi thẻ là tên dạng bài thật của lớp đó,
lấy thẳng từ chương trình đang vận hành chứ không phải lời giới thiệu viết sẵn.</p>
<div class="luoi-lop">
${[...Array(12)].map((_, i) => theLop(i + 1)).join('')}
</div>
<p class="dat">Ngoài chương trình theo lớp còn hai nhóm dùng chung cho nhiều lớp:
<a href="/chuong-trinh?nhom=X">liên môn và tư duy</a> (${khoi[3].gia} dạng) và
<a href="/chuong-trinh?nhom=E">tiếng Anh</a> (${khoi[4].gia} dạng).</p>

<h2>Ôn thi chuyển cấp</h2>
<div class="luoi">
  <a class="the" href="/on-thi/vao-lop-6"><span class="ma">Chuyển cấp</span><h3>Ôn thi vào lớp 6</h3>
    <p>Lấy đúng phần lớp 4 và lớp 5 mà đề trường chất lượng cao hay hỏi, cộng nhóm suy luận và đọc số liệu.</p></a>
  <a class="the" href="/on-thi/vao-lop-10"><span class="ma">Chuyển cấp</span><h3>Ôn thi vào lớp 10</h3>
    <p>Tập trung lớp 9 nhưng giữ nguyên nền lớp 8, vì mọi lời giải đều dựng trên đó.</p></a>
  <a class="the" href="/on-thi/danh-gia-nang-luc"><span class="ma">Chuyển cấp</span><h3>Đánh giá năng lực</h3>
    <p>Suy luận nhiều bước, đọc biểu đồ, vận dụng công thức và biết dừng ở chỗ dữ liệu hết nói.</p></a>
  <a class="the" href="/thi-thu"><span class="ma">Thi thử</span><h3>Đề trộn dạng, tính giờ</h3>
    <p>Chấm xong không dừng ở điểm số mà chỉ rõ mất điểm ở bẫy nào và cần luyện lại dạng nào trước.</p></a>
</div>

<h2>Hệ thống đang vận hành</h2>
<div class="so-lieu">
  <div class="o-so"><b>${soDang}</b><small>dạng bài, từ lớp 1 đến lớp 12 và hai nhóm ngoài môn Toán</small></div>
  <div class="o-so"><b>${soBanVe}</b><small>bản thiết kế bài, mỗi bản nhắm đúng một bẫy</small></div>
  <div class="o-so"><b>${soTang}</b><small>tầng năng lực, bảy tiêu chí lên tầng không bù trừ</small></div>
  <div class="o-so"><b>${soTro}</b><small>trợ lý AI chuyên môn làm việc theo tổ</small></div>
</div>

<h2>Chương trình trải đủ cấp học</h2>
<p class="dat">Không dừng ở một cấp rồi bỏ ngỏ phần còn lại. Đây là số dạng bài thật của từng khối,
đếm ngay trong lúc dựng trang này.</p>
${bieuDoCot(khoi, { nhan: `Số dạng bài theo khối: ${khoi.map((k) => `${k.ten} ${k.gia}`).join(', ')}` })}

<h2>Ba nhóm người dùng, ba việc khác nhau</h2>
<div class="luoi">
  <div class="the">
    <h3>Học viên</h3>
    <p>Làm bài đúng sức mình, thấy rõ mình đang ở tầng nào và còn thiếu gì để lên tầng. Sai ở đâu được chỉ ngay bẫy ở đó.</p>
    <p><a href="/lo-trinh">Xem lộ trình chín mươi ngày →</a></p>
  </div>
  <div class="the">
    <h3>Giáo viên</h3>
    <p>Nhìn được cả lớp trong một màn hình: ai đang hổng dạng nào, ai cần kèm trước. Giao phiếu luyện đúng chỗ yếu thay vì giao đại trà.</p>
    <p><a href="/cong-cu">Xem bộ công cụ dạy học →</a></p>
  </div>
  <div class="the">
    <h3>Nhà trường</h3>
    <p>Báo cáo theo lớp và theo khối dựng từ dữ liệu học thật, không phải từ bảng tổng hợp chép tay. Dữ liệu ở lại trên máy chủ của trường.</p>
    <p><a href="/chuong-trinh">Xem khung chương trình →</a></p>
  </div>
</div>

<h2>Bốn điều hệ thống làm khác</h2>
<div class="luoi">
  <div class="the nhan"><h3>Học liệu bị máy giải lại</h3>
    <p>Mỗi bài luyện đều bị thay nghiệm ngược vào đề để kiểm đáp số. Bài sai đáp số không vào được kho, dù trình bày đẹp đến đâu.</p></div>
  <div class="the"><h3>Ký hiệu toán đúng chuẩn quốc tế</h3>
    <p>Công thức hiện đúng ký hiệu của sách giáo khoa, và đọc lên thành lời cũng đúng như vậy. Bộ dựng công thức do chính hệ thống viết, chạy ngay tại máy chủ.</p></div>
  <div class="the"><h3>Tiếng Việt đúng chuẩn sư phạm</h3>
    <p>Học liệu được soát chính tả theo luật cấu tạo âm tiết, soát độ dài câu theo lớp và soát từ vựng xem có vượt quá chương trình của lớp đó không.</p></div>
  <div class="the"><h3>Đo tiến bộ, không đo lượt bấm</h3>
    <p>Hệ thống ghi từng thao tác, từng lỗi sai và thời gian làm bài, rồi dịch chuyển lộ trình theo đúng chỗ học viên đang vướng.</p></div>
</div>

<h2>Nghe thử giọng phát âm tiếng Anh</h2>
<p class="dat">Tiếng đọc dưới đây do máy chủ dựng ngay lúc bạn bấm, không phải tệp thu sẵn.
Người Việt hay mất thế đối lập dài và ngắn giữa hai âm này, nên hệ thống đưa thẳng cặp từ ra để tai so sánh.</p>
<div class="nghe">
  ${['sheep', 'ship', 'beat', 'bit'].map(oNghe).join('')}
</div>
<p class="nho">Hệ thống còn chỉ ra trước những chỗ người Việt sẽ đọc sai của bất kỳ từ nào: âm cuối bị nuốt, cụm phụ âm bị chèn thêm nguyên âm, trọng âm đọc đều tăm tắp.</p>

<h2>Câu hỏi thường gặp</h2>
${hoi.map((q) => `<details class="hoi-dap"><summary>${esc(q.hoi)}</summary><p class="dap">${esc(q.dap)}</p></details>`).join('\n')}

<h2>Bắt đầu</h2>
<p class="dat">Học viên mới làm một bài chẩn đoán đầu vào để hệ thống xác định tầng hiện tại, rồi nhận lộ trình riêng ngay sau đó.</p>
<div class="cta"><a class="nut" href="/ui/cong.html">Vào học ngay</a><a class="nut phu" href="/lo-trinh">Tìm hiểu lộ trình</a></div>
`;

  return khung({
    tieuDe: SEO.tieuDeVua('Học Toán theo lộ trình, đo được tiến bộ từng tuần'),
    moTa: SEO.moTaVua(`Chương trình Toán phổ thông chia thành ${soDang} dạng bài và ${soTang} tầng năng lực. `
      + 'Học liệu qua xác minh toán học, lộ trình riêng cho từng học viên.'),
    duongDan: '/',
    vun: [{ ten: 'Trang chủ', duongDan: '/' }],
    jsonLd: [SEO.trangGoc(), SEO.hoiDap(hoi)],
    than,
    nonce,
  });
}

// ── Danh mục chương trình ──────────────────────────────────────────────────

function trangChuongTrinh(N, { tim = '', lop = null, nhom = null, nonce = null } = {}) {
  const q = khongDau(tim).trim();
  let ds = [...FORM_INDEX.values()];
  if (lop) ds = ds.filter((f) => lopCua(f.code) === Number(lop));
  if (nhom === 'E') ds = ds.filter((f) => f.code.startsWith('E.'));
  if (nhom === 'X') ds = ds.filter((f) => f.code.startsWith('X.'));
  if (q) ds = ds.filter((f) => khongDau(f.name).includes(q) || khongDau(f.code).includes(q));
  ds.sort((a, b) => ((lopCua(a.code) || 99) - (lopCua(b.code) || 99)) || a.code.localeCompare(b.code));

  const theoNhom = new Map();
  for (const f of ds) {
    const k = nhomCua(f.code).nhan;
    if (!theoNhom.has(k)) theoNhom.set(k, []);
    theoNhom.get(k).push(f);
  }

  const dem = (loc) => [...FORM_INDEX.values()].filter(loc).length;
  const than = `
<h1>Chương trình: ${FORM_INDEX.size} dạng bài</h1>
<p class="lead">Mỗi dạng bài là một kỹ năng cụ thể, có điều kiện cần nắm trước, có bẫy thường gặp và có thời gian làm bài chuẩn.
Bấm vào từng dạng để xem yêu cầu, một bài mẫu thật và lối vào luyện tập.</p>

<h2>Lọc nhanh</h2>
<p>${[...Array(12)].map((_, i) => {
    const n = dem((f) => lopCua(f.code) === i + 1);
    return n ? `<a class="mon${Number(lop) === i + 1 ? ' dang' : ''}" href="/chuong-trinh?lop=${i + 1}">Lớp ${i + 1} <span class="nhan-nho">${n}</span></a>` : '';
  }).join('')}
<a class="mon${nhom === 'X' ? ' dang' : ''}" href="/chuong-trinh?nhom=X">Liên môn <span class="nhan-nho">${dem((f) => f.code.startsWith('X.'))}</span></a>
<a class="mon${nhom === 'E' ? ' dang' : ''}" href="/chuong-trinh?nhom=E">Tiếng Anh <span class="nhan-nho">${dem((f) => f.code.startsWith('E.'))}</span></a>
<a class="mon${!lop && !nhom ? ' dang' : ''}" href="/chuong-trinh">Tất cả <span class="nhan-nho">${FORM_INDEX.size}</span></a></p>

${lop || nhom || q ? `<p class="nho">${ds.length} dạng khớp điều kiện đang lọc.</p>` : ''}

${[...theoNhom.entries()].map(([ten, cac]) => `
<h2>${esc(ten)} — ${cac.length} dạng bài</h2>
<div class="khung-bang">
<table>
  <caption class="bo-qua">Danh sách dạng bài ${esc(ten)}</caption>
  <thead><tr><th scope="col">Mã dạng</th><th scope="col">Tên dạng</th><th scope="col">Tầng</th><th scope="col">Bẫy nhắm tới</th></tr></thead>
  <tbody>
  ${cac.map((f) => `<tr>
    <td><a href="/chuong-trinh/${esc(f.code)}"><code>${esc(f.code)}</code></a></td>
    <td><a href="/chuong-trinh/${esc(f.code)}">${esc(f.name)}</a></td>
    <td>${f.levelRange ? `${f.levelRange[0]}–${f.levelRange[1]}` : '—'}</td>
    <td>${esc(hoaDau((f.traps || [])[0] || 'chưa khai'))}</td>
  </tr>`).join('')}
  </tbody>
</table>
</div>`).join('')}
`;

  const ten = lop ? `Toán lớp ${lop}` : nhom === 'E' ? 'Tiếng Anh' : nhom === 'X' ? 'Liên môn và tư duy' : null;
  return khung({
    tieuDe: SEO.tieuDeVua(ten ? `${ten} — danh mục dạng bài` : `Chương trình học ${FORM_INDEX.size} dạng bài`),
    moTa: SEO.moTaVua(ten
      ? `Danh mục dạng bài ${ten} theo chương trình phân tầng GITA, kèm bẫy thường gặp và điều kiện cần nắm trước của từng dạng.`
      : `Toàn bộ ${FORM_INDEX.size} dạng bài từ lớp 1 đến lớp 12 cùng nhóm liên môn và nhóm tiếng Anh, phân theo ${LEVELS.length} tầng năng lực.`),
    duongDan: lop ? `/chuong-trinh?lop=${lop}` : nhom ? `/chuong-trinh?nhom=${nhom}` : '/chuong-trinh',
    vun: [{ ten: 'Trang chủ', duongDan: '/' }, { ten: 'Chương trình', duongDan: '/chuong-trinh' }],
    than,
    nonce,
  });
}

// ── Trang một dạng bài ─────────────────────────────────────────────────────

function trangDang(N, ma, nonce = null) {
  const f = FORM_INDEX.get(ma);
  if (!f) return null;
  const g = nhomCua(f.code);
  const truoc = (f.prereq || []).map((c) => FORM_INDEX.get(c)).filter(Boolean);
  const sau = [...FORM_INDEX.values()].filter((x) => (x.prereq || []).includes(f.code));
  const cungNhom = [...FORM_INDEX.values()].filter((x) => nhomCua(x.code).nhan === g.nhan && x.code !== f.code).slice(0, 8);
  const soBai = N.bank ? N.bank.query({ formCode: f.code, limit: 500 }).length : 0;
  const tang = f.levelRange ? `${f.levelRange[0]}–${f.levelRange[1]}` : '—';
  const mau = mauBai(f.code);

  const than = `
<p class="eyebrow">${esc(g.nhan)}</p>
<h1>${esc(f.name)}</h1>
<p class="lead">Dạng bài <code>${esc(f.code)}</code> nằm ở tầng ${tang} trong thang ${LEVELS.length} tầng năng lực.
Thời gian làm bài chuẩn là ${f.norm} giây cho một bài.</p>

<p>
  <span class="nhan-nho">${esc(g.nhan)}</span>
  <span class="nhan-nho">Tầng ${tang}</span>
  <span class="nhan-nho">${f.norm} giây một bài</span>
  ${(f.traps || []).length ? `<span class="nhan-nho bay">${f.traps.length} bẫy đã khai</span>` : ''}
  ${soBai ? `<span class="nhan-nho xong">${soBai} bài trong kho</span>` : ''}
</p>

${mau ? `<h2>Một bài mẫu của dạng này</h2>
<p class="dat">Bài dưới đây dựng thẳng từ bản thiết kế và được bộ kiểm chứng giải lại ngay trong lúc trang này hiện ra.
Đây là bài thật, không phải ảnh chụp màn hình.</p>
${khoiBai(f.code, { tieuDe: 'Dựng và kiểm ngay lúc mở trang' })}` : ''}

${truoc.length ? `<h2>Cần nắm trước</h2>
<p>Học viên nên thành thạo các dạng dưới đây rồi mới vào dạng này, vì mỗi dạng trước là một bước trong lời giải của dạng này.</p>
<div class="luoi">${truoc.map((p) => `<a class="the" href="/chuong-trinh/${esc(p.code)}"><span class="ma">${esc(p.code)}</span><h3>${esc(p.name)}</h3><p class="nho">${esc(nhomCua(p.code).nhan)}</p></a>`).join('')}</div>`
    : '<h2>Cần nắm trước</h2><p>Đây là dạng nền, không đòi hỏi dạng nào trước đó.</p>'}

${(f.traps || []).length ? `<h2>Bẫy thường gặp</h2>
<p>Đây là những chỗ học viên hay mất điểm nhất ở dạng này. Hệ thống ghi lại từng lần học viên mắc bẫy nào để luyện lại đúng chỗ đó.</p>
<div class="luoi">${f.traps.map((t, i) => `<div class="the"><span class="ma">Bẫy ${i + 1}</span><h3>${esc(hoaDau(t))}</h3></div>`).join('')}</div>` : ''}

<h2>Yêu cầu lên tầng</h2>
<p>Muốn được công nhận thành thạo dạng này, học viên phải đạt đủ bảy tiêu chí của tầng đang xét, chứ không chỉ làm đúng một vài bài.</p>
<div class="khung-bang">
<table>
  <caption class="bo-qua">Chuẩn lên tầng áp dụng cho dạng ${esc(f.code)}</caption>
  <thead><tr><th scope="col">Tầng</th><th scope="col">Tên tầng</th><th scope="col">Tỉ lệ đúng</th><th scope="col">Số bài tối thiểu</th></tr></thead>
  <tbody>${LEVEL_STANDARDS.filter((s) => !f.levelRange || (s.level >= f.levelRange[0] && s.level <= f.levelRange[1]))
    .map((s) => `<tr><td>${s.level}</td><td>${esc(s.name)}</td><td>${Math.round(s.accuracy * 100)}%</td><td>${s.minItemsPerForm}</td></tr>`).join('')}</tbody>
</table>
</div>

${sau.length ? `<h2>Dạng học tiếp theo</h2>
<div class="luoi">${sau.map((p) => `<a class="the" href="/chuong-trinh/${esc(p.code)}"><span class="ma">${esc(p.code)}</span><h3>${esc(p.name)}</h3><p class="nho">${esc(nhomCua(p.code).nhan)}</p></a>`).join('')}</div>` : ''}

${cungNhom.length ? `<h2>Dạng khác cùng nhóm</h2>
<p>${cungNhom.map((p) => `<a class="mon" href="/chuong-trinh/${esc(p.code)}">${esc(p.name)}</a>`).join('')}</p>` : ''}

<h2>Luyện dạng này</h2>
<div class="cta"><a class="nut" href="/ui/hoc-vien.html">Vào luyện tập</a><a class="nut phu" href="${esc(g.loc)}">Xem cả ${esc(g.tenLoc.toLocaleLowerCase('vi'))}</a></div>
`;

  const moTa = `${f.name} — dạng bài ${f.code} thuộc ${g.nhan}. `
    + `${(f.traps || []).length ? `${f.traps.length} bẫy thường gặp, ` : ''}thời gian chuẩn ${f.norm} giây một bài, `
    + `tầng ${tang} trong thang ${LEVELS.length} tầng năng lực.`;

  return khung({
    tieuDe: SEO.tieuDeVua(`${f.name} — ${g.nhan}`),
    moTa: SEO.moTaVua(moTa),
    duongDan: `/chuong-trinh/${f.code}`,
    loai: 'article',
    vun: [
      { ten: 'Trang chủ', duongDan: '/' },
      { ten: 'Chương trình', duongDan: '/chuong-trinh' },
      { ten: g.tenLoc, duongDan: g.loc },
      { ten: f.name, duongDan: `/chuong-trinh/${f.code}` },
    ],
    jsonLd: [SEO.khoaHoc({ ma: f.code, ten: f.name, moTa, duongDan: `/chuong-trinh/${f.code}`, capDo: g.nhan })],
    than,
    nonce,
  });
}

// ── Lộ trình ───────────────────────────────────────────────────────────────

function trangLoTrinh(nonce = null) {
  const demTang = (id) => [...FORM_INDEX.values()].filter((f) => f.levelRange && id >= f.levelRange[0] && id <= f.levelRange[1]).length;
  const than = `
<p class="eyebrow">Đi theo tầng, không đi theo bài</p>
<h1>Lộ trình học: ${LEVELS.length} tầng năng lực và chu kỳ chín mươi ngày</h1>
<p class="lead">Học viên không đi theo bài, mà đi theo tầng. Mỗi tầng có chuẩn riêng, và chỉ được lên tầng khi đủ cả bảy tiêu chí.
Cứ chín mươi ngày, hệ thống tổng kết một chu kỳ và dựng lại lộ trình theo số liệu của chính chu kỳ đó.</p>

<h2>Thang ${LEVELS.length} tầng</h2>
<p class="dat">Con số bên phải là số dạng bài có mặt ở tầng đó — đếm ngay trong lúc dựng trang này.</p>
<div class="thang">
${LEVELS.map((l) => {
    const s = LEVEL_STANDARDS.find((x) => x.level === l.id);
    return `<div class="bac">
    <span class="ma-tang">${esc(l.code)}</span>
    <span><b>${esc(l.name)}</b><span class="mo-ta">${esc(l.desc)}</span></span>
    <span class="dem">${demTang(l.id)} dạng${s ? ` · cần ${Math.round(s.accuracy * 100)}% đúng` : ''}</span>
  </div>`;
  }).join('')}
</div>

<h2>Bảy tiêu chí lên tầng</h2>
<p class="dat">Bảy tiêu chí cùng phải đạt, không bù trừ cho nhau. Làm đúng nhiều mà chậm thì chưa lên tầng; nhanh mà không ổn định qua nhiều buổi cũng chưa lên tầng.</p>
<div class="luoi">
  <div class="the"><span class="ma">Tiêu chí 1</span><h3>Mức thành thạo</h3><p>Ước lượng năng lực trên từng dạng, cập nhật sau mỗi lần làm bài.</p></div>
  <div class="the"><span class="ma">Tiêu chí 2</span><h3>Tỉ lệ đúng</h3><p>Tính trên cửa sổ những bài gần nhất, không tính cả quá trình học từ đầu.</p></div>
  <div class="the"><span class="ma">Tiêu chí 3</span><h3>Tốc độ</h3><p>So với thời gian chuẩn của chính dạng đó, không so với người khác.</p></div>
  <div class="the"><span class="ma">Tiêu chí 4</span><h3>Độ ổn định</h3><p>Phải giữ được phong độ qua nhiều buổi liên tiếp, không phải một buổi may mắn.</p></div>
  <div class="the"><span class="ma">Tiêu chí 5</span><h3>Độ phủ</h3><p>Đã chạm đủ các dạng của tầng, không bỏ trống dạng nào.</p></div>
  <div class="the"><span class="ma">Tiêu chí 6</span><h3>Bài thi cuối tầng</h3><p>Làm trong điều kiện thi thật, có giới hạn thời gian và không có gợi ý.</p></div>
  <div class="the"><span class="ma">Tiêu chí 7</span><h3>Không tụt lại</h3><p>Dạng đã thành thạo phải giữ được, hệ thống kiểm tra lại theo chu kỳ.</p></div>
</div>

<h2>Chu kỳ chín mươi ngày</h2>
<div class="luoi">
  <div class="the"><span class="ma">Ngày 1 đến 30</span><h3>Lấp lỗ hổng nền tảng</h3><p>Quay lại đúng những dạng tiên quyết còn yếu. Không học dạng mới khi nền chưa vững.</p></div>
  <div class="the"><span class="ma">Ngày 31 đến 60</span><h3>Mở rộng cách nghĩ</h3><p>Làm bài nhiều bước, bài có bẫy, và bài đòi chọn được cách giải ngắn nhất.</p></div>
  <div class="the"><span class="ma">Ngày 61 đến 90</span><h3>Luyện trong điều kiện thi</h3><p>Đề trộn dạng, tính giờ, và đối chiếu số liệu đầu chu kỳ với cuối chu kỳ.</p></div>
</div>

<h2>Bắt đầu từ đâu</h2>
<p class="dat">Học viên mới làm một bài chẩn đoán đầu vào để hệ thống xác định tầng hiện tại, rồi nhận lộ trình riêng ngay sau đó.</p>
<div class="cta"><a class="nut" href="/ui/hoc-vien.html">Làm bài chẩn đoán</a><a class="nut phu" href="/chuong-trinh">Xem chương trình</a></div>
`;
  return khung({
    tieuDe: SEO.tieuDeVua(`Lộ trình học ${LEVELS.length} tầng và chu kỳ 90 ngày`),
    moTa: SEO.moTaVua(`Thang ${LEVELS.length} tầng năng lực, bảy tiêu chí lên tầng không bù trừ cho nhau, và chu kỳ chín mươi ngày dựng lại lộ trình theo số liệu học thật của từng học viên.`),
    duongDan: '/lo-trinh',
    vun: [{ ten: 'Trang chủ', duongDan: '/' }, { ten: 'Lộ trình', duongDan: '/lo-trinh' }],
    than,
    nonce,
  });
}

// ── Phương pháp học ────────────────────────────────────────────────────────

function trangPhuongPhap(nonce = null) {
  const nhom = new Map();
  for (const [id, p] of Object.entries(PHUONG_PHAP)) {
    if (!nhom.has(p.nhom)) nhom.set(p.nhom, []);
    nhom.get(p.nhom).push({ id, ...p });
  }
  const than = `
<p class="eyebrow">Thư viện phương pháp</p>
<h1>${Object.keys(PHUONG_PHAP).length} phương pháp học Toán</h1>
<p class="lead">Mỗi phương pháp giải quyết một khó khăn cụ thể. Hệ thống ghép phương pháp theo đúng điều học viên đang vướng, chứ không phát cùng một lời khuyên cho tất cả.</p>
${[...nhom.entries()].map(([ten, cac]) => `
<h2>${esc(ten)} — ${cac.length} phương pháp</h2>
<div class="luoi">${cac.map((p) => `<a class="the" href="/phuong-phap/${esc(p.id)}"><h3>${esc(p.ten)}</h3><p>${esc(p.moTa)}</p></a>`).join('')}</div>`).join('')}

<h2>Ghép phương pháp cho trường hợp của mình</h2>
<p class="dat">Mô tả bằng lời của chính học viên, hệ thống chỉ ra phương pháp khớp với dấu hiệu đó và kế hoạch áp dụng theo tuần.</p>
<div class="cta"><a class="nut" href="/ui/khoa-hoc-toan.html">Mở bàn làm việc Toán</a></div>
`;
  return khung({
    tieuDe: SEO.tieuDeVua(`${Object.keys(PHUONG_PHAP).length} phương pháp học Toán hiệu quả`),
    moTa: SEO.moTaVua(`Thư viện ${Object.keys(PHUONG_PHAP).length} phương pháp học Toán chia theo sáu nhóm: đọc hiểu đề, tư duy, ghi nhớ, luyện tập, kiểm tra và tự học.`),
    duongDan: '/phuong-phap',
    vun: [{ ten: 'Trang chủ', duongDan: '/' }, { ten: 'Phương pháp học', duongDan: '/phuong-phap' }],
    than,
    nonce,
  });
}

function trangMotPhuongPhap(id, nonce = null) {
  const p = PHUONG_PHAP[id];
  if (!p) return null;
  const cungNhom = Object.entries(PHUONG_PHAP).filter(([k, v]) => v.nhom === p.nhom && k !== id);
  const than = `
<p class="eyebrow">Nhóm ${esc(p.nhom)}</p>
<h1>${esc(p.ten)}</h1>
<p class="lead">${esc(p.moTa)}</p>

<h2>Dùng khi nào</h2>
<p class="dat">Phương pháp này khớp với những dấu hiệu sau, lấy đúng theo cách học viên thường mô tả khó khăn của mình.</p>
<ul class="tick">${p.dau.map((d) => `<li>${esc(hoaDau(d))}</li>`).join('')}</ul>

<h2>Cách áp dụng</h2>
<div class="luoi">
  <div class="the"><span class="ma">Tuần đầu</span><h3>Làm đều mỗi ngày</h3><p>Giữ nhịp ngắn và đều, mỗi buổi một lượng nhỏ, hơn là dồn vào một buổi dài.</p></div>
  <div class="the"><span class="ma">Sau đó</span><h3>Ôn theo chu kỳ</h3><p>Nhắc lại sau một, ba, bảy, mười bốn và ba mươi ngày, đúng lúc trí nhớ sắp mờ đi.</p></div>
  <div class="the"><span class="ma">Mỗi buổi</span><h3>Ghi lại kết quả</h3><p>Ghi số bài đúng và thời gian làm, để biết phương pháp có thật sự giúp hay không.</p></div>
</div>

${cungNhom.length ? `<h2>Phương pháp khác cùng nhóm</h2>
<div class="luoi">${cungNhom.map(([k, v]) => `<a class="the" href="/phuong-phap/${esc(k)}"><h3>${esc(v.ten)}</h3><p>${esc(v.moTa)}</p></a>`).join('')}</div>` : ''}
<div class="cta"><a class="nut phu" href="/phuong-phap">Xem toàn bộ phương pháp</a></div>
`;
  const moTa = `${p.ten}: ${p.moTa} Phương pháp thuộc nhóm ${p.nhom}, dùng khi học viên gặp dấu hiệu ${p.dau.slice(0, 2).join(', ')}.`;
  return khung({
    tieuDe: SEO.tieuDeVua(`${p.ten} — phương pháp học Toán`),
    moTa: SEO.moTaVua(moTa),
    duongDan: `/phuong-phap/${id}`,
    loai: 'article',
    vun: [{ ten: 'Trang chủ', duongDan: '/' }, { ten: 'Phương pháp học', duongDan: '/phuong-phap' }, { ten: p.ten, duongDan: `/phuong-phap/${id}` }],
    than,
    nonce,
  });
}

// ── Công cụ ────────────────────────────────────────────────────────────────

function trangCongCu(nonce = null) {
  const than = `
<p class="eyebrow">Chạy tại máy trường</p>
<h1>Bộ công cụ dạy và học</h1>
<p class="lead">Năm công cụ chạy thẳng trên máy chủ của trường, không gửi dữ liệu ra ngoài và không tính phí theo lượt dùng.</p>

<div class="luoi hai">
  <div class="the">
    <span class="ma">Công cụ 1</span>
    <h3>Xưởng bài giảng</h3>
    <p>Gõ một chủ đề, nhận về một tệp video có hình và có tiếng, dựng từ học liệu đã thẩm định.
    Bài giảng kèm mốc thời gian từng đoạn để người dạy cắt ghép lại theo ý mình.</p>
    <p><a href="/ui/bai-giang.html">Mở xưởng bài giảng →</a></p>
  </div>
  <div class="the">
    <span class="ma">Công cụ 2</span>
    <h3>Bàn làm việc Toán</h3>
    <p>Giải phương trình và trình bày theo đúng lối sách giáo khoa, kèm bảng thẩm định bốn cấp: ký hiệu, văn phong, cấu trúc và đáp số.
    Mỗi bài giải đều bị thay nghiệm ngược vào đề để kiểm.</p>
    <p><a href="/ui/khoa-hoc-toan.html">Mở bàn làm việc Toán →</a></p>
  </div>
  <div class="the">
    <span class="ma">Công cụ 3</span>
    <h3>Soát tiếng Việt cho học liệu</h3>
    <p>Soát chính tả theo luật cấu tạo âm tiết, soát độ dài câu theo lớp và soát từ vựng xem có vượt chương trình của lớp đó không.
    Dùng trước khi đưa bất kỳ đề bài nào vào kho.</p>
    <p><a href="/ui/tieng-viet.html">Mở bàn soát tiếng Việt →</a></p>
  </div>
  <div class="the">
    <span class="ma">Công cụ 4</span>
    <h3>Bàn phát âm tiếng Anh</h3>
    <p>Phiên âm một từ hoặc cả câu theo bảng ký hiệu ngữ âm quốc tế, chỉ ra trọng âm và chỗ nối âm,
    rồi dự báo trước những chỗ người Việt sẽ đọc sai kèm cách sửa.</p>
    <p><a href="/ui/cong.html">Vào cổng công cụ →</a></p>
  </div>
  <div class="the">
    <span class="ma">Công cụ 5</span>
    <h3>Trung tâm chỉ huy</h3>
    <p>Dành cho quản trị: điều phối các tổ trợ lý AI chuyên môn, theo dõi công suất, kiểm tra nhật ký và khôi phục hệ thống khi có sự cố.</p>
    <p><a href="/ui/index.html">Mở trung tâm chỉ huy →</a></p>
  </div>
</div>

<h2>Điều kiện chạy</h2>
<ul class="tick">
  <li>Chỉ cần một máy chủ cài sẵn môi trường chạy JavaScript, không cần cơ sở dữ liệu riêng.</li>
  <li>Không có phụ thuộc nào phải tải về lúc chạy, nên cài được cả trong mạng nội bộ không ra ngoài.</li>
  <li>Kết quả tất định: cùng một dữ liệu vào thì cho đúng cùng một kết quả ra, tiện cho việc kiểm tra lại.</li>
</ul>
`;
  return khung({
    tieuDe: SEO.tieuDeVua('Bộ công cụ dạy và học chạy tại máy trường'),
    moTa: SEO.moTaVua('Xưởng bài giảng dựng video có tiếng, bàn làm việc Toán trình bày chuẩn sách giáo khoa, bàn soát tiếng Việt, bàn phát âm tiếng Anh và trung tâm chỉ huy dành cho quản trị.'),
    duongDan: '/cong-cu',
    vun: [{ ten: 'Trang chủ', duongDan: '/' }, { ten: 'Công cụ', duongDan: '/cong-cu' }],
    than,
    nonce,
  });
}

// ── Trang không tìm thấy ───────────────────────────────────────────────────

function trangKhongCo(duongDan, nonce = null) {
  const than = `
<p class="eyebrow">Lỗi 404</p>
<h1>Không tìm thấy trang này</h1>
<p class="lead">Đường dẫn <code>${esc(duongDan)}</code> không có trong hệ thống. Có thể trang đã đổi địa chỉ, hoặc đường dẫn bị gõ thiếu một phần.</p>

<h2>Những lối đi thường dùng</h2>
<div class="luoi">
  <a class="the" href="/"><h3>Trang chủ</h3><p>Tổng quan hệ thống và một bài mẫu dựng ngay tại chỗ.</p></a>
  <a class="the" href="/chuong-trinh"><h3>Chương trình</h3><p>Danh mục ${FORM_INDEX.size} dạng bài, lọc được theo lớp và theo nhóm.</p></a>
  <a class="the" href="/lo-trinh"><h3>Lộ trình</h3><p>Thang ${LEVELS.length} tầng và chu kỳ chín mươi ngày.</p></a>
  <a class="the" href="/phuong-phap"><h3>Phương pháp học</h3><p>Thư viện phương pháp ghép theo đúng khó khăn đang gặp.</p></a>
  <a class="the" href="/cong-cu"><h3>Công cụ</h3><p>Bộ công cụ dạy và học chạy tại máy chủ của trường.</p></a>
</div>
<p>Nếu đường dẫn này do một trang khác dẫn tới, xin báo lại để chúng tôi sửa liên kết.</p>
`;
  return khung({
    tieuDe: SEO.tieuDeVua('Không tìm thấy trang'),
    moTa: SEO.moTaVua('Đường dẫn không có trong hệ thống. Xem danh mục chương trình, lộ trình học và bộ công cụ dạy học của GITAV20nexus tại các liên kết bên dưới.'),
    duongDan,
    vun: [{ ten: 'Trang chủ', duongDan: '/' }],
    than,
    nonce,
  });
}

// ── Sơ đồ trang và luật thu thập ───────────────────────────────────────────

/** Mọi đường dẫn công khai — nguồn duy nhất cho sitemap và cho bộ kiểm định. */
function moiDuongDan() {
  const ra = ['/', '/chuong-trinh', '/de-thi', '/tai-lieu', '/thi-thu', '/lo-trinh', '/phuong-phap', '/cong-cu'];
  for (let l = 1; l <= 12; l++) ra.push(`/lop/${l}`);
  for (const id of Object.keys(ON_THI)) ra.push(`/on-thi/${id}`);
  for (let l = 1; l <= 12; l++) ra.push(`/tai-lieu?lop=${l}`);
  for (let l = 1; l <= 12; l++) ra.push(`/chuong-trinh?lop=${l}`);
  for (const n of ['X', 'E']) ra.push(`/chuong-trinh?nhom=${n}`);
  for (const f of FORM_INDEX.values()) ra.push(`/chuong-trinh/${f.code}`);
  for (const id of Object.keys(PHUONG_PHAP)) ra.push(`/phuong-phap/${id}`);
  return ra;
}

function sitemap() {
  const ngay = new Date().toISOString().slice(0, 10);
  const uuTien = (d) => (d === '/' ? '1.0' : d.split('/').length <= 2 ? '0.8' : '0.6');
  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${moiDuongDan().map((d) => `  <url><loc>${esc(SEO.tuyetDoi(d))}</loc><lastmod>${ngay}</lastmod><changefreq>weekly</changefreq><priority>${uuTien(d)}</priority></url>`).join('\n')}
</urlset>`;
}

/**
 * Tệp mô tả ứng dụng — cho phép cài trang lên màn hình chính của điện thoại.
 * Không có tệp này thì trang chỉ là một địa chỉ trong trình duyệt.
 */
function manifest() {
  return JSON.stringify({
    name: `${cfg.WEB.tenToChuc} — học Toán theo lộ trình`,
    short_name: cfg.WEB.tenToChuc,
    description: cfg.WEB.moTaToChuc,
    lang: 'vi',
    start_url: '/',
    scope: '/',
    display: 'standalone',
    orientation: 'portrait-primary',
    background_color: '#0d1117',
    theme_color: '#0d1117',
    icons: [{ src: '/ui/icon.png', sizes: '512x512', type: 'image/png', purpose: 'any maskable' }],
    shortcuts: [
      { name: 'Chương trình', url: '/chuong-trinh' },
      { name: 'Hành trình của tôi', url: '/ui/hanh-trinh.html' },
      { name: 'Bàn làm việc Toán', url: '/ui/khoa-hoc-toan.html' },
    ],
  }, null, 2);
}

function robots() {
  return `User-agent: *
Allow: /
Disallow: /ui/index.html
Disallow: /superadmin
Disallow: /recovery

Sitemap: ${SEO.tuyetDoi('/sitemap.xml')}
`;
}

/**
 * Bộ định tuyến trang công khai. Trả về null nếu đường dẫn không thuộc về
 * trang công khai, để lớp HTTP đi tiếp xuống API và giao diện ứng dụng.
 */
function dinhTuyen(N, duongDan, truyVan = {}, nonce = null) {
  const d = duongDan.replace(/\/+$/, '') || '/';
  if (d === '/') return { html: trangChu(N, nonce) };
  if (d === '/chuong-trinh') {
    return { html: trangChuongTrinh(N, { tim: truyVan.tim || '', lop: truyVan.lop || null, nhom: truyVan.nhom || null, nonce }) };
  }
  if (d.startsWith('/chuong-trinh/')) {
    const html = trangDang(N, decodeURIComponent(d.slice('/chuong-trinh/'.length)), nonce);
    return html ? { html } : null;
  }
  if (d.startsWith('/lop/')) {
    const html = trangLop(d.slice('/lop/'.length), nonce);
    return html ? { html } : null;
  }
  if (d.startsWith('/on-thi/')) {
    const html = trangOnThi(decodeURIComponent(d.slice('/on-thi/'.length)), nonce);
    return html ? { html } : null;
  }
  if (d === '/thi-thu') return { html: trangThiThu(nonce) };
  if (d === '/de-thi') return { html: trangDeThi(nonce) };
  if (d === '/tai-lieu') return { html: trangTaiLieu(N, { lop: truyVan.lop || null, nonce }) };
  if (d.startsWith('/tai-lieu/') && d.endsWith('.md')) {
    // Phiếu luyện dựng ra lúc bấm tải, không phải tệp nằm sẵn trên đĩa.
    const ma = decodeURIComponent(d.slice('/tai-lieu/'.length, -3));
    const chu = taiPhieu(N, ma);
    return chu ? { raw: chu, kieu: 'text/markdown; charset=utf-8' } : null;
  }
  if (d === '/lo-trinh') return { html: trangLoTrinh(nonce) };
  if (d === '/phuong-phap') return { html: trangPhuongPhap(nonce) };
  if (d.startsWith('/phuong-phap/')) {
    const html = trangMotPhuongPhap(decodeURIComponent(d.slice('/phuong-phap/'.length)), nonce);
    return html ? { html } : null;
  }
  if (d === '/cong-cu') return { html: trangCongCu(nonce) };
  if (d === '/sitemap.xml') return { raw: sitemap(), kieu: 'application/xml; charset=utf-8' };
  if (d === '/robots.txt') return { raw: robots(), kieu: 'text/plain; charset=utf-8' };
  if (d === '/manifest.webmanifest') return { raw: manifest(), kieu: 'application/manifest+json; charset=utf-8' };
  return null;
}

/**
 * Rút phần VĂN XUÔI của một trang: chỉ những đoạn chữ người đọc thật sự đọc.
 * Phải bỏ <style> và <script> TRƯỚC khi bóc thẻ, nếu không thì mã CSS và
 * JSON-LD lọt vào và bộ soát tiếng Việt báo lỗi trên mã nguồn.
 */
function vanXuoi(html) {
  const sach = String(html || '')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<head[\s\S]*?<\/head>/i, ' ')
    // Nhãn điều hướng không phải văn xuôi: "Chương trình · Lộ trình" là danh
    // mục liên kết, đòi nó có dấu chấm cuối câu là đòi sai.
    .replace(/<nav[\s\S]*?<\/nav>/gi, ' ')
    // Khối trưng bày một bài trong kho KHÔNG phải lời văn của trang: đó là HỌC
    // LIỆU, và học liệu đã có bộ soát riêng biết bỏ qua công thức trong $…$
    // (lệnh soi-kho). Đem thước văn xuôi ra đo một dòng công thức thì dòng nào
    // cũng bị báo "viết không dấu" — báo oan, và che mất lỗi thật của trang.
    .replace(/<section[^>]*data-hoc-lieu[\s\S]*?<\/section>/gi, ' ');
  const doan = [...sach.matchAll(/<(p|li|h[1-3]|td|caption)\b[^>]*>([\s\S]*?)<\/\1>/gi)]
    .map((m) => m[2]
      .replace(/<[^>]+>/g, ' ')
      .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"').replace(/&#39;/g, "'")
      .replace(/\s+/g, ' ').trim())
    .filter((x) => x.length > 12);
  return doan.join('\n');
}

module.exports = {
  dinhTuyen, moiDuongDan, sitemap, robots, manifest, khung, vanXuoi,
  trangLop, trangOnThi, trangThiThu, trangDeThi, trangTaiLieu, taiPhieu, ON_THI,
  trangChu, trangChuongTrinh, trangDang, trangLoTrinh, trangPhuongPhap, trangMotPhuongPhap, trangCongCu, trangKhongCo,
};
