'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  CÁC TRANG CỦA NGÔI NHÀ
 * ═══════════════════════════════════════════════════════════════════════════
 *  Mỗi hàm ở đây nhận VÀO dữ liệu đã cắt sẵn từ `dong-bo.boiCanh` hoặc
 *  `dong-bo.banDo`, rồi chỉ việc bày ra. Không hàm nào được nạp
 *  `truc-noi-dung`. Ràng buộc này là lý do trang không thể lộ bước sau dù
 *  người viết trang có vô ý tới đâu — thứ chưa tới không có mặt trong dữ liệu
 *  truyền vào, nên không in ra được.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { SVG, BIEU_PHONG, BIEU_VE_TINH, khung, esc } = require('./nha-giao-dien');
const CGM = require('./chong-gia-mao');

/** Làm tròn tới bậc 5% để khớp bộ lớp bề rộng. */
const bac5 = (p) => Math.max(0, Math.min(100, Math.round(Number(p) / 5) * 5));

// ── Bản đồ nhà ──────────────────────────────────────────────────────────────

function theOPhong(p) {
  const bieu = BIEU_PHONG[p.id] || SVG.nha;
  const td = p.tienDo;
  const lop = ['o-phong', `m-${p.mau}`];
  if (!p.mo) lop.push('khoa');
  if (td && td.xongTruc) lop.push('xong');
  const than = `${td && td.xongTruc ? `<span class="dau-xong">${SVG.tich}</span>` : ''}
    <span class="bieu">${p.mo ? bieu : SVG.khoa}</span>
    <span class="ten">${esc(p.ten)}</span>
    <span class="phu">${esc(p.mo ? p.phu : 'Phòng của vai khác')}</span>
    ${p.mo && td ? `<span class="thanh"><i class="w${bac5(td.tiLe)}"></i></span>
      <span class="so">${td.daXong}/${td.tong} bước</span>`
    : p.mo ? '<span class="so">Chưa bắt đầu</span>' : ''}`;
  return p.mo
    ? `<a class="${lop.join(' ')}" href="/nha/${esc(p.id)}">${than}</a>`
    : `<span class="${lop.join(' ')}" title="${esc(p.lyDoKhoa)}">${than}</span>`;
}

function trangBanDo(banDo, nguoi, nonce) {
  const mai = banDo.phong.find((p) => p.viTri === 'mai');
  const nen = banDo.phong.find((p) => p.viTri === 'nen');
  const giua = banDo.phong.filter((p) => p.viTri === 'phong');

  const veTinh = banDo.veTinh.map((v, i) => `<span class="vt vt${i + 1} m-${v.mau}${v.sang < 10 ? ' toi' : ''}">
    <span class="bieu">${BIEU_VE_TINH[v.id] || SVG.sao}</span>
    <span class="chu"><span class="ten">${esc(v.ten)}</span><span class="phu">${esc(v.phu)}</span>
    ${v.sang > 0 ? `<span class="sang">đang sáng ${v.sang}%</span>` : ''}</span>
  </span>`).join('');

  const than = `
<div class="tua">
  <span class="bieu">${SVG.nha}</span>
  <div>
    <h1>Bản đồ lộ trình</h1>
    <p class="phu">Kích vào từng phần để mở nội dung. Mỗi phòng là một đường đi thẳng,
    bám đúng cấu trúc đề thật, mở ra tới đâu thì hiện tới đó.</p>
  </div>
  <div class="bem">
    <span class="nhan-vai">${esc(banDo.tomTat.soXong)}/${esc(banDo.tomTat.soPhongMo)} phòng đã đi hết</span>
  </div>
</div>

<div class="san">
  <div class="vanh" aria-hidden="true">${veTinh}</div>
  <div class="nha">
    ${mai ? `<div class="mai-boc"><a class="mai" href="${mai.mo ? `/nha/${esc(mai.id)}` : '#'}">
      <h2>${esc(mai.ten)}</h2><p>${esc(mai.phu)}</p>
      ${mai.tienDo ? `<p>${mai.tienDo.daXong}/${mai.tienDo.tong} bước</p>` : ''}
    </a></div>` : ''}
    <div class="than-nha">
      <div class="luoi-phong">${giua.map(theOPhong).join('')}</div>
      ${nen ? `<a class="nen-nha" href="${nen.mo ? `/nha/${esc(nen.id)}` : '#'}">
        <span class="bieu">${SVG.nha}</span>
        <span><span class="ten">${esc(nen.ten)}</span><br><span class="phu">${esc(nen.phu)}</span></span>
        <span class="mui">${SVG.mui}</span>
      </a>` : ''}
    </div>
  </div>
</div>`;
  return khung({ tieuDe: 'Bản đồ lộ trình', duongDan: '/nha', than, nonce, nguoi });
}

// ── Trục thẳng của một phòng ────────────────────────────────────────────────

/** Ô nhập tương ứng với kiểu đầu ra mà bước này đòi. */
function oNhap(d) {
  if (!d) return '<input type="text" name="dauRa" required>';
  if (d.kieu === 'so') return '<input type="number" name="dauRa" step="any" required>';
  if (d.kieu === 'dau-tich') {
    return `<label><input type="checkbox" name="dauRa" value="co" required> ${esc(d.nhan)}</label>`;
  }
  if (d.kieu === 'danh-sach') {
    return '<textarea name="dauRa" required placeholder="Mỗi dòng một ý"></textarea>';
  }
  if (d.kieu === 'anh') {
    return '<input type="text" name="dauRa" required placeholder="Dán đường dẫn ảnh đã tải lên">';
  }
  return '<textarea name="dauRa" required></textarea>';
}

function goiYNhap(d) {
  if (!d) return '';
  if (d.kieu === 'danh-sach') {
    const r = [];
    if (d.toiThieu) r.push(`ít nhất ${d.toiThieu} dòng`);
    if (d.toiDa) r.push(`nhiều nhất ${d.toiDa} dòng`);
    return `Mỗi dòng một ý${r.length ? ` · ${r.join(' · ')}` : ''}.`;
  }
  if (d.kieu === 'chu' && d.toiDa) return `Không quá ${d.toiDa} chữ.`;
  if (d.kieu === 'so') return 'Nhập một con số.';
  if (d.kieu === 'anh') return 'Cần một tấm ảnh làm bằng chứng.';
  return '';
}

function trangTruc(boiCanh, nguoi, nonce, loi = null) {
  const v = boiCanh.chang;
  const gv = boiCanh.giaoViec;
  const mau = v.phong ? v.phong.mau : 'lam';

  const daQua = v.daQua.map((b) => `<li class="buoc qua">
    <span class="cham">${SVG.tich}</span>
    <div class="the-buoc"><h3>${esc(b.ten)}</h3>
      ${b.daNop ? `<p class="da-nop">Đã nộp: ${esc(b.daNop)}</p>` : ''}</div>
  </li>`).join('');

  const c = v.hienTai;
  const hienTai = c ? `<li class="buoc nay">
    <span class="cham">${v.viTri}</span>
    <div class="the-buoc">
      <h3>${esc(c.ten)}</h3>
      <p class="nhiem">${esc(c.nhiemVu)}</p>
      <p class="vi-sao"><b>Vì sao có bước này:</b> ${esc(c.viSao)}</p>
      <p class="xong-khi"><b>Coi là xong khi:</b> ${esc(c.xongKhi)}</p>
      <span class="phut">${SVG.dongho} khoảng ${c.phut} phút</span>
      <form class="nop" method="post" action="/nha/${esc(v.trucId)}/nop">
        ${CGM.oAn(nguoi && nguoi.ve)}
        <label for="dauRa">${esc(c.dauRa.nhan)}</label>
        ${oNhap(c.dauRa)}
        ${goiYNhap(c.dauRa) ? `<p class="goi-y">${esc(goiYNhap(c.dauRa))}</p>` : ''}
        ${loi ? `<p class="loi">${esc(loi)}</p>` : ''}
        <div class="hang-nut">
          <button class="nut nut-chinh" type="submit">Nộp và đi tiếp ${SVG.mui}</button>
          <a class="nut nut-vien" href="/nha">Về bản đồ lộ trình</a>
        </div>
      </form>
    </div>
  </li>` : `<li class="buoc qua">
    <span class="cham">${SVG.tich}</span>
    <div class="the-buoc"><h3>Đã đi hết phòng này</h3>
      <p class="da-nop">Mọi thứ nhà mình nộp lại đều còn đây.</p></div>
  </li>`;

  // Bước chưa tới: chỉ còn số thứ tự. Không tên, không mô tả, không gợi ý.
  const chuaToi = Array.from({ length: v.conLai }, (_, i) => `<li class="buoc chua">
    <span class="cham">${v.viTri + i + 1}</span>
    <div class="the-buoc"><span class="chua-mo">Bước ${v.viTri + i + 1} — mở khi bước trước xong</span></div>
  </li>`).join('');

  const troLy = gv.troLy;
  const than = `
<div class="tua">
  <span class="bieu">${BIEU_PHONG[v.trucId] || SVG.nha}</span>
  <div>
    <h1>${esc(v.phong ? v.phong.ten : v.tenTruc)}</h1>
    <p class="phu">${esc(v.motCau)}</p>
  </div>
  <div class="bem"><a class="nut nut-vien" href="/nha">${SVG.nha} Bản đồ lộ trình</a></div>
</div>

<div class="hai-cot">
  <div>
    <div class="hop">
      <div class="tien"><span>Chặng đường</span>
        <span class="thanh"><i class="w${bac5((v.viTri - (v.xong ? 0 : 1)) / v.tong * 100)}"></i></span>
        <span>${v.xong ? v.tong : v.viTri - 1}/${v.tong}</span></div>
    </div>
    <ol class="truc">${daQua}${hienTai}${chuaToi}</ol>
  </div>

  <aside class="cot-ben">
    <div class="hop">
      <div class="dau-hop"><span class="bieu">${SVG.troly}</span>
        <span><b>Trợ lý AI đồng hành</b><small>${esc(troLy.boiCanh)}</small></span></div>
      ${gv.nguoiDi.than.map((t) => `<p>${esc(t)}</p>`).join('')}
      ${gv.nguoiDi.canNop ? `<div class="vach"></div><p><b>Bước này cần nộp:</b> ${esc(gv.nguoiDi.canNop)}</p>` : ''}
    </div>
    <div class="hop">
      <div class="dau-hop"><span class="bieu">${SVG.laban}</span>
        <span><b>Người tư vấn đang thấy gì</b><small>Cùng một chỗ đứng với học viên</small></span></div>
      <ul>${gv.tuVan.nenHoi.map((h) => `<li>${esc(h)}</li>`).join('')}</ul>
    </div>
    <div class="hop">
      <div class="dau-hop"><span class="bieu">${SVG.sach}</span>
        <span><b>Giáo viên AI dạy gì lúc này</b><small>Chỉ đúng kỹ năng bước này cần</small></span></div>
      <p>${esc(gv.giaoVien.dayGi)}</p>
    </div>
  </aside>
</div>`;
  return khung({
    tieuDe: v.phong ? v.phong.ten : v.tenTruc,
    duongDan: `/nha/${v.trucId}`, than, nonce, nguoi, mau,
  });
}

// ── Nắm chặng đường ─────────────────────────────────────────────────────────

function trangChangDuong(banDo, dangODau, nguoi, nonce) {
  const dong = banDo.phong.filter((p) => p.mo).map((p) => {
    const td = p.tienDo;
    const o = dangODau.dangMo.find((x) => x.phongId === p.id);
    return `<tr>
      <td><a href="/nha/${esc(p.id)}">${esc(p.ten)}</a></td>
      <td>${td ? `${td.daXong}/${td.tong}` : `0/—`}</td>
      <td><span class="thanh-nho"><i class="w${bac5(td ? td.tiLe : 0)}"></i></span></td>
      <td>${o && o.buocHienTai ? esc(o.buocHienTai) : (td && td.xongTruc ? 'đã đi hết' : 'chưa bắt đầu')}</td>
    </tr>`;
  }).join('');
  const than = `
<div class="tua">
  <span class="bieu">${SVG.laban}</span>
  <div><h1>Nắm chặng đường</h1>
  <p class="phu">Học viên đang đứng ở đâu trong từng phòng. Chỉ hiện bước đang làm —
  bước chưa tới vẫn đóng, đúng như trong phòng.</p></div>
</div>
<div class="hop">
  <table class="bang">
    <thead><tr><th>Phòng</th><th>Bước</th><th>Tiến độ</th><th>Đang ở bước</th></tr></thead>
    <tbody>${dong}</tbody>
  </table>
</div>`;
  return khung({ tieuDe: 'Nắm chặng đường', duongDan: '/nha/chang-duong', than, nonce, nguoi });
}

// ── Ma trận đa tầng ─────────────────────────────────────────────────────────

/**
 * Bảng năm hệ chuẩn × mười tầng.
 *
 * Đây là chỗ hệ thống nói cùng ngôn ngữ với gia đình: nội bộ đo bằng TẦNG,
 * còn gia đình hỏi bằng ĐIỂM của kỳ thi. Mỗi ô là một khoảng điểm, không
 * phải một con số — con số đơn lẻ là thứ chưa ai đo được.
 */
function trangMaTran(mt, bienBan, tangHienTai, nguoi, nonce) {
  const dong = mt.hang.map((h) => `<tr${h.tang === tangHienTai ? ' class="dang-o-day"' : ''}>
    <td><b>${h.tang}</b> ${esc(h.tenTang)}</td>
    <td>${esc(h.tenNac)}</td>
    ${h.theoChuan.map((c) => `<td>${c.tu}–${c.den}</td>`).join('')}
  </tr>`).join('');
  const cot = mt.hang[0].theoChuan.map((c) => `<th scope="col">${esc(c.ngan)}</th>`).join('');

  const hong = bienBan.chuan.filter((c) => c.tiLeHong > 0).map((c) => `<li><b>${esc(c.ngan)}</b> — `
    + `${c.phanHong.filter((p) => p.hongHoanToan).map((p) => `${esc(p.ten)} (${p.cau} câu)`).join(', ')}. `
    + `Chiếm ${c.tiLeHong}% số câu của đề.</li>`).join('');

  const than = `
<div class="tua">
  <span class="bieu">${SVG.cot}</span>
  <div><h1>Ma trận đa tầng</h1>
  <p class="phu">Năm hệ chuẩn, mười tầng, năm mươi ô. Cả năm hệ đều chia trình độ thành
  đúng mười nấc cùng tên, nên tầng của hệ thống quy thẳng ra điểm của từng kỳ thi.</p></div>
</div>

<div class="hop">
  <table class="bang">
    <thead><tr><th scope="col">Tầng</th><th scope="col">Nấc chung</th>${cot}</tr></thead>
    <tbody>${dong}</tbody>
  </table>
  <p class="goi-y">Mỗi ô là một KHOẢNG điểm ứng với tầng, không phải điểm dự đoán của một lần thi cụ thể.</p>
</div>

${hong ? `<div class="hop">
  <div class="dau-hop"><span class="bieu">${SVG.laban}</span>
    <span><b>Chỗ chương trình còn hổng</b><small>Nói thẳng để không bán thứ chưa dạy được</small></span></div>
  <ul>${hong}</ul>
  <div class="vach"></div>
  <p>Phần hổng là phần học viên sẽ gặp lần đầu ngay trong phòng thi. Hệ thống nêu ra
  để gia đình biết mà bù bằng nguồn khác, thay vì im lặng.</p>
</div>` : ''}`;
  return khung({ tieuDe: 'Ma trận đa tầng', duongDan: '/nha/ma-tran', than, nonce, nguoi });
}

// ── Cây giá trị: năm tầng, mặt khách hàng ──────────────────────────────────

/**
 * Trang CÂY GIÁ TRỊ.
 *
 * Đây là trang trả lời câu hỏi phụ huynh nào cũng hỏi: "đi hết chương trình
 * thì con tôi được gì?". Năm tầng vẽ từ dưới lên như một cái cây — tầng một ở
 * gốc — vì thứ tự ấy nói đúng điều cần nói: không nhảy cóc được.
 *
 * Trang KHÔNG hiện điểm hứa hẹn, KHÔNG hiện gói dịch vụ, và KHÔNG hiện bất kỳ
 * dấu vết nào của việc hệ thống phân loại gia đình. Có một mục kiểm quét đúng
 * trang này bằng bảng từ cấm ở src/cay-tien/buc-tuong.js.
 */
function trangCayGiaTri(cay, dangO, nguoi, nonce) {
  // Vẽ từ tầng 5 xuống tầng 1: ngọn ở trên, gốc ở dưới.
  const tang = [...cay.tang].sort((a, b) => b.thu - a.thu).map((t) => {
    const qua = dangO && dangO.duCanCu && dangO.tang >= t.thu;
    const dangDung = dangO && dangO.duCanCu && dangO.tang === t.thu;
    return `<li class="tang${qua ? ' da-qua' : ''}${dangDung ? ' dang-o-day' : ''}">
      <span class="so">${t.thu}</span>
      <div class="ruot">
        <b>${esc(t.ten)}</b>
        <span class="hoi">${esc(t.cauHoi)}</span>
        <span class="duoc">${esc(t.duoc)}</span>
        <span class="dau-hieu"><b>Dấu hiệu nhìn thấy ở nhà:</b> ${esc(t.dauHieu)}</span>
        <span class="he-thong"><b>Hệ thống làm:</b> ${esc(t.heThongLam)}</span>
      </div>
    </li>`;
  }).join('');

  const viTri = dangO && dangO.duCanCu
    ? `<div class="hop">
        <div class="dau-hop"><span class="bieu">${SVG.laban}</span>
          <span><b>Con đang ở tầng ${dangO.tang}: ${esc(dangO.ten)}</b><small>${esc(dangO.ghiChu)}</small></span></div>
        ${dangO.tiepTheo ? `<div class="vach"></div>
        <p><b>Tầng kế tiếp — ${esc(dangO.tiepTheo.ten)}:</b> ${esc(dangO.tiepTheo.cauHoi)}</p>
        <p class="goi-y">${esc(dangO.tiepTheo.heThongLam)}</p>` : ''}
      </div>`
    : `<div class="hop">
        <div class="dau-hop"><span class="bieu">${SVG.laban}</span>
          <span><b>Chưa nói được con đang ở tầng nào</b><small>${esc((dangO && dangO.ghiChu) || 'Chưa có dữ liệu học.')}</small></span></div>
        <div class="vach"></div>
        <p>Hệ thống chỉ ghi một tầng khi có dấu vết của tầng đó. Đoán lên cho đẹp thì
        gia đình mừng một hôm rồi mất lòng tin vào mọi con số còn lại.</p>
      </div>`;

  // ── HÌNH CÂY ──────────────────────────────────────────────────────────
  // Năm tầng × mười cấp vẽ thành một cái cây thật: thân là con đường chung,
  // bốn nhánh lớn là bốn tầng đầu, tán là tầng năm. Lá là nhiệm vụ, quả là
  // thứ gia đình nhận được. Quả chín = cấp có bằng chứng đo bằng máy; quả non
  // = mốc mềm. Hình và bảng chữ dưới đây đọc từ CÙNG một nguồn là lưới 50 ô,
  // nên không thể lệch nhau.
  const C50 = require('../matran/cay-50');
  const luoi50 = C50.luoi();
  const { veCay } = require('./cay-hinh');
  const hinhCay = veCay({ luoi: luoi50, dangO }).svg;

  // Bảng chữ đầy đủ cho từng tầng. Hình cho cái nhìn tổng thể; bảng này mới là
  // thứ đọc được trên điện thoại, bằng màn hình đọc, và khi in ra giấy.
  const bangCap = [1, 2, 3, 4, 5].map((t) => {
    const cua = luoi50.o.filter((x) => x.tang === t);
    const tt = cay.tang.find((x) => x.thu === t);
    const hang = cua.map((x) => {
      const cung = x.bangChung.loai === 'moc-cung';
      const tt2 = dangO && dangO.duCanCu && dangO.tang
        ? ((t - 1) * 10 + x.cap < (dangO.tang - 1) * 10 + (dangO.cap || 10) ? ' da-qua' : '')
        : '';
      return `<tr class="${cung ? 'cung' : 'mem'}${tt2}">
        <td class="c-so">${x.cap}</td>
        <td class="c-ten">${esc(x.tenCap)}</td>
        <td class="c-la">${esc(x.la)}</td>
        <td class="c-qua">${esc(x.qua)}</td>
        <td class="c-chung">${cung ? `<b>Quả chín</b> — ${esc(x.bangChung.chung)}` : 'Quả non — mốc mềm'}</td>
      </tr>`;
    }).join('');
    return `<details class="tang-chi-tiet"${t === 1 ? ' open' : ''}>
      <summary><span class="so">${t}</span> <b>${esc(tt.ten)}</b>
        <span class="tom">10 cấp · 3 quả chín · 7 quả non</span></summary>
      <table class="bang-cap">
        <thead><tr><th>Cấp</th><th>Tên cấp</th><th>Lá — nhiệm vụ con làm</th>
          <th>Quả — thứ gia đình nhận được</th><th>Bằng chứng</th></tr></thead>
        <tbody>${hang}</tbody>
      </table>
    </details>`;
  }).join('');

  const than = `
<div class="tua">
  <span class="bieu">${SVG.sach}</span>
  <div><h1>Cây giá trị</h1>
  <p class="phu">${esc(cay.loiMo)}</p></div>
</div>

${viTri}

<div class="hop hop-cay">
  <div class="dau-hop"><span class="bieu">${SVG.sach}</span>
    <span><b>Cả cây trong một hình</b><small>5 nhánh lớn là 5 tầng · mỗi nhánh 10 cấp · lá là nhiệm vụ · quả là thứ nhận được</small></span></div>
  ${hinhCay}
  <ul class="chu-giai">
    <li><span class="mau mau-chin"></span> <b>Quả chín</b> — ${luoi50.soMocCung} cấp có bằng chứng đo được bằng máy. Chỉ những quả này dùng để nói “đã đạt”.</li>
    <li><span class="mau mau-non"></span> <b>Quả non</b> — ${luoi50.soMocMem} cấp còn lại là mốc mềm: thấy mình đang nhích, không dùng để báo đã đạt.</li>
    <li><span class="mau mau-la"></span> <b>Lá</b> — nhiệm vụ con làm ở cấp ấy. Rê chuột vào một quả để đọc cả lá lẫn quả của cấp đó.</li>
  </ul>
</div>

<div class="hop">
  <div class="dau-hop"><span class="bieu">${SVG.laban}</span>
    <span><b>Năm mươi cấp, viết bằng chữ</b><small>Mở từng tầng để đọc nhiệm vụ và thứ nhận được của mỗi cấp</small></span></div>
  ${bangCap}
</div>

<div class="hop">
  <ol class="cay-gt">${tang}</ol>
</div>

<div class="hop">
  <div class="dau-hop"><span class="bieu">${SVG.nguoi}</span>
    <span><b>Đi hết năm tầng thì gia đình giữ được gì</b><small>Viết bằng chữ cụ thể, không bằng lời hứa điểm số</small></span></div>
  <ul>${cay.qua.map((q) => `<li>${esc(q)}</li>`).join('')}</ul>
</div>`;
  return khung({ tieuDe: 'Cây giá trị', duongDan: '/nha/cay-gia-tri', than, nonce, nguoi, mau: 'luc' });
}

// ── Bộ khảo sát: danh sách và trang làm bài ───────────────────────────────

/**
 * Trang DANH SÁCH BỘ KHẢO SÁT.
 *
 * In LUẬT ĐO trước bảng công cụ, có chủ ý: người làm bài phải biết con số nào
 * nặng con số nào nhẹ TRƯỚC khi bỏ công trả lời. Một bảng hỏi tính cách đặt
 * cạnh một bài kiểm tra toán, cùng cỡ chữ, sẽ được người đọc dùng như nhau.
 */
function trangKhaoSat(ds, luat, nguoi, nonce) {
  const the = ds.map((c) => {
    const xong = c.daLam ? `<span class="da-lam">Đã làm ${esc(c.daLamLuc)}</span>` : '';
    const nut = c.lamDuoc
      ? `<a class="nut nut-chinh" href="/nha/khao-sat/${esc(c.ma)}">${c.daLam ? 'Làm lại' : 'Bắt đầu'} ${SVG.mui}</a>`
      : `<span class="goi-y">${esc(c.viSaoChuaLamDuoc || 'Chưa mở')}</span>`;
    return `<li class="the-ks tang-${c.tang}">
      <div class="dau">
        <b>${esc(c.ten)}</b>
        <span class="nhan-tang">Tầng ${c.tang} — ${esc(c.tenTang)}</span>
      </div>
      <p class="do">${esc(c.doDuoc)}</p>
      <p class="khong">${esc(c.khongDoDuoc)}</p>
      <p class="cham">Được ảnh hưởng tới: <b>${c.duocDungDe.length ? esc(c.duocDungDe.join(', ')) : 'không miền nào'}</b>${c.soCau ? ` · ${c.soCau} câu` : ''}</p>
      <div class="hang-nut">${nut}${xong}</div>
    </li>`;
  }).join('');

  const than = `
<div class="tua">
  <span class="bieu">${SVG.sach}</span>
  <div><h1>Bộ khảo sát</h1>
  <p class="phu">${esc(luat.loiDauBang)}</p></div>
</div>

<div class="hop">
  <ul class="ds-ks">${the}</ul>
</div>`;
  return khung({ tieuDe: 'Bộ khảo sát', duongDan: '/nha/khao-sat', than, nonce, nguoi, mau: 'ngoc' });
}

/**
 * Trang LÀM MỘT BÀI KHẢO SÁT.
 *
 * Một biểu mẫu HTML thật, nộp bằng POST, chạy được khi tắt JavaScript — đúng
 * luật chung của khu riêng. Toàn bộ câu nằm trên MỘT trang thay vì chia nhiều
 * bước: chia bước thì phải giữ trạng thái giữa chừng, mà trạng thái giữa chừng
 * của một bài sàng lọc tâm lý là thứ không nên tồn tại lâu hơn mức cần.
 */
function trangLamKhaoSat(bo, nguoi, nonce, loi = null) {
  const cau = bo.cau.map((c) => {
    if (bo.kieu === 'tu-bo') {
      // DISC: mỗi câu chọn ĐÚNG NHẤT và ÍT ĐÚNG NHẤT trong bốn ý.
      const o = (ten, nhan) => `<fieldset class="chon"><legend>${esc(nhan)}</legend>${c.luaChon.map((l) => `
        <label><input type="radio" name="${ten}_${c.so}" value="${esc(l.ma)}" required> ${esc(l.chu)}</label>`).join('')}</fieldset>`;
      return `<li class="cau"><p class="hoi"><b>${c.so}.</b> ${esc(c.tinhHuong)}</p>
        ${o('dung', 'Đúng với em nhất')}${o('it', 'Ít đúng với em nhất')}</li>`;
    }
    if (bo.kieu === 'hai-lua') {
      // MBTI: chọn một trong hai.
      return `<li class="cau"><p class="hoi"><b>${c.so}.</b> ${esc(c.hoi)}</p>
        <fieldset class="chon">${c.luaChon.map((l) => `
          <label><input type="radio" name="c_${c.so}" value="${esc(l.ma)}" required> ${esc(l.chu)}</label>`).join('')}</fieldset></li>`;
    }
    // Thang tần suất 0–4.
    return `<li class="cau"><p class="hoi"><b>${c.so}.</b> ${esc(c.hoi)}${c.tenMien ? ` <span class="mien">${esc(c.tenMien)}</span>` : ''}</p>
      <fieldset class="chon thang">${c.thang.map((t) => `
        <label><input type="radio" name="c_${c.so}" value="${t.diem}" required> ${esc(t.chu)}</label>`).join('')}</fieldset></li>`;
  }).join('');

  const than = `
<div class="tua">
  <span class="bieu">${SVG.sach}</span>
  <div><h1>${esc(bo.ten)}</h1>
  <p class="phu">${esc(bo.doDuoc)}</p></div>
  <div class="bem"><a class="nut nut-vien" href="/nha/khao-sat">${SVG.mui} Về danh sách</a></div>
</div>

<div class="hop">
  <div class="dau-hop"><span class="bieu">${SVG.laban}</span>
    <span><b>Đọc trước khi làm</b><small>Điều bộ này KHÔNG nói được</small></span></div>
  <p>${esc(bo.khongDoDuoc)}</p>
  <div class="vach"></div>
  <p class="goi-y">${esc(bo.ghiChu)}</p>
  ${bo.riengTu ? `<p class="goi-y">${esc(bo.riengTu)}</p>` : ''}
</div>

<div class="hop">
  <form method="post" action="/nha/khao-sat/${esc(bo.ma)}/nop">
    ${CGM.oAn(nguoi && nguoi.ve)}
    ${loi ? `<p class="loi">${esc(loi)}</p>` : ''}
    <ol class="ds-cau">${cau}</ol>
    <div class="hang-nut">
      <button class="nut nut-chinh" type="submit">Nộp bài ${SVG.mui}</button>
      <a class="nut nut-vien" href="/nha/khao-sat">Để lúc khác</a>
    </div>
  </form>
</div>`;
  return khung({ tieuDe: bo.ten, duongDan: '/nha/khao-sat', than, nonce, nguoi, mau: 'ngoc' });
}

/** Trang kết quả ngay sau khi nộp. */
function trangKetQuaKhaoSat(bo, kq, nguoi, nonce) {
  const dong = (kq.dong || []).map((d) => `<li><b>${esc(d.nhan)}</b> ${esc(d.chu)}</li>`).join('');
  const than = `
<div class="tua">
  <span class="bieu">${SVG.tich}</span>
  <div><h1>Đã nộp — ${esc(bo.ten)}</h1>
  <p class="phu">${esc(kq.motCau)}</p></div>
</div>

${kq.canNguoiLonNgay ? `<div class="hop">
  <div class="dau-hop"><span class="bieu">${SVG.nguoi}</span>
    <span><b>Cần một người lớn nói chuyện với em</b><small>Việc này đi trước mọi chuyện học hành</small></span></div>
  <p>${esc(kq.ketLuan)}</p>
</div>` : ''}

<div class="hop">
  ${dong ? `<ul>${dong}</ul>` : `<p>${esc(kq.ketLuan || 'Đã ghi nhận.')}</p>`}
  <div class="vach"></div>
  <p class="goi-y">${esc(bo.ghiChu)}</p>
  ${kq.khongLuuCauTho ? '<p class="goi-y">Hệ thống chỉ lưu kết quả theo miền, KHÔNG lưu từng câu trả lời của em.</p>' : ''}
</div>

<div class="hop">
  <div class="hang-nut">
    <a class="nut nut-chinh" href="/nha/lo-trinh-ca-nhan">Xem lộ trình riêng ${SVG.mui}</a>
    <a class="nut nut-vien" href="/nha/khao-sat">Về danh sách khảo sát</a>
  </div>
</div>`;
  return khung({ tieuDe: 'Đã nộp', duongDan: '/nha/khao-sat', than, nonce, nguoi, mau: 'luc' });
}

// ── Lộ trình cá nhân hoá theo chặng ───────────────────────────────────────

/**
 * Trang LỘ TRÌNH CÁ NHÂN HOÁ.
 *
 * Trang này phải trả lời được câu hỏi khó nhất mà phụ huynh đặt ra: "vì sao
 * lộ trình của con tôi lại như thế này?". Nên nó in cả VẾT NGUỒN — công cụ
 * nào ảnh hưởng tới trường nào — và in cả danh sách BỊ LUẬT CHẶN, để gia đình
 * thấy rằng những thứ không được phép quyết định thì thật sự đã không quyết
 * định gì.
 */
function trangLoTrinhCaNhan(lt, luat, nguoi, nonce) {
  if (!lt || !lt.ok) {
    // Thiếu lớp là thứ DUY NHẤT trong nhóm "chưa dựng được" mà gia đình tự vá
    // được ngay tại chỗ, nên chỗ này có biểu mẫu chứ không chỉ có lời nhắc.
    // Trước bản này, đường ghi lớp đã có ở máy chủ nhưng không trang nào dẫn
    // tới — một cánh cửa có khoá mà không có tay nắm.
    const thieuLop = lt && lt.error === 'CHƯA_BIẾT_LỚP';
    const oLop = Array.from({ length: 12 }, (_, i) => `<option value="${i + 1}">Lớp ${i + 1}</option>`).join('');
    const khaiLop = thieuLop ? `
<div class="hop">
  <div class="dau-hop"><span class="bieu">${SVG.laban}</span>
    <span><b>Khai lớp của con</b><small>Con số này quyết định phạm vi kiến thức của cả sáu chặng</small></span></div>
  <form method="post" action="/nha/lo-trinh-ca-nhan/khai-lop">
    ${CGM.oAn(nguoi && nguoi.ve)}
    <label for="lop">Con đang học lớp mấy?</label>
    <select id="lop" name="lop" required>
      <option value="">— chọn lớp —</option>
      ${oLop}
    </select>
    <div class="hang-nut">
      <button class="nut nut-chinh" type="submit">Lưu lớp ${SVG.mui}</button>
    </div>
  </form>
</div>` : '';
    const than = `
<div class="tua">
  <span class="bieu">${SVG.laban}</span>
  <div><h1>Lộ trình cá nhân hoá</h1>
  <p class="phu">Chưa dựng được lộ trình.</p></div>
</div>
<div class="hop">
  <div class="dau-hop"><span class="bieu">${SVG.sach}</span>
    <span><b>${esc((lt && lt.error) || 'CHƯA_ĐỦ_CĂN_CỨ')}</b><small>Nói thẳng còn thiếu gì</small></span></div>
  <p>${esc((lt && (lt.reason || lt.canGi)) || 'Chưa có kết quả khảo sát nào thuộc nhóm quyết định được nội dung học.')}</p>
  ${lt && lt.canGi ? `<div class="vach"></div><p class="goi-y">${esc(lt.canGi)}</p>` : ''}
</div>${khaiLop}`;
    return khung({ tieuDe: 'Lộ trình cá nhân hoá', duongDan: '/nha/lo-trinh-ca-nhan', than, nonce, nguoi, mau: 'tim' });
  }

  const chang = lt.chang.map((c) => `<li class="chang${c.baiTestCua && c.baiTestCua.laThiTongKet ? ' tong-ket' : ''}">
    <span class="so">${c.thu}</span>
    <div class="ruot">
      <b>${esc(c.ten)}</b>
      <span class="hoi">${esc(c.thang)} · tuần ${c.tuan[0]}–${c.tuan[1]} · ${c.soDangPhaiThao} dạng phải thạo</span>
      <span class="duoc">${esc(c.vaiTro)}</span>
      ${c.baiTestCua ? `<span class="dau-hieu"><b>${esc(c.baiTestCua.tenDe)}:</b> ${c.baiTestCua.tongCau} câu · `
        + esc(c.baiTestCua.theoMuc.filter((m) => m.soCau).map((m) => `${m.sao}★ ${m.soCau}`).join(' · ')) + '</span>'
        + `<span class="he-thong"><b>Qua cửa khi:</b> ${esc(c.baiTestCua.dieuKienQua)}</span>` : ''}
      <span class="he-thong"><b>Chưa qua thì:</b> ${esc(c.khongQuaThiSao)}</span>
    </div>
  </li>`).join('');

  const vet = lt.vetNguon.map((v) => `<tr><td>${esc(v.congCu)}</td><td>${esc(v.mien)}</td><td>${esc(v.truong)}</td><td>${esc(v.viec)}</td></tr>`).join('');
  const chan = lt.daTuChoi.map((v) => `<li><b>${esc(v.congCu)}</b> xin ảnh hưởng tới <b>${esc(v.mien)}</b> — bị chặn: ${esc(v.lyDo)}</li>`).join('');

  const than = `
<div class="tua">
  <span class="bieu">${SVG.laban}</span>
  <div><h1>Lộ trình cá nhân hoá</h1>
  <p class="phu">${esc(lt.soChang)} chặng theo đúng khung thời gian năm học. Mỗi chặng một bài test cửa;
  chặng cuối là bài thi tổng kết ở mức vận dụng cao.</p></div>
</div>

<div class="hop">
  <div class="dau-hop"><span class="bieu">${SVG.dongho}</span>
    <span><b>Nhịp học</b><small>${lt.nhip.buoiMoiTuan} buổi mỗi tuần · ${lt.nhip.phutMoiBuoi} phút mỗi buổi</small></span></div>
  ${lt.nhip.ghiChu ? `<p>${esc(lt.nhip.ghiChu)}</p>` : '<p class="goi-y">Nhịp chuẩn, chưa có căn cứ nào để chỉnh.</p>'}
  ${lt.cuaAnToan && lt.cuaAnToan.daMo ? `<div class="vach"></div>
  <p><b>Cửa an toàn đã mở</b> sau khi ${esc(lt.cuaAnToan.boi.ten)} (${esc(lt.cuaAnToan.boi.vai)}) nói chuyện với em.</p>` : ''}
</div>

<div class="hop">
  <ol class="cay-gt chang-ds">${chang}</ol>
</div>

<div class="hop">
  <div class="dau-hop"><span class="bieu">${SVG.cot}</span>
    <span><b>Vì sao lộ trình lại như thế này</b><small>Mọi trường đều tra ngược được về công cụ đã ảnh hưởng</small></span></div>
  <table class="bang">
    <thead><tr><th scope="col">Công cụ</th><th scope="col">Miền</th><th scope="col">Trường</th><th scope="col">Để làm gì</th></tr></thead>
    <tbody>${vet}</tbody>
  </table>
  ${chan ? `<div class="vach"></div>
  <p><b>Những thứ ĐÃ XIN nhưng bị luật đo chặn:</b></p>
  <ul>${chan}</ul>
  <p class="goi-y">Danh sách này in ra để gia đình thấy luật chặn thật, chứ không chỉ được hứa trong tài liệu.</p>` : ''}
</div>

<div class="hop">
  <div class="dau-hop"><span class="bieu">${SVG.sach}</span>
    <span><b>Con số nào nặng, con số nào nhẹ</b><small>${esc(luat.soDuocQuyetNoiDung)}/${esc(luat.soCongCu)} công cụ được phép quyết định nội dung học</small></span></div>
  <p>${esc(luat.loiDauBang)}</p>
</div>`;
  return khung({ tieuDe: 'Lộ trình cá nhân hoá', duongDan: '/nha/lo-trinh-ca-nhan', than, nonce, nguoi, mau: 'tim' });
}

// ── Trang chưa dựng: nói thẳng còn thiếu gì ────────────────────────────────

/**
 * Trang chưa có nội dung thật thì nói thẳng là chưa có, và nói rõ còn thiếu
 * dữ liệu gì. Dựng màn hình rỗng có vẻ đầy đủ là cách nhanh nhất mất lòng tin.
 */
function trangChuaDung({ tieuDe, duongDan, canGi, nguoi, nonce }) {
  const than = `
<div class="tua">
  <span class="bieu">${SVG.sach}</span>
  <div><h1>${esc(tieuDe)}</h1>
  <p class="phu">Phần này chưa mở, vì hệ thống chưa có dữ liệu thật để hiện.</p></div>
</div>
<div class="hop">
  <p>Để mở được phần này, hệ thống cần:</p>
  <ul>${canGi.map((c) => `<li>${esc(c)}</li>`).join('')}</ul>
  <div class="vach"></div>
  <p>Trong lúc chờ, học viên vẫn đi được các phòng trong
  <a href="/nha">bản đồ lộ trình</a>.</p>
</div>`;
  return khung({ tieuDe, duongDan, than, nonce, nguoi });
}

module.exports = {
  trangBanDo, trangTruc, trangChangDuong, trangMaTran, trangCayGiaTri,
  trangLoTrinhCaNhan, trangKhaoSat, trangLamKhaoSat, trangKetQuaKhaoSat, trangChuaDung, bac5,
};
