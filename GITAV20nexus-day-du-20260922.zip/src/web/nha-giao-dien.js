'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  GIAO DIỆN LỘ TRÌNH HỌC — GITAV20nexus
 * ═══════════════════════════════════════════════════════════════════════════
 *  Đây là mặt TRONG của hệ thống — chỗ người đã đăng nhập đi từng bước. Nó
 *  khác hẳn trang công khai ở ba điểm, và cả ba đều là chủ ý:
 *
 *  1. KHÔNG CHO CÔNG CỤ TÌM KIẾM VÀO. Mọi trang ở đây mang thẻ noindex và
 *     không nằm trong sitemap. Luật không xem trước mà để lộ ra ngoài qua kết
 *     quả tìm kiếm thì coi như không có luật.
 *  2. MÀN HÌNH KHÔNG TỰ DỰNG NỘI DUNG. Mọi chữ về bước đi đều lấy từ
 *     `boiCanh`, thứ đã bị cắt sẵn phần chưa tới. Trang không được phép đọc
 *     thẳng nội dung trục — nếu được phép thì sớm muộn sẽ có chỗ in thừa.
 *  3. CHẠY ĐƯỢC KHI TẮT JAVASCRIPT. Mỗi bước là một biểu mẫu gửi đi rồi nạp
 *     lại trang. Người đang ngồi với con, mạng yếu, máy cũ — vẫn đi được.
 *
 *  BẢN ĐỒ TOẢ TRÒN, ĐƯỜNG ĐI THẲNG.
 *  Hình ngôi nhà có mái, có phòng, có nền, quanh nhà là mười một phẩm chất
 *  sáng dần. Nhìn thì nhiều lối, nhưng bấm vào bất cứ phòng nào cũng chỉ có
 *  một đường đi tới cuối. Toả tròn là để nhìn thấy toàn cảnh; thẳng là để đi.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { PHONG_INDEX } = require('../nha/ban-do');

const esc = (s) => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

/* ── Bộ màu và hình khối ──────────────────────────────────────────────────
   Tách riêng khỏi trang công khai: mặt trong dùng nhiều mảng trắng và bóng
   mềm để mắt nghỉ, vì người dùng ở đây ngồi lâu chứ không lướt qua. */
const CSS = `
:root{
  --nen:#eef4fb; --tam:#fff; --tam2:#f6f9fe;
  --chu:#0f2744; --mo:#4a5d78; --mo2:#7387a3;
  --vien:#dfe8f4; --vien2:#c9d8ec;
  --lam:#1668c9; --lam2:#4dabf7; --lam-nhat:#e7f1fd;
  --luc:#0f9d6e; --luc2:#38d9a9; --luc-nhat:#e4f8f0;
  --tim:#6741d9; --tim2:#9775fa;
  --cam:#e8590c; --cam2:#ffa94d;
  --hong:#d6336c; --hong2:#faa2c1;
  --ngoc:#0b7285; --ngoc2:#3bc9db;
  --r1:12px; --r2:18px; --r3:26px;
  --bong:0 2px 6px -2px rgba(15,39,68,.10),0 12px 28px -18px rgba(15,39,68,.22);
  --bong2:0 6px 14px -6px rgba(15,39,68,.16),0 24px 50px -28px rgba(15,39,68,.30);
  --chuyen:220ms cubic-bezier(.2,.7,.3,1);
  --chu-he:system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;
  --chu-ma:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
  --mau:var(--lam); --mau2:var(--lam2);
}
*{box-sizing:border-box}
html{-webkit-text-size-adjust:100%}
body{margin:0;font:400 16px/1.62 var(--chu-he);color:var(--chu);background:var(--nen);
  min-height:100vh;-webkit-font-smoothing:antialiased}
/* Nền mềm phía sau, để mảng trắng của thẻ nổi lên mà không cần viền đậm. */
body::before{content:"";position:fixed;inset:-20%;z-index:-1;pointer-events:none;
  background:radial-gradient(40% 36% at 14% 16%,rgba(77,171,247,.20),transparent 70%),
    radial-gradient(38% 34% at 86% 24%,rgba(56,217,169,.16),transparent 72%),
    radial-gradient(44% 40% at 50% 94%,rgba(151,117,250,.14),transparent 74%);
  filter:blur(60px)}
a{color:var(--lam);text-decoration:none}
a:hover{text-decoration:underline}
h1,h2,h3{margin:0;line-height:1.22;letter-spacing:-.018em}
p{margin:0 0 10px}
.bo-qua{position:absolute;left:-9999px}
.bo-qua:focus{position:fixed;left:14px;top:14px;z-index:99;background:var(--tam);
  padding:10px 16px;border-radius:var(--r1);box-shadow:var(--bong2)}

/* ── Thanh trên ───────────────────────────────────────────────────────── */
.dinh{position:sticky;top:0;z-index:20;background:rgba(255,255,255,.92);
  backdrop-filter:blur(14px) saturate(1.3);-webkit-backdrop-filter:blur(14px) saturate(1.3);
  border-bottom:1px solid var(--vien)}
.dinh .hang{max-width:1220px;margin:0 auto;padding:11px 20px;display:flex;align-items:center;gap:14px}
.hieu{display:flex;align-items:center;gap:11px;font:800 21px/1 var(--chu-he);color:var(--chu);letter-spacing:-.03em}
.hieu:hover{text-decoration:none}
.hieu .dau{width:38px;height:38px;border-radius:11px;display:grid;place-items:center;
  background:linear-gradient(140deg,var(--lam2),var(--lam));color:#fff;font:800 15px/1 var(--chu-he)}
.hieu span{color:var(--lam)}
.hieu small{display:block;font:600 10.5px/1.3 var(--chu-he);color:var(--mo2);letter-spacing:.06em;margin-top:3px}
.day{flex:1}
.vai-chip{display:inline-flex;align-items:center;gap:7px;padding:7px 14px;border-radius:999px;
  background:var(--lam-nhat);color:var(--lam);font-weight:700;font-size:13.5px;
  border:1px solid color-mix(in srgb,var(--lam) 18%,var(--vien))}
.nguoi{display:flex;align-items:center;gap:10px}
.anh-dai-dien{width:38px;height:38px;border-radius:50%;display:grid;place-items:center;color:#fff;
  background:linear-gradient(140deg,var(--tim2),var(--tim));font:800 14px/1 var(--chu-he)}
.nguoi .ten{font-weight:700;font-size:14px;line-height:1.3}
.nguoi .nha{font-size:12.5px;color:var(--mo2)}

/* ── Thanh mục ────────────────────────────────────────────────────────── */
.muc{background:var(--tam);border-bottom:1px solid var(--vien)}
.muc .hang{max-width:1220px;margin:0 auto;padding:0 20px;display:flex;gap:4px;overflow-x:auto}
/* flex:0 0 auto là chỗ quan trọng: thiếu nó thì các mục TỰ CO LẠI cho vừa
   khung, và mục cuối bị cắt mất chữ ("Ngườ" thay cho "Người đồng hành") thay
   vì thanh cuộn ngang hiện ra. Cắt cụt một nhãn tệ hơn hẳn một thanh cuộn. */
.muc a{display:inline-flex;align-items:center;gap:8px;padding:14px 13px;font-weight:700;font-size:14px;
  color:var(--mo);border-bottom:3px solid transparent;white-space:nowrap;flex:0 0 auto}
.muc a:hover{color:var(--lam);text-decoration:none;background:var(--tam2)}
.muc a[aria-current]{color:var(--lam);border-bottom-color:var(--lam);background:var(--lam-nhat)}

/* ── Khung chung ──────────────────────────────────────────────────────── */
main{max-width:1220px;margin:0 auto;padding:26px 20px 64px}
.tua{display:flex;align-items:flex-start;gap:18px;flex-wrap:wrap;margin-bottom:22px}
.tua .bieu{width:62px;height:62px;border-radius:var(--r2);display:grid;place-items:center;flex:none;
  background:linear-gradient(140deg,var(--lam2),var(--lam));color:#fff}
.tua h1{font-size:clamp(26px,3.6vw,38px);font-weight:800}
.tua .phu{color:var(--mo);font-size:15.5px;margin-top:5px}
.tua .bem{margin-left:auto;display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.nut{display:inline-flex;align-items:center;gap:9px;padding:11px 20px;border-radius:999px;
  font-weight:700;font-size:14.5px;border:1px solid transparent;cursor:pointer;
  transition:transform var(--chuyen),box-shadow var(--chuyen)}
.nut:hover{text-decoration:none;transform:translateY(-1px)}
.nut-chinh{background:linear-gradient(135deg,var(--lam2),var(--lam));color:#fff;
  box-shadow:0 10px 24px -12px rgba(22,104,201,.7)}
.nut-vien{background:var(--tam);color:var(--chu);border-color:var(--vien2)}
.nut-vien:hover{border-color:var(--lam);color:var(--lam)}

/* ── Ngôi nhà ─────────────────────────────────────────────────────────── */
.san{position:relative;padding:26px 0 58px;min-height:760px}
.vanh{position:absolute;inset:0;pointer-events:none}
.vanh::before{content:"";position:absolute;left:50%;top:5%;width:min(78%,860px);height:84%;
  transform:translateX(-50%);border:2px dashed var(--vien2);border-radius:50%;opacity:.65}
.nha{position:relative;max-width:620px;margin:0 auto;z-index:2}
/* Mái cắt thành hình ngôi nhà bằng clip-path thay vì đắp thêm một tam giác
   bằng viền. Tam giác đắp thêm luôn lệch khi khung đổi bề rộng, còn clip-path
   thì cắt theo tỉ lệ nên mái vừa khít thân nhà ở mọi cỡ màn hình.
   Vì clip-path cắt luôn cả bóng đổ nên bóng đặt ở lớp bọc bên ngoài. */
.mai-boc{filter:drop-shadow(0 16px 30px rgba(22,104,201,.34))}
.mai{position:relative;display:block;background:linear-gradient(150deg,var(--lam2),var(--lam));
  color:#fff;padding:62px 28px 26px;text-align:center;
  clip-path:polygon(50% 0,100% 32%,100% 100%,0 100%,0 32%);margin-bottom:-1px}
.mai:hover{text-decoration:none;color:#fff}
.mai h2{font-size:26px;font-weight:800}
.mai p{margin:5px 0 0;font-size:14.5px;opacity:.92}
.than-nha{position:relative;z-index:1;background:var(--tam);border:1px solid var(--vien);border-top:none;
  border-radius:0 0 var(--r3) var(--r3);padding:20px;box-shadow:var(--bong2)}
.luoi-phong{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
.o-phong{position:relative;display:flex;flex-direction:column;gap:8px;padding:15px 13px 13px;
  border-radius:var(--r2);background:var(--tam);border:1px solid var(--vien);color:inherit;
  text-align:center;transition:transform var(--chuyen),box-shadow var(--chuyen),border-color var(--chuyen)}
.o-phong:hover{text-decoration:none;transform:translateY(-4px);border-color:color-mix(in srgb,var(--mau) 34%,var(--vien));
  box-shadow:0 16px 34px -18px color-mix(in srgb,var(--mau) 65%,transparent)}
.o-phong .bieu{width:44px;height:44px;margin:0 auto;border-radius:14px;display:grid;place-items:center;
  color:#fff;background:linear-gradient(140deg,var(--mau2),var(--mau))}
.o-phong .ten{font-weight:800;font-size:14.5px;line-height:1.3}
.o-phong .phu{font-size:11.5px;color:var(--mo2);line-height:1.4}
.o-phong .thanh{height:5px;border-radius:5px;background:var(--vien);overflow:hidden}
.o-phong .thanh i{display:block;height:100%;border-radius:5px;
  background:linear-gradient(90deg,var(--mau2),var(--mau))}
.o-phong .so{font-size:11.5px;font-weight:700;color:var(--mau)}
.o-phong.khoa{background:var(--tam2);border-style:dashed;cursor:not-allowed}
.o-phong.khoa .bieu{background:var(--vien2);color:var(--mo2)}
.o-phong.khoa .ten,.o-phong.khoa .phu{color:var(--mo2)}
.o-phong.xong{border-color:color-mix(in srgb,var(--luc) 40%,var(--vien))}
.o-phong .dau-xong{position:absolute;top:8px;right:8px;width:20px;height:20px;border-radius:50%;
  background:var(--luc);color:#fff;display:grid;place-items:center;font:800 11px/1 var(--chu-he)}
.nen-nha{display:flex;align-items:center;gap:14px;margin-top:12px;padding:17px 20px;border-radius:var(--r2);
  background:linear-gradient(135deg,var(--lam),#0d4f9e);color:#fff;
  box-shadow:0 14px 32px -18px rgba(13,79,158,.9);transition:transform var(--chuyen)}
.nen-nha:hover{text-decoration:none;color:#fff;transform:translateY(-2px)}
.nen-nha .bieu{width:44px;height:44px;border-radius:14px;background:rgba(255,255,255,.18);
  display:grid;place-items:center;flex:none}
.nen-nha .ten{font-weight:800;font-size:18px}
.nen-nha .phu{font-size:13px;opacity:.9}
.nen-nha .mui{margin-left:auto;width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,.2);
  display:grid;place-items:center;flex:none}

/* ── Vệ tinh ──────────────────────────────────────────────────────────── */
.vt{position:absolute;display:flex;align-items:center;gap:10px;padding:9px 16px 9px 9px;
  border-radius:999px;background:rgba(255,255,255,.94);border:1px solid var(--vien);
  box-shadow:var(--bong);width:198px;
  backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px)}
.vt .bieu{width:34px;height:34px;border-radius:50%;flex:none;display:grid;place-items:center;color:#fff;
  background:linear-gradient(140deg,var(--mau2),var(--mau))}
.vt .chu{min-width:0}
.vt .ten{display:block;font-weight:800;font-size:13px;line-height:1.25}
.vt .phu{display:block;font-size:10.5px;color:var(--mo2);line-height:1.3}
.vt .sang{display:block;font-size:10.5px;font-weight:800;color:var(--mau);margin-top:2px}
.vt.toi{opacity:.55}
.vt.toi .bieu{background:var(--vien2)}
/* Mười một chỗ đứng cố định quanh nhà. Đặt tay từng chỗ thay vì tính bằng
   góc: thân nhà là hình chữ nhật chứ không phải hình tròn, nên chia đều theo
   góc sẽ có chỗ chạm vào mái và chỗ hở cả mảng. */
.vt1{left:0;top:30%}    .vt2{left:4%;top:10%}   .vt3{right:4%;top:10%}
.vt4{left:0;top:47%}    .vt5{right:0;top:30%}   .vt6{left:0;top:64%}
.vt7{right:0;top:47%}   .vt8{left:0;top:79%}   .vt9{right:0;top:63%}
.vt10{left:12%;bottom:0}  .vt11{right:12%;bottom:0}

/* ── Trục thẳng ───────────────────────────────────────────────────────── */
.hai-cot{display:grid;grid-template-columns:minmax(0,1.55fr) minmax(0,1fr);gap:22px;align-items:start}
.truc{position:relative;padding-left:44px;list-style:none;margin:0}
.truc::before{content:"";position:absolute;left:15px;top:8px;bottom:8px;width:2px;
  background:linear-gradient(180deg,var(--mau),var(--vien2))}
.buoc{position:relative;margin:0 0 14px}
.buoc .cham{position:absolute;left:-44px;top:2px;width:32px;height:32px;border-radius:50%;
  display:grid;place-items:center;font:800 13px/1 var(--chu-he);
  background:var(--tam);border:2px solid var(--vien2);color:var(--mo2)}
.buoc.qua .cham{background:var(--luc);border-color:var(--luc);color:#fff}
.buoc.nay .cham{background:linear-gradient(140deg,var(--mau2),var(--mau));border-color:transparent;color:#fff;
  box-shadow:0 0 0 5px color-mix(in srgb,var(--mau) 16%,transparent)}
.buoc.chua .cham{background:var(--tam2);border-style:dashed}
.the-buoc{background:var(--tam);border:1px solid var(--vien);border-radius:var(--r2);padding:16px 18px;
  box-shadow:var(--bong)}
.buoc.nay .the-buoc{border-color:color-mix(in srgb,var(--mau) 32%,var(--vien));
  box-shadow:0 18px 40px -24px color-mix(in srgb,var(--mau) 70%,transparent)}
.buoc.qua .the-buoc{background:var(--tam2);padding:11px 16px}
.buoc.chua .the-buoc{background:transparent;border-style:dashed;padding:10px 16px;color:var(--mo2)}
.the-buoc h3{font-size:17.5px;font-weight:800}
.buoc.qua .the-buoc h3{font-size:14.5px;color:var(--mo)}
.the-buoc .nhiem{margin:9px 0 0;font-size:15.5px;line-height:1.66}
.the-buoc .vi-sao{margin:11px 0 0;padding:11px 14px;border-radius:var(--r1);background:var(--lam-nhat);
  font-size:14px;color:var(--mo);border-left:3px solid var(--mau)}
.the-buoc .da-nop{font-size:13px;color:var(--mo2);margin-top:4px}
.the-buoc .xong-khi{margin-top:11px;font-size:13.5px;color:var(--mo2)}
.the-buoc .xong-khi b{color:var(--chu)}
.the-buoc .phut{display:inline-flex;align-items:center;gap:6px;font-size:12.5px;font-weight:700;
  color:var(--mau);background:color-mix(in srgb,var(--mau) 10%,transparent);
  padding:4px 11px;border-radius:999px;margin-top:10px}
.chua-mo{font-size:13.5px;font-weight:700;color:var(--mo2)}

/* ── Biểu mẫu nộp ─────────────────────────────────────────────────────── */
form.nop{margin-top:15px;padding-top:15px;border-top:1px dashed var(--vien2)}
form.nop label{display:block;font-weight:700;font-size:14px;margin-bottom:7px}
form.nop input[type=text],form.nop input[type=number],form.nop textarea{
  width:100%;padding:12px 14px;border-radius:var(--r1);border:1px solid var(--vien2);
  font:400 15px/1.55 var(--chu-he);color:var(--chu);background:var(--tam);resize:vertical}
form.nop textarea{min-height:104px}
form.nop input:focus,form.nop textarea:focus{outline:none;border-color:var(--mau);
  box-shadow:0 0 0 4px color-mix(in srgb,var(--mau) 14%,transparent)}
form.nop .goi-y,.hop .goi-y{font-size:12.5px;color:var(--mo2);margin:7px 0 0}
.bang tr.dang-o-day{background:var(--lam-nhat)}
.bang tr.dang-o-day td{font-weight:700}
form.nop .hang-nut{display:flex;gap:10px;align-items:center;margin-top:13px;flex-wrap:wrap}
.loi{margin-top:12px;padding:11px 14px;border-radius:var(--r1);background:#fff1f1;
  border-left:3px solid var(--hong);color:#8f1d3c;font-size:14px}

/* ── Cột trợ lý ───────────────────────────────────────────────────────── */
.cot-ben{display:flex;flex-direction:column;gap:14px;position:sticky;top:132px}
.hop{background:var(--tam);border:1px solid var(--vien);border-radius:var(--r2);padding:17px 18px;
  box-shadow:var(--bong)}
.hop .dau-hop{display:flex;align-items:center;gap:11px;margin-bottom:12px}
.hop .dau-hop .bieu{width:36px;height:36px;border-radius:11px;display:grid;place-items:center;color:#fff;
  background:linear-gradient(140deg,var(--tim2),var(--tim))}
.hop .dau-hop b{font-size:15px}
.hop .dau-hop small{display:block;font-size:12px;color:var(--mo2)}
.hop p{font-size:14.5px;line-height:1.66;color:var(--mo)}
.hop p:last-child{margin-bottom:0}
.hop .vach{height:1px;background:var(--vien);margin:13px 0}
.hop ul{margin:0;padding-left:19px;font-size:14px;color:var(--mo)}
.hop ul.tron{list-style:none;padding-left:0}
.hop li{margin:5px 0}
.tien{display:flex;align-items:center;gap:11px;font-size:13.5px;font-weight:700;color:var(--mo)}
.tien .thanh{flex:1;height:8px;border-radius:8px;background:var(--vien);overflow:hidden}
.tien .thanh i{display:block;height:100%;border-radius:8px;
  background:linear-gradient(90deg,var(--mau2),var(--mau))}
.nhan-vai{display:inline-flex;align-items:center;gap:6px;font-size:11.5px;font-weight:800;
  letter-spacing:.05em;text-transform:uppercase;color:var(--mau);
  background:color-mix(in srgb,var(--mau) 11%,transparent);padding:4px 10px;border-radius:999px}

/* ── Chân trang ───────────────────────────────────────────────────────── */
.chan{max-width:1220px;margin:0 auto;padding:22px 20px 40px;text-align:center;
  color:var(--mo2);font-size:13.5px;font-style:italic}

/* ── Cây giá trị: năm tầng, ngọn trên gốc dưới ────────────────────────── */
/* Danh sách đánh số sẵn của trình duyệt bị tắt, vì số ở đây phải chạy NGƯỢC
   (5 ở trên, 1 ở dưới) và phải là số tầng chứ không phải thứ tự dòng. */
.cay-gt{list-style:none;margin:0;padding:0}
.cay-gt .tang{display:flex;gap:14px;align-items:flex-start;padding:15px 0;border-bottom:1px solid var(--vien)}
.cay-gt .tang:last-child{border-bottom:0}
.cay-gt .so{flex:0 0 34px;width:34px;height:34px;border-radius:50%;display:flex;align-items:center;
  justify-content:center;font-weight:800;font-size:15px;background:var(--vien2);color:var(--mo2)}
.cay-gt .tang.da-qua .so{background:var(--luc-nhat);color:var(--luc)}
.cay-gt .tang.dang-o-day .so{background:var(--luc);color:#fff}
.cay-gt .tang.dang-o-day{background:var(--luc-nhat);border-radius:12px;padding-left:12px;padding-right:12px}
.cay-gt .ruot{flex:1 1 auto;min-width:0}
.cay-gt .ruot>*{display:block}
.cay-gt .ruot b{font-size:16.5px}
.cay-gt .hoi{margin-top:3px;font-size:14px;font-style:italic;color:var(--mo2)}
.cay-gt .duoc{margin-top:7px;font-size:14.5px}
.cay-gt .dau-hieu,.cay-gt .he-thong{margin-top:6px;font-size:13.5px;color:var(--mo2)}

/* ── Hình cây giá trị ─────────────────────────────────────────────────── */
/* Toàn bộ hình là SVG nội tuyến: khu riêng chạy với script-src 'none' và
   không tải gì từ tên miền khác, nên không có thư viện vẽ và không có tệp
   ảnh ngoài. Màu lấy từ biến của chủ đề để hình hợp với cả trang. */
.hop-cay{overflow:hidden}
.cay-hinh{display:block;width:100%;height:auto;max-height:min(78vh,1100px);margin:6px auto 2px;
  background:linear-gradient(180deg,var(--tam2) 0%,var(--luc-nhat) 100%);border-radius:var(--r2)}
.cay-hinh .dat{fill:none;stroke:var(--vien2);stroke-width:7;stroke-linecap:round}
.cay-hinh .bong-dat{fill:var(--vien2);opacity:.38}
.cay-hinh .than{fill:#9a6b42}
.cay-hinh .re{fill:none;stroke:#9a6b42;stroke-width:10;stroke-linecap:round}
.cay-hinh .nhanh{fill:none;stroke:#8d6540;stroke-width:13;stroke-linecap:round}
.cay-hinh .nhanh-t5{stroke-width:9}
.cay-hinh .nhanh-con{stroke-width:5}
/* Vòm lá: mảng màu mềm phía sau nhánh. Không có nó thì nhánh trơ ra như nan
   quạt, và hình trông như sơ đồ chứ không như một cái cây. */
.cay-hinh .vom{fill:var(--luc2);opacity:.20}
.cay-hinh .vom-lon{opacity:.26}
.cay-hinh .la{fill:#3fb883;opacity:.80}
.cay-hinh .cuong{fill:none;stroke:#7d5836;stroke-width:3;stroke-linecap:round}

/* Quả chín = cấp có bằng chứng đo bằng máy. Quả non = mốc mềm. Hai thứ KHÔNG
   được trông giống nhau: đó là khác biệt giữa "đã đạt" và "đang nhích". */
.cay-hinh .qua{stroke:#fff;stroke-width:2}
.cay-hinh .qua-chin .qua{fill:var(--cam)}
.cay-hinh .qua-non .qua{fill:var(--vien2)}
.cay-hinh .qua-loi{fill:#fff;opacity:.34}
.cay-hinh .so-cap{font:700 11px var(--chu-he);fill:#fff}
.cay-hinh .qua-non .so-cap{fill:var(--mo)}

/* Chưa đủ căn cứ thì MỌI ô đều mờ như nhau. Tô sẵn vài quả cho hình đỡ trống
   là cách nhanh nhất để mất lòng tin vào cả năm mươi quả còn lại. */
.cay-hinh .o-chua-biet .qua,.cay-hinh .o-chua-toi .qua{opacity:.46}
.cay-hinh .o-chua-biet .la,.cay-hinh .o-chua-toi .la{opacity:.30}
.cay-hinh .o-da-qua .qua{opacity:1}
.cay-hinh .o-dang-o .qua{stroke:var(--luc);stroke-width:4}
.cay-hinh .o-dang-o .la{opacity:.95}

.cay-hinh .ten-tang{font:800 19px var(--chu-he);fill:var(--chu)}
.cay-hinh .ten-tang .so-tang{fill:var(--luc);font-size:15px}
.cay-hinh .viec-tang{font:400 13px var(--chu-he);fill:var(--mo2)}

.chu-giai{list-style:none;margin:10px 0 0;padding:0;display:grid;gap:8px}
.chu-giai li{display:flex;gap:10px;align-items:flex-start;font-size:13.5px;color:var(--mo)}
.chu-giai .mau{flex:0 0 16px;width:16px;height:16px;border-radius:50%;margin-top:3px;border:2px solid #fff;
  box-shadow:0 0 0 1px var(--vien2)}
.chu-giai .mau-chin{background:var(--cam)}
.chu-giai .mau-non{background:var(--vien2)}
.chu-giai .mau-la{background:var(--luc2);border-radius:50% 0 50% 0}

/* ── Bảng năm mươi cấp ───────────────────────────────────────────────── */
/* <details> chứ không phải tab bằng JavaScript: mở được khi tắt JavaScript,
   in ra giấy được, và màn hình đọc đọc được. */
.tang-chi-tiet{border:1px solid var(--vien);border-radius:var(--r1);margin-top:10px;background:var(--tam2)}
.tang-chi-tiet[open]{background:var(--tam)}
.tang-chi-tiet summary{display:flex;gap:10px;align-items:center;padding:12px 14px;cursor:pointer;
  font-size:15.5px;border-radius:var(--r1)}
.tang-chi-tiet summary::-webkit-details-marker{display:none}
.tang-chi-tiet summary .so{flex:0 0 28px;width:28px;height:28px;border-radius:50%;display:flex;
  align-items:center;justify-content:center;font-weight:800;font-size:14px;background:var(--luc-nhat);color:var(--luc)}
.tang-chi-tiet summary .tom{margin-left:auto;font-size:12.5px;color:var(--mo2);font-weight:400}
.bang-cap{width:100%;border-collapse:collapse;font-size:13.5px}
.bang-cap th{text-align:left;padding:8px 10px;border-top:1px solid var(--vien);
  font-size:12px;letter-spacing:.02em;text-transform:uppercase;color:var(--mo2);font-weight:700}
.bang-cap td{padding:9px 10px;border-top:1px solid var(--vien);vertical-align:top}
.bang-cap .c-so{width:38px;font-weight:800;color:var(--mo2)}
.bang-cap .c-ten{width:120px;font-weight:600}
.bang-cap .c-qua{color:var(--luc)}
.bang-cap tr.cung .c-so{color:var(--cam)}
.bang-cap tr.cung .c-chung b{color:var(--cam)}
.bang-cap tr.mem .c-chung{color:var(--mo2)}
.bang-cap tr.da-qua{background:var(--luc-nhat)}
@media (max-width:880px){
  .bang-cap,.bang-cap tbody,.bang-cap tr,.bang-cap td{display:block;width:auto}
  .bang-cap thead{display:none}
  .bang-cap tr{border-top:1px solid var(--vien);padding:8px 2px}
  .bang-cap td{border:0;padding:3px 10px}
  .bang-cap .c-so{display:inline-block;width:auto;margin-right:8px}
  .bang-cap .c-ten{display:inline-block}
  .bang-cap .c-la::before{content:"Lá: ";font-weight:700;color:var(--mo2)}
  .bang-cap .c-qua::before{content:"Quả: ";font-weight:700;color:var(--mo2)}
}
.chang-ds .tang.tong-ket .so,.chang-ds .chang.tong-ket .so{background:var(--tim);color:#fff}
.chang-ds .chang{display:flex;gap:14px;align-items:flex-start;padding:15px 0;border-bottom:1px solid var(--vien)}
.chang-ds .chang:last-child{border-bottom:0}
.chang-ds .chang .so{flex:0 0 34px;width:34px;height:34px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:15px;background:var(--vien2);color:var(--mo2)}

/* ── Bộ khảo sát: danh sách và biểu mẫu làm bài ───────────────────────── */
/* Ba tầng ba màu viền trái. Màu ở đây KHÔNG để trang trí: nó nhắc người đọc
   rằng sáu công cụ không cùng sức nặng, ngay cả khi họ lướt qua không đọc chữ.
   Tầng 3 (không dùng vào việc gì) dùng màu xám nhạt nhất có chủ ý. */
.ds-ks{list-style:none;margin:0;padding:0;display:grid;gap:14px}
.the-ks{border:1px solid var(--vien);border-radius:var(--r2);padding:16px 18px;background:var(--tam2);
  border-left:4px solid var(--vien2)}
.the-ks.tang-1{border-left-color:var(--luc);background:var(--luc-nhat)}
.the-ks.tang-2{border-left-color:var(--lam)}
.the-ks.tang-3{border-left-color:var(--vien2);opacity:.82}
.the-ks .dau{display:flex;flex-wrap:wrap;align-items:baseline;gap:10px;margin-bottom:8px}
.the-ks .dau b{font-size:16.5px}
.the-ks .nhan-tang{font-size:12px;font-weight:700;letter-spacing:.03em;text-transform:uppercase;
  color:var(--mo2);background:var(--tam);border:1px solid var(--vien);border-radius:999px;padding:3px 10px}
.the-ks .do{margin:0 0 6px;font-size:14.5px}
.the-ks .khong{margin:0 0 6px;font-size:13.5px;color:var(--mo2)}
.the-ks .cham{margin:0 0 12px;font-size:13.5px;color:var(--mo2)}
.the-ks .da-lam{align-self:center;font-size:13px;color:var(--luc);font-weight:700}
.the-ks .goi-y{margin:0}

/* Biểu mẫu làm bài. Mỗi câu một khối có viền, vì một danh sách ba mươi hai câu
   không có ranh giới thì người làm mất dấu mình đang ở câu nào. */
.ds-cau{list-style:none;margin:0;padding:0;counter-reset:none}
.ds-cau .cau{padding:16px 0;border-bottom:1px solid var(--vien)}
.ds-cau .cau:last-child{border-bottom:0}
.ds-cau .hoi{margin:0 0 10px;font-size:15.5px}
.ds-cau .hoi .mien{font-size:12px;color:var(--mo2);background:var(--tam2);border-radius:999px;padding:2px 9px;margin-left:6px}
.chon{border:0;margin:0 0 10px;padding:0;display:grid;gap:7px}
.chon:last-child{margin-bottom:0}
.chon legend{font-size:12.5px;font-weight:700;color:var(--mo2);padding:0 0 5px;text-transform:uppercase;letter-spacing:.04em}
.chon label{display:flex;align-items:flex-start;gap:9px;font-size:14.5px;line-height:1.55;
  padding:8px 11px;border:1px solid var(--vien);border-radius:var(--r1);background:var(--tam);cursor:pointer}
.chon label:hover{border-color:var(--lam2);background:var(--lam-nhat)}
.chon input[type=radio]{margin-top:3px;flex:0 0 auto;accent-color:var(--lam)}
.chon input[type=radio]:focus-visible{outline:2px solid var(--lam);outline-offset:2px}
/* Thang tần suất xếp ngang khi đủ chỗ: năm mức cạnh nhau đọc nhanh hơn năm dòng. */
.chon.thang{grid-template-columns:repeat(auto-fit,minmax(150px,1fr))}
select{font:inherit;font-size:15px;padding:10px 12px;border:1px solid var(--vien2);border-radius:var(--r1);
  background:var(--tam);color:var(--chu);min-width:220px;margin-bottom:12px}
select:focus-visible{outline:2px solid var(--lam);outline-offset:2px}

/* ── Bảng ─────────────────────────────────────────────────────────────── */
.bang{width:100%;border-collapse:collapse;font-size:14.5px}
.bang th{text-align:left;padding:10px 12px;font-size:11.5px;font-weight:800;letter-spacing:.06em;
  text-transform:uppercase;color:var(--mo2);border-bottom:1px solid var(--vien2)}
.bang td{padding:12px;border-bottom:1px solid var(--vien);vertical-align:middle}
.bang tr:last-child td{border-bottom:none}
.bang tbody tr:hover{background:var(--tam2)}
.thanh-nho{display:block;width:120px;height:7px;border-radius:7px;background:var(--vien);overflow:hidden}
.thanh-nho i{display:block;height:100%;border-radius:7px;
  background:linear-gradient(90deg,var(--mau2),var(--mau))}

/* ── Bề rộng thanh tiến độ ────────────────────────────────────────────────
   Chính sách bảo mật của hệ thống cấm thuộc tính style nội tuyến, nên bề rộng
   phải là lớp có sẵn. Làm tròn tới bậc 5% là đủ mịn với mắt và giữ số lớp ở
   mức hai mươi mốt. */
.w0{width:0%}
.w5{width:5%}
.w10{width:10%}
.w15{width:15%}
.w20{width:20%}
.w25{width:25%}
.w30{width:30%}
.w35{width:35%}
.w40{width:40%}
.w45{width:45%}
.w50{width:50%}
.w55{width:55%}
.w60{width:60%}
.w65{width:65%}
.w70{width:70%}
.w75{width:75%}
.w80{width:80%}
.w85{width:85%}
.w90{width:90%}
.w95{width:95%}
.w100{width:100%}

/* ── Màu theo phòng ───────────────────────────────────────────────────── */
.m-lam{--mau:var(--lam);--mau2:var(--lam2)}
.m-luc{--mau:var(--luc);--mau2:var(--luc2)}
.m-tim{--mau:var(--tim);--mau2:var(--tim2)}
.m-cam{--mau:var(--cam);--mau2:var(--cam2)}
.m-hong{--mau:var(--hong);--mau2:var(--hong2)}
.m-ngoc{--mau:var(--ngoc);--mau2:var(--ngoc2)}

@media (max-width:1040px){
  .hai-cot{grid-template-columns:1fr}
  .cot-ben{position:static}
  .vanh{display:none}
}
@media (max-width:760px){
  .luoi-phong{grid-template-columns:repeat(2,1fr)}
  .mai::before{border-left-width:120px;border-right-width:120px}
  .dinh .hang{flex-wrap:wrap;gap:10px}
  .nguoi .ten,.nguoi .nha{display:none}
  main{padding:18px 14px 48px}
  .truc{padding-left:36px}
  .buoc .cham{left:-36px;width:26px;height:26px;font-size:12px}
}
@media (prefers-reduced-motion:reduce){
  *{animation:none!important;transition:none!important}
  .o-phong:hover,.nen-nha:hover,.nut:hover{transform:none}
}
`.replace(/\n\s*/g, '\n');

/* ── Hình vẽ ──────────────────────────────────────────────────────────── */
const SVG = {
  nha: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M9.5 21v-6h5v6"/></svg>',
  tia: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="3.4"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M19.1 4.9 17 7M7 17l-2.1 2.1"/></svg>',
  dich: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1.2" fill="currentColor"/></svg>',
  mam: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M12 21v-7"/><path d="M12 14c0-3.3 2.7-6 6-6 0 3.3-2.7 6-6 6Z"/><path d="M12 16c0-2.8-2.2-5-5-5 0 2.8 2.2 5 5 5Z"/></svg>',
  sao: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="m12 3 2.6 5.6 6 .8-4.4 4.2 1.1 6L12 16.8 6.7 19.6l1.1-6L3.4 9.4l6-.8Z"/></svg>',
  tim: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="M12 20s-7-4.4-7-9.2A4 4 0 0 1 12 8a4 4 0 0 1 7 2.8C19 15.6 12 20 12 20Z"/></svg>',
  khien: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="M12 3 5 6v6c0 4.2 3 7.5 7 9 4-1.5 7-4.8 7-9V6Z"/><path d="m9 12 2 2 4-4"/></svg>',
  vuong: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="m4 8 4 3 4-6 4 6 4-3-2 10H6Z"/></svg>',
  cot: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M5 20V12M12 20V5M19 20v-6"/></svg>',
  mat: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M2 12s3.6-6 10-6 10 6 10 6-3.6 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.6"/></svg>',
  laban: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><path d="m15 9-2 5-5 2 2-5Z"/></svg>',
  nguoi: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 20c0-3.3 3.1-5.5 7-5.5S18 16.7 18 20"/><circle cx="11" cy="8" r="3.5"/><path d="M19 20c0-2.3-1-3.9-2.5-4.8"/></svg>',
  sach: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="M4 5.5A1.5 1.5 0 0 1 5.5 4H19v15H5.5A1.5 1.5 0 0 0 4 20.5Z"/><path d="M4 17.5h15"/></svg>',
  mui: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h13"/><path d="m12 6 6 6-6 6"/></svg>',
  tich: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 12 5 5L19 7"/></svg>',
  khoa: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="10.5" width="14" height="10" rx="2.4"/><path d="M8.5 10.5V7.8a3.5 3.5 0 0 1 7 0v2.7"/></svg>',
  dongho: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 1.8"/></svg>',
  troly: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="7.5" width="16" height="12" rx="3.2"/><path d="M12 7.5V4"/><circle cx="9" cy="13.5" r="1.3" fill="currentColor" stroke="none"/><circle cx="15" cy="13.5" r="1.3" fill="currentColor" stroke="none"/></svg>',
};

/** Biểu tượng của từng phòng — gắn theo ý nghĩa, không phát ngẫu nhiên. */
/** Biểu tượng của từng phòng — gắn theo ý nghĩa của đích, không phát bừa. */
const BIEU_PHONG = {
  'chon-dich': SVG.dich,
  'toan-pho-thong': SVG.cot,
  'tieng-anh-nen': SVG.mam,
  hsa: SVG.tia,
  tsa: SVG.laban,
  spt: SVG.vuong,
  sat: SVG.sao,
  ielts: SVG.sach,
  olympiad: SVG.khien,
  'luyen-hang-ngay': SVG.dongho,
};

/** Biểu tượng của mười một năng lực quanh bản đồ. */
const BIEU_VE_TINH = {
  'nen-tang-toan': SVG.cot,
  'tu-duy-logic': SVG.khien,
  'xu-ly-so-lieu': SVG.vuong,
  'toc-do-lam-bai': SVG.dongho,
  'doc-hieu': SVG.sach,
  'tu-vung': SVG.mam,
  'ngu-phap': SVG.tich,
  'phat-am': SVG.tim,
  'viet-hoc-thuat': SVG.nguoi,
  'nhin-that': SVG.mat,
  'nhip-luyen': SVG.laban,
};

// ── Khung trang ─────────────────────────────────────────────────────────────

/**
 * Nhãn trên thanh điều hướng NGẮN HƠN tiêu đề trang, có chủ ý.
 *
 * Bảy mục với nhãn đầy đủ không đủ chỗ ở bề ngang màn hình thường gặp, và khi
 * chật thì mục cuối bị cắt cụt ("Ngườ" thay cho "Người đồng hành") — một nhãn
 * cụt tệ hơn hẳn một nhãn ngắn. Tiêu đề bên trong mỗi trang vẫn viết đủ.
 */
const MUC = [
  { d: '/nha', t: 'Bản đồ', i: SVG.nha },
  { d: '/nha/chang-duong', t: 'Chặng đường', i: SVG.laban },
  { d: '/nha/ma-tran', t: 'Ma trận', i: SVG.cot },
  { d: '/nha/khao-sat', t: 'Khảo sát', i: SVG.sach },
  { d: '/nha/cay-gia-tri', t: 'Cây giá trị', i: SVG.sach },
  { d: '/nha/lo-trinh-ca-nhan', t: 'Lộ trình riêng', i: SVG.laban },
  { d: '/nha/hom-nay', t: 'Hôm nay', i: SVG.dongho },
  { d: '/nha/nguoi-dong-hanh', t: 'Đồng hành', i: SVG.nguoi },
];

/**
 * Khung trang mặt trong.
 * Luôn kèm noindex: phần này không được xuất hiện trong kết quả tìm kiếm, nếu
 * không thì luật không xem trước bị phá từ bên ngoài mà hệ thống không biết.
 */
function khung({ tieuDe, duongDan, than, nonce = null, nguoi = null, mau = 'lam' }) {
  const n = nonce ? ` nonce="${esc(nonce)}"` : '';
  const dd = (duongDan || '/nha').split('?')[0];
  const dang = (d) => (dd === d || (d !== '/nha' && dd.startsWith(`${d}/`)) ? ' aria-current="page"' : '');
  const chuCai = nguoi && nguoi.ten ? nguoi.ten.trim().split(/\s+/).slice(-2).map((x) => x[0]).join('').toUpperCase() : 'GT';
  return `<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<meta name="referrer" content="same-origin">
<title>${esc(tieuDe)} · GITAV20nexus</title>
<style${n}>${CSS}</style>
</head>
<body class="m-${esc(mau)}">
<a class="bo-qua" href="#noi-dung">Bỏ qua thanh điều hướng</a>
<header class="dinh">
  <div class="hang">
    <a class="hieu" href="/nha"><span class="dau">V20</span><span>GITA<small>NEXUS · TOÁN VÀ TIẾNG ANH</small></span></a>
    <span class="day"></span>
    ${nguoi ? `<span class="vai-chip">${SVG.nguoi} ${esc(nguoi.vaiTen)}</span>` : ''}
    ${nguoi ? `<span class="nguoi"><span class="anh-dai-dien">${esc(chuCai)}</span><span><span class="ten">${esc(nguoi.ten)}</span><span class="nha">${esc(nguoi.nhaTen || '')}</span></span></span>` : '<a class="nut nut-vien" href="/ui/cong.html">Đăng nhập</a>'}
  </div>
</header>
<nav class="muc" aria-label="Khu vực của nhà mình">
  <div class="hang">${MUC.map((m) => `<a href="${m.d}"${dang(m.d)}>${m.i}${esc(m.t)}</a>`).join('')}</div>
</nav>
<main id="noi-dung">${than}</main>
<p class="chan">Mỗi phòng là một đường đi thẳng — mở tới đâu hiện tới đó. Phòng mờ là phòng của vai khác.</p>
</body>
</html>`;
}

module.exports = { CSS, SVG, BIEU_PHONG, BIEU_VE_TINH, MUC, khung, esc };
