'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  HỆ THỐNG LỜI GIẢI CHI TIẾT
 * ═══════════════════════════════════════════════════════════════════════════
 *  VẤN ĐỀ CŨ
 *
 *  Mỗi bước giải trước đây chỉ là một chuỗi: "Thay $x = 2$ vào được $y = 5$."
 *  Học viên đọc xong biết MÁY ĐÃ LÀM GÌ nhưng không biết TẠI SAO ĐƯỢC PHÉP
 *  LÀM THẾ. Khi gặp bài khác một chút là bế tắc, vì thứ chuyển được sang bài
 *  mới là căn cứ, không phải thao tác.
 *
 *  CẤU TRÚC MỚI
 *  Một bước giải gồm hai phần tách bạch:
 *
 *    viec   — thao tác: làm gì, ra số nào. Đây là phần học viên chép theo.
 *    canCu  — căn cứ: định lý, công thức, quy tắc hay điều kiện nào cho phép
 *             làm thao tác đó. Đây là phần học viên mang sang bài khác được.
 *
 *  TƯƠNG THÍCH NGƯỢC
 *  Bản thiết kế cũ vẫn khai bước giải bằng chuỗi, và chuỗi vẫn hợp lệ — khi đó
 *  bước ấy có thao tác mà chưa có căn cứ. Mọi nơi đọc lời giải đều đi qua
 *  `chuanHoaBuoc`, nên không chỗ nào phải biết bước đang ở dạng nào.
 *
 *  VÌ SAO TÁCH RA MỘT TỆP RIÊNG
 *  Lời giải được đọc ở sáu chỗ khác nhau: trang công khai, phiếu tải về, bảng
 *  điều khiển giáo viên, bộ đọc thành tiếng, bộ chấm chất lượng và bộ soát
 *  tiếng Việt. Mỗi chỗ tự bóc tách lấy thì sớm muộn sáu chỗ hiểu khác nhau.
 * ═══════════════════════════════════════════════════════════════════════════
 */

/**
 * Đưa một bước giải về dạng chuẩn, dù nó được khai bằng chuỗi hay bằng đối tượng.
 * @param {string|{viec?:string, canCu?:string}} buoc
 * @returns {{viec: string, canCu: string|null}}
 */
function chuanHoaBuoc(buoc) {
  if (buoc == null) return { viec: '', canCu: null };
  if (typeof buoc === 'string') return { viec: buoc, canCu: null };
  const viec = typeof buoc.viec === 'string' ? buoc.viec : String(buoc.viec ?? '');
  const canCu = typeof buoc.canCu === 'string' && buoc.canCu.trim() ? buoc.canCu : null;
  return { viec, canCu };
}

/** Toàn bộ lời giải của một bài, đã chuẩn hoá. */
function cacBuoc(item) {
  const ds = Array.isArray(item?.solutionSteps) ? item.solutionSteps : [];
  return ds.map(chuanHoaBuoc);
}

/**
 * Phần THAO TÁC của một bước, dạng văn bản thuần.
 * Dùng cho bộ đọc thành tiếng và bộ chấm ký hiệu — hai chỗ chỉ quan tâm nội
 * dung toán, không quan tâm trình bày.
 */
function vanBanBuoc(buoc) {
  return chuanHoaBuoc(buoc).viec;
}

/**
 * Toàn bộ văn bản của một bước, gồm cả căn cứ.
 * Dùng cho bộ soát tiếng Việt: căn cứ cũng là câu chữ người học đọc, nên nó
 * phải chịu đúng chuẩn chính tả và văn phong như phần thao tác.
 */
function vanBanDayDu(buoc) {
  const b = chuanHoaBuoc(buoc);
  return b.canCu ? `${b.viec} ${b.canCu}` : b.viec;
}

/** Số bước có kèm căn cứ trên tổng số bước — thước đo độ chi tiết của lời giải. */
function doChiTiet(item) {
  const ds = cacBuoc(item);
  const coCanCu = ds.filter((b) => b.canCu).length;
  return {
    soBuoc: ds.length,
    soBuocCoCanCu: coCanCu,
    tiLe: ds.length ? Math.round((coCanCu / ds.length) * 100) : 0,
    dayDu: ds.length > 0 && coCanCu === ds.length,
  };
}

module.exports = { chuanHoaBuoc, cacBuoc, vanBanBuoc, vanBanDayDu, doChiTiet };
