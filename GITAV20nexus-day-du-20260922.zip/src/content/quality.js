'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  RUBRIC CHẤT LƯỢNG 5★ — chuẩn cao nhất, không nhân nhượng
 * ═══════════════════════════════════════════════════════════════════════════
 *  5 chiều đánh giá. Cổng phát hành (publish gate) đòi ĐỒNG THỜI:
 *    · correctness  = 5★  (tuyệt đối, không có 4★ "gần đúng")
 *    · notation    ≥ 4★
 *    · mọi chiều   ≥ 3★
 *    · tổng có trọng số ≥ 4.5/5
 *  Không đạt → trả về biên tập, không phát hành. Điều A01, A02, A03, A06.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { round } = require('../utils');
const { cacBuoc } = require('./loi-giai');
const notation = require('./notation');

const DIMENSIONS = {
  correctness: {
    weight: 0.40, min: 5,
    name: 'Chính xác toán học',
    desc: 'Đề đúng, đáp án đúng, lời giải đúng, đủ điều kiện, không bỏ trường hợp',
    scale: {
      5: 'Đúng tuyệt đối, đủ điều kiện, xét hết trường hợp',
      4: 'Đúng nhưng thiếu một điều kiện phụ',
      3: 'Đúng kết quả, lời giải có bước chưa chặt',
      2: 'Sai một bước, kết quả cuối vẫn đúng do may',
      1: 'Sai đáp án hoặc sai đề',
    },
  },
  notation: {
    weight: 0.20, min: 4,
    name: 'Chuẩn ký hiệu (A02)',
    desc: 'LaTeX chuẩn: \\dfrac, \\sqrt{}, ^{}; không dùng /, ^, sqrt() thô',
    scale: { 5: 'Chuẩn hoàn toàn', 4: 'Chuẩn, vài chỗ trình bày chưa gọn', 3: '1–2 lỗi ký hiệu', 2: 'Nhiều lỗi ký hiệu', 1: 'Viết thô, không LaTeX' },
  },
  pedagogy: {
    weight: 0.20, min: 3,
    name: 'Sư phạm',
    desc: 'Lời giải từng bước, có gợi ý phân tầng, nêu bẫy thường gặp',
    scale: { 5: 'Từng bước rõ, 3 mức gợi ý, chỉ rõ bẫy', 4: 'Từng bước rõ, có gợi ý', 3: 'Có lời giải đủ bước', 2: 'Lời giải tắt', 1: 'Chỉ có đáp án' },
  },
  originality: {
    weight: 0.10, min: 3,
    name: 'Độc bản',
    desc: 'Không trùng, không là biến thể đổi số của bài đã có',
    scale: { 5: 'Ý tưởng mới hoàn toàn', 4: 'Ngữ cảnh mới trên dạng quen', 3: 'Biến thể có thay đổi cấu trúc', 2: 'Đổi số trên khung cũ', 1: 'Trùng bài đã có' },
  },
  calibration: {
    weight: 0.10, min: 3,
    name: 'Đúng tầng, đúng độ khó',
    desc: 'Độ khó khai báo khớp với số bước, kiến thức và thời gian chuẩn',
    scale: { 5: 'Khớp hoàn toàn', 4: 'Lệch không đáng kể', 3: 'Lệch 1 sao', 2: 'Lệch 2 sao', 1: 'Sai tầng' },
  },
};

const DIM_KEYS = Object.keys(DIMENSIONS);
const PUBLISH_MIN_WEIGHTED = 4.5;

/** Chấm tự động phần đo được bằng máy: ký hiệu, sư phạm, độ khó. Con người/Critic chấm correctness. */
function autoScore(item) {
  const out = {};

  // notation
  // Căn cứ cũng là câu chữ người học đọc và cũng chứa công thức, nên nó phải
  // chịu đúng chuẩn ký hiệu như phần thao tác — không được miễn trừ.
  const texts = [item.stem, ...cacBuoc(item).flatMap((b) => [b.viec, b.canCu]), ...(item.hints || [])]
    .filter(Boolean);
  let notationErrors = 0;
  for (const t of texts) notationErrors += notation.validate(String(t)).errors.length;
  out.notation = notationErrors === 0 ? 5 : notationErrors <= 2 ? 3 : notationErrors <= 5 ? 2 : 1;

  // pedagogy
  const steps = (item.solutionSteps || []).length;
  const hints = (item.hints || []).length;
  const traps = (item.traps || []).length;
  out.pedagogy = steps >= 3 && hints >= 3 && traps >= 1 ? 5
    : steps >= 3 && hints >= 1 ? 4
      : steps >= 2 ? 3
        : steps >= 1 ? 2 : 1;

  // calibration — đối chiếu số bước với bậc sao đã khai báo
  const expectedSteps = { 1: [1, 2], 2: [2, 3], 3: [3, 5], 4: [5, 8], 5: [8, 99] }[item.stars] || [1, 99];
  const dev = steps < expectedSteps[0] ? expectedSteps[0] - steps
    : steps > expectedSteps[1] ? steps - expectedSteps[1] : 0;
  out.calibration = dev === 0 ? 5 : dev <= 1 ? 4 : dev <= 2 ? 3 : dev <= 4 ? 2 : 1;

  return out;
}

/**
 * Tổng hợp điểm: gộp điểm máy chấm với điểm Critic chấm (Critic thắng khi lệch).
 * @param {object} item
 * @param {object} criticScores {correctness, notation?, pedagogy?, originality?, calibration?}
 */
function score(item, criticScores = {}) {
  const auto = autoScore(item);
  const scores = {};
  for (const k of DIM_KEYS) {
    const v = criticScores[k] ?? auto[k] ?? (k === 'originality' ? 3 : null);
    scores[k] = v == null ? 0 : Math.max(1, Math.min(5, Number(v)));
  }

  const weighted = round(DIM_KEYS.reduce((s, k) => s + scores[k] * DIMENSIONS[k].weight, 0), 3);
  const minScore = Math.min(...DIM_KEYS.map((k) => scores[k]));

  const blockers = [];
  for (const k of DIM_KEYS) {
    if (scores[k] < DIMENSIONS[k].min) {
      blockers.push({ dimension: k, name: DIMENSIONS[k].name, got: scores[k], required: DIMENSIONS[k].min });
    }
  }
  if (weighted < PUBLISH_MIN_WEIGHTED) {
    blockers.push({ dimension: 'weighted', name: 'Tổng có trọng số', got: weighted, required: PUBLISH_MIN_WEIGHTED });
  }

  return {
    scores,
    auto,
    critic: criticScores,
    weighted,
    minScore,
    stars: Math.floor(weighted),
    publishable: blockers.length === 0,
    blockers,
    verdict: blockers.length === 0
      ? `ĐẠT CHUẨN PHÁT HÀNH — ${weighted}/5`
      : `CHƯA ĐẠT — ${blockers.map((b) => `${b.name} ${b.got}<${b.required}`).join('; ')}`,
  };
}

/** Bản mô tả rubric để Critic dùng làm đề bài chấm. */
function rubricPrompt() {
  return DIM_KEYS.map((k) => {
    const d = DIMENSIONS[k];
    const scale = Object.entries(d.scale).sort((a, b) => b[0] - a[0])
      .map(([s, t]) => `    ${s}★ ${t}`).join('\n');
    return `- ${k} (${d.name}, trọng số ${d.weight}, tối thiểu ${d.min}★): ${d.desc}\n${scale}`;
  }).join('\n');
}

module.exports = { DIMENSIONS, DIM_KEYS, PUBLISH_MIN_WEIGHTED, autoScore, score, rubricPrompt };
