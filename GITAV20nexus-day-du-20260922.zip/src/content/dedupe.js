'use strict';
/**
 * CHỐNG TRÙNG LẶP — ba tầng, không chỉ so chuỗi.
 *
 *  Tầng 1  EXACT      băm SHA-256 dạng chính tắc          → trùng tuyệt đối
 *  Tầng 2  NEAR       SimHash 64-bit trên 4-gram ký tự     → trùng gần (đổi vài chữ)
 *  Tầng 3  STRUCTURAL cùng DẠNG + cùng chữ ký số học       → cùng bài chỉ đổi số
 *
 *  Tầng 3 là tầng quan trọng nhất: nó chặn đúng kiểu "sinh 500.000 bài bằng cách
 *  thay số vào một khuôn" mà các bản thiết kế trước đã mắc phải.
 */

const { sha256 } = require('../utils');
const { canonical } = require('./notation');

const NEAR_HAMMING_THRESHOLD = 6;   // /64 bit — dùng cho văn bản dài
const NEAR_JACCARD_THRESHOLD = 0.75; // tỉ lệ shingle chung — tin cậy hơn với đề bài ngắn

// ── SimHash 64-bit trên 4-gram ký tự ───────────────────────────────────────
function shingles(text, n = 4) {
  const s = String(text).replace(/\s+/g, ' ').trim();
  const out = [];
  for (let i = 0; i + n <= s.length; i++) out.push(s.slice(i, i + n));
  return out.length ? out : [s];
}

/** FNV-1a 64-bit trả về BigInt. */
function fnv1a64(str) {
  let h = 0xcbf29ce484222325n;
  const prime = 0x100000001b3n;
  const mask = 0xffffffffffffffffn;
  for (let i = 0; i < str.length; i++) {
    h ^= BigInt(str.charCodeAt(i));
    h = (h * prime) & mask;
  }
  return h;
}

/** Tập băm 32-bit của các 4-gram — dùng tính Jaccard. */
function shingleSet(text) {
  const out = new Set();
  for (const sh of shingles(text)) out.add(Number(fnv1a64(sh) & 0xffffffffn));
  return out;
}

function jaccard(a, b) {
  if (!a.size || !b.size) return 0;
  let inter = 0;
  const [small, large] = a.size <= b.size ? [a, b] : [b, a];
  for (const x of small) if (large.has(x)) inter++;
  return inter / (a.size + b.size - inter);
}

function simhash(text) {
  const v = new Array(64).fill(0);
  for (const sh of shingles(text)) {
    const h = fnv1a64(sh);
    for (let b = 0; b < 64; b++) {
      const bit = (h >> BigInt(b)) & 1n;
      v[b] += bit === 1n ? 1 : -1;
    }
  }
  let out = 0n;
  for (let b = 0; b < 64; b++) if (v[b] > 0) out |= 1n << BigInt(b);
  return out;
}

function hamming(a, b) {
  let x = a ^ b;
  let count = 0;
  while (x) { x &= x - 1n; count++; }
  return count;
}

/**
 * Chữ ký cấu trúc: bỏ hết giá trị số, giữ khung bài.
 * "Giải 3x^{2}-5x+2=0" và "Giải 7x^{2}-2x+9=0" cho cùng một chữ ký
 * → nhận ra ngay là cùng một khuôn chỉ đổi số.
 */
/**
 * Chữ ký khung bài. Hai bài cùng chữ ký nghĩa là "cùng một khuôn, chỉ khác số".
 *
 * Dấu đứng trước hệ số cũng bị gộp: "x^{2} + 11x + 30 = 0" và "x^{2} - x - 6 = 0"
 * là CÙNG một khuôn — đổi dấu vẫn là đổi số, không phải ra đề mới.
 *
 * Nhưng hình dạng ĐÁP ÁN thì tách ra thành họ khác nhau: phương trình vô nghiệm
 * và phương trình hai nghiệm tuy nhìn giống nhau nhưng đòi hỏi kết luận khác
 * hẳn, nên không thể coi là cùng một bài.
 */
function answerShape(item) {
  if (!item || typeof item !== 'object') return '';
  if (Array.isArray(item.roots)) return `roots:${item.roots.length}`;
  const a = String(item.answer ?? '');
  if (!a) return '';
  if (/vô nghiệm|khong co nghiem/i.test(a)) return 'roots:0';
  if (/nghiệm kép/i.test(a)) return 'roots:1x2';
  const parts = a.split(/hoặc|;|,/).filter((x) => /\d/.test(x));
  return parts.length ? `roots:${parts.length}` : 'other';
}

function structuralSignature(formCode, stem, shape = '') {
  const skeleton = canonical(stem)
    .replace(/[+-]?\s*\d+(\.\d+)?/g, '#')   // mọi số KÈM DẤU → #
    .replace(/#(\s*#)+/g, '#');
  return sha256(`${formCode}|${skeleton}|${shape}`).slice(0, 32);
}

class DedupeIndex {
  constructor({ nearThreshold = NEAR_HAMMING_THRESHOLD } = {}) {
    this.nearThreshold = nearThreshold;
    this.exact = new Map();       // contentHash -> itemId
    this.structural = new Map();  // signature   -> [itemId]
    this.sims = [];               // {itemId, hash, formCode}
    this.stats = { checked: 0, exactHits: 0, nearHits: 0, structuralHits: 0, admitted: 0 };
  }

  /** Số bài tối đa cho phép dùng chung một khung cấu trúc. */
  static STRUCTURAL_QUOTA = 3;

  fingerprint(formCode, stem, shape = '') {
    const canon = canonical(stem);
    const sh = simhash(canon);
    return {
      contentHash: sha256(`${formCode}|${canon}`),
      simhash: sh,
      // BigInt không JSON hoá được — bản ghi đi vào kho và ra API phải là chuỗi.
      simhashHex: sh.toString(16).padStart(16, '0'),
      shingles: shingleSet(canon),
      structural: structuralSignature(formCode, stem, shape),
    };
  }

  /**
   * Kiểm tra một bài trước khi nhận vào kho.
   * @returns {{ok, reason?, conflictWith?, distance?}}
   */
  check(formCode, stem, shape = '') {
    this.stats.checked++;
    const fp = this.fingerprint(formCode, stem, shape);

    if (this.exact.has(fp.contentHash)) {
      this.stats.exactHits++;
      return { ok: false, reason: 'EXACT_DUPLICATE', conflictWith: this.exact.get(fp.contentHash), fingerprint: fp };
    }

    for (const s of this.sims) {
      if (s.formCode !== formCode) continue; // chỉ so trong cùng dạng
      const d = hamming(fp.simhash, s.hash);
      const j = jaccard(fp.shingles, s.shingles);
      if (d <= this.nearThreshold || j >= NEAR_JACCARD_THRESHOLD) {
        this.stats.nearHits++;
        return {
          ok: false, reason: 'NEAR_DUPLICATE', conflictWith: s.itemId,
          distance: d, similarity: Number(j.toFixed(3)), fingerprint: fp,
        };
      }
    }

    const sameSkeleton = this.structural.get(fp.structural) || [];
    if (sameSkeleton.length >= DedupeIndex.STRUCTURAL_QUOTA) {
      this.stats.structuralHits++;
      return {
        ok: false,
        reason: 'TEMPLATE_OVERUSE',
        conflictWith: sameSkeleton.slice(0, 3),
        detail: `Đã có ${sameSkeleton.length} bài dùng chung khung này — chỉ đổi số là biên soạn máy móc`,
        fingerprint: fp,
      };
    }

    return { ok: true, fingerprint: fp, sameSkeletonCount: sameSkeleton.length };
  }

  /** Ghi nhận một bài đã được duyệt vào chỉ mục. */
  add(itemId, formCode, stem, fingerprint = null, shape = '') {
    const fp = fingerprint || this.fingerprint(formCode, stem, shape);
    this.exact.set(fp.contentHash, itemId);
    this.sims.push({ itemId, hash: fp.simhash, shingles: fp.shingles, formCode });
    const list = this.structural.get(fp.structural) || [];
    list.push(itemId);
    this.structural.set(fp.structural, list);
    this.stats.admitted++;
    return fp;
  }

  remove(itemId) {
    for (const [h, id] of this.exact) if (id === itemId) this.exact.delete(h);
    this.sims = this.sims.filter((s) => s.itemId !== itemId);
    for (const [sig, list] of this.structural) {
      const next = list.filter((x) => x !== itemId);
      if (next.length) this.structural.set(sig, next); else this.structural.delete(sig);
    }
  }

  /** Độ đa dạng khung bài của một dạng: 1.0 = mỗi bài một khung riêng. */
  diversity(formCode) {
    const ids = new Set(this.sims.filter((s) => s.formCode === formCode).map((s) => s.itemId));
    if (!ids.size) return { formCode, items: 0, skeletons: 0, diversity: 0 };
    let skeletons = 0;
    for (const list of this.structural.values()) {
      if (list.some((id) => ids.has(id))) skeletons++;
    }
    return {
      formCode,
      items: ids.size,
      skeletons,
      diversity: Number((skeletons / ids.size).toFixed(3)),
    };
  }

  status() {
    return {
      ...this.stats,
      indexed: this.exact.size,
      skeletons: this.structural.size,
      nearThreshold: this.nearThreshold,
      structuralQuota: DedupeIndex.STRUCTURAL_QUOTA,
    };
  }
}

module.exports = {
  DedupeIndex, simhash, hamming, shingles, shingleSet, jaccard,
  structuralSignature, answerShape, NEAR_HAMMING_THRESHOLD, NEAR_JACCARD_THRESHOLD,
  STRUCTURAL_QUOTA: DedupeIndex.STRUCTURAL_QUOTA,
};
