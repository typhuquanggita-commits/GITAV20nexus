'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BẢN THIẾT KẾ BÀI — mỗi bản là một QUYẾT ĐỊNH SƯ PHẠM, không phải khuôn in
 * ═══════════════════════════════════════════════════════════════════════════
 *  Đây là chỗ phân biệt "biên soạn" với "ghép số ngẫu nhiên".
 *
 *  Một bản thiết kế KHÔNG phải là "đề mẫu rồi thay số". Mỗi bản khai báo:
 *    intent      dạy/kiểm tra điều gì — khác nhau thì bài khác nhau về bản chất
 *    targetTrap  nhằm vào đúng một lỗi sai điển hình đã khai trong danh mục dạng
 *    context     khung tình huống (thuần đại số, thực tế, hình học, đồ thị…)
 *    shape       hình dạng lời giải: số bước, có xét trường hợp hay không
 *    space       KHÔNG GIAN THAM SỐ kèm RÀNG BUỘC TOÁN HỌC, không phải dải số bừa
 *    render      dựng đề + lời giải + đáp án + phần để máy tự kiểm
 *
 *  Bộ sinh phải dùng HẾT các bản thiết kế khác nhau trước khi lặp lại một bản
 *  với bộ tham số khác. Và ngay cả khi lặp lại, lớp chống trùng khung bài chỉ
 *  cho tối đa 3 bài cùng khung — nên không thể "in" ra hàng loạt.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { round } = require('../utils');
const { BP_TIEU_HOC } = require('./blueprints/tieu-hoc');
const { BP_THCS } = require('./blueprints/thcs');
const { BP_THPT } = require('./blueprints/thpt');
const { BP_LIEN_MON } = require('./blueprints/lien-mon');
const { BP_TIENG_ANH } = require('./blueprints/tieng-anh');
const { BP_NEN_TANG } = require('./blueprints/nen-tang');
const { BP_THACH_THUC } = require('./blueprints/thach-thuc');

// ── Tiện ích số học dùng chung cho các ràng buộc ────────────────────────────
const gcd = (a, b) => (b ? gcd(b, a % b) : Math.abs(a));
const isPerfectSquare = (n) => n >= 0 && Number.isInteger(Math.sqrt(n));
const sgn = (n) => (n < 0 ? '-' : '+');
const abs = Math.abs;

/** Viết hệ số trước ẩn cho gọn: 1x → x, −1x → −x. */
function coef(c, sym) {
  if (c === 0) return '';
  if (c === 1) return sym;
  if (c === -1) return `-${sym}`;
  return `${c}${sym}`;
}

/** Ghép hạng tử có dấu: "x^{2} - 5x + 6". */
function poly(terms) {
  let s = '';
  for (const [c, sym] of terms) {
    if (c === 0) continue;
    const body = sym ? coef(abs(c), sym) : String(abs(c));
    if (!s) s = (c < 0 ? '-' : '') + body;
    else s += ` ${sgn(c)} ${body}`;
  }
  return s || '0';
}

/** Phân số LaTeX, tự rút gọn; mẫu 1 thì trả về số nguyên. */
function frac(num, den) {
  if (den === 0) return '\\text{không xác định}';
  let n = num, d = den;
  if (d < 0) { n = -n; d = -d; }
  const g = gcd(n, d) || 1;
  n /= g; d /= g;
  return d === 1 ? String(n) : `\\dfrac{${n}}{${d}}`;
}

const fracValue = (num, den) => (den === 0 ? NaN : num / den);

// ═══════════════════════════════════════════════════════════════════════════
//  DANH SÁCH BẢN THIẾT KẾ
// ═══════════════════════════════════════════════════════════════════════════

const BLUEPRINTS = [

  // ─────────────────────────── M9.PT2.GIAI ─────────────────────────────────
  {
    id: 'BP.M9.PT2.NGHIEM_NGUYEN',
    formCode: 'M9.PT2.GIAI',
    intent: 'Luyện thành thạo công thức nghiệm khi ∆ là số chính phương — học viên phải ra đúng hai nghiệm nguyên.',
    targetTrap: 'tính nhầm ∆',
    context: 'đại số thuần',
    shape: { steps: 4, cases: 1 },
    stars: 2,
    levels: [2, 3],
    space: function* () {
      // Hai nghiệm nguyên phân biệt, hệ số a khác 1 để không rơi vào nhẩm Vi-ét.
      for (const a of [1, 2, 3]) {
        for (let r1 = -6; r1 <= 6; r1++) {
          for (let r2 = r1 + 1; r2 <= 6; r2++) {
            if (r1 === 0 && r2 === 0) continue;
            const b = -a * (r1 + r2);
            const c = a * r1 * r2;
            if (abs(b) > 40 || abs(c) > 60) continue;
            if (gcd(gcd(abs(a), abs(b)), abs(c)) !== 1 && a !== 1) continue; // tránh phương trình rút gọn được
            yield { a, b, c, r1, r2 };
          }
        }
      }
    },
    render: ({ a, b, c, r1, r2 }) => {
      const lhs = poly([[a, 'x^{2}'], [b, 'x'], [c, '']]);
      const delta = b * b - 4 * a * c;
      return {
        stem: `Giải phương trình $${lhs} = 0$.`,
        solutionSteps: [
          {
            viec: `Xác định hệ số: $a = ${a}$, $b = ${b}$, $c = ${c}$.`,
            canCu: 'Đọc hệ số theo đúng thứ tự dạng chuẩn $ax^{2} + bx + c = 0$, kể cả khi hệ số âm.',
          },
          {
            viec: `Tính biệt thức: $\\Delta = b^{2} - 4ac = ${b}^{2} - 4 \\cdot ${a} \\cdot ${c} = ${delta}$.`,
            canCu: 'Công thức biệt thức $\\Delta = b^{2} - 4ac$. Dấu của $\\Delta$ quyết định số nghiệm, nên phải tính nó trước.',
          },
          {
            viec: `Vì $\\Delta = ${delta} > 0$ nên phương trình có hai nghiệm phân biệt.`,
            canCu: 'Phương trình bậc hai có hai nghiệm phân biệt khi và chỉ khi $\\Delta > 0$.',
          },
          {
            viec: `$x_{1} = \\dfrac{-b - \\sqrt{\\Delta}}{2a} = ${frac(-b - Math.sqrt(delta), 2 * a)} = ${Math.min(r1, r2)}$, ` +
          `$x_{2} = \\dfrac{-b + \\sqrt{\\Delta}}{2a} = ${frac(-b + Math.sqrt(delta), 2 * a)} = ${Math.max(r1, r2)}$.`,
            canCu: 'Công thức nghiệm $x = \\dfrac{-b \\pm \\sqrt{\\Delta}}{2a}$. Mẫu là $2a$, không phải $a$.',
          },
        ],
        hints: [
          'Viết rõ ba hệ số $a$, $b$, $c$ trước khi thay vào công thức.',
          'Dấu của $b$ và của $c$ phải lấy nguyên như trong phương trình, kể cả dấu trừ.',
          '$\\Delta = b^{2} - 4ac$. Chú ý $b^{2}$ luôn không âm.',
        ],
        answer: `x = ${Math.min(r1, r2)} \\text{ hoặc } x = ${Math.max(r1, r2)}`,
        check: { equation: `${a}*x^2 + (${b})*x + (${c}) = 0`, variable: 'x' },
      };
    },
  },

  {
    id: 'BP.M9.PT2.DELTA_AM',
    formCode: 'M9.PT2.GIAI',
    intent: 'Buộc học viên KẾT LUẬN vô nghiệm thay vì cố nặn ra nghiệm — kiểm tra hiểu ý nghĩa của ∆.',
    targetTrap: 'tính nhầm ∆',
    context: 'đại số thuần',
    shape: { steps: 3, cases: 1 },
    stars: 2,
    levels: [2, 3],
    space: function* () {
      for (let a = 1; a <= 3; a++) {
        for (let b = -6; b <= 6; b++) {
          for (let c = 1; c <= 9; c++) {
            const d = b * b - 4 * a * c;
            if (d >= 0 || d < -60) continue;
            yield { a, b, c, delta: d };
          }
        }
      }
    },
    render: ({ a, b, c, delta }) => ({
      stem: `Giải phương trình $${poly([[a, 'x^{2}'], [b, 'x'], [c, '']])} = 0$.`,
      solutionSteps: [
          {
            viec: `Hệ số: $a = ${a}$, $b = ${b}$, $c = ${c}$.`,
            canCu: 'Đọc hệ số theo đúng thứ tự dạng chuẩn $ax^{2} + bx + c = 0$.',
          },
          {
            viec: `$\\Delta = ${b}^{2} - 4 \\cdot ${a} \\cdot ${c} = ${delta}$.`,
            canCu: 'Công thức biệt thức $\\Delta = b^{2} - 4ac$, tính kèm dấu của từng hệ số.',
          },
          {
            viec: `Vì $\\Delta = ${delta} < 0$ nên phương trình vô nghiệm trên tập số thực.`,
            canCu: 'Biệt thức âm thì không có căn bậc hai thực, nên phương trình vô nghiệm trên tập số thực. Kết luận vô nghiệm là một đáp án đầy đủ, không phải bài làm dở.',
          },
        ],
      hints: [
        'Tính $\\Delta$ trước, đừng vội áp công thức nghiệm.',
        'Nếu $\\Delta < 0$ thì $\\sqrt{\\Delta}$ không tồn tại trên tập số thực.',
        'Kết luận “vô nghiệm” cũng là một đáp án hoàn chỉnh.',
      ],
      answer: 'Phương trình vô nghiệm',
      check: { equation: `${a}*x^2 + (${b})*x + (${c}) = 0`, roots: [], variable: 'x' },
    }),
  },

  {
    id: 'BP.M9.PT2.NGHIEM_KEP',
    formCode: 'M9.PT2.GIAI',
    intent: 'Phân biệt nghiệm kép với “một nghiệm” — chỗ học viên hay hiểu sai bản chất.',
    targetTrap: 'tính nhầm ∆',
    context: 'đại số thuần',
    shape: { steps: 3, cases: 1 },
    stars: 3,
    levels: [3, 4],
    space: function* () {
      for (let a = 1; a <= 4; a++) {
        for (let r = -5; r <= 5; r++) {
          if (r === 0) continue;
          const b = -2 * a * r;
          const c = a * r * r;
          if (abs(b) > 40 || abs(c) > 100) continue;
          yield { a, b, c, r };
        }
      }
    },
    render: ({ a, b, c, r }) => ({
      stem: `Giải phương trình $${poly([[a, 'x^{2}'], [b, 'x'], [c, '']])} = 0$.`,
      solutionSteps: [
          {
            viec: `Hệ số: $a = ${a}$, $b = ${b}$, $c = ${c}$.`,
            canCu: 'Đọc hệ số theo đúng thứ tự dạng chuẩn $ax^{2} + bx + c = 0$.',
          },
          {
            viec: `$\\Delta = ${b}^{2} - 4 \\cdot ${a} \\cdot ${c} = 0$.`,
            canCu: 'Công thức biệt thức $\\Delta = b^{2} - 4ac$.',
          },
          {
            viec: `$\\Delta = 0$ nên phương trình có nghiệm kép $x = \\dfrac{-b}{2a} = ${frac(-b, 2 * a)} = ${r}$.`,
            canCu: 'Khi $\\Delta = 0$ thì hai nghiệm của công thức trùng nhau thành một giá trị duy nhất, gọi là nghiệm kép. Nghiệm kép vẫn được tính là HAI nghiệm trùng nhau khi dùng Vi-ét.',
          },
        ],
      hints: [
        'Tính $\\Delta$ rồi hãy kết luận.',
        '$\\Delta = 0$ là trường hợp riêng, không phải vô nghiệm.',
        'Nghiệm kép vẫn chỉ là một giá trị $x$, nhưng phải gọi đúng tên là nghiệm kép.',
      ],
      answer: `x = ${r} \\text{ (nghiệm kép)}`,
      check: { equation: `${a}*x^2 + (${b})*x + (${c}) = 0`, roots: [r], variable: 'x' },
    }),
  },

  // ─────────────────────────── M8.PT.BACNHAT ───────────────────────────────
  {
    id: 'BP.M8.PTBN.CHUYENVE',
    formCode: 'M8.PT.BACNHAT',
    intent: 'Rèn thao tác chuyển vế đổi dấu với ẩn ở cả hai vế.',
    targetTrap: 'chuyển vế mà quên đổi dấu',
    context: 'đại số thuần',
    shape: { steps: 3, cases: 1 },
    stars: 2,
    levels: [2, 3],
    space: function* () {
      for (let a = 2; a <= 9; a++) {
        for (let d = 1; d <= 8; d++) {
          if (a === d) continue;
          for (let x0 = -6; x0 <= 6; x0++) {
            if (x0 === 0) continue;
            for (const b of [-7, -3, 2, 5, 9]) {
              const e = (a - d) * x0 + b;      // a·x + b = d·x + e có nghiệm x0
              if (abs(e) > 60) continue;
              yield { a, b, d, e, x0 };
            }
          }
        }
      }
    },
    render: ({ a, b, d, e, x0 }) => ({
      stem: `Giải phương trình $${poly([[a, 'x'], [b, '']])} = ${poly([[d, 'x'], [e, '']])}$.`,
      solutionSteps: [
          {
            viec: `Chuyển các hạng tử chứa $x$ về vế trái, hằng số về vế phải (nhớ đổi dấu khi chuyển vế).`,
            canCu: 'Quy tắc chuyển vế: chuyển một hạng tử sang vế kia thì phải đổi dấu hạng tử đó, vì thực chất là cộng hoặc trừ cùng một lượng vào cả hai vế.',
          },
          {
            viec: `$${poly([[a - d, 'x']])} = ${e - b}$.`,
            canCu: 'Chia hai vế cho hệ số của ẩn, với điều kiện hệ số đó khác $0$.',
          },
          {
            viec: `$x = ${frac(e - b, a - d)} = ${x0}$.`,
            canCu: 'Thay nghiệm trở lại phương trình ban đầu để đối chiếu hai vế.',
          },
        ],
      hints: [
        'Hạng tử chuyển qua dấu bằng thì đổi dấu.',
        `Gom $x$ một bên: $${a}x - ${d}x = ${a - d}x$.`,
        'Chia hai vế cho hệ số của $x$ — hệ số này khác 0 nên chia được.',
      ],
      answer: `x = ${x0}`,
      check: { equation: `${a}*x + (${b}) = ${d}*x + (${e})`, variable: 'x' },
    }),
  },

  {
    id: 'BP.M8.PTBN.MAUSO',
    formCode: 'M8.PT.BACNHAT',
    intent: 'Quy đồng khử mẫu rồi mới giải — kiểm tra kỷ luật trình bày.',
    targetTrap: 'chuyển vế mà quên đổi dấu',
    context: 'đại số thuần',
    shape: { steps: 4, cases: 1 },
    stars: 3,
    levels: [3, 4],
    space: function* () {
      for (const m of [2, 3, 4, 5, 6]) {
        for (const n of [2, 3, 4, 5, 6]) {
          if (m === n) continue;
          const L = (m * n) / gcd(m, n);
          for (let x0 = -5; x0 <= 5; x0++) {
            if (x0 === 0) continue;
            for (const p of [1, 2, 3]) {
              // (x + p)/m - x/n = k  với k chọn sao cho nghiệm đúng bằng x0
              const kNum = (x0 + p) * n - x0 * m;
              if (kNum % (m * n) !== 0) continue;
              const k = kNum / (m * n);
              if (abs(k) > 6) continue;
              yield { m, n, p, k, x0, L };
            }
          }
        }
      }
    },
    render: ({ m, n, p, k, x0, L }) => ({
      stem: `Giải phương trình $\\dfrac{x + ${p}}{${m}} - \\dfrac{x}{${n}} = ${k}$.`,
      solutionSteps: [
          {
            viec: `Mẫu chung của $${m}$ và $${n}$ là $${L}$.`,
            canCu: 'Mẫu chung nhỏ nhất của các mẫu là bội chung nhỏ nhất của chúng.',
          },
          {
            viec: `Nhân hai vế với $${L}$: $${L / m}(x + ${p}) - ${L / n}x = ${L * k}$.`,
            canCu: 'Nhân cả hai vế với cùng một số khác $0$ thì tập nghiệm không đổi — đây là phép biến đổi tương đương.',
          },
          {
            viec: `Khai triển và thu gọn: $${poly([[L / m - L / n, 'x'], [(L / m) * p, '']])} = ${L * k}$.`,
            canCu: 'Khai triển rồi gom các hạng tử đồng dạng để đưa về dạng bậc nhất chuẩn.',
          },
          {
            viec: `$x = ${x0}$.`,
            canCu: 'Chia hai vế cho hệ số của ẩn để tìm nghiệm.',
          },
        ],
      hints: [
        'Tìm mẫu chung nhỏ nhất trước.',
        'Nhân cả hai vế với mẫu chung — nhớ nhân cho TỪNG hạng tử.',
        `Khi khai triển $${L / m}(x + ${p})$ phải nhân vào cả $x$ lẫn $${p}$.`,
      ],
      answer: `x = ${x0}`,
      check: { equation: `(x + ${p})/${m} - x/${n} = ${k}`, variable: 'x' },
    }),
  },

  // ─────────────────────────── M8.HANGDANGTHUC.BAY ─────────────────────────
  {
    id: 'BP.M8.HDT.KHAITRIEN_HIEU',
    formCode: 'M8.HANGDANGTHUC.BAY',
    intent: 'Khai triển bình phương của một hiệu — bắt đúng lỗi mất hạng tử giữa.',
    targetTrap: 'khai triển (a−b)² thiếu số hạng giữa',
    context: 'đại số thuần',
    shape: { steps: 2, cases: 1 },
    stars: 2,
    levels: [2, 3],
    space: function* () {
      for (let p = 1; p <= 7; p++) {
        for (let q = 1; q <= 9; q++) {
          if (p === 1 && q === 1) continue;
          if (gcd(p, q) !== 1) continue;      // tránh trường hợp rút gọn được, đỡ trùng khung
          yield { p, q };
        }
      }
    },
    render: ({ p, q }) => ({
      stem: `Khai triển và thu gọn: $\\left( ${coef(p, 'x')} - ${q} \\right)^{2}$.`,
      solutionSteps: [
          {
            viec: `Nhận dạng: đây là bình phương của một HIỆU, áp dụng $(A - B)^{2} = A^{2} - 2AB + B^{2}$ với $A = ${coef(p, 'x')}$, $B = ${q}$.`,
            canCu: 'Hằng đẳng thức thứ hai: $\\left(A - B\\right)^{2} = A^{2} - 2AB + B^{2}$. Nhận dạng đúng $A$ và $B$ trước khi thay.',
          },
          {
            viec: `Tính từng hạng tử: $A^{2} = ${p * p}x^{2}$; $2AB = 2 \\cdot ${p} \\cdot ${q} = ${2 * p * q}$ (kèm $x$); $B^{2} = ${q * q}$.`,
            canCu: 'Tính riêng từng hạng tử để không bỏ sót hạng tử giữa $2AB$ — đây là hạng tử hay mất nhất.',
          },
          {
            viec: `Ghép lại theo đúng dấu của công thức: $= ${poly([[p * p, 'x^{2}'], [-2 * p * q, 'x'], [q * q, '']])}$.`,
            canCu: 'Ghép ba hạng tử theo đúng dấu của công thức: hạng tử giữa mang dấu trừ khi khai triển bình phương của một hiệu.',
          },
        ],
      hints: [
        'Đây là bình phương của một hiệu, không phải hiệu hai bình phương.',
        'Công thức có BA hạng tử, đừng bỏ quên hạng tử $-2AB$ ở giữa.',
        `$2AB = 2 \\cdot ${p} \\cdot ${q} = ${2 * p * q}$ (kèm $x$).`,
      ],
      answer: poly([[p * p, 'x^{2}'], [-2 * p * q, 'x'], [q * q, '']]),
      check: { expression: `(${p}*x - ${q})^2`, equals: `${p * p}*x^2 - ${2 * p * q}*x + ${q * q}` },
    }),
  },

  {
    id: 'BP.M8.HDT.HIEU_HAI_BINHPHUONG',
    formCode: 'M8.HANGDANGTHUC.BAY',
    intent: 'Nhận ra cấu trúc $A^2 - B^2$ để phân tích nhanh, thay vì khai triển rồi nhóm.',
    targetTrap: 'nhầm a³−b³ với (a−b)³',
    context: 'đại số thuần',
    shape: { steps: 2, cases: 1 },
    stars: 3,
    levels: [3, 4],
    space: function* () {
      for (let p = 1; p <= 6; p++) {
        for (let q = 1; q <= 9; q++) {
          if (!isPerfectSquare(p * p) || gcd(p, q) !== 1) continue;
          yield { p, q };
        }
      }
    },
    render: ({ p, q }) => ({
      stem: `Phân tích thành nhân tử: $${poly([[p * p, 'x^{2}'], [-(q * q), '']])}$.`,
      solutionSteps: [
          {
            viec: `Kiểm tra hai hạng tử có phải bình phương đúng không: $${p * p}x^{2} = (${coef(p, 'x')})^{2}$ và $${q * q} = ${q}^{2}$.`,
            canCu: 'Chỉ dùng được hằng đẳng thức hiệu hai bình phương khi CẢ HAI hạng tử đều là bình phương đúng.',
          },
          {
            viec: `Vậy biểu thức có dạng $A^{2} - B^{2}$ với $A = ${coef(p, 'x')}$, $B = ${q}$.`,
            canCu: 'Đặt tên $A$ và $B$ cho hai căn bậc hai vừa tìm được, để thay vào công thức không nhầm.',
          },
          {
            viec: `Áp dụng $A^{2} - B^{2} = (A - B)(A + B)$: $= \\left( ${coef(p, 'x')} - ${q} \\right)\\left( ${coef(p, 'x')} + ${q} \\right)$.`,
            canCu: 'Hằng đẳng thức thứ ba: $A^{2} - B^{2} = \\left(A - B\\right)\\left(A + B\\right)$.',
          },
        ],
      hints: [
        'Cả hai hạng tử có phải bình phương đúng không?',
        `$${p * p}x^{2}$ là bình phương của $${coef(p, 'x')}$.`,
        'Hiệu hai bình phương tách thành tích của hiệu và tổng.',
      ],
      answer: `\\left( ${coef(p, 'x')} - ${q} \\right)\\left( ${coef(p, 'x')} + ${q} \\right)`,
      check: { expression: `${p * p}*x^2 - ${q * q}`, equals: `(${p}*x - ${q})*(${p}*x + ${q})` },
    }),
  },

  // ─────────────────────────── M9.PT2.VIET ─────────────────────────────────
  {
    id: 'BP.M9.VIET.TONG_TICH',
    formCode: 'M9.PT2.VIET',
    intent: 'Dùng Vi-ét tính biểu thức đối xứng mà KHÔNG giải phương trình — mục đích thật của Vi-ét.',
    targetTrap: 'sai dấu S và P',
    context: 'đại số thuần',
    shape: { steps: 4, cases: 1 },
    stars: 4,
    levels: [4, 6],
    space: function* () {
      for (let a = 1; a <= 3; a++) {
        for (let b = -12; b <= 12; b++) {
          for (let c = -12; c <= 12; c++) {
            const d = b * b - 4 * a * c;
            if (d <= 0 || isPerfectSquare(d)) continue;   // ∆>0 nhưng KHÔNG chính phương → buộc dùng Vi-ét
            yield { a, b, c, delta: d };
          }
        }
      }
    },
    render: ({ a, b, c, delta }) => {
      const S = fracValue(-b, a);
      const P = fracValue(c, a);
      const val = S * S - 2 * P;                       // x1² + x2²
      return {
        stem: `Cho phương trình $${poly([[a, 'x^{2}'], [b, 'x'], [c, '']])} = 0$ có hai nghiệm $x_{1}, x_{2}$. `
          + `Không giải phương trình, hãy tính $x_{1}^{2} + x_{2}^{2}$.`,
        solutionSteps: [
          {
            viec: `$\\Delta = ${b}^{2} - 4 \\cdot ${a} \\cdot ${c} = ${delta} > 0$ nên phương trình có hai nghiệm phân biệt.`,
            canCu: 'Phải khẳng định phương trình có nghiệm trước khi dùng Vi-ét; $\\Delta > 0$ cho hai nghiệm phân biệt.',
          },
          {
            viec: `Theo hệ thức Vi-ét: $S = x_{1} + x_{2} = \\dfrac{-b}{a} = ${frac(-b, a)}$, $P = x_{1}x_{2} = \\dfrac{c}{a} = ${frac(c, a)}$.`,
            canCu: 'Định lý Vi-ét: tổng hai nghiệm bằng $\\dfrac{-b}{a}$, tích hai nghiệm bằng $\\dfrac{c}{a}$.',
          },
          {
            viec: `$x_{1}^{2} + x_{2}^{2} = (x_{1} + x_{2})^{2} - 2x_{1}x_{2} = S^{2} - 2P$.`,
            canCu: 'Hằng đẳng thức $a^{2} + b^{2} = \\left(a + b\\right)^{2} - 2ab$ — cách đưa biểu thức đối xứng về tổng và tích.',
          },
          {
            viec: `$= \\left( ${frac(-b, a)} \\right)^{2} - 2 \\cdot ${frac(c, a)} = ${round(val, 6)}$.`,
            canCu: 'Thay giá trị $S$ và $P$ vừa tính, chú ý dấu khi $P$ âm.',
          },
        ],
        hints: [
          'Kiểm tra $\\Delta > 0$ trước — chưa có nghiệm thì chưa được dùng Vi-ét.',
          '$S = -b/a$ (có dấu trừ), $P = c/a$ (không có dấu trừ).',
          'Biến đổi $x_{1}^{2} + x_{2}^{2}$ về $S$ và $P$: $S^{2} - 2P$.',
        ],
        answer: String(round(val, 6)),
        check: { expression: `(${-b}/${a})^2 - 2*(${c}/${a})`, equals: String(round(val, 10)) },
      };
    },
  },

  // ─────────────────────────── M9.CAN.RUTGON ───────────────────────────────
  {
    id: 'BP.M9.CAN.TRUCCANTHUC',
    formCode: 'M9.CAN.RUTGON',
    intent: 'Trục căn thức ở mẫu bằng biểu thức liên hợp, có nêu điều kiện xác định.',
    targetTrap: 'sai dấu khi trục căn thức',
    context: 'đại số thuần',
    shape: { steps: 4, cases: 1 },
    stars: 3,
    levels: [3, 5],
    space: function* () {
      for (let n = 2; n <= 12; n++) {
        if (isPerfectSquare(n)) continue;       // căn phải là số vô tỉ, nếu không bài mất ý nghĩa
        for (let k = 1; k <= 6; k++) {
          if (k * k === n) continue;
          yield { n, k };
        }
      }
    },
    render: ({ n, k }) => {
      const den = k * k - n;
      return {
        stem: `Trục căn thức ở mẫu và rút gọn: $\\dfrac{1}{${k} - \\sqrt{${n}}}$.`,
        solutionSteps: [
          {
            viec: `Điều kiện: mẫu khác 0, tức $${k} - \\sqrt{${n}} \\ne 0$ (đúng vì $${n}$ không là số chính phương).`,
            canCu: 'Phân thức chỉ xác định khi mẫu khác $0$, nên phải kiểm điều kiện này trước mọi biến đổi.',
          },
          {
            viec: `Nhân cả tử và mẫu với biểu thức liên hợp $${k} + \\sqrt{${n}}$.`,
            canCu: 'Nhân cả tử và mẫu với cùng một biểu thức khác $0$ thì giá trị phân thức không đổi. Biểu thức liên hợp của $a - \\sqrt{b}$ là $a + \\sqrt{b}$.',
          },
          {
            viec: `Mẫu trở thành $(${k})^{2} - (\\sqrt{${n}})^{2} = ${k * k} - ${n} = ${den}$.`,
            canCu: 'Hằng đẳng thức $\\left(A - B\\right)\\left(A + B\\right) = A^{2} - B^{2}$ làm mẫu hết căn.',
          },
          {
            viec: `Kết quả: $\\dfrac{${k} + \\sqrt{${n}}}{${den}}$.`,
            canCu: 'Viết lại phân thức sau khi mẫu đã thành số hữu tỉ.',
          },
        ],
        hints: [
          'Liên hợp của $a - \\sqrt{b}$ là $a + \\sqrt{b}$ — đổi dấu ở giữa.',
          'Nhân cả TỬ và MẪU, nếu chỉ nhân mẫu thì giá trị biểu thức đã đổi.',
          `Mẫu mới là hiệu hai bình phương: $${k * k} - ${n} = ${den}$.`,
        ],
        answer: `\\dfrac{${k} + \\sqrt{${n}}}{${den}}`,
        check: { expression: `1/(${k} - sqrt(${n}))`, equals: `(${k} + sqrt(${n}))/(${den})` },
      };
    },
  },

  // ─────────────────────────── M5.TISO.PHANTRAM ────────────────────────────
  {
    id: 'BP.M5.PHANTRAM.TANG_GIAM',
    formCode: 'M5.TISO.PHANTRAM',
    intent: 'Cho thấy tăng rồi giảm cùng một số phần trăm KHÔNG đưa về giá trị ban đầu.',
    targetTrap: 'tăng rồi giảm cùng số phần trăm tưởng về chỗ cũ',
    context: 'thực tế — giá cả',
    shape: { steps: 4, cases: 1 },
    stars: 4,
    levels: [4, 6],
    space: function* () {
      for (const p of [10, 20, 25, 30, 40, 50]) {
        for (const base of [200000, 400000, 500000, 800000, 1200000, 1500000]) {
          const up = base * (1 + p / 100);
          const down = up * (1 - p / 100);
          if (!Number.isInteger(up) || !Number.isInteger(down)) continue;
          yield { p, base, up, down };
        }
      }
    },
    render: ({ p, base, up, down }) => {
      const vnd = (x) => x.toLocaleString('vi-VN');
      return {
        stem: `Một mặt hàng giá $${vnd(base)}$ đồng. Cửa hàng tăng giá $${p}\\%$, sau đó lại giảm $${p}\\%$ so với giá mới. `
          + `Hỏi giá cuối cùng là bao nhiêu và chênh lệch so với giá ban đầu là bao nhiêu?`,
        solutionSteps: [
          {
            viec: `Giá sau khi tăng $${p}\\%$: $${vnd(base)} \\times \\left(1 + \\dfrac{${p}}{100}\\right) = ${vnd(up)}$ đồng.`,
            canCu: 'Tăng $p\\%$ nghĩa là nhân với $1 + \\dfrac{p}{100}$, không phải cộng thêm $p$.',
          },
          {
            viec: `Giá sau khi giảm $${p}\\%$ so với GIÁ MỚI: $${vnd(up)} \\times \\left(1 - \\dfrac{${p}}{100}\\right) = ${vnd(down)}$ đồng.`,
            canCu: 'Lần giảm tính trên GIÁ MỚI, vì cụm "giảm so với giá hiện tại" chỉ rõ mốc so sánh là giá vừa tăng.',
          },
          {
            viec: `Chênh lệch: $${vnd(base)} - ${vnd(down)} = ${vnd(base - down)}$ đồng, tức thấp hơn giá ban đầu.`,
            canCu: 'So sánh giá cuối với giá ban đầu bằng phép trừ.',
          },
          {
            viec: `Lý do: lần tăng tính trên $${vnd(base)}$, còn lần giảm tính trên $${vnd(up)}$ — hai mốc khác nhau.`,
            canCu: 'Hai lần thay đổi tính trên hai mốc khác nhau nên không triệt tiêu nhau — đây là lý do bản chất, không phải lỗi tính toán.',
          },
        ],
        hints: [
          'Mốc 100% của lần tăng và lần giảm có giống nhau không?',
          'Tính giá sau khi tăng trước, rồi mới lấy đó làm mốc để giảm.',
          `Giảm $${p}\\%$ của $${vnd(up)}$ lớn hơn tăng $${p}\\%$ của $${vnd(base)}$.`,
        ],
        answer: `${vnd(down)} đồng; thấp hơn giá ban đầu ${vnd(base - down)} đồng`,
        check: { expression: `${base} * (1 + ${p}/100) * (1 - ${p}/100)`, equals: String(down) },
      };
    },
  },

  // ─────────────────────────── M6.UOCBOI.UCLNBCNN ──────────────────────────
  {
    id: 'BP.M6.UCLN.PHANBIET',
    formCode: 'M6.UOCBOI.UCLNBCNN',
    intent: 'Phân biệt rành mạch quy tắc lấy ƯCLN (thừa số chung, mũ nhỏ nhất) với BCNN (chung và riêng, mũ lớn nhất).',
    targetTrap: 'nhầm quy tắc ƯCLN với BCNN',
    context: 'số học',
    shape: { steps: 4, cases: 1 },
    stars: 3,
    levels: [3, 4],
    space: function* () {
      for (let a = 12; a <= 90; a += 3) {
        for (let b = a + 4; b <= 96; b += 2) {
          const g = gcd(a, b);
          if (g < 2 || g === a || g === b) continue;   // phải có ước chung thật sự, không chia hết nhau
          const l = (a * b) / g;
          if (l > 900) continue;
          yield { a, b, g, l };
        }
      }
    },
    render: ({ a, b, g, l }) => {
      const factor = (n) => {
        const out = [];
        let m = n;
        for (let p = 2; p * p <= m; p++) {
          let e = 0;
          while (m % p === 0) { m /= p; e++; }
          if (e) out.push(e === 1 ? `${p}` : `${p}^{${e}}`);
        }
        if (m > 1) out.push(String(m));
        return out.join(' \\cdot ');
      };
      return {
        stem: `Tìm $\\text{ƯCLN}(${a}, ${b})$ và $\\text{BCNN}(${a}, ${b})$.`,
        solutionSteps: [
          {
            viec: `Phân tích ra thừa số nguyên tố: $${a} = ${factor(a)}$ và $${b} = ${factor(b)}$.`,
            canCu: 'Mọi số tự nhiên lớn hơn $1$ đều phân tích được thành tích các thừa số nguyên tố, và cách phân tích là duy nhất.',
          },
          {
            viec: `ƯCLN: lấy các thừa số nguyên tố CHUNG, mỗi thừa số lấy số mũ NHỎ NHẤT → $\\text{ƯCLN} = ${g}$.`,
            canCu: 'Quy tắc ước chung lớn nhất: lấy thừa số nguyên tố CHUNG, mỗi thừa số lấy số mũ NHỎ NHẤT.',
          },
          {
            viec: `BCNN: lấy các thừa số nguyên tố CHUNG VÀ RIÊNG, mỗi thừa số lấy số mũ LỚN NHẤT → $\\text{BCNN} = ${l}$.`,
            canCu: 'Quy tắc bội chung nhỏ nhất: lấy thừa số nguyên tố CHUNG VÀ RIÊNG, mỗi thừa số lấy số mũ LỚN NHẤT.',
          },
          {
            viec: `Kiểm tra lại: $\\text{ƯCLN} \\times \\text{BCNN} = ${g} \\times ${l} = ${g * l} = ${a} \\times ${b}$.`,
            canCu: 'Với hai số dương bất kỳ, tích của ước chung lớn nhất và bội chung nhỏ nhất luôn bằng tích hai số đó — dùng để kiểm tra lại.',
          },
        ],
        hints: [
          'Phân tích cả hai số ra thừa số nguyên tố trước đã.',
          'ƯCLN chỉ lấy thừa số CHUNG; BCNN lấy cả thừa số RIÊNG.',
          'Có thể kiểm tra kết quả bằng đẳng thức $\\text{ƯCLN} \\times \\text{BCNN} = a \\times b$.',
        ],
        answer: `ƯCLN = ${g}; BCNN = ${l}`,
        check: { expression: `${g} * ${l}`, equals: `${a} * ${b}` },
      };
    },
  },

  // ─────────────────────────── M9.HPT.BACNHAT ──────────────────────────────
  {
    id: 'BP.M9.HPT.CONGDAISO',
    formCode: 'M9.HPT.BACNHAT',
    intent: 'Khử một ẩn bằng phép cộng đại số, chú trọng dấu khi nhân hai vế.',
    targetTrap: 'nhầm dấu khi cộng đại số',
    context: 'đại số thuần',
    shape: { steps: 4, cases: 1 },
    stars: 3,
    levels: [2, 4],
    space: function* () {
      for (let x0 = -5; x0 <= 5; x0++) {
        for (let y0 = -5; y0 <= 5; y0++) {
          if (x0 === 0 && y0 === 0) continue;
          for (const [a1, b1] of [[2, 3], [3, -2], [1, 4], [5, 2], [3, 5], [4, -3]]) {
            for (const [a2, b2] of [[1, -2], [2, 5], [4, 1], [-1, 3]]) {
              const det = a1 * b2 - a2 * b1;
              if (det === 0) continue;
              const c1 = a1 * x0 + b1 * y0;
              const c2 = a2 * x0 + b2 * y0;
              if (abs(c1) > 40 || abs(c2) > 40) continue;
              yield { a1, b1, c1, a2, b2, c2, x0, y0 };
            }
          }
        }
      }
    },
    render: ({ a1, b1, c1, a2, b2, c2, x0, y0 }) => ({
      stem: `Giải hệ phương trình $\\begin{cases} ${poly([[a1, 'x'], [b1, 'y']])} = ${c1} \\\\ ${poly([[a2, 'x'], [b2, 'y']])} = ${c2} \\end{cases}$`,
      solutionSteps: [
          {
            viec: `Nhân phương trình thứ nhất với $${a2}$ và phương trình thứ hai với $${a1}$ để hệ số của $x$ bằng nhau.`,
            canCu: 'Nhân hai vế của một phương trình với cùng một số khác $0$ không làm đổi nghiệm, nên làm được để hệ số của một ẩn bằng nhau.',
          },
          {
            viec: `Trừ vế theo vế để khử $x$, chú ý đổi dấu toàn bộ vế bị trừ.`,
            canCu: 'Trừ vế theo vế hai phương trình có cùng hệ số của một ẩn thì ẩn đó bị khử.',
          },
          {
            viec: `Giải ra $y = ${y0}$.`,
            canCu: 'Phương trình còn lại chỉ một ẩn, giải như phương trình bậc nhất.',
          },
          {
            viec: `Thay $y = ${y0}$ vào phương trình đầu: $x = ${x0}$. Vậy $(x; y) = (${x0}; ${y0})$.`,
            canCu: 'Thay giá trị vừa tìm vào một phương trình ban đầu để tìm ẩn còn lại.',
          },
        ],
      hints: [
        'Chọn khử ẩn nào cho hệ số dễ làm chẵn hơn.',
        'Khi nhân một phương trình với số, phải nhân CẢ HAI VẾ.',
        'Khi trừ vế theo vế, mọi hạng tử của vế bị trừ đều đổi dấu.',
      ],
      answer: `(x; y) = (${x0}; ${y0})`,
      check: { expression: `${a1}*(${x0}) + (${b1})*(${y0})`, equals: String(c1) },
    }),
  },

  // ─────────────────────────── M7.TILE.THUCDAY ─────────────────────────────
  {
    id: 'BP.M7.TILE.CHIA_PHAN',
    formCode: 'M7.TILE.THUCDAY',
    intent: 'Dùng dãy tỉ số bằng nhau để chia một tổng theo tỉ lệ cho trước.',
    targetTrap: 'nhân chéo sai vị trí',
    context: 'thực tế — chia phần',
    shape: { steps: 4, cases: 1 },
    stars: 3,
    levels: [3, 5],
    space: function* () {
      for (const [p, q, r] of [[2, 3, 4], [3, 4, 5], [1, 2, 3], [2, 5, 7], [3, 5, 8], [4, 5, 6], [2, 3, 5]]) {
        for (const unit of [3, 5, 7, 10, 12, 15, 20]) {
          const total = (p + q + r) * unit;
          if (total > 400) continue;
          yield { p, q, r, unit, total };
        }
      }
    },
    render: ({ p, q, r, unit, total }) => ({
      stem: `Ba lớp 7A, 7B, 7C cùng trồng cây. Số cây của ba lớp tỉ lệ với $${p} : ${q} : ${r}$ và tổng số cây là $${total}$ cây. `
        + `Tính số cây mỗi lớp trồng được.`,
      solutionSteps: [
          {
            viec: `Gọi số cây ba lớp là $a$, $b$, $c$ (cây, $a,b,c \\in \\mathbb{N}^{*}$), ta có $\\dfrac{a}{${p}} = \\dfrac{b}{${q}} = \\dfrac{c}{${r}}$ và $a + b + c = ${total}$.`,
            canCu: 'Đặt ẩn kèm đơn vị và điều kiện; chia theo tỉ lệ cho một dãy tỉ số bằng nhau.',
          },
          {
            viec: `Áp dụng tính chất dãy tỉ số bằng nhau: $\\dfrac{a}{${p}} = \\dfrac{b}{${q}} = \\dfrac{c}{${r}} = \\dfrac{a+b+c}{${p}+${q}+${r}} = \\dfrac{${total}}{${p + q + r}} = ${unit}$.`,
            canCu: 'Tính chất dãy tỉ số bằng nhau: $\\dfrac{a}{m} = \\dfrac{b}{n} = \\dfrac{c}{p} = \\dfrac{a + b + c}{m + n + p}$.',
          },
          {
            viec: `Suy ra $a = ${p} \\cdot ${unit} = ${p * unit}$, $b = ${q} \\cdot ${unit} = ${q * unit}$, $c = ${r} \\cdot ${unit} = ${r * unit}$.`,
            canCu: 'Nhân giá trị chung vừa tìm với từng hệ số tỉ lệ để ra từng phần.',
          },
          {
            viec: `Kiểm tra: $${p * unit} + ${q * unit} + ${r * unit} = ${total}$ (đúng).`,
            canCu: 'Cộng ba phần lại phải bằng tổng ban đầu — bước kiểm bắt buộc.',
          },
        ],
      hints: [
        'Đặt ẩn cho số cây mỗi lớp, kèm điều kiện là số nguyên dương.',
        'Tính chất dãy tỉ số bằng nhau cho phép cộng cả tử và cả mẫu.',
        `Tổng các phần là $${p} + ${q} + ${r} = ${p + q + r}$ phần.`,
      ],
      answer: `7A: ${p * unit} cây; 7B: ${q * unit} cây; 7C: ${r * unit} cây`,
      check: { expression: `${p * unit} + ${q * unit} + ${r * unit}`, equals: String(total) },
    }),
  },

  // ─────────────────────────── M10.BPT.BAC2 ────────────────────────────────
  {
    id: 'BP.M10.BPT.XETDAU',
    formCode: 'M10.BPT.BAC2',
    intent: 'Lập bảng xét dấu tam thức và đọc đúng tập nghiệm — không học vẹt “trong trái ngoài cùng”.',
    targetTrap: 'sai bảng xét dấu',
    context: 'đại số thuần',
    shape: { steps: 4, cases: 2 },
    stars: 3,
    levels: [3, 5],
    space: function* () {
      for (const a of [1, 2, -1, -2]) {
        for (let r1 = -5; r1 <= 4; r1++) {
          for (let r2 = r1 + 1; r2 <= 5; r2++) {
            const b = -a * (r1 + r2);
            const c = a * r1 * r2;
            if (abs(b) > 30 || abs(c) > 50) continue;
            yield { a, b, c, r1, r2 };
          }
        }
      }
    },
    render: ({ a, b, c, r1, r2 }) => {
      const lhs = poly([[a, 'x^{2}'], [b, 'x'], [c, '']]);
      const inside = a > 0 ? `${r1} < x < ${r2}` : `x < ${r1} \\text{ hoặc } x > ${r2}`;
      return {
        stem: `Giải bất phương trình $${lhs} < 0$.`,
        solutionSteps: [
          {
            viec: `Xét tam thức $f(x) = ${lhs}$ với $a = ${a}$.`,
            canCu: 'Muốn xét dấu tam thức thì phải biết hệ số $a$ và các nghiệm của nó.',
          },
          {
            viec: `$f(x) = 0 \\Leftrightarrow x = ${r1}$ hoặc $x = ${r2}$ (hai nghiệm phân biệt).`,
            canCu: 'Giải phương trình bậc hai để tìm nghiệm — đó là các điểm mà tam thức đổi dấu.',
          },
          {
            viec: `Vì $a = ${a} ${a > 0 ? '> 0' : '< 0'}$, $f(x)$ ${a > 0 ? 'mang dấu âm trong khoảng hai nghiệm' : 'mang dấu âm ngoài khoảng hai nghiệm'}.`,
            canCu: 'Định lý về dấu tam thức: tam thức cùng dấu với $a$ ở ngoài khoảng hai nghiệm, trái dấu với $a$ ở trong khoảng hai nghiệm.',
          },
          {
            viec: `Tập nghiệm: $${inside}$.`,
            canCu: 'Đọc tập nghiệm từ bảng xét dấu theo chiều bất phương trình đề yêu cầu.',
          },
        ],
        hints: [
          'Tìm nghiệm của tam thức trước, rồi mới lập bảng xét dấu.',
          `Dấu của $a$ quyết định dấu của $f(x)$ ở hai đầu bảng — ở đây $a = ${a}$.`,
          'Bất phương trình là $f(x) < 0$, nên lấy phần bảng mang dấu âm.',
        ],
        answer: inside,
        check: { expression: `${a}*x^2 + (${b})*x + (${c})`, equals: `${a}*(x - ${r1})*(x - ${r2})` },
      };
    },
  },

  // ══════════ BỔ SUNG: phủ các tầng cao còn trống ══════════════════════════

  {
    id: 'BP.M9.VIET.NGHICH_DAO',
    formCode: 'M9.PT2.VIET',
    intent: 'Biến đổi biểu thức nghịch đảo về S và P — buộc học viên kiểm điều kiện P khác 0 trước khi viết phân thức.',
    targetTrap: 'dùng Vi-ét khi chưa có nghiệm',
    context: 'đại số thuần',
    shape: { steps: 4, cases: 1 },
    stars: 4,
    levels: [5, 7],
    space: function* () {
      for (let a = 1; a <= 3; a++) {
        for (let b = -11; b <= 11; b++) {
          for (let c = -11; c <= 11; c++) {
            if (c === 0) continue;                       // P ≠ 0 mới viết được nghịch đảo
            const d = b * b - 4 * a * c;
            if (d <= 0 || isPerfectSquare(d)) continue;
            yield { a, b, c, delta: d };
          }
        }
      }
    },
    render: ({ a, b, c, delta }) => {
      const val = fracValue(-b, c);                       // (x1+x2)/(x1·x2) = (−b/a)/(c/a) = −b/c
      return {
        stem: `Cho phương trình $${poly([[a, 'x^{2}'], [b, 'x'], [c, '']])} = 0$ có hai nghiệm $x_{1}, x_{2}$. `
          + `Không giải phương trình, hãy tính $\\dfrac{1}{x_{1}} + \\dfrac{1}{x_{2}}$.`,
        solutionSteps: [
          {
            viec: `$\\Delta = ${b}^{2} - 4 \\cdot ${a} \\cdot ${c} = ${delta} > 0$ nên phương trình có hai nghiệm phân biệt.`,
            canCu: 'Phải khẳng định phương trình có nghiệm trước khi dùng Vi-ét.',
          },
          {
            viec: `Theo Vi-ét: $S = ${frac(-b, a)}$, $P = ${frac(c, a)}$. Vì $P \\ne 0$ nên hai nghiệm đều khác 0, phân thức có nghĩa.`,
            canCu: 'Định lý Vi-ét cho $S$ và $P$. Thêm điều kiện $P \\ne 0$ vì mẫu của phân thức nghịch đảo là hai nghiệm.',
          },
          {
            viec: `$\\dfrac{1}{x_{1}} + \\dfrac{1}{x_{2}} = \\dfrac{x_{1} + x_{2}}{x_{1}x_{2}} = \\dfrac{S}{P}$.`,
            canCu: 'Quy đồng hai phân thức nghịch đảo thì tử thành tổng hai nghiệm, mẫu thành tích hai nghiệm.',
          },
          {
            viec: `$= ${frac(-b, c)} = ${round(val, 6)}$.`,
            canCu: 'Thay $S$ và $P$ vào, chú ý dấu khi $P$ âm.',
          },
        ],
        hints: [
          'Kiểm tra $\\Delta > 0$ và $P \\ne 0$ trước khi viết nghịch đảo.',
          'Quy đồng hai phân thức: mẫu chung là $x_{1}x_{2}$.',
          'Tử thành $x_{1} + x_{2}$, tức là $S$; mẫu là $P$.',
        ],
        answer: String(round(val, 6)),
        check: { expression: `(${-b}/${a}) / (${c}/${a})`, equals: String(round(val, 10)) },
      };
    },
  },

  {
    id: 'BP.M9.CAN.CONG_DONGDANG',
    formCode: 'M9.CAN.RUTGON',
    intent: 'Đưa các căn về cùng căn thức rồi mới cộng — chặn thói quen cộng thẳng số trong căn.',
    targetTrap: 'quên điều kiện xác định',
    context: 'đại số thuần',
    shape: { steps: 4, cases: 1 },
    stars: 3,
    levels: [4, 6],
    space: function* () {
      for (const base of [2, 3, 5, 6, 7, 10, 11, 13]) {
        for (let k1 = 2; k1 <= 5; k1++) {
          for (let k2 = k1 + 1; k2 <= 6; k2++) {
            const n1 = k1 * k1 * base;
            const n2 = k2 * k2 * base;
            if (n2 > 400) continue;
            yield { base, k1, k2, n1, n2 };
          }
        }
      }
    },
    render: ({ base, k1, k2, n1, n2 }) => ({
      stem: `Rút gọn: $\\sqrt{${n1}} + \\sqrt{${n2}}$.`,
      solutionSteps: [
          {
            viec: `Tách thừa số chính phương: $${n1} = ${k1 * k1} \\cdot ${base}$ và $${n2} = ${k2 * k2} \\cdot ${base}$.`,
            canCu: 'Muốn cộng được căn thì trước hết phải đưa chúng về cùng một căn thức, nên phải tách thừa số chính phương.',
          },
          {
            viec: `Đưa ra ngoài dấu căn: $\\sqrt{${n1}} = ${k1}\\sqrt{${base}}$, $\\sqrt{${n2}} = ${k2}\\sqrt{${base}}$.`,
            canCu: 'Quy tắc đưa thừa số ra ngoài dấu căn: $\\sqrt{k^{2}m} = k\\sqrt{m}$ với $k \\ge 0$.',
          },
          {
            viec: `Hai căn thức đã đồng dạng (cùng $\\sqrt{${base}}$) nên cộng được hệ số.`,
            canCu: 'Hai căn thức đồng dạng là hai căn có cùng phần căn; chỉ khi đó mới cộng được hệ số.',
          },
          {
            viec: `$= (${k1} + ${k2})\\sqrt{${base}} = ${k1 + k2}\\sqrt{${base}}$.`,
            canCu: 'Cộng hệ số và GIỮ NGUYÊN phần căn, giống như cộng các hạng tử đồng dạng trong đa thức.',
          },
        ],
      hints: [
        'Không cộng thẳng số dưới dấu căn — $\\sqrt{a} + \\sqrt{b} \\ne \\sqrt{a+b}$.',
        `Tìm thừa số chính phương lớn nhất của $${n1}$ và $${n2}$.`,
        'Chỉ cộng được khi phần dưới căn giống hệt nhau.',
      ],
      answer: `${k1 + k2}\\sqrt{${base}}`,
      check: { expression: `sqrt(${n1}) + sqrt(${n2})`, equals: `${k1 + k2}*sqrt(${base})` },
    }),
  },

  {
    id: 'BP.M5.PHANTRAM.TIM_GOC',
    formCode: 'M5.TISO.PHANTRAM',
    intent: 'Bài toán ngược: biết giá sau khi giảm, tìm giá gốc — chặn phản xạ cộng lại đúng số phần trăm đã giảm.',
    targetTrap: 'lấy nhầm số làm mốc 100%',
    context: 'thực tế — giá cả',
    shape: { steps: 4, cases: 1 },
    stars: 4,
    levels: [5, 6],
    space: function* () {
      for (const p of [10, 20, 25, 40, 50]) {
        for (const base of [240000, 360000, 480000, 600000, 720000, 900000, 1200000]) {
          const after = base * (100 - p) / 100;
          if (!Number.isInteger(after)) continue;
          yield { p, base, after };
        }
      }
    },
    render: ({ p, base, after }) => {
      const vnd = (x) => x.toLocaleString('vi-VN');
      return {
        stem: `Sau khi giảm giá $${p}\\%$, một mặt hàng có giá $${vnd(after)}$ đồng. Hỏi giá gốc của mặt hàng là bao nhiêu?`,
        solutionSteps: [
          {
            viec: `Giá gốc là mốc $100\\%$. Giảm $${p}\\%$ nghĩa là giá sau giảm bằng $${100 - p}\\%$ giá gốc.`,
            canCu: 'Giá gốc luôn là mốc $100\\%$; giảm $p\\%$ thì giá còn lại là $\\left(100 - p\\right)\\%$ của giá gốc.',
          },
          {
            viec: `Gọi giá gốc là $x$ (đồng, $x > 0$), ta có $x \\times \\dfrac{${100 - p}}{100} = ${vnd(after)}$.`,
            canCu: 'Đặt ẩn kèm đơn vị và điều kiện, rồi viết quan hệ thành phương trình.',
          },
          {
            viec: `$x = ${vnd(after)} \\div \\dfrac{${100 - p}}{100} = ${vnd(base)}$ đồng.`,
            canCu: 'Tìm số bị nhân thì lấy tích chia cho thừa số đã biết.',
          },
          {
            viec: `Thử lại: $${vnd(base)} \\times \\dfrac{${100 - p}}{100} = ${vnd(after)}$ (đúng).`,
            canCu: 'Thay kết quả trở lại điều kiện của đề để đối chiếu.',
          },
        ],
        hints: [
          'Mốc $100\\%$ ở đây là giá GỐC, không phải giá đã giảm.',
          `Giá sau giảm chiếm $${100 - p}\\%$ giá gốc.`,
          `Cộng lại $${p}\\%$ của giá đã giảm sẽ ra sai — vì hai mốc khác nhau.`,
        ],
        answer: `${vnd(base)} đồng`,
        check: { expression: `${after} / ((100 - ${p})/100)`, equals: String(base) },
      };
    },
  },

  {
    id: 'BP.M6.UCLN.CHIA_QUA',
    formCode: 'M6.UOCBOI.UCLNBCNN',
    intent: 'Nhận ra bài toán thực tế "chia đều nhiều loại" là bài toán ƯCLN, không phải BCNN.',
    targetTrap: 'nhầm quy tắc ƯCLN với BCNN',
    context: 'thực tế — chia phần',
    shape: { steps: 4, cases: 1 },
    stars: 4,
    levels: [4, 5],
    space: function* () {
      for (let g = 4; g <= 16; g += 2) {
        for (let m = 3; m <= 9; m++) {
          for (let n = m + 1; n <= 11; n++) {
            if (gcd(m, n) !== 1) continue;         // để ƯCLN đúng bằng g
            const a = g * m;
            const b = g * n;
            if (b > 200) continue;
            yield { g, a, b, m, n };
          }
        }
      }
    },
    render: ({ g, a, b, m, n }) => ({
      stem: `Cô giáo có $${a}$ quyển vở và $${b}$ chiếc bút. Cô muốn chia hết chúng vào các phần quà. `
        + 'Mỗi phần quà phải có số vở như nhau và số bút như nhau. '
        + 'Hỏi chia được nhiều nhất bao nhiêu phần quà? Mỗi phần có bao nhiêu vở và bao nhiêu bút?',
      solutionSteps: [
          {
            viec: `Số phần quà phải là ước chung của $${a}$ và $${b}$; muốn NHIỀU NHẤT thì lấy ước chung LỚN NHẤT.`,
            canCu: 'Số phần quà phải chia hết cả hai loại đồ, nên nó là ước chung của hai số. Muốn nhiều phần nhất thì lấy ước chung lớn nhất.',
          },
          {
            viec: `$\\text{ƯCLN}(${a}, ${b}) = ${g}$.`,
            canCu: 'Tìm ước chung lớn nhất bằng cách phân tích ra thừa số nguyên tố rồi lấy các thừa số chung với số mũ nhỏ nhất.',
          },
          {
            viec: `Vậy chia được nhiều nhất $${g}$ phần quà.`,
            canCu: 'Số phần quà chính bằng ước chung lớn nhất vừa tìm.',
          },
          {
            viec: `Mỗi phần có $${a} \\div ${g} = ${m}$ quyển vở và $${b} \\div ${g} = ${n}$ chiếc bút.`,
            canCu: 'Số đồ trong mỗi phần bằng tổng số đồ chia cho số phần; phép chia này luôn hết vì số phần là ước chung.',
          },
        ],
      hints: [
        'Chia ĐỀU cả hai loại nên số phần phải là ước chung của cả hai số.',
        '“Nhiều nhất” ứng với ƯCLN, không phải BCNN.',
        `Sau khi có số phần, lấy từng số chia cho nó để ra số đồ mỗi phần.`,
      ],
      answer: `${g} phần quà; mỗi phần ${m} quyển vở và ${n} chiếc bút`,
      check: { expression: `${g} * ${m}`, equals: String(a) },
    }),
  },

  {
    id: 'BP.M7.TILE.NGHICH',
    formCode: 'M7.TILE.THUCDAY',
    intent: 'Phân biệt tỉ lệ nghịch với tỉ lệ thuận qua bài toán năng suất — tích không đổi, không phải thương.',
    targetTrap: 'dùng dãy tỉ số khi mẫu có thể bằng 0',
    context: 'thực tế — năng suất',
    shape: { steps: 4, cases: 1 },
    stars: 4,
    levels: [4, 6],
    space: function* () {
      for (const k of [24, 36, 48, 60, 72, 90, 120]) {
        for (let n1 = 2; n1 <= 8; n1++) {
          if (k % n1 !== 0) continue;
          for (let n2 = n1 + 1; n2 <= 12; n2++) {
            if (k % n2 !== 0) continue;
            yield { k, n1, n2, d1: k / n1, d2: k / n2 };
          }
        }
      }
    },
    render: ({ k, n1, n2, d1, d2 }) => ({
      stem: `Một đội có $${n1}$ người làm xong một công việc trong $${d1}$ ngày. `
        + `Hỏi nếu đội có $${n2}$ người (năng suất mỗi người như nhau) thì làm xong công việc đó trong bao nhiêu ngày?`,
      solutionSteps: [
          {
            viec: `Số người và số ngày là hai đại lượng TỈ LỆ NGHỊCH: càng đông người thì càng ít ngày.`,
            canCu: 'Hai đại lượng tỉ lệ nghịch khi đại lượng này tăng bao nhiêu lần thì đại lượng kia giảm đúng bấy nhiêu lần.',
          },
          {
            viec: `Tổng khối lượng công việc không đổi: $${n1} \\times ${d1} = ${k}$ (ngày công).`,
            canCu: 'Với hai đại lượng tỉ lệ nghịch, TÍCH của chúng là một hằng số.',
          },
          {
            viec: `Gọi số ngày cần tìm là $x$ ($x > 0$), ta có $${n2} \\times x = ${k}$.`,
            canCu: 'Viết quan hệ tích không đổi thành phương trình theo ẩn cần tìm.',
          },
          {
            viec: `$x = ${k} \\div ${n2} = ${d2}$ ngày.`,
            canCu: 'Tìm thừa số chưa biết thì lấy tích chia cho thừa số đã biết.',
          },
        ],
      hints: [
        'Đông người hơn thì thời gian nhiều lên hay ít đi?',
        'Tỉ lệ nghịch thì TÍCH hai đại lượng không đổi (không phải thương).',
        `Tính tổng ngày công trước: $${n1} \\times ${d1} = ${k}$.`,
      ],
      answer: `${d2} ngày`,
      check: { expression: `${k} / ${n2}`, equals: String(d2) },
    }),
  },

  {
    id: 'BP.M8.PTBN.AN_O_MAU',
    formCode: 'M8.PT.BACNHAT',
    intent: 'Phương trình chứa ẩn ở mẫu — bắt buộc đặt điều kiện xác định và đối chiếu nghiệm trước khi kết luận.',
    targetTrap: 'chia hai vế cho biểu thức có thể bằng 0',
    context: 'đại số thuần',
    shape: { steps: 4, cases: 1 },
    stars: 4,
    levels: [4, 5],
    space: function* () {
      for (let m = 1; m <= 9; m++) {
        for (let k = 2; k <= 9; k++) {
          for (let x0 = -8; x0 <= 8; x0++) {
            if (x0 === m) continue;                  // nghiệm không được trùng điều kiện loại
            // (k·x + c)/(x − m) = k  vô lý; dùng dạng  a/(x − m) = b  →  x = m + a/b
            const a = (x0 - m) * k;
            if (a === 0 || Math.abs(a) > 60) continue;
            yield { m, k, a, x0 };
          }
        }
      }
    },
    render: ({ m, k, a, x0 }) => ({
      stem: `Giải phương trình $\\dfrac{${a}}{x - ${m}} = ${k}$.`,
      solutionSteps: [
          {
            viec: `Điều kiện xác định: $x - ${m} \\ne 0 \\Leftrightarrow x \\ne ${m}$.`,
            canCu: 'Phân thức chỉ xác định khi mẫu khác $0$; điều kiện này sẽ dùng lại ở bước cuối để nhận hay loại nghiệm.',
          },
          {
            viec: `Nhân hai vế với $x - ${m}$ (khác 0 theo điều kiện): $${a} = ${k}(x - ${m})$.`,
            canCu: 'Nhân hai vế với một biểu thức KHÁC $0$ là phép biến đổi tương đương; điều kiện ở bước một bảo đảm điều đó.',
          },
          {
            viec: `$x - ${m} = ${frac(a, k)}$, suy ra $x = ${m} + ${frac(a, k)} = ${x0}$.`,
            canCu: 'Giải phương trình bậc nhất thu được sau khi khử mẫu.',
          },
          {
            viec: `Đối chiếu điều kiện: $x = ${x0} \\ne ${m}$ nên nhận. Vậy nghiệm là $x = ${x0}$.`,
            canCu: 'Nghiệm tìm được phải nằm trong điều kiện xác định, nếu không thì phải loại.',
          },
        ],
      hints: [
        'Trước khi biến đổi phải đặt điều kiện cho mẫu khác 0.',
        'Chỉ được nhân hai vế với biểu thức khi biết chắc nó khác 0.',
        'Giải xong phải đối chiếu lại với điều kiện, nghiệm vi phạm thì loại.',
      ],
      answer: `x = ${x0}`,
      check: { equation: `${a}/(x - ${m}) = ${k}`, variable: 'x' },
    }),
  },

  {
    id: 'BP.M8.HDT.LAPPHUONG_TONG',
    formCode: 'M8.HANGDANGTHUC.BAY',
    intent: 'Khai triển lập phương của một tổng — phân biệt với bình phương và với tổng hai lập phương.',
    targetTrap: 'nhầm a³−b³ với (a−b)³',
    context: 'đại số thuần',
    shape: { steps: 4, cases: 1 },
    stars: 4,
    levels: [4, 5],
    space: function* () {
      for (let p = 1; p <= 5; p++) {
        for (let q = 1; q <= 6; q++) {
          if (gcd(p, q) !== 1) continue;
          yield { p, q };
        }
      }
    },
    render: ({ p, q }) => {
      const t3 = p * p * p, t2 = 3 * p * p * q, t1 = 3 * p * q * q, t0 = q * q * q;
      const full = poly([[t3, 'x^{3}'], [t2, 'x^{2}'], [t1, 'x'], [t0, '']]);
      return {
        stem: `Khai triển và thu gọn: $\\left( ${coef(p, 'x')} + ${q} \\right)^{3}$.`,
        solutionSteps: [
          {
            viec: `Áp dụng $(A + B)^{3} = A^{3} + 3A^{2}B + 3AB^{2} + B^{3}$ với $A = ${coef(p, 'x')}$, $B = ${q}$.`,
            canCu: 'Hằng đẳng thức thứ tư: $\\left(A + B\\right)^{3} = A^{3} + 3A^{2}B + 3AB^{2} + B^{3}$ — bốn hạng tử, không phải hai.',
          },
          {
            viec: `$A^{3} = ${t3}x^{3}$; $3A^{2}B = 3 \\cdot ${p * p} \\cdot ${q} = ${t2}$ (kèm $x^{2}$).`,
            canCu: 'Tính riêng hai hạng tử đầu để không nhầm hệ số $3$ ở hạng tử thứ hai.',
          },
          {
            viec: `$3AB^{2} = 3 \\cdot ${p} \\cdot ${q * q} = ${t1}$ (kèm $x$); $B^{3} = ${t0}$.`,
            canCu: 'Tính tiếp hai hạng tử sau, chú ý $B$ được bình phương ở hạng tử thứ ba.',
          },
          {
            viec: `Ghép lại: $= ${full}$.`,
            canCu: 'Ghép bốn hạng tử theo đúng thứ tự giảm dần của số mũ.',
          },
        ],
        hints: [
          'Lập phương của một tổng có BỐN hạng tử, không phải hai.',
          'Hệ số giữa đều là 3, đừng nhầm với hằng đẳng thức tổng hai lập phương.',
          `Chú ý bậc giảm dần: $x^{3}, x^{2}, x$, hằng số.`,
        ],
        answer: full,
        check: { expression: `(${p}*x + ${q})^3`, equals: `${t3}*x^3 + ${t2}*x^2 + ${t1}*x + ${t0}` },
      };
    },
  },

  // ══════════ TẦNG NỀN (L0–L2): tiểu học, chỗ mọi lộ trình bắt đầu ═════════

  {
    id: 'BP.M1.CONG10.TACHSO',
    formCode: 'M1.TINH.CONGTRU10',
    intent: 'Cộng trong phạm vi 10 bằng cách tách số, không đếm ngón — đặt nền cho cộng qua 10 về sau.',
    targetTrap: 'đếm cả số xuất phát khi đếm thêm',
    context: 'số học',
    shape: { steps: 3, cases: 1 },
    stars: 1,
    levels: [0, 2],
    space: function* () {
      for (let a = 2; a <= 8; a++) {
        for (let b = 2; b <= 8; b++) {
          if (a + b > 10 || a + b < 5) continue;
          yield { a, b, s: a + b };
        }
      }
    },
    render: ({ a, b, s }) => ({
      stem: `Tính: $${a} + ${b} = ?$`,
      solutionSteps: [
          {
            viec: `Đếm thêm $${b}$ đơn vị kể từ $${a}$ — bắt đầu đếm từ $${a + 1}$, KHÔNG đếm lại số $${a}$.`,
            canCu: 'Đếm thêm thì bắt đầu đếm từ số kế tiếp, không đếm lại số xuất phát.',
          },
          {
            viec: `Hoặc tách cho tròn chục: $${a} + ${b} = ${a} + ${10 - a} ${b - (10 - a) >= 0 ? `+ ${b - (10 - a)}` : ''}$.`,
            canCu: 'Tách một số thành tổng hai số nhỏ hơn thì tổng chung không đổi.',
          },
          {
            viec: `Kết quả: $${a} + ${b} = ${s}$.`,
            canCu: 'Viết lại kết quả của phép cộng.',
          },
        ],
      hints: [
        `Đặt $${a}$ trong đầu rồi đếm thêm $${b}$ lần.`,
        'Số đầu tiên đếm là số liền sau, không phải chính nó.',
        `Có thể dùng ngón tay nhưng phải nhớ: đếm $${b}$ ngón kể từ sau $${a}$.`,
      ],
      answer: String(s),
      check: { expression: `${a} + ${b}`, equals: String(s) },
    }),
  },

  {
    id: 'BP.M1.CONG20.QUA10',
    formCode: 'M1.TINH.CONGTRU20',
    intent: 'Cộng qua 10 bằng cách tách cho tròn chục — kỹ thuật nền của mọi phép cộng có nhớ sau này.',
    targetTrap: 'tách số sai khi cộng qua 10',
    context: 'số học',
    shape: { steps: 3, cases: 1 },
    stars: 2,
    levels: [1, 3],
    space: function* () {
      for (let a = 6; a <= 9; a++) {
        for (let b = 2; b <= 9; b++) {
          if (a + b <= 10 || a + b > 20) continue;
          yield { a, b, s: a + b, fill: 10 - a, rest: b - (10 - a) };
        }
      }
    },
    render: ({ a, b, s, fill, rest }) => ({
      stem: `Tính: $${a} + ${b} = ?$`,
      solutionSteps: [
          {
            viec: `Tách $${b}$ thành $${fill} + ${rest}$, vì $${a}$ còn thiếu $${fill}$ nữa là tròn $10$.`,
            canCu: 'Tách số hạng thứ hai sao cho phần tách ra vừa đủ làm số hạng thứ nhất tròn chục.',
          },
          {
            viec: `$${a} + ${fill} = 10$.`,
            canCu: 'Cộng cho tròn chục trước, vì phép cộng với số tròn chục dễ nhẩm hơn.',
          },
          {
            viec: `$10 + ${rest} = ${s}$. Vậy $${a} + ${b} = ${s}$.`,
            canCu: 'Cộng nốt phần còn lại vào số tròn chục. Tính chất kết hợp của phép cộng cho phép nhóm lại như vậy.',
          },
        ],
      hints: [
        `$${a}$ cần thêm mấy nữa thì tròn $10$?`,
        `Tách $${b} = ${fill} + ${rest}$.`,
        'Cộng cho tròn 10 trước, phần còn lại cộng sau.',
      ],
      answer: String(s),
      check: { expression: `${a} + ${b}`, equals: String(s) },
    }),
  },

  {
    id: 'BP.M2.TRU100.CONHO',
    formCode: 'M2.TINH.CONGTRU100',
    intent: 'Trừ có nhớ trong phạm vi 100 — nhắm đúng lỗi mượn 1 mà quên giảm hàng chục.',
    targetTrap: 'trừ có nhớ mà không giảm hàng chục',
    context: 'số học',
    shape: { steps: 3, cases: 1 },
    stars: 2,
    levels: [1, 3],
    space: function* () {
      for (let a = 21; a <= 98; a++) {
        for (let b = 12; b < a; b++) {
          if (a % 10 >= b % 10) continue;          // phải có mượn thì bài mới đúng ý đồ
          if (a - b < 5) continue;
          yield { a, b, d: a - b };
        }
      }
    },
    render: ({ a, b, d }) => ({
      stem: `Đặt tính rồi tính: $${a} - ${b} = ?$`,
      solutionSteps: [
          {
            viec: `Hàng đơn vị: $${a % 10} < ${b % 10}$ nên phải mượn $1$ chục, thành $${a % 10 + 10} - ${b % 10} = ${(a % 10 + 10) - (b % 10)}$.`,
            canCu: 'Khi chữ số bị trừ nhỏ hơn chữ số trừ thì phải mượn $1$ chục của hàng bên trái, tức mượn $10$ đơn vị.',
          },
          {
            viec: `Hàng chục: đã mượn $1$ nên $${Math.floor(a / 10)}$ chỉ còn $${Math.floor(a / 10) - 1}$; lấy $${Math.floor(a / 10) - 1} - ${Math.floor(b / 10)} = ${Math.floor(a / 10) - 1 - Math.floor(b / 10)}$.`,
            canCu: 'Đã mượn $1$ chục thì hàng chục phải giảm đi $1$ — đây là bước hay quên nhất.',
          },
          {
            viec: `Kết quả: $${a} - ${b} = ${d}$.`,
            canCu: 'Ghép kết quả của hai hàng lại theo đúng vị trí.',
          },
        ],
      hints: [
        'Trừ hàng đơn vị trước. Không trừ được thì mượn 1 chục.',
        'Mượn rồi thì hàng chục của số bị trừ phải BỚT đi 1.',
        `Kiểm tra lại bằng phép cộng: $${d} + ${b} = ${a}$?`,
      ],
      answer: String(d),
      check: { expression: `${a} - ${b}`, equals: String(d) },
    }),
  },

  {
    id: 'BP.M3.CHIA.SODU',
    formCode: 'M3.CHIA.CODU',
    intent: 'Phép chia có dư — buộc kiểm điều kiện số dư phải nhỏ hơn số chia.',
    targetTrap: 'để số dư lớn hơn hoặc bằng số chia',
    context: 'số học',
    shape: { steps: 3, cases: 1 },
    stars: 2,
    levels: [2, 4],
    space: function* () {
      for (let b = 3; b <= 9; b++) {
        for (let q = 3; q <= 12; q++) {
          for (let r = 1; r < b; r++) {
            const a = b * q + r;
            if (a > 99) continue;
            yield { a, b, q, r };
          }
        }
      }
    },
    render: ({ a, b, q, r }) => ({
      stem: `Thực hiện phép chia $${a} : ${b}$ rồi cho biết thương và số dư.`,
      solutionSteps: [
          {
            viec: `Tìm số lớn nhất nhân với $${b}$ mà không vượt quá $${a}$: $${b} \\times ${q} = ${b * q}$.`,
            canCu: 'Thương là số lớn nhất mà nhân với số chia vẫn không vượt quá số bị chia.',
          },
          {
            viec: `Số dư: $${a} - ${b * q} = ${r}$.`,
            canCu: 'Số dư bằng số bị chia trừ đi tích của thương và số chia.',
          },
          {
            viec: `Kiểm tra: $${r} < ${b}$ nên số dư hợp lệ. Vậy $${a} : ${b} = ${q}$ dư $${r}$.`,
            canCu: 'Điều kiện của phép chia có dư: số dư phải nhỏ hơn số chia. Nếu dư lớn hơn hoặc bằng số chia thì thương còn tăng được.',
          },
        ],
      hints: [
        `Nhẩm bảng nhân $${b}$ xem tới đâu thì chưa vượt $${a}$.`,
        'Số dư luôn phải NHỎ HƠN số chia.',
        `Thử lại: $${b} \\times ${q} + ${r}$ có bằng $${a}$ không?`,
      ],
      answer: `Thương ${q}, dư ${r}`,
      check: { expression: `${b} * ${q} + ${r}`, equals: String(a) },
    }),
  },

  {
    id: 'BP.M4.PHANSO.KHACMAU',
    formCode: 'M4.PHANSO.CONGTRU',
    intent: 'Cộng hai phân số khác mẫu — chặn đứng thói quen cộng thẳng tử với tử, mẫu với mẫu.',
    targetTrap: 'cộng thẳng tử với tử, mẫu với mẫu',
    context: 'số học',
    shape: { steps: 4, cases: 1 },
    stars: 3,
    levels: [2, 5],
    space: function* () {
      for (let b = 2; b <= 9; b++) {
        for (let d = b + 1; d <= 12; d++) {
          if (d % b === 0) continue;               // mẫu không chia hết nhau mới phải quy đồng thật
          for (let a = 1; a < b; a++) {
            for (let c = 1; c < d; c++) {
              if (gcd(a, b) !== 1 || gcd(c, d) !== 1) continue;
              const L = (b * d) / gcd(b, d);
              const num = a * (L / b) + c * (L / d);
              if (num >= L * 2) continue;          // giữ kết quả không quá 2, vừa sức tiểu học
              yield { a, b, c, d, L, num };
            }
          }
        }
      }
    },
    render: ({ a, b, c, d, L, num }) => ({
      stem: `Tính: $\\dfrac{${a}}{${b}} + \\dfrac{${c}}{${d}}$.`,
      solutionSteps: [
          {
            viec: `Hai mẫu khác nhau nên phải quy đồng. Mẫu chung nhỏ nhất của $${b}$ và $${d}$ là $${L}$.`,
            canCu: 'Chỉ cộng trực tiếp được khi hai phân số cùng mẫu, nên khác mẫu thì phải quy đồng trước.',
          },
          {
            viec: `$\\dfrac{${a}}{${b}} = \\dfrac{${a * (L / b)}}{${L}}$ và $\\dfrac{${c}}{${d}} = \\dfrac{${c * (L / d)}}{${L}}$.`,
            canCu: 'Quy đồng là nhân cả tử và mẫu với cùng một số khác $0$ — giá trị phân số không đổi.',
          },
          {
            viec: `Cộng tử, GIỮ NGUYÊN mẫu: $\\dfrac{${a * (L / b)} + ${c * (L / d)}}{${L}} = \\dfrac{${num}}{${L}}$.`,
            canCu: 'Cộng hai phân số cùng mẫu thì cộng tử và giữ nguyên mẫu.',
          },
          {
            viec: `Rút gọn nếu được: $= ${frac(num, L)}$.`,
            canCu: 'Rút gọn phân số về dạng tối giản bằng cách chia cả tử và mẫu cho ước chung lớn nhất.',
          },
        ],
      hints: [
        'Khác mẫu thì chưa cộng được, phải quy đồng trước.',
        `Mẫu chung của $${b}$ và $${d}$ là $${L}$.`,
        'Sau khi quy đồng thì chỉ cộng TỬ, mẫu giữ nguyên.',
      ],
      answer: frac(num, L),
      check: { expression: `${a}/${b} + ${c}/${d}`, equals: `${num}/${L}` },
    }),
  },

  {
    id: 'BP.M5.THAPPHAN.NHAN',
    formCode: 'M5.THAPPHAN.BONPHEP',
    intent: 'Nhân số thập phân — đếm đúng số chữ số ở phần thập phân để đặt dấu phẩy, không đặt theo cảm tính.',
    targetTrap: 'đặt dấu phẩy lệch khi nhân',
    context: 'số học',
    shape: { steps: 4, cases: 1 },
    stars: 3,
    levels: [2, 5],
    space: function* () {
      for (let x = 12; x <= 98; x++) {
        for (let y = 12; y <= 45; y++) {
          const prod = x * y;
          if (prod > 4000) continue;
          yield { x, y, prod };
        }
      }
    },
    render: ({ x, y, prod }) => {
      const A = (x / 10).toFixed(1);
      const B = (y / 10).toFixed(1);
      const P = (prod / 100).toFixed(2);
      return {
        stem: `Tính: $${A} \\times ${B}$.`,
        solutionSteps: [
          {
            viec: `Tạm bỏ dấu phẩy, nhân như số tự nhiên: $${x} \\times ${y} = ${prod}$.`,
            canCu: 'Nhân hai số thập phân trước hết nhân như hai số tự nhiên, dấu phẩy xử lý sau.',
          },
          {
            viec: `Đếm chữ số ở phần thập phân: $${A}$ có $1$ chữ số, $${B}$ có $1$ chữ số, tổng cộng $2$ chữ số.`,
            canCu: 'Số chữ số ở phần thập phân của tích bằng TỔNG số chữ số ở phần thập phân của hai thừa số.',
          },
          {
            viec: `Đặt dấu phẩy vào tích, tách $2$ chữ số từ phải sang: $${P}$.`,
            canCu: 'Đặt dấu phẩy bằng cách tách từ phải sang trái đúng số chữ số vừa đếm.',
          },
          {
            viec: `Vậy $${A} \\times ${B} = ${P}$.`,
            canCu: 'Viết lại kết quả đầy đủ để đối chiếu với đề bài.',
          },
        ],
        hints: [
          'Nhân như số tự nhiên trước, chưa quan tâm dấu phẩy.',
          'Đếm TỔNG số chữ số thập phân của cả hai thừa số.',
          'Tách đúng bấy nhiêu chữ số từ bên phải của tích.',
        ],
        answer: P,
        check: { expression: `${x}/10 * ${y}/10`, equals: `${prod}/100` },
      };
    },
  },

  // Bản thiết kế theo cấp học, tách tệp riêng cho dễ đọc và dễ soát.
  ...BP_TIEU_HOC,
  ...BP_THCS,
  ...BP_THPT,
  ...BP_LIEN_MON,
  ...BP_TIENG_ANH,
  ...BP_NEN_TANG,
  ...BP_THACH_THUC,
];

const BLUEPRINT_INDEX = new Map(BLUEPRINTS.map((b) => [b.id, b]));

function blueprintsForForm(formCode) {
  return BLUEPRINTS.filter((b) => b.formCode === formCode);
}

/** Soát danh mục bản thiết kế — chạy khi khởi động, sai là dừng ngay. */
function validateBlueprints(FORM_INDEX) {
  const errors = [];
  const seen = new Set();
  for (const b of BLUEPRINTS) {
    if (seen.has(b.id)) errors.push(`Trùng mã bản thiết kế: ${b.id}`);
    seen.add(b.id);
    const form = FORM_INDEX.get(b.formCode);
    if (!form) { errors.push(`${b.id}: không có dạng ${b.formCode}`); continue; }
    if (!b.intent || b.intent.length < 20) errors.push(`${b.id}: thiếu ý đồ sư phạm`);
    if (!form.traps.includes(b.targetTrap)) {
      errors.push(`${b.id}: bẫy "${b.targetTrap}" không nằm trong danh mục bẫy của ${b.formCode}`);
    }
    const [lo, hi] = form.levelRange;
    if (!Array.isArray(b.levels) || b.levels[0] < lo || b.levels[1] > hi) {
      errors.push(`${b.id}: tầng ${JSON.stringify(b.levels)} nằm ngoài ${JSON.stringify(form.levelRange)} của dạng`);
    }
    if (typeof b.space !== 'function' || typeof b.render !== 'function') errors.push(`${b.id}: thiếu space hoặc render`);
  }
  // Mỗi dạng có bản thiết kế thì nên có ít nhất 2 ý đồ khác nhau, tránh đơn điệu.
  const byForm = {};
  for (const b of BLUEPRINTS) (byForm[b.formCode] ??= []).push(b.intent);
  return {
    ok: errors.length === 0,
    errors,
    blueprints: BLUEPRINTS.length,
    forms: Object.keys(byForm).length,
    intentsPerForm: Object.fromEntries(Object.entries(byForm).map(([k, v]) => [k, v.length])),
  };
}

module.exports = {
  BLUEPRINTS, BLUEPRINT_INDEX, blueprintsForForm, validateBlueprints,
  gcd, isPerfectSquare, poly, frac, coef,
};
