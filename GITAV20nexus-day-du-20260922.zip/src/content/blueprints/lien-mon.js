'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BẢN THIẾT KẾ BÀI — LIÊN MÔN VÀ TƯ DUY (nhóm X)
 * ═══════════════════════════════════════════════════════════════════════════
 *  Nhóm này không thuộc một lớp nào. Nó đo thứ mà đề thi đánh giá năng lực
 *  thật sự hỏi: đọc được dữ liệu, suy luận đúng luật, và BIẾT DỪNG LẠI ở chỗ
 *  dữ liệu hết nói.
 *
 *  Điểm chung của sáu dạng dưới đây: câu hỏi đưa ra luôn TÍNH ĐƯỢC ra một con
 *  số, nên máy kiểm được đáp án; còn phần dạy — vì sao mệnh đề đảo không đúng,
 *  vì sao tương quan không phải nhân quả — nằm trong lời giải, nơi nó thuộc về.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { tiSo } = require('./thpt');

const BP_LIEN_MON = [
  {
    id: 'BP.X.SUYLUAN.MENHDEDAO',
    formCode: 'X.LOGIC.SUYLUAN',
    intent: 'Mệnh đề kéo theo đúng KHÔNG kéo theo mệnh đề đảo cũng đúng — phải bác bằng một phản ví dụ cụ thể, không bác bằng cảm giác.',
    targetTrap: 'đảo ngược mệnh đề kéo theo',
    context: 'logic',
    shape: { steps: 5, cases: 2 },
    stars: 4,
    levels: [3, 7],
    space: function* () {
      for (let a = 2; a <= 9; a++) {
        for (let b = 2; b <= 7; b++) {
          if (a * b > 45) continue;
          for (const tu of [10, 20, 30, 50, 80, 120]) {
            // Phản ví dụ NHỎ NHẤT lớn hơn "tu": bội của a, không phải bội của a·b.
            let n0 = null;
            for (let k = Math.floor(tu / a) + 1; k <= Math.floor(tu / a) + b + 2; k++) {
              const n = a * k;
              if (n > tu && n % (a * b) !== 0) { n0 = n; break; }
            }
            if (n0 === null) continue;
            yield { a, b, tu, n0, c: n0 / a };
          }
        }
      }
    },
    render: ({ a, b, tu, n0, c }) => ({
      stem: `Xét mệnh đề $P$: "Nếu một số tự nhiên chia hết cho $${a * b}$ thì nó chia hết cho $${a}$." `
        + `Mệnh đề $P$ đúng. Hỏi mệnh đề ĐẢO của $P$ có đúng không? `
        + `Nếu sai, hãy chỉ ra phản ví dụ NHỎ NHẤT lớn hơn $${tu}$.`,
      solutionSteps: [
          {
            viec: `Mệnh đề đảo của $P$ là: "Nếu một số tự nhiên chia hết cho $${a}$ thì nó chia hết cho $${a * b}$."`,
            canCu: 'Mệnh đề đảo của "nếu $P$ thì $Q$" là "nếu $Q$ thì $P$" — đổi chỗ giả thiết và kết luận.',
          },
          {
            viec: `Muốn bác một mệnh đề dạng "nếu… thì…", chỉ cần MỘT số vừa thoả giả thiết vừa không thoả kết luận.`,
            canCu: 'Mệnh đề dạng kéo theo là khẳng định với MỌI trường hợp, nên chỉ cần một phản ví dụ là bác được.',
          },
          {
            viec: `Lần lượt xét các bội của $${a}$ lớn hơn $${tu}$ và loại những số đồng thời là bội của $${a * b}$.`,
            canCu: 'Tìm phản ví dụ bằng cách duyệt các số thoả giả thiết rồi loại dần các số cũng thoả kết luận.',
          },
          {
            viec: `Số đầu tiên còn lại là $n = ${n0} = ${a} \\times ${c}$: chia hết cho $${a}$, nhưng $${c}$ không chia hết cho $${b}$ nên $${n0}$ không chia hết cho $${a * b}$.`,
            canCu: 'Số còn lại vừa thoả giả thiết vừa không thoả kết luận, đúng là phản ví dụ cần tìm.',
          },
          {
            viec: `Vậy mệnh đề đảo SAI, với phản ví dụ nhỏ nhất lớn hơn $${tu}$ là $n = ${n0}$. Mệnh đề $P$ đúng không nói gì về chiều ngược lại.`,
            canCu: 'Một mệnh đề kéo theo đúng KHÔNG bảo đảm mệnh đề đảo của nó cũng đúng — hai chiều là hai khẳng định độc lập.',
          },
        ],
      hints: [
        'Viết mệnh đề đảo ra giấy trước: đổi chỗ giả thiết và kết luận, giữ nguyên mọi thứ khác.',
        'Bác một mệnh đề tổng quát chỉ cần MỘT phản ví dụ; chứng minh nó đúng thì phải đúng với MỌI số.',
        `Duyệt bội của $${a}$ theo thứ tự tăng dần thì phản ví dụ tìm được chắc chắn là nhỏ nhất.`,
      ],
      answer: `Mệnh đề đảo sai; phản ví dụ nhỏ nhất là n = ${n0}`,
      // Biểu thức này bằng 0 KHI VÀ CHỈ KHI n₀ là phản ví dụ hợp lệ:
      //   số hạng đầu  = 0 ⇔ n₀ chia hết cho a
      //   số hạng sau  = 0 ⇔ n₀ KHÔNG chia hết cho a·b
      check: {
        expression: `abs(${n0} - ${a}*floor(${n0}/${a})) + (1 - sign(abs(${n0} - ${a * b}*floor(${n0}/${a * b}))))`,
        equals: `0`,
      },
    }),
  },
  {
    id: 'BP.X.DAYSO.SAIPHANBAC2',
    formCode: 'X.LOGIC.DAYSO',
    intent: 'Dãy có sai phân bậc nhất KHÔNG đều nhưng sai phân bậc hai đều — dừng ở bậc nhất là đoán sai số tiếp theo.',
    targetTrap: 'dừng ở quy luật bậc nhất khi thực tế là bậc hai',
    context: 'quy luật số',
    shape: { steps: 5, cases: 1 },
    stars: 4,
    levels: [2, 7],
    space: function* () {
      for (let a = 1; a <= 4; a++) {
        for (let b = -5; b <= 5; b++) {
          for (let c = -5; c <= 5; c++) {
            const u1 = a + b + c;
            if (u1 <= 0) continue;                 // dãy bắt đầu bằng số dương cho dễ đọc
            yield { a, b, c };
          }
        }
      }
    },
    render: ({ a, b, c }) => {
      const u = (n) => a * n * n + b * n + c;
      const day = [1, 2, 3, 4, 5].map(u);
      const hieu1 = [0, 1, 2, 3].map((i) => day[i + 1] - day[i]);
      const u6 = u(6);
      return {
        stem: `Cho dãy số: $${day.join(';\\ ')};\\ \\ldots$ Tìm số hạng tiếp theo và nêu quy luật.`,
        solutionSteps: [
          {
            viec: `Tính hiệu hai số liên tiếp (sai phân bậc nhất): $${hieu1.join(';\\ ')}$.`,
            canCu: 'Bước đầu tiên khi tìm quy luật dãy số luôn là xét hiệu hai số liên tiếp.',
          },
          {
            viec: `Các hiệu này KHÔNG bằng nhau, nên dãy không phải cấp số cộng — chưa được dừng ở đây.`,
            canCu: 'Hiệu không đều thì dãy không phải cấp số cộng, nhưng chưa kết luận được là vô quy luật.',
          },
          {
            viec: `Tính hiệu của các hiệu (sai phân bậc hai): $${[0, 1, 2].map((i) => hieu1[i + 1] - hieu1[i]).join(';\\ ')}$ — tất cả đều bằng $${2 * a}$.`,
            canCu: 'Xét tiếp hiệu CỦA CÁC HIỆU: đây là bước phân biệt dãy bậc hai với dãy vô quy luật.',
          },
          {
            viec: `Sai phân bậc hai không đổi nghĩa là số hạng tổng quát có dạng bậc hai: $u_{n} = ${a}n^{2} ${b >= 0 ? '+' : '-'} ${Math.abs(b)}n ${c >= 0 ? '+' : '-'} ${Math.abs(c)}$.`,
            canCu: 'Sai phân bậc hai không đổi thì số hạng tổng quát là một đa thức bậc hai theo $n$.',
          },
          {
            viec: `Số hạng thứ sáu: $u_{6} = ${a} \\cdot 36 ${b >= 0 ? '+' : '-'} ${Math.abs(b)} \\cdot 6 ${c >= 0 ? '+' : '-'} ${Math.abs(c)} = ${u6}$.`,
            canCu: 'Có công thức tổng quát thì tính được số hạng ở bất kỳ vị trí nào, không cần cộng dồn.',
          },
        ],
        hints: [
          'Thấy hiệu không đều thì đừng bỏ cuộc — lấy hiệu của hiệu một lần nữa.',
          'Sai phân bậc hai không đổi ⇔ số hạng tổng quát là đa thức bậc hai.',
          `Kiểm tra lại công thức bằng cách thay $n = 1, 2, 3$ và đối chiếu với dãy đã cho.`,
        ],
        answer: `${u6}`,
        check: { expression: `${a}*6^2 + (${b})*6 + (${c})`, equals: `${u6}` },
      };
    },
  },
  {
    id: 'BP.X.SAPXEP.KHOILIENKE',
    formCode: 'X.LOGIC.SAPXEP',
    intent: 'Buộc một nhóm đứng liền nhau thì phải nhân thêm số cách hoán vị BÊN TRONG nhóm — quên phần này là bỏ sót hàng loạt phương án.',
    targetTrap: 'bỏ sót một phương án thoả mãn',
    context: 'tổ hợp thực tế',
    shape: { steps: 5, cases: 1 },
    stars: 4,
    levels: [3, 7],
    space: function* () {
      for (let n = 4; n <= 9; n++) {
        for (let k = 2; k <= Math.min(4, n - 1); k++) yield { n, k };
      }
    },
    render: ({ n, k }) => {
      const giaiThua = (x) => { let r = 1; for (let i = 2; i <= x; i++) r *= i; return r; };
      const khoi = n - k + 1;
      const so = giaiThua(khoi) * giaiThua(k);
      return {
        stem: `Một tổ có $${n}$ học viên xếp thành một hàng dọc. Có $${k}$ bạn trong tổ muốn đứng LIỀN NHAU (theo thứ tự nào cũng được). `
          + 'Hỏi có bao nhiêu cách xếp hàng?',
        solutionSteps: [
          {
            viec: `Coi $${k}$ bạn muốn đứng liền nhau là MỘT KHỐI. Khi đó hàng chỉ còn $${khoi}$ vị trí cần xếp.`,
            canCu: 'Ràng buộc "phải đứng liền nhau" xử lý bằng cách coi nhóm đó là MỘT đối tượng duy nhất — bài toán có ràng buộc trở thành bài toán không ràng buộc.',
          },
          {
            viec: `Số cách xếp $${khoi}$ đối tượng (gồm khối và $${n - k}$ bạn còn lại): $${khoi}! = ${giaiThua(khoi)}$.`,
            canCu: 'Số cách xếp $n$ đối tượng phân biệt thành một hàng là $n!$.',
          },
          {
            viec: `Bên TRONG khối, $${k}$ bạn còn đổi chỗ được cho nhau: $${k}! = ${giaiThua(k)}$ cách.`,
            canCu: 'Bên trong khối, các thành viên vẫn hoán vị được cho nhau.',
          },
          {
            viec: `Hai việc trên độc lập nên nhân lại: $${khoi}! \\times ${k}! = ${giaiThua(khoi)} \\times ${giaiThua(k)} = ${so}$.`,
            canCu: 'Quy tắc nhân: hai việc độc lập thì số cách bằng tích số cách của từng việc.',
          },
          {
            viec: `Quên nhân $${k}!$ là chỉ đếm được $${giaiThua(khoi)}$ cách — bỏ sót $${so - giaiThua(khoi)}$ phương án hoàn toàn hợp lệ.`,
            canCu: 'Quên nhân số cách hoán vị bên trong khối là bỏ sót đúng một nửa số phương án.',
          },
        ],
        hints: [
          'Gộp nhóm phải đứng liền thành một khối là bước đúng, nhưng chưa phải bước cuối.',
          `Hỏi thêm: trong khối đó, đổi chỗ hai bạn thì hàng có khác đi không? Có — nên phải đếm.`,
          'Quy tắc nhân áp dụng được vì hai lựa chọn không ảnh hưởng lẫn nhau.',
        ],
        answer: `${so} cách`,
        check: { expression: `${khoi}!*${k}!`, equals: `${so}` },
      };
    },
  },
  {
    id: 'BP.X.BIEUDO.DIEMPHANTRAM',
    formCode: 'X.SOLIEU.BIEUDO',
    intent: 'Phân biệt tăng bao nhiêu ĐIỂM PHẦN TRĂM với tăng bao nhiêu PHẦN TRĂM — hai con số khác nhau, và báo chí hay dùng lẫn.',
    targetTrap: 'nhầm phần trăm tương đối và tuyệt đối',
    context: 'đọc số liệu',
    shape: { steps: 5, cases: 1 },
    stars: 3,
    levels: [2, 6],
    space: function* () {
      for (let p1 = 15; p1 <= 60; p1 += 5) {
        for (let p2 = p1 + 5; p2 <= 85; p2 += 5) yield { p1, p2 };
      }
    },
    render: ({ p1, p2 }) => {
      const diem = p2 - p1;
      const tuongDoi = tiSo(100 * diem, p1);
      const tdTex = tuongDoi.includes('/') ? `\\dfrac{${tuongDoi.split('/')[0]}}{${tuongDoi.split('/')[1]}}` : tuongDoi;
      return {
        stem: `Một khảo sát cho biết tỉ lệ học viên tự học ở nhà là $${p1}\\%$ vào năm ngoái và $${p2}\\%$ vào năm nay. `
          + 'Hỏi tỉ lệ đó đã tăng bao nhiêu ĐIỂM PHẦN TRĂM, và tăng bao nhiêu PHẦN TRĂM?',
        solutionSteps: [
          {
            viec: `Điểm phần trăm là HIỆU của hai tỉ lệ: $${p2}\\% - ${p1}\\% = ${diem}$ điểm phần trăm.`,
            canCu: 'Điểm phần trăm là HIỆU của hai tỉ lệ phần trăm — một phép trừ, không phải phép chia.',
          },
          {
            viec: `Phần trăm tăng là so sánh phần tăng thêm với mức CŨ: $\\dfrac{${p2} - ${p1}}{${p1}} \\times 100\\%$.`,
            canCu: 'Phần trăm tăng là so phần tăng thêm với mức CŨ — một phép chia, mẫu số là giá trị gốc.',
          },
          {
            viec: `$= \\dfrac{${diem}}{${p1}} \\times 100\\% = ${tdTex}\\%$.`,
            canCu: 'Nhân với $100\\%$ để chuyển tỉ số thành phần trăm.',
          },
          {
            viec: `Hai con số $${diem}$ và $${tdTex}$ trả lời hai câu hỏi khác nhau, không thay thế cho nhau được.`,
            canCu: 'Hai con số trả lời hai câu hỏi khác nhau, nên không thay thế cho nhau được.',
          },
          {
            viec: `Câu "tăng $${diem}\\%$" là cách nói SAI nếu ý muốn nói hiệu hai tỉ lệ — phải nói "tăng $${diem}$ điểm phần trăm".`,
            canCu: 'Gọi hiệu hai tỉ lệ là "tăng bao nhiêu phần trăm" là cách nói sai — phải nói "điểm phần trăm".',
          },
        ],
        hints: [
          'Hỏi "tăng bao nhiêu phần trăm" thì luôn phải chia cho mức GỐC.',
          'Điểm phần trăm là phép trừ; phần trăm tăng là phép chia rồi nhân trăm.',
          'Mức gốc là số liệu năm trước, không phải năm nay.',
        ],
        answer: `tăng ${diem} điểm phần trăm; tăng ${tuongDoi}%`,
        check: { expression: `(${p2} - ${p1})/${p1}*100`, equals: tuongDoi },
      };
    },
  },
  {
    id: 'BP.X.KHTN.DOIDONVI',
    formCode: 'X.KHTN.CONGTHUC',
    intent: 'Công thức vật lý chỉ đúng khi mọi đại lượng đã về đơn vị chuẩn SI — thay số thô vào công thức là nguồn sai phổ biến nhất.',
    targetTrap: 'sai đơn vị chuẩn SI',
    context: 'vật lý ứng dụng',
    shape: { steps: 5, cases: 1 },
    stars: 4,
    levels: [2, 6],
    space: function* () {
      for (const s of [1.2, 1.8, 2.4, 3, 3.6, 4.5, 5.4, 6, 7.2, 9]) {
        for (const t of [2, 3, 4, 5, 6, 10, 12, 15]) {
          const v = (s * 1000) / (t * 60);
          if (!Number.isInteger(v * 10)) continue;
          yield { s, t, v };
        }
      }
    },
    render: ({ s, t, v }) => {
      const viet = (x) => String(x).replace('.', '{,}');
      return {
        stem: `Một người đi bộ được quãng đường $${viet(s)}$ km trong $${t}$ phút. Tính vận tốc trung bình của người đó theo đơn vị mét trên giây $\\left(\\mathrm{m/s}\\right)$.`,
        solutionSteps: [
          {
            viec: `Công thức $v = \\dfrac{s}{t}$ chỉ cho kết quả theo $\\mathrm{m/s}$ khi $s$ tính bằng MÉT và $t$ tính bằng GIÂY.`,
            canCu: 'Mọi công thức vật lý chỉ đúng khi các đại lượng đã ở đúng hệ đơn vị mà công thức giả định.',
          },
          {
            viec: `Đổi quãng đường: $${viet(s)}$ km $= ${viet(s)} \\times 1000 = ${s * 1000}$ m.`,
            canCu: 'Đổi đơn vị độ dài: $1$ ki-lô-mét bằng $1000$ mét.',
          },
          {
            viec: `Đổi thời gian: $${t}$ phút $= ${t} \\times 60 = ${t * 60}$ s.`,
            canCu: 'Đổi đơn vị thời gian: $1$ phút bằng $60$ giây.',
          },
          {
            viec: `$v = \\dfrac{${s * 1000}}{${t * 60}} = ${viet(v)}$ m/s.`,
            canCu: 'Thay số đã đổi vào công thức để ra kết quả đúng đơn vị.',
          },
          {
            viec: `Nếu thay thẳng $${viet(s)}$ và $${t}$ vào công thức sẽ ra $${viet(Math.round((s / t) * 1000) / 1000)}$ — con số này có đơn vị km/phút, không phải m/s.`,
            canCu: 'Thay thẳng số chưa đổi thì vẫn ra một con số, nhưng con số ấy mang đơn vị khác — sai mà không lộ.',
          },
        ],
        hints: [
          'Đổi đơn vị TRƯỚC khi thay vào công thức, không đổi sau.',
          '$1$ km $= 1000$ m và $1$ phút $= 60$ s — đổi cả hai, đừng đổi một cái.',
          `Ước lượng để tự kiểm: người đi bộ thường nhanh khoảng $1$ đến $2$ m/s.`,
        ],
        answer: `${viet(v)} m/s`,
        check: { expression: `${s}*1000/(${t}*60)`, equals: `${v}` },
      };
    },
  },
  {
    id: 'BP.X.DOCHIEU.TUONGQUAN',
    formCode: 'X.DOCHIEU.KHOAHOC',
    intent: 'Đọc số liệu của một nghiên cứu: tính được tỉ lệ so sánh, nhưng phải dừng đúng chỗ — số liệu quan sát không chứng minh được nguyên nhân.',
    targetTrap: 'suy diễn vượt quá dữ liệu bài cho',
    context: 'đọc hiểu khoa học',
    shape: { steps: 5, cases: 1 },
    stars: 4,
    levels: [4, 8],
    space: function* () {
      for (const nA of [200, 250, 300, 400, 500]) {
        for (const nB of [200, 250, 300, 400, 500]) {
          for (const kA of [24, 30, 36, 40, 48, 60]) {
            for (const kB of [10, 12, 15, 20, 24]) {
              if (kA > nA / 4 || kB > nB / 4) continue;
              const tiA = kA / nA;
              const tiB = kB / nB;
              if (!(tiA > tiB)) continue;
              yield { nA, nB, kA, kB };
            }
          }
        }
      }
    },
    render: ({ nA, nB, kA, kB }) => {
      const pA = tiSo(100 * kA, nA);
      const pB = tiSo(100 * kB, nB);
      const lan = tiSo(kA * nB, kB * nA);
      const tex = (r) => (r.includes('/') ? `\\dfrac{${r.split('/')[0]}}{${r.split('/')[1]}}` : r);
      return {
        stem: `Một nghiên cứu quan sát theo dõi hai nhóm học viên trong một năm. Nhóm A gồm $${nA}$ em có dùng ứng dụng học tập, `
          + `trong đó $${kA}$ em đạt loại giỏi. Nhóm B gồm $${nB}$ em không dùng ứng dụng, trong đó $${kB}$ em đạt loại giỏi. `
          + `Tính tỉ lệ đạt loại giỏi của mỗi nhóm và cho biết tỉ lệ ở nhóm A gấp bao nhiêu lần nhóm B. `
          + `Từ số liệu này, có kết luận được rằng ứng dụng LÀM CHO học viên học giỏi hơn không?`,
        solutionSteps: [
          {
            viec: `Tỉ lệ nhóm A: $\\dfrac{${kA}}{${nA}} = ${tex(pA)}\\%$.`,
            canCu: 'Tỉ lệ bằng số trường hợp quan tâm chia cho cỡ nhóm, rồi nhân $100\\%$.',
          },
          {
            viec: `Tỉ lệ nhóm B: $\\dfrac{${kB}}{${nB}} = ${tex(pB)}\\%$.`,
            canCu: 'Tính tương tự cho nhóm thứ hai, chú ý mẫu số là cỡ của chính nhóm đó.',
          },
          {
            viec: `Tỉ lệ nhóm A gấp nhóm B: lấy tỉ lệ nhóm A chia cho tỉ lệ nhóm B, được $${tex(lan)}$ lần.`,
            canCu: 'So sánh hai tỉ lệ bằng phép chia thì ra số LẦN; bằng phép trừ thì ra điểm phần trăm.',
          },
          {
            viec: `Số liệu cho thấy có TƯƠNG QUAN: nhóm dùng ứng dụng có tỉ lệ giỏi cao hơn.`,
            canCu: 'Số liệu cho thấy hai nhóm khác nhau — đó là tương quan, và tương quan là một kết luận hợp lệ.',
          },
          {
            viec: `Nhưng KHÔNG kết luận được về nguyên nhân. Đây là nghiên cứu QUAN SÁT, hai nhóm tự chọn chứ không được chia ngẫu nhiên; `
            + `rất có thể những em vốn chăm học mới đi tìm ứng dụng để dùng. Muốn nói về nguyên nhân thì phải có thử nghiệm phân nhóm ngẫu nhiên.`,
            canCu: 'Nghiên cứu QUAN SÁT không chia nhóm ngẫu nhiên nên yếu tố gây nhiễu chưa bị loại trừ; muốn kết luận nhân quả phải có thiết kế khác.',
          },
        ],
        hints: [
          'Tính tỉ lệ trước, đừng so sánh số tuyệt đối khi hai nhóm có cỡ khác nhau.',
          'Hỏi "gấp bao nhiêu lần" là so sánh hai TỈ LỆ, không phải hai số đếm.',
          'Trước khi kết luận nguyên nhân, hỏi: hai nhóm được chia thế nào? Ai quyết định ai vào nhóm nào?',
        ],
        answer: `nhóm A ${pA}%, nhóm B ${pB}%, gấp ${lan} lần; KHÔNG kết luận được nhân quả`,
        check: { expression: `(${kA}/${nA})/(${kB}/${nB})`, equals: lan },
      };
    },
  },
];

module.exports = { BP_LIEN_MON };
