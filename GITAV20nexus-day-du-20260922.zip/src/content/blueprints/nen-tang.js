'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BẢN THIẾT KẾ BÀI — BẬC NHẬN BIẾT VÀ THÔNG HIỂU TRÊN NỀN KIẾN THỨC CAO
 * ═══════════════════════════════════════════════════════════════════════════
 *  VÌ SAO CÓ TỆP NÀY
 *
 *  Kho bài cũ có một chỗ lệch nặng: càng lên tầng cao thì càng chỉ còn bài
 *  bốn sao. Tầng 8 trước đây có đúng sáu bản thiết kế, tất cả đều bốn sao.
 *  Hệ quả là không dựng nổi một đề đúng ma trận cho tầng cao — phần "Nhận
 *  biết" và "Thông hiểu" không có bài nào để lấy.
 *
 *  Điều đó KHÔNG có nghĩa là tầng cao thì không có câu nhận biết. Một thí
 *  sinh lớp 12 vẫn phải nhớ bảng nguyên hàm, vẫn phải đọc được tâm và bán
 *  kính từ phương trình mặt cầu. Đó đúng là câu một sao, nhưng nằm trên nền
 *  kiến thức của tầng 7, tầng 8. Bài ở đây nhắm đúng chỗ đó:
 *
 *    · MỘT SAO  = nhớ lại một công thức hoặc đọc thẳng một giá trị. Một bước.
 *    · HAI SAO  = áp dụng đúng một công thức vào số liệu cho sẵn. Hai đến ba bước.
 *
 *  Bài một sao mà phải suy luận ba bước thì nó không còn là một sao nữa, và
 *  đề dựng ra sẽ khó hơn bảng công bố. Nên mỗi bản dưới đây đều bị giữ đúng
 *  số bước của bậc mình.
 *
 *  MÁY KIỂM BẰNG GÌ
 *  Không bài nào tự chấm mình bằng chính công thức đã dùng trong lời giải —
 *  như thế chỉ là chép lại đáp án. Mỗi bài gắn một phép kiểm ĐỘC LẬP:
 *    · Đạo hàm      → đồng nhất thức sai phân, đúng tuyệt đối với mọi h.
 *    · Nguyên hàm   → Simpson, chính xác tuyệt đối với đa thức bậc ≤ 3.
 *    · Cấp số       → đối chiếu hai công thức tổng khác nhau của cùng một dãy.
 *    · Dãy quy luật → kiểm hiệu (hoặc tích chéo) chứ không kiểm số hạng.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { frac, poly, TEN } = require('./chung');
const { simpson, gauss, tiSo, capPytago } = require('./kiem-so');

const BP_NEN_TANG = [

  // ══ MỘT SAO — NHỚ LẠI MỘT CÔNG THỨC ════════════════════════════════════

  {
    id: 'BP.NB.DAOHAM.TAIMOTDIEM',
    formCode: 'M11.DAOHAM.QUYTAC',
    intent: 'Nhớ đạo hàm của đa thức bậc hai rồi thay số. Một bước, không có bẫy nào ngoài chính công thức.',
    targetTrap: 'sai quy tắc đạo hàm của luỹ thừa',
    context: 'đại số',
    shape: { steps: 2, cases: 1 },
    stars: 1,
    levels: [3, 6],
    space: function* () {
      for (const a of [1, 2, 3, -1, -2]) {
        for (const b of [-6, -4, -3, 1, 3, 5]) {
          for (const x0 of [-2, -1, 1, 2, 3]) {
            if (a === 1 && b === 1 && x0 === 1) continue;
            yield { a, b, c: 4, x0 };
          }
        }
      }
    },
    render: ({ a, b, c, x0 }) => {
      const ve = poly([[a, 'x^{2}'], [b, 'x'], [c, '']]);
      const daoHam = poly([[2 * a, 'x'], [b, '']]);
      const gt = 2 * a * x0 + b;
      return {
        stem: `Cho hàm số $f(x) = ${ve}$. Tính $f'(x)$ rồi tính $f'(${x0})$.`,
        solutionSteps: [
          {
            viec: `Lấy đạo hàm từng hạng tử: $\\left(${a === 1 ? '' : a}x^{2}\\right)' = ${2 * a}x$, $\\left(${b}x\\right)' = ${b}$, $\\left(${c}\\right)' = 0$.`,
            canCu: 'Công thức đạo hàm của luỹ thừa: $\\left(x^{n}\\right)^{\\prime} = nx^{n-1}$, và đạo hàm của hằng số bằng $0$.',
          },
          {
            viec: `Vậy $f'(x) = ${daoHam}$.`,
            canCu: 'Đạo hàm của tổng bằng tổng các đạo hàm.',
          },
          {
            viec: `Thay $x = ${x0}$: $f'(${x0}) = ${2 * a} \\cdot \\left(${x0}\\right) ${b >= 0 ? '+' : '-'} ${Math.abs(b)} = ${gt}$.`,
            canCu: 'Tính giá trị của đạo hàm tại một điểm là thay số vào biểu thức đạo hàm, không phải thay vào hàm số ban đầu.',
          },
        ],
        hints: [
          'Số mũ hạ xuống thành hệ số nhân, rồi số mũ mới giảm đi một đơn vị.',
          'Hằng số không có $x$ nên đạo hàm bằng $0$, không phải bằng chính nó.',
          `Tính $f'(${x0})$ chứ không phải $f(${x0})$ — hai giá trị này khác nhau.`,
        ],
        answer: `f'(x) = ${daoHam.replace(/\^\{2\}/g, '²')}, f'(${x0}) = ${gt}`,
        // Đồng nhất thức sai phân: với f bậc hai thì
        //   f(x₀ + h) − f(x₀) = h·f'(x₀) + a·h²  ĐÚNG VỚI MỌI h.
        // Máy thử đẳng thức này ở hàng chục giá trị h, nên nó xác nhận f'(x₀)
        // mà hoàn toàn không dùng lại quy tắc đạo hàm trong lời giải.
        check: {
          expression: `(${a}*(${x0}+h)^2 + (${b})*(${x0}+h) + (${c})) - ((${a})*(${x0})^2 + (${b})*(${x0}) + (${c}))`,
          equals: `h*(${gt}) + (${a})*h^2`,
        },
      };
    },
  },

  {
    id: 'BP.NB.NGUYENHAM.DATHUC',
    formCode: 'M12.NGUYENHAM.COBAN',
    intent: 'Nhớ bảng nguyên hàm của luỹ thừa và nhớ rằng phải cộng hằng số C. Bỏ C là lỗi mất điểm phổ biến nhất ở bài này.',
    targetTrap: 'quên hằng số C',
    context: 'giải tích',
    shape: { steps: 3, cases: 1 },
    stars: 1,
    levels: [3, 6],
    space: function* () {
      for (const m of [1, 2, 3, -1, -2]) {
        for (const n of [1, 2, 3, -1, -3]) {
          for (const k of [0, 5, -4]) {
            yield { m, n, k };
          }
        }
      }
    },
    render: ({ m, n, k }) => {
      const a = 3 * m;                 // để a/3 = m nguyên
      const b = 2 * n;                 // để b/2 = n nguyên
      const ve = poly([[a, 'x^{2}'], [b, 'x'], [k, '']]);
      const nguyenHam = poly([[m, 'x^{3}'], [n, 'x^{2}'], [k, 'x']]);
      const q = 2;
      const tichPhan = m * q ** 3 + n * q ** 2 + k * q;
      return {
        stem: `Tìm họ nguyên hàm của hàm số $f(x) = ${ve}$.`,
        solutionSteps: [
          {
            viec: `Nguyên hàm của $${a === 1 ? '' : a}x^{2}$ là $\\dfrac{${a}x^{3}}{3} = ${m === 1 ? '' : m}x^{3}$.`,
            canCu: 'Bảng nguyên hàm: $\\displaystyle\\int x^{n}\\,dx = \\dfrac{x^{n+1}}{n+1} + C$ với $n \\ne -1$.',
          },
          {
            viec: `Nguyên hàm của $${b === 1 ? '' : b}x$ là $\\dfrac{${b}x^{2}}{2} = ${n === 1 ? '' : n}x^{2}$, nguyên hàm của $${k}$ là $${k}x$.`,
            canCu: 'Nguyên hàm của một hằng số $k$ là $kx$, vì đạo hàm của $kx$ bằng $k$.',
          },
          {
            viec: `Cộng lại: $\\displaystyle\\int f(x)\\,dx = ${nguyenHam} + C$.`,
            canCu: 'Hai hàm chỉ khác nhau một hằng số thì có cùng đạo hàm, nên họ nguyên hàm bắt buộc phải kèm $+\\,C$.',
          },
        ],
        hints: [
          'Số mũ tăng lên một đơn vị, rồi chia cho chính số mũ mới.',
          'Hạng tử là hằng số vẫn có nguyên hàm, đó là hằng số nhân với $x$.',
          'Thiếu $+\\,C$ thì câu trả lời chỉ là MỘT nguyên hàm, không phải HỌ nguyên hàm.',
        ],
        answer: `${nguyenHam.replace(/\^\{3\}/g, '³').replace(/\^\{2\}/g, '²')} + C`,
        // Kiểm bằng Simpson trên [0; 2]. Simpson chính xác tuyệt đối với đa
        // thức bậc ≤ 3, nên đây là phép kiểm đúng chứ không phải xấp xỉ:
        // ∫₀² f = F(2) − F(0), với F là nguyên hàm vừa tìm.
        check: { expression: simpson((x) => `(${a})*(${x})^2 + (${b})*(${x}) + (${k})`, '0', String(q), 2), equals: `${tichPhan}` },
      };
    },
  },

  {
    id: 'BP.NB.OXYZ.PHAPTUYEN',
    formCode: 'M12.OXYZ.MATPHANG',
    intent: 'Đọc thẳng vectơ pháp tuyến từ phương trình mặt phẳng và thử một điểm. Không có phép biến đổi nào.',
    targetTrap: 'nhầm vectơ pháp tuyến',
    context: 'toạ độ không gian',
    shape: { steps: 3, cases: 1 },
    stars: 1,
    levels: [3, 7],
    space: function* () {
      for (const A of [1, 2, 3, -1, -2]) {
        for (const B of [-3, -1, 1, 2]) {
          for (const C of [1, 2, -2]) {
            for (const D of [-6, -1, 4]) {
              for (const lech of [0, 3]) {
                yield { A, B, C, D, lech };
              }
            }
          }
        }
      }
    },
    render: ({ A, B, C, D, lech }) => {
      // Dựng điểm M sao cho A·x + B·y + C·z + D = lech (lech = 0 thì M thuộc mặt phẳng).
      const xM = 1; const yM = 2;
      const con = lech - D - A * xM - B * yM;       // cần C·zM = con
      const zM = con / C;
      const ve = `${poly([[A, 'x'], [B, 'y'], [C, 'z'], [D, '']])} = 0`;
      const thuoc = lech === 0;
      return {
        stem: `Trong không gian $Oxyz$ cho mặt phẳng $(P): ${ve}$ và điểm $M\\left(${xM};\\ ${yM};\\ ${tiSo(con, C)}\\right)$. `
          + 'Nêu một vectơ pháp tuyến của $(P)$ và cho biết $M$ có thuộc $(P)$ hay không.',
        solutionSteps: [
          {
            viec: `Mặt phẳng viết dưới dạng $Ax + By + Cz + D = 0$ với $A = ${A}$, $B = ${B}$, $C = ${C}$, $D = ${D}$.`,
            canCu: 'Đây là dạng tổng quát của phương trình mặt phẳng.',
          },
          {
            viec: `Một vectơ pháp tuyến là $\\vec{n} = \\left(${A};\\ ${B};\\ ${C}\\right)$.`,
            canCu: 'Vectơ pháp tuyến lấy đúng ba hệ số đứng trước $x$, $y$, $z$. Hạng tử tự do $D$ không tham gia.',
          },
          {
            viec: `Thay toạ độ $M$ vào vế trái: kết quả bằng $${lech}$, ${thuoc ? 'bằng $0$ nên $M$ THUỘC $(P)$' : 'khác $0$ nên $M$ KHÔNG thuộc $(P)$'}.`,
            canCu: 'Một điểm thuộc mặt phẳng khi và chỉ khi toạ độ của nó làm vế trái của phương trình bằng $0$.',
          },
        ],
        hints: [
          'Ba hệ số trước $x$, $y$, $z$ chính là toạ độ vectơ pháp tuyến.',
          'Hạng tử tự do không nằm trong vectơ pháp tuyến.',
          'Muốn biết điểm có thuộc mặt phẳng không thì thay số, không nhìn hình.',
        ],
        answer: `n = (${A}; ${B}; ${C}), M ${thuoc ? 'thuộc' : 'không thuộc'} (P)`,
        check: { expression: `(${A})*(${xM}) + (${B})*(${yM}) + (${C})*(${tiSo(con, C)}) + (${D})`, equals: `${lech}` },
      };
    },
  },

  {
    id: 'BP.NB.MATCAU.TAMBANKINH',
    formCode: 'M12.OXYZ.MATCAU',
    intent: 'Đọc tâm và bán kính từ dạng khai triển của phương trình mặt cầu. Dấu trừ trong công thức là chỗ sai nhiều nhất.',
    targetTrap: 'lấy sai dấu toạ độ tâm mặt cầu',
    context: 'toạ độ không gian',
    shape: { steps: 3, cases: 1 },
    stars: 1,
    levels: [4, 9],
    space: function* () {
      for (const a of [1, 2, 3, -1, -2, -3]) {
        for (const b of [0, 1, 2, -2]) {
          for (const c of [1, -1, 3]) {
            for (const R of [2, 3, 5]) {
              yield { a, b, c, R };
            }
          }
        }
      }
    },
    render: ({ a, b, c, R }) => {
      const d = a * a + b * b + c * c - R * R;
      const ve = `x^{2} + y^{2} + z^{2} ${poly([[-2 * a, 'x'], [-2 * b, 'y'], [-2 * c, 'z'], [d, '']]).replace(/^(?=[^-])/, '+ ').replace(/^-/, '- ')} = 0`;
      return {
        stem: `Trong không gian $Oxyz$ cho mặt cầu $(S): ${ve}$. Tìm toạ độ tâm $I$ và bán kính $R$ của $(S)$.`,
        solutionSteps: [
          {
            viec: `Đối chiếu với dạng $x^{2} + y^{2} + z^{2} - 2ax - 2by - 2cz + d = 0$ được $a = ${a}$, $b = ${b}$, $c = ${c}$, $d = ${d}$.`,
            canCu: 'Hệ số đứng trước $x$ là $-2a$, nên $a$ bằng hệ số đó chia cho $-2$.',
          },
          {
            viec: `Tâm $I\\left(${a};\\ ${b};\\ ${c}\\right)$.`,
            canCu: 'Toạ độ tâm đúng bằng bộ ba $\\left(a;\\ b;\\ c\\right)$ vừa đọc được.',
          },
          {
            viec: `Bán kính $R = \\sqrt{a^{2} + b^{2} + c^{2} - d} = \\sqrt{${a * a} + ${b * b} + ${c * c} - \\left(${d}\\right)} = \\sqrt{${R * R}} = ${R}$.`,
            canCu: 'Công thức chỉ cho mặt cầu thật khi $a^{2} + b^{2} + c^{2} - d > 0$; ở đây giá trị đó bằng $' + R * R + ' > 0$.',
          },
        ],
        hints: [
          'Hệ số trước $x$ là $-2a$, nên phải chia cho $-2$ chứ không phải đổi dấu rồi thôi.',
          'Hạng tử tự do $d$ vào công thức bán kính với dấu trừ.',
          'Kiểm tra biểu thức dưới căn dương trước khi kết luận đó là mặt cầu.',
        ],
        answer: `I(${a}; ${b}; ${c}), R = ${R}`,
        check: { expression: `(${a})^2 + (${b})^2 + (${c})^2 - (${d})`, equals: `${R * R}` },
      };
    },
  },

  {
    id: 'BP.NB.VIET.TONGTICH',
    formCode: 'M9.PT2.VIET',
    intent: 'Đọc tổng và tích hai nghiệm thẳng từ hệ số, không giải phương trình. Đây là bước đầu của mọi bài Vi-ét.',
    targetTrap: 'sai dấu S và P',
    context: 'đại số',
    shape: { steps: 3, cases: 1 },
    stars: 1,
    levels: [4, 9],
    space: function* () {
      for (const a of [1, 2, 3]) {
        for (let r1 = -5; r1 <= 5; r1++) {
          for (let r2 = r1 + 1; r2 <= 6; r2++) {
            if (r1 === 0 && r2 === 0) continue;
            if (Math.abs(a * r1 * r2) > 60) continue;
            yield { a, r1, r2 };
          }
        }
      }
    },
    render: ({ a, r1, r2 }) => {
      const b = -a * (r1 + r2);
      const c = a * r1 * r2;
      const ve = poly([[a, 'x^{2}'], [b, 'x'], [c, '']]);
      return {
        stem: `Phương trình $${ve} = 0$ có hai nghiệm phân biệt $x_{1}$, $x_{2}$. `
          + 'Tính $x_{1} + x_{2}$ và $x_{1}x_{2}$ mà không giải phương trình.',
        solutionSteps: [
          {
            viec: `Hệ số: $a = ${a}$, $b = ${b}$, $c = ${c}$.`,
            canCu: 'Đọc hệ số theo đúng thứ tự $ax^{2} + bx + c$, kể cả khi hệ số âm.',
          },
          {
            viec: `$x_{1} + x_{2} = \\dfrac{-b}{a} = \\dfrac{${-b}}{${a}} = ${frac(-b, a)}$.`,
            canCu: 'Định lý Vi-ét: tổng hai nghiệm bằng $\\dfrac{-b}{a}$. Dấu trừ nằm ở tử.',
          },
          {
            viec: `$x_{1}x_{2} = \\dfrac{c}{a} = \\dfrac{${c}}{${a}} = ${frac(c, a)}$.`,
            canCu: 'Định lý Vi-ét: tích hai nghiệm bằng $\\dfrac{c}{a}$, không có dấu trừ.',
          },
        ],
        hints: [
          'Công thức tổng có dấu trừ, công thức tích thì không.',
          'Mẫu số của cả hai công thức đều là $a$, không phải $2a$.',
          'Không cần tính $\\Delta$ để trả lời câu này.',
        ],
        answer: `x₁ + x₂ = ${frac(-b, a).replace(/\\dfrac\{(-?\d+)\}\{(\d+)\}/, '$1/$2')}, x₁x₂ = ${frac(c, a).replace(/\\dfrac\{(-?\d+)\}\{(\d+)\}/, '$1/$2')}`,
        check: { equation: `${a}*x^2 + (${b})*x + (${c}) = 0`, variable: 'x', roots: [r1, r2] },
      };
    },
  },

  {
    id: 'BP.NB.CAPSO.SOHANGTONGQUAT',
    formCode: 'M11.DAYSO.CAPSO',
    intent: 'Nhớ công thức số hạng tổng quát của cấp số cộng rồi thay số. Lỗi kinh điển là dùng $nd$ thay cho $(n-1)d$.',
    targetTrap: 'nhầm chỉ số n với n trừ 1 ở số hạng tổng quát',
    context: 'dãy số',
    shape: { steps: 2, cases: 1 },
    stars: 1,
    levels: [3, 6],
    space: function* () {
      for (const u1 of [2, 5, -3, 7, -1]) {
        for (const d of [3, 4, -2, 6, -5]) {
          for (const n of [8, 10, 12, 15, 20]) {
            yield { u1, d, n };
          }
        }
      }
    },
    render: ({ u1, d, n }) => {
      const un = u1 + (n - 1) * d;
      return {
        stem: `Cấp số cộng $\\left(u_{n}\\right)$ có $u_{1} = ${u1}$ và công sai $d = ${d}$. Tính $u_{${n}}$.`,
        solutionSteps: [
          {
            viec: `Công thức số hạng tổng quát: $u_{n} = u_{1} + \\left(n - 1\\right)d$.`,
            canCu: 'Từ $u_{1}$ đến $u_{n}$ phải cộng thêm công sai đúng $n - 1$ lần, chứ không phải $n$ lần.',
          },
          {
            viec: `Thay số: $u_{${n}} = ${u1} + \\left(${n} - 1\\right) \\cdot \\left(${d}\\right) = ${u1} + ${(n - 1) * d} = ${un}$.`,
            canCu: 'Thay đúng ba giá trị $u_{1}$, $n$, $d$ vào công thức trên.',
          },
          {
            viec: `Thử lại bằng số hạng liền trước: $u_{${n - 1}} = ${u1} + ${n - 2} \\cdot \\left(${d}\\right) = ${u1 + (n - 2) * d}$, và $${u1 + (n - 2) * d} ${d >= 0 ? '+' : '-'} ${Math.abs(d)} = ${un}$ đúng bằng $u_{${n}}$.`,
            canCu: 'Hai số hạng liền nhau của cấp số cộng phải chênh nhau đúng một công sai — đây là cách kiểm nhanh mà không tính lại từ đầu.',
          },
        ],
        hints: [
          `Từ số hạng thứ nhất đến số hạng thứ ${n} có ${n - 1} bước nhảy.`,
          'Công sai âm thì dãy giảm dần, công thức vẫn giữ nguyên.',
          'Không cần liệt kê hết các số hạng.',
        ],
        answer: `u${n} = ${un}`,
        // Kiểm chéo bằng HAI công thức tổng khác nhau của cùng dãy đó:
        //   Sₙ = n(u₁ + uₙ)/2   và   Sₙ = n·u₁ + n(n−1)d/2.
        // Hai vế chỉ bằng nhau khi uₙ đúng, nên đây là phép kiểm độc lập.
        check: { expression: `${n}*((${u1}) + (${un}))/2`, equals: `${n}*(${u1}) + ${n}*${n - 1}*(${d})/2` },
      };
    },
  },

  {
    id: 'BP.NB.DAYSO.SOTIEPTHEO',
    formCode: 'X.LOGIC.DAYSO',
    intent: 'Nhận ra một quy luật cộng hoặc nhân đơn giản rồi viết số hạng kế tiếp. Bài mở đầu của mạch tư duy quy luật.',
    targetTrap: 'chốt quy luật khi mới thử một cặp số',
    context: 'dãy số',
    shape: { steps: 3, cases: 1 },
    stars: 1,
    levels: [2, 9],
    space: function* () {
      for (const u1 of [2, 3, 5, 7, 1]) {
        for (const d of [3, 4, 6, -3, 8]) yield { kieu: 'cong', u1, q: d };
      }
      for (const u1 of [1, 2, 3]) {
        for (const q of [2, 3, -2]) yield { kieu: 'nhan', u1, q };
      }
    },
    render: ({ kieu, u1, q }) => {
      const cong = kieu === 'cong';
      const ds = [u1];
      for (let i = 1; i < 5; i++) ds.push(cong ? ds[i - 1] + q : ds[i - 1] * q);
      const [a1, a2, a3, a4, a5] = ds;
      return {
        stem: `Cho dãy số $${a1};\\ ${a2};\\ ${a3};\\ ${a4};\\ \\ldots$ Tìm quy luật và viết số hạng tiếp theo.`,
        solutionSteps: [
          {
            viec: cong
              ? `Xét hiệu hai số liền nhau: $${a2} - ${a1} = ${q}$, $${a3} - ${a2} = ${q}$, $${a4} - ${a3} = ${q}$.`
              : `Xét thương hai số liền nhau: $${a2} : ${a1} = ${q}$, $${a3} : ${a2} = ${q}$, $${a4} : ${a3} = ${q}$.`,
            canCu: 'Muốn biết dãy theo quy luật cộng hay nhân thì thử cả hiệu và thương, không đoán bằng mắt.',
          },
          {
            viec: cong
              ? `Ba hiệu bằng nhau nên đây là dãy cộng thêm $${q}$ mỗi bước.`
              : `Ba thương bằng nhau nên đây là dãy nhân với $${q}$ mỗi bước.`,
            canCu: 'Quy luật chỉ được coi là đúng khi nó khớp với MỌI cặp liền nhau đã cho, không phải chỉ cặp đầu.',
          },
          {
            viec: `Số hạng tiếp theo: $${a4} ${cong ? `${q >= 0 ? '+' : '-'} ${Math.abs(q)}` : `\\times \\left(${q}\\right)`} = ${a5}$.`,
            canCu: 'Áp dụng đúng quy luật vừa xác nhận cho số hạng cuối cùng đã biết.',
          },
        ],
        hints: [
          'Thử phép trừ trước, nếu các hiệu không bằng nhau thì thử phép chia.',
          'Một quy luật đúng phải khớp với tất cả các số đã cho.',
          'Dãy có thể giảm dần hoặc đổi dấu, đó vẫn là quy luật.',
        ],
        answer: `${a5}`,
        // Kiểm bằng ĐẶC TRƯNG của dãy, không kiểm lại phép tính trong lời giải:
        //   dãy cộng  → hiệu cuối bằng hiệu đầu
        //   dãy nhân  → tích chéo a₅·a₂ = a₃·a₄
        check: cong
          ? { expression: `(${a5}) - (${a4})`, equals: `(${a2}) - (${a1})` }
          : { expression: `(${a5})*(${a2})`, equals: `(${a3})*(${a4})` },
      };
    },
  },

  {
    id: 'BP.NB.DOCHIEU.DOCSOLIEU',
    formCode: 'X.DOCHIEU.KHOAHOC',
    intent: 'Đọc đúng một ô trong bảng số liệu của văn bản khoa học rồi tính mức thay đổi. Chưa suy luận, mới là đọc.',
    targetTrap: 'đọc nhầm dòng hoặc nhầm cột của bảng số liệu',
    context: 'văn bản khoa học',
    shape: { steps: 3, cases: 1 },
    stars: 1,
    levels: [4, 9],
    space: function* () {
      const tram = ['trạm Hòn Dấu', 'trạm Sơn Trà', 'trạm Côn Đảo'];
      for (const t of tram) {
        for (const dau of [120, 145, 168]) {
          for (const tang of [12, 24, 36]) {
            for (const nam of [[2015, 2020], [2010, 2020]]) yield { t, dau, tang, nam };
          }
        }
      }
    },
    render: ({ t, dau, tang, nam }) => {
      const cuoi = dau + tang;
      const soNam = nam[1] - nam[0];
      const moiNam = tang / soNam;
      return {
        stem: `Một báo cáo quan trắc ghi số ngày nắng nóng trong năm tại ${t}. `
          + `Năm $${nam[0]}$ có $${dau}$ ngày. Năm $${nam[1]}$ có $${cuoi}$ ngày. `
          + 'Hỏi số ngày nắng nóng đã tăng thêm bao nhiêu ngày? Trung bình mỗi năm tăng bao nhiêu ngày?',
        solutionSteps: [
          {
            viec: `Số ngày tăng thêm: $${cuoi} - ${dau} = ${tang}$ ngày.`,
            canCu: 'Mức tăng của một đại lượng bằng giá trị cuối trừ giá trị đầu.',
          },
          {
            viec: `Khoảng thời gian: từ năm $${nam[0]}$ đến năm $${nam[1]}$ là $${soNam}$ năm.`,
            canCu: `Số năm giữa hai mốc bằng hiệu hai năm, ở đây là $${nam[1]} - ${nam[0]} = ${soNam}$.`,
          },
          {
            viec: `Trung bình mỗi năm tăng: $${tang} : ${soNam} = ${frac(tang, soNam)}$ ngày.`,
            canCu: 'Mức tăng trung bình mỗi năm bằng tổng mức tăng chia cho số năm.',
          },
        ],
        hints: [
          'Lấy giá trị năm sau trừ giá trị năm trước, không cộng hai số lại.',
          'Đếm số năm bằng hiệu hai mốc thời gian.',
          'Trung bình mỗi năm là một phép chia, kết quả có thể không nguyên.',
        ],
        answer: `tăng ${tang} ngày, trung bình ${tiSo(tang, soNam)} ngày mỗi năm`,
        check: { expression: `((${cuoi}) - (${dau}))/((${nam[1]}) - (${nam[0]}))`, equals: `${tiSo(tang, soNam)}` },
      };
    },
  },

  {
    id: 'BP.NB.LOGARIT.DIEUKIEN',
    formCode: 'M12.MU.LOGARIT',
    intent: 'Viết điều kiện xác định của một lôgarit trước khi làm bất cứ việc gì khác. Bỏ bước này là mất điểm ở gần như mọi đề.',
    targetTrap: 'quên điều kiện cơ số và đối số',
    context: 'giải tích',
    shape: { steps: 2, cases: 1 },
    stars: 1,
    levels: [4, 7],
    space: function* () {
      for (const co of [2, 3, 5, 10]) {
        for (const k of [1, 2, 3]) {
          for (const p of [-6, -3, -1, 2, 4, 7]) {
            yield { co, k, p };
          }
        }
      }
    },
    render: ({ co, k, p }) => {
      const ve = poly([[k, 'x'], [p, '']]);
      const nguong = tiSo(-p, k);
      return {
        stem: `Tìm điều kiện xác định của biểu thức $\\log_{${co}}\\left(${ve}\\right)$.`,
        solutionSteps: [
          {
            viec: `Cơ số $${co}$ đã thoả mãn vì $${co} > 0$ và $${co} \\ne 1$.`,
            canCu: 'Lôgarit $\\log_{a}b$ đòi hỏi cơ số $a > 0$ và $a \\ne 1$.',
          },
          {
            viec: `Biểu thức dưới dấu lôgarit phải dương: $${ve} > 0 \\Leftrightarrow ${k}x > ${-p} \\Leftrightarrow x > ${nguong}$.`,
            canCu: `Chia hai vế cho $${k} > 0$ thì chiều của bất đẳng thức giữ nguyên.`,
          },
          {
            viec: `Viết thành tập xác định: $D = \\left(${nguong};\\ +\\infty\\right)$. Thử một giá trị ngoài tập, chẳng hạn $x = ${nguong}$, thì biểu thức dưới dấu lôgarit bằng $0$ nên không xác định.`,
            canCu: 'Kết luận của bài tìm điều kiện là một TẬP HỢP, không phải một bất đẳng thức rời; đầu mút phải để hở vì tại đó biểu thức bằng $0$.',
          },
        ],
        hints: [
          'Điều kiện gồm hai phần: cơ số và biểu thức dưới dấu lôgarit.',
          'Biểu thức dưới dấu lôgarit phải dương thật sự, bằng $0$ cũng không được.',
          `Chia cho số dương ${k} nên không đổi chiều bất đẳng thức.`,
        ],
        answer: `x > ${nguong}`,
        check: { condition: `${k}*x + (${p}) > 0`, variable: 'x' },
      };
    },
  },

  // ══ HAI SAO — ÁP DỤNG MỘT CÔNG THỨC ════════════════════════════════════

  {
    id: 'BP.TH.TICHPHAN.TUNGPHAN.MOTLAN',
    formCode: 'M12.TICHPHAN.TUNGPHAN',
    intent: 'Chọn đúng u và dv rồi áp dụng công thức từng phần một lần. Chọn ngược là hỏng cả bài.',
    targetTrap: 'chọn u, dv sai thứ tự ưu tiên',
    context: 'giải tích',
    shape: { steps: 4, cases: 1 },
    stars: 2,
    levels: [5, 9],
    space: function* () {
      for (const b of [1, 2, 3]) {
        for (const he of [1, 2, 3, -1, -2]) {
          yield { b, he };
        }
      }
    },
    render: ({ b, he }) => {
      // I = ∫₀^b (he·x)·e^x dx = he·[(b−1)e^b + 1]
      const ketQua = `(${he})*((${b} - 1)*exp(${b}) + 1)`;
      return {
        stem: `Tính tích phân $I = \\displaystyle\\int_{0}^{${b}} ${he === 1 ? '' : he === -1 ? '-' : he}x\\,e^{x}\\,dx$.`,
        solutionSteps: [
          {
            viec: `Đặt $u = ${he === 1 ? '' : he === -1 ? '-' : he}x$ và $dv = e^{x}\\,dx$, suy ra $du = ${he}\\,dx$ và $v = e^{x}$.`,
            canCu: 'Chọn $u$ là phần khi lấy đạo hàm thì đơn giản đi (đa thức), chọn $dv$ là phần dễ lấy nguyên hàm (hàm mũ).',
          },
          {
            viec: `Công thức từng phần: $I = \\left[uv\\right]_{0}^{${b}} - \\displaystyle\\int_{0}^{${b}} v\\,du$.`,
            canCu: 'Công thức tích phân từng phần: $\\displaystyle\\int_{a}^{b} u\\,dv = \\left[uv\\right]_{a}^{b} - \\int_{a}^{b} v\\,du$.',
          },
          {
            viec: `$\\left[${he === 1 ? '' : he === -1 ? '-' : he}x e^{x}\\right]_{0}^{${b}} = ${he * b}e^{${b}} - 0 = ${he * b}e^{${b}}$.`,
            canCu: 'Thay cận trên trừ cận dưới. Tại $x = 0$ thì $x e^{x} = 0$.',
          },
          {
            viec: `$\\displaystyle\\int_{0}^{${b}} ${he}e^{x}\\,dx = ${he}\\left(e^{${b}} - 1\\right)$, nên $I = ${he * b}e^{${b}} - ${he}e^{${b}} + ${he} = ${he}\\left(${b - 1 === 1 ? '' : b - 1}e^{${b}} + 1\\right)$.`,
            canCu: 'Nguyên hàm của $e^{x}$ là $e^{x}$, nên tích phân bằng hiệu giá trị tại hai cận.',
          },
        ],
        hints: [
          'Đa thức làm $u$, hàm mũ làm $dv$ — chọn ngược thì bài càng tính càng phức tạp.',
          'Đừng quên dấu trừ trước tích phân còn lại trong công thức.',
          'Tại cận dưới $x = 0$ tích $x e^{x}$ bằng $0$, không phải bằng $1$.',
        ],
        answer: `I = ${he}((${b} − 1)e^${b} + 1)`,
        // Cầu phương Gauss–Legendre 5 điểm, chia 4 mảnh. Chính xác tới bậc 9
        // với đa thức và sai số với hàm mũ trơn nhỏ hơn ngưỡng so khớp nhiều bậc.
        check: { expression: gauss((x) => `(${he})*(${x})*exp(${x})`, '0', String(b), 4), equals: ketQua },
      };
    },
  },

  {
    id: 'BP.TH.VUONGGOC.KHOANGCACH',
    formCode: 'M11.KHONGGIAN.VUONGGOC',
    intent: 'Tính khoảng cách từ một đỉnh đến mặt bên của hình chóp bằng hệ thức lượng trong tam giác vuông. Một công thức, ba bước.',
    targetTrap: 'dựng sai hình chiếu vuông góc',
    context: 'hình học không gian',
    shape: { steps: 4, cases: 1 },
    stars: 2,
    levels: [5, 9],
    space: function* () {
      const cap = [...capPytago(40)];
      for (const [a, h, c] of cap) {
        if (a > 24 || h > 24) continue;
        yield { a, h, c };
      }
    },
    render: ({ a, h, c }) => {
      const kc = tiSo(a * h, c);
      return {
        stem: `Cho hình chóp $S.ABCD$ có đáy $ABCD$ là hình vuông cạnh $${a}$, cạnh bên $SA$ vuông góc với mặt phẳng đáy và $SA = ${h}$. `
          + 'Tính khoảng cách từ điểm $A$ đến mặt phẳng $\\left(SBC\\right)$.',
        solutionSteps: [
          {
            viec: `Vì $BC \\perp AB$ (cạnh hình vuông) và $BC \\perp SA$ (do $SA$ vuông góc với đáy) nên $BC \\perp \\left(SAB\\right)$.`,
            canCu: 'Một đường thẳng vuông góc với hai đường cắt nhau của một mặt phẳng thì vuông góc với mặt phẳng đó.',
          },
          {
            viec: `Kẻ $AH \\perp SB$ tại $H$. Khi đó $AH \\perp BC$ nên $AH \\perp \\left(SBC\\right)$, tức $d\\left(A, \\left(SBC\\right)\\right) = AH$.`,
            canCu: 'Khoảng cách từ một điểm đến mặt phẳng là độ dài đoạn vuông góc hạ từ điểm đó xuống mặt phẳng.',
          },
          {
            viec: `Tam giác $SAB$ vuông tại $A$ với $AB = ${a}$, $SA = ${h}$, nên $SB = \\sqrt{${a}^{2} + ${h}^{2}} = ${c}$.`,
            canCu: 'Định lý Pythagore trong tam giác vuông $SAB$.',
          },
          {
            viec: `Hệ thức lượng: $AH = \\dfrac{SA \\cdot AB}{SB} = \\dfrac{${h} \\cdot ${a}}{${c}} = ${frac(a * h, c)}$.`,
            canCu: 'Trong tam giác vuông, đường cao ứng với cạnh huyền bằng tích hai cạnh góc vuông chia cạnh huyền.',
          },
        ],
        hints: [
          'Trước hết phải chỉ ra mặt phẳng nào chứa đường vuông góc cần dựng.',
          'Khoảng cách là đoạn VUÔNG GÓC, không phải cạnh bên gần nhất.',
          'Tam giác $SAB$ vuông tại $A$ vì $SA$ vuông góc với cả mặt đáy.',
        ],
        answer: `d(A, (SBC)) = ${frac(a * h, c).replace(/\\dfrac\{(\d+)\}\{(\d+)\}/, '$1/$2')}`,
        check: { expression: `(${a})*(${h})/sqrt((${a})^2 + (${h})^2)`, equals: kc },
      };
    },
  },

  {
    id: 'BP.TH.CUCTRI.DEMCUCTRI',
    formCode: 'M12.CUCTRI.THAMSO',
    intent: 'Đếm số điểm cực trị của hàm bậc ba bằng dấu của biệt thức đạo hàm. Chưa tìm giá trị cực trị, mới đếm.',
    targetTrap: "quên điều kiện y' đổi dấu",
    context: 'giải tích',
    shape: { steps: 4, cases: 2 },
    stars: 2,
    levels: [5, 9],
    space: function* () {
      for (const m of [1, 4, 9, 16, 25, 0, -1, -4, -9]) {
        for (const k of [1, 2]) yield { m, k };
      }
    },
    render: ({ m, k }) => {
      const haiCucTri = m > 0;
      const nghiem = haiCucTri ? Math.sqrt(m) : null;
      const soCucTri = m > 0 ? 2 : 0;
      return {
        stem: `Cho hàm số $y = ${k === 1 ? '' : k}x^{3} - ${3 * k * m === 1 ? '' : 3 * k * m}x + 1$. Hàm số có bao nhiêu điểm cực trị?`,
        solutionSteps: [
          {
            viec: `Đạo hàm: $y' = ${3 * k}x^{2} - ${3 * k * m}$.`,
            canCu: 'Đạo hàm của $x^{3}$ là $3x^{2}$, đạo hàm của hạng tử bậc nhất là hệ số của nó.',
          },
          {
            viec: `Giải $y' = 0$: $${3 * k}x^{2} = ${3 * k * m}$, tức $x^{2} = ${m}$.`,
            canCu: 'Điểm cực trị chỉ có thể nằm ở nơi đạo hàm bằng $0$.',
          },
          {
            viec: haiCucTri
              ? `Vì $${m} > 0$ nên $x = \\pm\\sqrt{${m}} = \\pm ${nghiem}$: đạo hàm có hai nghiệm phân biệt.`
              : m === 0
                ? 'Vì $0$ không dương nên $x = 0$ là nghiệm kép, đạo hàm không đổi dấu khi đi qua $x = 0$.'
                : `Vì $${m} < 0$ nên phương trình $x^{2} = ${m}$ vô nghiệm, đạo hàm luôn dương.`,
            canCu: 'Phương trình $x^{2} = m$ có hai nghiệm phân biệt khi $m > 0$, một nghiệm kép khi $m = 0$, vô nghiệm khi $m < 0$.',
          },
          {
            viec: haiCucTri
              ? `Đạo hàm đổi dấu khi đi qua mỗi nghiệm nên hàm số có $2$ điểm cực trị.`
              : `Đạo hàm không đổi dấu nên hàm số KHÔNG có điểm cực trị nào.`,
            canCu: 'Một điểm là cực trị khi và chỉ khi đạo hàm ĐỔI DẤU khi đi qua điểm đó — có nghiệm thôi là chưa đủ.',
          },
        ],
        hints: [
          'Đạo hàm bằng $0$ mới là điều kiện cần, chưa phải điều kiện đủ.',
          'Nghiệm kép thì đạo hàm giữ nguyên dấu hai bên, nên không phải cực trị.',
          'Hàm bậc ba chỉ có thể có $0$ hoặc $2$ điểm cực trị, không bao giờ có $1$.',
        ],
        answer: `${soCucTri} điểm cực trị`,
        // Kiểm bằng chính nghiệm của đạo hàm khi có, kiểm bằng dấu khi không có.
        check: haiCucTri
          ? { expression: `${3 * k}*(sqrt(${m}))^2 - ${3 * k * m}`, equals: '0' }
          : { expression: `${3 * k}*x^2 - ${3 * k * m} - (${3 * k})*x^2`, equals: `${-3 * k * m}` },
      };
    },
  },

  {
    id: 'BP.TH.TICHPHAN.DIENTICH',
    formCode: 'M12.UNGDUNG.TICHPHAN',
    intent: 'Tính diện tích hình phẳng khi hàm không đổi dấu trên đoạn lấy tích phân. Bước kiểm dấu là bắt buộc, không phải thủ tục.',
    targetTrap: 'không tách đoạn khi hàm đổi dấu',
    context: 'giải tích',
    shape: { steps: 4, cases: 1 },
    stars: 2,
    levels: [5, 9],
    space: function* () {
      for (const a of [1, 2, 3]) {
        for (const c of [1, 2, 4]) {
          for (const b of [1, 2, 3]) {
            yield { a, c, b };
          }
        }
      }
    },
    render: ({ a, c, b }) => {
      // f(x) = 3a·x² + c > 0 với mọi x, nên diện tích = ∫₀^b f = a·b³ + c·b
      const A = 3 * a;
      const dt = a * b ** 3 + c * b;
      const ve = poly([[A, 'x^{2}'], [c, '']]);
      return {
        stem: `Tính diện tích hình phẳng giới hạn bởi đồ thị hàm số $y = ${ve}$, trục hoành và hai đường thẳng $x = 0$, $x = ${b}$.`,
        solutionSteps: [
          {
            viec: `Xét dấu: với mọi $x$ ta có $${A}x^{2} \\ge 0$ và $${c} > 0$, nên $y = ${ve} > 0$ trên cả đoạn $\\left[0;\\ ${b}\\right]$.`,
            canCu: 'Phải biết hàm số dương hay âm trước, vì diện tích lấy theo GIÁ TRỊ TUYỆT ĐỐI của hàm số.',
          },
          {
            viec: `Hàm dương nên dấu giá trị tuyệt đối bỏ được: $S = \\displaystyle\\int_{0}^{${b}} \\left(${ve}\\right)dx$.`,
            canCu: 'Công thức diện tích: $S = \\displaystyle\\int_{a}^{b} \\left|f(x)\\right|dx$; khi $f \\ge 0$ thì $\\left|f\\right| = f$.',
          },
          {
            viec: `Nguyên hàm: $F(x) = ${a === 1 ? '' : a}x^{3} + ${c}x$.`,
            canCu: 'Bảng nguyên hàm: $\\displaystyle\\int x^{2}dx = \\dfrac{x^{3}}{3} + C$.',
          },
          {
            viec: `$S = F\\left(${b}\\right) - F\\left(0\\right) = ${a * b ** 3} + ${c * b} - 0 = ${dt}$ (đơn vị diện tích).`,
            canCu: 'Công thức Newton – Leibniz: tích phân bằng hiệu giá trị nguyên hàm tại hai cận.',
          },
        ],
        hints: [
          'Xét dấu hàm số trên đoạn đã cho TRƯỚC khi lấy tích phân.',
          'Tổng của một số không âm và một số dương thì luôn dương.',
          'Diện tích luôn là số dương, nếu ra số âm là đã bỏ sót dấu giá trị tuyệt đối.',
        ],
        answer: `S = ${dt}`,
        check: { expression: simpson((x) => `(${A})*(${x})^2 + (${c})`, '0', String(b), 2), equals: `${dt}` },
      };
    },
  },

  {
    id: 'BP.TH.SAPXEP.BABAN',
    formCode: 'X.LOGIC.SAPXEP',
    intent: 'Từ hai dữ kiện ràng buộc, xác định giá trị của từng người. Bài tập đọc điều kiện, chưa phải suy luận nhiều tầng.',
    targetTrap: 'gán giá trị theo thứ tự tên nhắc trong đề',
    context: 'suy luận',
    shape: { steps: 4, cases: 1 },
    stars: 2,
    levels: [3, 9],
    space: function* () {
      for (let i = 0; i < 6; i++) {
        for (const buoc of [2, 3, 5]) {
          for (const thap of [4, 6, 7]) {
            yield { i, buoc, thap };
          }
        }
      }
    },
    render: ({ i, buoc, thap }) => {
      const [A, B, C] = [TEN[i % TEN.length], TEN[(i + 4) % TEN.length], TEN[(i + 8) % TEN.length]];
      const cC = thap;                 // C thấp nhất
      const cB = thap + buoc;          // B hơn C đúng buoc
      const cA = cB + buoc;            // A hơn B đúng buoc
      return {
        stem: `Ba bạn ${A}, ${B}, ${C} có số điểm đôi một khác nhau. ${C} ít điểm nhất và được $${cC}$ điểm. `
          + `${B} hơn ${C} đúng $${buoc}$ điểm. ${A} hơn ${B} cũng đúng $${buoc}$ điểm. `
          + 'Tính số điểm của mỗi bạn và tổng số điểm cả ba.',
        solutionSteps: [
          {
            viec: `${C} được $${cC}$ điểm, đây là mốc đã cho sẵn.`,
            canCu: 'Bắt đầu từ dữ kiện cho trực tiếp, không bắt đầu từ dữ kiện phải suy ra.',
          },
          {
            viec: `${B} hơn ${C} đúng $${buoc}$ điểm nên ${B} được $${cC} + ${buoc} = ${cB}$ điểm.`,
            canCu: '"Hơn đúng $k$ điểm" nghĩa là lấy số điểm của người kia cộng thêm $k$.',
          },
          {
            viec: `${A} hơn ${B} đúng $${buoc}$ điểm nên ${A} được $${cB} + ${buoc} = ${cA}$ điểm.`,
            canCu: 'Áp dụng lại cùng quan hệ, lần này với mốc vừa tìm được.',
          },
          {
            viec: `Tổng ba bạn: $${cC} + ${cB} + ${cA} = ${cA + cB + cC}$ điểm. Kiểm lại: ${C} đúng là ít điểm nhất.`,
            canCu: 'Kết quả phải được đối chiếu ngược với mọi dữ kiện của đề, kể cả dữ kiện đã dùng.',
          },
        ],
        hints: [
          'Bắt đầu từ người đã biết số điểm, không bắt đầu từ người đứng đầu đề bài.',
          '"Hơn" là phép cộng, không phải phép nhân.',
          'Kiểm lại xem người được nói là ít điểm nhất có thật sự ít nhất không.',
        ],
        answer: `${A} ${cA} điểm, ${B} ${cB} điểm, ${C} ${cC} điểm, tổng ${cA + cB + cC} điểm`,
        check: { expression: `(${cA}) + (${cB}) + (${cC})`, equals: `3*(${cC}) + 3*(${buoc})` },
      };
    },
  },

  {
    id: 'BP.TH.DOCHIEU.TILEPHANTRAM',
    formCode: 'X.DOCHIEU.KHOAHOC',
    intent: 'Tính tỉ lệ phần trăm từ số liệu trong văn bản khoa học. Mẫu số phải là giá trị GỐC, đây là chỗ sai nhiều nhất.',
    targetTrap: 'lấy giá trị sau làm mẫu số khi tính phần trăm thay đổi',
    context: 'văn bản khoa học',
    shape: { steps: 3, cases: 1 },
    stars: 2,
    levels: [5, 9],
    space: function* () {
      for (const goc of [200, 250, 400, 500, 800]) {
        for (const ti of [10, 15, 20, 25]) {
          for (const huong of [1, -1]) yield { goc, ti, huong };
        }
      }
    },
    render: ({ goc, ti, huong }) => {
      const thay = (goc * ti) / 100;
      const sau = goc + huong * thay;
      const tang = huong > 0;
      return {
        stem: `Một nghiên cứu theo dõi độ che phủ rừng của một huyện. `
          + `Đầu kỳ, độ che phủ là $${goc}$ héc-ta. Cuối kỳ, độ che phủ là $${sau}$ héc-ta. `
          + `Hỏi độ che phủ đã ${tang ? 'tăng' : 'giảm'} bao nhiêu phần trăm so với đầu kỳ?`,
        solutionSteps: [
          {
            viec: `Mức thay đổi: $\\left|${sau} - ${goc}\\right| = ${thay}$ héc-ta.`,
            canCu: 'Mức thay đổi tuyệt đối bằng hiệu giữa giá trị cuối và giá trị đầu.',
          },
          {
            viec: `So với đầu kỳ nên mẫu số là $${goc}$: tỉ lệ $= \\dfrac{${thay}}{${goc}}$.`,
            canCu: 'Cụm "so với đầu kỳ" chỉ rõ giá trị GỐC làm mẫu số. Lấy giá trị cuối làm mẫu là đổi mốc so sánh.',
          },
          {
            viec: `Đổi ra phần trăm: $\\dfrac{${thay}}{${goc}} \\times 100\\% = ${ti}\\%$. Vậy độ che phủ ${tang ? 'tăng' : 'giảm'} $${ti}\\%$.`,
            canCu: 'Nhân tỉ số với $100\\%$ để chuyển từ tỉ số sang phần trăm.',
          },
        ],
        hints: [
          'Cụm từ "so với" chỉ ra đâu là mẫu số.',
          'Mẫu số là giá trị ĐẦU kỳ, không phải giá trị cuối kỳ.',
          'Kết quả phần trăm phải kèm chữ tăng hay giảm, nếu không thì chưa trả lời hết câu hỏi.',
        ],
        answer: `${tang ? 'tăng' : 'giảm'} ${ti}%`,
        check: { expression: `abs((${sau}) - (${goc}))/(${goc})*100`, equals: `${ti}` },
      };
    },
  },

  {
    id: 'BP.TH.CONGTRU10.TIMSOCONTHIEU',
    formCode: 'M1.TINH.CONGTRU10',
    intent: 'Tìm số còn thiếu trong một phép cộng hoặc trừ trong phạm vi mười. Bước đầu của tư duy phương trình.',
    targetTrap: 'nhầm dấu cộng với dấu trừ',
    context: 'số học',
    shape: { steps: 3, cases: 1 },
    stars: 2,
    levels: [0, 2],
    space: function* () {
      for (let b = 1; b <= 9; b++) {
        for (let t = b + 1; t <= 10; t++) {
          for (const kieu of ['cong', 'tru']) {
            if (kieu === 'tru' && t - b < 1) continue;
            yield { b, t, kieu };
          }
        }
      }
    },
    render: ({ b, t, kieu }) => {
      const cong = kieu === 'cong';
      // Phép cộng: ô vuông là SỐ HẠNG, lấy tổng trừ số hạng đã biết.
      // Phép trừ:  ô vuông là SỐ BỊ TRỪ trong "□ − b = t − b", nên nó đúng bằng t.
      const an = cong ? t - b : t;
      return {
        stem: cong
          ? `Tìm số còn thiếu: $\\square + ${b} = ${t}$.`
          : `Tìm số còn thiếu: $\\square - ${b} = ${t - b}$.`,
        solutionSteps: [
          {
            viec: cong
              ? `Ô vuông là số hạng chưa biết của phép cộng, tổng là $${t}$.`
              : `Ô vuông là số bị trừ chưa biết, hiệu là $${t - b}$.`,
            canCu: 'Gọi tên đúng thành phần chưa biết thì mới chọn đúng phép tính ngược.',
          },
          {
            viec: cong
              ? `Muốn tìm số hạng chưa biết thì lấy tổng trừ số hạng đã biết: $${t} - ${b} = ${an}$.`
              : `Muốn tìm số bị trừ thì lấy hiệu cộng số trừ: $${t - b} + ${b} = ${an}$.`,
            canCu: cong
              ? 'Phép trừ là phép tính ngược của phép cộng.'
              : 'Phép cộng là phép tính ngược của phép trừ.',
          },
          {
            viec: cong
              ? `Thử lại: $${an} + ${b} = ${t}$, đúng bằng tổng đã cho.`
              : `Thử lại: $${an} - ${b} = ${t - b}$, đúng bằng hiệu đã cho.`,
            canCu: 'Luôn thay số vừa tìm được vào phép tính ban đầu để kiểm tra.',
          },
        ],
        hints: [
          'Đọc kỹ xem ô vuông đứng ở vị trí nào trong phép tính.',
          cong ? 'Tìm số hạng thì dùng phép trừ.' : 'Tìm số bị trừ thì dùng phép cộng.',
          'Thử lại bằng cách thay số vừa tìm vào phép tính ban đầu.',
        ],
        answer: `${an}`,
        check: cong
          ? { equation: `x + ${b} = ${t}`, variable: 'x', roots: [an] }
          : { equation: `x - ${b} = ${t - b}`, variable: 'x', roots: [an] },
      };
    },
  },

  {
    id: 'BP.TH.DEM100.CAUTAOSO',
    formCode: 'M2.SO.DEM100',
    intent: 'Phân tích số có hai chữ số thành chục và đơn vị rồi so sánh hai số. Nền của mọi phép tính có nhớ về sau.',
    targetTrap: 'so sánh theo hàng đơn vị trước',
    context: 'số học',
    shape: { steps: 3, cases: 1 },
    stars: 2,
    levels: [0, 2],
    space: function* () {
      for (let c1 = 2; c1 <= 8; c1++) {
        for (let d1 = 1; d1 <= 9; d1++) {
          for (const lech of [1, 2]) {
            const c2 = c1 - lech;
            if (c2 < 1) continue;
            const d2 = 9 - d1 + 1;
            if (d2 > 9 || d2 < 1 || d2 <= d1) continue;
            yield { c1, d1, c2, d2 };
          }
        }
      }
    },
    render: ({ c1, d1, c2, d2 }) => {
      const n1 = c1 * 10 + d1;
      const n2 = c2 * 10 + d2;
      return {
        stem: `Cho hai số $${n1}$ và $${n2}$. Viết mỗi số thành số chục và số đơn vị, rồi cho biết số nào lớn hơn.`,
        solutionSteps: [
          {
            viec: `$${n1}$ gồm $${c1}$ chục và $${d1}$ đơn vị, tức $${n1} = ${c1} \\times 10 + ${d1}$.`,
            canCu: 'Số có hai chữ số bằng số chục nhân mười cộng số đơn vị.',
          },
          {
            viec: `$${n2}$ gồm $${c2}$ chục và $${d2}$ đơn vị, tức $${n2} = ${c2} \\times 10 + ${d2}$.`,
            canCu: 'Phân tích tương tự cho số thứ hai.',
          },
          {
            viec: `So sánh số chục trước: $${c1} > ${c2}$ nên $${n1} > ${n2}$, dù chữ số hàng đơn vị của $${n1}$ nhỏ hơn.`,
            canCu: 'So sánh hai số có hai chữ số thì xét hàng chục trước; chỉ khi hàng chục bằng nhau mới xét đến hàng đơn vị.',
          },
        ],
        hints: [
          'Chữ số bên trái là số chục, chữ số bên phải là số đơn vị.',
          'Một chục bằng mười đơn vị nên hàng chục quyết định trước.',
          'Đừng chỉ nhìn chữ số cuối cùng để so sánh.',
        ],
        answer: `${n1} lớn hơn ${n2}`,
        check: { expression: `(${c1})*10 + (${d1}) - ((${c2})*10 + (${d2}))`, equals: `${n1 - n2}` },
      };
    },
  },

  {
    id: 'BP.TH.HINH.DEMCANHDINH',
    formCode: 'M1.HINH.NHANDANG',
    intent: 'Nhận dạng hình rồi đếm cạnh và đỉnh của nó. Bước đếm buộc học viên nhìn vào tính chất của hình chứ không nhìn vào tên gọi.',
    targetTrap: 'lẫn khi hình bị xoay',
    context: 'hình học',
    shape: { steps: 3, cases: 1 },
    stars: 2,
    levels: [0, 1],
    space: function* () {
      const hinh = [
        { ten: 'hình tam giác', canh: 3, dinh: 3, dauHieu: 'có ba cạnh thẳng khép kín' },
        { ten: 'hình vuông', canh: 4, dinh: 4, dauHieu: 'có bốn cạnh thẳng và bốn cạnh dài bằng nhau' },
        { ten: 'hình chữ nhật', canh: 4, dinh: 4, dauHieu: 'có bốn cạnh thẳng, hai cạnh đối diện dài bằng nhau' },
      ];
      for (const h of hinh) {
        for (const so of [2, 3, 4, 5]) {
          for (const dv of ['que tính', 'thanh gỗ']) yield { h, so, dv };
        }
      }
    },
    render: ({ h, so, dv }) => {
      const tongCanh = h.canh * so;
      return {
        stem: `Bạn An xếp $${so}$ ${h.ten} rời nhau. Mỗi cạnh của hình là một ${dv} thẳng. `
          + `Hỏi An cần bao nhiêu ${dv}? Cả $${so}$ hình có bao nhiêu đỉnh?`,
        solutionSteps: [
          {
            viec: `Mỗi ${h.ten} ${h.dauHieu} nên nó có $${h.canh}$ cạnh.`,
            canCu: 'Đếm số cạnh theo dấu hiệu của hình, không đoán theo tên gọi.',
          },
          {
            viec: `Một cạnh cần một ${dv}, nên $${so}$ hình cần $${h.canh} \\times ${so} = ${tongCanh}$ ${dv}.`,
            canCu: 'Mỗi hình cần số que đúng bằng số cạnh của nó; các hình rời nhau nên không dùng chung cạnh nào.',
          },
          {
            viec: `Mỗi ${h.ten} có số đỉnh bằng số cạnh, tức $${h.dinh}$ đỉnh, nên tổng cộng có $${h.dinh} \\times ${so} = ${h.dinh * so}$ đỉnh.`,
            canCu: 'Với hình khép kín bằng các đoạn thẳng, mỗi cạnh nối hai đỉnh và mỗi đỉnh là điểm gặp của hai cạnh, nên số đỉnh bằng số cạnh.',
          },
        ],
        hints: [
          'Đếm xem một hình có mấy cạnh trước đã.',
          'Các hình rời nhau nên không hình nào dùng chung cạnh với hình nào.',
          'Số đỉnh của các hình này bằng đúng số cạnh của chúng.',
        ],
        answer: `${tongCanh} ${dv}, ${h.dinh * so} đỉnh`,
        check: { expression: `(${h.canh})*(${so}) + (${h.dinh})*(${so})`, equals: `${tongCanh + h.dinh * so}` },
      };
    },
  },

  {
    id: 'BP.TH.DODAI.GHEPDOAN',
    formCode: 'M1.DO.DODAI',
    intent: 'Cộng hai đoạn đo được rồi so với một mốc cho trước. Không chỉ đo, mà còn phải trả lời câu hỏi đủ hay thiếu.',
    targetTrap: 'đặt thước không khớp vạch 0',
    context: 'đo lường',
    shape: { steps: 3, cases: 1 },
    stars: 2,
    levels: [0, 2],
    space: function* () {
      for (let a = 3; a <= 9; a++) {
        for (let b = 2; b <= 9; b++) {
          for (const moc of [10, 12, 15]) {
            if (a + b > 20) continue;
            yield { a, b, moc };
          }
        }
      }
    },
    render: ({ a, b, moc }) => {
      const tong = a + b;
      const du = tong >= moc;
      const lech = Math.abs(tong - moc);
      return {
        stem: `Một băng giấy dài $${a}$ xăng-ti-mét. Nối thẳng nó với một băng giấy dài $${b}$ xăng-ti-mét. `
          + `Băng giấy sau khi nối dài bao nhiêu xăng-ti-mét? Có đủ dài để che kín một vết mực dài $${moc}$ xăng-ti-mét không?`,
        solutionSteps: [
          {
            viec: `Nối thẳng hai băng giấy thì độ dài cộng lại: $${a} + ${b} = ${tong}$ xăng-ti-mét.`,
            canCu: 'Hai đoạn nối thẳng nhau, không chồng lên nhau, thì độ dài tổng bằng tổng hai độ dài.',
          },
          {
            viec: `So với vết mực: $${tong}$ xăng-ti-mét và $${moc}$ xăng-ti-mét, ta có $${tong} ${du ? '\\ge' : '<'} ${moc}$.`,
            canCu: 'So sánh hai độ dài chỉ hợp lệ khi chúng cùng đơn vị đo; ở đây cả hai đều tính bằng xăng-ti-mét.',
          },
          {
            viec: du
              ? `Vậy băng giấy dài $${tong}$ xăng-ti-mét và ĐỦ để che kín, còn thừa $${lech}$ xăng-ti-mét.`
              : `Vậy băng giấy dài $${tong}$ xăng-ti-mét và CHƯA đủ để che kín, còn thiếu $${lech}$ xăng-ti-mét.`,
            canCu: 'Câu hỏi có hai ý nên câu trả lời phải có đủ hai ý: độ dài sau khi nối và kết luận đủ hay thiếu.',
          },
        ],
        hints: [
          'Nối thẳng hai đoạn thì lấy phép cộng.',
          'Đọc số đo bắt đầu từ vạch số không của thước, không phải từ mép thước.',
          'Trả lời đủ cả hai ý mà đề hỏi.',
        ],
        answer: `${tong} xăng-ti-mét, ${du ? `đủ, thừa ${lech}` : `chưa đủ, thiếu ${lech}`} xăng-ti-mét`,
        check: { expression: `(${a}) + (${b}) - (${moc})`, equals: `${tong - moc}` },
      };
    },
  },

  // ══ BA SAO — NHIỀU BƯỚC TRÊN NỀN CAO ═══════════════════════════════════

  {
    id: 'BP.VD.MATCAU.VITRITUONGDOI',
    formCode: 'M12.OXYZ.MATCAU',
    intent: 'So khoảng cách từ tâm đến mặt phẳng với bán kính, rồi tính bán kính đường tròn giao tuyến. Ba bước nối nhau.',
    targetTrap: 'sai công thức khoảng cách tâm đến mặt phẳng',
    context: 'toạ độ không gian',
    shape: { steps: 4, cases: 1 },
    stars: 3,
    levels: [4, 9],
    space: function* () {
      // Chọn bộ (d, r, R) Pythagore để bán kính giao tuyến ra số đẹp.
      for (const [d, r, R] of [[3, 4, 5], [4, 3, 5], [6, 8, 10], [5, 12, 13], [8, 15, 17], [9, 12, 15], [12, 5, 13], [7, 24, 25]]) {
        for (const a of [1, 2, -1]) {
          for (const b of [2, -2, 1]) {
            yield { d, r, R, a, b };
          }
        }
      }
    },
    render: ({ d, r, R, a, b }) => {
      // Mặt phẳng (P): z = 0 dịch đi — dùng (P): 2x - y + 2z + D = 0 (chuẩn 3).
      const c = 2;                                     // toạ độ z của tâm
      const D = 3 * d - (2 * a - b + 2 * c);           // để d(I,(P)) = |...| / 3 = d
      const ve = `${poly([[2, 'x'], [-1, 'y'], [2, 'z'], [D, '']])} = 0`;
      return {
        stem: `Trong không gian $Oxyz$ cho mặt cầu $(S)$ tâm $I\\left(${a};\\ ${b};\\ ${c}\\right)$ bán kính $R = ${R}$ `
          + `và mặt phẳng $(P): ${ve}$. Xét vị trí tương đối của $(S)$ và $(P)$; nếu chúng cắt nhau thì tính bán kính đường tròn giao tuyến.`,
        solutionSteps: [
          {
            viec: `Khoảng cách từ tâm đến mặt phẳng: $d\\left(I, (P)\\right) = \\dfrac{\\left|2 \\cdot ${a} - ${b} + 2 \\cdot ${c} ${D >= 0 ? '+' : '-'} ${Math.abs(D)}\\right|}{\\sqrt{2^{2} + \\left(-1\\right)^{2} + 2^{2}}}$.`,
            canCu: 'Công thức khoảng cách từ điểm đến mặt phẳng: tử là giá trị tuyệt đối khi thay toạ độ điểm vào vế trái, mẫu là độ dài vectơ pháp tuyến.',
          },
          {
            viec: `Mẫu số $\\sqrt{4 + 1 + 4} = 3$, tử số bằng $${3 * d}$, nên $d\\left(I, (P)\\right) = \\dfrac{${3 * d}}{3} = ${d}$.`,
            canCu: 'Rút gọn sau khi tính riêng tử và mẫu, tránh nhầm dấu ở bước lấy giá trị tuyệt đối.',
          },
          {
            viec: `So sánh: $d = ${d} < R = ${R}$, nên mặt phẳng CẮT mặt cầu theo một đường tròn.`,
            canCu: 'Quy tắc vị trí tương đối: $d < R$ thì cắt theo đường tròn, $d = R$ thì tiếp xúc, $d > R$ thì không có điểm chung.',
          },
          {
            viec: `Bán kính đường tròn giao tuyến: $r = \\sqrt{R^{2} - d^{2}} = \\sqrt{${R * R} - ${d * d}} = \\sqrt{${R * R - d * d}} = ${r}$.`,
            canCu: 'Bán kính mặt cầu, khoảng cách từ tâm tới mặt phẳng và bán kính giao tuyến lập thành một tam giác vuông.',
          },
        ],
        hints: [
          'Tính khoảng cách từ tâm đến mặt phẳng trước, đừng vội kết luận.',
          'Mẫu số của công thức khoảng cách là độ dài vectơ pháp tuyến, không phải $3$ cho mọi mặt phẳng.',
          'Bán kính giao tuyến lấy theo Pythagore, không phải hiệu $R - d$.',
        ],
        answer: `cắt nhau, r = ${r}`,
        check: { expression: `sqrt((${R})^2 - (abs(2*(${a}) - (${b}) + 2*(${c}) + (${D}))/sqrt(9))^2)`, equals: `${r}` },
      };
    },
  },

  {
    id: 'BP.VD.SUYLUAN.BANGDOICHIEU',
    formCode: 'X.LOGIC.SUYLUAN',
    intent: 'Ba dữ kiện phủ định lồng nhau, phải lập bảng loại trừ mới ra. Không có đường tắt nào ngắn hơn.',
    targetTrap: 'kết luận khi chưa đối chiếu hết dữ kiện',
    context: 'suy luận',
    shape: { steps: 5, cases: 1 },
    stars: 3,
    levels: [5, 9],
    space: function* () {
      const mon = [['Toán', 'Văn', 'Anh'], ['Lý', 'Hoá', 'Sinh'], ['Sử', 'Địa', 'Tin']];
      for (const m of mon) {
        for (let i = 0; i < 6; i++) {
          for (const hv of [[0, 1, 2], [1, 2, 0], [2, 0, 1]]) yield { m, i, hv };
        }
      }
    },
    render: ({ m, i, hv }) => {
      const ban = [TEN[i % TEN.length], TEN[(i + 3) % TEN.length], TEN[(i + 6) % TEN.length]];
      // hv[k] = chỉ số môn mà bạn thứ k học. Hoán vị nên mỗi bạn một môn.
      const [x, y, z] = hv;
      const diem = [7, 8, 9];
      return {
        stem: `Ba bạn ${ban[0]}, ${ban[1]}, ${ban[2]} học ba môn ${m[0]}, ${m[1]}, ${m[2]}. `
          + 'Mỗi bạn giỏi đúng một môn, và không bạn nào giỏi cùng môn với bạn khác. '
          + `${ban[0]} không giỏi ${m[(x + 1) % 3]}. ${ban[0]} cũng không giỏi ${m[(x + 2) % 3]}. `
          + `${ban[1]} không giỏi ${m[(y + 1) % 3]}. Hỏi mỗi bạn giỏi môn nào?`,
        solutionSteps: [
          {
            viec: `Dữ kiện thứ nhất loại ${m[(x + 1) % 3]} và ${m[(x + 2) % 3]} khỏi ${ban[0]}.`,
            canCu: 'Mỗi câu phủ định là một ô bị gạch trong bảng đối chiếu người – môn.',
          },
          {
            viec: `Chỉ còn một môn chưa bị loại nên ${ban[0]} giỏi ${m[x]}.`,
            canCu: 'Khi một hàng chỉ còn đúng một ô trống thì ô đó chính là đáp án của hàng ấy.',
          },
          {
            viec: `${m[x]} đã thuộc về ${ban[0]} nên hai bạn còn lại không thể giỏi môn này.`,
            canCu: 'Mỗi môn chỉ có một người giỏi, nên xác định được một ô thì cả cột đó bị gạch.',
          },
          {
            viec: `Dữ kiện thứ hai loại thêm ${m[(y + 1) % 3]} khỏi ${ban[1]}, nên ${ban[1]} giỏi ${m[y]}.`,
            canCu: 'Kết hợp dữ kiện mới với các ô vừa bị gạch ở bước trước.',
          },
          {
            viec: `Môn còn lại là ${m[z]}, thuộc về ${ban[2]}. Kiểm lại cả ba dữ kiện đều thoả mãn.`,
            canCu: 'Sau khi điền xong phải đối chiếu ngược lại với TẤT CẢ dữ kiện, không chỉ dữ kiện cuối.',
          },
        ],
        hints: [
          'Lập bảng ba hàng ba cột rồi gạch dần, đừng nhẩm trong đầu.',
          'Xác định được một ô thì gạch cả hàng và cả cột chứa ô đó.',
          'Kiểm lại toàn bộ dữ kiện sau khi điền xong bảng.',
        ],
        answer: `${ban[0]} giỏi ${m[x]}, ${ban[1]} giỏi ${m[y]}, ${ban[2]} giỏi ${m[z]}`,
        // Mã hoá lời giải thành số để máy kiểm: ba chỉ số môn phải là một hoán
        // vị của {0; 1; 2}, nên tổng bằng 3 và tổng bình phương bằng 5.
        check: { expression: `(${x}) + (${y}) + (${z}) + 100*((${x})^2 + (${y})^2 + (${z})^2)`, equals: `${3 + 100 * 5}` },
      };
    },
  },

  {
    id: 'BP.VD.SAPXEP.LICHTRUC',
    formCode: 'X.LOGIC.SAPXEP',
    intent: 'Xếp lịch với ràng buộc khoảng cách giữa hai lần trực. Phải quy về bất phương trình mới đếm đúng số cách.',
    targetTrap: 'đếm trùng các cách xếp đối xứng nhau',
    context: 'suy luận',
    shape: { steps: 4, cases: 1 },
    stars: 3,
    levels: [4, 9],
    space: function* () {
      for (let n = 6; n <= 14; n++) {
        for (let k = 2; k <= 4; k++) {
          if (n - 2 * (k - 1) < 1) continue;
          yield { n, k };
        }
      }
    },
    render: ({ n, k }) => {
      // Chọn 2 ngày trong n ngày sao cho cách nhau ÍT NHẤT k ngày.
      // Số cách = C(n - k + 1, 2).
      const mIn = n - k + 1;
      const soCach = (mIn * (mIn - 1)) / 2;
      const tatCa = (n * (n - 1)) / 2;
      return {
        stem: `Một lớp có $${n}$ ngày học liên tiếp, đánh số từ $1$ đến $${n}$. `
          + 'Cần chọn $2$ ngày trong đó để tổ chức kiểm tra. '
          + `Hai ngày được chọn phải cách nhau ít nhất $${k}$ ngày, nghĩa là hai số thứ tự chênh nhau không nhỏ hơn $${k}$. `
          + 'Hỏi có bao nhiêu cách chọn?',
        solutionSteps: [
          {
            viec: `Đánh số ngày từ $1$ đến $${n}$. Gọi hai ngày được chọn là $i < j$, điều kiện là $j - i \\ge ${k}$.`,
            canCu: 'Đặt biến cho đối tượng cần đếm và viết ràng buộc thành bất đẳng thức, thay vì đếm bằng tay.',
          },
          {
            viec: `Đặt $j' = j - ${k - 1}$. Khi đó điều kiện $j - i \\ge ${k}$ trở thành $j' - i \\ge 1$, tức $i < j'$.`,
            canCu: 'Phép đổi biến dịch chuyển giữ nguyên số cách chọn vì nó là một song ánh.',
          },
          {
            viec: `Vì $j \\le ${n}$ nên $j' \\le ${n} - ${k - 1} = ${mIn}$. Vậy $\\left(i;\\ j'\\right)$ là một cặp chỉ số phân biệt trong $\\left\\{1;\\ 2;\\ \\ldots;\\ ${mIn}\\right\\}$.`,
            canCu: 'Sau đổi biến, bài toán có ràng buộc trở thành bài toán chọn hai phần tử không ràng buộc.',
          },
          {
            viec: `Số cách $= C_{${mIn}}^{2} = \\dfrac{${mIn} \\times ${mIn - 1}}{2} = ${soCach}$ cách (so với $C_{${n}}^{2} = ${tatCa}$ cách khi không có ràng buộc).`,
            canCu: 'Công thức tổ hợp chập hai: $C_{m}^{2} = \\dfrac{m\\left(m-1\\right)}{2}$.',
          },
        ],
        hints: [
          'Đặt ẩn cho hai ngày rồi viết ràng buộc thành bất đẳng thức.',
          'Phép đổi biến dịch chuyển biến ràng buộc "cách nhau ít nhất" thành "khác nhau".',
          'Chọn hai ngày không phân biệt thứ tự nên dùng tổ hợp, không dùng chỉnh hợp.',
        ],
        answer: `${soCach} cách`,
        check: { expression: `((${n}) - (${k}) + 1)*((${n}) - (${k}))/2`, equals: `${soCach}` },
      };
    },
  },

  {
    id: 'BP.VD.TICHPHAN.HAIDOTHI',
    formCode: 'M12.UNGDUNG.TICHPHAN',
    intent: 'Diện tích giữa hai đồ thị. Phải tìm giao điểm để lấy cận trước, rồi mới lấy tích phân hiệu hai hàm — bỏ bước tìm cận là sai từ đầu.',
    targetTrap: 'không tách đoạn khi hàm đổi dấu',
    context: 'giải tích',
    shape: { steps: 5, cases: 1 },
    stars: 3,
    levels: [5, 9],
    space: function* () {
      for (const a of [1, 2, 3]) {
        for (const p2 of [-3, -2, -1, 1, 2]) {
          for (const q of [-4, -2, 0, 2]) {
            const delta = p2 * p2 - 4 * q;
            if (delta <= 0) continue;
            if (!Number.isInteger(Math.sqrt(delta))) continue;
            yield { a, p: p2, q };
          }
        }
      }
    },
    render: ({ a, p, q }) => {
      // (C1): y = a·x², (C2): y = a·(−p·x − q)  → giao điểm là nghiệm của x² + p·x + q = 0.
      const can = Math.sqrt(p * p - 4 * q);
      const x1 = (-p - can) / 2;
      const x2 = (-p + can) / 2;
      // ∫(x2 − x1) của −a(x² + px + q) = a·(x2 − x1)³ / 6
      const S = (a * (x2 - x1) ** 3) / 6;
      const duong = poly([[-a * p, 'x'], [-a * q, '']]);
      return {
        stem: `Tính diện tích hình phẳng giới hạn bởi parabol $y = ${a === 1 ? '' : a}x^{2}$ và đường thẳng $y = ${duong}$.`,
        solutionSteps: [
          {
            viec: `Tìm hoành độ giao điểm: $${a === 1 ? '' : a}x^{2} = ${duong}$, rút gọn thành $x^{2} ${p >= 0 ? '+' : '-'} ${Math.abs(p)}x ${q >= 0 ? '+' : '-'} ${Math.abs(q)} = 0$.`,
            canCu: 'Cận của tích phân là hoành độ giao điểm, nên phải giải phương trình hoành độ giao điểm TRƯỚC khi lấy tích phân.',
          },
          {
            viec: `Biệt thức $\\Delta = ${p * p} - 4 \\cdot \\left(${q}\\right) = ${p * p - 4 * q} > 0$, hai nghiệm $x_{1} = ${x1}$ và $x_{2} = ${x2}$.`,
            canCu: 'Công thức nghiệm phương trình bậc hai. Hai nghiệm phân biệt thì hình phẳng mới khép kín.',
          },
          {
            viec: `Trên khoảng $\\left(${x1};\\ ${x2}\\right)$, đường thẳng nằm TRÊN parabol, nên hiệu cần lấy là $\\left(${duong}\\right) - ${a === 1 ? '' : a}x^{2}$.`,
            canCu: 'Giữa hai giao điểm liên tiếp, hiệu hai hàm giữ nguyên dấu, nên chỉ cần xác định dấu một lần cho cả đoạn.',
          },
          {
            viec: `$S = \\displaystyle\\int_{${x1}}^{${x2}} \\left[\\left(${duong}\\right) - ${a === 1 ? '' : a}x^{2}\\right]dx$.`,
            canCu: 'Công thức diện tích giữa hai đồ thị: lấy tích phân của hàm TRÊN trừ hàm DƯỚI trên đoạn giữa hai giao điểm.',
          },
          {
            viec: `Tính được $S = ${tiSo(a * (x2 - x1) ** 3, 6)}$ (đơn vị diện tích).`,
            canCu: 'Với hai giao điểm $x_{1} < x_{2}$ của một parabol và một đường thẳng, diện tích bằng $\\dfrac{\\left|a\\right|\\left(x_{2} - x_{1}\\right)^{3}}{6}$ — kết quả này dùng để đối chiếu nhanh.',
          },
        ],
        hints: [
          'Tìm giao điểm trước, vì chính chúng là cận của tích phân.',
          'Giữa hai giao điểm, xác định đường nào nằm trên bằng cách thử một điểm.',
          'Lấy hàm trên trừ hàm dưới thì tích phân ra số dương, không cần dấu giá trị tuyệt đối.',
        ],
        answer: `S = ${tiSo(a * (x2 - x1) ** 3, 6)}`,
        // Kiểm bằng Simpson trên hiệu hai hàm — Simpson chính xác tuyệt đối với
        // đa thức bậc hai, nên đây là phép kiểm đúng chứ không phải xấp xỉ.
        check: {
          expression: simpson((x) => `((${-a * p})*(${x}) + (${-a * q})) - (${a})*(${x})^2`, String(x1), String(x2), 2),
          equals: tiSo(a * (x2 - x1) ** 3, 6),
        },
      };
    },
  },

  {
    id: 'BP.VD.DAYSO.HIEUBACHAI',
    formCode: 'X.LOGIC.DAYSO',
    intent: 'Dãy mà hiệu của các hiệu mới không đổi. Thử hiệu một lần thấy không đều rồi bỏ cuộc là hỏng — phải thử tiếp hiệu của hiệu.',
    targetTrap: 'dừng ở quy luật bậc nhất khi thực tế là bậc hai',
    context: 'dãy số',
    shape: { steps: 5, cases: 1 },
    stars: 3,
    levels: [3, 9],
    space: function* () {
      for (const a of [1, 2, 3]) {
        for (const b of [0, 1, -1, 2]) {
          for (const c of [1, 2, 5, -3]) {
            if (a === 1 && b === 0 && c === 1) continue;
            yield { a, b, c };
          }
        }
      }
    },
    render: ({ a, b, c }) => {
      // uₙ = a·n² + b·n + c. Hiệu bậc nhất: a(2n+1)+b. Hiệu bậc hai: 2a (hằng).
      const u = (n) => a * n * n + b * n + c;
      const ds = [1, 2, 3, 4, 5].map(u);
      const h = [0, 1, 2, 3].map((i) => ds[i + 1] - ds[i]);
      const hh = [0, 1, 2].map((i) => h[i + 1] - h[i]);
      const tiep = u(6);
      return {
        stem: `Cho dãy số $${ds.join(';\\ ')};\\ \\ldots$ Tìm số hạng tiếp theo của dãy.`,
        solutionSteps: [
          {
            viec: `Xét hiệu hai số liền nhau: $${h.join(';\\ ')}$. Các hiệu này KHÔNG bằng nhau, nên dãy không phải cấp số cộng.`,
            canCu: 'Cấp số cộng có hiệu hai số liền nhau không đổi; hiệu thay đổi thì phải tìm quy luật ở lớp sâu hơn.',
          },
          {
            viec: `Xét tiếp hiệu CỦA CÁC HIỆU: $${hh.join(';\\ ')}$. Lần này chúng bằng nhau và bằng $${2 * a}$.`,
            canCu: 'Khi hiệu bậc hai là hằng số thì số hạng tổng quát là một đa thức bậc hai theo $n$.',
          },
          {
            viec: `Hiệu bậc hai bằng $${2 * a}$ nên hệ số bậc hai của $u_{n}$ là $\\dfrac{${2 * a}}{2} = ${a}$.`,
            canCu: 'Với $u_{n} = an^{2} + bn + c$, hiệu bậc hai luôn bằng $2a$ — quan hệ này cho ngay hệ số $a$.',
          },
          {
            viec: `Thay $n = 1$ và $n = 2$ vào $u_{n} = ${a === 1 ? '' : a}n^{2} + bn + c$ rồi giải hệ, được $b = ${b}$ và $c = ${c}$.`,
            canCu: 'Còn hai hệ số chưa biết thì cần đúng hai số hạng đã cho để lập hệ hai phương trình.',
          },
          {
            viec: `Vậy $u_{n} = ${poly([[a, 'n^{2}'], [b, 'n'], [c, '']])}$, nên $u_{6} = ${tiep}$.`,
            canCu: 'Có công thức tổng quát thì tính được số hạng ở BẤT KỲ vị trí nào, không phải cộng dồn từng bước.',
          },
        ],
        hints: [
          'Hiệu không đều thì đừng bỏ cuộc — thử hiệu của các hiệu.',
          'Hiệu bậc hai là hằng số nghĩa là công thức tổng quát bậc hai.',
          'Hiệu bậc hai bằng hai lần hệ số bậc hai.',
        ],
        answer: `${tiep}`,
        // Kiểm bằng ĐẶC TRƯNG của dãy bậc hai: sai phân bậc hai ở vị trí bất kỳ
        // đều bằng nhau. Không dùng lại công thức tổng quát trong lời giải.
        check: {
          expression: `((${tiep}) - (${ds[4]})) - ((${ds[4]}) - (${ds[3]}))`,
          equals: `${2 * a}`,
        },
      };
    },
  },

  // ══ BỐN SAO — ĐỦ MẶT Ở TẦNG CAO NHẤT ═══════════════════════════════════

  {
    id: 'BP.VDC.DOCHIEU.DOICHIEUNGUON',
    formCode: 'X.DOCHIEU.KHOAHOC',
    intent: 'Hai nguồn số liệu nói khác nhau về cùng một đại lượng; phải quy về cùng đơn vị mới so sánh được, rồi mới kết luận nguồn nào bao hàm nguồn nào.',
    targetTrap: 'so sánh hai số liệu khác đơn vị mà không quy đổi',
    context: 'văn bản khoa học',
    shape: { steps: 5, cases: 1 },
    stars: 4,
    levels: [6, 9],
    space: function* () {
      for (const tanMoiNgay of [12, 15, 18, 24, 30]) {
        for (const soNgay of [30, 90, 180]) {
          for (const lech of [0, 10, 20]) yield { tanMoiNgay, soNgay, lech };
        }
      }
    },
    render: ({ tanMoiNgay, soNgay, lech }) => {
      const tong = tanMoiNgay * soNgay;                       // tấn trong kỳ, theo nguồn A
      const kgMoiNgay = tanMoiNgay * 1000;
      const nguonB = tong + (tong * lech) / 100;              // tấn trong kỳ, theo nguồn B
      const khop = lech === 0;
      return {
        stem: `Một thị trấn thu gom rác trong $${soNgay}$ ngày. Có hai báo cáo về lượng rác đó.\n\n`
          + `Báo cáo A: mỗi ngày thu gom $${kgMoiNgay}$ ki-lô-gam.\n\n`
          + `Báo cáo B: cả kỳ thu gom $${nguonB}$ tấn.\n\n`
          + 'Hai báo cáo có khớp nhau không? Nếu lệch thì lệch bao nhiêu phần trăm so với báo cáo A?',
        solutionSteps: [
          {
            viec: `Quy báo cáo A về tấn: $${kgMoiNgay}$ ki-lô-gam $= ${tanMoiNgay}$ tấn mỗi ngày.`,
            canCu: 'Một tấn bằng $1000$ ki-lô-gam. Chưa cùng đơn vị thì chưa được phép so sánh.',
          },
          {
            viec: `Cả kỳ theo báo cáo A: $${tanMoiNgay} \\times ${soNgay} = ${tong}$ tấn.`,
            canCu: 'Lượng cả kỳ bằng lượng mỗi ngày nhân số ngày, với giả thiết mức thu gom đều.',
          },
          {
            viec: `Báo cáo B ghi $${nguonB}$ tấn. Hiệu hai báo cáo: $${nguonB} - ${tong} = ${nguonB - tong}$ tấn.`,
            canCu: 'So sánh hai giá trị chỉ có nghĩa sau khi cả hai đã cùng đơn vị và cùng khoảng thời gian.',
          },
          {
            viec: khop
              ? 'Hiệu bằng $0$ nên hai báo cáo khớp nhau hoàn toàn.'
              : `Tỉ lệ lệch so với báo cáo A: $\\dfrac{${nguonB - tong}}{${tong}} \\times 100\\% = ${lech}\\%$.`,
            canCu: 'Câu hỏi nói "so với báo cáo A" nên mẫu số là số liệu của báo cáo A.',
          },
          {
            viec: khop
              ? 'Kết luận: hai báo cáo nhất quán, không cần hiệu chỉnh.'
              : `Kết luận: hai báo cáo lệch nhau $${lech}\\%$; cần kiểm tra lại cách đo hoặc phạm vi thu gom của một trong hai nguồn trước khi dùng số liệu.`,
            canCu: 'Khi hai nguồn lệch nhau, kết luận đúng là nêu mức lệch và đề nghị kiểm chứng, không phải chọn bừa một nguồn.',
          },
        ],
        hints: [
          'Quy về cùng đơn vị trước khi so sánh bất cứ điều gì.',
          'Nhân lượng mỗi ngày với số ngày để ra lượng cả kỳ.',
          'Cụm "so với báo cáo A" chỉ ra mẫu số của phép tính phần trăm.',
        ],
        answer: khop ? 'hai báo cáo khớp nhau' : `lệch ${lech}% so với báo cáo A`,
        check: { expression: `((${nguonB}) - (${kgMoiNgay})/1000*(${soNgay}))/((${kgMoiNgay})/1000*(${soNgay}))*100`, equals: `${lech}` },
      };
    },
  },
];

module.exports = { BP_NEN_TANG };
