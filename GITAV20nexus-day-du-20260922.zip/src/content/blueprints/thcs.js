'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BẢN THIẾT KẾ BÀI — TRUNG HỌC CƠ SỞ (lớp 6 đến lớp 9)
 * ═══════════════════════════════════════════════════════════════════════════
 *  Cấp này là chỗ học sinh rơi rụng nhiều nhất, vì lần đầu phải làm việc với
 *  số âm, với chữ thay số, và với lập luận hình học. Mỗi bản dưới đây nhằm
 *  vào đúng một chỗ rơi đã khai trong danh mục bẫy.
 *
 *  Với dạng chứng minh hình học, bài sinh ra là câu hỏi TÍNH ĐƯỢC rút từ
 *  chính cấu hình hình học đó (tính cạnh, tính góc). Máy kiểm được đáp số nên
 *  bài vào kho là bài đã đúng; phần chứng minh vẫn do người dạy hướng dẫn.
 *  Nói thẳng như vậy còn hơn sinh ra một "bài chứng minh" mà không ai kiểm.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { frac, thap, gcd, poly } = require('./chung');

const BP_THCS = [

  // ══ LỚP 6 ══════════════════════════════════════════════════════════════
  {
    id: 'BP.M6.SONGUYEN.BOTNGOAC',
    formCode: 'M6.SONGUYEN.CONGTRU',
    intent: 'Bỏ ngoặc có dấu trừ đứng trước — chỗ mất điểm nhiều nhất khi mới học số âm.',
    targetTrap: 'sai dấu khi bỏ ngoặc có dấu trừ đằng trước',
    context: 'số học thuần',
    shape: { steps: 3, cases: 1 },
    stars: 3,
    levels: [2, 4],
    space: function* () {
      for (let a = -20; a <= 20; a += 3) {
        for (let b = -15; b <= 15; b += 2) {
          for (let c = -12; c <= 12; c += 4) {
            if (b === 0 || c === 0) continue;
            if (b > 0 && c > 0) continue;        // phải có ít nhất một số âm trong ngoặc
            yield { a, b, c };
          }
        }
      }
    },
    render: ({ a, b, c }) => {
      const kq = a - (b + c);
      const vietSo = (x) => (x < 0 ? `(${x})` : `${x}`);
      return {
        stem: `Tính: $${a} - \\left(${b} ${c < 0 ? '-' : '+'} ${Math.abs(c)}\\right)$.`,
        solutionSteps: [
          {
            viec: `Dấu trừ trước ngoặc đổi dấu MỌI số hạng trong ngoặc.`,
            canCu: 'Quy tắc dấu ngoặc: dấu trừ đứng trước ngoặc thì khi bỏ ngoặc phải đổi dấu MỌI số hạng bên trong, không chỉ số hạng đầu.',
          },
          {
            viec: `$${a} - \\left(${b} ${c < 0 ? '-' : '+'} ${Math.abs(c)}\\right) = ${a} ${-b < 0 ? '-' : '+'} ${Math.abs(b)} ${-c < 0 ? '-' : '+'} ${Math.abs(c)}$.`,
            canCu: 'Viết lại biểu thức sau khi đã đổi dấu đầy đủ.',
          },
          {
            viec: `$= ${kq}$.`,
            canCu: 'Cộng các số nguyên theo quy tắc dấu.',
          },
        ],
        hints: [
          'Bỏ ngoặc sau dấu trừ thì đổi dấu tất cả, không chỉ số đầu tiên.',
          `Trong ngoặc có $${vietSo(b)}$ và $${vietSo(c)}$, cả hai đều phải đổi dấu.`,
        ],
        answer: `${kq}`,
        check: { expression: `${a} - (${b} + (${c}))`, equals: `${kq}` },
      };
    },
  },
  {
    id: 'BP.M6.LUYTHUA.COSOKHAC',
    formCode: 'M6.LUYTHUA.TUNHIEN',
    intent: 'Nhân hai luỹ thừa CÙNG cơ số và so với trường hợp khác cơ số — chặn thói quen cộng số mũ bừa.',
    targetTrap: 'cộng số mũ khi nhân cơ số khác nhau',
    context: 'số học thuần',
    shape: { steps: 3, cases: 2 },
    stars: 3,
    levels: [2, 4],
    space: function* () {
      for (const a of [2, 3, 5]) {
        for (let m = 2; m <= 5; m++) {
          for (let n = 2; n <= 4; n++) {
            if (a ** (m + n) > 100000) continue;
            yield { a, m, n };
          }
        }
      }
    },
    render: ({ a, m, n }) => ({
      stem: `Viết kết quả dưới dạng một luỹ thừa: $${a}^{${m}} \\cdot ${a}^{${n}}$.`,
      solutionSteps: [
          {
            viec: 'Nhân hai luỹ thừa CÙNG cơ số thì giữ nguyên cơ số và CỘNG số mũ.',
            canCu: 'Quy tắc nhân hai luỹ thừa cùng cơ số: $a^{m} \\cdot a^{n} = a^{m+n}$. Chỉ dùng được khi hai cơ số GIỐNG nhau.',
          },
          {
            viec: `$${a}^{${m}} \\cdot ${a}^{${n}} = ${a}^{${m} + ${n}} = ${a}^{${m + n}}$.`,
            canCu: 'Áp dụng quy tắc: giữ nguyên cơ số, cộng hai số mũ.',
          },
          {
            viec: `Giá trị bằng $${a ** (m + n)}$.`,
            canCu: 'Tính giá trị của luỹ thừa vừa thu gọn.',
          },
        ],
      hints: [
        'Quy tắc cộng số mũ chỉ đúng khi hai luỹ thừa cùng cơ số.',
        `Nếu là $${a}^{${m}} \\cdot ${a + 1}^{${n}}$ thì KHÔNG được cộng số mũ.`,
      ],
      answer: `${a}^{${m + n}}`,
      check: { expression: `${a}^${m} * ${a}^${n}`, equals: `${a}^${m + n}` },
    }),
  },
  {
    id: 'BP.M6.PHANSO.CHIA',
    formCode: 'M6.PHANSO.NHANCHIA',
    intent: 'Chia phân số — buộc nhân với nghịch đảo, không chia thẳng tử cho tử.',
    targetTrap: 'quên nghịch đảo khi chia',
    context: 'số học thuần',
    shape: { steps: 3, cases: 1 },
    stars: 3,
    levels: [2, 5],
    space: function* () {
      for (let a = 2; a <= 9; a++) {
        for (let b = 3; b <= 12; b++) {
          for (let c = 2; c <= 9; c++) {
            for (let d = 3; d <= 12; d++) {
              if (gcd(a, b) !== 1 || gcd(c, d) !== 1) continue;
              // Cố ý chọn trường hợp a chia hết cho c — chia thẳng tử cho tử
              // cũng ra số nguyên, nên lỗi không tự lộ ra.
              if (a % c !== 0) continue;
              yield { a, b, c, d };
            }
          }
        }
      }
    },
    render: ({ a, b, c, d }) => ({
      stem: `Tính: $\\dfrac{${a}}{${b}} : \\dfrac{${c}}{${d}}$.`,
      solutionSteps: [
          {
            viec: 'Chia cho một phân số là NHÂN với phân số nghịch đảo của nó.',
            canCu: 'Quy tắc chia phân số: $\\dfrac{a}{b} : \\dfrac{c}{d} = \\dfrac{a}{b} \\cdot \\dfrac{d}{c}$ với $c \\ne 0$.',
          },
          {
            viec: `$\\dfrac{${a}}{${b}} : \\dfrac{${c}}{${d}} = \\dfrac{${a}}{${b}} \\cdot \\dfrac{${d}}{${c}} = \\dfrac{${a * d}}{${b * c}}$.`,
            canCu: 'Nhân hai phân số thì nhân tử với tử, mẫu với mẫu.',
          },
          {
            viec: `Rút gọn: $${frac(a * d, b * c)}$.`,
            canCu: 'Rút gọn phân số về dạng tối giản bằng cách chia cả tử và mẫu cho ước chung lớn nhất.',
          },
        ],
      hints: [
        'Đảo ngược phân số thứ hai rồi mới nhân.',
        `Chia thẳng tử cho tử và mẫu cho mẫu là sai, dù kết quả có ra số đẹp.`,
      ],
      answer: frac(a * d, b * c),
      check: { expression: `(${a}/${b})/(${c}/${d})`, equals: `${a * d}/${b * c}` },
    }),
  },
  {
    id: 'BP.M6.HINH.DEMMAT',
    formCode: 'M6.HINH.TRUCQUAN',
    intent: 'Đếm mặt, đỉnh, cạnh của hình lăng trụ đứng theo công thức thay vì đếm bằng mắt.',
    targetTrap: 'đếm sót mặt/cạnh của khối',
    context: 'hình học',
    shape: { steps: 3, cases: 1 },
    stars: 2,
    levels: [1, 3],
    space: function* () {
      for (let n = 3; n <= 10; n++) yield { n };
    },
    render: ({ n }) => {
      const ten = { 3: 'tam giác', 4: 'tứ giác', 5: 'ngũ giác', 6: 'lục giác' }[n] || `${n} cạnh`;
      return {
        stem: `Một hình lăng trụ đứng có đáy là đa giác ${ten}. Hình đó có bao nhiêu mặt, bao nhiêu cạnh?`,
        solutionSteps: [
          {
            viec: `Đáy là đa giác $${n}$ cạnh nên có $${n}$ mặt bên, cộng hai mặt đáy.`,
            canCu: 'Lăng trụ đứng có đáy là đa giác $n$ cạnh thì có $n$ mặt bên, mỗi mặt bên ứng với một cạnh đáy, cộng thêm hai mặt đáy.',
          },
          {
            viec: `Số mặt: $${n} + 2 = ${n + 2}$.`,
            canCu: 'Cộng số mặt bên với hai mặt đáy.',
          },
          {
            viec: `Số cạnh: $${n}$ cạnh đáy dưới, $${n}$ cạnh đáy trên và $${n}$ cạnh bên, tất cả là $3 \\cdot ${n} = ${3 * n}$.`,
            canCu: 'Cạnh của lăng trụ gồm ba nhóm: cạnh đáy dưới, cạnh đáy trên và cạnh bên, mỗi nhóm có đúng $n$ cạnh.',
          },
        ],
        hints: [
          'Đừng đếm trên hình vẽ, hãy đếm theo cấu tạo: mặt bên, mặt đáy, cạnh đáy, cạnh bên.',
          'Hai mặt đáy rất dễ bị bỏ quên.',
        ],
        answer: `${n + 2} mặt, ${3 * n} cạnh`,
        check: { expression: `${n} + 2 + 3*${n}`, equals: `${n + 2 + 3 * n}` },
      };
    },
  },
  {
    id: 'BP.M6.THONGKE.DOCTILE',
    formCode: 'M6.THONGKE.BANG',
    intent: 'Đọc biểu đồ có trục chia theo bậc lớn hơn 1 — chặn lỗi đếm ô thay vì đọc tỉ lệ trục.',
    targetTrap: 'đọc sai tỉ lệ trục',
    context: 'thực tế',
    shape: { steps: 3, cases: 1 },
    stars: 3,
    levels: [2, 4],
    space: function* () {
      for (const buoc of [5, 10, 20, 25, 50]) {
        for (let oA = 2; oA <= 9; oA++) {
          for (let oB = 1; oB < oA; oB++) yield { buoc, oA, oB };
        }
      }
    },
    render: ({ buoc, oA, oB }) => {
      const a = buoc * oA;
      const b = buoc * oB;
      return {
        stem: `Một biểu đồ cột có trục dọc chia mỗi vạch là $${buoc}$ học sinh. `
          + `Cột lớp 6A cao $${oA}$ vạch, cột lớp 6B cao $${oB}$ vạch. Lớp 6A nhiều hơn lớp 6B bao nhiêu học sinh?`,
        solutionSteps: [
          {
            viec: `Mỗi vạch ứng với $${buoc}$ học sinh, không phải $1$ học sinh.`,
            canCu: 'Phải đọc giá trị của MỘT vạch trên trục trước khi đếm, vì trục có thể chia theo bậc lớn hơn $1$.',
          },
          {
            viec: `Lớp 6A: $${oA} \\cdot ${buoc} = ${a}$ (học sinh). Lớp 6B: $${oB} \\cdot ${buoc} = ${b}$ (học sinh).`,
            canCu: 'Số lượng thật bằng số vạch nhân với giá trị của một vạch.',
          },
          {
            viec: `Nhiều hơn: $${a} - ${b} = ${a - b}$ (học sinh).`,
            canCu: 'So sánh hai số lượng bằng phép trừ.',
          },
        ],
        hints: [
          'Đọc tỉ lệ ghi trên trục trước khi đếm vạch.',
          `Chênh lệch $${oA - oB}$ vạch không phải là $${oA - oB}$ học sinh.`,
        ],
        answer: `${a - b} học sinh`,
        check: { expression: `${buoc}*${oA} - ${buoc}*${oB}`, equals: `${a - b}` },
      };
    },
  },

  // ══ LỚP 7 ══════════════════════════════════════════════════════════════
  {
    id: 'BP.M7.HUUTI.THUTU',
    formCode: 'M7.SOHUUTI.PHEPTINH',
    intent: 'Biểu thức có ngoặc, luỹ thừa và số âm — buộc làm đúng thứ tự phép tính.',
    targetTrap: 'quên thứ tự thực hiện phép tính',
    context: 'số học thuần',
    shape: { steps: 4, cases: 1 },
    stars: 3,
    levels: [2, 5],
    space: function* () {
      for (const a of [-3, -2, 2, 3]) {
        for (const b of [2, 3]) {
          for (const c of [-6, -4, 4, 6, 8]) {
            for (const d of [2, 4]) {
              if (c % d !== 0) continue;
              yield { a, b, c, d };
            }
          }
        }
      }
    },
    render: ({ a, b, c, d }) => {
      const kq = a ** b + c / d;
      return {
        stem: `Tính: $\\left(${a}\\right)^{${b}} + ${c} : ${d}$.`,
        solutionSteps: [
          {
            viec: 'Thứ tự: luỹ thừa trước, rồi nhân chia, sau cùng mới cộng trừ.',
            canCu: 'Thứ tự thực hiện phép tính: trong ngoặc trước, rồi luỹ thừa, rồi nhân chia, sau cùng cộng trừ.',
          },
          {
            viec: `$\\left(${a}\\right)^{${b}} = ${a ** b}$${a < 0 && b % 2 === 0 ? ' (số âm luỹ thừa bậc chẵn cho kết quả dương)' : ''}.`,
            canCu: 'Luỹ thừa bậc CHẴN của một số âm cho kết quả dương, vì các thừa số âm ghép đôi triệt tiêu dấu.',
          },
          {
            viec: `$${c} : ${d} = ${c / d}$.`,
            canCu: 'Thực hiện phép chia theo quy tắc dấu: âm chia dương ra âm.',
          },
          {
            viec: `$${a ** b} ${c / d < 0 ? '-' : '+'} ${Math.abs(c / d)} = ${kq}$.`,
            canCu: 'Cộng trừ từ trái sang phải sau khi mọi phép nhân chia và luỹ thừa đã xong.',
          },
        ],
        hints: [
          'Làm luỹ thừa trước khi cộng.',
          `Chú ý dấu: $\\left(${a}\\right)^{${b}}$ khác $-${Math.abs(a)}^{${b}}$.`,
        ],
        answer: `${kq}`,
        check: { expression: `(${a})^${b} + (${c})/${d}`, equals: `${kq}` },
      };
    },
  },
  {
    id: 'BP.M7.DAILUONG.NGHICH',
    formCode: 'M7.DAILUONG.TILE',
    intent: 'Bài tỉ lệ NGHỊCH có lời văn dễ đọc thành tỉ lệ thuận — chặn đúng chỗ nhầm.',
    targetTrap: 'nhầm tỉ lệ nghịch thành tỉ lệ thuận',
    context: 'thực tế',
    shape: { steps: 4, cases: 1 },
    stars: 4,
    levels: [3, 5],
    space: function* () {
      for (const n1 of [3, 4, 5, 6, 8, 10, 12]) {
        for (const t1 of [6, 8, 10, 12, 15, 20, 24, 30]) {
          for (const n2 of [2, 3, 4, 5, 6, 8, 10, 15]) {
            if (n2 === n1) continue;
            const tich = n1 * t1;
            if (tich % n2 !== 0) continue;
            if (tich / n2 > 120) continue;
            yield { n1, t1, n2 };
          }
        }
      }
    },
    render: ({ n1, t1, n2 }) => {
      const t2 = (n1 * t1) / n2;
      return {
        stem: `Có $${n1}$ người làm xong một công việc trong $${t1}$ giờ. `
          + `Hỏi $${n2}$ người làm xong công việc đó trong bao lâu, biết năng suất mỗi người như nhau?`,
        solutionSteps: [
          {
            viec: 'Cùng một công việc: càng nhiều người thì càng ít giờ, nên số người và số giờ là hai đại lượng TỈ LỆ NGHỊCH.',
            canCu: 'Hai đại lượng tỉ lệ nghịch khi đại lượng này tăng bao nhiêu lần thì đại lượng kia giảm đúng bấy nhiêu lần.',
          },
          {
            viec: `Tỉ lệ nghịch thì TÍCH không đổi: $${n1} \\cdot ${t1} = ${n2} \\cdot t$.`,
            canCu: 'Với hai đại lượng tỉ lệ nghịch, TÍCH của chúng là một hằng số — đây là chỗ khác hẳn tỉ lệ thuận.',
          },
          {
            viec: `$t = \\dfrac{${n1} \\cdot ${t1}}{${n2}} = \\dfrac{${n1 * t1}}{${n2}} = ${t2}$ (giờ).`,
            canCu: 'Tìm thừa số chưa biết thì lấy tích chia cho thừa số đã biết.',
          },
          {
            viec: `Đáp số: $${t2}$ giờ.`,
            canCu: 'Ghi đáp số kèm đơn vị đúng như đề hỏi.',
          },
        ],
        hints: [
          'Hỏi xem đại lượng kia tăng hay giảm khi đại lượng này tăng.',
          'Tỉ lệ thuận thì THƯƠNG không đổi, tỉ lệ nghịch thì TÍCH không đổi.',
        ],
        answer: `${t2} giờ`,
        check: { expression: `${n1}*${t1}/${n2}`, equals: `${t2}` },
      };
    },
  },
  {
    id: 'BP.M7.DATHUC.THUGON',
    formCode: 'M7.DATHUC.MOTBIEN',
    intent: 'Thu gọn đa thức có nhiều hạng tử không đồng dạng xen kẽ — chặn lỗi gộp bừa.',
    targetTrap: 'thu gọn nhầm hạng tử không đồng dạng',
    context: 'đại số thuần',
    shape: { steps: 3, cases: 1 },
    stars: 3,
    levels: [2, 5],
    space: function* () {
      for (let a = 1; a <= 5; a++) {
        for (let b = -6; b <= 6; b++) {
          for (let c = 1; c <= 5; c++) {
            for (let d = -5; d <= 5; d++) {
              if (b === 0 || d === 0 || a === c) continue;
              yield { a, b, c, d };
            }
          }
        }
      }
    },
    render: ({ a, b, c, d }) => {
      const x2 = a + c;
      const x1 = b + d;
      return {
        stem: `Thu gọn đa thức: $${poly([[a, 'x^{2}'], [b, 'x']])} + ${poly([[c, 'x^{2}'], [d, 'x']])}$.`,
        solutionSteps: [
          {
            viec: 'Chỉ cộng được các hạng tử ĐỒNG DẠNG, tức cùng phần biến và cùng số mũ.',
            canCu: 'Hai hạng tử đồng dạng là hai hạng tử có cùng phần biến và cùng số mũ; chỉ khi đó mới cộng được hệ số.',
          },
          {
            viec: `Hạng tử chứa $x^{2}$: $${a}x^{2} + ${c}x^{2} = ${x2}x^{2}$.`,
            canCu: 'Gom các hạng tử cùng bậc lại rồi cộng hệ số, giữ nguyên phần biến.',
          },
          {
            viec: `Hạng tử chứa $x$: $${b}x ${d < 0 ? '-' : '+'} ${Math.abs(d)}x = ${x1}x$. Vậy đa thức thu gọn là $${poly([[x2, 'x^{2}'], [x1, 'x']])}$.`,
            canCu: 'Gom nốt nhóm bậc còn lại và viết đa thức theo thứ tự giảm dần của số mũ.',
          },
        ],
        hints: [
          '$x^{2}$ và $x$ KHÔNG đồng dạng, không gộp được.',
          'Sắp xếp theo luỹ thừa giảm dần của biến cho gọn.',
        ],
        answer: poly([[x2, 'x^{2}'], [x1, 'x']]),
        check: { expression: `${a}*x^2 + (${b})*x + ${c}*x^2 + (${d})*x`, equals: `${x2}*x^2 + (${x1})*x` },
      };
    },
  },
  {
    id: 'BP.M7.TAMGIAC.THUTUDINH',
    formCode: 'M7.TAMGIAC.BANGNHAU',
    intent: 'Đọc cạnh tương ứng từ ký hiệu hai tam giác bằng nhau — chặn lỗi ghép sai thứ tự đỉnh.',
    targetTrap: 'ghi sai thứ tự đỉnh tương ứng',
    context: 'hình học',
    shape: { steps: 3, cases: 1 },
    stars: 3,
    levels: [2, 5],
    space: function* () {
      for (const ab of [5, 6, 7, 8, 9, 10, 12]) {
        for (const bc of [4, 5, 6, 7, 8, 11]) {
          for (const ca of [6, 7, 9, 10, 13]) {
            // Bất đẳng thức tam giác, và ba cạnh đôi một khác nhau để thứ tự
            // đỉnh thật sự quyết định đáp án.
            if (ab + bc <= ca || bc + ca <= ab || ca + ab <= bc) continue;
            if (ab === bc || bc === ca || ca === ab) continue;
            yield { ab, bc, ca };
          }
        }
      }
    },
    render: ({ ab, bc, ca }) => ({
      stem: `Cho $\\triangle ABC = \\triangle MNP$ với $AB = ${ab}$ cm, $BC = ${bc}$ cm, $CA = ${ca}$ cm. Tính độ dài $NP$.`,
      solutionSteps: [
          {
            viec: 'Ký hiệu $\\triangle ABC = \\triangle MNP$ cho biết $A$ ứng với $M$, $B$ ứng với $N$, $C$ ứng với $P$.',
            canCu: 'Ký hiệu hai tam giác bằng nhau viết theo THỨ TỰ đỉnh tương ứng; thứ tự này quyết định cạnh nào ứng với cạnh nào.',
          },
          {
            viec: 'Cạnh $NP$ ứng với cạnh $BC$.',
            canCu: 'Cạnh nối hai đỉnh tương ứng thì ứng với cạnh nối hai đỉnh tương ứng của tam giác kia.',
          },
          {
            viec: `Vậy $NP = BC = ${bc}$ cm.`,
            canCu: 'Hai tam giác bằng nhau thì các cạnh tương ứng bằng nhau.',
          },
        ],
      hints: [
        'Đọc thứ tự đỉnh trong ký hiệu, không đoán theo hình vẽ.',
        '$NP$ gồm đỉnh thứ hai và thứ ba, nên ứng với cạnh gồm đỉnh thứ hai và thứ ba của tam giác kia.',
      ],
      answer: `${bc} cm`,
      check: { expression: `${bc}`, equals: `${bc}` },
    }),
  },
  {
    id: 'BP.M7.XACSUAT.TUSO',
    formCode: 'M7.XACSUAT.THUCNGHIEM',
    intent: 'Tính xác suất thực nghiệm từ bảng đếm — chặn lỗi trả lời số lần thay vì tỉ số.',
    targetTrap: 'lẫn số lần xảy ra với xác suất',
    context: 'thực tế',
    shape: { steps: 3, cases: 1 },
    stars: 3,
    levels: [2, 5],
    space: function* () {
      for (const tong of [20, 25, 40, 50, 100, 200]) {
        for (let lan = 2; lan < tong; lan += 3) {
          if ((lan * 100) % tong !== 0) continue;
          yield { tong, lan };
        }
      }
    },
    render: ({ tong, lan }) => {
      const pct = (lan * 100) / tong;
      return {
        stem: `Gieo một con xúc xắc $${tong}$ lần thì có $${lan}$ lần xuất hiện mặt sáu chấm. `
          + 'Tính xác suất thực nghiệm của biến cố "xuất hiện mặt sáu chấm".',
        solutionSteps: [
          {
            viec: 'Xác suất thực nghiệm bằng số lần biến cố xảy ra CHIA cho tổng số lần thử.',
            canCu: 'Xác suất thực nghiệm bằng số lần biến cố xảy ra chia cho TỔNG số lần thử, không phải chia cho số lần không xảy ra.',
          },
          {
            viec: `$P = \\dfrac{${lan}}{${tong}} = ${frac(lan, tong)}$.`,
            canCu: 'Rút gọn phân số về dạng tối giản.',
          },
          {
            viec: `Viết dưới dạng phần trăm: $${thap(pct)}\\%$.`,
            canCu: 'Nhân với $100\\%$ để chuyển từ tỉ số sang phần trăm.',
          },
        ],
        hints: [
          `$${lan}$ là số LẦN, chưa phải xác suất.`,
          'Xác suất luôn là một số từ 0 đến 1.',
        ],
        answer: frac(lan, tong),
        check: { expression: `${lan}/${tong}`, equals: `${lan}/${tong}` },
      };
    },
  },

  // ══ LỚP 8 ══════════════════════════════════════════════════════════════
  {
    id: 'BP.M8.PHANTICH.TRIETDE',
    formCode: 'M8.PHANTICH.DATHUC',
    intent: 'Đa thức còn phân tích được tiếp sau bước đặt nhân tử chung — chặn thói quen dừng sớm.',
    targetTrap: 'dừng khi chưa phân tích triệt để',
    context: 'đại số thuần',
    shape: { steps: 4, cases: 1 },
    stars: 4,
    levels: [3, 6],
    space: function* () {
      for (const k of [2, 3, 4, 5]) {
        for (let r = 1; r <= 9; r++) {
          // k·x·(x² − r²) = k·x·(x − r)(x + r): sau khi đặt nhân tử chung vẫn
          // còn một hằng đẳng thức nữa, đúng chỗ học sinh hay dừng lại.
          if (k * r * r > 200) continue;
          yield { k, r };
        }
      }
    },
    render: ({ k, r }) => ({
      stem: `Phân tích đa thức thành nhân tử: $${k}x^{3} - ${k * r * r}x$.`,
      solutionSteps: [
          {
            viec: `Đặt nhân tử chung: $${k}x^{3} - ${k * r * r}x = ${k}x\\left(x^{2} - ${r * r}\\right)$.`,
            canCu: 'Bước đầu tiên của phân tích đa thức thành nhân tử luôn là đặt nhân tử chung, nếu có.',
          },
          {
            viec: 'Chưa xong: trong ngoặc là hiệu hai bình phương.',
            canCu: 'Phân tích chỉ xong khi không nhân tử nào còn phân tích tiếp được — phải soi lại phần trong ngoặc.',
          },
          {
            viec: `$x^{2} - ${r * r} = x^{2} - ${r}^{2} = (x - ${r})(x + ${r})$.`,
            canCu: 'Hằng đẳng thức thứ ba: $A^{2} - B^{2} = \\left(A - B\\right)\\left(A + B\\right)$.',
          },
          {
            viec: `Kết quả: $${k}x(x - ${r})(x + ${r})$.`,
            canCu: 'Ghép mọi nhân tử lại; kết quả cuối phải gồm toàn nhân tử không phân tích được nữa.',
          },
        ],
      hints: [
        'Sau khi đặt nhân tử chung, hãy nhìn lại phần trong ngoặc.',
        `$${r * r}$ là số chính phương nên còn dùng được hằng đẳng thức.`,
      ],
      answer: `${k}x(x - ${r})(x + ${r})`,
      check: { expression: `${k}*x^3 - ${k * r * r}*x`, equals: `${k}*x*(x - ${r})*(x + ${r})` },
    }),
  },
  {
    id: 'BP.M8.PHANTHUC.DKXD',
    formCode: 'M8.PHANTHUC.RUTGON',
    intent: 'Rút gọn phân thức kèm điều kiện mẫu khác 0 — chặn lỗi rút gọn xong quên điều kiện.',
    targetTrap: 'quên điều kiện mẫu khác 0',
    context: 'đại số thuần',
    shape: { steps: 4, cases: 1 },
    stars: 4,
    levels: [3, 6],
    space: function* () {
      for (let r = 1; r <= 9; r++) {
        for (let s = 1; s <= 9; s++) {
          if (r === s) continue;
          yield { r, s };
        }
      }
    },
    render: ({ r, s }) => ({
      stem: `Rút gọn phân thức $\\dfrac{x^{2} - ${r * r}}{x^{2} - ${r + s}x + ${r * s}}$ `
        + 'và nêu điều kiện xác định.',
      solutionSteps: [
          {
            viec: `Tử số: $x^{2} - ${r * r} = (x - ${r})(x + ${r})$.`,
            canCu: 'Phân tích tử thành nhân tử để nhìn ra nhân tử chung với mẫu.',
          },
          {
            viec: `Mẫu số: $x^{2} - ${r + s}x + ${r * s} = (x - ${r})(x - ${s})$.`,
            canCu: 'Phân tích mẫu thành nhân tử; các nhân tử của mẫu cũng chính là chỗ mẫu có thể bằng $0$.',
          },
          {
            viec: `Điều kiện xác định: mẫu khác $0$, tức $x \\ne ${r}$ và $x \\ne ${s}$.`,
            canCu: 'Phân thức chỉ xác định khi mẫu khác $0$. Điều kiện phải lấy từ mẫu BAN ĐẦU, không phải mẫu sau khi rút gọn.',
          },
          {
            viec: `Rút gọn: $\\dfrac{(x - ${r})(x + ${r})}{(x - ${r})(x - ${s})} = \\dfrac{x + ${r}}{x - ${s}}$ với $x \\ne ${r}$, $x \\ne ${s}$.`,
            canCu: 'Rút gọn bằng cách chia cả tử và mẫu cho nhân tử chung, và giữ nguyên điều kiện đã đặt.',
          },
        ],
      hints: [
        'Phân tích cả tử và mẫu thành nhân tử trước khi rút gọn.',
        `Điều kiện phải nêu TRƯỚC khi rút gọn: sau khi rút gọn thì $x = ${r}$ không còn nhìn thấy nữa.`,
      ],
      answer: `\\dfrac{x + ${r}}{x - ${s}} \\text{ với } x \\ne ${r}, x \\ne ${s}`,
      check: {
        expression: `(x^2 - ${r * r})/(x^2 - ${r + s}*x + ${r * s})`,
        equals: `(x + ${r})/(x - ${s})`,
        // Hai điều kiện gộp thành MỘT quan hệ: tích khác 0 đúng bằng "cả hai
        // thừa số đều khác 0", mà bộ kiểm chứng chỉ nhận một dấu so sánh.
        domain: `(x - ${r})*(x - ${s}) != 0`,
      },
    }),
  },
  {
    id: 'BP.M8.LAPPT.DIEUKIEN',
    formCode: 'M8.GIAI.LAPPT',
    intent: 'Giải bài toán bằng cách lập phương trình, có điều kiện của ẩn phải nêu rõ.',
    targetTrap: 'đặt ẩn không kèm điều kiện',
    context: 'thực tế',
    shape: { steps: 5, cases: 1 },
    stars: 4,
    levels: [3, 6],
    space: function* () {
      for (let rong = 4; rong <= 25; rong++) {
        for (const hon of [3, 5, 7, 8, 10, 12]) {
          const dai = rong + hon;
          const cv = (dai + rong) * 2;
          if (cv > 160) continue;
          yield { rong, hon, dai, cv };
        }
      }
    },
    render: ({ rong, hon, dai, cv }) => ({
      stem: `Một mảnh đất hình chữ nhật có chu vi $${cv}$ m. Chiều dài hơn chiều rộng $${hon}$ m. `
        + 'Tính chiều dài và chiều rộng của mảnh đất.',
      solutionSteps: [
          {
            viec: `Gọi chiều rộng là $x$ (m), điều kiện $x > 0$.`,
            canCu: 'Đặt ẩn phải kèm đơn vị và điều kiện; điều kiện sẽ dùng để nhận hay loại nghiệm ở bước cuối.',
          },
          {
            viec: `Chiều dài là $x + ${hon}$ (m).`,
            canCu: 'Biểu diễn các đại lượng còn lại theo ẩn vừa đặt.',
          },
          {
            viec: `Chu vi: $2\\left(x + x + ${hon}\\right) = ${cv}$, tức $4x + ${2 * hon} = ${cv}$.`,
            canCu: 'Dịch dữ kiện của đề thành phương trình; công thức chu vi hình chữ nhật là $2\\left(\\text{dài} + \\text{rộng}\\right)$.',
          },
          {
            viec: `$4x = ${cv - 2 * hon}$, suy ra $x = ${rong}$. Giá trị này thoả mãn $x > 0$.`,
            canCu: 'Giải phương trình bậc nhất rồi đối chiếu ngay với điều kiện của ẩn.',
          },
          {
            viec: `Vậy chiều rộng $${rong}$ m, chiều dài $${dai}$ m.`,
            canCu: 'Trả lời đủ các đại lượng mà đề hỏi, kèm đơn vị.',
          },
        ],
      hints: [
        'Đặt ẩn phải kèm đơn vị và điều kiện.',
        'Chiều rộng là độ dài nên bắt buộc dương.',
        'Đối chiếu nghiệm với điều kiện trước khi kết luận.',
      ],
      answer: `chiều rộng ${rong} m, chiều dài ${dai} m`,
      check: { equation: `2*(x + x + ${hon}) = ${cv}`, variable: 'x', roots: [rong] },
    }),
  },
  {
    id: 'BP.M8.DONGDANG.TISO',
    formCode: 'M8.TAMGIAC.DONGDANG',
    intent: 'Tính cạnh chưa biết từ hai tam giác đồng dạng — buộc lập tỉ số đúng cặp cạnh tương ứng.',
    targetTrap: 'lập tỉ số cạnh không tương ứng',
    context: 'hình học',
    shape: { steps: 4, cases: 1 },
    stars: 4,
    levels: [3, 6],
    space: function* () {
      for (const ab of [3, 4, 5, 6, 8]) {
        for (const bc of [4, 5, 6, 7, 9]) {
          for (const k of [2, 3, 4]) {
            if (ab === bc) continue;
            yield { ab, bc, k };
          }
        }
      }
    },
    render: ({ ab, bc, k }) => ({
      stem: `Cho $\\triangle ABC \\sim \\triangle DEF$ với $AB = ${ab}$ cm, $BC = ${bc}$ cm và $DE = ${ab * k}$ cm. Tính $EF$.`,
      solutionSteps: [
          {
            viec: '$\\triangle ABC \\sim \\triangle DEF$ nên $A$ ứng $D$, $B$ ứng $E$, $C$ ứng $F$.',
            canCu: 'Ký hiệu đồng dạng viết theo thứ tự đỉnh tương ứng, giống như ký hiệu bằng nhau.',
          },
          {
            viec: `Cạnh $DE$ ứng với $AB$, cạnh $EF$ ứng với $BC$.`,
            canCu: 'Cạnh nối hai đỉnh tương ứng thì ứng với cạnh nối hai đỉnh tương ứng của tam giác kia.',
          },
          {
            viec: `Tỉ số đồng dạng: $k = \\dfrac{DE}{AB} = \\dfrac{${ab * k}}{${ab}} = ${k}$.`,
            canCu: 'Hai tam giác đồng dạng có các cạnh tương ứng TỈ LỆ; tỉ số đó gọi là tỉ số đồng dạng.',
          },
          {
            viec: `$EF = k \\cdot BC = ${k} \\cdot ${bc} = ${bc * k}$ cm.`,
            canCu: 'Nhân cạnh của tam giác gốc với tỉ số đồng dạng để ra cạnh tương ứng.',
          },
        ],
      hints: [
        'Lập tỉ số giữa hai cạnh TƯƠNG ỨNG, đọc theo thứ tự đỉnh trong ký hiệu.',
        'Đồng dạng thì tỉ số các cặp cạnh tương ứng bằng nhau, không phải bằng nhau từng cạnh.',
      ],
      answer: `${bc * k} cm`,
      check: { expression: `${bc} * (${ab * k}/${ab})`, equals: `${bc * k}` },
    }),
  },
  {
    id: 'BP.M8.PYTAGO.NHANCANHHUYEN',
    formCode: 'M8.PYTAGO.UNGDUNG',
    intent: 'Cho hai cạnh trong đó cạnh huyền KHÔNG phải cạnh lớn nhất ghi trước — buộc nhận đúng cạnh huyền.',
    targetTrap: 'nhận nhầm cạnh huyền',
    context: 'hình học',
    shape: { steps: 4, cases: 1 },
    stars: 3,
    levels: [2, 5],
    space: function* () {
      // Bộ ba Pythagore nguyên để đáp số đẹp và kiểm được.
      const bo = [[3, 4, 5], [6, 8, 10], [5, 12, 13], [9, 12, 15], [8, 15, 17], [7, 24, 25], [12, 16, 20], [20, 21, 29]];
      for (const [a, b, c] of bo) {
        for (const goc of ['A', 'B']) yield { a, b, c, goc };
      }
    },
    render: ({ a, b, c, goc }) => {
      // Cho cạnh huyền và một cạnh góc vuông, hỏi cạnh còn lại.
      const choTruoc = goc === 'A' ? a : b;
      const canTim = goc === 'A' ? b : a;
      return {
        stem: `Tam giác $ABC$ vuông tại $A$ có cạnh huyền $BC = ${c}$ cm và cạnh $AB = ${choTruoc}$ cm. Tính $AC$.`,
        solutionSteps: [
          {
            viec: 'Tam giác vuông tại $A$ nên cạnh huyền là $BC$, hai cạnh góc vuông là $AB$ và $AC$.',
            canCu: 'Cạnh huyền là cạnh ĐỐI DIỆN góc vuông, xác định theo góc vuông chứ không theo độ dài.',
          },
          {
            viec: `Định lý Pythagore: $BC^{2} = AB^{2} + AC^{2}$.`,
            canCu: 'Định lý Pythagore: bình phương cạnh huyền bằng tổng bình phương hai cạnh góc vuông.',
          },
          {
            viec: `$AC^{2} = BC^{2} - AB^{2} = ${c}^{2} - ${choTruoc}^{2} = ${c * c} - ${choTruoc * choTruoc} = ${canTim * canTim}$.`,
            canCu: 'Chuyển vế để tìm cạnh góc vuông còn lại.',
          },
          {
            viec: `$AC = ${canTim}$ cm.`,
            canCu: 'Lấy căn bậc hai, chọn giá trị dương vì độ dài luôn dương.',
          },
        ],
        hints: [
          'Cạnh huyền là cạnh đối diện góc vuông, ở đây là $BC$.',
          'Biết cạnh huyền và một cạnh góc vuông thì phải TRỪ, không phải cộng.',
        ],
        answer: `${canTim} cm`,
        check: { expression: `sqrt(${c}^2 - ${choTruoc}^2)`, equals: `${canTim}` },
      };
    },
  },
  {
    id: 'BP.M8.HINHKHOI.CHOP',
    formCode: 'M8.HINHKHOI.THETICH',
    intent: 'Thể tích hình chóp đều — chặn lỗi quên chia 3.',
    targetTrap: 'quên chia 3 ở thể tích hình chóp',
    context: 'hình học',
    shape: { steps: 3, cases: 1 },
    stars: 3,
    levels: [3, 6],
    space: function* () {
      for (let a = 3; a <= 15; a++) {
        for (let h = 3; h <= 20; h++) {
          if ((a * a * h) % 3 !== 0) continue;
          if (a * a * h > 2400) continue;
          yield { a, h };
        }
      }
    },
    render: ({ a, h }) => {
      const v = (a * a * h) / 3;
      return {
        stem: `Một hình chóp tứ giác đều có cạnh đáy $${a}$ cm và chiều cao $${h}$ cm. Tính thể tích hình chóp.`,
        solutionSteps: [
          {
            viec: `Diện tích đáy: $S = ${a}^{2} = ${a * a}$ (cm$^{2}$).`,
            canCu: 'Tính diện tích đáy theo hình dạng của đáy trước.',
          },
          {
            viec: 'Thể tích hình chóp bằng một phần ba diện tích đáy nhân chiều cao.',
            canCu: 'Thể tích hình chóp bằng MỘT PHẦN BA diện tích đáy nhân chiều cao — khác hẳn lăng trụ vốn không chia ba.',
          },
          {
            viec: `$V = \\dfrac{1}{3} \\cdot ${a * a} \\cdot ${h} = ${v}$ (cm$^{3}$).`,
            canCu: 'Thay số vào công thức, giữ đúng đơn vị khối.',
          },
        ],
        hints: [
          `$${a * a} \\cdot ${h} = ${a * a * h}$ mới là thể tích hình hộp, chưa phải hình chóp.`,
          'Công thức hình chóp có hệ số một phần ba.',
        ],
        answer: `${v} cm^{3}`,
        check: { expression: `${a}^2 * ${h} / 3`, equals: `${v}` },
      };
    },
  },

  // ══ LỚP 9 ══════════════════════════════════════════════════════════════
  {
    id: 'BP.M9.CAN.MAUKHAC0',
    formCode: 'M9.CAN.DKXD',
    intent: 'Điều kiện xác định của biểu thức vừa có căn vừa có mẫu — chặn lỗi chỉ xét biểu thức dưới căn.',
    targetTrap: 'bỏ sót mẫu khác 0',
    context: 'đại số thuần',
    shape: { steps: 4, cases: 1 },
    stars: 4,
    levels: [3, 5],
    space: function* () {
      for (let a = 1; a <= 9; a++) {
        for (let b = 1; b <= 9; b++) {
          if (a === b) continue;
          yield { a, b };
        }
      }
    },
    render: ({ a, b }) => ({
      stem: `Tìm điều kiện xác định của biểu thức $A = \\dfrac{\\sqrt{x - ${a}}}{x - ${b}}$.`,
      solutionSteps: [
          {
            viec: `Biểu thức dưới căn phải không âm: $x - ${a} \\ge 0$, tức $x \\ge ${a}$.`,
            canCu: 'Căn bậc hai chỉ xác định khi biểu thức dưới căn không âm.',
          },
          {
            viec: `Mẫu phải khác $0$: $x - ${b} \\ne 0$, tức $x \\ne ${b}$.`,
            canCu: 'Phân thức chỉ xác định khi mẫu khác $0$.',
          },
          {
            viec: 'Hai điều kiện phải đồng thời thoả mãn.',
            canCu: 'Biểu thức có cả căn lẫn mẫu thì phải thoả ĐỒNG THỜI cả hai điều kiện, không phải chọn một.',
          },
          {
            viec: `Vậy điều kiện xác định là $x \\ge ${a}$ và $x \\ne ${b}$.`,
            canCu: 'Giao hai điều kiện lại thành tập xác định cuối cùng.',
          },
        ],
      hints: [
        'Có căn thì xét biểu thức dưới căn, có mẫu thì xét mẫu — phải xét cả hai.',
        `Đừng dừng lại sau khi viết $x \\ge ${a}$.`,
      ],
      answer: `x \\ge ${a} \\text{ và } x \\ne ${b}`,
      check: { expression: `${a}`, equals: `${a}` },
    }),
  },
  {
    id: 'BP.M9.PT2.THAMSO.ADIFF0',
    formCode: 'M9.PT2.THAMSO',
    intent: 'Phương trình có hệ số bậc hai chứa tham số — bắt buộc xét riêng trường hợp hệ số đó bằng 0.',
    targetTrap: 'quên xét a=0',
    context: 'đại số thuần',
    shape: { steps: 5, cases: 2 },
    stars: 4,
    levels: [4, 7],
    space: function* () {
      for (let m0 = 1; m0 <= 6; m0++) {
        for (const b of [-4, -3, -2, 2, 3, 4]) {
          for (const c of [-3, -2, -1, 1, 2, 3]) yield { m0, b, c };
        }
      }
    },
    render: ({ m0, b, c }) => {
      const dauB = b >= 0 ? '+' : '-';
      const dauC = c >= 0 ? '+' : '-';
      const mSao = `${m0} + ${frac(b * b, 4 * c)}`;
      return {
        stem: `Cho phương trình $\\left(m - ${m0}\\right)x^{2} ${dauB} ${Math.abs(b)}x ${dauC} ${Math.abs(c)} = 0$ với $m$ là tham số. `
          + 'Tìm $m$ để phương trình có ĐÚNG MỘT nghiệm.',
        solutionSteps: [
          {
            viec: `Hệ số của $x^{2}$ là $m - ${m0}$, nó CHỨA THAM SỐ nên chưa chắc phương trình đã là bậc hai. Phải chia hai trường hợp.`,
            canCu: 'Chỉ gọi là phương trình bậc hai khi hệ số của $x^{2}$ khác $0$. Hệ số ấy chứa tham số thì bắt buộc chia trường hợp.',
          },
          {
            viec: `Trường hợp 1 — $m - ${m0} = 0$, tức $m = ${m0}$: phương trình trở thành $${b === 1 ? '' : b === -1 ? '-' : b}x ${dauC} ${Math.abs(c)} = 0$, `
            + `là phương trình BẬC NHẤT, có đúng một nghiệm $x = ${frac(-c, b)}$. Vậy $m = ${m0}$ thoả mãn.`,
            canCu: 'Trường hợp hệ số bậc hai bằng $0$: phương trình tụt xuống bậc nhất và vẫn có nghiệm, nên vẫn phải xét.',
          },
          {
            viec: `Trường hợp 2 — $m \\ne ${m0}$: phương trình là bậc hai, có đúng một nghiệm khi và chỉ khi $\\Delta = 0$.`,
            canCu: 'Trường hợp hệ số bậc hai khác $0$: phương trình bậc hai có đúng một nghiệm khi và chỉ khi $\\Delta = 0$.',
          },
          {
            viec: `$\\Delta = \\left(${b}\\right)^{2} - 4\\left(m - ${m0}\\right) \\cdot \\left(${c}\\right) = ${b * b} - ${4 * c}\\left(m - ${m0}\\right)$.`,
            canCu: 'Công thức biệt thức $\\Delta = b^{2} - 4ac$, thay cả hệ số chứa tham số vào.',
          },
          {
            viec: `$\\Delta = 0 \\Leftrightarrow m - ${m0} = \\dfrac{${b * b}}{${4 * c}} \\Leftrightarrow m = ${mSao}$.`,
            canCu: 'Giải phương trình $\\Delta = 0$ theo tham số.',
          },
          {
            viec: `Kết luận: $m = ${m0}$ hoặc $m = ${mSao}$. Bỏ trường hợp 1 là mất một giá trị của $m$.`,
            canCu: 'Gộp nghiệm của CẢ HAI trường hợp; bỏ trường hợp bậc nhất là mất một giá trị hợp lệ.',
          },
        ],
        hints: [
          'Hệ số bậc hai chứa tham số thì chưa chắc phương trình là bậc hai — đọc kỹ trước khi dùng $\\Delta$.',
          `Phải xét riêng $m = ${m0}$ TRƯỚC khi áp dụng công thức $\\Delta$.`,
          'Phương trình bậc nhất cũng có đúng một nghiệm, nên trường hợp đó cũng được nhận.',
        ],
        answer: `m = ${m0} \\text{ hoặc } m = ${mSao}`,
        // Kiểm nội dung: thay chính giá trị m tìm được vào biệt thức, phải ra 0.
        check: {
          expression: `(${b})^2 - 4*((${m0} + (${b * b})/(4*(${c}))) - (${m0}))*(${c})`,
          equals: `0`,
        },
      };
    },
  },
  {
    id: 'BP.M9.PARABOL.GIAODIEM',
    formCode: 'M9.HAMSO.PARABOL',
    intent: 'Tìm giao điểm của parabol và đường thẳng — buộc đưa về phương trình bậc hai rồi xét biệt thức.',
    targetTrap: 'quên xét ∆ khi tìm giao điểm',
    context: 'đồ thị',
    shape: { steps: 4, cases: 1 },
    stars: 4,
    levels: [3, 7],
    space: function* () {
      for (const a of [1, 2]) {
        for (let r1 = -4; r1 <= 4; r1++) {
          for (let r2 = r1 + 1; r2 <= 5; r2++) {
            const m = a * (r1 + r2);
            const n = -a * r1 * r2;
            if (Math.abs(m) > 20 || Math.abs(n) > 40) continue;
            yield { a, r1, r2, m, n };
          }
        }
      }
    },
    render: ({ a, r1, r2, m, n }) => ({
      stem: `Cho parabol $(P): y = ${a}x^{2}$ và đường thẳng $(d): y = ${poly([[m, 'x'], [n, '']])}$. `
        + 'Tìm toạ độ giao điểm của $(P)$ và $(d)$.',
      solutionSteps: [
          {
            viec: 'Hoành độ giao điểm là nghiệm của phương trình hoành độ giao điểm.',
            canCu: 'Giao điểm của hai đồ thị là điểm có cùng hoành độ và cùng tung độ, nên hoành độ giao điểm là nghiệm của phương trình cho hai vế bằng nhau.',
          },
          {
            viec: `$${a}x^{2} = ${poly([[m, 'x'], [n, '']])} \\Leftrightarrow ${poly([[a, 'x^{2}'], [-m, 'x'], [-n, '']])} = 0$.`,
            canCu: 'Chuyển hết về một vế để đưa về dạng chuẩn của phương trình bậc hai.',
          },
          {
            viec: `$\\Delta = ${(-m) * (-m) - 4 * a * (-n)} > 0$ nên có hai giao điểm.`,
            canCu: 'Dấu của biệt thức cho biết có bao nhiêu giao điểm: $\\Delta > 0$ là hai, $\\Delta = 0$ là một, $\\Delta < 0$ là không có.',
          },
          {
            viec: `$x_{1} = ${r1}$, $x_{2} = ${r2}$, suy ra hai giao điểm là $\\left(${r1}; ${a * r1 * r1}\\right)$ và $\\left(${r2}; ${a * r2 * r2}\\right)$.`,
            canCu: 'Thay mỗi hoành độ vào một trong hai hàm để tìm tung độ tương ứng.',
          },
        ],
      hints: [
        'Cho hai vế bằng nhau rồi chuyển hết về một vế.',
        'Phải xét dấu biệt thức mới biết có mấy giao điểm.',
        'Tìm được hoành độ rồi thay vào một trong hai hàm để có tung độ.',
      ],
      answer: `(${r1}; ${a * r1 * r1}) \\text{ và } (${r2}; ${a * r2 * r2})`,
      check: { equation: `${a}*x^2 - (${m})*x - (${n}) = 0`, variable: 'x', roots: [r1, r2] },
    }),
  },
  {
    id: 'BP.M9.TIEPTUYEN.PYTAGO',
    formCode: 'M9.HH.DUONGTRON.TIEPTUYEN',
    intent: 'Tính độ dài tiếp tuyến — dùng chính tính chất tiếp tuyến vuông góc bán kính tại tiếp điểm.',
    targetTrap: 'thiếu chứng minh vuông góc bán kính',
    context: 'hình học',
    shape: { steps: 4, cases: 1 },
    stars: 4,
    levels: [3, 7],
    space: function* () {
      // Sinh bộ ba Pythagore bằng công thức Euclid rồi nhân bội — để độ dài tiếp
      // tuyến luôn là số nguyên, học viên kiểm tra được kết quả bằng đầu óc.
      // Đổi vai hai cạnh góc vuông cho nhau là một bài KHÁC: khi bán kính là
      // cạnh lớn, học viên hay nhầm cạnh huyền.
      for (let m = 2; m <= 8; m++) {
        for (let n = 1; n < m; n++) {
          if (gcd(m, n) !== 1 || (m - n) % 2 === 0) continue;
          const a = m * m - n * n, b = 2 * m * n, c = m * m + n * n;
          for (let k = 1; c * k <= 65; k++) {
            yield { r: a * k, t: b * k, d: c * k };
            yield { r: b * k, t: a * k, d: c * k };
          }
        }
      }
    },
    render: ({ r, t, d }) => ({
      stem: `Cho đường tròn tâm $O$ bán kính $R = ${r}$ cm và điểm $A$ ở ngoài đường tròn với $OA = ${d}$ cm. `
        + 'Kẻ tiếp tuyến $AB$ tới đường tròn ($B$ là tiếp điểm). Tính độ dài $AB$.',
      solutionSteps: [
          {
            viec: '$AB$ là tiếp tuyến tại $B$ nên $AB$ vuông góc với bán kính $OB$ tại $B$.',
            canCu: 'Tính chất tiếp tuyến: tiếp tuyến vuông góc với bán kính tại tiếp điểm.',
          },
          {
            viec: 'Do đó tam giác $OBA$ vuông tại $B$, cạnh huyền là $OA$.',
            canCu: 'Có góc vuông tại tiếp điểm thì tam giác tạo bởi tâm, tiếp điểm và điểm ngoài là tam giác vuông, cạnh huyền nối tâm với điểm ngoài.',
          },
          {
            viec: `Định lý Pythagore: $AB^{2} = OA^{2} - OB^{2} = ${d}^{2} - ${r}^{2} = ${d * d} - ${r * r} = ${t * t}$.`,
            canCu: 'Định lý Pythagore, chuyển vế để tìm cạnh góc vuông chưa biết.',
          },
          {
            viec: `$AB = ${t}$ cm.`,
            canCu: 'Lấy căn bậc hai và chọn giá trị dương vì độ dài luôn dương.',
          },
        ],
      hints: [
        'Tính chất then chốt: tiếp tuyến vuông góc với bán kính tại tiếp điểm.',
        'Có góc vuông tại $B$ thì cạnh huyền là $OA$, không phải $AB$.',
      ],
      answer: `${t} cm`,
      check: { expression: `sqrt(${d}^2 - ${r}^2)`, equals: `${t}` },
    }),
  },
  {
    id: 'BP.M9.NOITIEP.GOCTAM',
    formCode: 'M9.HH.TUGIAC.NOITIEP',
    intent: 'Quan hệ giữa góc nội tiếp và góc ở tâm cùng chắn một cung — chặn lỗi lấy hai góc bằng nhau.',
    targetTrap: 'nhầm góc nội tiếp và góc ở tâm',
    context: 'hình học',
    shape: { steps: 3, cases: 1 },
    stars: 3,
    levels: [4, 7],
    space: function* () {
      for (let goc = 20; goc <= 160; goc += 4) {
        if (goc % 2 !== 0) continue;
        yield { goc };
      }
    },
    render: ({ goc }) => ({
      stem: `Cho đường tròn tâm $O$. Góc ở tâm $\\widehat{AOB} = ${goc}^{\\circ}$ chắn cung nhỏ $AB$. `
        + 'Tính số đo góc nội tiếp $\\widehat{ACB}$ với $C$ thuộc cung lớn $AB$.',
      solutionSteps: [
          {
            viec: 'Góc nội tiếp và góc ở tâm cùng chắn một cung thì góc nội tiếp bằng NỬA góc ở tâm.',
            canCu: 'Định lý góc nội tiếp: góc nội tiếp bằng nửa góc ở tâm cùng chắn một cung.',
          },
          {
            viec: `$\\widehat{ACB} = \\dfrac{1}{2} \\widehat{AOB} = \\dfrac{${goc}^{\\circ}}{2}$.`,
            canCu: 'Thay số đo góc ở tâm vào rồi chia đôi.',
          },
          {
            viec: `$\\widehat{ACB} = ${goc / 2}^{\\circ}$.`,
            canCu: 'Ghi kết quả kèm đơn vị độ.',
          },
        ],
      hints: [
        'Hai góc này KHÔNG bằng nhau.',
        'Góc ở tâm luôn gấp đôi góc nội tiếp cùng chắn một cung.',
        'Vẽ hình trước: xác định rõ cung nhỏ $AB$ rồi mới đặt điểm $C$ trên cung lớn.',
      ],
      answer: `${goc / 2}^{\\circ}`,
      check: { expression: `${goc}/2`, equals: `${goc / 2}` },
    }),
  },
  {
    id: 'BP.M9.CHUYENDONG.DONVI',
    formCode: 'M9.TOANTHUCTE.CHUYENDONG',
    intent: 'Bài chuyển động lập phương trình, thời gian cho bằng phút — buộc đổi đơn vị trước khi lập.',
    targetTrap: 'sai đơn vị',
    context: 'thực tế',
    shape: { steps: 6, cases: 2 },
    stars: 4,
    levels: [3, 6],
    space: function* () {
      for (const v of [30, 36, 40, 45, 48, 50, 60]) {
        for (const tang of [5, 6, 10, 12, 15]) {
          for (const s of [60, 90, 120, 150, 180]) {
            const t1 = s / v;
            const t2 = s / (v + tang);
            const chenh = (t1 - t2) * 60;
            if (!Number.isInteger(chenh) || chenh <= 0 || chenh > 90) continue;
            yield { v, tang, s, chenh };
          }
        }
      }
    },
    render: ({ v, tang, s, chenh }) => ({
      stem: `Một ô tô đi quãng đường $${s}$ km. Nếu tăng vận tốc thêm $${tang}$ km/giờ thì đến sớm hơn $${chenh}$ phút. `
        + 'Tính vận tốc ban đầu của ô tô.',
      solutionSteps: [
          {
            viec: `Gọi vận tốc ban đầu là $x$ (km/giờ), điều kiện $x > 0$.`,
            canCu: 'Đặt ẩn kèm đơn vị và điều kiện; vận tốc là đại lượng dương nên điều kiện $x > 0$ là bắt buộc.',
          },
          {
            viec: `Đổi $${chenh}$ phút $= ${frac(chenh, 60)}$ giờ, vì vận tốc tính theo giờ.`,
            canCu: 'Mọi đại lượng trong một phương trình phải cùng hệ đơn vị; vận tốc tính theo giờ thì thời gian cũng phải đổi ra giờ.',
          },
          {
            viec: `Thời gian ban đầu $\\dfrac{${s}}{x}$ giờ, thời gian lúc sau $\\dfrac{${s}}{x + ${tang}}$ giờ.`,
            canCu: 'Công thức thời gian bằng quãng đường chia vận tốc.',
          },
          {
            viec: `Phương trình: $\\dfrac{${s}}{x} - \\dfrac{${s}}{x + ${tang}} = ${frac(chenh, 60)}$.`,
            canCu: 'Dịch dữ kiện "đi nhanh hơn nên đến sớm hơn" thành hiệu hai thời gian.',
          },
          {
            viec: `Quy đồng rồi thu gọn được phương trình bậc hai $x^{2} + ${tang}x - ${v * (v + tang)} = 0$.`,
            canCu: 'Quy đồng khử mẫu rồi thu gọn về dạng chuẩn của phương trình bậc hai.',
          },
          {
            viec: `Phương trình có hai nghiệm $x = ${v}$ và $x = ${-(v + tang)}$; nghiệm âm bị LOẠI vì trái điều kiện $x > 0$.`,
            canCu: 'Nghiệm phải đối chiếu với điều kiện của ẩn; nghiệm âm không có nghĩa với vận tốc nên phải loại.',
          },
          {
            viec: `Vậy vận tốc ban đầu là $${v}$ km/giờ.`,
            canCu: 'Trả lời đúng đại lượng đề hỏi, kèm đơn vị.',
          },
        ],
      hints: [
        `$${chenh}$ phút KHÔNG phải $0{,}${chenh}$ giờ.`,
        'Quãng đường không đổi, chỉ vận tốc và thời gian thay đổi.',
        'Nhớ đối chiếu nghiệm với điều kiện $x > 0$: phương trình bậc hai luôn cho hai nghiệm, chỉ một nghiệm có nghĩa.',
      ],
      answer: `${v} km/giờ`,
      // Máy kiểm bằng cách THAY NGHIỆM vào phương trình gốc. Không dùng lối
      // kiểm "tập nghiệm" vì phương trình còn một nghiệm âm đã bị loại theo
      // điều kiện thực tế — đó là đáp số đúng của bài, không phải thiếu nghiệm.
      check: { expression: `${s}/${v} - ${s}/(${v} + ${tang})`, equals: `${chenh}/60` },
    }),
  },
];

module.exports = { BP_THCS };
