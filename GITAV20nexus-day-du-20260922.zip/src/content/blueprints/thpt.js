'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BẢN THIẾT KẾ BÀI — TRUNG HỌC PHỔ THÔNG (lớp 10 đến lớp 12)
 * ═══════════════════════════════════════════════════════════════════════════
 *  Ở cấp này đề bài thường dài và nhiều bước, nên chỗ sai không còn là sai
 *  phép tính mà là sai MỘT ĐIỀU KIỆN bị bỏ quên: quên xét dấu, quên đổi cận,
 *  quên điều kiện cơ số, quên đầu mút của đoạn. Mỗi bản dưới đây nhằm đúng
 *  vào một điều kiện như thế.
 *
 *  CÁCH MÁY TỰ KIỂM Ở CẤP NÀY
 *  Bộ kiểm chứng chỉ biết TÍNH GIÁ TRỊ của biểu thức, nó không biết đạo hàm
 *  hay lấy nguyên hàm. Vì vậy mỗi bài được gắn một phép kiểm ĐỘC LẬP với
 *  đường lối giải trong lời giải:
 *
 *    · Đạo hàm  → kiểm bằng ĐỒNG NHẤT THỨC SAI PHÂN chính xác. Với f bậc hai,
 *                 f(x + h) − f(x) = h·f'(x) + h²·(hệ số bậc hai) là đẳng thức
 *                 ĐÚNG TUYỆT ĐỐI với mọi x, h — không phải phép tính xấp xỉ.
 *                 Máy thử đẳng thức đó ở hàng chục điểm ngẫu nhiên.
 *    · Nguyên hàm, tích phân → kiểm bằng CÔNG THỨC SIMPSON. Simpson chính xác
 *                 tuyệt đối với đa thức bậc ≤ 3, nên khi hàm dưới dấu tích phân
 *                 là đa thức bậc ≤ 3 thì đây là phép kiểm đúng, không xấp xỉ.
 *                 Hàm siêu việt thì dùng Simpson ghép nhiều đoạn, sai số nằm
 *                 dưới ngưỡng so khớp của bộ kiểm chứng.
 *    · Hình không gian, toạ độ → quy về độ dài và khoảng cách tính được.
 *
 *  Những gì máy KHÔNG kiểm được (lập luận chứng minh, bảng biến thiên) thì
 *  bài không hỏi, chứ không giả vờ đã kiểm.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { frac, thap, gcd } = require('./chung');
const { simpson, gauss, tiSo, chinhPhuong, capPytago } = require('./kiem-so');

const BP_THPT = [

  // ══ LỚP 10 ═════════════════════════════════════════════════════════════
  {
    id: 'BP.M10.MENHDE.PHUDINH',
    formCode: 'M10.MENHDE.TAPHOP',
    intent: 'Phủ định mệnh đề có lượng từ — phải đổi cả lượng từ lẫn dấu so sánh, rồi xét tính đúng sai bằng giá trị nhỏ nhất.',
    targetTrap: 'nhầm phủ định của mệnh đề chứa lượng từ',
    context: 'logic toán',
    shape: { steps: 4, cases: 2 },
    stars: 3,
    levels: [1, 3],
    space: function* () {
      for (let a = -4; a <= 4; a++) {
        for (let c = -6; c <= 12; c += 2) {
          if (c === a * a) continue;          // bỏ trường hợp biên, để kết luận dứt khoát
          yield { a, c };
        }
      }
    },
    render: ({ a, c }) => {
      const nho = c - a * a;                   // giá trị nhỏ nhất của x² − 2ax + c
      const dung = nho > 0;
      const veTrai = `x^{2} ${a >= 0 ? '-' : '+'} ${Math.abs(2 * a)}x ${c >= 0 ? '+' : '-'} ${Math.abs(c)}`;
      return {
        stem: `Cho mệnh đề $P$: "$\\forall x \\in \\mathbb{R},\\ ${veTrai} > 0$". `
          + 'Viết mệnh đề phủ định của $P$ và cho biết $P$ đúng hay sai.',
        solutionSteps: [
          {
            viec: 'Phủ định của $\\forall$ là $\\exists$, đồng thời dấu $>$ đổi thành $\\le$.',
            canCu: 'Phủ định một mệnh đề có lượng từ phải đổi ĐỒNG THỜI hai thứ: lượng từ và dấu so sánh. Đổi một thứ là sai.',
          },
          {
            viec: `$\\overline{P}$: "$\\exists x \\in \\mathbb{R},\\ ${veTrai} \\le 0$".`,
            canCu: 'Viết mệnh đề phủ định thành câu đầy đủ, giữ nguyên tập hợp mà biến chạy trên đó.',
          },
          {
            viec: `Đưa về dạng bình phương: $${veTrai} = \\left(x ${a >= 0 ? '-' : '+'} ${Math.abs(a)}\\right)^{2} ${nho >= 0 ? '+' : '-'} ${Math.abs(nho)}$.`,
            canCu: 'Đưa tam thức về dạng chính phương $\\left(x - p\\right)^{2} + q$ để đọc ngay giá trị nhỏ nhất.',
          },
          {
            viec: `Giá trị nhỏ nhất của vế trái là $${nho}$, đạt tại $x = ${a}$.`,
            canCu: 'Bình phương luôn không âm nên dạng chính phương đạt nhỏ nhất khi phần bình phương bằng $0$.',
          },
          {
            viec: dung
            ? `Vì $${nho} > 0$ nên vế trái luôn dương: $P$ ĐÚNG, $\\overline{P}$ sai.`
            : `Vì $${nho} \\le 0$ nên tại $x = ${a}$ vế trái bằng $${nho}$: $P$ SAI, $\\overline{P}$ đúng với phản ví dụ $x = ${a}$.`,
            canCu: 'So giá trị nhỏ nhất với $0$ để kết luận; khi mệnh đề sai thì phải chỉ ra phản ví dụ cụ thể, không chỉ nói là sai.',
          },
        ],
        hints: [
          'Phủ định phải đổi HAI thứ: lượng từ và dấu so sánh. Đổi một thứ là sai.',
          'Muốn biết $P$ đúng hay sai thì tìm giá trị nhỏ nhất của vế trái.',
        ],
        answer: dung ? 'P đúng' : `P sai (phản ví dụ x = ${a})`,
        check: { expression: `(${a})^2 - 2*(${a})*(${a}) + (${c})`, equals: `${nho}` },
      };
    },
  },
  {
    id: 'BP.M10.BAC2.DINH',
    formCode: 'M10.HAMSO.BAC2',
    intent: 'Tìm toạ độ đỉnh parabol và chiều bề lõm — hai việc khác nhau, học viên hay lấy đỉnh đúng mà kết luận bề lõm sai.',
    targetTrap: 'xác định sai toạ độ đỉnh',
    context: 'đồ thị',
    shape: { steps: 4, cases: 1 },
    stars: 3,
    levels: [3, 5],
    space: function* () {
      for (const a of [-3, -2, -1, 1, 2, 3]) {
        for (let p = -4; p <= 4; p++) {
          for (let c = -6; c <= 6; c += 3) {
            if (a === 1 && p === 0 && c === 0) continue;   // y = x² quá hiển nhiên
            yield { a, p, c };
          }
        }
      }
    },
    render: ({ a, p, c }) => {
      const b = -2 * a * p;                     // để hoành độ đỉnh đúng bằng p
      const yd = c - a * p * p;
      const veTrai = `${a === 1 ? '' : a === -1 ? '-' : a}x^{2}`
        + (b === 0 ? '' : ` ${b > 0 ? '+' : '-'} ${Math.abs(b) === 1 ? '' : Math.abs(b)}x`)
        + (c === 0 ? '' : ` ${c > 0 ? '+' : '-'} ${Math.abs(c)}`);
      return {
        stem: `Cho hàm số $y = ${veTrai}$. Tìm toạ độ đỉnh của parabol và cho biết bề lõm quay lên hay quay xuống.`,
        solutionSteps: [
          {
            viec: `Hệ số: $a = ${a}$, $b = ${b}$, $c = ${c}$.`,
            canCu: 'Đọc hệ số theo đúng dạng chuẩn $y = ax^{2} + bx + c$.',
          },
          {
            viec: `Hoành độ đỉnh: $x_{I} = \\dfrac{-b}{2a} = \\dfrac{${-b}}{${2 * a}} = ${p}$.`,
            canCu: 'Công thức hoành độ đỉnh $x_{I} = \\dfrac{-b}{2a}$ — có dấu trừ ở tử.',
          },
          {
            viec: `Tung độ đỉnh: thay $x = ${p}$ vào hàm số được $y_{I} = ${yd}$.`,
            canCu: 'Tung độ đỉnh lấy bằng cách thay hoành độ đỉnh vào chính hàm số, không có công thức riêng nào dễ nhớ hơn.',
          },
          {
            viec: `Đỉnh $I\\left(${p};\\ ${yd}\\right)$. Vì $a = ${a} ${a > 0 ? '>' : '<'} 0$ nên bề lõm quay ${a > 0 ? 'LÊN' : 'XUỐNG'}.`,
            canCu: 'Chiều bề lõm chỉ phụ thuộc DẤU của $a$, không phụ thuộc toạ độ đỉnh.',
          },
        ],
        hints: [
          'Công thức hoành độ đỉnh có dấu trừ: $x_{I} = -\\dfrac{b}{2a}$.',
          'Chiều bề lõm chỉ phụ thuộc dấu của $a$, không phụ thuộc đỉnh.',
        ],
        answer: `I(${p}; ${yd}), bề lõm quay ${a > 0 ? 'lên' : 'xuống'}`,
        check: { expression: `-(${b})/(2*(${a}))`, equals: `${p}` },
      };
    },
  },
  {
    id: 'BP.M10.VECTO.COSGOC',
    formCode: 'M10.VECTO.TICHVOHUONG',
    intent: 'Tính tích vô hướng rồi suy ra côsin góc giữa hai vectơ — mẫu số là tích hai ĐỘ DÀI, không phải tổng.',
    targetTrap: 'nhầm góc giữa hai vectơ',
    context: 'toạ độ phẳng',
    shape: { steps: 4, cases: 1 },
    stars: 4,
    levels: [3, 6],
    space: function* () {
      const bo = [[3, 4, 5], [4, 3, 5], [6, 8, 10], [8, 6, 10], [5, 12, 13], [12, 5, 13], [9, 12, 15], [8, 15, 17], [15, 8, 17], [20, 21, 29], [7, 24, 25]];
      for (const [u1, u2, nu] of bo) {
        for (const [v1, v2, nv] of bo) {
          for (const dau of [1, -1]) {
            const b1 = dau * v1;
            if (u1 === b1 && u2 === v2) continue;          // trùng vectơ thì góc bằng 0, không đáng một bài
            const tich = u1 * b1 + u2 * v2;
            if (Math.abs(tich) > 400) continue;
            yield { u1, u2, nu, v1: b1, v2, nv, tich };
          }
        }
      }
    },
    render: ({ u1, u2, nu, v1, v2, nv, tich }) => {
      const cos = tiSo(tich, nu * nv);
      return {
        stem: `Trong mặt phẳng toạ độ, cho $\\vec{u} = \\left(${u1};\\ ${u2}\\right)$ và $\\vec{v} = \\left(${v1};\\ ${v2}\\right)$. `
          + 'Tính $\\vec{u} \\cdot \\vec{v}$ và côsin của góc giữa hai vectơ.',
        solutionSteps: [
          {
            viec: `$\\vec{u} \\cdot \\vec{v} = ${u1} \\cdot ${v1} + ${u2} \\cdot ${v2} = ${tich}$.`,
            canCu: 'Tích vô hướng theo toạ độ: $\\vec{u} \\cdot \\vec{v} = u_{1}v_{1} + u_{2}v_{2}$.',
          },
          {
            viec: `$\\left|\\vec{u}\\right| = \\sqrt{${u1}^{2} + ${u2}^{2}} = ${nu}$; $\\left|\\vec{v}\\right| = \\sqrt{${v1}^{2} + ${v2}^{2}} = ${nv}$.`,
            canCu: 'Độ dài vectơ theo toạ độ: $\\left|\\vec{u}\\right| = \\sqrt{u_{1}^{2} + u_{2}^{2}}$.',
          },
          {
            viec: `$\\cos\\left(\\vec{u},\\ \\vec{v}\\right) = \\dfrac{\\vec{u} \\cdot \\vec{v}}{\\left|\\vec{u}\\right| \\cdot \\left|\\vec{v}\\right|} = \\dfrac{${tich}}{${nu * nv}}$.`,
            canCu: 'Công thức côsin góc giữa hai vectơ: mẫu số là TÍCH hai độ dài, không phải tổng.',
          },
          {
            viec: `Rút gọn: $\\cos\\left(\\vec{u},\\ \\vec{v}\\right) = ${cos.includes('/') ? `\\dfrac{${cos.split('/')[0]}}{${cos.split('/')[1]}}` : cos}$.`,
            canCu: 'Rút gọn phân số về dạng tối giản.',
          },
        ],
        hints: [
          'Mẫu số là TÍCH của hai độ dài, không phải tổng.',
          tich === 0 ? 'Tích vô hướng bằng 0 thì hai vectơ vuông góc.' : 'Dấu của côsin cùng dấu với tích vô hướng.',
        ],
        answer: `u·v = ${tich}, cos = ${cos}`,
        check: { expression: `(${u1}*(${v1}) + ${u2}*(${v2}))/(sqrt(${u1}^2+${u2}^2)*sqrt((${v1})^2+${v2}^2))`, equals: cos },
      };
    },
  },
  {
    id: 'BP.M10.HETHUC.COSIN',
    formCode: 'M10.LUONGGIAC.HETHUC',
    intent: 'Biết hai cạnh và GÓC XEN GIỮA thì phải dùng định lý côsin — đây chính là dữ kiện mà định lý sin không dùng được.',
    targetTrap: 'dùng định lý sin khi thiếu dữ kiện',
    context: 'hình học',
    shape: { steps: 4, cases: 1 },
    stars: 4,
    levels: [3, 6],
    space: function* () {
      // Chọn a, b sao cho cạnh thứ ba cũng nguyên — học viên tự kiểm được kết quả.
      for (let a = 3; a <= 26; a++) {
        for (let b = a + 1; b <= 30; b++) {
          const s60 = a * a + b * b - a * b;
          if (chinhPhuong(s60)) yield { a, b, goc: 60, c: Math.sqrt(s60) };
          const s120 = a * a + b * b + a * b;
          if (chinhPhuong(s120)) yield { a, b, goc: 120, c: Math.sqrt(s120) };
        }
      }
    },
    render: ({ a, b, goc, c }) => {
      const cosStr = goc === 60 ? 'cos(pi/3)' : 'cos(2*pi/3)';
      const cosTex = goc === 60 ? '\\dfrac{1}{2}' : '-\\dfrac{1}{2}';
      const bp = goc === 60 ? a * a + b * b - a * b : a * a + b * b + a * b;
      return {
        stem: `Tam giác $ABC$ có $BC = ${a}$ cm, $AC = ${b}$ cm và $\\widehat{C} = ${goc}^{\\circ}$. Tính cạnh $AB$.`,
        solutionSteps: [
          {
            viec: 'Dữ kiện là hai cạnh và góc XEN GIỮA hai cạnh đó, nên dùng định lý côsin.',
            canCu: 'Định lý côsin dùng khi biết hai cạnh và góc XEN GIỮA; định lý sin dùng khi biết cạnh và góc đối diện. Chọn nhầm định lý là bế tắc ngay.',
          },
          {
            viec: `$AB^{2} = BC^{2} + AC^{2} - 2 \\cdot BC \\cdot AC \\cdot \\cos\\widehat{C}$.`,
            canCu: 'Định lý côsin: $c^{2} = a^{2} + b^{2} - 2ab\\cos C$, trong đó $C$ là góc xen giữa hai cạnh $a$ và $b$.',
          },
          {
            viec: `$AB^{2} = ${a}^{2} + ${b}^{2} - 2 \\cdot ${a} \\cdot ${b} \\cdot \\left(${cosTex}\\right) = ${bp}$.`,
            canCu: 'Thay số, chú ý dấu khi côsin âm thì hạng tử cuối thành cộng.',
          },
          {
            viec: `$AB = ${c}$ cm.`,
            canCu: 'Lấy căn bậc hai, chọn giá trị dương vì độ dài luôn dương.',
          },
        ],
        hints: [
          'Định lý sin cần một cặp cạnh – góc ĐỐI DIỆN nhau; đề này không cho cặp đó.',
          goc === 120 ? 'Góc tù thì côsin âm, dấu trừ trước ngoặc thành dấu cộng.' : 'Góc $60^{\\circ}$ có côsin bằng $\\dfrac{1}{2}$.',
        ],
        answer: `${c} cm`,
        check: { expression: `sqrt(${a}^2 + ${b}^2 - 2*${a}*${b}*${cosStr})`, equals: `${c}` },
      };
    },
  },
  {
    id: 'BP.M10.THONGKE.TRUNGVI',
    formCode: 'M10.THONGKE.SOLIEU',
    intent: 'Mẫu số liệu có một giá trị bất thường — trung bình bị kéo lệch còn trung vị thì không, đó là lý do phải phân biệt hai số.',
    targetTrap: 'nhầm trung vị với trung bình',
    context: 'thực tế — số liệu',
    shape: { steps: 4, cases: 1 },
    stars: 2,
    levels: [1, 4],
    space: function* () {
      for (let x = 2; x <= 9; x++) {
        for (const lech of [12, 15, 18, 20, 24, 28, 30]) {
          for (const buoc of [1, 2]) yield { x, lech, buoc };
        }
      }
    },
    render: ({ x, lech, buoc }) => {
      const day = [0, 1, 2, 3, 4, 5, 6].map((i) => x + i * buoc);
      day.push(x + lech);
      const tv = (day[3] + day[4]) / 2;
      const tong = day.reduce((s, v) => s + v, 0);
      const tb = tong / 8;
      return {
        stem: `Số giờ tự học trong tuần của $8$ học viên lần lượt là: $${day.join(';\\ ')}$. `
          + 'Tính trung vị của mẫu số liệu và giải thích vì sao ở đây trung vị phản ánh mức phổ biến tốt hơn số trung bình.',
        solutionSteps: [
          {
            viec: `Mẫu đã sắp xếp tăng dần, cỡ mẫu $n = 8$ là số CHẴN.`,
            canCu: 'Muốn tìm trung vị thì mẫu phải được sắp xếp tăng dần trước, và phải biết cỡ mẫu chẵn hay lẻ.',
          },
          {
            viec: `Trung vị là trung bình cộng của hai giá trị chính giữa, tức số thứ tư và số thứ năm: $${day[3]}$ và $${day[4]}$.`,
            canCu: 'Cỡ mẫu chẵn thì trung vị là trung bình cộng của HAI giá trị chính giữa; cỡ mẫu lẻ thì lấy giá trị chính giữa.',
          },
          {
            viec: `$M_{e} = \\dfrac{${day[3]} + ${day[4]}}{2} = ${thap(tv)}$ giờ.`,
            canCu: 'Tính trung bình cộng của hai giá trị giữa.',
          },
          {
            viec: `Số trung bình là $\\dfrac{${tong}}{8} = ${thap(tb)}$ giờ — bị giá trị bất thường $${x + lech}$ kéo lên, nên cao hơn hẳn phần đông.`,
            canCu: 'Trung vị không bị giá trị bất thường kéo lệch, còn số trung bình thì có — đó là lý do dùng trung vị khi mẫu có giá trị đột biến.',
          },
        ],
        hints: [
          'Cỡ mẫu chẵn thì trung vị là trung bình của HAI giá trị giữa, không phải một giá trị.',
          'Trung vị chỉ phụ thuộc vị trí, nên một giá trị bất thường không kéo nó đi.',
        ],
        answer: `${thap(tv)} giờ`,
        check: { expression: `(${day[3]} + ${day[4]})/2`, equals: `${tv}` },
      };
    },
  },
  {
    id: 'BP.M10.TOHOP.KHONGTHUTU',
    formCode: 'M10.TOHOP.XACSUAT',
    intent: 'Phân biệt chọn có phân công với chọn không phân công — cùng một đề, đổi một chữ là đổi từ chỉnh hợp sang tổ hợp.',
    targetTrap: 'dùng chỉnh hợp khi thứ tự không quan trọng',
    context: 'thực tế — tổ chức',
    shape: { steps: 4, cases: 1 },
    stars: 3,
    levels: [3, 6],
    space: function* () {
      for (let n = 6; n <= 14; n++) {
        for (let k = 2; k <= 5; k++) {
          if (k >= n - 1) continue;
          yield { n, k };
        }
      }
    },
    render: ({ n, k }) => {
      let C = 1;
      for (let i = 0; i < k; i++) C = (C * (n - i)) / (i + 1);
      C = Math.round(C);
      let A = 1;
      for (let i = 0; i < k; i++) A *= n - i;
      return {
        stem: `Một tổ có $${n}$ học viên. Cần chọn $${k}$ bạn cùng trực nhật, các bạn được chọn làm việc như nhau, không ai giữ chức vụ riêng. `
          + 'Hỏi có bao nhiêu cách chọn?',
        solutionSteps: [
          {
            viec: 'Các bạn được chọn làm việc như nhau nên đổi chỗ hai bạn KHÔNG tạo ra cách chọn mới: đây là tổ hợp.',
            canCu: 'Chọn mà KHÔNG phân biệt thứ tự thì dùng tổ hợp; có phân công vai trò khác nhau thì dùng chỉnh hợp.',
          },
          {
            viec: `$C_{${n}}^{${k}} = \\dfrac{${n}!}{${k}! \\cdot ${n - k}!}$.`,
            canCu: 'Công thức tổ hợp: $C_{n}^{k} = \\dfrac{n!}{k!\\left(n-k\\right)!}$.',
          },
          {
            viec: `$C_{${n}}^{${k}} = ${C}$ cách.`,
            canCu: 'Rút gọn giai thừa rồi tính giá trị.',
          },
          {
            viec: `Đối chiếu: nếu đề phân công ${k} nhiệm vụ khác nhau thì đáp số là $A_{${n}}^{${k}} = ${A}$, gấp $${k}!$ lần.`,
            canCu: 'Chỉnh hợp gấp $k!$ lần tổ hợp, vì mỗi cách chọn còn được xếp theo $k!$ thứ tự — so hai đáp số để thấy rõ chỗ khác nhau.',
          },
        ],
        hints: [
          'Hỏi "có bao nhiêu cách chọn" mà không nêu chức vụ thì thứ tự không tính.',
          'Chỉnh hợp luôn lớn hơn tổ hợp đúng $k!$ lần — ra số lớn bất thường là dấu hiệu nhầm.',
        ],
        answer: `${C} cách`,
        check: { expression: `${n}!/(${k}!*${n - k}!)`, equals: `${C}` },
      };
    },
  },
  {
    id: 'BP.M10.DUONGTHANG.KHOANGCACH',
    formCode: 'M10.TOADO.DUONGTHANG',
    intent: 'Từ vectơ chỉ phương phải QUAY 90 độ mới ra vectơ pháp tuyến, rồi mới viết được phương trình tổng quát để tính khoảng cách.',
    targetTrap: 'nhầm vectơ pháp tuyến với vectơ chỉ phương',
    context: 'toạ độ phẳng',
    shape: { steps: 5, cases: 1 },
    stars: 4,
    levels: [3, 6],
    space: function* () {
      for (const [A, B, H] of capPytago(30)) {
        for (let xa = -3; xa <= 3; xa += 3) {
          for (let x0 = -4; x0 <= 4; x0 += 4) {
            if (x0 === xa) continue;
            yield { A, B, H, xa, ya: 1, x0, y0: -2 };
          }
        }
      }
    },
    render: ({ A, B, H, xa, ya, x0, y0 }) => {
      const C = -(A * xa + B * ya);
      const tu = Math.abs(A * x0 + B * y0 + C);
      const kc = tiSo(tu, H);
      return {
        stem: `Trong mặt phẳng toạ độ, đường thẳng $d$ đi qua $A\\left(${xa};\\ ${ya}\\right)$ và nhận `
          + `$\\vec{u} = \\left(${-B};\\ ${A}\\right)$ làm vectơ chỉ phương. `
          + `Viết phương trình tổng quát của $d$ rồi tính khoảng cách từ $M\\left(${x0};\\ ${y0}\\right)$ đến $d$.`,
        solutionSteps: [
          {
            viec: `Vectơ pháp tuyến vuông góc với vectơ chỉ phương: từ $\\vec{u} = \\left(${-B};\\ ${A}\\right)$ suy ra $\\vec{n} = \\left(${A};\\ ${B}\\right)$.`,
            canCu: 'Vectơ pháp tuyến vuông góc với vectơ chỉ phương, nên lấy bằng cách đổi chỗ hai toạ độ rồi đổi dấu một toạ độ.',
          },
          {
            viec: `Phương trình tổng quát qua $A$: $${A}\\left(x - ${xa}\\right) + ${B}\\left(y - ${ya}\\right) = 0$.`,
            canCu: 'Phương trình tổng quát của đường thẳng qua điểm $A\\left(x_{0}; y_{0}\\right)$ với pháp tuyến $\\left(a; b\\right)$ là $a\\left(x - x_{0}\\right) + b\\left(y - y_{0}\\right) = 0$.',
          },
          {
            viec: `Thu gọn: $${A}x + ${B}y ${C >= 0 ? '+' : '-'} ${Math.abs(C)} = 0$.`,
            canCu: 'Khai triển và gom hằng số để đưa về dạng $ax + by + c = 0$.',
          },
          {
            viec: `$d\\left(M, d\\right) = \\dfrac{\\left|${A} \\cdot ${x0} + ${B} \\cdot \\left(${y0}\\right) ${C >= 0 ? '+' : '-'} ${Math.abs(C)}\\right|}{\\sqrt{${A}^{2} + ${B}^{2}}} = \\dfrac{${tu}}{${H}}$.`,
            canCu: 'Công thức khoảng cách từ điểm đến đường thẳng: tử là giá trị tuyệt đối khi thay toạ độ điểm vào vế trái, mẫu là độ dài vectơ pháp tuyến.',
          },
          {
            viec: `Vậy khoảng cách bằng $${kc.includes('/') ? `\\dfrac{${kc.split('/')[0]}}{${kc.split('/')[1]}}` : kc}$.`,
            canCu: 'Rút gọn ra kết quả cuối.',
          },
        ],
        hints: [
          'Đổi từ chỉ phương sang pháp tuyến là ĐỔI CHỖ hai toạ độ rồi đổi dấu một toạ độ.',
          'Đem thẳng vectơ chỉ phương vào công thức khoảng cách là sai ngay từ dòng đầu.',
        ],
        answer: kc,
        check: { expression: `abs(${A}*(${x0}) + ${B}*(${y0}) + (${C}))/sqrt(${A}^2 + ${B}^2)`, equals: kc },
      };
    },
  },
  // ══ LỚP 11 ═════════════════════════════════════════════════════════════
  {
    id: 'BP.M11.LUONGGIAC.HONGHIEM',
    formCode: 'M11.LUONGGIAC.PHUONGTRINH',
    intent: 'Phương trình lượng giác cơ bản có VÔ SỐ nghiệm chia thành các họ — viết thiếu một họ là mất nửa đáp số.',
    targetTrap: 'thiếu họ nghiệm k2π',
    context: 'lượng giác',
    shape: { steps: 5, cases: 2 },
    stars: 4,
    levels: [3, 6],
    space: function* () {
      const GIA_TRI = {
        30: { tex: '\\dfrac{1}{2}', bt: '1/2' },
        45: { tex: '\\dfrac{\\sqrt{2}}{2}', bt: 'sqrt(2)/2' },
        60: { tex: '\\dfrac{\\sqrt{3}}{2}', bt: 'sqrt(3)/2' },
        90: { tex: '1', bt: '1' },
        120: { tex: '-\\dfrac{1}{2}', bt: '-1/2' },
        135: { tex: '-\\dfrac{\\sqrt{2}}{2}', bt: '-sqrt(2)/2' },
        150: { tex: '-\\dfrac{\\sqrt{3}}{2}', bt: '-sqrt(3)/2' },
      };
      for (const goc of [-60, -45, -30, 30, 45, 60, 90]) {
        const g = GIA_TRI[Math.abs(goc)];
        yield { ham: 'sin', goc, tex: goc < 0 ? `-${g.tex}` : g.tex, bt: goc < 0 ? `-(${g.bt})` : g.bt };
      }
      for (const goc of [30, 45, 60, 90, 120, 135, 150]) {
        // cos α = sin(90° − α), nên bảng giá trị ở trên dùng lại được bằng cách
        // tra theo GÓC PHỤ; riêng góc 90° thì côsin bằng 0, không có trong bảng.
        const gt = goc === 90 ? { tex: '0', bt: '0' } : GIA_TRI[goc < 90 ? 90 - goc : goc];
        yield { ham: 'cos', goc, tex: gt.tex, bt: gt.bt };
      }
    },
    render: ({ ham, goc, tex, bt }) => {
      const rad = (g) => {
        const m = { 30: '\\dfrac{\\pi}{6}', 45: '\\dfrac{\\pi}{4}', 60: '\\dfrac{\\pi}{3}', 90: '\\dfrac{\\pi}{2}', 120: '\\dfrac{2\\pi}{3}', 135: '\\dfrac{3\\pi}{4}', 150: '\\dfrac{5\\pi}{6}', 0: '0' };
        return g < 0 ? `-${m[-g]}` : m[g];
      };
      const radBt = (g) => {
        const m = { 30: 'pi/6', 45: 'pi/4', 60: 'pi/3', 90: 'pi/2', 120: '2*pi/3', 135: '3*pi/4', 150: '5*pi/6', 0: '0' };
        return g < 0 ? `-(${m[-g]})` : m[g];
      };
      const a = rad(goc);
      const hoSin = [`x = ${a} + k2\\pi`, `x = \\pi - \\left(${a}\\right) + k2\\pi`];
      const hoCos = [`x = ${a} + k2\\pi`, `x = -\\left(${a}\\right) + k2\\pi`];
      const ho = ham === 'sin' ? hoSin : hoCos;
      return {
        stem: `Giải phương trình $\\${ham} x = ${tex}$ trên tập số thực.`,
        solutionSteps: [
          {
            viec: `Tìm một góc đặc biệt có ${ham === 'sin' ? 'sin' : 'côsin'} bằng $${tex}$: đó là $${a}$.`,
            canCu: 'Muốn giải phương trình lượng giác cơ bản thì trước hết phải nhận ra giá trị đó là sin của góc đặc biệt nào.',
          },
          {
            viec: `Phương trình trở thành $\\${ham} x = \\${ham}\\left(${a}\\right)$.`,
            canCu: 'Đưa hai vế về cùng một hàm lượng giác thì mới so sánh góc được.',
          },
          {
            viec: ham === 'sin'
            ? 'Hai góc có cùng sin thì hoặc BẰNG NHAU, hoặc BÙ NHAU — nên có hai họ nghiệm.'
            : 'Hai góc có cùng côsin thì hoặc BẰNG NHAU, hoặc ĐỐI NHAU — nên có hai họ nghiệm.',
            canCu: 'Hai góc có cùng sin thì hoặc bằng nhau, hoặc bù nhau — vì vậy nghiệm chia thành HAI họ.',
          },
          {
            viec: `$${ho[0]}$ hoặc $${ho[1]}$, với $k \\in \\mathbb{Z}$.`,
            canCu: 'Hàm sin tuần hoàn chu kỳ $2\\pi$, nên mỗi họ nghiệm phải kèm $k2\\pi$ với $k$ nguyên.',
          },
          {
            viec: 'Thiếu một trong hai họ là mất một nửa số nghiệm; thiếu $k2\\pi$ là chỉ còn đúng hai nghiệm trong vô số nghiệm.',
            canCu: 'Thiếu một họ là mất một nửa số nghiệm; thiếu chu kỳ là biến vô số nghiệm thành hai nghiệm.',
          },
        ],
        hints: [
          `Đưa về dạng $\\${ham} x = \\${ham} \\alpha$ rồi mới viết nghiệm.`,
          ham === 'sin' ? 'Đừng quên họ nghiệm $\\pi - \\alpha$.' : 'Đừng quên họ nghiệm $-\\alpha$.',
          'Chu kỳ của cả hai họ là $2\\pi$, không phải $\\pi$.',
        ],
        answer: `${ho[0]} hoặc ${ho[1]} (k ∈ ℤ)`,
        check: { expression: `${ham}(${radBt(goc)})`, equals: bt },
      };
    },
  },
  {
    id: 'BP.M11.CAPSO.TONGCONG',
    formCode: 'M11.DAYSO.CAPSO',
    intent: 'Tính tổng n số hạng đầu của cấp số CỘNG, đặt cạnh cấp số nhân để thấy rõ công sai khác công bội ở chỗ nào.',
    targetTrap: 'nhầm công sai với công bội',
    context: 'đại số thuần',
    shape: { steps: 5, cases: 1 },
    stars: 4,
    levels: [3, 6],
    space: function* () {
      for (let u1 = -9; u1 <= 9; u1 += 3) {
        for (const d of [-5, -3, -2, 2, 3, 4, 5, 7]) {
          for (const n of [8, 10, 12, 15, 20, 25]) {
            const S = (n * (2 * u1 + (n - 1) * d)) / 2;
            if (!Number.isInteger(S) || Math.abs(S) > 3000) continue;
            yield { u1, d, n, S };
          }
        }
      }
    },
    render: ({ u1, d, n, S }) => {
      const un = u1 + (n - 1) * d;
      return {
        stem: `Cấp số cộng $\\left(u_{n}\\right)$ có $u_{1} = ${u1}$ và công sai $d = ${d}$. Tính tổng $S_{${n}}$ của $${n}$ số hạng đầu tiên.`,
        solutionSteps: [
          {
            viec: `Số hạng tổng quát: $u_{n} = u_{1} + \\left(n - 1\\right)d$.`,
            canCu: 'Công thức số hạng tổng quát của cấp số cộng: $u_{n} = u_{1} + \\left(n - 1\\right)d$, cộng công sai $n-1$ lần chứ không phải $n$ lần.',
          },
          {
            viec: `$u_{${n}} = ${u1} + ${n - 1} \\cdot \\left(${d}\\right) = ${un}$.`,
            canCu: 'Thay số vào công thức số hạng tổng quát.',
          },
          {
            viec: `Tổng $n$ số hạng đầu: $S_{n} = \\dfrac{n\\left(u_{1} + u_{n}\\right)}{2}$.`,
            canCu: 'Công thức tổng $n$ số hạng đầu của cấp số CỘNG: $S_{n} = \\dfrac{n\\left(u_{1} + u_{n}\\right)}{2}$.',
          },
          {
            viec: `$S_{${n}} = \\dfrac{${n} \\cdot \\left(${u1} + ${un}\\right)}{2} = ${S}$.`,
            canCu: 'Thay $u_{1}$ và $u_{n}$ vừa tính vào công thức tổng.',
          },
          {
            viec: `Lưu ý: $d = ${d}$ là công SAI, tức số CỘNG thêm mỗi bước. Nếu đây là cấp số NHÂN với công bội $q = ${d}$ thì phải dùng $S_{n} = u_{1}\\dfrac{q^{n} - 1}{q - 1}$ — một công thức hoàn toàn khác.`,
            canCu: 'Cấp số cộng dùng công SAI và phép cộng; cấp số nhân dùng công BỘI và phép nhân — hai bộ công thức khác hẳn, không thay thế cho nhau.',
          },
        ],
        hints: [
          'Công sai thì CỘNG, công bội thì NHÂN — hai công thức tổng không giống nhau chút nào.',
          `Tìm $u_{${n}}$ trước, rồi mới tính tổng.`,
          `Trong công thức $u_{n} = u_{1} + \\left(n - 1\\right)d$, hệ số là $n - 1$ chứ không phải $n$.`,
        ],
        answer: `${S}`,
        check: { expression: `${n}*(2*(${u1}) + (${n} - 1)*(${d}))/2`, equals: `${S}` },
      };
    },
  },
  {
    id: 'BP.M11.GIOIHAN.KHUVODINH',
    formCode: 'M11.GIOIHAN.DAYHAM',
    intent: 'Giới hạn dạng 0/0 phải khử bằng phân tích thành nhân tử rồi rút gọn — thay số trực tiếp là bế tắc chứ không phải vô nghiệm.',
    targetTrap: 'khử dạng vô định sai',
    context: 'giải tích',
    shape: { steps: 5, cases: 1 },
    stars: 4,
    levels: [3, 6],
    space: function* () {
      for (let a = -6; a <= 6; a++) {
        for (let b = -6; b <= 6; b++) {
          if (a === b) continue;          // trùng nghiệm thì không còn dạng 0/0 đơn
          yield { a, b };
        }
      }
    },
    render: ({ a, b }) => {
      const tong = a + b;
      const tich = a * b;
      const kq = a - b;
      const tu = `x^{2} ${tong >= 0 ? '-' : '+'} ${Math.abs(tong)}x ${tich >= 0 ? '+' : '-'} ${Math.abs(tich)}`;
      return {
        stem: `Tính giới hạn $\\lim\\limits_{x \\to ${a}} \\dfrac{${tu}}{x ${a >= 0 ? '-' : '+'} ${Math.abs(a)}}$.`,
        solutionSteps: [
          {
            viec: `Thay $x = ${a}$ vào thì tử và mẫu cùng bằng $0$ — đây là dạng vô định $\\dfrac{0}{0}$, CHƯA kết luận được.`,
            canCu: 'Thay trực tiếp mà tử và mẫu cùng bằng $0$ thì đó là dạng vô định, chưa được kết luận gì.',
          },
          {
            viec: `Phân tích tử số thành nhân tử: $${tu} = \\left(x ${a >= 0 ? '-' : '+'} ${Math.abs(a)}\\right)\\left(x ${b >= 0 ? '-' : '+'} ${Math.abs(b)}\\right)$.`,
            canCu: 'Tử và mẫu cùng bằng $0$ tại $x_{0}$ nghĩa là cả hai chia hết cho $x - x_{0}$, nên phân tích được thành nhân tử.',
          },
          {
            viec: `Với $x \\ne ${a}$, rút gọn được $\\dfrac{${tu}}{x ${a >= 0 ? '-' : '+'} ${Math.abs(a)}} = x ${b >= 0 ? '-' : '+'} ${Math.abs(b)}$.`,
            canCu: 'Rút gọn nhân tử chung, hợp lệ vì khi lấy giới hạn thì $x$ chỉ tiến gần $x_{0}$ chứ không bằng $x_{0}$.',
          },
          {
            viec: `Hàm sau khi rút gọn liên tục tại $x = ${a}$, nên thay trực tiếp: $${a} ${b >= 0 ? '-' : '+'} ${Math.abs(b)} = ${kq}$.`,
            canCu: 'Hàm sau khi rút gọn liên tục tại điểm đang xét nên thay trực tiếp được.',
          },
          {
            viec: `Vậy giới hạn bằng $${kq}$.`,
            canCu: 'Giá trị vừa tính chính là giới hạn cần tìm.',
          },
        ],
        hints: [
          'Dạng $\\dfrac{0}{0}$ nghĩa là tử và mẫu có chung một nhân tử — đi tìm nhân tử đó.',
          `Chỉ được rút gọn khi $x \\ne ${a}$; nhưng giới hạn xét $x$ TIẾN TỚI $${a}$ chứ không BẰNG $${a}$, nên rút gọn là hợp lệ.`,
          'Dạng $\\dfrac{0}{0}$ không có nghĩa là giới hạn bằng $0$, cũng không có nghĩa là không tồn tại.',
        ],
        answer: `${kq}`,
        check: {
          expression: `(x^2 - (${tong})*x + (${tich}))/(x - (${a}))`,
          equals: `x - (${b})`,
          domain: `x != ${a}`,
        },
      };
    },
  },
  {
    id: 'BP.M11.DAOHAM.HAMHOP',
    formCode: 'M11.DAOHAM.QUYTAC',
    intent: 'Đạo hàm hàm hợp phải nhân thêm đạo hàm của hàm bên trong — thiếu thừa số đó là lỗi kinh điển nhất của chương đạo hàm.',
    targetTrap: 'quên đạo hàm hàm hợp',
    context: 'giải tích',
    shape: { steps: 5, cases: 1 },
    stars: 4,
    levels: [3, 6],
    space: function* () {
      for (const a of [-5, -4, -3, -2, 2, 3, 4, 5, 6, 7]) {
        for (let b = -7; b <= 7; b++) {
          if (b === 0) continue;
          yield { a, b };
        }
      }
    },
    render: ({ a, b }) => {
      const trong = `${a === 1 ? '' : a}x ${b >= 0 ? '+' : '-'} ${Math.abs(b)}`;
      return {
        stem: `Cho hàm số $y = \\left(${trong}\\right)^{2}$. Tính $y'$.`,
        solutionSteps: [
          {
            viec: `Đây là hàm HỢP: bên ngoài là $u^{2}$, bên trong là $u = ${trong}$.`,
            canCu: 'Nhận dạng hàm hợp: có một biểu thức nằm bên trong một phép toán khác. Nhận nhầm thành hàm đơn là mất luôn thừa số đạo hàm trong.',
          },
          {
            viec: `Quy tắc đạo hàm hàm hợp: $\\left(u^{2}\\right)' = 2u \\cdot u'$.`,
            canCu: 'Quy tắc đạo hàm hàm hợp: đạo hàm hàm ngoài nhân với đạo hàm hàm trong.',
          },
          {
            viec: `$u' = ${a}$ (đạo hàm của $${trong}$).`,
            canCu: 'Tính riêng đạo hàm của hàm bên trong.',
          },
          {
            viec: `$y' = 2\\left(${trong}\\right) \\cdot ${a} = ${2 * a * a}x ${2 * a * b >= 0 ? '+' : '-'} ${Math.abs(2 * a * b)}$.`,
            canCu: 'Nhân hai phần lại theo đúng quy tắc.',
          },
          {
            viec: `Nếu quên nhân $u' = ${a}$ thì sẽ ra $2\\left(${trong}\\right)$ — sai đúng $${a}$ lần.`,
            canCu: 'Quên nhân đạo hàm hàm trong thì kết quả sai đúng một thừa số — lỗi này không lộ ra khi nhìn hình dạng đáp án.',
          },
        ],
        hints: [
          'Hỏi trước: hàm này là hàm của cái gì? Cái đó có phải là $x$ không?',
          `Bên trong là $${trong}$, đạo hàm của nó bằng $${a}$ — thừa số này KHÔNG được bỏ.`,
          'Kiểm tra lại bằng cách khai triển bình phương rồi đạo hàm từng hạng tử, hai cách phải cho cùng kết quả.',
        ],
        answer: `y' = ${2 * a * a}x ${2 * a * b >= 0 ? '+' : '-'} ${Math.abs(2 * a * b)}`,
        // Máy kiểm bằng ĐỒNG NHẤT THỨC SAI PHÂN chính xác, đúng với mọi x và h:
        //   f(x+h) − f(x) = h·f'(x) + a²h²  khi  f(x) = (ax + b)².
        // Đây là đẳng thức đại số, không phải phép tính xấp xỉ.
        check: {
          expression: `((${a}*(x + h) + (${b}))^2 - (${a}*x + (${b}))^2)/h - ${a * a}*h`,
          equals: `2*(${a})*(${a}*x + (${b}))`,
          domain: `h != 0`,
        },
      };
    },
  },
  {
    id: 'BP.M11.SONGSONG.TRUNGBINH',
    formCode: 'M11.KHONGGIAN.SONGSONG',
    intent: 'Đường nối hai trung điểm song song với một mặt phẳng — dịp để phân biệt SONG SONG với CHÉO NHAU, hai quan hệ chỉ có trong không gian.',
    targetTrap: 'kết luận song song khi hai đường chéo nhau',
    context: 'hình học không gian',
    shape: { steps: 5, cases: 1 },
    stars: 4,
    levels: [3, 6],
    space: function* () {
      for (const [p, q, ac] of capPytago(40)) {
        for (const r of [6, 8, 10, 12]) yield { p, q, r, ac };
      }
    },
    render: ({ p, q, r, ac }) => ({
      stem: `Cho hình hộp chữ nhật $ABCD.A'B'C'D'$ có $AB = ${p}$ cm, $AD = ${q}$ cm, $AA' = ${r}$ cm. `
        + `Gọi $M$, $N$ lần lượt là trung điểm của $AA'$ và $CC'$. `
        + `Chứng minh $MN$ song song với mặt phẳng $\\left(ABCD\\right)$ và tính độ dài $MN$.`,
      solutionSteps: [
          {
            viec: `$M$, $N$ là trung điểm của hai cạnh bên bằng nhau và song song, nên $AMNC$ là hình bình hành.`,
            canCu: 'Hai cạnh bằng nhau và song song thì tứ giác tạo thành là hình bình hành.',
          },
          {
            viec: `Suy ra $MN$ song song với $AC$.`,
            canCu: 'Hai cạnh đối của hình bình hành thì song song với nhau.',
          },
          {
            viec: `$AC$ nằm trong mặt phẳng $\\left(ABCD\\right)$ còn $MN$ không nằm trong mặt phẳng đó, nên $MN$ song song với $\\left(ABCD\\right)$.`,
            canCu: 'Đường thẳng không nằm trong một mặt phẳng mà song song với một đường của mặt phẳng đó thì song song với cả mặt phẳng.',
          },
          {
            viec: `Do $MN = AC$, tính $AC$ bằng định lý Pythagore trong tam giác $ABC$ vuông tại $B$: $AC = \\sqrt{${p}^{2} + ${q}^{2}} = ${ac}$ cm.`,
            canCu: 'Hai cạnh đối của hình bình hành thì bằng nhau, nên tính cạnh kia là ra cạnh này.',
          },
          {
            viec: `Vậy $MN = ${ac}$ cm.`,
            canCu: 'Ghi kết luận kèm đơn vị.',
          },
        ],
      hints: [
        'Muốn chứng minh đường song song với mặt phẳng, phải chỉ ra một đường NẰM TRONG mặt phẳng song song với nó.',
        `Cẩn thận: $MN$ và $BD$ KHÔNG song song — chúng CHÉO NHAU, vì không cùng nằm trong một mặt phẳng nào. Trong không gian, "không cắt nhau" chưa đủ để kết luận song song.`,
        `Độ dài $MN$ bằng $AC$, không phải bằng $AA'$.`,
      ],
      answer: `${ac} cm`,
      check: { expression: `sqrt(${p}^2 + ${q}^2)`, equals: `${ac}` },
    }),
  },
  {
    id: 'BP.M11.VUONGGOC.KHOANGCACH',
    formCode: 'M11.KHONGGIAN.VUONGGOC',
    intent: 'Khoảng cách từ đỉnh đáy tới mặt bên — phải dựng đúng chân đường vuông góc thì mới quy được về tam giác vuông phẳng.',
    targetTrap: 'dựng sai hình chiếu vuông góc',
    context: 'hình học không gian',
    shape: { steps: 6, cases: 1 },
    stars: 4,
    levels: [4, 7],
    space: function* () {
      for (const [a, h, c] of capPytago(50)) {
        if (a > 30 || h > 30) continue;
        yield { a, h, c };
      }
    },
    render: ({ a, h, c }) => {
      const kc = tiSo(a * h, c);
      const kcTex = kc.includes('/') ? `\\dfrac{${kc.split('/')[0]}}{${kc.split('/')[1]}}` : kc;
      return {
        stem: `Cho hình chóp $S.ABCD$ có đáy $ABCD$ là hình vuông cạnh $${a}$ cm, $SA$ vuông góc với mặt phẳng đáy và $SA = ${h}$ cm. `
          + `Tính khoảng cách từ điểm $A$ đến mặt phẳng $\\left(SBC\\right)$.`,
        solutionSteps: [
          {
            viec: `$BC \\perp AB$ (cạnh hình vuông) và $BC \\perp SA$ (vì $SA$ vuông góc với đáy).`,
            canCu: 'Một cạnh của hình vuông vuông góc với cạnh kề, và vuông góc với đường cao của hình chóp vì đường cao vuông góc với cả mặt đáy.',
          },
          {
            viec: `Hai đường $AB$ và $SA$ cắt nhau trong $\\left(SAB\\right)$, nên $BC \\perp \\left(SAB\\right)$.`,
            canCu: 'Đường thẳng vuông góc với hai đường CẮT NHAU của một mặt phẳng thì vuông góc với mặt phẳng đó.',
          },
          {
            viec: `Kẻ $AH \\perp SB$ tại $H$. Khi đó $AH \\perp BC$ (vì $BC \\perp \\left(SAB\\right)$), nên $AH \\perp \\left(SBC\\right)$.`,
            canCu: 'Đường thẳng vuông góc với một mặt phẳng thì vuông góc với mọi đường nằm trong mặt phẳng đó.',
          },
          {
            viec: `Vậy $AH$ chính là khoảng cách cần tìm; $H$ là chân đường vuông góc hạ từ $A$ xuống $SB$, KHÔNG phải trung điểm của $SB$.`,
            canCu: 'Khoảng cách từ điểm đến mặt phẳng là độ dài đoạn VUÔNG GÓC hạ xuống, chân đường vuông góc nói chung không phải trung điểm.',
          },
          {
            viec: `Tam giác $SAB$ vuông tại $A$: $\\dfrac{1}{AH^{2}} = \\dfrac{1}{SA^{2}} + \\dfrac{1}{AB^{2}}$, hay $AH = \\dfrac{SA \\cdot AB}{\\sqrt{SA^{2} + AB^{2}}}$.`,
            canCu: 'Hệ thức lượng trong tam giác vuông: đường cao ứng với cạnh huyền bằng tích hai cạnh góc vuông chia cạnh huyền.',
          },
          {
            viec: `$AH = \\dfrac{${h} \\cdot ${a}}{\\sqrt{${h}^{2} + ${a}^{2}}} = \\dfrac{${a * h}}{${c}} = ${kcTex}$ cm.`,
            canCu: 'Thay số và rút gọn.',
          },
        ],
        hints: [
          'Muốn tính khoảng cách tới một mặt phẳng, phải dựng được đường vuông góc với mặt phẳng đó — không được ước lượng.',
          `Chân đường vuông góc $H$ nằm trên $SB$ nhưng không chia đôi $SB$, trừ khi $SA = AB$.`,
          'Hệ thức lượng trong tam giác vuông cho đường cao ứng với cạnh huyền là công cụ đúng ở bước cuối.',
        ],
        answer: `${kc} cm`,
        check: { expression: `${a}*${h}/sqrt(${a}^2 + ${h}^2)`, equals: kc },
      };
    },
  },
  {
    id: 'BP.M11.XACSUAT.ITNHATMOT',
    formCode: 'M11.XACSUAT.BIENCO',
    intent: 'Bài "ít nhất một" giải bằng biến cố ĐỐI — cộng thẳng xác suất từng lần lấy là đếm trùng phần giao.',
    targetTrap: 'cộng xác suất hai biến cố không xung khắc',
    context: 'thực tế — xác suất',
    shape: { steps: 5, cases: 1 },
    stars: 4,
    levels: [3, 6],
    space: function* () {
      for (let n = 6; n <= 14; n++) {
        for (let r = 2; r <= n - 3; r++) yield { n, r };
      }
    },
    render: ({ n, r }) => {
      const x = n - r;                         // số bi không đỏ
      const tong = (n * (n - 1)) / 2;
      const khongDo = (x * (x - 1)) / 2;
      const p = tiSo(tong - khongDo, tong);
      const pTex = p.includes('/') ? `\\dfrac{${p.split('/')[0]}}{${p.split('/')[1]}}` : p;
      return {
        stem: `Một hộp có $${n}$ viên bi cùng kích thước, trong đó có $${r}$ viên màu đỏ. Lấy ngẫu nhiên đồng thời $2$ viên. `
          + 'Tính xác suất để lấy được ÍT NHẤT một viên đỏ.',
        solutionSteps: [
          {
            viec: `Số cách lấy $2$ viên từ $${n}$ viên: $C_{${n}}^{2} = ${tong}$ — đây là không gian mẫu.`,
            canCu: 'Không gian mẫu là số cách chọn không phân biệt thứ tự, nên dùng tổ hợp.',
          },
          {
            viec: `Gọi $A$ là biến cố "lấy được ít nhất một viên đỏ". Biến cố đối $\\overline{A}$ là "không lấy được viên đỏ nào".`,
            canCu: 'Biến cố "ít nhất một" có nhiều trường hợp con, còn biến cố ĐỐI của nó chỉ có một trường hợp — nên đi đường đối ngắn hơn hẳn.',
          },
          {
            viec: `Số cách lấy $2$ viên đều không đỏ: $C_{${x}}^{2} = ${khongDo}$.`,
            canCu: 'Đếm số cách của biến cố đối bằng tổ hợp trên phần còn lại.',
          },
          {
            viec: `$P\\left(\\overline{A}\\right) = \\dfrac{${khongDo}}{${tong}}$, nên $P\\left(A\\right) = 1 - \\dfrac{${khongDo}}{${tong}} = ${pTex}$.`,
            canCu: 'Công thức xác suất biến cố đối: $P\\left(A\\right) = 1 - P\\left(\\overline{A}\\right)$.',
          },
          {
            viec: `Cách sai thường gặp: lấy xác suất "viên thứ nhất đỏ" cộng với "viên thứ hai đỏ". Hai biến cố này CÙNG XẢY RA được (cả hai viên đều đỏ), nên cộng thẳng là đếm hai lần phần giao.`,
            canCu: 'Cộng thẳng xác suất các trường hợp là sai khi chúng có thể CÙNG xảy ra, vì phần giao bị đếm hai lần.',
          },
        ],
        hints: [
          'Gặp chữ "ít nhất một" thì nghĩ ngay tới biến cố đối.',
          'Công thức $P\\left(A \\cup B\\right) = P\\left(A\\right) + P\\left(B\\right)$ CHỈ đúng khi hai biến cố xung khắc.',
          'Lấy "đồng thời" nghĩa là không tính thứ tự, nên dùng tổ hợp chứ không dùng chỉnh hợp.',
        ],
        answer: p,
        check: { expression: `1 - (${x}*(${x} - 1)/2)/(${n}*(${n} - 1)/2)`, equals: p },
      };
    },
  },
  // ══ LỚP 12 ═════════════════════════════════════════════════════════════
  {
    id: 'BP.M12.KHAOSAT.TIEMCAN',
    formCode: 'M12.KHAOSAT.HAMSO',
    intent: 'Hàm phân thức bậc nhất trên bậc nhất luôn có ĐỦ HAI tiệm cận — bỏ sót một đường là vẽ sai hẳn dáng đồ thị.',
    targetTrap: 'thiếu tiệm cận',
    context: 'đồ thị',
    shape: { steps: 5, cases: 1 },
    stars: 4,
    levels: [3, 6],
    space: function* () {
      for (const c of [1, 2, 3]) {
        for (let k = -4; k <= 4; k++) {
          for (let m = -4; m <= 4; m++) {
            for (const b of [-5, -3, -1, 1, 3, 5]) {
              if (c * k * m === b) continue;        // ad − bc = 0 thì đồ thị suy biến thành đường thẳng
              yield { c, k, m, b };
            }
          }
        }
      }
    },
    render: ({ c, k, m, b }) => {
      const a = c * k;
      const d = c * m;
      const tu = `${a === 0 ? '' : a === 1 ? 'x' : a === -1 ? '-x' : `${a}x`}${a === 0 ? `${b}` : ` ${b >= 0 ? '+' : '-'} ${Math.abs(b)}`}`;
      const mau = `${c === 1 ? 'x' : `${c}x`} ${d >= 0 ? '+' : '-'} ${Math.abs(d)}`;
      return {
        stem: `Cho hàm số $y = \\dfrac{${tu}}{${mau}}$. Tìm hai đường tiệm cận của đồ thị và toạ độ giao điểm $I$ của chúng.`,
        solutionSteps: [
          {
            viec: `Mẫu bằng $0$ khi $${mau} = 0$, tức $x = ${-m}$. Tại đó tử khác $0$ nên đây là TIỆM CẬN ĐỨNG: $x = ${-m}$.`,
            canCu: 'Tiệm cận đứng nằm ở chỗ mẫu bằng $0$ mà tử khác $0$; nếu tử cũng bằng $0$ thì phải rút gọn trước.',
          },
          {
            viec: `Khi $x \\to \\pm\\infty$, tỉ số tiến về thương hai hệ số của $x$: $\\dfrac{${a}}{${c}} = ${k}$.`,
            canCu: 'Khi $x$ ra vô cùng, phân thức bậc nhất trên bậc nhất tiến về thương hai hệ số của $x$.',
          },
          {
            viec: `Vậy TIỆM CẬN NGANG là $y = ${k}$.`,
            canCu: 'Giới hạn đó chính là tiệm cận ngang.',
          },
          {
            viec: `Giao điểm hai tiệm cận: $I\\left(${-m};\\ ${k}\\right)$.`,
            canCu: 'Giao điểm hai tiệm cận là tâm đối xứng của đồ thị.',
          },
          {
            viec: `Hàm phân thức bậc nhất trên bậc nhất luôn có ĐỦ cả hai tiệm cận; chỉ tìm một đường là chưa xong bài.`,
            canCu: 'Phân thức bậc nhất trên bậc nhất luôn có ĐỦ cả hai tiệm cận; tìm một đường là mới làm nửa bài.',
          },
        ],
        hints: [
          'Tiệm cận đứng tìm từ nghiệm của MẪU; tiệm cận ngang tìm từ giới hạn khi $x$ ra vô cực.',
          `Tiệm cận ngang là $y = \\dfrac{a}{c}$, không phải $y = \\dfrac{b}{d}$.`,
          'Giao điểm hai tiệm cận chính là tâm đối xứng của đồ thị — kiểm tra lại dáng đồ thị qua điểm này.',
        ],
        answer: `TCĐ x = ${-m}, TCN y = ${k}, I(${-m}; ${k})`,
        check: { expression: `-(${d})/(${c}) + (${a})/(${c})`, equals: `${-m + k}` },
      };
    },
  },
  {
    id: 'BP.M12.CUCTRI.DIEUKIEN',
    formCode: 'M12.CUCTRI.THAMSO',
    intent: 'Hàm bậc ba có hai cực trị KHI VÀ CHỈ KHI đạo hàm có hai nghiệm phân biệt — không phải chỉ cần đạo hàm có nghiệm.',
    targetTrap: "quên điều kiện y' đổi dấu",
    context: 'giải tích có tham số',
    shape: { steps: 6, cases: 1 },
    stars: 4,
    levels: [5, 9],
    space: function* () {
      for (const p of [1, 2, 3]) {
        for (let a = -6; a <= 6; a++) {
          if (a === 0) continue;
          yield { p, a };
        }
      }
    },
    render: ({ p, a }) => {
      const nguong = tiSo(a * a, 3 * p);
      const nguongTex = nguong.includes('/') ? `\\dfrac{${nguong.split('/')[0]}}{${nguong.split('/')[1]}}` : nguong;
      return {
        stem: `Cho hàm số $y = ${p === 1 ? '' : p}x^{3} ${a >= 0 ? '+' : '-'} ${Math.abs(a)}x^{2} + mx$ với $m$ là tham số. `
          + 'Tìm tất cả giá trị của $m$ để hàm số có hai điểm cực trị.',
        solutionSteps: [
          {
            viec: `$y' = ${3 * p}x^{2} ${2 * a >= 0 ? '+' : '-'} ${Math.abs(2 * a)}x + m$.`,
            canCu: 'Điểm cực trị chỉ có thể nằm ở nơi đạo hàm bằng $0$, nên phải lấy đạo hàm trước.',
          },
          {
            viec: `Hàm bậc ba có hai điểm cực trị khi và chỉ khi $y'$ có HAI NGHIỆM PHÂN BIỆT, để $y'$ ĐỔI DẤU hai lần.`,
            canCu: 'Hàm bậc ba có hai cực trị khi và chỉ khi đạo hàm ĐỔI DẤU hai lần, tức đạo hàm có hai nghiệm phân biệt.',
          },
          {
            viec: `Điều kiện: $\\Delta' > 0$ với $\\Delta' = ${a}^{2} - ${3 * p}m$.`,
            canCu: 'Tam thức bậc hai có hai nghiệm phân biệt khi và chỉ khi biệt thức dương.',
          },
          {
            viec: `$${a * a} - ${3 * p}m > 0 \\Leftrightarrow m < ${nguongTex}$.`,
            canCu: 'Giải bất phương trình theo tham số.',
          },
          {
            viec: `Chú ý dấu BẤT ĐẲNG THỨC NGHIÊM NGẶT: nếu $\\Delta' = 0$ thì $y'$ có nghiệm kép, $y'$ không đổi dấu, hàm số KHÔNG có cực trị nào.`,
            canCu: 'Dấu bất đẳng thức phải NGHIÊM NGẶT: biệt thức bằng $0$ cho nghiệm kép, đạo hàm không đổi dấu, hàm số không có cực trị.',
          },
          {
            viec: `Kết luận: $m < ${nguongTex}$.`,
            canCu: 'Ghi kết luận dưới dạng khoảng giá trị của tham số.',
          },
        ],
        hints: [
          "Có nghiệm chưa đủ — đạo hàm phải ĐỔI DẤU tại nghiệm đó thì mới là điểm cực trị.",
          "Nghiệm kép của $y'$ cho điểm uốn có tiếp tuyến ngang, không phải cực trị.",
          `Hệ số của $x^{2}$ trong $y'$ là $${3 * p}$, đừng quên nhân $3$ với hệ số bậc ba.`,
        ],
        answer: `m < ${nguong}`,
        check: { condition: `${a * a} - ${3 * p}*m > 0`, variable: 'm' },
      };
    },
  },
  {
    id: 'BP.M12.GTLN.DAUMUT',
    formCode: 'M12.GTLN.GTNN',
    intent: 'Giá trị lớn nhất trên một đoạn có thể rơi vào ĐẦU MÚT chứ không rơi vào điểm cực trị — đây là chỗ bỏ sót kinh điển.',
    targetTrap: 'bỏ quên giá trị tại hai đầu mút',
    context: 'giải tích',
    shape: { steps: 6, cases: 1 },
    stars: 4,
    levels: [3, 6],
    space: function* () {
      for (let k = 1; k <= 4; k++) {
        for (let c = -6; c <= 6; c += 2) {
          for (let b = Math.ceil(k * Math.sqrt(3)) + 1; b <= k + 8; b++) {
            yield { k, c, b };
          }
        }
      }
    },
    render: ({ k, c, b }) => {
      const f0 = c;
      const fk = c - 2 * k * k * k;
      const fb = b * b * b - 3 * k * k * b + c;
      return {
        stem: `Tìm giá trị lớn nhất và giá trị nhỏ nhất của hàm số $y = x^{3} - ${3 * k * k}x ${c >= 0 ? '+' : '-'} ${Math.abs(c)}$ trên đoạn $\\left[0;\\ ${b}\\right]$.`,
        solutionSteps: [
          {
            viec: `$y' = 3x^{2} - ${3 * k * k} = 3\\left(x^{2} - ${k * k}\\right)$.`,
            canCu: 'Lấy đạo hàm để tìm các điểm mà hàm số có thể đạt cực trị.',
          },
          {
            viec: `$y' = 0 \\Leftrightarrow x = ${k}$ hoặc $x = ${-k}$; chỉ $x = ${k}$ thuộc đoạn $\\left[0;\\ ${b}\\right]$.`,
            canCu: 'Chỉ giữ lại các nghiệm NẰM TRONG đoạn đang xét; nghiệm ngoài đoạn không liên quan.',
          },
          {
            viec: `Tính giá trị tại điểm tới hạn VÀ tại HAI ĐẦU MÚT: $y\\left(0\\right) = ${f0}$, $y\\left(${k}\\right) = ${fk}$, $y\\left(${b}\\right) = ${fb}$.`,
            canCu: 'Trên một đoạn kín, giá trị lớn nhất và nhỏ nhất đạt tại điểm tới hạn HOẶC tại hai đầu mút — nên phải tính đủ cả ba loại điểm.',
          },
          {
            viec: `So sánh ba số $${f0}$, $${fk}$, $${fb}$.`,
            canCu: 'So sánh các giá trị vừa tính để chọn ra lớn nhất và nhỏ nhất.',
          },
          {
            viec: `Giá trị nhỏ nhất là $${fk}$, đạt tại $x = ${k}$.`,
            canCu: 'Ghi rõ giá trị nhỏ nhất và điểm đạt được.',
          },
          {
            viec: `Giá trị lớn nhất là $${fb}$, đạt tại ĐẦU MÚT $x = ${b}$ — không phải tại điểm cực trị.`,
            canCu: 'Giá trị lớn nhất có thể rơi vào đầu mút chứ không phải điểm cực trị — bỏ hai đầu mút là nguồn sai phổ biến nhất của dạng này.',
          },
        ],
        hints: [
          'Trên một ĐOẠN kín, luôn phải tính thêm giá trị tại hai đầu mút.',
          `Nghiệm $x = ${-k}$ của $y'$ nằm ngoài đoạn nên bị loại — nhưng phải nói rõ lý do loại.`,
          'Cực trị địa phương không đồng nghĩa với giá trị lớn nhất hay nhỏ nhất trên đoạn.',
        ],
        answer: `GTNN = ${fk} tại x = ${k}; GTLN = ${fb} tại x = ${b}`,
        check: { expression: `${b}^3 - ${3 * k * k}*${b} + (${c})`, equals: `${fb}` },
      };
    },
  },
  {
    id: 'BP.M12.LOGARIT.DIEUKIEN',
    formCode: 'M12.MU.LOGARIT',
    intent: 'Phương trình lôgarit phải đặt điều kiện TRƯỚC khi biến đổi, vì phép gộp hai lôgarit làm xuất hiện nghiệm ngoại lai.',
    targetTrap: 'quên điều kiện cơ số và đối số',
    context: 'đại số thuần',
    shape: { steps: 6, cases: 2 },
    stars: 4,
    levels: [3, 7],
    space: function* () {
      for (const a of [2, 3, 5, 10]) {
        for (let k = 1; k <= 3; k++) {
          const A = a ** k;
          if (A > 1000) continue;
          for (let p = 1; p <= A; p++) {
            if (A % p !== 0) continue;
            const d = p - A / p;
            if (d < 1) continue;
            yield { a, k, A, p, d, loai: -A / p };
          }
        }
      }
    },
    render: ({ a, k, A, p, d, loai }) => ({
      stem: `Giải phương trình $\\log_{${a}} x + \\log_{${a}}\\left(x - ${d}\\right) = ${k}$.`,
      solutionSteps: [
          {
            viec: `ĐIỀU KIỆN trước tiên: $x > 0$ và $x - ${d} > 0$, tức $x > ${d}$.`,
            canCu: 'Điều kiện xác định phải viết TRƯỚC mọi biến đổi, vì các bước gộp lôgarit về sau có thể làm mất dấu vết của nó.',
          },
          {
            viec: `Gộp hai lôgarit cùng cơ số: $\\log_{${a}}\\left[x\\left(x - ${d}\\right)\\right] = ${k}$.`,
            canCu: 'Quy tắc cộng hai lôgarit cùng cơ số: $\\log_{a}m + \\log_{a}n = \\log_{a}\\left(mn\\right)$, dùng được khi $m$, $n$ dương.',
          },
          {
            viec: `Đưa về dạng không còn lôgarit: $x\\left(x - ${d}\\right) = ${a}^{${k}} = ${A}$.`,
            canCu: 'Định nghĩa lôgarit: $\\log_{a}b = c$ tương đương $b = a^{c}$.',
          },
          {
            viec: `$x^{2} - ${d}x - ${A} = 0$, hai nghiệm là $x = ${p}$ và $x = ${loai}$.`,
            canCu: 'Giải phương trình bậc hai thu được.',
          },
          {
            viec: `Đối chiếu điều kiện $x > ${d}$: nghiệm $x = ${loai}$ bị LOẠI, nghiệm $x = ${p}$ được nhận.`,
            canCu: 'Đối chiếu từng nghiệm với điều kiện xác định; nghiệm nằm ngoài điều kiện phải loại.',
          },
          {
            viec: `Vậy phương trình có nghiệm duy nhất $x = ${p}$.`,
            canCu: 'Ghi kết luận chỉ gồm các nghiệm đã qua đối chiếu.',
          },
        ],
      hints: [
        'Đặt điều kiện TRƯỚC khi biến đổi, không phải sau khi ra đáp số.',
        `Phép gộp $\\log u + \\log v = \\log\\left(uv\\right)$ mở rộng tập xác định, nên sinh ra nghiệm ngoại lai.`,
        `Điều kiện chặt hơn là $x > ${d}$, không phải chỉ $x > 0$.`,
      ],
      answer: `x = ${p}`,
      check: { expression: `log(${p}, ${a}) + log(${p} - ${d}, ${a})`, equals: `${k}` },
    }),
  },
  {
    id: 'BP.M12.NGUYENHAM.HANGSO',
    formCode: 'M12.NGUYENHAM.COBAN',
    intent: 'Hằng số C không phải thứ trang trí: khi bài cho một điều kiện ban đầu thì C có giá trị xác định, bỏ quên là sai đáp số.',
    targetTrap: 'quên hằng số C',
    context: 'giải tích',
    shape: { steps: 6, cases: 1 },
    stars: 4,
    levels: [3, 6],
    space: function* () {
      for (const a of [1, 2, 3]) {
        for (let b = -4; b <= 4; b++) {
          for (let c = -3; c <= 3; c++) {
            for (const x0 of [0, 1, 2]) {
              for (const y0 of [-2, 1, 4]) yield { a, b, c, x0, y0 };
            }
          }
        }
      }
    },
    render: ({ a, b, c, x0, y0 }) => {
      const F = (x) => a * x * x * x + b * x * x + c * x;
      const C = y0 - F(x0);
      const x1 = x0 + 2;
      const F1 = F(x1) + C;
      const fTex = `${3 * a}x^{2} ${2 * b >= 0 ? '+' : '-'} ${Math.abs(2 * b)}x ${c >= 0 ? '+' : '-'} ${Math.abs(c)}`;
      return {
        stem: `Biết $F\\left(x\\right)$ là một nguyên hàm của $f\\left(x\\right) = ${fTex}$ và $F\\left(${x0}\\right) = ${y0}$. Tính $F\\left(${x1}\\right)$.`,
        solutionSteps: [
          {
            viec: `Nguyên hàm tổng quát: $F\\left(x\\right) = ${a === 1 ? '' : a}x^{3} ${b >= 0 ? '+' : '-'} ${Math.abs(b)}x^{2} ${c >= 0 ? '+' : '-'} ${Math.abs(c)}x + C$.`,
            canCu: 'Bảng nguyên hàm cơ bản cho họ nguyên hàm, luôn kèm hằng số $C$.',
          },
          {
            viec: `Hằng số $C$ CHƯA xác định — phải dùng điều kiện đề cho mới tìm được.`,
            canCu: 'Hằng số $C$ chưa xác định thì chưa có một hàm cụ thể nào — phải dùng điều kiện đề cho mới chốt được.',
          },
          {
            viec: `Thay $x = ${x0}$: $F\\left(${x0}\\right) = ${F(x0)} + C = ${y0}$.`,
            canCu: 'Thay giá trị của điểm đã biết vào để lập phương trình theo $C$.',
          },
          {
            viec: `Suy ra $C = ${C}$.`,
            canCu: 'Giải ra hằng số $C$.',
          },
          {
            viec: `Vậy $F\\left(x\\right) = ${a === 1 ? '' : a}x^{3} ${b >= 0 ? '+' : '-'} ${Math.abs(b)}x^{2} ${c >= 0 ? '+' : '-'} ${Math.abs(c)}x ${C >= 0 ? '+' : '-'} ${Math.abs(C)}$.`,
            canCu: 'Viết lại hàm số với hằng số đã xác định.',
          },
          {
            viec: `$F\\left(${x1}\\right) = ${F(x1)} ${C >= 0 ? '+' : '-'} ${Math.abs(C)} = ${F1}$.`,
            canCu: 'Thay giá trị cần tính vào hàm vừa tìm.',
          },
        ],
        hints: [
          'Nguyên hàm không phải một hàm mà là cả một HỌ hàm, khác nhau đúng ở hằng số $C$.',
          'Điều kiện đề cho dùng để chọn ra một hàm cụ thể trong họ đó.',
          `Kiểm tra lại: đạo hàm của $F$ phải cho đúng $f$.`,
        ],
        answer: `${F1}`,
        // Kiểm bằng Simpson: với hàm dưới dấu tích phân là đa thức bậc hai,
        // Simpson chính xác tuyệt đối, nên đây là phép kiểm ĐỘC LẬP với việc
        // lấy nguyên hàm ở lời giải: ∫ từ x₀ đến x₁ của f phải bằng F(x₁) − F(x₀).
        check: {
          expression: simpson((x) => `${3 * a}*(${x})^2 + ${2 * b}*(${x}) + (${c})`, `${x0}`, `${x1}`, 2),
          equals: `${F1 - y0}`,
        },
      };
    },
  },
  {
    id: 'BP.M12.DOIBIEN.DOICAN',
    formCode: 'M12.TICHPHAN.DOIBIEN',
    intent: 'Đổi biến thì phải đổi cả CẬN — giữ nguyên cận cũ là tính tích phân của một bài khác.',
    targetTrap: 'quên đổi cận',
    context: 'giải tích',
    shape: { steps: 6, cases: 1 },
    stars: 4,
    levels: [4, 7],
    space: function* () {
      for (const a of [2, 3, 4, 5]) {
        for (let b = -4; b <= 4; b++) {
          for (let p = 0; p <= 2; p++) {
            for (let q = p + 1; q <= p + 4; q++) yield { a, b, p, q };
          }
        }
      }
    },
    render: ({ a, b, p, q }) => {
      const u1 = a * p + b;
      const u2 = a * q + b;
      const I = (u2 ** 3 - u1 ** 3) / (3 * a);
      const trong = `${a}x ${b >= 0 ? '+' : '-'} ${Math.abs(b)}`;
      return {
        stem: `Tính tích phân $I = \\displaystyle\\int_{${p}}^{${q}} \\left(${trong}\\right)^{2}\\,dx$ bằng phương pháp đổi biến số.`,
        solutionSteps: [
          {
            viec: `Đặt $u = ${trong}$, khi đó $du = ${a}\\,dx$, tức $dx = \\dfrac{du}{${a}}$.`,
            canCu: 'Đặt ẩn phụ rồi lấy vi phân hai vế để đổi $dx$ sang $du$.',
          },
          {
            viec: `ĐỔI CẬN — đây là bước hay bị bỏ quên: $x = ${p} \\Rightarrow u = ${u1}$; $x = ${q} \\Rightarrow u = ${u2}$.`,
            canCu: 'Tích phân XÁC ĐỊNH thì cận cũng phải đổi theo biến mới; giữ nguyên cận cũ là tính tích phân của một bài khác.',
          },
          {
            viec: `$I = \\dfrac{1}{${a}}\\displaystyle\\int_{${u1}}^{${u2}} u^{2}\\,du$.`,
            canCu: 'Viết lại tích phân hoàn toàn theo biến mới, không còn dấu vết của biến cũ.',
          },
          {
            viec: `$= \\dfrac{1}{${a}} \\cdot \\left.\\dfrac{u^{3}}{3}\\right|_{${u1}}^{${u2}} = \\dfrac{${u2}^{3} - \\left(${u1}\\right)^{3}}{${3 * a}}$.`,
            canCu: 'Công thức Newton – Leibniz: tích phân bằng hiệu giá trị nguyên hàm tại hai cận.',
          },
          {
            viec: `$= \\dfrac{${u2 ** 3 - u1 ** 3}}{${3 * a}} = ${tiSo(u2 ** 3 - u1 ** 3, 3 * a).includes('/') ? `\\dfrac{${tiSo(u2 ** 3 - u1 ** 3, 3 * a).split('/')[0]}}{${tiSo(u2 ** 3 - u1 ** 3, 3 * a).split('/')[1]}}` : tiSo(u2 ** 3 - u1 ** 3, 3 * a)}$.`,
            canCu: 'Rút gọn về phân số tối giản.',
          },
          {
            viec: `Nếu giữ nguyên cận $${p}$ và $${q}$ cho biến $u$ thì kết quả sẽ là một số khác hẳn — đó là tích phân của bài toán khác.`,
            canCu: 'Nếu không đổi cận thì kết quả là một số khác hẳn, và sai này không lộ ra khi nhìn dạng đáp án.',
          },
        ],
        hints: [
          'Đổi biến là đổi cả ba thứ: hàm, vi phân, và CẬN.',
          `Cận mới tính bằng cách thay cận cũ vào chính biểu thức $u = ${trong}$.`,
          'Cách khác để tự kiểm: khai triển bình phương rồi tính trực tiếp, hai cách phải cho cùng một số.',
        ],
        answer: tiSo(u2 ** 3 - u1 ** 3, 3 * a),
        check: {
          expression: simpson((x) => `(${a}*(${x}) + (${b}))^2`, `${p}`, `${q}`, 2),
          equals: tiSo(u2 ** 3 - u1 ** 3, 3 * a),
        },
      };
    },
  },
  {
    id: 'BP.M12.TUNGPHAN.CHONU',
    formCode: 'M12.TICHPHAN.TUNGPHAN',
    intent: 'Tích phân từng phần chỉ có lợi khi chọn u là phần ĐƠN GIẢN ĐI sau khi đạo hàm — chọn ngược lại thì bài càng rối.',
    targetTrap: 'chọn u, dv sai thứ tự ưu tiên',
    context: 'giải tích',
    shape: { steps: 6, cases: 1 },
    stars: 4,
    levels: [5, 9],
    space: function* () {
      for (let a = 1; a <= 4; a++) {
        for (let b = -3; b <= 4; b++) {
          for (const t of [1, 2, 3]) yield { a, b, t };
        }
      }
    },
    render: ({ a, b, t }) => {
      const trong = `${a === 1 ? '' : a}x ${b >= 0 ? '+' : '-'} ${Math.abs(b)}`;
      const kq = `e^{${t}}\\left(${a * t + b - a}\\right) ${-(b - a) >= 0 ? '+' : '-'} ${Math.abs(b - a)}`;
      return {
        stem: `Tính tích phân $I = \\displaystyle\\int_{0}^{${t}} \\left(${trong}\\right)e^{x}\\,dx$.`,
        solutionSteps: [
          {
            viec: `Thứ tự ưu tiên chọn $u$: lôgarit → đa thức → lượng giác → mũ. Ở đây có đa thức và hàm mũ, nên chọn $u$ là ĐA THỨC.`,
            canCu: 'Thứ tự ưu tiên chọn $u$ là lôgarit, đa thức, lượng giác, rồi mũ — chọn phần mà đạo hàm làm nó đơn giản đi.',
          },
          {
            viec: `Đặt $u = ${trong}$ và $dv = e^{x}\\,dx$; khi đó $du = ${a}\\,dx$ và $v = e^{x}$.`,
            canCu: 'Sau khi chọn $u$ và $dv$, tính $du$ bằng đạo hàm và $v$ bằng nguyên hàm.',
          },
          {
            viec: `$I = \\left.\\left(${trong}\\right)e^{x}\\right|_{0}^{${t}} - ${a}\\displaystyle\\int_{0}^{${t}} e^{x}\\,dx$.`,
            canCu: 'Công thức tích phân từng phần: $\\displaystyle\\int_{a}^{b} u\\,dv = \\left[uv\\right]_{a}^{b} - \\int_{a}^{b} v\\,du$. Dấu trừ đứng trước tích phân còn lại.',
          },
          {
            viec: `$= \\left[\\left(${a * t + b}\\right)e^{${t}} - \\left(${b}\\right)\\right] - ${a}\\left(e^{${t}} - 1\\right)$.`,
            canCu: 'Thay cận trên trừ cận dưới cho phần ngoài dấu tích phân.',
          },
          {
            viec: `$= \\left(${a * t + b - a}\\right)e^{${t}} ${-(b - a) >= 0 ? '+' : '-'} ${Math.abs(b - a)}$.`,
            canCu: 'Tính nốt tích phân còn lại rồi gom hạng tử.',
          },
          {
            viec: `Nếu chọn ngược lại ($u = e^{x}$) thì sau một lần từng phần bậc của đa thức TĂNG lên, bài càng khó hơn lúc đầu.`,
            canCu: 'Chọn ngược thì sau một lần từng phần bậc đa thức TĂNG lên, bài càng làm càng khó — đó là dấu hiệu đã chọn sai.',
          },
        ],
        hints: [
          'Chọn $u$ sao cho $u$ ĐƠN GIẢN ĐI khi đạo hàm; đa thức đạo hàm thì giảm bậc, hàm mũ thì không đổi.',
          'Phần $dv$ phải là phần lấy nguyên hàm được dễ dàng.',
          `Đừng quên phần thế cận $\\left.uv\\right|_{0}^{${t}}$ — mất phần này là mất một nửa đáp số.`,
        ],
        answer: kq,
        // Hàm dưới dấu tích phân có hàm mũ nên Simpson không còn chính xác
        // tuyệt đối; dùng cầu phương Gauss–Legendre 5 điểm chia hai đoạn.
        check: {
          expression: gauss((x) => `(${a}*(${x}) + (${b}))*exp(${x})`, '0', `${t}`, 2),
          equals: `exp(${t})*(${a * t + b - a}) - (${b - a})`,
        },
      };
    },
  },
  {
    id: 'BP.M12.DIENTICH.TACHDOAN',
    formCode: 'M12.UNGDUNG.TICHPHAN',
    intent: 'Diện tích hình phẳng dùng trị tuyệt đối, nên phải TÁCH ĐOẠN tại chỗ hàm đổi dấu; tính một lèo là ra hiệu số chứ không phải diện tích.',
    targetTrap: 'không tách đoạn khi hàm đổi dấu',
    context: 'giải tích',
    shape: { steps: 6, cases: 2 },
    stars: 4,
    levels: [5, 9],
    space: function* () {
      for (let k = 1; k <= 12; k++) {
        for (let m = -3; m <= 3; m++) yield { k, m };
      }
    },
    render: ({ k, m }) => {
      const S = tiSo(8 * k * k * k, 3);
      const STex = S.includes('/') ? `\\dfrac{${S.split('/')[0]}}{${S.split('/')[1]}}` : S;
      const ham = m === 0 ? `x^{2} - ${k * k}` : `\\left(x ${m >= 0 ? '-' : '+'} ${Math.abs(m)}\\right)^{2} - ${k * k}`;
      const L = m - k; const G = m + k; const R = m + 2 * k;
      return {
        stem: `Tính diện tích hình phẳng giới hạn bởi đồ thị hàm số $y = ${ham}$, trục hoành và hai đường thẳng $x = ${L}$, $x = ${R}$.`,
        solutionSteps: [
          {
            viec: `Diện tích là $S = \\displaystyle\\int_{${L}}^{${R}} \\left|${ham}\\right|\\,dx$ — có dấu GIÁ TRỊ TUYỆT ĐỐI.`,
            canCu: 'Công thức diện tích hình phẳng có dấu giá trị tuyệt đối, nên không bỏ qua bước xét dấu được.',
          },
          {
            viec: `Tìm chỗ hàm đổi dấu: $${ham} = 0 \\Leftrightarrow x = ${L}$ hoặc $x = ${G}$.`,
            canCu: 'Tìm nghiệm của hàm dưới dấu tích phân — đó chính là các điểm hàm đổi dấu.',
          },
          {
            viec: `Trên $\\left[${L};\\ ${G}\\right]$ hàm ÂM, trên $\\left[${G};\\ ${R}\\right]$ hàm DƯƠNG, nên phải tách thành hai tích phân.`,
            canCu: 'Giữa hai nghiệm liên tiếp, hàm giữ nguyên dấu, nên mỗi khoảng là một tích phân riêng.',
          },
          {
            viec: `$S = \\displaystyle\\int_{${L}}^{${G}} \\left(${k * k} - \\left(x ${m >= 0 ? '-' : '+'} ${Math.abs(m)}\\right)^{2}\\right)dx + \\displaystyle\\int_{${G}}^{${R}} \\left(\\left(x ${m >= 0 ? '-' : '+'} ${Math.abs(m)}\\right)^{2} - ${k * k}\\right)dx$.`,
            canCu: 'Trên khoảng hàm âm thì đổi dấu biểu thức để bỏ giá trị tuyệt đối; trên khoảng hàm dương thì giữ nguyên.',
          },
          {
            viec: `Tính từng phần: mỗi tích phân bằng $\\dfrac{4 \\cdot ${k}^{3}}{3} = \\dfrac{${4 * k * k * k}}{3}$.`,
            canCu: 'Tính từng tích phân thành phần.',
          },
          {
            viec: `$S = ${STex}$ (đơn vị diện tích). Nếu tính một lèo không tách đoạn thì kết quả bằng $0$ hoặc một số nhỏ hơn — đó là HIỆU hai phần, không phải diện tích.`,
            canCu: 'Cộng các phần lại. Tính một lèo không tách đoạn thì phần âm và phần dương triệt tiêu nhau, ra số nhỏ hơn diện tích thật.',
          },
        ],
        hints: [
          'Diện tích luôn là số không âm; tích phân thì có thể âm.',
          `Nghiệm của hàm dưới dấu tích phân chính là chỗ phải tách đoạn: $x = ${L}$ và $x = ${G}$.`,
          'Trên đoạn hàm âm, bỏ trị tuyệt đối bằng cách ĐỔI DẤU cả biểu thức.',
        ],
        answer: S,
        // Hai đoạn đều là đa thức bậc hai nên Simpson chính xác tuyệt đối;
        // cộng hai đoạn lại đúng bằng tích phân của trị tuyệt đối.
        check: {
          // Hai đoạn, mỗi đoạn là một đa thức bậc hai nên Simpson chính xác
          // tuyệt đối. Đoạn trái hàm âm nên lấy đúng biểu thức ĐÃ ĐỔI DẤU —
          // cộng hai đoạn lại chính là tích phân của trị tuyệt đối.
          expression: simpson((x) => `${k * k} - ((${x}) - (${m}))^2`, `${L}`, `${G}`, 2)
            + ' + ' + simpson((x) => `((${x}) - (${m}))^2 - ${k * k}`, `${G}`, `${R}`, 2),
          equals: S,
        },
      };
    },
  },
  {
    id: 'BP.M12.SOPHUC.LIENHOP',
    formCode: 'M12.SOPHUC.PHUONGTRINH',
    intent: 'Phương trình bậc hai hệ số thực có biệt thức âm vẫn có ĐỦ hai nghiệm, và hai nghiệm đó liên hợp với nhau.',
    targetTrap: 'bỏ nghiệm phức liên hợp',
    context: 'số phức',
    shape: { steps: 6, cases: 1 },
    stars: 4,
    levels: [4, 7],
    space: function* () {
      for (let b = -8; b <= 8; b++) {
        for (let c = 1; c <= 40; c++) {
          const delta = b * b - 4 * c;
          if (delta >= 0) continue;
          if (!chinhPhuong(-delta)) continue;     // phần ảo là số nguyên, học viên tự kiểm được
          yield { b, c, q: Math.sqrt(-delta) / 2 };
        }
      }
    },
    render: ({ b, c, q }) => {
      const p = tiSo(-b, 2);
      const qs = tiSo(Math.sqrt(4 * c - b * b), 2);
      const pTex = p.includes('/') ? `\\dfrac{${p.split('/')[0]}}{${p.split('/')[1]}}` : p;
      const qTex = qs.includes('/') ? `\\dfrac{${qs.split('/')[0]}}{${qs.split('/')[1]}}` : qs;
      return {
        stem: `Giải phương trình $z^{2} ${b >= 0 ? '+' : '-'} ${Math.abs(b)}z + ${c} = 0$ trên tập số phức $\\mathbb{C}$.`,
        solutionSteps: [
          {
            viec: `$\\Delta = ${b}^{2} - 4 \\cdot ${c} = ${b * b - 4 * c}$.`,
            canCu: 'Công thức biệt thức vẫn dùng như trên tập số thực.',
          },
          {
            viec: `$\\Delta < 0$ nên phương trình VÔ NGHIỆM THỰC, nhưng trên $\\mathbb{C}$ vẫn có đủ hai nghiệm.`,
            canCu: 'Biệt thức âm thì vô nghiệm thực, nhưng trên tập số phức phương trình bậc hai luôn có đủ hai nghiệm.',
          },
          {
            viec: `Viết $\\Delta = \\left(i\\sqrt{${4 * c - b * b}}\\right)^{2}$, tức căn bậc hai của $\\Delta$ là $\\pm i\\sqrt{${4 * c - b * b}}$.`,
            canCu: 'Đơn vị ảo thoả $i^{2} = -1$, nên số âm viết được thành bình phương của một số thuần ảo.',
          },
          {
            viec: `$z = \\dfrac{${-b} \\pm i\\sqrt{${4 * c - b * b}}}{2}$.`,
            canCu: 'Công thức nghiệm giữ nguyên, chỉ thay căn của biệt thức bằng số thuần ảo vừa tìm.',
          },
          {
            viec: `Hai nghiệm: $z_{1} = ${pTex} + ${qTex}i$ và $z_{2} = ${pTex} - ${qTex}i$ — hai số LIÊN HỢP của nhau.`,
            canCu: 'Phương trình bậc hai hệ số THỰC có hai nghiệm phức thì chúng luôn LIÊN HỢP với nhau.',
          },
          {
            viec: `Kiểm tra bằng Vi-ét: $z_{1} + z_{2} = ${-b}$ và $z_{1}z_{2} = \\left(${pTex}\\right)^{2} + \\left(${qTex}\\right)^{2} = ${c}$.`,
            canCu: 'Định lý Vi-ét vẫn đúng trên tập số phức, dùng để kiểm lại hai nghiệm.',
          },
        ],
        hints: [
          '$\\Delta < 0$ chỉ nghĩa là không có nghiệm THỰC, không có nghĩa là vô nghiệm.',
          'Phương trình bậc hai hệ số thực luôn có hai nghiệm phức liên hợp khi $\\Delta < 0$ — viết một nghiệm là thiếu.',
          'Dùng Vi-ét để tự kiểm: tổng hai nghiệm phải bằng $-b$, tích phải bằng $c$.',
        ],
        answer: `z = ${p} ± ${qs}i`,
        // Kiểm bằng hệ thức Vi-ét: với z = p ± qi thì z₁z₂ = p² + q² phải bằng c.
        check: { expression: `(${-b}/2)^2 + (sqrt(${4 * c - b * b})/2)^2`, equals: `${c}` },
      };
    },
  },
  {
    id: 'BP.M12.THETICH.CHOPVUONG',
    formCode: 'M12.KHOIDADIEN.THETICH',
    intent: 'Thể tích khối chóp dùng chiều cao HẠ VUÔNG GÓC xuống đáy, không phải cạnh bên — phân biệt được hai thứ này là qua được dạng bài.',
    targetTrap: 'xác định sai chân đường cao',
    context: 'hình học không gian',
    shape: { steps: 5, cases: 1 },
    stars: 4,
    levels: [4, 7],
    space: function* () {
      for (const [pq, qq, cc] of capPytago(40)) {
        for (const h of [3, 6, 9, 12]) {
          if (pq * qq * h % 6 !== 0) continue;   // thể tích ra số nguyên cho gọn
          yield { p: pq, q: qq, c: cc, h };
        }
      }
    },
    render: ({ p, q, c, h }) => {
      const V = (p * q * h) / 6;
      const canhBen = Math.sqrt(p * p + h * h);
      return {
        stem: `Cho khối chóp $S.ABC$ có đáy $ABC$ là tam giác vuông tại $B$ với $AB = ${p}$ cm, $BC = ${q}$ cm. `
          + `Cạnh $SA$ vuông góc với mặt phẳng đáy và $SA = ${h}$ cm. Tính thể tích khối chóp.`,
        solutionSteps: [
          {
            viec: `Vì $SA$ vuông góc với mặt đáy nên CHÂN ĐƯỜNG CAO của khối chóp chính là điểm $A$, và chiều cao bằng $SA = ${h}$ cm.`,
            canCu: 'Cạnh bên vuông góc với đáy thì chính nó là đường cao, và chân đường cao là đỉnh chung của cạnh đó với đáy.',
          },
          {
            viec: `Diện tích đáy: tam giác $ABC$ vuông tại $B$ nên $S_{ABC} = \\dfrac{1}{2} \\cdot ${p} \\cdot ${q} = ${(p * q) / 2}$ cm².`,
            canCu: 'Tính diện tích đáy theo hình dạng thật của đáy.',
          },
          {
            viec: `$V = \\dfrac{1}{3} \\cdot S_{ABC} \\cdot SA = \\dfrac{1}{3} \\cdot ${(p * q) / 2} \\cdot ${h}$.`,
            canCu: 'Thể tích khối chóp bằng một phần ba diện tích đáy nhân CHIỀU CAO.',
          },
          {
            viec: `$V = ${V}$ cm³.`,
            canCu: 'Thay số và rút gọn.',
          },
          {
            viec: `Lưu ý: cạnh bên $SB = \\sqrt{SA^{2} + AB^{2}} = ${Number.isInteger(canhBen) ? canhBen : `\\sqrt{${p * p + h * h}}`}$ cm — dài hơn chiều cao và KHÔNG được thay vào công thức thể tích.`,
            canCu: 'Cạnh bên xiên dài hơn chiều cao; thay cạnh bên vào công thức là làm thể tích lớn hơn thực tế.',
          },
        ],
        hints: [
          'Chiều cao là đoạn vuông góc hạ từ đỉnh xuống mặt phẳng đáy, không phải cạnh bên bất kỳ.',
          `$SA \\perp$ đáy nên chân đường cao là $A$; nếu đề nói $SB \\perp$ đáy thì chân đường cao lại là $B$.`,
          'Diện tích tam giác vuông tính theo hai cạnh GÓC VUÔNG, không dùng cạnh huyền.',
        ],
        answer: `${V} cm³`,
        check: { expression: `(1/3)*(${p}*${q}/2)*${h}`, equals: `${V}` },
      };
    },
  },
  {
    id: 'BP.M12.NON.DUONGSINH',
    formCode: 'M12.TRONXOAY.NON TRU CAU',
    intent: 'Diện tích xung quanh hình nón dùng ĐƯỜNG SINH, thể tích dùng CHIỀU CAO — thay nhầm hai đại lượng này là lỗi phổ biến nhất của chương.',
    targetTrap: 'nhầm đường sinh với chiều cao',
    context: 'hình học không gian',
    shape: { steps: 5, cases: 1 },
    stars: 4,
    levels: [4, 7],
    space: function* () {
      for (const [r, h, l] of capPytago(50)) {
        if (r > 24 || h > 30) continue;
        yield { r, h, l };
      }
    },
    render: ({ r, h, l }) => {
      const sxq = r * l;
      const V = tiSo(r * r * h, 3);
      const VTex = V.includes('/') ? `\\dfrac{${V.split('/')[0]}}{${V.split('/')[1]}}` : V;
      return {
        stem: `Một hình nón có bán kính đáy $R = ${r}$ cm và chiều cao $h = ${h}$ cm. `
          + 'Tính diện tích xung quanh và thể tích của khối nón.',
        solutionSteps: [
          {
            viec: `Đường sinh: $l = \\sqrt{R^{2} + h^{2}} = \\sqrt{${r}^{2} + ${h}^{2}} = ${l}$ cm.`,
            canCu: 'Bán kính, chiều cao và đường sinh của hình nón lập thành một tam giác vuông, đường sinh là cạnh huyền.',
          },
          {
            viec: `Diện tích xung quanh dùng ĐƯỜNG SINH: $S_{xq} = \\pi R l = \\pi \\cdot ${r} \\cdot ${l} = ${sxq}\\pi$ cm².`,
            canCu: 'Diện tích xung quanh hình nón dùng ĐƯỜNG SINH: $S_{xq} = \\pi R l$.',
          },
          {
            viec: `Thể tích dùng CHIỀU CAO: $V = \\dfrac{1}{3}\\pi R^{2} h = \\dfrac{1}{3}\\pi \\cdot ${r * r} \\cdot ${h}$.`,
            canCu: 'Thể tích khối nón dùng CHIỀU CAO: $V = \\dfrac{1}{3}\\pi R^{2}h$.',
          },
          {
            viec: `$V = ${VTex}\\pi$ cm³.`,
            canCu: 'Thay số và rút gọn.',
          },
          {
            viec: `Đường sinh $${l}$ cm và chiều cao $${h}$ cm là hai đoạn KHÁC NHAU; đường sinh luôn dài hơn vì nó là cạnh huyền.`,
            canCu: 'Đường sinh là cạnh huyền nên luôn dài hơn chiều cao; dùng lẫn hai đại lượng là sai cả hai công thức.',
          },
        ],
        hints: [
          'Vẽ mặt cắt qua trục: được tam giác vuông với hai cạnh góc vuông là $R$ và $h$, cạnh huyền là $l$.',
          '$S_{xq}$ dùng $l$, còn $V$ dùng $h$ — nhớ theo hình chứ đừng nhớ theo chữ.',
          `Kiểm tra nhanh: đường sinh phải LỚN HƠN cả $R$ lẫn $h$.`,
        ],
        answer: `Sxq = ${sxq}π cm², V = ${V}π cm³`,
        check: { expression: `${r}*sqrt(${r}^2 + ${h}^2)`, equals: `${sxq}` },
      };
    },
  },
  {
    id: 'BP.M12.OXYZ.KHOANGCACHMP',
    formCode: 'M12.OXYZ.MATPHANG',
    intent: 'Hệ số của x, y, z trong phương trình mặt phẳng chính là vectơ PHÁP TUYẾN — đây là chìa khoá của mọi công thức về mặt phẳng.',
    targetTrap: 'nhầm vectơ pháp tuyến',
    context: 'toạ độ không gian',
    shape: { steps: 5, cases: 1 },
    stars: 4,
    levels: [3, 6],
    space: function* () {
      // Bộ ba Pythagore trong không gian: A² + B² + C² là số chính phương, nhờ
      // vậy mẫu số của công thức khoảng cách là số nguyên.
      const bo = [[1, 2, 2, 3], [2, 3, 6, 7], [1, 4, 8, 9], [4, 4, 7, 9], [2, 6, 9, 11], [6, 6, 7, 11], [3, 4, 12, 13], [2, 5, 14, 15], [2, 10, 11, 15], [1, 12, 12, 17]];
      for (const [A, B, C, N] of bo) {
        for (let xa = -2; xa <= 2; xa += 2) {
          for (let x0 = -3; x0 <= 3; x0 += 3) {
            if (x0 === xa) continue;
            yield { A, B, C, N, xa, ya: 1, za: -1, x0, y0: 2, z0: 1 };
          }
        }
      }
    },
    render: ({ A, B, C, N, xa, ya, za, x0, y0, z0 }) => {
      const D = -(A * xa + B * ya + C * za);
      const tu = Math.abs(A * x0 + B * y0 + C * z0 + D);
      const kc = tiSo(tu, N);
      const kcTex = kc.includes('/') ? `\\dfrac{${kc.split('/')[0]}}{${kc.split('/')[1]}}` : kc;
      return {
        stem: `Trong không gian $Oxyz$, mặt phẳng $\\left(P\\right)$ đi qua điểm $A\\left(${xa};\\ ${ya};\\ ${za}\\right)$ và nhận `
          + `$\\vec{n} = \\left(${A};\\ ${B};\\ ${C}\\right)$ làm vectơ pháp tuyến. `
          + `Viết phương trình mặt phẳng $\\left(P\\right)$ rồi tính khoảng cách từ $M\\left(${x0};\\ ${y0};\\ ${z0}\\right)$ đến $\\left(P\\right)$.`,
        solutionSteps: [
          {
            viec: `Phương trình mặt phẳng qua $A$ với pháp tuyến $\\vec{n}$: $${A}\\left(x - ${xa}\\right) + ${B}\\left(y - ${ya}\\right) + ${C}\\left(z ${za >= 0 ? '-' : '+'} ${Math.abs(za)}\\right) = 0$.`,
            canCu: 'Phương trình mặt phẳng qua điểm $A$ với pháp tuyến $\\left(a; b; c\\right)$ là $a\\left(x - x_{A}\\right) + b\\left(y - y_{A}\\right) + c\\left(z - z_{A}\\right) = 0$.',
          },
          {
            viec: `Thu gọn: $${A}x + ${B}y + ${C}z ${D >= 0 ? '+' : '-'} ${Math.abs(D)} = 0$.`,
            canCu: 'Khai triển và gom hằng số để đưa về dạng tổng quát.',
          },
          {
            viec: `Ba hệ số đứng trước $x$, $y$, $z$ chính là toạ độ vectơ pháp tuyến — nhìn phương trình là đọc ra ngay $\\vec{n}$.`,
            canCu: 'Vectơ pháp tuyến lấy đúng ba hệ số đứng trước $x$, $y$, $z$; hạng tử tự do không tham gia.',
          },
          {
            viec: `$d\\left(M, \\left(P\\right)\\right) = \\dfrac{\\left|${A} \\cdot ${x0} + ${B} \\cdot ${y0} + ${C} \\cdot ${z0} ${D >= 0 ? '+' : '-'} ${Math.abs(D)}\\right|}{\\sqrt{${A}^{2} + ${B}^{2} + ${C}^{2}}}$.`,
            canCu: 'Công thức khoảng cách từ điểm đến mặt phẳng: tử là giá trị tuyệt đối khi thay toạ độ điểm vào vế trái, mẫu là độ dài vectơ pháp tuyến.',
          },
          {
            viec: `$= \\dfrac{${tu}}{${N}} = ${kcTex}$.`,
            canCu: 'Rút gọn ra kết quả cuối.',
          },
        ],
        hints: [
          'Mẫu số của công thức khoảng cách là độ dài vectơ PHÁP TUYẾN, không phải một vectơ nào khác.',
          'Tử số phải có dấu giá trị tuyệt đối — khoảng cách không âm.',
          `Thay đúng toạ độ của $M$, đừng thay nhầm toạ độ của $A$.`,
        ],
        answer: kc,
        check: { expression: `abs(${A}*(${x0}) + ${B}*(${y0}) + ${C}*(${z0}) + (${D}))/sqrt(${A}^2 + ${B}^2 + ${C}^2)`, equals: kc },
      };
    },
  },
  {
    id: 'BP.M12.OXYZ.GIAODIEM',
    formCode: 'M12.OXYZ.DUONGTHANG',
    intent: 'Hai đường thẳng khác nhau phải dùng HAI THAM SỐ khác nhau; dùng chung một chữ t là tự áp đặt điều kiện không có trong đề.',
    targetTrap: 'nhầm tham số của hai đường khác nhau khi xét cắt nhau',
    context: 'toạ độ không gian',
    shape: { steps: 6, cases: 1 },
    stars: 4,
    levels: [4, 7],
    space: function* () {
      const HUONG = [[1, 2, 1], [2, -1, 1], [1, 1, 2], [3, 1, -1], [1, -2, 2], [2, 2, 1]];
      for (let i = 0; i < HUONG.length; i++) {
        for (let j = 0; j < HUONG.length; j++) {
          if (i === j) continue;
          const u = HUONG[i]; const v = HUONG[j];
          // Hai vectơ chỉ phương phải không cùng phương, và định thức 2×2 đầu
          // phải khác 0 thì mới giải được tham số từ hai phương trình đầu.
          const det = u[0] * v[1] - u[1] * v[0];
          if (det === 0) continue;
          for (const I of [[1, 2, 3], [-1, 0, 2], [2, -3, 1]]) {
            yield { u, v, I, t0: 2, s0: -1, det };
          }
        }
      }
    },
    render: ({ u, v, I, t0, s0 }) => {
      const P = [I[0] - t0 * u[0], I[1] - t0 * u[1], I[2] - t0 * u[2]];
      const Q = [I[0] - s0 * v[0], I[1] - s0 * v[1], I[2] - s0 * v[2]];
      const ts = (p, d, ten) => `${p} ${d >= 0 ? '+' : '-'} ${Math.abs(d) === 1 ? '' : Math.abs(d)}${ten}`;
      return {
        stem: `Trong không gian $Oxyz$, cho hai đường thẳng `
          + `$d_{1}: \\begin{cases} x = ${ts(P[0], u[0], 't')} \\\\ y = ${ts(P[1], u[1], 't')} \\\\ z = ${ts(P[2], u[2], 't')} \\end{cases}$ và `
          + `$d_{2}: \\begin{cases} x = ${ts(Q[0], v[0], 's')} \\\\ y = ${ts(Q[1], v[1], 's')} \\\\ z = ${ts(Q[2], v[2], 's')} \\end{cases}$. `
          + 'Chứng tỏ hai đường thẳng cắt nhau và tìm toạ độ giao điểm.',
        solutionSteps: [
          {
            viec: `Hai đường thẳng KHÁC NHAU nên phải dùng HAI tham số khác nhau: $t$ cho $d_{1}$, $s$ cho $d_{2}$.`,
            canCu: 'Mỗi đường thẳng có tham số riêng của nó; dùng chung một chữ là vô tình bắt hai điểm phải ứng với cùng giá trị tham số, làm mất nghiệm.',
          },
          {
            viec: `Giao điểm nếu có thì thoả đồng thời ba phương trình toạ độ.`,
            canCu: 'Giao điểm là điểm nằm trên cả hai đường nên phải thoả đồng thời ba phương trình toạ độ.',
          },
          {
            viec: `Từ hai phương trình đầu, giải hệ hai ẩn $t$, $s$ được $t = ${t0}$ và $s = ${s0}$.`,
            canCu: 'Lấy hai phương trình để giải ra hai tham số.',
          },
          {
            viec: `Thử vào phương trình thứ ba: $${P[2]} ${u[2] >= 0 ? '+' : '-'} ${Math.abs(u[2])} \\cdot ${t0} = ${I[2]}$ và $${Q[2]} ${v[2] >= 0 ? '+' : '-'} ${Math.abs(v[2])} \\cdot \\left(${s0}\\right) = ${I[2]}$ — KHỚP, nên hai đường thật sự cắt nhau.`,
            canCu: 'Phương trình thứ ba là điều kiện KIỂM TRA: khớp thì hai đường cắt nhau, không khớp thì chéo nhau.',
          },
          {
            viec: `Thay $t = ${t0}$ vào $d_{1}$: giao điểm $I\\left(${I[0]};\\ ${I[1]};\\ ${I[2]}\\right)$.`,
            canCu: 'Thay tham số vừa tìm vào phương trình của một đường để ra toạ độ giao điểm.',
          },
          {
            viec: `Nếu dùng chung một chữ $t$ cho cả hai đường thì đã vô tình bắt hai điểm phải ứng với cùng một giá trị tham số — một điều kiện đề bài không hề nói.`,
            canCu: 'Dùng chung tham số là lỗi âm thầm: bài vẫn ra một đáp số, chỉ là đáp số sai.',
          },
        ],
        hints: [
          'Đặt tên tham số khác nhau cho hai đường ngay từ lúc chép đề.',
          'Giải hệ từ hai phương trình rồi BẮT BUỘC phải thử lại phương trình thứ ba: khớp thì cắt nhau, không khớp thì chéo nhau.',
          'Có nghiệm hệ hai phương trình chưa đủ để kết luận hai đường cắt nhau.',
        ],
        answer: `I(${I[0]}; ${I[1]}; ${I[2]})`,
        // Kiểm ĐỘC LẬP: giải tham số t từ hai phương trình đầu bằng quy tắc
        // Cramer rồi thay vào phương trình toạ độ z của d₁. Kết quả phải đúng
        // bằng cao độ giao điểm — nếu lời giải sai thì con số này lệch ngay.
        check: {
          expression: `(${P[2]}) + ((((${Q[0]}) - (${P[0]}))*(${v[1]}) - ((${Q[1]}) - (${P[1]}))*(${v[0]}))/((${u[0]})*(${v[1]}) - (${u[1]})*(${v[0]})))*(${u[2]})`,
          equals: `${I[2]}`,
        },
      };
    },
  },
  {
    id: 'BP.M12.MATCAU.GIAOTUYEN',
    formCode: 'M12.OXYZ.MATCAU',
    intent: 'Bán kính đường tròn giao tuyến suy ra từ khoảng cách TÂM đến mặt phẳng — sai công thức khoảng cách là sai toàn bộ phần sau.',
    targetTrap: 'sai công thức khoảng cách tâm đến mặt phẳng',
    context: 'toạ độ không gian',
    shape: { steps: 6, cases: 1 },
    stars: 4,
    levels: [4, 9],
    space: function* () {
      const PHAP = [[1, 2, 2, 3], [2, 3, 6, 7], [1, 4, 8, 9], [4, 4, 7, 9], [2, 6, 9, 11]];
      for (const [A, B, C, N] of PHAP) {
        for (const [d, r, R] of [[3, 4, 5], [6, 8, 10], [5, 12, 13], [8, 15, 17], [9, 12, 15], [7, 24, 25]]) {
          if (R > 30) continue;
          for (const I of [[1, 1, 1], [0, 2, -1]]) yield { A, B, C, N, d, r, R, I };
        }
      }
    },
    render: ({ A, B, C, N, d, r, R, I }) => {
      // Chọn hệ số tự do D sao cho khoảng cách từ tâm đến mặt phẳng đúng bằng d.
      const D = d * N - (A * I[0] + B * I[1] + C * I[2]);
      return {
        stem: `Trong không gian $Oxyz$, cho mặt cầu $\\left(S\\right)$ tâm $I\\left(${I[0]};\\ ${I[1]};\\ ${I[2]}\\right)$ bán kính $R = ${R}$ `
          + `và mặt phẳng $\\left(P\\right): ${A}x + ${B}y + ${C}z ${D >= 0 ? '+' : '-'} ${Math.abs(D)} = 0$. `
          + 'Chứng tỏ $\\left(P\\right)$ cắt $\\left(S\\right)$ và tính bán kính đường tròn giao tuyến.',
        solutionSteps: [
          {
            viec: `Khoảng cách từ tâm đến mặt phẳng: $d\\left(I, \\left(P\\right)\\right) = \\dfrac{\\left|${A} \\cdot ${I[0]} + ${B} \\cdot ${I[1]} + ${C} \\cdot ${I[2]} ${D >= 0 ? '+' : '-'} ${Math.abs(D)}\\right|}{\\sqrt{${A}^{2} + ${B}^{2} + ${C}^{2}}}$.`,
            canCu: 'Công thức khoảng cách từ điểm đến mặt phẳng, thay toạ độ tâm vào vế trái.',
          },
          {
            viec: `Mẫu số $\\sqrt{${A}^{2} + ${B}^{2} + ${C}^{2}} = ${N}$; tử số bằng $${d * N}$.`,
            canCu: 'Tính riêng tử và mẫu để tránh nhầm dấu ở bước lấy giá trị tuyệt đối.',
          },
          {
            viec: `$d\\left(I, \\left(P\\right)\\right) = ${d}$.`,
            canCu: 'Rút gọn ra khoảng cách.',
          },
          {
            viec: `Vì $${d} < ${R}$ nên mặt phẳng CẮT mặt cầu theo một đường tròn.`,
            canCu: 'Quy tắc vị trí tương đối: khoảng cách nhỏ hơn bán kính thì cắt nhau theo đường tròn, bằng thì tiếp xúc, lớn hơn thì không có điểm chung.',
          },
          {
            viec: `Bán kính đường tròn giao tuyến: $r = \\sqrt{R^{2} - d^{2}} = \\sqrt{${R}^{2} - ${d}^{2}} = \\sqrt{${R * R - d * d}}$.`,
            canCu: 'Bán kính mặt cầu, khoảng cách từ tâm tới mặt phẳng và bán kính giao tuyến lập thành một tam giác vuông.',
          },
          {
            viec: `$r = ${r}$.`,
            canCu: 'Lấy căn bậc hai để ra bán kính đường tròn giao tuyến.',
          },
        ],
        hints: [
          'Mẫu số là độ dài vectơ pháp tuyến $\\sqrt{A^{2} + B^{2} + C^{2}}$, không phải $A + B + C$.',
          `So sánh $d$ với $R$: $d < R$ thì cắt, $d = R$ thì tiếp xúc, $d > R$ thì không cắt.`,
          '$r$, $d$, $R$ lập thành tam giác vuông với $R$ là cạnh huyền — nhớ theo hình sẽ không nhầm công thức.',
        ],
        answer: `d = ${d} < R = ${R}, bán kính giao tuyến r = ${r}`,
        check: { expression: `sqrt(${R}^2 - (abs(${A}*(${I[0]}) + ${B}*(${I[1]}) + ${C}*(${I[2]}) + (${D}))/sqrt(${A}^2 + ${B}^2 + ${C}^2))^2)`, equals: `${r}` },
      };
    },
  },
];

module.exports = { BP_THPT, simpson, gauss, tiSo, chinhPhuong, capPytago };
