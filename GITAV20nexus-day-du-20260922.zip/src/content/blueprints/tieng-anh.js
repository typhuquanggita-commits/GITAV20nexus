'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BẢN THIẾT KẾ BÀI — TIẾNG ANH (nhóm E)
 * ═══════════════════════════════════════════════════════════════════════════
 *  NÓI TRƯỚC VỀ PHẠM VI, để không ai hiểu nhầm hệ thống làm được gì.
 *
 *  Tám dạng dưới đây SINH ĐƯỢC và KIỂM LẠI ĐƯỢC bằng máy, vì đáp án của chúng
 *  xác định duy nhất: một câu biến đổi đúng luật, một động từ kết hợp đúng,
 *  một con số rút ra từ đoạn nghe.
 *
 *  Bốn dạng còn lại của nhóm E — đọc hiểu ý chính, đọc hiểu suy luận, viết
 *  luận, nói theo chủ đề — KHÔNG ghép được bằng máy: ghép câu bằng máy ra một
 *  đoạn không có ý chính nào để mà hỏi. Nên văn bản của bốn dạng đó được VIẾT
 *  TAY, nằm ở src/lang/en-corpus.js, và bốn bản thiết kế cuối tệp này chỉ làm
 *  việc dựng đề quanh văn bản có sẵn.
 *
 *  Phần máy vẫn kiểm được, và kiểm rất nghiêm, là CHẤT LƯỢNG ĐỀ: bộ kiểm đọc
 *  lại chính đoạn văn, tự tách câu, tự đếm, rồi đo quan hệ giữa từng phương án
 *  với văn bản — ý chính phải trải trên nhiều câu, câu suy luận phải bám bài
 *  mà không câu nào nêu thẳng, dàn ý phải phục vụ đúng dạng câu hỏi đọc ra từ
 *  chữ của đề, bài nói phải chạm đủ bốn gạch đầu dòng của thẻ.
 *
 *  Vẫn nói thẳng một giới hạn: hệ thống KHÔNG chấm bài luận và bài nói thành
 *  band. Chấm band cần người. Cái hệ thống dạy và kiểm được là bước trước khi
 *  viết và trước khi nói — chọn đúng dạng, dựng đủ ý — và đó đúng là chỗ mất
 *  điểm Task Response nhiều nhất.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const G = require('../../lang/en-grammar');
const { DOAN_Y_CHINH, DOAN_SUY_LUAN, DE_LUAN, THE_NOI } = require('../../lang/en-corpus');
const { cumDuyNhat, KET_HOP } = require('../../lang/en-collocation');

const CN = G.CHU_NGU;
const TN = G.TAN_NGU;
const tim = (ten) => CN.find((c) => c.viet === ten);
const timTN = (ten) => TN.find((t) => t.viet === ten);

// Cặp động từ – tân ngữ ĐI ĐƯỢC VỚI NHAU. Ghép bừa động từ với tân ngữ sẽ ra
// những câu đúng ngữ pháp nhưng vô nghĩa ("finish the windows"), và học viên
// đọc một câu vô nghĩa thì không học được gì.
const VIEC = [
  ['write', 'the letter'], ['write', 'the report'], ['clean', 'the room'],
  ['clean', 'the windows'], ['finish', 'the homework'], ['finish', 'the report'],
  ['answer', 'the question'], ['answer', 'the letter'], ['repair', 'the machine'],
  ['open', 'the windows'], ['open', 'the letter'], ['read', 'this book'],
  ['read', 'these books'], ['check', 'the homework'], ['check', 'the report'],
  ['paint', 'the room'], ['take', 'the pictures'], ['send', 'the letter'],
  ['send', 'these books'], ['close', 'the windows'], ['show', 'the pictures'],
  ['bring', 'these books'], ['carry', 'the machine'], ['study', 'this book'],
];

const MOC_THOI_GIAN = [
  { tu: 'last week', thi: 'qua khu don', vi: 'tuần trước' },
  { tu: 'yesterday', thi: 'qua khu don', vi: 'hôm qua' },
  { tu: 'in 2019', thi: 'qua khu don', vi: 'năm 2019' },
  { tu: 'two days ago', thi: 'qua khu don', vi: 'hai ngày trước' },
  { tu: 'already', thi: 'hien tai hoan thanh', vi: 'đã (rồi)' },
  { tu: 'since Monday', thi: 'hien tai hoan thanh', vi: 'từ thứ Hai' },
  { tu: 'for three years', thi: 'hien tai hoan thanh', vi: 'trong ba năm nay' },
  { tu: 'just', thi: 'hien tai hoan thanh', vi: 'vừa mới' },
];

// ── BỐN DẠNG DỰNG QUANH VĂN BẢN VIẾT TAY ───────────────────────────────────

const CHU = ['A', 'B', 'C', 'D'];

/**
 * Xếp bốn phương án, đặt đáp án đúng vào một vị trí ĐỊNH TRƯỚC theo số thứ tự
 * của đơn vị văn bản. Đáp án đúng nằm rải đều ở A, B, C, D thay vì luôn ở A —
 * người học đoán vị trí là đề hỏng, mà xáo ngẫu nhiên thì mất tính lặp lại.
 */
function xepPhuongAn(dung, nhieu, chiSo) {
  const cho = chiSo % 4;
  const con = nhieu.map((n) => n.y);
  const ra = [];
  for (let i = 0; i < 4; i++) ra.push(i === cho ? dung : con.shift());
  return ra.map((y, i) => `${CHU[i]}. ${y}`);
}

const BP_DOC_VIET_NOI = [
  {
    id: 'BP.E.DOC.YCHINH',
    formCode: 'E.READING.MAINIDEA',
    intent: 'Ý chính là câu PHỦ ĐƯỢC CẢ ĐOẠN. Một câu đúng sự thật mà chỉ nói về một dòng của đoạn thì là chi tiết, và chọn nó là mất điểm.',
    targetTrap: 'chọn chi tiết phụ làm ý chính',
    context: 'đọc hiểu',
    shape: { steps: 5, cases: 1 },
    stars: 3,
    levels: [2, 7],
    space: function* () {
      for (let i = 0; i < DOAN_Y_CHINH.length; i++) yield { i };
    },
    render: ({ i }) => {
      const u = DOAN_Y_CHINH[i];
      const pa = xepPhuongAn(u.dung, u.nhieu, i);
      const chiTiet = u.nhieu.find((n) => n.loai === 'chi-tiet');
      const ngoai = u.nhieu.find((n) => n.loai === 'ngoai-bai');
      const rong = u.nhieu.find((n) => n.loai === 'qua-rong');
      return {
        stem: `Đọc đoạn văn sau rồi chọn câu nêu đúng Ý CHÍNH của cả đoạn.\n`
          + `${u.doan}\n`
          + `${pa.join('\n')}\n`
          + `Chép lại nguyên văn phương án đúng.`,
        solutionSteps: [
          {
            viec: `Đếm số câu của đoạn trước đã: đoạn này có ${u.doan.split(/(?<=[.!?])\s+/).filter(Boolean).length} câu, cùng nói về một chuyện là ${u.chuDe}.`,
            canCu: 'Ý chính là điều cả đoạn cùng nói tới, nên việc đầu tiên là xác định đoạn có mấy câu.',
          },
          {
            viec: `Thử từng phương án bằng một câu hỏi: phương án này nói về MẤY CÂU của đoạn? Phương án đúng phải chạm được từ ba câu trở lên.`,
            canCu: 'Ý chính phủ được nhiều câu; chi tiết chỉ phủ được một câu.',
          },
          {
            viec: `Loại "${chiTiet.y}" — câu này đúng, nhưng nó nằm gọn trong MỘT câu của đoạn. Đó là chi tiết, không phải ý chính.`,
            canCu: 'Một phương án nằm gọn trong một câu của đoạn là chi tiết của câu đó.',
          },
          {
            viec: `Loại "${ngoai.y}" — đoạn văn không hề nhắc tới chuyện này. Phương án ngoài bài loại được ngay mà chưa cần so sánh.`,
            canCu: 'Phương án nhắc tới thứ không có trong bài thì sai, dù nghe có lý đến đâu.',
          },
          {
            viec: `Loại "${rong.y}" — phương án này nói rộng hơn bài. Bài viết về một trường hợp, phương án lại nói về mọi trường hợp.`,
            canCu: 'Phương án dùng từ phạm vi (every, always, all) mà bài không hề nói là phương án nói quá.',
          },
        ],
        hints: [
          'Đọc câu đầu và câu cuối trước — chúng thường đỡ lấy ý chính.',
          'Với mỗi phương án, hỏi "câu này nói về mấy câu của đoạn?".',
          'Thấy every, always, all trong phương án thì kiểm lại xem bài có nói rộng đến thế không.',
        ],
        answer: u.dung,
        check: { english: { kieu: 'y chinh', doan: u.doan, dapAnDung: u.dung, nhieu: u.nhieu } },
      };
    },
  },
  {
    id: 'BP.E.DOC.SUYLUAN',
    formCode: 'E.READING.INFERENCE',
    intent: 'Câu suy luận phải BÁM VÀO BÀI mà KHÔNG có sẵn trong bài. Chọn câu bài đã nêu thẳng là trả lời nhầm câu hỏi chi tiết.',
    targetTrap: 'chọn đáp án đúng nhưng không được nêu trong bài',
    context: 'đọc hiểu',
    shape: { steps: 6, cases: 1 },
    stars: 4,
    levels: [4, 9],
    space: function* () {
      for (let i = 0; i < DOAN_SUY_LUAN.length; i++) yield { i };
    },
    render: ({ i }) => {
      const u = DOAN_SUY_LUAN[i];
      const pa = xepPhuongAn(u.dung, u.nhieu, i);
      const daNeu = u.nhieu.find((n) => n.loai === 'da-neu');
      const ngoai = u.nhieu.find((n) => n.loai === 'ngoai-bai');
      const trai = u.nhieu.find((n) => n.loai === 'trai-bai');
      return {
        stem: `Đọc đoạn văn sau. Câu nào SUY RA ĐƯỢC từ đoạn văn, dù đoạn văn không nói thẳng ra?\n`
          + `${u.doan}\n`
          + `${pa.join('\n')}\n`
          + `Chép lại nguyên văn phương án đúng.`,
        solutionSteps: [
          {
            viec: `Ghi ra dữ kiện của đoạn, mỗi câu một dữ kiện. Đoạn nói về ${u.chuDe}.`,
            canCu: 'Suy luận bắt đầu từ việc liệt kê dữ kiện, không từ cảm giác về đoạn văn.',
          },
          {
            viec: 'Câu suy luận đúng phải thoả HAI điều cùng lúc: bám vào dữ kiện của bài, và KHÔNG có câu nào của bài nói thẳng ra nó.',
            canCu: 'Suy luận là điều rút ra từ bài; điều bài đã nêu thẳng là chi tiết, không phải suy luận.',
          },
          {
            viec: `Loại "${daNeu.y}" — đọc lại đi, có một câu của đoạn chứa đủ ý này. Nó đúng, nhưng nó là điều bài NÊU THẲNG.`,
            canCu: 'Một phương án nằm gọn trong một câu của bài là câu trả lời cho câu hỏi chi tiết, không phải suy luận.',
          },
          {
            viec: `Loại "${ngoai.y}" — chuyện này không có dữ kiện nào trong đoạn đỡ. Suy luận phải đi ra TỪ bài.`,
            canCu: 'Suy luận phải dựa trên dữ kiện của bài; thiếu dữ kiện thì đó là phỏng đoán.',
          },
          {
            viec: `Loại "${trai.y}" — phương án này phủ định điều bài khẳng định. Trái bài thì không thể là suy ra từ bài.`,
            canCu: 'Một phương án mâu thuẫn với dữ kiện của bài thì sai, không cần xét tiếp.',
          },
          {
            viec: `Còn lại "${u.dung}" — nối được ít nhất hai dữ kiện của đoạn, và không câu nào của đoạn nói thẳng nó. Đó là câu suy luận.`,
            canCu: 'Phương án nối được nhiều dữ kiện mà bài chưa nêu thẳng chính là suy luận cần tìm.',
          },
        ],
        hints: [
          'Gạch chân dữ kiện trong bài trước khi đọc phương án.',
          'Phương án nào chép gần nguyên một câu của bài thì thường là bẫy "đã nêu".',
          'Thấy not, never, no trong phương án thì dò lại xem bài có phủ định như thế không.',
        ],
        answer: u.dung,
        check: { english: { kieu: 'suy luan', doan: u.doan, dapAnDung: u.dung, nhieu: u.nhieu } },
      };
    },
  },
  {
    id: 'BP.E.VIET.DUNGDANG',
    formCode: 'E.WRITING.TASK2',
    intent: 'Mất điểm nặng nhất của bài luận là LẠC DẠNG: đề hỏi "đồng ý tới đâu" mà bài lại cân hai mặt. Dạng đề đọc ra được từ chính chữ của đề, trước khi viết chữ nào.',
    targetTrap: 'lạc đề',
    context: 'viết học thuật',
    shape: { steps: 8, cases: 1 },
    stars: 5,
    levels: [5, 9],
    space: function* () {
      for (let i = 0; i < DE_LUAN.length; i++) yield { i };
    },
    render: ({ i }) => {
      const u = DE_LUAN[i];
      const pa = xepPhuongAn(u.dung, u.nhieu, i);
      const TEN_DANG = {
        'dong-y': 'đồng ý tới mức nào (agree or disagree)',
        'hai-quan-diem': 'bàn cả hai quan điểm rồi nêu ý mình (discuss both views)',
        'van-de-giai-phap': 'vấn đề và giải pháp (problems and solutions)',
        'nguyen-nhan-giai-phap': 'nguyên nhân và biện pháp (causes and measures)',
        'hai-mat': 'hai mặt, cân hơn thiệt (advantages outweigh disadvantages)',
      };
      const DOI_HOI = {
        'dong-y': 'nêu rõ ĐỒNG Ý hay KHÔNG, kèm LÝ DO (because / since)',
        'hai-quan-diem': 'nhắc CẢ HAI phía (while / although) rồi nói RÕ Ý MÌNH (I believe / I think)',
        'van-de-giai-phap': 'gọi tên VẤN ĐỀ (problem) và nêu GIẢI PHÁP (solution / measure)',
        'nguyen-nhan-giai-phap': 'gọi tên NGUYÊN NHÂN (cause) và nêu BIỆN PHÁP (solution / measure)',
        'hai-mat': 'nêu cả LỢI (advantage) và HẠI (disadvantage / drawback) rồi cân',
      };
      return {
        stem: `Đọc đề viết luận sau. Câu chủ đề nào TRẢ LỜI ĐÚNG DẠNG câu hỏi của đề?\n`
          + `${u.de}\n`
          + `${pa.join('\n')}\n`
          + `Chép lại nguyên văn câu chủ đề đúng.`,
        solutionSteps: [
          {
            viec: 'Trước khi nghĩ nội dung, hãy đọc CÂU LỆNH của đề. Câu lệnh là câu cuối, thường in ở dạng câu hỏi.',
            canCu: 'Dạng bài luận nằm ở câu lệnh của đề, không nằm ở phần dẫn nhập.',
          },
          {
            viec: `Câu lệnh của đề này cho biết đề thuộc dạng: ${TEN_DANG[u.dang]}.`,
            canCu: 'Mỗi cụm lệnh của IELTS Task 2 ứng với đúng một dạng bài, tra được bằng chính chữ của đề.',
          },
          {
            viec: `Dạng đó đòi câu chủ đề phải ${DOI_HOI[u.dang]}. Thiếu một trong hai là lạc dạng, dù câu văn hay tới đâu.`,
            canCu: 'Tiêu chí Task Response chấm việc bài có trả lời đúng câu hỏi của đề hay không.',
          },
          {
            viec: `Xét "${u.nhieu[0].y}" — câu này thiếu dấu hiệu bắt buộc của dạng ${TEN_DANG[u.dang]}, nên nó phục vụ một dạng đề khác.`,
            canCu: 'Câu chủ đề phục vụ dạng đề khác là biểu hiện của lạc đề.',
          },
          {
            viec: `Xét "${u.nhieu[1].y}" — đây là một câu SỰ KIỆN, nó thuật lại thông tin chứ không nêu lập trường. Câu chủ đề phải có lập trường.`,
            canCu: 'Câu chủ đề nêu lập trường của người viết; câu thuật thông tin thuộc phần dẫn nhập.',
          },
          {
            viec: `Xét "${u.nhieu[2].y}" — câu này chỉ HỨA sẽ nói, chứ chưa nói gì. Người chấm không cho điểm lời hứa.`,
            canCu: 'Câu chủ đề phải chứa nội dung lập luận, không phải lời thông báo về bố cục bài.',
          },
          {
            viec: `Chọn "${u.dung}" — câu này đủ dấu hiệu của dạng đề, có lập trường và có nội dung.`,
            canCu: 'Câu chủ đề đúng vừa khớp dạng đề vừa nêu được lập trường có nội dung.',
          },
          {
            viec: 'Bước cuối trước khi viết thân bài: từ câu chủ đề vừa chọn, tách ra hai ý lớn, mỗi ý một đoạn thân bài, mỗi đoạn một ví dụ cụ thể.',
            canCu: 'Bố cục bốn đoạn — mở bài, hai thân bài, kết bài — là bố cục chấm được của Task 2.',
          },
        ],
        hints: [
          'Đọc câu lệnh của đề TRƯỚC khi đọc phần dẫn nhập.',
          '"Discuss both views" và "To what extent do you agree" là HAI dạng khác nhau, đừng trộn.',
          'Câu chủ đề mà bỏ đi vẫn không mất gì thì đó là lời hứa, chưa phải lập trường.',
        ],
        answer: u.dung,
        check: { english: { kieu: 'de luan', de: u.de, dapAnDung: u.dung, nhieu: u.nhieu } },
      };
    },
  },
  {
    id: 'BP.E.NOI.DUGACH',
    formCode: 'E.SPEAKING.PART2',
    intent: 'Thẻ Part 2 có ĐÚNG bốn gạch đầu dòng và hai phút. Bỏ sót một gạch là mất điểm tiêu chí Fluency and Coherence, dù ba gạch kia nói rất hay.',
    targetTrap: 'lạc sang ý khác của đề',
    context: 'nói theo chủ đề',
    shape: { steps: 6, cases: 1 },
    stars: 4,
    levels: [4, 8],
    space: function* () {
      for (let i = 0; i < THE_NOI.length; i++) yield { i };
    },
    render: ({ i }) => {
      const u = THE_NOI[i];
      const pa = xepPhuongAn(u.dung, u.nhieu, i);
      const gach = u.the.split('\n').filter((d) => d.trim().startsWith('·')).map((d) => d.replace(/^·\s*/, ''));
      const lac = u.nhieu.find((n) => n.loai === 'lac-de');
      const sot = u.nhieu.filter((n) => n.loai === 'bo-sot');
      return {
        stem: `Đây là một thẻ đề nói có chuẩn bị. Dàn ý nào chạm ĐỦ cả bốn gạch đầu dòng?\n`
          + `${u.the}\n`
          + `${pa.join('\n')}\n`
          + `Chép lại nguyên văn dàn ý đúng.`,
        solutionSteps: [
          {
            viec: `Đếm gạch đầu dòng trước khi nghĩ nội dung: thẻ này có bốn gạch, lần lượt hỏi ${gach.map((g, k) => `(${k + 1}) ${g}`).join(', ')}.`,
            canCu: 'Thẻ đề Part 2 luôn có bốn gạch đầu dòng, và bài nói phải chạm đủ bốn.',
          },
          {
            viec: 'Hai phút chia cho bốn gạch là khoảng ba mươi giây mỗi gạch. Dồn hết thời gian vào gạch dễ nhất là cách mất điểm êm nhất.',
            canCu: 'Điểm Fluency and Coherence chấm việc bài nói có đi hết các ý của thẻ hay không.',
          },
          {
            viec: `Soi từng dàn ý bằng một bảng bốn ô, đánh dấu ô nào đã có. Dàn ý "${sot[0].y.slice(0, 60)}…" bỏ trống một ô.`,
            canCu: 'Đối chiếu dàn ý với từng gạch đầu dòng là cách phát hiện chỗ bỏ sót.',
          },
          {
            viec: `Dàn ý "${sot[1].y.slice(0, 60)}…" cũng bỏ trống một ô, chỉ là ô khác. Nói thêm chi tiết cho ô đã có không bù được ô còn trống.`,
            canCu: 'Nói kỹ một ý không thay thế được một ý bị bỏ sót.',
          },
          {
            viec: `Dàn ý "${lac.y.slice(0, 60)}…" trôi chảy, nhưng nó nói sang chuyện khác hẳn chủ đề của thẻ. Đây là lỗi nặng hơn bỏ sót.`,
            canCu: 'Bài nói lạc chủ đề của thẻ bị trừ ở tiêu chí trả lời đúng đề, dù ngôn ngữ vẫn tốt.',
          },
          {
            viec: `Chọn "${u.dung.slice(0, 60)}…" — dàn ý này bám chủ đề và chạm đủ cả bốn gạch.`,
            canCu: 'Dàn ý đúng vừa bám chủ đề của thẻ vừa chạm đủ bốn gạch đầu dòng.',
          },
        ],
        hints: [
          'Một phút chuẩn bị hãy dùng để ghi bốn từ khoá, mỗi gạch một từ.',
          'Gạch thứ tư bắt đầu bằng "and explain" — nó đòi LÝ DO, không đòi thêm mô tả.',
          'Nói hết bốn ý rồi còn thời gian thì quay lại mở rộng, đừng mở rộng trước.',
        ],
        answer: u.dung,
        check: { english: { kieu: 'the noi', the: u.the, dapAnDung: u.dung, nhieu: u.nhieu } },
      };
    },
  },
];

const BP_TIENG_ANH = [
  {
    id: 'BP.E.THI.MOCTHOIGIAN',
    formCode: 'E.GRAMMAR.TENSE',
    intent: 'Trạng ngữ thời gian QUYẾT ĐỊNH thì, không phải cảm tính — mốc đã kết thúc thì quá khứ đơn, mốc còn nối tới hiện tại thì hiện tại hoàn thành.',
    targetTrap: 'nhầm hiện tại hoàn thành với quá khứ đơn',
    context: 'ngữ pháp',
    shape: { steps: 5, cases: 1 },
    stars: 3,
    levels: [0, 4],
    space: function* () {
      for (const ten of ['He', 'She', 'They', 'The teacher', 'The students']) {
        for (const [v, o] of VIEC) {
          for (const moc of MOC_THOI_GIAN) yield { ten, v, o, moc: moc.tu };
        }
      }
    },
    render: ({ ten, v, o, moc }) => {
      const cn = tim(ten);
      const tn = timTN(o);
      const m = MOC_THOI_GIAN.find((x) => x.tu === moc);
      const nguon = `${cn.viet} ${G.chia(v, 'hien tai don', cn)} ${tn.viet}.`;
      const dapAn = `${cn.viet} ${G.chia(v, m.thi, cn)} ${tn.viet} ${moc}.`;
      const hoanThanh = m.thi === 'hien tai hoan thanh';
      return {
        stem: `Cho câu ở thì hiện tại đơn: "${nguon}" `
          + `Viết lại câu đó với trạng ngữ "${moc}" (${m.vi}), dùng đúng thì.`,
        solutionSteps: [
          {
            viec: `Xác định trạng ngữ trước, chia thì sau. Ở đây trạng ngữ là "${moc}".`,
            canCu: 'Trạng ngữ chỉ thời gian là căn cứ khách quan để chọn thì; cảm giác về câu thì không phải căn cứ.',
          },
          {
            viec: hoanThanh
            ? `"${moc}" nối khoảng thời gian tới TẬN BÂY GIỜ, không chỉ một mốc đã khép lại — đó là dấu hiệu của thì HIỆN TẠI HOÀN THÀNH.`
            : `"${moc}" chỉ một mốc thời gian ĐÃ KẾT THÚC trong quá khứ — đó là dấu hiệu của thì QUÁ KHỨ ĐƠN.`,
            canCu: 'Mốc thời gian đã khép lại trong quá khứ thì dùng thì quá khứ đơn.',
          },
          {
            viec: hoanThanh
            ? `Công thức: ${cn.so === 'it' ? 'has' : 'have'} + quá khứ phân từ. Quá khứ phân từ của "${v}" là "${G.phanTu(v)}".`
            : `Công thức: động từ ở dạng quá khứ đơn. Quá khứ đơn của "${v}" là "${G.quaKhu(v)}".`,
            canCu: 'Quá khứ đơn của động từ bất quy tắc phải tra bảng, không thêm đuôi -ed.',
          },
          {
            viec: `Câu hoàn chỉnh: "${dapAn}"`,
            canCu: 'Ghép chủ ngữ, động từ đã chia và trạng ngữ thành câu hoàn chỉnh.',
          },
          {
            viec: hoanThanh
            ? `Không được viết "${cn.viet} ${G.quaKhu(v)} ${tn.viet} ${moc}." — quá khứ đơn không đi với trạng ngữ loại này.`
            : `Không được viết "${cn.viet} ${G.chia(v, 'hien tai hoan thanh', cn)} ${tn.viet} ${moc}." — hiện tại hoàn thành không đi với mốc thời gian đã khép lại.`,
            canCu: 'Hiện tại hoàn thành không đi với mốc thời gian đã khép lại — đây là lỗi kết hợp thì với trạng ngữ, không phải lỗi chia động từ.',
          },
        ],
        hints: [
          'Nhìn trạng ngữ trước khi nhìn động từ.',
          'Mốc đã xong hẳn (yesterday, last week, in 2019, ago) → quá khứ đơn.',
          'Khoảng còn nối tới hiện tại (since, for, already, just) → hiện tại hoàn thành.',
        ],
        answer: dapAn,
        check: { english: { kieu: 'thi', nguon, thiDich: m.thi, trangNgu: moc } },
      };
    },
  },
  {
    id: 'BP.E.BIDONG.DOITHI',
    formCode: 'E.GRAMMAR.PASSIVE',
    intent: 'Đổi sang bị động thì động từ "to be" phải mang ĐÚNG THÌ của câu chủ động — động từ chính chỉ còn một dạng duy nhất là quá khứ phân từ.',
    targetTrap: 'quên đổi thì của động từ to be',
    context: 'ngữ pháp',
    shape: { steps: 5, cases: 1 },
    stars: 4,
    levels: [2, 5],
    space: function* () {
      for (const ten of ['He', 'She', 'They', 'We', 'The teacher', 'The students']) {
        for (const [v, o] of VIEC) {
          for (const thi of ['hien tai don', 'qua khu don', 'hien tai hoan thanh', 'tuong lai don']) {
            // "They read these books." đọc được thành cả hiện tại lẫn quá khứ:
            // câu nguồn như vậy KHÔNG ra đề được, vì đáp án không duy nhất.
            const cn = tim(ten);
            if (G.chia(v, 'hien tai don', cn) === G.chia(v, 'qua khu don', cn)) continue;
            yield { ten, v, o, thi };
          }
        }
      }
    },
    render: ({ ten, v, o, thi }) => {
      const cn = tim(ten);
      const tn = timTN(o);
      const nguon = `${cn.viet} ${G.chia(v, thi, cn)} ${tn.viet}.`;
      const dapAn = G.biDong({ cn, v, tn, thi });
      const tenThi = { 'hien tai don': 'hiện tại đơn', 'qua khu don': 'quá khứ đơn', 'hien tai hoan thanh': 'hiện tại hoàn thành', 'tuong lai don': 'tương lai đơn' }[thi];
      const beDung = dapAn.split(' ').slice(tn.viet.split(' ').length).join(' ').replace(` ${G.phanTu(v)} by ${cn.tanNgu}.`, '');
      return {
        stem: `Chuyển câu sau sang thể bị động: "${nguon}"`,
        solutionSteps: [
          {
            viec: `Xác định thì của câu chủ động: đây là thì ${tenThi}.`,
            canCu: 'Đổi sang bị động thì thì của câu KHÔNG đổi, nên phải xác định thì gốc trước.',
          },
          {
            viec: `Tân ngữ "${tn.viet}" chuyển lên làm chủ ngữ của câu bị động.`,
            canCu: 'Tân ngữ của câu chủ động lên làm chủ ngữ của câu bị động.',
          },
          {
            viec: `Động từ "to be" phải chia ở ĐÚNG thì ${tenThi} và hợp với chủ ngữ mới: "${beDung}".`,
            canCu: 'Động từ "to be" mang thì của câu và phải hợp với chủ ngữ MỚI — chủ ngữ đã đổi thì cách chia cũng đổi theo.',
          },
          {
            viec: `Động từ chính luôn ở dạng quá khứ phân từ, không đổi theo thì: "${G.phanTu(v)}".`,
            canCu: 'Động từ chính trong câu bị động luôn ở dạng quá khứ phân từ, không mang thì.',
          },
          {
            viec: `Câu bị động: "${dapAn}"`,
            canCu: 'Ghép các thành phần theo đúng trật tự của câu bị động.',
          },
        ],
        hints: [
          'Thì của câu nằm ở động từ "to be", không nằm ở động từ chính.',
          `Động từ chính chỉ có một dạng duy nhất trong câu bị động: quá khứ phân từ "${G.phanTu(v)}".`,
          `Chủ ngữ cũ "${cn.viet}" chuyển thành tân ngữ sau "by": "${cn.tanNgu}".`,
        ],
        answer: dapAn,
        check: { english: { kieu: 'bi dong', nguon, boi: true } },
      };
    },
  },
  {
    id: 'BP.E.DIEUKIEN.PHANLOAI',
    formCode: 'E.GRAMMAR.CONDITIONAL',
    intent: 'Loại 2 nói về hiện tại KHÔNG có thật, loại 3 nói về quá khứ ĐÃ KHÁC ĐI — hai loại dùng hai bộ thì khác nhau và không thay nhau được.',
    targetTrap: 'lẫn loại 2 và loại 3',
    context: 'ngữ pháp',
    shape: { steps: 5, cases: 1 },
    stars: 4,
    levels: [2, 6],
    space: function* () {
      for (const a of ['He', 'She', 'They']) {
        for (const b of ['She', 'We', 'The students']) {
          for (let i = 0; i < VIEC.length; i += 3) {
            for (let j = 1; j < VIEC.length; j += 5) {
              if (i === j) continue;
              for (const loai of [1, 2, 3]) yield { a, b, i, j, loai };
            }
          }
        }
      }
    },
    render: ({ a, b, i, j, loai }) => {
      const cnA = tim(a); const cnB = tim(b);
      const [vA, oA] = VIEC[i]; const [vB, oB] = VIEC[j];
      const tnA = timTN(oA); const tnB = timTN(oB);
      const nguonA = `${cnA.viet} ${G.chia(vA, 'hien tai don', cnA)} ${tnA.viet}.`;
      const nguonB = `${cnB.viet} ${G.chia(vB, 'hien tai don', cnB)} ${tnB.viet}.`;
      const dapAn = G.dieuKien({ cnA, vA, tnA, cnB, vB, tnB, loai });
      const moTa = {
        1: 'điều kiện CÓ THẬT ở hiện tại hoặc tương lai',
        2: 'điều kiện KHÔNG CÓ THẬT ở hiện tại',
        3: 'điều kiện KHÔNG CÓ THẬT ở quá khứ',
      }[loai];
      const congThuc = {
        1: 'If + hiện tại đơn, … will + động từ nguyên thể',
        2: 'If + quá khứ đơn, … would + động từ nguyên thể',
        3: 'If + quá khứ hoàn thành, … would have + quá khứ phân từ',
      }[loai];
      return {
        stem: `Nối hai câu sau thành MỘT câu điều kiện LOẠI ${loai}: "${nguonA}" + "${nguonB}"`,
        solutionSteps: [
          {
            viec: `Câu điều kiện loại ${loai} diễn tả ${moTa}.`,
            canCu: 'Phân loại câu điều kiện theo mức độ có thật của điều kiện, không theo hình thức câu.',
          },
          {
            viec: `Công thức: ${congThuc}.`,
            canCu: 'Mỗi loại câu điều kiện có một công thức cố định cho cả hai mệnh đề.',
          },
          {
            viec: loai === 3
            ? `Mệnh đề If dùng quá khứ HOÀN THÀNH: "had ${G.phanTu(vA)}", không phải quá khứ đơn.`
            : loai === 2
              ? `Mệnh đề If dùng quá khứ ĐƠN: "${vA === 'be' ? 'were' : G.quaKhu(vA)}", còn mệnh đề chính dùng "would".`
              : `Mệnh đề If dùng hiện tại đơn, mệnh đề chính dùng "will".`,
            canCu: 'Áp dụng đúng thì cho từng mệnh đề theo công thức.',
          },
          {
            viec: `Câu hoàn chỉnh: "${dapAn}"`,
            canCu: 'Ghép hai mệnh đề thành câu hoàn chỉnh.',
          },
          {
            viec: loai === 2
            ? `Phân biệt với loại 3: loại 3 sẽ là "If ${cnA.viet.toLowerCase()} had ${G.phanTu(vA)} …, … would have …" — nói về chuyện đã qua, không sửa được nữa.`
            : loai === 3
              ? `Phân biệt với loại 2: loại 2 sẽ là "If ${cnA.viet.toLowerCase()} ${G.quaKhu(vA)} …, … would …" — nói về hiện tại, chuyện vẫn còn đang thế.`
              : `Loại 1 nói chuyện có thể xảy ra thật, nên KHÔNG lùi thì như loại 2 và loại 3.`,
            canCu: 'Loại 1 nói chuyện có thể xảy ra nên không lùi thì; lùi thì là chuyển sang loại 2 hoặc loại 3, tức đổi hẳn nghĩa.',
          },
        ],
        hints: [
          'Đọc đề xem đang nói về hiện tại hay quá khứ trước khi chọn công thức.',
          'Loại 2 lùi một bậc thì; loại 3 lùi hai bậc.',
          'Sau "If" không bao giờ dùng "will" hay "would".',
        ],
        answer: dapAn,
        check: { english: { kieu: 'dieu kien', nguonA, nguonB, loai } },
      };
    },
  },
  {
    id: 'BP.E.QUANHE.DAUPHAY',
    formCode: 'E.GRAMMAR.RELATIVE',
    intent: 'Dấu phẩy không phải chuyện trình bày: có phẩy thì mệnh đề chỉ bổ sung thông tin, không phẩy thì mệnh đề dùng để XÁC ĐỊNH đang nói về ai.',
    targetTrap: 'thiếu dấu phẩy ở mệnh đề không xác định',
    context: 'ngữ pháp',
    shape: { steps: 5, cases: 2 },
    stars: 4,
    levels: [3, 6],
    space: function* () {
      const KHUNG = [
        { danhTu: 'The man', nguoi: true, cauChinh: '§ is my neighbour.' },
        { danhTu: 'The woman', nguoi: true, cauChinh: '§ works in this school.' },
        { danhTu: 'The teacher', nguoi: true, cauChinh: '§ is very famous.' },
        { danhTu: 'The machine', nguoi: false, cauChinh: '§ is very expensive.' },
        { danhTu: 'The book', nguoi: false, cauChinh: '§ is on the table.' },
      ];
      for (let k = 0; k < KHUNG.length; k++) {
        for (const ten of ['He', 'She', 'They']) {
          for (let i = 0; i < VIEC.length; i += 2) {
            for (const xacDinh of [true, false]) yield { k, ten, i, xacDinh, KHUNG_k: KHUNG[k] };
          }
        }
      }
    },
    render: ({ ten, i, xacDinh, KHUNG_k }) => {
      const { danhTu, nguoi, cauChinh } = KHUNG_k;
      const cn = tim(ten);
      const [v, o] = VIEC[i];
      const tn = timTN(o);
      const nguonB = `${cn.viet} ${G.chia(v, 'hien tai don', cn)} ${tn.viet}.`;
      const menhDe = `${G.chia(v, 'hien tai don', cn)} ${tn.viet}`;
      const dapAn = G.quanHe({ danhTu, nguoi, menhDe, cauChinh, xacDinh });
      const dai = nguoi ? 'who' : 'which';
      return {
        stem: `Nối hai câu sau bằng mệnh đề quan hệ ${xacDinh ? 'XÁC ĐỊNH' : 'KHÔNG XÁC ĐỊNH'}: `
          + `"${cauChinh.replace('§', danhTu)}" + "${nguonB}"`,
        solutionSteps: [
          {
            viec: `Danh từ được nói tới là "${danhTu}" — ${nguoi ? 'chỉ người nên dùng "who"' : 'chỉ vật nên dùng "which"'}.`,
            canCu: 'Chọn đại từ quan hệ theo danh từ đứng trước: người dùng "who", vật dùng "which".',
          },
          {
            viec: `Thay chủ ngữ "${cn.viet}" của câu thứ hai bằng đại từ quan hệ "${dai}".`,
            canCu: 'Đại từ quan hệ thay cho thành phần trùng lặp ở câu thứ hai.',
          },
          {
            viec: xacDinh
            ? `Mệnh đề XÁC ĐỊNH trả lời câu hỏi "người/vật nào?", là phần KHÔNG THỂ bỏ, nên viết LIỀN, KHÔNG có dấu phẩy.`
            : `Mệnh đề KHÔNG XÁC ĐỊNH chỉ bổ sung thông tin, bỏ đi câu vẫn đủ nghĩa, nên phải tách bằng HAI dấu phẩy.`,
            canCu: 'Mệnh đề xác định là phần không thể bỏ vì nó chỉ rõ đang nói về ai; loại này viết liền, không có dấu phẩy.',
          },
          {
            viec: `Câu hoàn chỉnh: "${dapAn}"`,
            canCu: 'Ghép thành một câu duy nhất.',
          },
          {
            viec: xacDinh
            ? `Nếu thêm dấu phẩy vào đây thì nghĩa đổi: người nghe sẽ hiểu là đã biết rõ đang nói về ai rồi.`
            : `Thiếu dấu phẩy là lỗi NGHĨA chứ không phải lỗi trình bày — câu sẽ thành mệnh đề xác định.`,
            canCu: 'Thêm dấu phẩy là chuyển sang mệnh đề không xác định, và nghĩa của câu đổi theo — dấu phẩy ở đây là ngữ pháp, không phải trình bày.',
          },
        ],
        hints: [
          'Hỏi thử: bỏ mệnh đề đó đi, người nghe có còn biết đang nói về ai không?',
          'Còn biết → không xác định → có hai dấu phẩy. Không còn biết → xác định → không phẩy.',
          'Mệnh đề không xác định KHÔNG dùng được "that".',
        ],
        answer: dapAn,
        check: { english: { kieu: 'quan he', nguonB, danhTu, nguoi, cauChinh, xacDinh } },
      };
    },
  },
  {
    id: 'BP.E.TUONGTHUAT.LUITHI',
    formCode: 'E.GRAMMAR.REPORTED',
    intent: 'Chuyển sang lời tường thuật phải đổi CẢ BA thứ cùng lúc: thì của động từ, đại từ, và trạng ngữ chỉ thời gian.',
    targetTrap: 'quên đổi trạng từ chỉ thời gian',
    context: 'ngữ pháp',
    shape: { steps: 5, cases: 1 },
    stars: 4,
    levels: [3, 6],
    space: function* () {
      for (const nguoiNoi of ['Tom', 'Mary', 'The teacher', 'My brother']) {
        for (const ten of ['I', 'He', 'She', 'We', 'They']) {
          for (let i = 0; i < VIEC.length; i += 2) {
            for (const tg of ['today', 'yesterday', 'tomorrow', 'now', 'this week']) {
              yield { nguoiNoi, ten, i, tg };
            }
          }
        }
      }
    },
    render: ({ nguoiNoi, ten, i, tg }) => {
      const cn = tim(ten);
      const [v, o] = VIEC[i];
      const tn = timTN(o);
      const nguon = `${cn.viet} ${G.chia(v, 'hien tai don', cn)} ${tn.viet}.`;
      const trucTiep = `${cn.viet} ${G.chia(v, 'hien tai don', cn)} ${tn.viet} ${tg}.`;
      const dapAn = G.tuongThuat({ nguoiNoi, cn, v, tn, thi: 'hien tai don', trangNgu: tg });
      const tgMoi = G.DOI_TRANG_NGU[tg] || tg;
      const daiTuMoi = cn.viet === 'I' ? 'he' : cn.viet === 'We' ? 'they' : cn.viet.toLowerCase();
      return {
        stem: `Chuyển câu sau sang lời nói gián tiếp: ${nguoiNoi} said: "${trucTiep}"`,
        solutionSteps: [
          {
            viec: `Động từ tường thuật "said" ở quá khứ, nên phải LÙI THÌ mệnh đề được tường thuật.`,
            canCu: 'Động từ tường thuật ở quá khứ thì mệnh đề được tường thuật phải lùi thì một bậc.',
          },
          {
            viec: `Lùi thì: hiện tại đơn "${G.chia(v, 'hien tai don', cn)}" trở thành quá khứ đơn "${G.chiaLui(v, 'qua khu don', cn)}".`,
            canCu: 'Quy tắc lùi thì: hiện tại đơn thành quá khứ đơn, quá khứ đơn thành quá khứ hoàn thành.',
          },
          {
            viec: `Đổi đại từ theo người nói: "${cn.viet}" trở thành "${daiTuMoi}".`,
            canCu: 'Đại từ đổi theo người kể lại, không giữ nguyên như lời nói trực tiếp.',
          },
          {
            viec: `Đổi trạng ngữ chỉ thời gian: "${tg}" trở thành "${tgMoi}" — đây là bước hay bị bỏ quên nhất.`,
            canCu: 'Trạng ngữ chỉ thời gian và nơi chốn cũng phải đổi theo mốc kể lại.',
          },
          {
            viec: `Câu tường thuật: "${dapAn}"`,
            canCu: 'Ghép thành câu tường thuật hoàn chỉnh; thiếu một trong ba phép đổi là câu sai.',
          },
        ],
        hints: [
          'Ba thứ phải đổi cùng lúc: thì, đại từ, trạng ngữ thời gian.',
          `"${tg}" tính theo thời điểm người ta NÓI, nên khi kể lại phải đổi thành "${tgMoi}".`,
          'Nếu điều được nói vẫn còn đúng ở hiện tại (chân lý, thói quen) thì được phép GIỮ NGUYÊN thì — lùi thì máy móc là sai.',
        ],
        answer: dapAn,
        check: { english: { kieu: 'tuong thuat', nguon, nguoiNoi, trangNgu: tg } },
      };
    },
  },
  {
    id: 'BP.E.KETHOPTU.DOMAKE',
    formCode: 'E.VOCAB.COLLOCATION',
    intent: 'Kết hợp từ không suy ra được từ nghĩa — dịch từng từ từ tiếng Việt là ra "make homework". Phải học theo CỤM.',
    targetTrap: 'dịch từng từ từ tiếng Việt sang',
    context: 'từ vựng',
    shape: { steps: 4, cases: 1 },
    stars: 3,
    levels: [1, 6],
    space: function* () {
      for (const { cum, dung } of cumDuyNhat()) {
        // Ba phương án nhiễu lấy theo thứ tự cố định trong bảng, bỏ qua mọi
        // động từ thật sự đi được với cụm này — nhờ vậy đề không bao giờ có
        // hai đáp án cùng đúng.
        const nhieu = Object.keys(KET_HOP).filter((v) => v !== dung && !KET_HOP[v].includes(cum)).slice(0, 3);
        if (nhieu.length < 3) continue;
        yield { cum, dung, nhieu };
      }
    },
    render: ({ cum, dung, nhieu }) => {
      const luaChon = [dung, ...nhieu].sort();
      const nhan = ['A', 'B', 'C', 'D'];
      return {
        stem: `Chọn động từ đúng để điền vào chỗ trống: "_____ ${cum}". `
          + luaChon.map((v, i) => `${nhan[i]}. ${v}`).join('   '),
        solutionSteps: [
          {
            viec: `Đáp án đúng là ${nhan[luaChon.indexOf(dung)]}: "${dung} ${cum}".`,
            canCu: 'Chọn phương án theo thói quen kết hợp từ của người bản ngữ, không theo nghĩa từ điển của từng từ.',
          },
          {
            viec: `Đây là một CỤM CỐ ĐỊNH của tiếng Anh, không suy ra được từ nghĩa của từng từ.`,
            canCu: 'Kết hợp từ là cụm cố định; nghĩa của cụm không suy ra được từ nghĩa các thành phần.',
          },
          {
            viec: `Ba động từ còn lại (${nhieu.join(', ')}) đều không đi với "${cum}" — người bản ngữ không nói như vậy.`,
            canCu: 'Các phương án còn lại đều đúng ngữ pháp nhưng người bản ngữ không dùng — đó chính là chỗ đánh bẫy.',
          },
          {
            viec: `Cách học: ghi vào sổ nguyên cụm "${dung} ${cum}", không ghi riêng từng từ.`,
            canCu: 'Cách học đúng là ghi nhớ nguyên cụm, vì đơn vị được dùng lại là cả cụm chứ không phải từng từ.',
          },
        ],
        hints: [
          'Đừng dịch từng từ từ tiếng Việt — tiếng Việt dùng "làm" cho cả "do" lẫn "make".',
          `Nhớ theo cụm: "${dung} ${cum}".`,
          'Khi không chắc, thử đọc to cả cụm lên; cụm sai thường nghe rất gượng.',
        ],
        answer: dung,
        check: { english: { kieu: 'ket hop tu', cum, dapAnDung: dung, nhieu } },
      };
    },
  },
  {
    id: 'BP.E.NGHE.SUALAI',
    formCode: 'E.LISTENING.DETAIL',
    intent: 'Bài nghe thật luôn có chỗ người nói tự sửa lại thông tin — nghe được câu đầu mà bỏ câu sửa là ghi sai đáp án.',
    targetTrap: 'bẫy đổi thông tin phút chót',
    context: 'nghe hiểu',
    shape: { steps: 5, cases: 1 },
    stars: 4,
    levels: [2, 7],
    space: function* () {
      const THU = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
      for (const thu of THU) {
        for (let gio1 = 8; gio1 <= 11; gio1++) {
          for (let gio2 = 8; gio2 <= 15; gio2++) {
            if (gio2 === gio1) continue;
            for (const keoDai of [1, 2, 3]) {
              if (gio2 + keoDai > 18) continue;
              yield { thu, gio1, gio2, keoDai };
            }
          }
        }
      }
    },
    render: ({ thu, gio1, gio2, keoDai }) => {
      const ketThuc = gio2 + keoDai;
      const kich = `Good morning. The English club meets on ${thu}. `
        + `The meeting starts at ${gio1} o'clock. `
        + `Sorry, not ${gio1} — the meeting starts at ${gio2} o'clock. `
        + `It lasts ${keoDai} ${keoDai === 1 ? 'hour' : 'hours'}.`;
      return {
        stem: `Nghe đoạn thông báo sau rồi trả lời: buổi sinh hoạt KẾT THÚC lúc mấy giờ?\n`
          + `[NGHE]${kich}[/NGHE]\n`
          + `(Đoạn này đọc được bằng bộ giọng tiếng Anh của hệ thống; học viên chỉ nghe, không nhìn chữ.)`,
        solutionSteps: [
          {
            viec: `Người nói nêu giờ bắt đầu là ${gio1} giờ.`,
            canCu: 'Ghi lại thông tin đầu tiên nghe được, nhưng chưa chốt vội.',
          },
          {
            viec: `Ngay sau đó người nói TỰ SỬA: "Sorry, not ${gio1}" — giờ bắt đầu thật là ${gio2} giờ.`,
            canCu: 'Người nói tự sửa thì thông tin trước đó bị huỷ; lời nói thật luôn có những chỗ sửa như vậy.',
          },
          {
            viec: `Thông tin cuối cùng mới là thông tin đúng; câu trước đó đã bị huỷ.`,
            canCu: 'Thông tin sau cùng mới là thông tin dùng để trả lời.',
          },
          {
            viec: `Buổi sinh hoạt kéo dài ${keoDai} giờ, nên kết thúc lúc ${gio2} + ${keoDai} = ${ketThuc} giờ.`,
            canCu: 'Tính toán dựa trên thông tin đã chốt.',
          },
          {
            viec: `Nghe sót câu sửa sẽ ra ${gio1} + ${keoDai} = ${gio1 + keoDai} giờ — sai.`,
            canCu: 'Nghe sót câu sửa thì vẫn ra một đáp án nhìn hợp lý — đây là kiểu sai khó tự phát hiện nhất khi nghe.',
          },
        ],
        hints: [
          'Nghe hết câu rồi mới ghi; đừng ghi ngay khi vừa nghe thấy con số đầu tiên.',
          'Các từ "sorry", "actually", "I mean", "no wait" báo hiệu thông tin phía trước sắp bị sửa.',
          'Câu hỏi hỏi giờ KẾT THÚC, không hỏi giờ bắt đầu — đọc kỹ câu hỏi trước khi nghe.',
        ],
        answer: `${ketThuc}`,
        check: { expression: `${gio2} + ${keoDai}`, equals: `${ketThuc}` },
      };
    },
  },
  {
    id: 'BP.E.VIET.CAUTONGQUAN',
    formCode: 'E.WRITING.TASK1',
    intent: 'Bài mô tả số liệu mất điểm nặng nhất ở chỗ thiếu CÂU TỔNG QUAN — liệt kê hết số liệu mà không nêu nét nổi bật thì không phải là mô tả.',
    targetTrap: 'thiếu câu tổng quan',
    context: 'viết học thuật',
    shape: { steps: 5, cases: 1 },
    stars: 4,
    levels: [4, 8],
    space: function* () {
      for (let a = 10; a <= 40; a += 10) {
        for (const b1 of [5, 10, 15]) {
          for (const b2 of [5, 10, 20]) {
            for (const b3 of [5, 15, 25]) {
              const d = [a, a + b1, a + b1 + b2, a + b1 + b2 + b3];
              if (d[3] > 95) continue;
              yield { d0: d[0], d1: d[1], d2: d[2], d3: d[3] };
            }
          }
        }
      }
    },
    render: ({ d0, d1, d2, d3 }) => {
      const nam = [2018, 2020, 2022, 2024];
      const so = [d0, d1, d2, d3];
      const tang = d3 - d0;
      const buoc = [d1 - d0, d2 - d1, d3 - d2];
      const manhNhat = buoc.indexOf(Math.max(...buoc));
      return {
        // Mỗi dòng của bảng kết thúc bằng dấu chấm và không thụt đầu dòng bằng
        // hai dấu cách: bộ soát tiếng Việt gộp cả bảng vào câu đầu nếu các dòng
        // không tự kết thúc, và bắt lỗi thừa dấu cách ở phần thụt đầu dòng.
        stem: 'Bảng sau cho biết tỉ lệ học viên dùng ứng dụng học tiếng Anh, tính theo phần trăm.\n'
          + nam.map((n, i) => `${n}: ${so[i]}%.`).join('\n')
          + '\nViết một đoạn khoảng 150 từ mô tả bảng trên. '
          + 'Trước hết hãy viết CÂU TỔNG QUAN. '
          + 'Sau đó cho biết giai đoạn nào tăng mạnh nhất và tăng bao nhiêu điểm phần trăm.',
        solutionSteps: [
          {
            viec: `Câu tổng quan phải nêu XU HƯỚNG CHUNG, không nêu số cụ thể: tỉ lệ tăng liên tục suốt giai đoạn ${nam[0]}–${nam[3]}.`,
            canCu: 'Câu tổng quan nêu xu hướng chung của cả bảng; nêu số cụ thể là việc của phần thân bài.',
          },
          {
            viec: `Tính mức tăng cả giai đoạn: ${d3} − ${d0} = ${tang} điểm phần trăm.`,
            canCu: 'Mức tăng cả giai đoạn bằng giá trị cuối trừ giá trị đầu, đơn vị là điểm phần trăm.',
          },
          {
            viec: `Tính mức tăng từng giai đoạn: ${nam[0]}–${nam[1]} tăng ${buoc[0]}; ${nam[1]}–${nam[2]} tăng ${buoc[1]}; ${nam[2]}–${nam[3]} tăng ${buoc[2]}.`,
            canCu: 'Tính mức tăng từng chặng để so sánh, không ước lượng bằng mắt.',
          },
          {
            viec: `Giai đoạn tăng mạnh nhất là ${nam[manhNhat]}–${nam[manhNhat + 1]}, tăng ${buoc[manhNhat]} điểm phần trăm.`,
            canCu: 'Chặng tăng mạnh nhất là chặng có mức tăng lớn nhất trong các số vừa tính.',
          },
          {
            viec: `Bố cục đoạn văn: một câu mở bài diễn đạt lại đề · một CÂU TỔNG QUAN · hai đoạn thân bài nêu số liệu chọn lọc. `
            + `Liệt kê đủ bốn con số mà không có câu tổng quan thì mất điểm tiêu chí "Task Achievement".`,
            canCu: 'Bài mô tả số liệu mất điểm nặng nhất khi thiếu câu tổng quan hoặc khi liệt kê hết mọi con số mà không chọn lọc.',
          },
        ],
        hints: [
          'Câu tổng quan nêu xu hướng, KHÔNG nêu con số cụ thể.',
          'Không mô tả hết mọi số liệu — chọn điểm cao nhất, thấp nhất và chỗ thay đổi mạnh nhất.',
          'Mức tăng tính bằng ĐIỂM PHẦN TRĂM khi số liệu vốn đã là phần trăm.',
        ],
        answer: `${buoc[manhNhat]}`,
        check: { expression: `${so[manhNhat + 1]} - ${so[manhNhat]}`, equals: `${buoc[manhNhat]}` },
      };
    },
  },
];

BP_TIENG_ANH.push(...BP_DOC_VIET_NOI);

module.exports = { BP_TIENG_ANH, BP_DOC_VIET_NOI, VIEC, MOC_THOI_GIAN };
