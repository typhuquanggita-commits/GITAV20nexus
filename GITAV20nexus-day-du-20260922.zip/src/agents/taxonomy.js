'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BẢNG PHÂN CÔNG 500 TRỢ LÝ AI — GITAmath Nexus V20
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Tổ chức theo HAI chiều trực giao, đúng như hai bảng trong tài liệu gốc:
 *
 *    Chiều 1 — KHỐI CHUYÊN MÔN (division)   : Math 80 · Vietnamese 100 · Tutor 100
 *                                             Research 80 · Code 80 · Business 60 = 500
 *    Chiều 2 — CẤP BẬC / CHỨC NĂNG (rank)   : Planner 10 · Worker 400 · Critic 30
 *                                             Coach 20 · Researcher 20 · Guardian 20 = 500
 *
 *  ALLOCATION là ma trận phân bổ ĐƯỢC CHỐT SẴN, tổng đúng theo CẢ HAI chiều.
 *  Không sinh ngẫu nhiên — cùng một danh sách 500 agent sau mỗi lần khởi động.
 *  Ràng buộc này được kiểm tra bằng unit test (test/agents.test.js).
 * ═══════════════════════════════════════════════════════════════════════════
 */

// ── CHIỀU 1: KHỐI CHUYÊN MÔN ────────────────────────────────────────────────
const DIVISIONS = {
  MATH: {
    id: 'MATH', code: 'MTH', name: 'Khối Toán học', size: 80,
    specialty: 'math_reasoning',
    scope: 'math',
    mission: 'Soạn đề, viết lời giải LaTeX, hiệu chỉnh độ khó, bồi dưỡng Olympiad',
    defaultTier: 'balanced',
    squads: ['item-authoring', 'solution-writing', 'difficulty-calibration', 'olympiad'],
    systemPrompt: 'Bạn là chuyên gia toán học của GITAmath. Trình bày từng bước, dùng LaTeX chuẩn (\\dfrac, \\sqrt{}, ^{}). Tuyệt đối không viết sai dấu hay thiếu điều kiện.',
  },
  VIETNAMESE: {
    id: 'VIETNAMESE', code: 'VIE', name: 'Khối Ngôn ngữ Việt', size: 100,
    specialty: 'vietnamese',
    scope: 'lang',
    mission: 'Nội dung tiếng Việt, ngữ pháp, đọc hiểu, biên tập, bản địa hoá',
    defaultTier: 'fast',
    squads: ['lang-grammar', 'lang-reading', 'lang-writing', 'content-vi', 'localization'],
    systemPrompt: 'Bạn là chuyên gia ngôn ngữ Việt của GITAmath. Viết chuẩn chính tả, ngữ pháp, phù hợp lứa tuổi học sinh phổ thông.',
  },
  TUTOR: {
    id: 'TUTOR', code: 'TUT', name: 'Khối Gia sư', size: 100,
    specialty: 'tutoring',
    scope: 'tutor',
    mission: 'Kèm 1-1, gợi ý nhiều cấp, giải thích, coaching lộ trình',
    defaultTier: 'balanced',
    squads: ['socratic', 'friendly', 'strict', 'expert', 'coach-1v1'],
    systemPrompt: 'Bạn là gia sư kiên nhẫn của GITAmath. Không đưa đáp án ngay — dẫn dắt bằng câu hỏi. Không làm hộ bài tập về nhà.',
  },
  RESEARCH: {
    id: 'RESEARCH', code: 'RES', name: 'Khối Nghiên cứu', size: 80,
    specialty: 'long_context',
    scope: 'research',
    mission: 'Nghiên cứu chương trình, knowledge graph, phân tích đề thi, tài liệu dài',
    defaultTier: 'strong',
    squads: ['curriculum', 'knowledge-graph', 'exam-intel', 'longform-analysis'],
    systemPrompt: 'Bạn là nhà nghiên cứu giáo dục của GITAmath. Phân tích sâu, trích nguồn, nêu rõ mức độ chắc chắn.',
  },
  CODE: {
    id: 'CODE', code: 'COD', name: 'Khối Kỹ thuật', size: 80,
    specialty: 'code_generation',
    scope: 'eng',
    mission: 'Sinh mã, review, kiểm thử, vận hành hạ tầng',
    defaultTier: 'balanced',
    squads: ['codegen', 'review', 'test', 'devops'],
    systemPrompt: 'Bạn là kỹ sư phần mềm cấp cao của GITAmath. Code sạch, có test, xử lý lỗi đầy đủ, không dùng eval.',
  },
  BUSINESS: {
    id: 'BUSINESS', code: 'BIZ', name: 'Khối Kinh doanh', size: 60,
    specialty: 'complex_reasoning',
    scope: 'biz',
    mission: 'Tài chính, tăng trưởng, BI, chiến lược',
    defaultTier: 'strong',
    squads: ['finance', 'growth', 'bi'],
    systemPrompt: 'Bạn là chiến lược gia của GITAmath. Đưa khuyến nghị hành động được, có số liệu, nêu rõ giả định.',
  },
};

// ── CHIỀU 2: CẤP BẬC / CHỨC NĂNG ────────────────────────────────────────────
/**
 * capacity.maxConcurrent  : số task chạy song song tối đa của một agent
 * capacity.tokensPerMin   : hạn mức token/phút của một agent
 * capacity.tasksPerHour   : công suất danh định dùng để tính mức sử dụng (utilization)
 * kpi.*                   : ngưỡng KPI riêng theo cấp bậc
 */
const RANKS = {
  PLANNER: {
    id: 'PLANNER', code: 'PL', name: 'Điều phối viên', total: 10, weight: 5,
    duty: 'Chia nhỏ tác vụ phức tạp, phân công cho tổ, tổng hợp kết quả',
    permissions: ['task.execute', 'task.decompose', 'task.assign', 'agent.dispatch', 'kb.read', 'llm.call:strong'],
    capacity: { maxConcurrent: 2, tokensPerMin: 4000, tasksPerHour: 12 },
    kpi: { successRate: 0.92, qualityScore: 0.88, p95LatencyMs: 12000, costPerTaskUsd: 0.004 },
    tierOverride: 'strong',
  },
  WORKER: {
    id: 'WORKER', code: 'WK', name: 'Chuyên viên thực thi', total: 400, weight: 1,
    duty: 'Thực thi tác vụ chuyên môn chính của khối',
    permissions: ['task.execute', 'kb.read', 'llm.call:balanced'],
    capacity: { maxConcurrent: 4, tokensPerMin: 2000, tasksPerHour: 40 },
    kpi: { successRate: 0.90, qualityScore: 0.85, p95LatencyMs: 5000, costPerTaskUsd: 0.001 },
    tierOverride: null,
  },
  CRITIC: {
    id: 'CRITIC', code: 'CR', name: 'Thanh tra chất lượng', total: 30, weight: 3,
    duty: 'Chấm chất lượng đầu ra, quyền phủ quyết (điều A23), trả lại việc không đạt',
    permissions: ['task.execute', 'task.review', 'task.reject', 'kb.read', 'llm.call:strong', 'audit.write'],
    capacity: { maxConcurrent: 2, tokensPerMin: 3000, tasksPerHour: 24 },
    kpi: { successRate: 0.95, qualityScore: 0.92, p95LatencyMs: 8000, costPerTaskUsd: 0.003 },
    tierOverride: 'strong',
  },
  COACH: {
    id: 'COACH', code: 'CO', name: 'Huấn luyện viên prompt', total: 20, weight: 2,
    duty: 'Đề xuất cải tiến prompt cho agent có KPI dưới ngưỡng (điều A18, A26)',
    permissions: ['task.execute', 'prompt.propose', 'kpi.read', 'kb.read', 'llm.call:strong'],
    capacity: { maxConcurrent: 1, tokensPerMin: 3000, tasksPerHour: 8 },
    kpi: { successRate: 0.90, qualityScore: 0.88, p95LatencyMs: 15000, costPerTaskUsd: 0.005 },
    tierOverride: 'strong',
  },
  RESEARCHER: {
    id: 'RESEARCHER', code: 'RS', name: 'Nghiên cứu viên', total: 20, weight: 2,
    duty: 'Tra cứu, tổng hợp tri thức, ghi vào kho tri thức',
    permissions: ['task.execute', 'kb.read', 'kb.write', 'web.search', 'llm.call:strong'],
    capacity: { maxConcurrent: 2, tokensPerMin: 6000, tasksPerHour: 10 },
    kpi: { successRate: 0.88, qualityScore: 0.86, p95LatencyMs: 20000, costPerTaskUsd: 0.006 },
    tierOverride: 'strong',
  },
  GUARDIAN: {
    id: 'GUARDIAN', code: 'GD', name: 'Hộ pháp', total: 20, weight: 4,
    duty: 'Cưỡng chế Hiến pháp và guardrails, chặn tác vụ vi phạm, ghi audit (điều A21–A30)',
    permissions: ['task.execute', 'constitution.enforce', 'task.block', 'audit.write', 'kpi.read', 'llm.call:balanced'],
    capacity: { maxConcurrent: 3, tokensPerMin: 1500, tasksPerHour: 60 },
    kpi: { successRate: 0.97, qualityScore: 0.90, p95LatencyMs: 3000, costPerTaskUsd: 0.0005 },
    tierOverride: null,
  },
};

/**
 * MA TRẬN PHÂN BỔ [division][rank] — chốt sẵn, tổng khớp cả hai chiều.
 * Hàng (khối):  MATH 80 · VIETNAMESE 100 · TUTOR 100 · RESEARCH 80 · CODE 80 · BUSINESS 60 = 500
 * Cột (cấp bậc): PLANNER 10 · WORKER 400 · CRITIC 30 · COACH 20 · RESEARCHER 20 · GUARDIAN 20 = 500
 */
const ALLOCATION = {
  //            PLANNER WORKER CRITIC COACH RESEARCHER GUARDIAN   tổng
  MATH: { PLANNER: 2, WORKER: 64, CRITIC: 5, COACH: 3, RESEARCHER: 3, GUARDIAN: 3 }, //  80
  VIETNAMESE: { PLANNER: 2, WORKER: 80, CRITIC: 6, COACH: 4, RESEARCHER: 4, GUARDIAN: 4 }, // 100
  TUTOR: { PLANNER: 2, WORKER: 80, CRITIC: 6, COACH: 4, RESEARCHER: 4, GUARDIAN: 4 }, // 100
  RESEARCH: { PLANNER: 2, WORKER: 64, CRITIC: 5, COACH: 3, RESEARCHER: 3, GUARDIAN: 3 }, //  80
  CODE: { PLANNER: 1, WORKER: 64, CRITIC: 5, COACH: 3, RESEARCHER: 4, GUARDIAN: 3 }, //  80
  BUSINESS: { PLANNER: 1, WORKER: 48, CRITIC: 3, COACH: 3, RESEARCHER: 2, GUARDIAN: 3 }, //  60
};

const SQUAD_SIZE = 20;

/** Quyền theo phạm vi khối: agent chỉ được nhận task thuộc scope của khối mình (điều A13). */
function scopePermission(division) {
  return `${DIVISIONS[division].scope}.*`;
}

/** Ánh xạ loại task → khối phụ trách. Tường minh, không đoán. */
const TASK_ROUTING = {
  math_reasoning: 'MATH',
  item_authoring: 'MATH',
  solution_writing: 'MATH',
  vietnamese: 'VIETNAMESE',
  content_editing: 'VIETNAMESE',
  tutoring: 'TUTOR',
  hint_generation: 'TUTOR',
  grading: 'TUTOR',
  long_context: 'RESEARCH',
  curriculum_research: 'RESEARCH',
  knowledge_graph: 'RESEARCH',
  code_generation: 'CODE',
  code_review: 'CODE',
  testing: 'CODE',
  complex_reasoning: 'BUSINESS',
  business_analysis: 'BUSINESS',
};

/**
 * Loại việc chính danh của một khối — nghịch đảo của TASK_ROUTING.
 * Giao việc cho một agent cụ thể PHẢI dùng hàm này, nếu không điều A13
 * (AI chỉ làm việc trong chuyên môn của mình) sẽ chặn và treo agent.
 */
const DIVISION_TASK = {
  MATH: 'math_reasoning',
  VIETNAMESE: 'vietnamese',
  TUTOR: 'tutoring',
  RESEARCH: 'long_context',
  CODE: 'code_generation',
  BUSINESS: 'complex_reasoning',
};

function taskTypeForDivision(division) {
  return DIVISION_TASK[division] || 'vietnamese';
}

/** Kiểm tra bất biến của bảng phân công. Gọi lúc khởi động và trong test. */
function validateTaxonomy() {
  const errors = [];

  const divTotal = Object.values(DIVISIONS).reduce((s, d) => s + d.size, 0);
  const rankTotal = Object.values(RANKS).reduce((s, r) => s + r.total, 0);
  if (divTotal !== rankTotal) errors.push(`Tổng khối (${divTotal}) ≠ tổng cấp bậc (${rankTotal})`);

  for (const [dId, d] of Object.entries(DIVISIONS)) {
    const row = ALLOCATION[dId];
    if (!row) { errors.push(`Thiếu hàng phân bổ cho khối ${dId}`); continue; }
    const sum = Object.values(row).reduce((a, b) => a + b, 0);
    if (sum !== d.size) errors.push(`Khối ${dId}: phân bổ ${sum} ≠ quy mô ${d.size}`);
    if (d.size % SQUAD_SIZE !== 0) errors.push(`Khối ${dId}: quy mô ${d.size} không chia hết cho ${SQUAD_SIZE}`);
    if (d.squads.length !== d.size / SQUAD_SIZE) {
      errors.push(`Khối ${dId}: ${d.squads.length} tổ ≠ ${d.size / SQUAD_SIZE} tổ cần có`);
    }
    // Mỗi tổ phải có ít nhất một agent cấp chỉ huy (Planner hoặc Critic)
    const leaders = row.PLANNER + row.CRITIC;
    if (leaders < d.squads.length) errors.push(`Khối ${dId}: ${leaders} chỉ huy < ${d.squads.length} tổ`);
  }

  for (const [rId, r] of Object.entries(RANKS)) {
    const col = Object.values(ALLOCATION).reduce((s, row) => s + (row[rId] || 0), 0);
    if (col !== r.total) errors.push(`Cấp bậc ${rId}: cột ${col} ≠ chỉ tiêu ${r.total}`);
  }

  return { ok: errors.length === 0, errors, total: divTotal, squads: divTotal / SQUAD_SIZE };
}

module.exports = {
  DIVISIONS, RANKS, ALLOCATION, SQUAD_SIZE, TASK_ROUTING, DIVISION_TASK,
  scopePermission, taskTypeForDivision, validateTaxonomy,
};
