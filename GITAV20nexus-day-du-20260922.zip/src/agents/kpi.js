'use strict';
/**
 * KPI & HIỆU SUẤT — đo cho từng agent, từng tổ, từng khối và toàn hệ.
 *
 *  Chỉ số đo (điều A16, A19 — báo cáo trung thực, không che lỗi):
 *   · successRate      tỉ lệ task thành công
 *   · qualityScore     điểm chất lượng do Critic chấm (0..1)
 *   · p95LatencyMs     độ trễ phân vị 95
 *   · costPerTaskUsd   chi phí trung bình mỗi task
 *   · utilization      mức sử dụng công suất = task thực tế / công suất danh định
 *   · violations       số lần vi phạm Hiến pháp
 *
 *  efficiency = (successRate · qualityScore · utilizationFactor) / costFactor
 *  kpiScore   = trung bình có trọng số của 6 chỉ số đã chuẩn hoá về [0,1]
 */

const cfg = require('../config');
const bus = require('../kernel/eventbus');
const { percentile, round, clamp, ema } = require('../utils');

const WEIGHTS = {
  successRate: 0.30,
  qualityScore: 0.30,
  latency: 0.15,
  cost: 0.15,
  utilization: 0.05,
  compliance: 0.05,
};

function blankMetrics() {
  return {
    tasks: 0, ok: 0, failed: 0, rejected: 0,
    latencies: [], // giữ tối đa 200 mẫu gần nhất
    totalMs: 0, avgMs: 0,
    tokensIn: 0, tokensOut: 0, costUsd: 0,
    qualitySum: 0, qualityN: 0,
    violations: 0, blocks: 0,
    busyMs: 0, firstAt: 0, lastAt: 0,
    coachApplied: 0, coachRolledBack: 0,
  };
}

class KPITracker {
  constructor({ agents }) {
    this.byAgent = new Map();
    this.targets = new Map();
    for (const a of agents) {
      this.byAgent.set(a.id, blankMetrics());
      this.targets.set(a.id, a.kpiTargets);
    }
    this.agentIndex = new Map(agents.map((a) => [a.id, a]));
    this.startedAt = Date.now();
  }

  record(agentId, r) {
    const m = this.byAgent.get(agentId);
    if (!m) return null;
    const now = Date.now();
    if (!m.firstAt) m.firstAt = now;
    m.lastAt = now;

    m.tasks++;
    if (r.ok) m.ok++; else m.failed++;
    if (r.rejected) m.rejected++;

    const ms = r.ms || 0;
    m.latencies.push(ms);
    if (m.latencies.length > 200) m.latencies.shift();
    m.totalMs += ms;
    m.busyMs += ms;
    m.avgMs = round(ema(m.avgMs, ms), 1);

    m.tokensIn += r.tokensIn || 0;
    m.tokensOut += r.tokensOut || 0;
    m.costUsd += r.costUsd || 0;

    if (typeof r.quality === 'number') { m.qualitySum += r.quality; m.qualityN++; }
    if (r.violation) m.violations++;
    if (r.blocked) m.blocks++;

    const snap = this.agent(agentId);
    if (snap.kpiScore < cfg.KPI.coachThreshold && m.tasks >= 10) {
      bus.safeEmit('kpi:below_target', { agentId, kpiScore: snap.kpiScore, tasks: m.tasks });
    }
    return snap;
  }

  /** Chuẩn hoá một chỉ số "càng thấp càng tốt" về [0,1] so với ngưỡng mục tiêu. */
  _lowerIsBetter(actual, target) {
    if (!actual) return 1;
    return clamp(target / actual, 0, 1);
  }

  agent(agentId) {
    const m = this.byAgent.get(agentId);
    const a = this.agentIndex.get(agentId);
    if (!m || !a) return null;
    const t = this.targets.get(agentId);

    const successRate = m.tasks ? m.ok / m.tasks : 0;
    const qualityScore = m.qualityN ? m.qualitySum / m.qualityN : 0;
    const p95 = percentile(m.latencies, 95);
    const costPerTask = m.tasks ? m.costUsd / m.tasks : 0;

    // Mức sử dụng: task thực tế so với công suất danh định trong khoảng thời gian đã sống.
    const elapsedH = Math.max((Date.now() - this.startedAt) / 3_600_000, 1 / 3600);
    const nominal = a.capacity.tasksPerHour * elapsedH;
    const utilization = clamp(m.tasks / Math.max(nominal, 1), 0, 1);

    const compliance = m.tasks ? clamp(1 - m.violations / m.tasks, 0, 1) : 1;

    const nSuccess = clamp(successRate / t.successRate, 0, 1);
    const nQuality = m.qualityN ? clamp(qualityScore / t.qualityScore, 0, 1) : 0.5; // chưa chấm → trung tính
    const nLatency = this._lowerIsBetter(p95, t.p95LatencyMs);
    const nCost = this._lowerIsBetter(costPerTask, t.costPerTaskUsd);
    const nUtil = clamp(utilization / cfg.KPI.utilization, 0, 1);

    const kpiScore =
      nSuccess * WEIGHTS.successRate +
      nQuality * WEIGHTS.qualityScore +
      nLatency * WEIGHTS.latency +
      nCost * WEIGHTS.cost +
      nUtil * WEIGHTS.utilization +
      compliance * WEIGHTS.compliance;

    const costFactor = Math.max(costPerTask / t.costPerTaskUsd, 0.1);
    const efficiency = round((successRate * Math.max(qualityScore, 0.5) * Math.max(utilization, 0.05)) / costFactor, 4);

    return {
      agentId, division: a.division, squad: a.squad, rank: a.rank, state: a.state,
      tasks: m.tasks, ok: m.ok, failed: m.failed, rejected: m.rejected,
      successRate: round(successRate, 4),
      qualityScore: round(qualityScore, 4),
      avgMs: m.avgMs, p95LatencyMs: p95,
      tokensIn: m.tokensIn, tokensOut: m.tokensOut,
      costUsd: round(m.costUsd, 6), costPerTaskUsd: round(costPerTask, 6),
      utilization: round(utilization, 4),
      violations: m.violations, blocks: m.blocks, compliance: round(compliance, 4),
      kpiScore: round(kpiScore, 4),
      efficiency,
      belowTarget: kpiScore < cfg.KPI.coachThreshold,
      targets: t,
    };
  }

  all() {
    return [...this.byAgent.keys()].map((id) => this.agent(id));
  }

  /** Gộp theo một trường bất kỳ: division | squad | rank */
  groupBy(field) {
    const out = new Map();
    for (const s of this.all()) {
      const key = s[field];
      const g = out.get(key) || {
        key, agents: 0, tasks: 0, ok: 0, failed: 0, violations: 0,
        costUsd: 0, kpiSum: 0, effSum: 0, utilSum: 0, qualitySum: 0, qualityN: 0, p95s: [],
      };
      g.agents++; g.tasks += s.tasks; g.ok += s.ok; g.failed += s.failed;
      g.violations += s.violations; g.costUsd += s.costUsd;
      g.kpiSum += s.kpiScore; g.effSum += s.efficiency; g.utilSum += s.utilization;
      if (s.qualityScore) { g.qualitySum += s.qualityScore; g.qualityN++; }
      if (s.p95LatencyMs) g.p95s.push(s.p95LatencyMs);
      out.set(key, g);
    }
    return [...out.values()].map((g) => ({
      [field]: g.key,
      agents: g.agents,
      tasks: g.tasks,
      successRate: g.tasks ? round(g.ok / g.tasks, 4) : 0,
      qualityScore: g.qualityN ? round(g.qualitySum / g.qualityN, 4) : 0,
      p95LatencyMs: percentile(g.p95s, 95),
      costUsd: round(g.costUsd, 6),
      utilization: round(g.utilSum / g.agents, 4),
      violations: g.violations,
      kpiScore: round(g.kpiSum / g.agents, 4),
      efficiency: round(g.effSum / g.agents, 4),
    })).sort((a, b) => b.kpiScore - a.kpiScore);
  }

  system() {
    const all = this.all();
    const tasks = all.reduce((s, x) => s + x.tasks, 0);
    const ok = all.reduce((s, x) => s + x.ok, 0);
    const cost = all.reduce((s, x) => s + x.costUsd, 0);
    const active = all.filter((x) => x.tasks > 0);
    const below = all.filter((x) => x.belowTarget && x.tasks >= 10);
    const p95s = all.map((x) => x.p95LatencyMs).filter(Boolean);

    return {
      agents: all.length,
      activeAgents: active.length,
      tasks, ok, failed: tasks - ok,
      successRate: tasks ? round(ok / tasks, 4) : 0,
      qualityScore: active.length ? round(active.reduce((s, x) => s + x.qualityScore, 0) / active.length, 4) : 0,
      p95LatencyMs: percentile(p95s, 95),
      costUsd: round(cost, 6),
      costPerTaskUsd: tasks ? round(cost / tasks, 6) : 0,
      utilization: all.length ? round(all.reduce((s, x) => s + x.utilization, 0) / all.length, 4) : 0,
      violations: all.reduce((s, x) => s + x.violations, 0),
      kpiScore: all.length ? round(all.reduce((s, x) => s + x.kpiScore, 0) / all.length, 4) : 0,
      efficiency: all.length ? round(all.reduce((s, x) => s + x.efficiency, 0) / all.length, 4) : 0,
      belowTarget: below.length,
      belowTargetIds: below.slice(0, 20).map((x) => x.agentId),
      thresholds: cfg.KPI,
      uptimeSec: Math.round((Date.now() - this.startedAt) / 1000),
    };
  }

  leaderboard(limit = 20, field = 'kpiScore') {
    return this.all()
      .filter((x) => x.tasks > 0)
      .sort((a, b) => b[field] - a[field])
      .slice(0, limit)
      .map((x) => ({
        agentId: x.agentId, division: x.division, squad: x.squad, rank: x.rank,
        tasks: x.tasks, kpiScore: x.kpiScore, efficiency: x.efficiency,
        successRate: x.successRate, qualityScore: x.qualityScore, utilization: x.utilization,
      }));
  }
}

module.exports = KPITracker;
module.exports.WEIGHTS = WEIGHTS;
