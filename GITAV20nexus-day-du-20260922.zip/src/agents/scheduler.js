'use strict';
/**
 * SCHEDULER — phân công việc cho 500 agent.
 *
 *  Chọn agent theo thứ tự tường minh (điều A13, A17 — đúng chuyên môn, không trùng lệnh):
 *   1. Khối phụ trách loại task  (TASK_ROUTING, không đoán)
 *   2. Cấp bậc phù hợp           (task.rank hoặc suy ra từ loại việc)
 *   3. Còn chỗ trống công suất
 *   4. Điểm ưu tiên = 0.5·KPI + 0.3·(chỗ trống) + 0.2·(ít việc nhất)
 *
 *  Chế độ teamwork (§4.4): Planner chia việc → nhiều Worker chạy song song
 *                          → Critic chấm → gộp kết quả.
 */

const bus = require('../kernel/eventbus');
const L = require('../logger');
const { TASK_ROUTING, DIVISIONS } = require('./taxonomy');
const { round, id: newId } = require('../utils');
const AgentRuntime = require('./runtime');

/** Cấp bậc mặc định cho từng loại việc. */
const RANK_FOR_TASK = {
  review: 'CRITIC',
  audit: 'GUARDIAN',
  enforce: 'GUARDIAN',
  research: 'RESEARCHER',
  plan: 'PLANNER',
  coach: 'COACH',
};

const SPREAD_BAND = 12;      // rải tải trong nhóm 12 agent dẫn đầu
const MAX_FAILOVER_TRIES = 16;

class Scheduler {
  constructor({ agents, runtime, kpi, capacity, queue, shield = null }) {
    this._cursor = new Map();   // con trỏ xoay vòng theo (khối|cấp bậc)
    this.shield = shield;
    this.agents = agents;
    this.runtime = runtime;
    this.kpi = kpi;
    this.capacity = capacity;
    this.queue = queue;
    this.byDivision = new Map();
    for (const a of agents) {
      if (!this.byDivision.has(a.division)) this.byDivision.set(a.division, []);
      this.byDivision.get(a.division).push(a);
    }
    this.inflight = new Map(); // dedupeKey -> hết hạn lúc (A17: không trùng lệnh)
    this.dedupeWindowMs = 5000;
    this.stats = { dispatched: 0, teamRuns: 0, rejectedDuplicate: 0, noAgent: 0, reviewed: 0, rejectedByCritic: 0, failover: 0 };
  }

  divisionFor(taskType) {
    return TASK_ROUTING[taskType] || 'VIETNAMESE'; // mặc định tường minh, không ngẫu nhiên
  }

  /** Chọn agent tốt nhất cho một task. estTokens giúp loại sớm agent đã cạn hạn mức. */
  select(taskType, { rank = null, squad = null, exclude = [], estTokens = 800 } = {}) {
    const division = this.divisionFor(taskType);
    const wantRank = rank || RANK_FOR_TASK[taskType] || 'WORKER';
    let pool = (this.byDivision.get(division) || []).filter(
      (a) => a.rank === wantRank && !exclude.includes(a.id) && a.state !== 'SUSPENDED'
    );
    if (squad) pool = pool.filter((a) => a.squad === squad || a.squadName === squad);
    if (!pool.length) {
      // Dự phòng tường minh: WORKER của cùng khối
      pool = (this.byDivision.get(division) || []).filter(
        (a) => a.rank === 'WORKER' && !exclude.includes(a.id) && a.state !== 'SUSPENDED'
      );
    }
    if (!pool.length) return null;

    // Đếm lý do bị loại, để khi không còn ai thì nói được VÌ SAO —
    // "không có agent nào" là câu trả lời vô dụng lúc đang sự cố.
    const why = { suspended: 0, quarantined: 0, noSlot: 0, noTokens: 0 };
    const eligible = pool.filter((a) => {
      if (this.shield && !this.shield.isEligible(a.id)) { why.quarantined++; return false; }
      return true;
    });
    const affordable = eligible.filter((a) => {
      if (!this.capacity.canAfford(a.id, estTokens)) {
        if (this.capacity.freeSlots(a.id) <= 0) why.noSlot++; else why.noTokens++;
        return false;
      }
      return true;
    });
    this._lastReject = { poolSize: pool.length, ...why };

    const scored = affordable
      .map((a) => {
        const free = this.capacity.freeSlots(a.id);
        const snap = this.kpi.agent(a.id);
        const loadScore = free / Math.max(a.capacity.maxConcurrent, 1);
        const idleScore = 1 / (1 + snap.tasks);
        return { agent: a, free, score: 0.5 * snap.kpiScore + 0.3 * loadScore + 0.2 * idleScore };
      });

    if (!scored.length) return null;
    scored.sort((a, b) => b.score - a.score || a.agent.id.localeCompare(b.agent.id));

    // Vì sao không lấy thẳng người điểm cao nhất:
    // hàng trăm yêu cầu đến CÙNG MỘT LÚC đều đọc trạng thái y như nhau (chưa ai
    // kịp chạy), nên tất cả sẽ chọn đúng một agent, agent đó đầy ngay, rồi toàn
    // bộ phần còn lại bị từ chối — trong khi 499 agent kia đang rảnh.
    // Cách chữa: lấy nhóm dẫn đầu rồi xoay vòng trong nhóm đó. Vẫn tất định
    // (xoay theo bộ đếm, không phải ngẫu nhiên) nhưng tải được rải ra.
    const band = scored.slice(0, Math.min(SPREAD_BAND, scored.length));
    const key = `${division}|${wantRank}`;
    const cur = this._cursor.get(key) || 0;
    this._cursor.set(key, (cur + 1) % Math.max(band.length, 1));
    return band[cur % band.length].agent;
  }

  /**
   * Chạy task, tự đổi agent khi agent được chọn chạm trần công suất.
   * Với 500 agent, một cá nhân hết hạn mức KHÔNG được phép làm hỏng cả công việc.
   */
  async _runWithFailover(taskType, task, { rank = null, squad = null, maxTries = MAX_FAILOVER_TRIES } = {}) {
    const estTokens = AgentRuntime.estimateTokens(task);
    const tried = [];
    let last = { ok: false, error: 'NO_AGENT_AVAILABLE', division: this.divisionFor(taskType) };
    for (let i = 0; i < maxTries; i++) {
      const agent = this.select(taskType, { rank, squad, exclude: tried, estTokens });
      if (!agent) break;   // lý do nằm ở this._lastReject, trả ra ở dưới
      tried.push(agent.id);
      this.stats.dispatched++;
      const r = await this.runtime.run(agent.id, task);
      if (r.ok || r.error !== 'CAPACITY_LIMIT') return r;
      this.stats.failover++;
      last = r;
    }
    if (!tried.length) {
      this.stats.noAgent++;
      const w = this._lastReject || {};
      // Nói rõ vì sao không có ai: hết chỗ, hết hạn mức token, hay đang bị cách ly.
      const reason = w.noTokens > 0 && w.noTokens >= w.noSlot ? 'hết hạn mức token trong phút này'
        : w.noSlot > 0 ? 'tất cả agent đang bận hết chỗ'
          : w.quarantined > 0 ? 'agent phù hợp đang bị cách ly'
            : 'không có agent nào thuộc khối và cấp bậc cần thiết';
      return {
        ...last,
        reason,
        breakdown: w,
        hint: w.noTokens > 0
          ? 'Tăng AGENT_TOKENS_PER_MIN hoặc chờ sang phút sau. Đây là lớp bảo vệ quota, không phải lỗi.'
          : w.noSlot > 0
            ? 'Tăng AGENT_GLOBAL_CONCURRENCY hoặc giảm nhịp gửi việc.'
            : null,
        triedAgents: tried,
      };
    }
    return { ...last, triedAgents: tried };
  }

  /** Phân công một task đơn. */
  async dispatch(task) {
    const key = task.dedupeKey || null;
    if (key) {
      const now = Date.now();
      for (const [k, exp] of this.inflight) if (exp < now) this.inflight.delete(k);
      if (this.inflight.has(key)) {
        this.stats.rejectedDuplicate++;
        return { ok: false, error: 'DUPLICATE_TASK', dedupeKey: key };
      }
      this.inflight.set(key, now + this.dedupeWindowMs);
    }

    try {
      return await this._runWithFailover(task.type, task, { rank: task.rank, squad: task.squad });
    } finally {
      // Giữ khoá thêm hết cửa sổ dedupe; dọn bằng quét hết hạn ở lần gọi sau.
    }
  }

  /**
   * TEAMWORK: Planner chia việc → Worker chạy song song → Critic chấm → gộp.
   * @param {object} job {type, input, subtasks?, workers?, review?}
   */
  async team(job) {
    const runId = newId('TEAM');
    const t0 = Date.now();
    this.stats.teamRuns++;
    const division = this.divisionFor(job.type);
    const trail = [];

    // 1) PLANNER chia việc
    let subtasks = job.subtasks;
    const planner = this.select(job.type, { rank: 'PLANNER' });
    if (!subtasks && planner) {
      const p = await this.runtime.run(planner.id, {
        type: job.type,
        input:
          `Chia yêu cầu sau thành ${job.workers || 3} tiểu tác vụ độc lập, mỗi dòng một tiểu tác vụ, ` +
          `không đánh số, không giải thích:\n\n${job.input}`,
        maxTokens: 400, allowCache: false,
      });
      trail.push({ phase: 'plan', agentId: planner.id, ok: p.ok, ms: p.ms, error: p.error, detail: p.detail });
      if (p.ok) {
        subtasks = String(p.output).split('\n').map((s) => s.replace(/^[-*\d.)\s]+/, '').trim())
          .filter((s) => s.length > 8).slice(0, job.workers || 3);
      }
    }
    if (!subtasks || !subtasks.length) subtasks = [job.input];

    // 2) WORKER chạy song song, mỗi tiểu tác vụ một agent khác nhau
    const used = [];
    const workerJobs = subtasks.map((st) => {
      const a = this.select(job.type, { rank: 'WORKER', exclude: used });
      if (a) used.push(a.id);
      return { agent: a, input: st };
    });

    const results = await Promise.all(workerJobs.map(async (w) => {
      if (!w.agent) return { ok: false, error: 'NO_AGENT_AVAILABLE' };
      const task = { type: job.type, input: w.input, maxTokens: job.maxTokens || 900 };
      let r = await this.runtime.run(w.agent.id, task);
      if (!r.ok && r.error === 'CAPACITY_LIMIT') {
        this.stats.failover++;
        r = await this._runWithFailover(job.type, task, { rank: 'WORKER' });
      }
      trail.push({ phase: 'work', agentId: r.agentId || w.agent.id, ok: r.ok, ms: r.ms, error: r.error, detail: r.detail });
      return r;
    }));

    const good = results.filter((r) => r.ok);
    if (!good.length) {
      return { ok: false, runId, error: 'ALL_WORKERS_FAILED', division, trail, ms: Date.now() - t0 };
    }

    const merged = good.map((r, i) => `### Phần ${i + 1}\n${r.output}`).join('\n\n');

    // 3) CRITIC chấm chất lượng, có quyền phủ quyết (A23)
    let review = null;
    if (job.review !== false) {
      const critic = this.select(job.type, { rank: 'CRITIC' });
      if (critic) {
        const c = await this.runtime.run(critic.id, {
          type: job.type, allowCache: false, maxTokens: 400,
          input:
            `Chấm chất lượng bản tổng hợp dưới đây theo thang 0.0–1.0 và nêu tối đa 3 lỗi.\n` +
            `Dòng đầu tiên PHẢI có dạng "SCORE: 0.xx".\n\n${merged.slice(0, 4000)}`,
        });
        trail.push({ phase: 'review', agentId: critic.id, ok: c.ok, ms: c.ms, error: c.error, detail: c.detail });
        this.stats.reviewed++;
        if (c.ok) {
          const m = String(c.output).match(/SCORE:\s*([01](?:\.\d+)?)/i);
          const score = m ? Math.min(1, parseFloat(m[1])) : 0.8;
          review = { criticId: critic.id, score: round(score, 3), notes: c.output };
          if (score < 0.6) {
            this.stats.rejectedByCritic++;
            bus.safeEmit('critic:rejected', { runId, score });
            return {
              ok: false, runId, error: 'REJECTED_BY_CRITIC', review, division,
              output: merged, trail, ms: Date.now() - t0,
            };
          }
          // Cập nhật lại điểm chất lượng cho các worker theo đánh giá của Critic
          for (const r of good) this.kpi.record(r.agentId, { ok: true, ms: 0, quality: score });
        }
      }
    }

    return {
      ok: true, runId, division,
      subtasks: subtasks.length,
      workers: good.length,
      planner: planner ? planner.id : null,
      output: merged,
      review,
      costUsd: round(good.reduce((s, r) => s + (r.costUsd || 0), 0), 6),
      tokens: good.reduce((s, r) => s + (r.tokensIn || 0) + (r.tokensOut || 0), 0),
      trail,
      ms: Date.now() - t0,
    };
  }

  /** Đăng ký worker hàng đợi để chạy task bất đồng bộ. */
  attachQueue() {
    if (!this.queue) return this;
    this.queue.registerWorker('agent:task', async (job) => {
      const r = await this.dispatch(job.data);
      if (!r.ok && r.error !== 'DUPLICATE_TASK') throw new Error(r.error);
      bus.safeEmit('agent:queued_done', { jobId: job.id, ok: r.ok });
    }, { concurrency: 12 });
    this.queue.registerWorker('agent:team', async (job) => {
      const r = await this.team(job.data);
      if (!r.ok) throw new Error(r.error);
    }, { concurrency: 4 });
    return this;
  }

  status() {
    return {
      ...this.stats,
      divisions: [...this.byDivision.keys()].map((d) => ({
        division: d, name: DIVISIONS[d].name, agents: this.byDivision.get(d).length,
      })),
      inflight: this.inflight.size,
    };
  }
}

module.exports = Scheduler;
module.exports.RANK_FOR_TASK = RANK_FOR_TASK;
