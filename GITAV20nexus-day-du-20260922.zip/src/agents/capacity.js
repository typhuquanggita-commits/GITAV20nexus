'use strict';
/**
 * CÔNG SUẤT — bộ điều tiết ba tầng: agent → khối → toàn hệ.
 * Ngăn 500 agent cùng gọi LLM một lúc làm vỡ rate-limit nhà cung cấp và ngân sách.
 */

const cfg = require('../config');
const { DIVISIONS } = require('./taxonomy');
const { round } = require('../utils');

class CapacityGovernor {
  constructor({ agents }) {
    this.agents = new Map(agents.map((a) => [a.id, a]));

    // Tầng agent
    this.running = new Map(agents.map((a) => [a.id, 0]));
    this.tokenWindow = new Map(agents.map((a) => [a.id, []])); // [{t, n}]

    // Tầng khối: hạn mức đồng thời = 40% tổng maxConcurrent của khối (chống một khối chiếm hết)
    this.divLimit = Object.create(null);
    this.divRunning = Object.create(null);
    for (const d of Object.keys(DIVISIONS)) { this.divLimit[d] = 0; this.divRunning[d] = 0; }
    for (const a of agents) this.divLimit[a.division] += a.capacity.maxConcurrent;
    for (const d of Object.keys(this.divLimit)) this.divLimit[d] = Math.max(1, Math.floor(this.divLimit[d] * 0.4));

    // Tầng hệ
    this.globalLimit = cfg.AGENT_GLOBAL_CONCURRENCY;
    this.globalRunning = 0;
    this.globalTokenWindow = [];
    this.globalTokensPerMin = cfg.AGENT_TOKENS_PER_MIN;

    this.stats = { admitted: 0, deniedAgent: 0, deniedDivision: 0, deniedGlobal: 0, deniedTokens: 0, peakGlobal: 0 };

    this._gc = setInterval(() => this._sweep(), 15_000);
    if (this._gc.unref) this._gc.unref();
  }

  _sweep() {
    const cutoff = Date.now() - 60_000;
    for (const [id, w] of this.tokenWindow) {
      const kept = w.filter((x) => x.t > cutoff);
      if (kept.length) this.tokenWindow.set(id, kept); else this.tokenWindow.set(id, []);
    }
    this.globalTokenWindow = this.globalTokenWindow.filter((x) => x.t > cutoff);
  }

  _tokensUsed(windowArr) {
    const cutoff = Date.now() - 60_000;
    return windowArr.filter((x) => x.t > cutoff).reduce((s, x) => s + x.n, 0);
  }

  /** Xin chỗ chạy. Trả {ok:false, reason} nếu chạm trần ở bất kỳ tầng nào. */
  admit(agentId, estimatedTokens = 500) {
    const a = this.agents.get(agentId);
    if (!a) return { ok: false, reason: 'UNKNOWN_AGENT' };

    if (this.globalRunning >= this.globalLimit) {
      this.stats.deniedGlobal++;
      return { ok: false, reason: 'GLOBAL_CONCURRENCY', limit: this.globalLimit };
    }
    if (this.divRunning[a.division] >= this.divLimit[a.division]) {
      this.stats.deniedDivision++;
      return { ok: false, reason: 'DIVISION_CONCURRENCY', division: a.division, limit: this.divLimit[a.division] };
    }
    if ((this.running.get(agentId) || 0) >= a.capacity.maxConcurrent) {
      this.stats.deniedAgent++;
      return { ok: false, reason: 'AGENT_CONCURRENCY', limit: a.capacity.maxConcurrent };
    }

    const agentTokens = this._tokensUsed(this.tokenWindow.get(agentId) || []);
    if (agentTokens + estimatedTokens > a.capacity.tokensPerMin) {
      this.stats.deniedTokens++;
      return { ok: false, reason: 'AGENT_TOKEN_BUDGET', used: agentTokens, limit: a.capacity.tokensPerMin };
    }
    const globalTokens = this._tokensUsed(this.globalTokenWindow);
    if (globalTokens + estimatedTokens > this.globalTokensPerMin) {
      this.stats.deniedTokens++;
      return { ok: false, reason: 'GLOBAL_TOKEN_BUDGET', used: globalTokens, limit: this.globalTokensPerMin };
    }

    this.running.set(agentId, (this.running.get(agentId) || 0) + 1);
    this.divRunning[a.division]++;
    this.globalRunning++;
    if (this.globalRunning > this.stats.peakGlobal) this.stats.peakGlobal = this.globalRunning;
    this.stats.admitted++;
    return { ok: true };
  }

  /** Trả chỗ và ghi nhận token đã tiêu thật. */
  release(agentId, actualTokens = 0) {
    const a = this.agents.get(agentId);
    if (!a) return;
    this.running.set(agentId, Math.max(0, (this.running.get(agentId) || 1) - 1));
    this.divRunning[a.division] = Math.max(0, this.divRunning[a.division] - 1);
    this.globalRunning = Math.max(0, this.globalRunning - 1);
    if (actualTokens > 0) {
      const t = Date.now();
      this.tokenWindow.get(agentId).push({ t, n: actualTokens });
      this.globalTokenWindow.push({ t, n: actualTokens });
    }
  }

  /**
   * Kiểm tra khả năng nhận việc mà KHÔNG chiếm chỗ — dùng cho bước chọn agent.
   * Nhờ đó scheduler loại sớm agent đã cạn hạn mức, thay vì chọn rồi mới bị từ chối.
   */
  canAfford(agentId, estimatedTokens = 500) {
    const a = this.agents.get(agentId);
    if (!a) return false;
    if (this.globalRunning >= this.globalLimit) return false;
    if (this.divRunning[a.division] >= this.divLimit[a.division]) return false;
    if ((this.running.get(agentId) || 0) >= a.capacity.maxConcurrent) return false;
    if (this._tokensUsed(this.tokenWindow.get(agentId) || []) + estimatedTokens > a.capacity.tokensPerMin) return false;
    if (this._tokensUsed(this.globalTokenWindow) + estimatedTokens > this.globalTokensPerMin) return false;
    return true;
  }

  /** Agent nào đang rảnh nhất trong một tập cho trước (dùng để cân bằng tải). */
  freeSlots(agentId) {
    const a = this.agents.get(agentId);
    if (!a) return 0;
    return Math.max(0, a.capacity.maxConcurrent - (this.running.get(agentId) || 0));
  }

  stop() { clearInterval(this._gc); }

  /** Đặt lại mốc đỉnh — dùng khi muốn đo riêng một đợt tải, không lẫn đợt trước. */
  /**
   * Xoá cửa sổ đếm token. Chỉ dùng cho kiểm thử và bảo trì — gọi lúc đang chạy
   * thật là tự tháo lớp bảo vệ quota của mình.
   */
  clearTokenWindow() {
    const before = this._tokensUsed(this.globalTokenWindow);
    for (const id of this.tokenWindow.keys()) this.tokenWindow.set(id, []);
    this.globalTokenWindow = [];
    return { ok: true, clearedTokens: before };
  }

  resetPeak() {
    const was = this.stats.peakGlobal;
    this.stats.peakGlobal = this.globalRunning;
    return { ok: true, previousPeak: was };
  }

  status() {
    const byDivision = {};
    for (const d of Object.keys(this.divLimit)) {
      byDivision[d] = {
        running: this.divRunning[d],
        limit: this.divLimit[d],
        utilization: round(this.divRunning[d] / this.divLimit[d], 3),
      };
    }
    const gTokens = this._tokensUsed(this.globalTokenWindow);
    return {
      global: {
        running: this.globalRunning,
        limit: this.globalLimit,
        utilization: round(this.globalRunning / this.globalLimit, 3),
        tokensLastMin: gTokens,
        tokensPerMinLimit: this.globalTokensPerMin,
        tokenUtilization: round(gTokens / this.globalTokensPerMin, 3),
        peak: this.stats.peakGlobal,
      },
      byDivision,
      stats: { ...this.stats },
    };
  }
}

module.exports = CapacityGovernor;
