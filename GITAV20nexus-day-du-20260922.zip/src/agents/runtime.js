'use strict';
/**
 * AGENT RUNTIME — vòng đời thực thi một tác vụ của một agent.
 *
 *  CREATE → BOOT → WORK → KPI TRACK → COACH → APPLY → ROLLBACK  (đúng §4.3 tài liệu gốc)
 *
 *  Mỗi lượt chạy đi qua đủ 9 chốt kiểm soát, không bỏ chốt nào (điều A31):
 *   1 quyền hạn  2 Hiến pháp  3 guardrails  4 HEART vào  5 công suất
 *   6 safe-meta-prompt  7 LLM  8 HEART ra  9 KPI + audit
 */

const bus = require('../kernel/eventbus');
const L = require('../logger');
const { round, id: newId } = require('../utils');
const { TASK_ROUTING } = require('./taxonomy');

const STATES = { IDLE: 'IDLE', WORKING: 'WORKING', ERROR: 'ERROR', COACHING: 'COACHING', SUSPENDED: 'SUSPENDED' };

class AgentRuntime {
  constructor({ agents, kpi, capacity, llm, adaptiveRouter, constitution, heart, guardrails, safePrompt, cache, audit, otel, shield = null }) {
    this.shield = shield;
    this.index = new Map(agents.map((a) => [a.id, a]));
    this.agents = agents;
    this.kpi = kpi;
    this.capacity = capacity;
    this.llm = llm;
    this.router = adaptiveRouter;
    this.constitution = constitution;
    this.heart = heart;
    this.guardrails = guardrails;
    this.safePrompt = safePrompt;
    this.cache = cache;
    this.audit = audit;
    this.otel = otel;
    this.consecutiveFailures = new Map(agents.map((a) => [a.id, 0]));
    this.stats = { executed: 0, ok: 0, failed: 0, blocked: 0, cached: 0, suspended: 0 };
  }

  get(agentId) { return this.index.get(agentId) || null; }

  /** Kiểm tra quyền: agent có được làm loại task này không (điều A05, A13). */
  can(agent, permission) {
    for (const p of agent.permissions) {
      if (p === permission) return true;
      if (p.endsWith('.*') && permission.startsWith(p.slice(0, -1))) return true;
      if (p.includes(':') && permission.includes(':')) {
        const [pk, pv] = p.split(':');
        const [nk, nv] = permission.split(':');
        if (pk === nk) {
          const order = { fast: 1, balanced: 2, strong: 3 };
          if ((order[nv] || 9) <= (order[pv] || 0)) return true;
        }
      }
    }
    return false;
  }

  _setState(agent, state) {
    agent.state = state;
    if (state === STATES.SUSPENDED) this.stats.suspended++;
  }

  /**
   * @param {string} agentId
   * @param {object} task {type, input, priority, requester, allowCache, maxTokens, temperature}
   */
  async run(agentId, task) {
    const agent = this.get(agentId);
    if (!agent) return { ok: false, error: 'AGENT_NOT_FOUND', agentId };

    const t0 = Date.now();
    const runId = newId('AT');
    const trace = this.otel ? this.otel.startTrace('agent.run', { agentId, taskType: task.type }) : null;

    if (agent.state === STATES.SUSPENDED && Date.now() < agent.suspendedUntil) {
      return { ok: false, error: 'AGENT_SUSPENDED', agentId, until: agent.suspendedUntil };
    }
    if (agent.state === STATES.SUSPENDED) this._setState(agent, STATES.IDLE);

    const fail = async (reason, detail, opts = {}) => {
      const ms = Date.now() - t0;
      this.stats.failed++;
      if (opts.blocked) this.stats.blocked++;
      this._setState(agent, STATES.IDLE);
      this.kpi.record(agentId, { ok: false, ms, violation: !!opts.violation, blocked: !!opts.blocked });
      if (this.audit) {
        await this.audit.record({
          actor: agentId, actorRole: agent.rank, action: `agent.${task.type || 'task'}`,
          target: task.requester || null, verdict: opts.blocked ? 'BLOCK' : 'DENY',
          severity: opts.severity || 1, detail: { reason, detail },
        });
      }
      if (trace) trace.end({ error: reason });
      bus.safeEmit('agent:task_failed', { agentId, runId, reason });
      return { ok: false, runId, agentId, error: reason, detail, ms };
    };

    // ── CHỐT 1: quyền hạn ──────────────────────────────────────────────
    if (!this.can(agent, 'task.execute')) return fail('PERMISSION_DENIED', 'thiếu task.execute', { severity: 3, blocked: true });
    const expectedDivision = TASK_ROUTING[task.type];
    const specialtyMatch = !expectedDivision || expectedDivision === agent.division;
    const scopeOk = !task.scope || this.can(agent, task.scope);
    if (!scopeOk) return fail('SCOPE_DENIED', task.scope, { severity: 3, blocked: true });

    // ── CHỐT 2: Hiến pháp ──────────────────────────────────────────────
    const verdict = this.constitution.validate('agent_task', {
      specialtyMatch,
      duplicate: !!task.duplicate,
      capability: 1,
      permitted: true,
      consecutiveFailures: this.consecutiveFailures.get(agentId) || 0,
    });
    if (!verdict.ok) {
      return fail('CONSTITUTION_BLOCK', verdict.violations, { severity: 3, blocked: true, violation: true });
    }
    if (verdict.sanction === 'SUSPEND') {
      agent.suspendedUntil = Date.now() + 60_000;
      this._setState(agent, STATES.SUSPENDED);
      return fail('CONSTITUTION_SUSPEND', verdict.violations, { severity: 2, violation: true });
    }

    // ── CHỐT 3: guardrails ─────────────────────────────────────────────
    const g = this.guardrails.checkInput(task.input, { allowPII: false });
    if (!g.ok) return fail('GUARDRAIL_BLOCK', g.reason + (g.detail ? `:${g.detail}` : ''), { severity: 2, blocked: true });

    // ── CHỐT 4: HEART đầu vào ──────────────────────────────────────────
    const hIn = this.heart.validateInput(task.input);
    if (!hIn.ok) return fail('HEART_BLOCK', hIn.axiom, { severity: 3, blocked: true, violation: true });

    // ── Cache: trả sớm nếu trúng ───────────────────────────────────────
    if (task.allowCache !== false && this.cache) {
      const hit = await this.cache.get(task.input);
      if (hit) {
        const ms = Date.now() - t0;
        this.stats.cached++;
        this.stats.executed++;
        this.stats.ok++;
        this.kpi.record(agentId, { ok: true, ms, quality: 0.85, costUsd: 0, tokensIn: 0, tokensOut: 0 });
        if (trace) trace.end({ cached: true });
        return { ok: true, runId, agentId, output: hit.value, cached: true, category: hit.category, ms };
      }
    }

    // ── CHỐT 5: công suất ──────────────────────────────────────────────
    const est = AgentRuntime.estimateTokens(task);
    const adm = this.capacity.admit(agentId, est);
    if (!adm.ok) return fail('CAPACITY_LIMIT', adm.reason, { severity: 1 });

    this._setState(agent, STATES.WORKING);
    if (this.shield) this.shield.markInflight(agentId);
    let actualTokens = 0;

    try {
      // ── CHỐT 6: safe meta-prompt ─────────────────────────────────────
      const sp = this.safePrompt.build(task.input, { retrieved: task.retrieved });
      if (!sp.ok) {
        this.capacity.release(agentId, 0);
        return fail('INJECTION_DETECTED', sp.pattern, { severity: 3, blocked: true, violation: true });
      }

      // ── CHỐT 7: gọi LLM (bậc theo cấp bậc & khối, có bandit tinh chỉnh) ─
      const span = trace ? trace.startSpan('gen_ai.chat', { agentId, tier: agent.tier }) : null;
      let provider = null;
      if (this.router) {
        const route = await this.router.route(task.input);
        provider = route.arm.provider;
        task._armId = route.arm.id;
        task._armCost = route.arm.cost;
      }

      const r = await this.llm.call({
        task: agent.specialty,
        prompt: sp.prompt,
        system: agent.systemPrompt,
        tier: agent.tier,
        provider,
        temperature: task.temperature ?? 0.4,
        maxTokens: task.maxTokens || 1024,
      });

      if (span) span.end({ provider: r.provider, tokensIn: r.tokensIn, tokensOut: r.tokensOut, error: r.ok ? undefined : r.error });

      if (!r.ok) {
        this.capacity.release(agentId, 0);
        const n = (this.consecutiveFailures.get(agentId) || 0) + 1;
        this.consecutiveFailures.set(agentId, n);
        if (n >= 3) { agent.suspendedUntil = Date.now() + 30_000; this._setState(agent, STATES.SUSPENDED); }
        else this._setState(agent, STATES.ERROR);
        return fail('LLM_FAILED', r.error, { severity: 1 });
      }

      actualTokens = (r.tokensIn || 0) + (r.tokensOut || 0);

      // ── CHỐT 8: HEART đầu ra (ranh giới NES) ─────────────────────────
      let output = r.text;
      let nesBreach = null;
      const hOut = this.heart.validateOutput(output);
      if (!hOut.ok) {
        nesBreach = hOut.nesBreach;
        output = hOut.sanitized;
      }

      // ── CHỐT 9: KPI, cache, bandit, audit ────────────────────────────
      const ms = Date.now() - t0;
      this.consecutiveFailures.set(agentId, 0);
      this.capacity.release(agentId, actualTokens);
      this._setState(agent, STATES.IDLE);
      this.stats.executed++;
      this.stats.ok++;

      const quality = task.quality ?? (nesBreach ? 0.6 : 0.85);
      this.kpi.record(agentId, {
        ok: true, ms, quality,
        tokensIn: r.tokensIn, tokensOut: r.tokensOut, costUsd: r.costUsd,
        violation: !!nesBreach,
      });

      if (this.router && task._armId) {
        await this.router.updateReward(task._armId, { quality, cost: task._armCost, latencyMs: ms }).catch(() => {});
      }
      if (task.allowCache !== false && this.cache) {
        await this.cache.set(task.input, output).catch(() => {});
      }
      if (this.audit) {
        await this.audit.record({
          actor: agentId, actorRole: agent.rank, action: `agent.${task.type || 'task'}`,
          target: task.requester || null, verdict: 'ALLOW', severity: nesBreach ? 1 : 0,
          detail: { ms, provider: r.provider, tokens: actualTokens, nesBreach },
        });
      }
      if (trace) trace.end({ ok: true, provider: r.provider });
      bus.safeEmit('agent:task_done', { agentId, runId, ms, provider: r.provider });

      return {
        ok: true, runId, agentId,
        division: agent.division, squad: agent.squad, rank: agent.rank,
        output, provider: r.provider, model: r.model, tier: agent.tier,
        tokensIn: r.tokensIn, tokensOut: r.tokensOut, costUsd: round(r.costUsd, 6),
        nesBreach, fellBack: r.fellBack, ms,
      };
    } catch (e) {
      this.capacity.release(agentId, actualTokens);
      this._setState(agent, STATES.ERROR);
      return fail('RUNTIME_ERROR', e.message, { severity: 2 });
    }
  }

  /**
   * Ước lượng token cho một task: phần nhập (prompt hệ thống ~350 token + đầu vào)
   * cộng 40% trần đầu ra. Lấy nguyên trần maxTokens sẽ ước lượng thừa gấp đôi và
   * khoá agent một cách vô cớ.
   */
  static estimateTokens(task) {
    const input = Math.ceil(String(task.input || '').length / 4) + 350;
    const output = Math.ceil((task.maxTokens || 800) * 0.4);
    return input + output;
  }

  /** COACH: đề xuất prompt mới cho agent dưới ngưỡng KPI (điều A18, A26). */
  async coach(agentId) {
    const agent = this.get(agentId);
    if (!agent) return { ok: false, error: 'AGENT_NOT_FOUND' };
    const snap = this.kpi.agent(agentId);
    if (!snap.belowTarget) return { ok: false, error: 'KPI_OK', kpiScore: snap.kpiScore };

    this._setState(agent, STATES.COACHING);
    const r = await this.llm.call({
      task: 'complex_reasoning',
      system: 'Bạn là chuyên gia prompt engineering. Chỉ trả về system prompt mới, không giải thích.',
      prompt:
        `Agent "${agent.id}" (${agent.rankName}, ${agent.divisionName}) đang dưới chỉ tiêu KPI.\n` +
        `KPI: thành công ${snap.successRate}, chất lượng ${snap.qualityScore}, p95 ${snap.p95LatencyMs}ms, ` +
        `chi phí/task $${snap.costPerTaskUsd}, vi phạm ${snap.violations}.\n\n` +
        `System prompt hiện tại:\n"""${agent.systemPrompt}"""\n\n` +
        `Viết lại system prompt để cải thiện các chỉ số trên, giữ nguyên chuyên môn và ràng buộc LaTeX.`,
      temperature: 0.4, maxTokens: 600,
    });
    this._setState(agent, STATES.IDLE);
    if (!r.ok) return { ok: false, error: r.error };

    const proposal = {
      id: newId('COACH'), agentId, at: Date.now(),
      kpiBefore: snap.kpiScore,
      currentPrompt: agent.systemPrompt,
      proposedPrompt: r.text.trim(),
      status: 'PENDING',
    };
    bus.safeEmit('coach:proposal', { agentId, proposalId: proposal.id });
    return { ok: true, proposal };
  }

  /** APPLY / ROLLBACK — con người hoặc Planner duyệt, có thể hoàn tác. */
  applyPrompt(agentId, newPrompt) {
    const agent = this.get(agentId);
    if (!agent) return { ok: false, error: 'AGENT_NOT_FOUND' };
    const previous = agent.systemPrompt;
    agent.systemPrompt = newPrompt;
    agent._promptHistory = agent._promptHistory || [];
    agent._promptHistory.push({ previous, at: Date.now() });
    bus.safeEmit('coach:applied', { agentId });
    return { ok: true, agentId, previous };
  }

  rollbackPrompt(agentId) {
    const agent = this.get(agentId);
    if (!agent || !agent._promptHistory?.length) return { ok: false, error: 'NO_HISTORY' };
    const last = agent._promptHistory.pop();
    agent.systemPrompt = last.previous;
    bus.safeEmit('coach:rolledback', { agentId });
    return { ok: true, agentId };
  }

  status() {
    const byState = Object.create(null);
    for (const a of this.agents) byState[a.state] = (byState[a.state] || 0) + 1;
    return { ...this.stats, total: this.agents.length, byState };
  }
}

module.exports = AgentRuntime;
module.exports.STATES = STATES;
