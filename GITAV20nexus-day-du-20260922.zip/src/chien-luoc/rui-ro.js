'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  SỔ RỦI RO — PHÒNG TRƯỚC, KHÔNG CHỮA SAU
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Phần lớn sổ rủi ro trong doanh nghiệp là danh sách nỗi lo kèm cột "biện
 *  pháp" viết bằng động từ mềm: tăng cường, chú trọng, nâng cao. Những chữ ấy
 *  không chặn được gì, và ai đọc cũng biết thế, nhưng không ai nói ra.
 *
 *  Ở đây mỗi rủi ro phải khai ba thứ CÓ ĐỊA CHỈ, và mục kiểm đi kiểm từng thứ:
 *
 *    chan      — tệp mã ĐANG CHẠY chặn rủi ro này. Phải tồn tại trên đĩa.
 *    cachChan  — cơ chế chặn, nói bằng câu cụ thể. Trường này từng mang tên
 *                `conHo` ("còn hở") trong khi nội dung lại mô tả cách chặn —
 *                một nhãn sai trong sổ rủi ro là thứ đánh lừa người đọc đúng
 *                lúc 3 giờ sáng, nên nó được đổi tên chứ không để lại.
 *    thay      — ai/cái gì PHÁT HIỆN khi nó vẫn xảy ra: mã thanh tra viên,
 *                mã tình huống, hoặc nói thẳng 'chưa có gì canh'.
 *    xuLy      — mã kịch bản trực khi nó đã xảy ra.
 *
 *  Rủi ro mức NGHIÊM TRỌNG mà không có cả ba thì mục kiểm gọi tên. Không có
 *  chỗ nào để ghi "đang theo dõi".
 *
 *  MỘT ĐIỀU NỮA: rủi ro ở đây KHÔNG chấm điểm bằng tích xác suất × mức độ.
 *  Phép nhân ấy làm một rủi ro hiếm-nhưng-chết-người tụt xuống ngang một rủi
 *  ro thường-mà-nhẹ, rồi cả hai cùng nằm giữa bảng và không ai làm gì cả. Ở
 *  đây mức độ do HẬU QUẢ NẶNG NHẤT quyết định, giống cách bộ phân loại rủi ro
 *  học tập lấy miền nặng nhất thay vì lấy trung bình.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const MUC = {
  NGHIEM_TRONG: { ma: 'NGHIEM_TRONG', ten: 'Nghiêm trọng', y: 'Xảy ra là mất khách hàng hàng loạt, mất pháp lý, hoặc mất dữ liệu không khôi phục được.' },
  NANG: { ma: 'NANG', ten: 'Nặng', y: 'Xảy ra là mất tiền hoặc mất uy tín ở mức phải báo cáo.' },
  VUA: { ma: 'VUA', ten: 'Vừa', y: 'Xảy ra thì khó chịu và tốn công, nhưng gỡ được trong ngày.' },
};

const RUI_RO = [
  {
    ma: 'R01', ten: 'Lộ dữ liệu cá nhân của trẻ em', muc: 'NGHIEM_TRONG', nhom: 'phap-ly',
    hauQua: 'Không có đường quay lại về mặt lòng tin, và đây là nhóm dữ liệu được pháp luật bảo vệ chặt nhất.',
    chan: ['src/api/cong-quyen.js', 'src/khao-sat/kho.js', 'src/cay-tien/buc-tuong.js'],
    thay: ['TT02', 'TT03', 'TT09'],
    xuLy: 'KB02',
    cachChan: 'Bảng phân quyền mặc định ĐÓNG cho nhóm cổng chưa khai; câu trả lời thô của sàng lọc tâm lý bị gọt trước khi lưu.',
  },
  {
    ma: 'R02', ten: 'Mất dữ liệu học của học viên', muc: 'NGHIEM_TRONG', nhom: 'ky-thuat',
    hauQua: 'Mất bằng chứng tiến bộ là mất luôn lý do gia đình tin mình. Không dựng lại được bằng lời.',
    chan: ['src/data/repository.js'],
    thay: ['TT01'],
    xuLy: 'KB01',
    cachChan: 'Thứ tự năm bước ghi đĩa được mục kiểm đọc thẳng mã nguồn để chắc không bị đảo.',
  },
  {
    ma: 'R03', ten: 'Bảng phân loại gia đình lọt ra mặt khách hàng', muc: 'NGHIEM_TRONG', nhom: 'phap-ly',
    hauQua: 'Gia đình đọc thấy nhóm xếp hạng của mình là mất trắng quan hệ, và chuyện ấy lan rất nhanh.',
    chan: ['src/cay-tien/buc-tuong.js'],
    thay: ['TT03'],
    xuLy: 'KB02',
    cachChan: 'Bộ quét 22 cụm từ cấm chạy trên mọi trang công khai của cả bốn vai, không phân biệt dấu.',
  },
  {
    ma: 'R04', ten: 'Chi phí gọi mô hình cháy trong một đêm', muc: 'NANG', nhom: 'tai-chinh',
    hauQua: 'Một vòng lặp gọi mô hình có thể tiêu hết ngân sách tháng trong vài giờ, lúc không ai ngồi trước màn hình.',
    chan: ['src/dong-tien/so-cai.js'],
    thay: ['TT04'],
    xuLy: 'KB03',
    cachChan: 'Trần ngày và trần tháng CHẶN CỨNG khoản chi, không phải ghi cảnh báo rồi cho qua.',
  },
  {
    ma: 'R05', ten: 'Học liệu sai đáp số lọt tới học viên', muc: 'NANG', nhom: 'chuyen-mon',
    hauQua: 'Em bị chấm sai sẽ nhớ rất lâu, và gia đình mất niềm tin vào mọi con số còn lại.',
    chan: ['src/math/verifier.js', 'src/content/item-bank.js', 'src/content/quality.js'],
    thay: ['TT06', 'TT10'],
    xuLy: 'KB05',
    cachChan: 'Bài không có bằng chứng xác minh thì không được phát hành; quyền GỠ bài không có trần.',
  },
  {
    ma: 'R06', ten: 'Sàng lọc tâm lý báo dấu hiệu nặng mà không ai nhận việc', muc: 'NGHIEM_TRONG', nhom: 'an-toan',
    hauQua: 'Đây là rủi ro duy nhất trong sổ này mà hậu quả không đo bằng tiền.',
    chan: ['src/khao-sat/tam-ly-hoc-duong.js', 'src/khao-sat/lo-trinh-ca-nhan.js'],
    thay: ['TT09'],
    xuLy: 'KB04',
    cachChan: 'Cổng an toàn đòi có tên người lớn đã nói chuyện trước khi lộ trình đi tiếp; người trực KHÔNG có quyền tự xử.',
  },
  {
    ma: 'R07', ten: 'Biểu mẫu khu riêng bị trang ngoài nộp hộ', muc: 'NANG', nhom: 'ky-thuat',
    hauQua: 'Một trang bất kỳ có thể nộp hộ bài sàng lọc tâm lý của một đứa trẻ đang đăng nhập.',
    chan: ['src/web/chong-gia-mao.js', 'src/index.js'],
    thay: ['TT02'],
    xuLy: 'KB02',
    cachChan: 'Hai lớp hỏng theo hai cách khác nhau: dấu vết nguồn, và vé HMAC của token phiên.',
  },
  {
    ma: 'R08', ten: 'Hứa với gia đình một mức điểm', muc: 'NANG', nhom: 'phap-ly',
    hauQua: 'Lời hứa điểm số là thứ không ai giữ được, và nó quay lại làm chứng chống chính mình.',
    chan: ['src/nha/cay-gia-tri.js', 'src/trai-nghiem/tinh-huong.js'],
    thay: ['chưa có mục soi tự động — dựa vào mục kiểm trong bộ test'],
    xuLy: 'không phải sự cố kỹ thuật; xử theo tình huống TH20',
    cachChan: 'Mục kiểm quét mọi kịch bản và mọi quả của lưới 50 ô, bắt câu nào hứa bằng điểm số.',
  },
  {
    ma: 'R09', ten: 'Báo cáo bằng con số ước lượng như thể đã đo', muc: 'NANG', nhom: 'quan-tri',
    hauQua: 'Một bảng chỉ số nửa thật nửa ước lượng tệ hơn không có bảng nào: nó dẫn tới quyết định sai mà vẫn thấy yên tâm.',
    chan: ['src/dong-tien/so-cai.js', 'src/trai-nghiem/do-luong.js', 'src/chien-luoc/thuoc-do.js'],
    thay: ['TT04'],
    xuLy: 'không phải sự cố; sửa bằng cách gỡ chỉ tiêu khỏi thước đo chưa nối nguồn',
    cachChan: 'Sổ cái TỪ CHỐI ghi vào khoản chưa nối nguồn; thước đo chưa nối nguồn KHÔNG được có chỉ tiêu.',
  },
  {
    ma: 'R10', ten: 'Lượt thanh tra không chạy mà không ai biết', muc: 'NANG', nhom: 'quan-tri',
    hauQua: 'Lượt không chạy trông giống hệt lượt sạch. Hệ thống tưởng mình đang được canh trong khi không.',
    chan: ['src/thanh-tra/to-thanh-tra.js'],
    thay: ['biên bản ngày — đếm lượt thiếu'],
    xuLy: 'KB08',
    cachChan: 'Biên bản ngày tính lượt thiếu là KHÔNG ĐẠT; phép soi ném lỗi cũng tính là không đạt.',
  },
  {
    ma: 'R11', ten: 'Trợ lý AI chuyên môn treo giữa buổi học', muc: 'VUA', nhom: 'ky-thuat',
    hauQua: 'Buổi học hỏng và em mất nhịp. Gỡ được trong ngày nhưng lặp lại thì thành lý do rời bỏ.',
    chan: ['src/agents/runtime.js', 'src/kernel/queue.js'],
    thay: ['TT08'],
    xuLy: 'KB06',
    cachChan: 'Ngắt mạch theo từng trợ lý và chuyển việc sang tuyến người thật.',
  },
  {
    ma: 'R12', ten: 'Phụ thuộc vào một người để hệ thống chạy', muc: 'NANG', nhom: 'quan-tri',
    hauQua: 'Người ấy nghỉ là cả tầng nền tụt theo, và không ai biết trước ngày nào.',
    chan: ['src/quy-trinh/so-tay.js', 'src/trai-nghiem/tinh-huong.js', 'RUNBOOK.md'],
    thay: ['chưa có mục soi tự động'],
    xuLy: 'không phải sự cố; xử bằng việc viết lại quy trình thành tài liệu bàn giao được',
    cachChan: 'Tám kịch bản trực và bốn mươi tình huống đều viết để người chưa từng gặp việc ấy vẫn làm được.',
  },
];

const RR_INDEX = new Map(RUI_RO.map((r) => [r.ma, r]));

/**
 * Soi sổ rủi ro. Chỗ này kiểm địa chỉ chứ không kiểm lời hứa: tệp khai ra có
 * tồn tại không, mã thanh tra viên có thật không, mã kịch bản có thật không.
 */
function soiRuiRo({ goc = null } = {}) {
  const fs = require('node:fs');
  const path = require('node:path');
  const ROOT = goc || path.join(__dirname, '..', '..');
  const TT = require('../thanh-tra/to-thanh-tra');
  const ST = require('../quy-trinh/so-tay');
  const maVien = new Set(TT.THANH_TRA_VIEN.map((v) => v.ma));

  const loi = [];
  for (const r of RUI_RO) {
    if (!MUC[r.muc]) loi.push(`${r.ma} có mức lạ "${r.muc}"`);
    if (!r.hauQua || r.hauQua.length < 30) loi.push(`${r.ma} không nói rõ hậu quả`);
    if (!r.cachChan || r.cachChan.length < 20) loi.push(`${r.ma} không nói cơ chế chặn hoạt động thế nào`);
    if (/tăng cường|chú trọng|nâng cao|đẩy mạnh|quan tâm hơn/i.test(r.cachChan || '')) {
      loi.push(`${r.ma} mô tả cách chặn bằng động từ mềm — những chữ ấy không chặn được gì`);
    }

    // Biện pháp chặn phải là tệp mã ĐANG CHẠY.
    if (!r.chan || !r.chan.length) loi.push(`${r.ma} không có biện pháp chặn nào`);
    for (const f of (r.chan || [])) {
      if (!fs.existsSync(path.join(ROOT, f))) loi.push(`${r.ma} khai chặn bằng "${f}" — tệp không tồn tại`);
    }

    // Phát hiện: hoặc là mã thanh tra viên có thật, hoặc nói thẳng là chưa có.
    for (const t of (r.thay || [])) {
      if (/^TT\d\d$/.test(t)) {
        if (!maVien.has(t)) loi.push(`${r.ma} khai thanh tra viên "${t}" không tồn tại`);
      } else if (!/chưa có|biên bản/.test(t)) {
        loi.push(`${r.ma} khai cách phát hiện "${t}" không phải mã thanh tra viên và cũng không nói thẳng là chưa có`);
      }
    }

    // Kịch bản xử lý: mã KB phải có thật.
    if (/^KB\d\d$/.test(r.xuLy) && !ST.KICH_BAN_INDEX.has(r.xuLy)) {
      loi.push(`${r.ma} trỏ vào kịch bản "${r.xuLy}" không tồn tại`);
    }

    // Luật cứng: rủi ro NGHIÊM TRỌNG phải có đủ cả ba, không có chỗ ghi "đang theo dõi".
    if (r.muc === 'NGHIEM_TRONG') {
      const thayThat = (r.thay || []).some((t) => /^TT\d\d$/.test(t));
      if (!thayThat) loi.push(`${r.ma} mức NGHIÊM TRỌNG mà không có mục soi tự động nào phát hiện`);
      if (!/^KB\d\d$/.test(r.xuLy)) loi.push(`${r.ma} mức NGHIÊM TRỌNG mà không có kịch bản trực`);
    }
  }

  const theoMuc = {};
  for (const r of RUI_RO) theoMuc[r.muc] = (theoMuc[r.muc] || 0) + 1;
  return {
    tong: RUI_RO.length,
    theoMuc,
    coMucSoiTuDong: RUI_RO.filter((r) => (r.thay || []).some((t) => /^TT\d\d$/.test(t))).length,
    khongCoMucSoi: RUI_RO.filter((r) => !(r.thay || []).some((t) => /^TT\d\d$/.test(t))).map((r) => ({ ma: r.ma, ten: r.ten, muc: r.muc })),
    loi,
    ok: loi.length === 0,
    nhac: 'Rủi ro không có mục soi tự động thì KHÔNG ai canh lúc 11 giờ đêm. '
      + 'Ba rủi ro như vậy trong sổ này đều ở mức NẶNG và được chấp nhận có ý thức, không phải bị bỏ quên.',
  };
}

module.exports = { MUC, RUI_RO, RR_INDEX, soiRuiRo };
