'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BẢN ĐỒ CHIẾN LƯỢC — BỐN VIỄN CẢNH, VÀ CHUỖI NHÂN QUẢ NỐI CHÚNG
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  SAI LẦM LỚN NHẤT khi dùng thẻ điểm cân bằng là biến nó thành một bảng KPI:
 *  liệt kê bốn nhóm chỉ số, giao chỉ tiêu, cuối tháng chấm điểm. Làm thế thì
 *  nó thành công cụ đánh giá nhân sự, và mất đúng thứ làm nên giá trị của nó.
 *
 *  Thứ làm nên giá trị là CHUỖI NHÂN QUẢ: năng lực tạo ra quy trình, quy trình
 *  tạo ra giá trị cho khách, giá trị cho khách tạo ra kết quả tài chính. Một
 *  mục tiêu không nối vào chuỗi ấy là một mục tiêu không ai biết vì sao mình
 *  đang theo đuổi.
 *
 *  NÊN Ở ĐÂY CHUỖI NHÂN QUẢ ĐƯỢC MÁY CANH, KHÔNG PHẢI ĐƯỢC HỨA:
 *    1. Mọi mục tiêu ngoài tầng tài chính PHẢI có ít nhất một cạnh đi ra.
 *       Mục tiêu mồ côi bị mục kiểm gọi tên.
 *    2. Mọi chuỗi PHẢI kết thúc ở một mục tiêu tài chính. Đi lòng vòng rồi
 *       tắt giữa đường nghĩa là ta không biết mục tiêu ấy dẫn tới đâu.
 *    3. KHÔNG được có vòng lặp. Vòng lặp trong bản đồ nhân quả nghĩa là ta
 *       đang giải thích A bằng B và B bằng A — nghe hợp lý và không kiểm được.
 *    4. Cạnh chỉ được đi LÊN một tầng hoặc trong cùng tầng. Năng lực không
 *       trực tiếp tạo ra doanh thu; nó đi qua quy trình và qua khách hàng.
 *
 *  HAI LOẠI CẠNH, VÀ VÌ SAO PHẢI TÁCH RA.
 *
 *  Bộ soi ở tệp này từng bắt chính người viết nó: ba cạnh được vẽ thẳng từ
 *  tầng nền lên tầng tài chính, vi phạm luật 4. Nhìn kỹ thì đó không phải lỗi
 *  dữ liệu mà là thiếu sót của mô hình — vì có hai kiểu quan hệ khác hẳn nhau:
 *
 *    `dan`  — CHUỖI TẠO GIÁ TRỊ. Năng lực → quy trình → giá trị cho khách →
 *             kết quả tài chính. Loại này đi từng tầng một và không được nhảy.
 *
 *    `chan` — LIÊN KẾT PHÒNG TỔN THẤT. Một vụ lộ dữ liệu trẻ em tốn tiền
 *             NGAY LẬP TỨC: khắc phục, có thể bị phạt, có thể mất khách hàng
 *             hàng loạt. Nó không đi qua "gia đình hài lòng hơn". Bắt nó đi
 *             vòng qua tầng khách hàng cho hợp luật là vẽ sai cách tiền mất.
 *
 *  ĐỂ `chan` KHÔNG THÀNH CỬA SAU, nó bị siết bằng một luật riêng: cạnh `chan`
 *  CHỈ được trỏ vào mục tiêu có `laPhongTonThat: true`. Muốn dùng nó để nhảy
 *  tầng cho tiện thì mục kiểm chặn ngay.
 *
 *    5. Mọi mục tiêu NGOÀI tầng nền phải có ít nhất một cạnh ĐI VÀO. Luật 1
 *       bắt mục tiêu mồ côi ở đầu ra; luật này bắt mồ côi ở đầu vào — một
 *       mục tiêu tài chính mà không chuỗi nào dẫn tới nghĩa là ta viết ra
 *       một kết quả mong muốn rồi không nói nó đến từ đâu. Chính bộ soi này
 *       tìm ra hai mục tiêu như vậy ngay trong bản dựng đầu tiên.
 * ═══════════════════════════════════════════════════════════════════════════
 */

/** Bốn viễn cảnh, xếp từ nền lên ngọn. Số thứ tự dùng để cưỡng chế hướng cạnh. */
const VIEN_CANH = [
  { ma: 'HH', thu: 1, ten: 'Học hỏi và phát triển',
    cauHoi: 'Ta cần năng lực gì để làm được những việc phía trên?',
    y: 'Tầng nền. Đầu tư ở đây lâu thấy kết quả nhất và bị cắt đầu tiên khi khó khăn — đó là lý do phải ghi nó ra.' },
  { ma: 'QT', thu: 2, ten: 'Quy trình nội bộ',
    cauHoi: 'Quy trình nào phải làm xuất sắc?',
    y: 'Nơi năng lực biến thành việc làm được. Quy trình không gắn với chiến lược thì tối ưu nó cũng vô ích.' },
  { ma: 'KH', thu: 3, ten: 'Khách hàng',
    cauHoi: 'Gia đình nhận được giá trị gì?',
    y: 'Thước đo thật của cả hệ thống. Mọi tầng dưới chỉ có nghĩa khi tầng này đổi.' },
  { ma: 'TC', thu: 4, ten: 'Tài chính',
    cauHoi: 'Kết quả kinh tế nào cần đạt để đi đường dài?',
    y: 'Kết quả, không phải điểm xuất phát. Nhưng bỏ qua nó thì không có đường dài nào cả.' },
];

const VC_INDEX = new Map(VIEN_CANH.map((v) => [v.ma, v]));

/**
 * Mục tiêu chiến lược.
 *   dan   — các mục tiêu mà mục tiêu này DẪN TỚI (cạnh nhân quả đi ra)
 *   viSao — giả thuyết nhân quả, viết thành câu kiểm chứng được
 */
const MUC_TIEU = [
  // ── HỌC HỎI VÀ PHÁT TRIỂN ─────────────────────────────────────────────
  {
    ma: 'HH1', vienCanh: 'HH', ten: 'Đội trợ lý AI chuyên môn luôn sẵn sàng và đo được',
    viSao: 'Trợ lý treo giữa buổi thì học viên chờ, và buổi học ấy hỏng. Sẵn sàng là điều kiện của mọi việc phía trên.',
    dan: ['QT2', 'QT3', 'QT4'],
  },
  {
    ma: 'HH2', vienCanh: 'HH', ten: 'Mọi bài học liệu đều có bằng chứng xác minh',
    viSao: 'Một bài sai đáp số lọt ra ngoài phá lòng tin nhanh hơn mười bài đúng xây được. Bằng chứng ở tầng nền chặn việc đó.',
    dan: ['QT1', 'QT2'],
  },
  {
    ma: 'HH3', vienCanh: 'HH', ten: 'Dữ liệu học viên bền vững và riêng tư',
    viSao: 'Mất dữ liệu học là mất cả bằng chứng tiến bộ lẫn lý do gia đình tin mình. Lộ dữ liệu trẻ thì không có đường quay lại.',
    dan: ['QT4'],
    chan: ['TC4'],
  },
  {
    ma: 'HH4', vienCanh: 'HH', ten: 'Người trực biết chính xác phải làm gì khi có việc',
    viSao: 'Phần lớn sự cố nhỏ thành lớn vì người trực làm một việc tưởng là cứu chữa. Sổ tay và bốn mươi tình huống chặn chỗ đó.',
    dan: ['QT3', 'QT5'],
  },

  // ── QUY TRÌNH NỘI BỘ ──────────────────────────────────────────────────
  {
    ma: 'QT1', vienCanh: 'QT', ten: 'Đo đúng: công cụ nào được quyết định việc gì',
    viSao: 'Một bảng hỏi tính cách đặt cạnh bài kiểm tra năng lực, cùng cỡ chữ, sẽ được dùng như nhau. Luật đo chặn việc đó.',
    dan: ['QT2', 'KH2'],
  },
  {
    ma: 'QT2', vienCanh: 'QT', ten: 'Dạy đúng chỗ hổng, theo lộ trình cá nhân hoá',
    viSao: 'Dạy đúng chỗ hổng là cách duy nhất làm học viên tiến bộ nhanh hơn tự học. Đó là toàn bộ lý do gia đình trả tiền.',
    dan: ['KH1'],
  },
  {
    ma: 'QT3', vienCanh: 'QT', ten: 'Chạm đúng lúc, đúng kênh, đúng mức',
    viSao: 'Nhà rời bỏ thường không phải vì dạy dở mà vì im lặng quá lâu ở đúng lúc họ đang phân vân.',
    dan: ['KH2', 'KH3'],
  },
  {
    ma: 'QT4', vienCanh: 'QT', ten: 'Bắt lỗi trước khi nó thành sự cố',
    viSao: 'Sửa sau sự cố là việc đắt nhất trong vận hành: tốn tiền, tốn uy tín, và tốn người.',
    dan: ['KH2'],
    chan: ['TC4', 'TC1'],
  },
  {
    ma: 'QT5', vienCanh: 'QT', ten: 'Phục hồi tử tế khi đã hỏng việc',
    viSao: 'Nhà gặp sự cố rồi được xử lý tử tế thường gắn bó hơn nhà chưa từng gặp sự cố — nhưng chỉ khi làm đủ và đúng thứ tự.',
    dan: ['KH3'],
    chan: ['TC4'],
  },

  // ── KHÁCH HÀNG ────────────────────────────────────────────────────────
  {
    ma: 'KH1', vienCanh: 'KH', ten: 'Học viên tiến bộ, đo bằng mốc cứng',
    viSao: 'Đây là thứ gia đình mua. Mọi thứ khác chỉ là cách để có nó.',
    dan: ['KH2', 'KH3'],
  },
  {
    ma: 'KH2', vienCanh: 'KH', ten: 'Gia đình tin số liệu vì xem được bài làm thật',
    viSao: 'Gia đình không nghi ngờ bài làm của con mình; họ nghi ngờ bảng tổng hợp do người bán dịch vụ dựng ra.',
    dan: ['KH3'],
  },
  {
    ma: 'KH3', vienCanh: 'KH', ten: 'Gia đình ở lại và đi đều',
    viSao: 'Giữ một nhà rẻ hơn tìm một nhà mới rất nhiều, và nhà ở lâu mới cho thấy hệ thống có tác dụng thật.',
    dan: ['KH4', 'TC2'],
  },
  {
    ma: 'KH4', vienCanh: 'KH', ten: 'Gia đình chủ động giới thiệu người quen',
    viSao: 'Nhà giới thiệu là bằng chứng mạnh nhất rằng giá trị là thật, vì họ đem uy tín của mình ra bảo đảm.',
    dan: ['TC2'],
  },

  // ── TÀI CHÍNH ─────────────────────────────────────────────────────────
  {
    ma: 'TC1', vienCanh: 'TC', ten: 'Chi phí vận hành nằm trong trần, không có đêm cháy ngân sách',
    viSao: 'Chi phí gọi mô hình có thể tăng gấp trăm lần trong một đêm vì một vòng lặp. Trần cứng là thứ duy nhất chặn được.',
    dan: ['TC3'],
    laPhongTonThat: true,
  },
  {
    ma: 'TC2', vienCanh: 'TC', ten: 'Doanh thu từ gia đình',
    viSao: 'Gia đình ở lại lâu và giới thiệu người quen thì doanh thu đi theo. Đây là kết quả, không phải điểm xuất phát.',
    dan: ['TC3'],
    chuaNoiNguon: true,
  },
  {
    ma: 'TC3', vienCanh: 'TC', ten: 'Biên lợi nhuận đủ để đi đường dài',
    viSao: 'Không có biên thì không tái đầu tư được vào tầng nền, và tầng nền là chỗ quyết định năm sau.',
    dan: [],
    chuaNoiNguon: true,
  },
  {
    ma: 'TC4', vienCanh: 'TC', ten: 'Không mất tiền vì sự cố, vì phạt, vì mất dữ liệu',
    viSao: 'Khoản lỗ lớn nhất của một tổ chức giáo dục hiếm khi đến từ kinh doanh kém — nó đến từ một sự cố dữ liệu hoặc một vi phạm.',
    dan: [],
    laPhongTonThat: true,
  },
];

const MT_INDEX = new Map(MUC_TIEU.map((m) => [m.ma, m]));

/** Chuỗi nhân quả đi từ một mục tiêu lên tới tầng tài chính. */
function chuoiTu(ma, daQua = []) {
  const m = MT_INDEX.get(ma);
  if (!m) return [];
  if (daQua.includes(ma)) return [[...daQua, ma, '⟲ VÒNG LẶP']];
  const duong = [...daQua, ma];
  if (!m.dan.length) return [duong];
  const ra = [];
  for (const d of m.dan) ra.push(...chuoiTu(d, duong));
  return ra;
}

/**
 * Soi bản đồ. Bốn luật ở đầu tệp, kiểm bằng máy chứ không bằng lời hứa.
 */
function soiBanDo() {
  const loi = [];

  for (const m of MUC_TIEU) {
    const vc = VC_INDEX.get(m.vienCanh);
    if (!vc) { loi.push(`${m.ma} thuộc viễn cảnh lạ "${m.vienCanh}"`); continue; }

    // Luật 1: mục tiêu ngoài tầng tài chính phải có cạnh đi ra.
    if (vc.ma !== 'TC' && m.dan.length === 0) {
      loi.push(`${m.ma} không dẫn tới mục tiêu nào — mục tiêu mồ côi`);
    }

    for (const d of m.dan) {
      const dich = MT_INDEX.get(d);
      if (!dich) { loi.push(`${m.ma} dẫn tới "${d}" không tồn tại`); continue; }
      // Luật 4: cạnh tạo giá trị chỉ đi lên một tầng hoặc trong cùng tầng.
      const buoc = VC_INDEX.get(dich.vienCanh).thu - vc.thu;
      if (buoc < 0) loi.push(`${m.ma} → ${d} đi NGƯỢC xuống tầng dưới`);
      if (buoc > 1) loi.push(`${m.ma} → ${d} nhảy ${buoc} tầng — năng lực không tạo ra tiền trực tiếp, nó đi qua quy trình và khách hàng`);
    }

    // Cạnh phòng tổn thất được nhảy tầng, nhưng CHỈ tới mục tiêu phòng tổn
    // thất. Nếu không siết chỗ này thì `chan` thành cửa sau để lách luật 4.
    for (const d of (m.chan || [])) {
      const dich = MT_INDEX.get(d);
      if (!dich) { loi.push(`${m.ma} chặn tổn thất vào "${d}" không tồn tại`); continue; }
      if (!dich.laPhongTonThat) {
        loi.push(`${m.ma} ⇢ ${d}: cạnh phòng tổn thất chỉ được trỏ vào mục tiêu phòng tổn thất, không dùng để nhảy tầng cho tiện`);
      }
    }

    if (!m.viSao || m.viSao.length < 40) {
      loi.push(`${m.ma} không nêu được giả thuyết nhân quả bằng một câu kiểm chứng được`);
    }
  }

  // Luật 5: mọi mục tiêu ngoài tầng nền phải có ít nhất một cạnh ĐI VÀO.
  const coDauVao = new Set();
  for (const m of MUC_TIEU) {
    for (const d of m.dan) coDauVao.add(d);
    for (const d of (m.chan || [])) coDauVao.add(d);
  }
  for (const m of MUC_TIEU) {
    if (m.vienCanh === 'HH') continue;          // tầng nền không có gì phía dưới
    if (!coDauVao.has(m.ma)) {
      loi.push(`${m.ma} không có chuỗi nào dẫn tới — một kết quả mong muốn mà không nói nó đến từ đâu`);
    }
  }

  // Luật 2 và 3: mọi chuỗi kết thúc ở tài chính, và không có vòng lặp.
  let soChuoi = 0;
  for (const m of MUC_TIEU) {
    if (m.vienCanh === 'TC') continue;
    for (const c of chuoiTu(m.ma)) {
      soChuoi++;
      if (c.includes('⟲ VÒNG LẶP')) { loi.push(`có vòng lặp: ${c.join(' → ')}`); continue; }
      const cuoi = MT_INDEX.get(c[c.length - 1]);
      if (!cuoi || cuoi.vienCanh !== 'TC') {
        loi.push(`chuỗi từ ${m.ma} tắt giữa đường ở ${c[c.length - 1]}, không tới tầng tài chính`);
      }
    }
  }

  return {
    soVienCanh: VIEN_CANH.length,
    soMucTieu: MUC_TIEU.length,
    soCanh: MUC_TIEU.reduce((s, m) => s + m.dan.length, 0),
    soCanhPhongTonThat: MUC_TIEU.reduce((s, m) => s + (m.chan || []).length, 0),
    soChuoi,
    loi,
    ok: loi.length === 0,
  };
}

/** Bản đồ đầy đủ, xếp theo viễn cảnh từ nền lên ngọn. */
function banDo() {
  return {
    vienCanh: VIEN_CANH.map((v) => ({
      ...v,
      mucTieu: MUC_TIEU.filter((m) => m.vienCanh === v.ma),
    })),
    soi: soiBanDo(),
    chuoiMau: chuoiTu('HH2').map((c) => c.join(' → ')),
    nhac: 'Bản đồ này KHÔNG phải bảng KPI. Thứ làm nên giá trị của nó là các mũi tên, '
      + 'không phải các ô. Thêm một mục tiêu mà không nối nó vào chuỗi thì mục kiểm sẽ gọi tên.',
  };
}

module.exports = { VIEN_CANH, VC_INDEX, MUC_TIEU, MT_INDEX, chuoiTu, soiBanDo, banDo };
