'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  HÁT TIẾNG VIỆT — tổng hợp giọng hát ngay trong tiến trình
 * ═══════════════════════════════════════════════════════════════════════════
 *  Bản thiết kế gốc giao việc hát cho SoulX-Singer, DiffSinger và So-VITS-SVC.
 *  Ba mô hình đó đều tốt, và đều được giữ làm nhà cung cấp cắm thêm. Nhưng cả
 *  ba đều cần Python, cần GPU, cần tải mô hình hàng GB — nghĩa là hệ thống
 *  KHÔNG hát được gì cho tới khi có người cài xong. Riêng SoulX-Singer còn
 *  chưa có tiếng Việt.
 *
 *  Nên lớp hát mặc định được viết thẳng ở đây, dùng lại bộ tổng hợp formant
 *  của phần nói. Khác biệt giữa NÓI và HÁT không nằm ở chất giọng mà nằm ở
 *  cách điều khiển cao độ và thời gian:
 *
 *    NÓI                                HÁT
 *    cao độ do thanh điệu quyết định    cao độ do NỐT NHẠC quyết định
 *    âm tiết dài 200–400ms              âm tiết dài bằng trường độ nốt
 *    không rung giọng                   rung giọng (vibrato) vào sau ~250ms
 *    chuyển tiếp gãy                    luyến (portamento) giữa hai nốt
 *    không lấy hơi                      lấy hơi ở chỗ nghỉ
 *
 *  Một điểm riêng của tiếng Việt mà mô hình tiếng Trung/Anh không có: THANH
 *  ĐIỆU. Hát đúng nốt mà bỏ hết thanh thì "má" thành "ma", nghe sai nghĩa.
 *  Người hát thật giữ lại một phần nét thanh ngay đầu mỗi nốt. Ở đây điều đó
 *  là tham số `toneBlend` — pha một phần đường thanh điệu đã nén lại vào cao
 *  độ nốt, mặc định 22%.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { VoiceSynth, SAMPLE_RATE } = require('./synth');
const { parseSyllable, segmentsOf, TONES } = require('./phonemizer');
const { midiToFreq, midiName, parseMelody, parseMidi, extractLeadLine, withRests, fitToRange } = require('./music');
const { round, clamp } = require('../utils');

/** Cách hát theo thể loại. */
const STYLES = {
  // toneFade = tới phần nào của nốt thì nét thanh tan hết vào đúng cao độ nốt.
  pop: { name: 'Pop', vibratoDepth: 0.35, vibratoRate: 5.6, vibratoOnset: 0.30, portamentoMs: 55, toneBlend: 0.55, toneFade: 0.30, breathiness: 1.0, attackMs: 22, releaseMs: 40 },
  ballad: { name: 'Ballad', vibratoDepth: 0.55, vibratoRate: 5.0, vibratoOnset: 0.25, portamentoMs: 90, toneBlend: 0.50, toneFade: 0.32, breathiness: 1.3, attackMs: 38, releaseMs: 70 },
  'dan-ca': { name: 'Dân ca', vibratoDepth: 0.80, vibratoRate: 6.4, vibratoOnset: 0.18, portamentoMs: 130, toneBlend: 0.85, toneFade: 0.55, breathiness: 0.9, attackMs: 30, releaseMs: 60 },
  'thieu-nhi': { name: 'Thiếu nhi', vibratoDepth: 0.15, vibratoRate: 5.2, vibratoOnset: 0.45, portamentoMs: 25, toneBlend: 0.45, toneFade: 0.26, breathiness: 0.8, attackMs: 16, releaseMs: 28 },
  'doc-rap': { name: 'Đọc rap', vibratoDepth: 0.05, vibratoRate: 4.0, vibratoOnset: 0.80, portamentoMs: 10, toneBlend: 1.00, toneFade: 0.95, breathiness: 0.7, attackMs: 10, releaseMs: 18 },
};

/**
 * Ghép lời vào nốt.
 *   · mỗi âm tiết một nốt
 *   · "-" trong lời = luyến: âm tiết trước ngân tiếp sang nốt này
 *   · dấu lặng trong giai điệu được bỏ qua khi ghép, giữ lại khi dựng tiếng
 */
function alignLyrics(lyrics, notes) {
  const syllables = String(lyrics || '').trim().split(/\s+/).filter(Boolean);
  const pitched = notes.filter((n) => !n.rest && n.midi != null);
  const plan = [];
  let si = 0;
  let melisma = 0;

  for (const n of pitched) {
    const syl = syllables[si];
    if (syl === undefined) {
      plan.push({ ...n, syllable: null, missing: true });
      continue;
    }
    if (syl === '-' || syl === '~') {
      // Ngân tiếp âm tiết trước sang nốt này.
      const prev = plan[plan.length - 1];
      plan.push({ ...n, syllable: prev ? prev.syllable : null, melisma: true });
      melisma++;
      si++;
      continue;
    }
    plan.push({ ...n, syllable: syl, melisma: false });
    si++;
  }

  const leftover = syllables.slice(si).filter((x) => x !== '-' && x !== '~');
  return {
    ok: leftover.length === 0 && !plan.some((p) => p.missing),
    plan,
    syllables: syllables.filter((x) => x !== '-' && x !== '~').length,
    notes: pitched.length,
    melisma,
    leftoverSyllables: leftover,
    notesWithoutLyrics: plan.filter((p) => p.missing).length,
    warning: leftover.length ? `Thừa ${leftover.length} âm tiết không có nốt để hát: ${leftover.slice(0, 5).join(' ')}`
      : (plan.some((p) => p.missing) ? `Thiếu lời cho ${plan.filter((p) => p.missing).length} nốt` : null),
  };
}

class SingingVoice {
  /**
   * @param {object} profile hồ sơ giọng (cùng dạng với phần nói)
   * @param {object} opts {style}
   */
  constructor(profile = {}, { style = 'pop' } = {}) {
    this.profile = profile;
    this.style = STYLES[style] ? { ...STYLES[style], id: style } : { ...STYLES.pop, id: 'pop' };
    this.synth = new VoiceSynth({
      ...(profile.params || profile),
      // Hát thì hơi nhiều hơn nói, và rung giọng thay cho jitter ngẫu nhiên.
      breathiness: ((profile.params || profile).breathiness ?? 0.06) * this.style.breathiness,
      jitter: ((profile.params || profile).jitter ?? 0.01) * 0.45,
    });
  }

  /**
   * Kéo dài một âm tiết cho vừa trường độ nốt.
   * Chỉ NGUYÊN ÂM được kéo — phụ âm đầu và âm cuối giữ nguyên độ dài tự nhiên.
   * Kéo cả phụ âm thì nghe như băng chạy chậm, không phải như hát.
   */
  _stretch(segments, targetMs) {
    if (!segments.length) return segments;
    const fixed = segments.filter((s) => s.kind !== 'vowel');
    const vowels = segments.filter((s) => s.kind === 'vowel');
    if (!vowels.length) return segments;

    // Âm cuối mũi (m, n, ng, nh) được ngân một phần — người hát vẫn ngâm "ơ…ng".
    const nasalCoda = segments.find((s) => s.role === 'coda' && s.type === 'nasal');
    const fixedMs = fixed.reduce((a, s) => a + s.ms, 0);
    let room = targetMs - fixedMs;

    if (room < 40) {
      // Nốt quá ngắn so với âm tiết: nén đều tất cả lại cho vừa.
      const total = segments.reduce((a, s) => a + s.ms, 0);
      const k = Math.max(0.35, targetMs / total);
      return segments.map((s) => ({ ...s, ms: s.ms * k }));
    }

    let nasalExtra = 0;
    if (nasalCoda && room > 260) {
      nasalExtra = Math.min(room * 0.18, 220);
      room -= nasalExtra;
    }
    const perVowel = room / vowels.length;
    return segments.map((s) => {
      if (s.kind === 'vowel') return { ...s, ms: perVowel };
      if (nasalExtra && s === nasalCoda) return { ...s, ms: s.ms + nasalExtra };
      return s;
    });
  }

  /**
   * Đường cao độ cho một nốt: nốt + luyến từ nốt trước + rung giọng
   * + một phần nét thanh điệu tiếng Việt.
   */
  _pitchCurve(noteHz, prevHz, toneName, noteMs) {
    const st = this.style;
    const tone = TONES[Object.keys(TONES).find((k) => TONES[k].name === toneName)] || TONES.ngang;
    // Nét thanh được tính TƯƠNG ĐỐI so với điểm bắt đầu của chính nó. Nếu lấy
    // thẳng đường thanh (thanh huyền nằm quanh 0,8) thì cả nốt bị kéo thấp gần
    // một cung — hát thành phô. Chia cho giá trị đầu thì nét thanh chỉ còn là
    // HƯỚNG đi, không còn kéo lệch cao độ.
    const c0 = tone.contour[0] || 1;
    const rel = tone.contour.map((c) => c / c0);
    const portaMs = Math.min(st.portamentoMs, noteMs * 0.35);
    const fade = st.toneFade;

    return (t, ms) => {
      // 1) Luyến: trượt từ cao độ nốt trước sang nốt này
      let base = noteHz;
      if (prevHz && portaMs > 0 && ms < portaMs) {
        const w = ms / portaMs;
        const smooth = w * w * (3 - 2 * w);                  // vào êm ra êm
        base = prevHz * (1 - smooth) + noteHz * smooth;
      }

      // 2) Nét thanh điệu: rõ ở đầu nốt rồi tan dần về đúng cao độ nốt.
      //    Người hát tiếng Việt làm đúng như vậy — đủ để nghe ra "má" khác
      //    "mà", nhưng phần ngân vẫn đúng nốt.
      const seg = clamp(t * (rel.length - 1), 0, rel.length - 1);
      const i = Math.floor(seg);
      const f = seg - i;
      const shape = rel[i] * (1 - f) + rel[Math.min(rel.length - 1, i + 1)] * f;
      const weight = t >= fade ? 0 : (1 - t / fade);
      const toneMul = 1 + (shape - 1) * st.toneBlend * weight;

      // 3) Rung giọng: chỉ vào sau một quãng, rồi mạnh dần
      let vib = 1;
      if (t > st.vibratoOnset && noteMs > 320) {
        const grow = Math.min(1, (t - st.vibratoOnset) / 0.3);
        const cents = st.vibratoDepth * 50 * grow;           // nửa cung = 100 cent
        vib = Math.pow(2, (cents * Math.sin(2 * Math.PI * st.vibratoRate * ms / 1000)) / 1200);
      }

      return base * toneMul * vib;
    };
  }

  /** Bao biên độ của một nốt: vào, giữ, ra. */
  _envelope(n, sr, attackMs, releaseMs) {
    const env = new Float32Array(n);
    const a = Math.max(1, Math.round(attackMs / 1000 * sr));
    const r = Math.max(1, Math.round(releaseMs / 1000 * sr));
    for (let i = 0; i < n; i++) {
      let g = 1;
      if (i < a) g = i / a;
      if (n - i < r) g = Math.min(g, (n - i) / r);
      env[i] = g;
    }
    return env;
  }

  /** Tiếng lấy hơi trước câu hát — nhỏ, ngắn, nhưng thiếu nó thì nghe như máy. */
  _breath(ms, sr) {
    const n = Math.max(1, Math.round(ms / 1000 * sr));
    const out = new Float32Array(n);
    const rnd = this.synth.rnd;
    let lp = 0;
    for (let i = 0; i < n; i++) {
      const noise = (rnd() - 0.5) * 2;
      lp = lp * 0.86 + noise * 0.14;                          // hơi là nhiễu trầm
      const env = Math.sin(Math.PI * (i / n)) ** 1.6;
      out[i] = lp * env * 0.11;
    }
    return out;
  }

  /**
   * Hát một câu.
   * @param {string} lyrics lời, các âm tiết cách nhau bởi dấu cách; "-" = luyến
   * @param {Array} notes danh sách nốt (có thể chứa dấu lặng)
   */
  sing(lyrics, notes, { breathAtRests = true } = {}) {
    const align = alignLyrics(lyrics, notes);
    const sr = SAMPLE_RATE;
    const sequence = notes.filter((n) => n.rest || n.midi != null);
    const chunks = [];
    const sung = [];
    let planIdx = 0;
    let prevHz = null;
    const unknown = [];

    for (const n of sequence) {
      if (n.rest) {
        const ms = n.ms;
        if (breathAtRests && ms >= 260) {
          const quiet = Math.max(0, ms - 180);
          chunks.push(new Float32Array(Math.round(quiet / 1000 * sr)));
          chunks.push(this._breath(Math.min(180, ms), sr));
        } else {
          chunks.push(new Float32Array(Math.round(ms / 1000 * sr)));
        }
        prevHz = null;                       // sau chỗ nghỉ thì không luyến
        continue;
      }

      const item = align.plan[planIdx++] || {};
      const syl = item.syllable;
      const hz = midiToFreq(n.midi);

      if (!syl) {                            // nốt không có lời: ngân bằng "a"
        const segs = this._stretch(segmentsOf(parseSyllable('a'), { rate: 1 }), n.ms);
        chunks.push(this._renderNote(segs, hz, prevHz, 'ngang', n.ms, sr));
        sung.push({ note: midiName(n.midi), ms: n.ms, syllable: '(ngân)', melisma: true });
        prevHz = hz;
        continue;
      }

      const parsed = parseSyllable(syl);
      if (!parsed.ok) {
        unknown.push(syl);
        chunks.push(new Float32Array(Math.round(n.ms / 1000 * sr)));
        continue;
      }
      const segs = this._stretch(segmentsOf(parsed, { rate: 1 }), n.ms);
      chunks.push(this._renderNote(segs, hz, item.melisma ? prevHz : prevHz, parsed.tone, n.ms, sr));
      sung.push({
        note: midiName(n.midi), hz: round(hz, 1), ms: n.ms,
        syllable: syl, tone: parsed.tone, melisma: !!item.melisma,
      });
      prevHz = hz;
    }

    const total = chunks.reduce((s, c) => s + c.length, 0);
    const out = new Float32Array(total);
    let o = 0;
    for (const c of chunks) { out.set(c, o); o += c.length; }

    // Chuẩn biên độ về mức an toàn — hậu kỳ sẽ lo phần độ vang.
    let peak = 0;
    for (let i = 0; i < out.length; i++) peak = Math.max(peak, Math.abs(out[i]));
    if (peak > 0) { const k = 0.82 / peak; for (let i = 0; i < out.length; i++) out[i] *= k; }

    return {
      ok: true,
      samples: out,
      sampleRate: sr,
      ms: Math.round(out.length / sr * 1000),
      style: this.style.id,
      styleName: this.style.name,
      notesSung: sung.length,
      sung,
      unknown,
      alignment: {
        ok: align.ok, syllables: align.syllables, notes: align.notes,
        melisma: align.melisma, warning: align.warning,
      },
    };
  }

  _renderNote(segs, hz, prevHz, toneName, noteMs, sr) {
    const curve = this._pitchCurve(hz, prevHz, toneName, noteMs);
    const raw = this.synth.renderSegments(segs, { f0Base: hz, f0At: curve });
    const env = this._envelope(raw.length, sr, this.style.attackMs, this.style.releaseMs);
    const out = new Float32Array(raw.length);
    for (let i = 0; i < raw.length; i++) out[i] = raw[i] * env[i];
    return out;
  }
}

/**
 * Đầu vào một cửa: lời + (ký âm chữ HOẶC tệp MIDI) → tiếng hát.
 * Trả về cả phần kiểm tra trước khi hát, để giao diện báo lỗi sớm.
 */
function prepare({ lyrics, melody = null, midi = null, bpm = 90, range = null, track = null, channel = null }) {
  let notes;
  let source;
  if (midi) {
    const m = parseMidi(midi);
    if (!m.ok) return { ok: false, error: m.error };
    const lead = extractLeadLine(m.notes, { track, channel });
    if (!lead.length) return { ok: false, error: 'TỆP_MIDI_KHÔNG_CÓ_NỐT_NÀO' };
    notes = withRests(lead);
    source = { kind: 'midi', bpm: m.bpm, tracks: m.tracks, totalNotes: m.notes.length, leadNotes: lead.length };
  } else if (melody) {
    const m = parseMelody(melody, { bpm });
    if (!m.ok) return { ok: false, error: 'KÝ_ÂM_SAI', errors: m.errors };
    notes = m.notes;
    source = { kind: 'ký âm chữ', bpm, notes: m.notes.length, beats: m.beats };
  } else {
    return { ok: false, error: 'THIẾU_GIAI_ĐIỆU', need: ['melody hoặc midi'] };
  }

  let shift = 0;
  let fit = null;
  if (range) {
    fit = fitToRange(notes, range);
    if (!fit.ok) return { ok: false, error: fit.error, detail: fit.detail };
    shift = fit.shift;
    if (shift) notes = notes.map((n) => (n.rest ? n : { ...n, midi: n.midi + shift, name: midiName(n.midi + shift) }));
  }

  const align = alignLyrics(lyrics, notes);
  return {
    ok: true, notes, source, align,
    transpose: shift, fit,
    totalMs: notes.reduce((s, n) => s + n.ms, 0),
  };
}

module.exports = { SingingVoice, STYLES, alignLyrics, prepare };
