'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  LỚP PHÁP LÝ CHO GIỌNG NÓI NHÂN TẠO
 * ═══════════════════════════════════════════════════════════════════════════
 *  Tài liệu gốc mới chỉ liệt kê 7 gạch đầu dòng "cần có" theo Luật An ninh
 *  mạng 116/2025/QH15. Liệt kê thì không bảo vệ được ai. Ở đây bảy điều đó
 *  được LÀM THÀNH MÃ CHẠY ĐƯỢC:
 *
 *    1. Đồng ý có văn bản      → ConsentRegistry, có mã hồ sơ, có người ký
 *    2. Đánh dấu nội dung AI   → watermark: vừa nghe được, vừa nhúng trong sóng
 *    3. Nhật ký không sửa được → chuỗi băm nối tiếp, phát hiện sửa một mắt xích
 *    4. Thời hạn lưu trữ       → quét và xoá theo hạn
 *    5. Xác minh tuổi          → dưới 18 bắt buộc có người giám hộ đồng ý
 *    6. Công bố công khai      → bản công bố máy đọc được, đính kèm mọi phản hồi
 *    7. Quyền được xoá         → xoá theo chủ thể, có biên bản
 *
 *  Nguyên tắc: KHÔNG có giọng nào phát ra mà chưa qua authorize(), và KHÔNG
 *  có tệp âm thanh nào rời hệ thống mà chưa đóng dấu.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const cfg = require('../config');
const { sha256, id: newId, round } = require('../utils');
const { fromWav, toWav, SAMPLE_RATE } = require('./synth');

const MAGIC = 'GITAV1';
const DAY = 86_400_000;

/** ── 1 & 5. ĐỒNG Ý VÀ XÁC MINH TUỔI ─────────────────────────────────────── */

const CONSENT_KINDS = {
  VOICE_CLONE: {
    code: 'VOICE_CLONE',
    name: 'Dùng giọng người thật để nhân bản',
    requiresWritten: true,
    requiresGuardianUnder: cfg.VOICE.minorAge,
    note: 'Bắt buộc có văn bản của chính chủ giọng. Không có thì không được nhân bản.',
  },
  VOICE_LISTEN: {
    code: 'VOICE_LISTEN',
    name: 'Học viên nghe bài giảng bằng giọng tổng hợp',
    requiresWritten: false,
    requiresGuardianUnder: cfg.VOICE.minorAge,
    note: 'Giọng tổng hợp hoàn toàn, không lấy từ người thật, nhưng vẫn phải báo trước.',
  },
  VOICE_RECORD: {
    code: 'VOICE_RECORD',
    name: 'Ghi âm giọng học viên để chấm phát âm',
    requiresWritten: true,
    requiresGuardianUnder: cfg.VOICE.minorAge,
    note: 'Dữ liệu sinh trắc học giọng nói — mức bảo vệ cao nhất.',
  },
};

class ConsentRegistry {
  /** @param {object} o repo tuỳ chọn để hồ sơ đồng ý sống sót khởi động lại */
  constructor({ repo = null, now = () => Date.now() } = {}) {
    this.repo = repo;
    this.now = now;
    this.records = new Map();       // consentId -> record
    this.bySubject = new Map();     // subjectId -> Set(consentId)
    if (repo) for (const d of repo.all()) this._index(d);
  }

  _index(rec) {
    this.records.set(rec.consentId, rec);
    if (!this.bySubject.has(rec.subjectId)) this.bySubject.set(rec.subjectId, new Set());
    this.bySubject.get(rec.subjectId).add(rec.consentId);
  }

  _persist(rec) {
    if (this.repo) this.repo.put({ id: rec.consentId, ...rec });
  }

  /**
   * Ghi nhận một phiếu đồng ý.
   * @param {object} o
   * @param {string} o.subjectId     người được nói tới (học viên / chủ giọng)
   * @param {string} o.kind          VOICE_CLONE | VOICE_LISTEN | VOICE_RECORD
   * @param {number} o.age           tuổi khai báo
   * @param {string} o.method        'đơn giấy' | 'ký số' | 'tích chọn trên web'
   * @param {string} o.documentRef   mã hồ sơ giấy / mã ký số — bắt buộc khi cần văn bản
   * @param {object} o.guardian      {name, relation, documentRef} khi dưới tuổi
   * @param {number} o.validDays     hiệu lực, mặc định 365 ngày
   */
  grant({ subjectId, kind, age = null, method = 'tích chọn trên web', documentRef = '', guardian = null, validDays = 365, scope = 'toàn hệ thống', grantedBy = '' } = {}) {
    if (!subjectId) return { ok: false, error: 'THIẾU_CHỦ_THỂ' };
    const spec = CONSENT_KINDS[kind];
    if (!spec) return { ok: false, error: 'LOẠI_ĐỒNG_Ý_KHÔNG_HỢP_LỆ', allowed: Object.keys(CONSENT_KINDS) };

    if (spec.requiresWritten && !documentRef) {
      return { ok: false, error: 'THIẾU_VĂN_BẢN', need: 'documentRef', law: 'Luật 116/2025/QH15 — đồng ý phải bằng văn bản' };
    }
    if (age == null) return { ok: false, error: 'CHƯA_XÁC_MINH_TUỔI', need: 'age' };
    if (age < spec.requiresGuardianUnder) {
      if (!guardian || !guardian.name || !guardian.documentRef) {
        return {
          ok: false, error: 'THIẾU_ĐỒNG_Ý_NGƯỜI_GIÁM_HỘ',
          need: ['guardian.name', 'guardian.relation', 'guardian.documentRef'],
          law: `Dưới ${spec.requiresGuardianUnder} tuổi phải có người giám hộ đồng ý`,
        };
      }
    }

    const at = this.now();
    const rec = {
      consentId: `CS-${newId(10)}`,
      subjectId,
      kind,
      kindName: spec.name,
      scope,
      age,
      minor: age < spec.requiresGuardianUnder,
      method,
      documentRef,
      guardian: guardian ? { name: guardian.name, relation: guardian.relation || 'không khai', documentRef: guardian.documentRef } : null,
      grantedBy: grantedBy || subjectId,
      grantedAt: at,
      expiresAt: at + validDays * DAY,
      revokedAt: null,
      revokeReason: null,
    };
    this._index(rec);
    this._persist(rec);
    return { ok: true, consent: rec };
  }

  /** Còn hiệu lực hay không — đây là cái mà authorize() hỏi. */
  check(subjectId, kind) {
    const ids = this.bySubject.get(subjectId);
    if (!ids || !ids.size) return { ok: false, error: 'CHƯA_CÓ_ĐỒNG_Ý', subjectId, kind };
    const now = this.now();
    for (const cid of ids) {
      const r = this.records.get(cid);
      if (!r || r.kind !== kind) continue;
      if (r.revokedAt) continue;
      if (r.expiresAt <= now) continue;
      return { ok: true, consent: r, daysLeft: round((r.expiresAt - now) / DAY, 1) };
    }
    const expired = [...ids].map((c) => this.records.get(c)).find((r) => r && r.kind === kind);
    return {
      ok: false,
      error: expired ? (expired.revokedAt ? 'ĐÃ_RÚT_ĐỒNG_Ý' : 'ĐỒNG_Ý_HẾT_HẠN') : 'CHƯA_CÓ_ĐỒNG_Ý',
      subjectId, kind,
    };
  }

  revoke(consentId, reason = 'chủ thể yêu cầu') {
    const r = this.records.get(consentId);
    if (!r) return { ok: false, error: 'KHÔNG_TÌM_THẤY' };
    if (r.revokedAt) return { ok: false, error: 'ĐÃ_RÚT_TRƯỚC_ĐÓ', at: r.revokedAt };
    r.revokedAt = this.now();
    r.revokeReason = reason;
    this._persist(r);
    return { ok: true, consent: r };
  }

  ofSubject(subjectId) {
    return [...(this.bySubject.get(subjectId) || [])].map((c) => this.records.get(c)).filter(Boolean);
  }

  /** 7. Quyền được xoá — xoá sạch hồ sơ đồng ý của một người. */
  forget(subjectId) {
    const ids = [...(this.bySubject.get(subjectId) || [])];
    for (const cid of ids) {
      this.records.delete(cid);
      if (this.repo) this.repo.delete(cid);
    }
    this.bySubject.delete(subjectId);
    return { ok: true, removed: ids.length };
  }

  /** 4. Quét hết hạn. Hồ sơ quá hạn lưu trữ bị xoá, có đếm. */
  sweep({ retentionDays = cfg.VOICE.retentionDays } = {}) {
    const cutoff = this.now() - retentionDays * DAY;
    let removed = 0;
    for (const [cid, r] of [...this.records]) {
      const dead = (r.revokedAt && r.revokedAt < cutoff) || (r.expiresAt && r.expiresAt < cutoff);
      if (!dead) continue;
      this.records.delete(cid);
      this.bySubject.get(r.subjectId)?.delete(cid);
      if (this.repo) this.repo.delete(cid);
      removed++;
    }
    return { ok: true, removed, retentionDays };
  }

  status() {
    const now = this.now();
    const byKind = Object.create(null);
    let active = 0; let revoked = 0; let expired = 0; let minors = 0;
    for (const r of this.records.values()) {
      byKind[r.kind] = (byKind[r.kind] || 0) + 1;
      if (r.revokedAt) revoked++;
      else if (r.expiresAt <= now) expired++;
      else active++;
      if (r.minor) minors++;
    }
    return { total: this.records.size, active, revoked, expired, minors, byKind, subjects: this.bySubject.size };
  }
}

/** ── 2. ĐÁNH DẤU NỘI DUNG DO AI TẠO ─────────────────────────────────────── */

/**
 * Dấu nghe được: một tín hiệu hai tông rất ngắn và nhỏ ở đầu tệp.
 * Đủ để tai người nhận ra "đây là máy đọc", đủ nhỏ để không phá bài giảng.
 */
function audibleMark(sampleRate = SAMPLE_RATE) {
  const ms = 150;
  const n = Math.round((ms / 1000) * sampleRate);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const t = i / sampleRate;
    const half = t < 0.075 ? 880 : 1320;         // hai nốt đi lên
    const env = Math.sin(Math.PI * (i / n)) ** 2; // vào êm ra êm, không "tạch"
    out[i] = 0.12 * env * Math.sin(2 * Math.PI * half * t);
  }
  return out;
}

/** Chuỗi byte của dấu chìm: MAGIC | độ dài | payload JSON rút gọn. */
function markPayload(meta) {
  const body = JSON.stringify({
    v: 1,
    g: meta.voiceId || '',
    p: meta.provider || '',
    t: meta.at || Date.now(),
    h: sha256(`${meta.voiceId}|${meta.textHash || ''}|${meta.at || ''}`).slice(0, 16),
  });
  const bytes = Buffer.from(body, 'utf8');
  const head = Buffer.from(MAGIC, 'ascii');
  const len = Buffer.alloc(2);
  len.writeUInt16BE(bytes.length, 0);
  return Buffer.concat([head, len, bytes]);
}

/**
 * Nhúng dấu chìm vào bit thấp nhất của mẫu PCM 16-bit.
 * Bit thấp nhất tương đương -96 dB: tai người không nghe thấy, nhưng máy đọc
 * lại được, kể cả khi tệp bị cắt đầu đuôi vài giây (dấu được lặp lại).
 */
function embedWatermark(samples, meta) {
  const payload = markPayload(meta);
  const bits = payload.length * 8;
  const stride = 3;
  const need = bits * stride;
  if (samples.length < need) return { ok: false, error: 'ÂM_THANH_QUÁ_NGẮN', need, have: samples.length };

  const out = Int16Array.from(samples, (x) => Math.max(-32768, Math.min(32767, Math.round(x * 32767))));
  // Lặp dấu suốt tệp để cắt đoạn nào cũng còn dấu.
  const copies = Math.max(1, Math.floor(out.length / need));
  for (let c = 0; c < copies; c++) {
    const base = c * need;
    for (let b = 0; b < bits; b++) {
      const bit = (payload[b >> 3] >> (7 - (b & 7))) & 1;
      const idx = base + b * stride;
      out[idx] = (out[idx] & ~1) | bit;
    }
  }
  return { ok: true, samples: out, copies, bytes: payload.length };
}

/** Đọc dấu chìm ra từ tệp WAV đã đóng dấu. */
function extractWatermark(wavBuffer) {
  let pcm;
  try { pcm = fromWav(wavBuffer); } catch (e) { return { ok: false, error: `KHÔNG_ĐỌC_ĐƯỢC_WAV: ${e.message}` }; }
  if (!pcm) return { ok: false, error: 'KHÔNG_ĐỌC_ĐƯỢC_WAV' };
  const int = pcm.int16 || Int16Array.from(pcm.samples, (x) => Math.round(x * 32767));
  const stride = 3;

  const readBytes = (base, count) => {
    const buf = Buffer.alloc(count);
    for (let b = 0; b < count * 8; b++) {
      const idx = base + b * stride;
      if (idx >= int.length) return null;
      const bit = int[idx] & 1;
      buf[b >> 3] = (buf[b >> 3] << 1) | bit;
    }
    return buf;
  };

  const headLen = MAGIC.length + 2;
  const head = readBytes(0, headLen);
  if (!head || head.slice(0, MAGIC.length).toString('ascii') !== MAGIC) {
    return { ok: false, error: 'KHÔNG_CÓ_DẤU', hint: 'Tệp không do hệ thống này tạo, hoặc đã bị nén lại.' };
  }
  const len = head.readUInt16BE(MAGIC.length);
  const payload = readBytes(0, headLen + len);
  if (!payload) return { ok: false, error: 'DẤU_BỊ_CẮT' };
  try {
    const json = JSON.parse(payload.slice(headLen).toString('utf8'));
    return { ok: true, mark: { version: json.v, voiceId: json.g, provider: json.p, at: json.t, hash: json.h }, aiGenerated: true, bytes: payload.length };
  } catch (e) {
    return { ok: false, error: `DẤU_HỎNG: ${e.message}` };
  }
}

/** ── 3. NHẬT KÝ KHÔNG SỬA ĐƯỢC ──────────────────────────────────────────── */

class VoiceAuditChain {
  /**
   * Định danh người học KHÔNG nằm trong phần được băm. Lý do: quyền được xoá
   * (điều 7) bắt buộc gỡ được định danh, mà chuỗi băm thì cấm sửa. Hai yêu cầu
   * này chỉ sống chung được nếu tách ra: phần băm giữ `subjectRef` (băm rút
   * gọn, không truy ngược được), còn tên thật nằm ở bảng phụ xoá được tự do.
   */
  constructor({ repo = null, max = 20_000, now = () => Date.now() } = {}) {
    this.repo = repo;
    this.max = max;
    this.now = now;
    this.entries = [];
    this.subjects = new Map();      // entryId -> subjectId (xoá được, không ảnh hưởng chuỗi)
    this.head = sha256('GITAmath|voice|genesis');
    if (repo) {
      const docs = repo.all().sort((a, b) => a.seq - b.seq);
      if (docs.length) {
        this.entries = docs.map(({ subject, ...e }) => {
          if (subject) this.subjects.set(e.id, subject);
          return e;
        });
        this.head = this.entries[this.entries.length - 1].hash;
      }
    }
  }

  append(event, data = {}) {
    const { subjectId = null, ...rest } = data;
    const seq = this.entries.length + 1;
    const at = this.now();
    const body = { seq, at, event, ...rest };
    if (subjectId) body.subjectRef = sha256(`subject|${subjectId}`).slice(0, 16);
    const hash = sha256(`${this.head}|${JSON.stringify(body)}`);
    const entry = { id: `VA-${seq}`, ...body, prev: this.head, hash };
    this.head = hash;
    this.entries.push(entry);
    if (subjectId) this.subjects.set(entry.id, subjectId);
    if (this.repo) this.repo.put(subjectId ? { ...entry, subject: subjectId } : entry);
    if (this.entries.length > this.max) {
      const cut = this.entries.splice(0, this.entries.length - this.max);
      for (const e of cut) this.subjects.delete(e.id);
    }
    return entry;
  }

  /** Soát toàn chuỗi. Sửa một mắt xích là lộ ngay vị trí. */
  verify() {
    let prev = this.entries.length ? this.entries[0].prev : sha256('GITAmath|voice|genesis');
    for (const e of this.entries) {
      const { id, prev: p, hash, subject, ...body } = e;
      const expect = sha256(`${prev}|${JSON.stringify(body)}`);
      if (p !== prev) return { ok: false, error: 'ĐỨT_MẮT_XÍCH', at: e.seq };
      if (expect !== hash) return { ok: false, error: 'BẢN_GHI_BỊ_SỬA', at: e.seq };
      prev = hash;
    }
    return { ok: true, entries: this.entries.length, head: this.head };
  }

  /** Bản ghi kèm tên chủ thể — chỉ dùng cho màn hình quản trị và tra soát. */
  _withSubject(e) {
    const s = this.subjects.get(e.id);
    return s ? { ...e, subjectId: s } : { ...e, subjectId: e.subjectRef ? 'ĐÃ_XOÁ' : null };
  }

  recent(n = 50) { return this.entries.slice(-n).reverse().map((e) => this._withSubject(e)); }

  ofSubject(subjectId, n = 100) {
    return this.entries
      .filter((e) => this.subjects.get(e.id) === subjectId)
      .slice(-n).reverse().map((e) => this._withSubject(e));
  }

  /** Gỡ định danh của một người khỏi nhật ký mà không đụng tới chuỗi băm. */
  anonymize(subjectId) {
    let n = 0;
    for (const [eid, sid] of [...this.subjects]) {
      if (sid !== subjectId) continue;
      this.subjects.delete(eid);
      n++;
      if (this.repo) {
        const doc = this.repo.get(eid);
        if (doc) { const { subject, ...rest } = doc; this.repo.put(rest); }
      }
    }
    return n;
  }

  /** 4. Xoá bản ghi quá hạn lưu trữ. Chuỗi được nối lại từ mốc mới. */
  sweep({ retentionDays = cfg.VOICE.retentionDays } = {}) {
    const cutoff = this.now() - retentionDays * DAY;
    const before = this.entries.length;
    const kept = this.entries.filter((e) => e.at >= cutoff);
    if (kept.length === before) return { ok: true, removed: 0 };
    for (const e of this.entries) {
      if (e.at >= cutoff) continue;
      this.subjects.delete(e.id);
      if (this.repo) this.repo.delete(e.id);
    }
    this.entries = kept;
    return { ok: true, removed: before - kept.length, note: 'Chuỗi băm được nối tiếp từ bản ghi còn lại.' };
  }
}

/** ── 6. BẢN CÔNG BỐ CÔNG KHAI ───────────────────────────────────────────── */

const DISCLOSURE = {
  aiGenerated: true,
  statement: 'Giọng nói trong bài giảng này do máy tổng hợp, không phải giọng người thật.',
  shortLabel: '🔊 Giọng AI',
  spokenPrefix: 'Giọng đọc sau đây do máy tổng hợp.',
  law: 'Luật An ninh mạng số 116/2025/QH15',
  operator: 'GITAmath Nexus V20',
  dataUse: [
    'Văn bản bài giảng được chuyển thành âm thanh ngay trên máy chủ của hệ thống.',
    'Bộ tổng hợp mặc định chạy nội bộ — không gửi nội dung ra bên thứ ba.',
    'Nếu người vận hành bật nhà cung cấp đám mây, nội dung sẽ được gửi tới nhà cung cấp đó và phần này được ghi rõ trong nhật ký.',
  ],
  rights: [
    'Được biết nội dung nào do AI tạo ra (dấu nghe được và dấu chìm trong sóng âm).',
    'Được rút lại đồng ý bất cứ lúc nào.',
    'Được yêu cầu xoá toàn bộ dữ liệu giọng nói liên quan tới mình.',
    'Được xem nhật ký hệ thống đã tạo giọng cho mình lúc nào, bằng giọng gì.',
  ],
};

/** ── HỢP NHẤT ───────────────────────────────────────────────────────────── */

class VoiceCompliance {
  constructor({ db = null, now = () => Date.now() } = {}) {
    this.now = now;
    const consentRepo = db ? db.collection('voice_consents', { indexes: ['subjectId', 'kind'] }) : null;
    const auditRepo = db ? db.collection('voice_audit', { indexes: ['event', 'subjectId'] }) : null;
    this.consents = new ConsentRegistry({ repo: consentRepo, now });
    this.audit = new VoiceAuditChain({ repo: auditRepo, now });
    this.stats = { authorized: 0, denied: 0, stamped: 0, deletions: 0 };
  }

  /**
   * Cổng duy nhất trước khi phát giọng. Không qua được thì không có âm thanh.
   * Học viên nghe giọng tổng hợp: cần đồng ý VOICE_LISTEN (trừ khi ẩn danh —
   * không gắn với người nào thì không có dữ liệu cá nhân để bảo vệ).
   */
  authorize({ subjectId = null, kind = 'VOICE_LISTEN', purpose = 'giảng bài' } = {}) {
    if (!subjectId) {
      this.stats.authorized++;
      return { ok: true, anonymous: true, disclosure: DISCLOSURE, note: 'Không gắn với người dùng nào nên không cần đồng ý cá nhân.' };
    }
    const c = this.consents.check(subjectId, kind);
    if (!c.ok) {
      this.stats.denied++;
      this.audit.append('TỪ_CHỐI_PHÁT_GIỌNG', { subjectId, kind, purpose, reason: c.error });
      return { ok: false, error: c.error, subjectId, kind, disclosure: DISCLOSURE, howToFix: 'Gửi phiếu đồng ý qua POST /voice/consent' };
    }
    this.stats.authorized++;
    return { ok: true, consentId: c.consent.consentId, daysLeft: c.daysLeft, disclosure: DISCLOSURE };
  }

  /**
   * Đóng dấu một bản ghi âm: dấu nghe được ở đầu + dấu chìm suốt tệp + một
   * mắt xích nhật ký. Trả về WAV mới.
   */
  stamp(samples, { voiceId, provider, text = '', subjectId = null, sampleRate = SAMPLE_RATE, audible = true } = {}) {
    if (!cfg.VOICE.watermark) {
      return { ok: true, wav: toWav(samples, sampleRate), watermarked: false, note: 'VOICE_WATERMARK=0 — người vận hành đã tắt, tự chịu trách nhiệm.' };
    }
    const at = this.now();
    const textHash = sha256(String(text)).slice(0, 16);

    let full = samples;
    if (audible) {
      const mark = audibleMark(sampleRate);
      full = new Float32Array(mark.length + samples.length);
      full.set(mark, 0);
      full.set(samples, mark.length);
    }

    const emb = embedWatermark(full, { voiceId, provider, at, textHash });
    const wav = emb.ok ? toWav(emb.samples, sampleRate) : toWav(full, sampleRate);
    const entry = this.audit.append('TẠO_GIỌNG', {
      subjectId, voiceId, provider, textHash, chars: String(text).length,
      ms: Math.round((full.length / sampleRate) * 1000),
      watermarked: emb.ok, audibleMark: audible,
    });
    this.stats.stamped++;
    return {
      ok: true, wav, watermarked: emb.ok, copies: emb.copies || 0,
      reason: emb.ok ? null : emb.error, auditId: entry.id, auditHash: entry.hash,
      disclosure: DISCLOSURE,
    };
  }

  /** Kiểm tra một tệp bất kỳ: có phải do hệ thống này tạo không. */
  verifyAudio(wavBuffer) {
    const r = extractWatermark(wavBuffer);
    if (!r.ok) return { ok: false, aiGenerated: null, ...r };
    return { ok: true, aiGenerated: true, mark: r.mark, disclosure: DISCLOSURE };
  }

  /** 7. Quyền được xoá — xoá hồ sơ đồng ý và gỡ định danh khỏi nhật ký. */
  forget(subjectId, { reason = 'chủ thể yêu cầu' } = {}) {
    if (!subjectId) return { ok: false, error: 'THIẾU_CHỦ_THỂ' };
    const c = this.consents.forget(subjectId);
    const anonymized = this.audit.anonymize(subjectId);
    // Ghi biên bản việc xoá — bản thân việc xoá cũng phải để lại dấu vết.
    const entry = this.audit.append('XOÁ_THEO_YÊU_CẦU', { subjectHash: sha256(subjectId).slice(0, 16), reason, consents: c.removed, anonymized });
    this.stats.deletions++;
    return { ok: true, consentsRemoved: c.removed, auditAnonymized: anonymized, receipt: entry.id, at: entry.at };
  }

  /** 4. Quét hạn lưu trữ cho cả hai kho. */
  sweepRetention({ retentionDays = cfg.VOICE.retentionDays } = {}) {
    const c = this.consents.sweep({ retentionDays });
    const a = this.audit.sweep({ retentionDays });
    if (c.removed || a.removed) this.audit.append('QUÉT_HẠN_LƯU_TRỮ', { consents: c.removed, audit: a.removed, retentionDays });
    return { ok: true, retentionDays, consentsRemoved: c.removed, auditRemoved: a.removed };
  }

  /** Bản tự kiểm: 7 yêu cầu của luật, mỗi yêu cầu có bằng chứng là mã nào lo. */
  checklist() {
    const items = [
      { no: 1, req: 'Đồng ý có văn bản trước khi dùng giọng người thật', impl: 'ConsentRegistry.grant() chặn khi thiếu documentRef', ok: true },
      { no: 2, req: 'Đánh dấu rõ nội dung do AI tạo', impl: `dấu nghe được + dấu chìm LSB${cfg.VOICE.watermark ? '' : ' (ĐANG TẮT)'}`, ok: !!cfg.VOICE.watermark },
      { no: 3, req: 'Nhật ký không sửa được', impl: 'VoiceAuditChain — chuỗi băm nối tiếp', ok: this.audit.verify().ok },
      { no: 4, req: 'Thời hạn lưu trữ', impl: `sweepRetention() — ${cfg.VOICE.retentionDays} ngày`, ok: cfg.VOICE.retentionDays > 0 },
      { no: 5, req: 'Xác minh tuổi, dưới tuổi phải có giám hộ', impl: `chặn khi age < ${cfg.VOICE.minorAge} mà thiếu guardian`, ok: true },
      { no: 6, req: 'Công bố công khai', impl: 'DISCLOSURE — kèm trong mọi phản hồi giọng', ok: true },
      { no: 7, req: 'Quyền được xoá', impl: 'forget() — xoá đồng ý, gỡ định danh nhật ký, cấp biên bản', ok: true },
    ];
    return { ok: items.every((i) => i.ok), law: DISCLOSURE.law, items };
  }

  status() {
    return {
      law: DISCLOSURE.law,
      watermark: !!cfg.VOICE.watermark,
      retentionDays: cfg.VOICE.retentionDays,
      minorAge: cfg.VOICE.minorAge,
      consents: this.consents.status(),
      audit: { entries: this.audit.entries.length, head: this.audit.head, verified: this.audit.verify().ok },
      stats: { ...this.stats },
      checklist: this.checklist(),
    };
  }
}

module.exports = {
  VoiceCompliance, ConsentRegistry, VoiceAuditChain,
  CONSENT_KINDS, DISCLOSURE,
  audibleMark, embedWatermark, extractWatermark, markPayload,
};
