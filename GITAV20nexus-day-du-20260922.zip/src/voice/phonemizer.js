'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  ÂM VỊ HỌC TIẾNG VIỆT — tách chữ viết thành âm để tổng hợp giọng nói
 * ═══════════════════════════════════════════════════════════════════════════
 *  Tiếng Việt là ngôn ngữ ĐƠN ÂM TIẾT CÓ THANH ĐIỆU. Mỗi âm tiết có cấu trúc:
 *
 *      [âm đầu]  [âm đệm]  ÂM CHÍNH  [âm cuối]  +  THANH ĐIỆU
 *         ng        u          y         ên          huyền     → "nguyền"
 *
 *  Muốn máy đọc đúng tiếng Việt thì phải tách được đúng năm thành phần này.
 *  Đọc sai thanh điệu là đổi nghĩa hoàn toàn: "ma · má · mà · mả · mã · mạ".
 *
 *  Bảng dưới đây biên soạn tay theo ngữ âm tiếng Việt chuẩn (giọng Bắc), có
 *  xử lý các quy tắc chính tả rắc rối:
 *    · c / k / q      cùng một âm /k/, khác nhau ở chữ viết
 *    · g / gh         cùng âm /ɣ/;  ng / ngh cùng âm /ŋ/
 *    · gi             là /z/ chứ không phải /g/+/i/
 *    · ia/iê/yê/ya    cùng một nguyên âm đôi /iə/
 *    · ua/uô, ưa/ươ   tương tự
 *    · dấu thanh đặt ở âm chính, phải bóc ra trước khi tách vần
 * ═══════════════════════════════════════════════════════════════════════════
 */

// ── Thanh điệu ──────────────────────────────────────────────────────────────
// contour = đường đi của cao độ, tính theo hệ số nhân với cao độ nền (F0).
// Lấy theo mô tả ngữ âm giọng Bắc: ngang bằng, huyền thấp xuống, sắc lên cao,
// hỏi võng xuống rồi lên, ngã gãy giữa, nặng rơi nhanh rồi tắt.
const TONES = {
  ngang: { id: 0, name: 'ngang', mark: '', contour: [1.00, 1.01, 1.00, 0.99], length: 1.00, glottal: false },
  huyen: { id: 1, name: 'huyền', mark: '̀', contour: [0.92, 0.86, 0.80, 0.76], length: 1.05, glottal: false },
  sac: { id: 2, name: 'sắc', mark: '́', contour: [1.00, 1.10, 1.24, 1.34], length: 0.92, glottal: false },
  hoi: { id: 3, name: 'hỏi', mark: '̉', contour: [0.98, 0.86, 0.82, 0.96], length: 1.12, glottal: false },
  nga: { id: 4, name: 'ngã', mark: '̃', contour: [1.00, 0.92, 1.18, 1.32], length: 1.05, glottal: true },
  nang: { id: 5, name: 'nặng', mark: '̣', contour: [0.94, 0.84, 0.72, 0.66], length: 0.72, glottal: true },
};
const TONE_BY_MARK = Object.fromEntries(Object.values(TONES).filter((t) => t.mark).map((t) => [t.mark, t]));

// ── Âm đầu (phụ âm đầu) ─────────────────────────────────────────────────────
// type: stop (tắc) · fricative (xát) · nasal (mũi) · liquid (nước) · affricate
const INITIALS = {
  b: { ipa: 'ɓ', type: 'stop', voiced: true, place: 'labial' },
  ch: { ipa: 'c', type: 'stop', voiced: false, place: 'palatal' },
  d: { ipa: 'z', type: 'fricative', voiced: true, place: 'alveolar' },
  đ: { ipa: 'ɗ', type: 'stop', voiced: true, place: 'alveolar' },
  g: { ipa: 'ɣ', type: 'fricative', voiced: true, place: 'velar' },
  gh: { ipa: 'ɣ', type: 'fricative', voiced: true, place: 'velar' },
  gi: { ipa: 'z', type: 'fricative', voiced: true, place: 'alveolar' },
  h: { ipa: 'h', type: 'fricative', voiced: false, place: 'glottal' },
  k: { ipa: 'k', type: 'stop', voiced: false, place: 'velar' },
  kh: { ipa: 'x', type: 'fricative', voiced: false, place: 'velar' },
  l: { ipa: 'l', type: 'liquid', voiced: true, place: 'alveolar' },
  m: { ipa: 'm', type: 'nasal', voiced: true, place: 'labial' },
  n: { ipa: 'n', type: 'nasal', voiced: true, place: 'alveolar' },
  ng: { ipa: 'ŋ', type: 'nasal', voiced: true, place: 'velar' },
  ngh: { ipa: 'ŋ', type: 'nasal', voiced: true, place: 'velar' },
  nh: { ipa: 'ɲ', type: 'nasal', voiced: true, place: 'palatal' },
  p: { ipa: 'p', type: 'stop', voiced: false, place: 'labial' },
  ph: { ipa: 'f', type: 'fricative', voiced: false, place: 'labial' },
  q: { ipa: 'k', type: 'stop', voiced: false, place: 'velar' },
  r: { ipa: 'z', type: 'fricative', voiced: true, place: 'alveolar' },
  s: { ipa: 's', type: 'fricative', voiced: false, place: 'alveolar' },
  t: { ipa: 't', type: 'stop', voiced: false, place: 'alveolar' },
  th: { ipa: 'tʰ', type: 'stop', voiced: false, place: 'alveolar', aspirated: true },
  tr: { ipa: 'ʈ', type: 'stop', voiced: false, place: 'retroflex' },
  v: { ipa: 'v', type: 'fricative', voiced: true, place: 'labial' },
  x: { ipa: 's', type: 'fricative', voiced: false, place: 'alveolar' },
  c: { ipa: 'k', type: 'stop', voiced: false, place: 'velar' },
};
// Xét âm đầu dài trước âm đầu ngắn: "ngh" phải thử trước "ng" trước "n".
const INITIAL_ORDER = Object.keys(INITIALS).sort((a, b) => b.length - a.length);

// ── Âm chính (nguyên âm) ────────────────────────────────────────────────────
// f1/f2 = hai formant đầu tiên (Hz) của giọng nam chuẩn. Đây là thứ quyết định
// người nghe nhận ra đó là nguyên âm nào.
const VOWELS = {
  i: { ipa: 'i', f1: 300, f2: 2280, f3: 3000, long: true },
  y: { ipa: 'i', f1: 300, f2: 2280, f3: 3000, long: true },
  ê: { ipa: 'e', f1: 410, f2: 2050, f3: 2800, long: true },
  e: { ipa: 'ɛ', f1: 560, f2: 1900, f3: 2600, long: true },
  ư: { ipa: 'ɯ', f1: 350, f2: 1350, f3: 2400, long: true },
  ơ: { ipa: 'ɤ', f1: 540, f2: 1160, f3: 2400, long: true },
  â: { ipa: 'ɤ̆', f1: 570, f2: 1200, f3: 2400, long: false },
  a: { ipa: 'aː', f1: 800, f2: 1320, f3: 2500, long: true },
  ă: { ipa: 'a', f1: 760, f2: 1360, f3: 2500, long: false },
  u: { ipa: 'u', f1: 320, f2: 720, f3: 2300, long: true },
  ô: { ipa: 'o', f1: 450, f2: 820, f3: 2350, long: true },
  o: { ipa: 'ɔ', f1: 580, f2: 900, f3: 2400, long: true },
};

// ── Nguyên âm đôi ───────────────────────────────────────────────────────────
// Ba nguyên âm đôi thật của tiếng Việt, viết bằng nhiều cách khác nhau.
const DIPHTHONGS = {
  iê: ['i', 'ê'], ia: ['i', 'ơ'], yê: ['i', 'ê'], ya: ['i', 'ơ'],
  uô: ['u', 'ô'], ua: ['u', 'ơ'],
  ươ: ['ư', 'ơ'], ưa: ['ư', 'ơ'],
};

// ── Âm cuối ─────────────────────────────────────────────────────────────────
const FINALS = {
  m: { ipa: 'm', type: 'nasal', place: 'labial' },
  n: { ipa: 'n', type: 'nasal', place: 'alveolar' },
  ng: { ipa: 'ŋ', type: 'nasal', place: 'velar' },
  nh: { ipa: 'ɲ', type: 'nasal', place: 'palatal' },
  p: { ipa: 'p', type: 'stop', place: 'labial' },
  t: { ipa: 't', type: 'stop', place: 'alveolar' },
  c: { ipa: 'k', type: 'stop', place: 'velar' },
  ch: { ipa: 'k', type: 'stop', place: 'palatal' },
  i: { ipa: 'j', type: 'glide', place: 'palatal' },
  y: { ipa: 'j', type: 'glide', place: 'palatal' },
  o: { ipa: 'w', type: 'glide', place: 'labial' },
  u: { ipa: 'w', type: 'glide', place: 'labial' },
};
const FINAL_ORDER = Object.keys(FINALS).sort((a, b) => b.length - a.length);

/** Bóc dấu thanh khỏi chữ, trả về chữ trần và thanh điệu. */
function stripTone(syllable) {
  const nfd = syllable.normalize('NFD');
  let tone = TONES.ngang;
  let out = '';
  for (const ch of nfd) {
    if (TONE_BY_MARK[ch]) { tone = TONE_BY_MARK[ch]; continue; }
    out += ch;
  }
  // Giữ lại dấu phụ của chữ cái (ă â ê ô ơ ư đ) — đó là phần của nguyên âm,
  // không phải dấu thanh.
  return { base: out.normalize('NFC'), tone };
}

/**
 * Tách một âm tiết thành năm thành phần.
 * @returns {{ok, initial, glide, nucleus, coda, tone, syllable}|{ok:false}}
 */
function parseSyllable(raw) {
  const text = String(raw || '').toLowerCase().trim();
  if (!text) return { ok: false, error: 'EMPTY' };
  const { base, tone } = stripTone(text);
  if (!/^[a-zđăâêôơư]+$/.test(base)) return { ok: false, error: 'NOT_VIETNAMESE', text: base };

  let rest = base;

  // 1. Âm đầu — thử chuỗi dài trước.
  let initial = null;
  for (const k of INITIAL_ORDER) {
    if (!rest.startsWith(k)) continue;
    // "gi" chỉ là âm đầu khi còn phần vần phía sau ("gia" ✓, "gi" → g + i).
    if (k === 'gi' && rest.length === 2) continue;
    // "qu" luôn đi liền: q + âm đệm u.
    if (k === 'q' && rest[1] !== 'u') continue;
    initial = k;
    rest = rest.slice(k.length);
    break;
  }

  // 2. Âm đệm /w/: sau q luôn có u; ngoài ra o/u đứng trước nguyên âm mở.
  let glide = null;
  if (initial === 'q' && rest.startsWith('u')) { glide = 'u'; rest = rest.slice(1); }
  // "u" chỉ là âm đệm trước â ê y ơ (tuân, tuế, tuy, thuở). Trước a và e thì
  // "ua", "ưa" là NGUYÊN ÂM ĐÔI: "của" đọc là c-uả chứ không phải c-u-ả, và
  // dấu thanh của nó cũng rơi vào chữ u chứ không phải chữ a.
  else if (/^u[yêâơ]/.test(rest) && initial !== 'g') { glide = 'u'; rest = rest.slice(1); }
  else if (/^o[aăe]/.test(rest)) { glide = 'o'; rest = rest.slice(1); }

  if (!rest) return { ok: false, error: 'NO_NUCLEUS', text: base };

  // 3. Âm cuối — thử chuỗi dài trước, nhưng phải chừa lại ít nhất một nguyên âm.
  let coda = null;
  for (const k of FINAL_ORDER) {
    if (!rest.endsWith(k)) continue;
    const head = rest.slice(0, rest.length - k.length);
    if (!head) continue;                       // không được ăn hết nguyên âm
    if (!/[aăâeêioôơuưy]/.test(head)) continue; // phần còn lại phải có nguyên âm
    coda = k;
    rest = head;
    break;
  }

  // 4. Âm chính: phần còn lại. Có thể là nguyên âm đơn hoặc đôi.
  const nucleusText = rest;
  if (!nucleusText) return { ok: false, error: 'NO_NUCLEUS', text: base };

  let nucleus;
  if (DIPHTHONGS[nucleusText]) {
    nucleus = { text: nucleusText, kind: 'diphthong', parts: DIPHTHONGS[nucleusText] };
  } else if (VOWELS[nucleusText]) {
    nucleus = { text: nucleusText, kind: 'mono', parts: [nucleusText] };
  } else if (nucleusText.length === 2 && VOWELS[nucleusText[0]] && VOWELS[nucleusText[1]]) {
    // Hai nguyên âm không phải nguyên âm đôi chuẩn: đọc lướt từ âm đầu sang âm sau.
    nucleus = { text: nucleusText, kind: 'sequence', parts: [nucleusText[0], nucleusText[1]] };
  } else {
    return { ok: false, error: 'UNKNOWN_NUCLEUS', text: base, nucleus: nucleusText };
  }

  return {
    ok: true,
    syllable: text,
    base,
    initial,
    glide,
    nucleus,
    coda,
    tone: tone.name,
    toneId: tone.id,
  };
}

/**
 * Chuyển một âm tiết thành chuỗi ĐOẠN ÂM để bộ tổng hợp phát.
 * Mỗi đoạn: { kind, key, ms, ...tham số âm học }
 */
function segmentsOf(parsed, { rate = 1.0 } = {}) {
  if (!parsed.ok) return [];
  const tone = TONES[Object.keys(TONES).find((k) => TONES[k].name === parsed.tone)] || TONES.ngang;
  const segs = [];
  const scale = 1 / Math.max(0.4, rate);

  // Âm đầu
  if (parsed.initial) {
    const ini = INITIALS[parsed.initial];
    const ms = ini.type === 'stop' ? (ini.aspirated ? 78 : 58)
      : ini.type === 'fricative' ? 92
        : ini.type === 'nasal' ? 68 : 52;
    segs.push({ kind: 'consonant', role: 'initial', key: parsed.initial, ...ini, ms: ms * scale });
  }

  // Âm đệm
  if (parsed.glide) {
    segs.push({ kind: 'glide', role: 'glide', key: parsed.glide, f1: 340, f2: 760, f3: 2300, ms: 46 * scale });
  }

  // Âm chính — chia thành các chặng để vẽ được đường thanh điệu.
  const nucleusMs = (parsed.nucleus.kind === 'mono'
    ? (VOWELS[parsed.nucleus.parts[0]]?.long ? 190 : 130)
    : 215) * tone.length * scale;
  const parts = parsed.nucleus.parts;
  const each = nucleusMs / parts.length;
  parts.forEach((p, i) => {
    const v = VOWELS[p] || VOWELS.a;
    segs.push({
      kind: 'vowel', role: 'nucleus', key: p, ...v,
      ms: each,
      tonePhase: [i / parts.length, (i + 1) / parts.length],
    });
  });

  // Âm cuối
  if (parsed.coda) {
    const f = FINALS[parsed.coda];
    const ms = f.type === 'stop' ? 42 : f.type === 'glide' ? 62 : 86;
    segs.push({ kind: 'consonant', role: 'coda', key: parsed.coda, ...f, ms: ms * scale });
  }

  return segs.map((s) => ({ ...s, tone: tone.name, toneContour: tone.contour, glottal: tone.glottal }));
}

/** Tách một câu thành các âm tiết và dấu câu. */
function tokenize(text) {
  const out = [];
  const re = /([A-Za-zÀ-ỹĐđ]+)|([0-9]+)|([,;:.!?…—–-])|(\s+)/g;
  let m;
  while ((m = re.exec(String(text || ''))) !== null) {
    if (m[1]) out.push({ type: 'word', text: m[1] });
    else if (m[2]) out.push({ type: 'number', text: m[2] });
    else if (m[3]) out.push({ type: 'punct', text: m[3] });
    else out.push({ type: 'space', text: ' ' });
  }
  return out;
}

/**
 * Phiên âm cả một đoạn văn bản.
 * Trả về danh sách âm tiết đã tách + chỗ ngắt hơi.
 */
function phonemize(text, { rate = 1.0 } = {}) {
  const tokens = tokenize(text);
  const items = [];
  const unknown = [];

  for (const t of tokens) {
    if (t.type === 'space') continue;
    if (t.type === 'punct') {
      // Dấu câu quyết định nhịp nghỉ — đây là thứ làm giọng đọc nghe tự nhiên.
      const ms = /[.!?…]/.test(t.text) ? 340 : /[,;:]/.test(t.text) ? 190 : 120;
      items.push({ type: 'pause', ms, mark: t.text });
      continue;
    }
    if (t.type === 'number') {
      unknown.push({ text: t.text, reason: 'SỐ_CHƯA_ĐỌC_THÀNH_CHỮ' });
      continue;
    }
    const p = parseSyllable(t.text);
    if (!p.ok) { unknown.push({ text: t.text, reason: p.error }); continue; }
    items.push({ type: 'syllable', parsed: p, segments: segmentsOf(p, { rate }) });
  }

  const totalMs = items.reduce((s, it) => s + (it.type === 'pause' ? it.ms : it.segments.reduce((a, x) => a + x.ms, 0)), 0);
  return {
    ok: true,
    items,
    syllables: items.filter((i) => i.type === 'syllable').length,
    pauses: items.filter((i) => i.type === 'pause').length,
    unknown,
    estimatedMs: Math.round(totalMs),
  };
}

module.exports = {
  TONES, INITIALS, VOWELS, DIPHTHONGS, FINALS,
  stripTone, parseSyllable, segmentsOf, tokenize, phonemize,
};
