'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  KỊCH BẢN GIẢNG BÀI BẰNG GIỌNG NÓI
 * ═══════════════════════════════════════════════════════════════════════════
 *  Đọc một bài toán không phải là đọc to chuỗi ký tự. Một giảng viên thật sẽ:
 *    · nêu tên dạng bài trước, để học viên biết mình đang học cái gì
 *    · đọc đề chậm, ngắt ở dấu câu
 *    · dừng lại cho học viên suy nghĩ TRƯỚC khi chữa
 *    · chữa từng bước, mỗi bước xưng số thứ tự
 *    · nhắc cái bẫy thường gặp
 *    · chốt đáp án
 *
 *  Vì vậy mỗi bài sinh ra một KỊCH BẢN gồm nhiều phân đoạn, mỗi phân đoạn có
 *  vai trò riêng, tốc độ riêng và khoảng lặng riêng. Học viên tầng thấp nghe
 *  chậm hơn và được nghỉ lâu hơn giữa các bước — đây là chỗ hệ thống bám theo
 *  chân dung học viên chứ không đọc đều một giọng cho tất cả.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { toSpeech } = require('./speech-text');
const { cacBuoc } = require('../content/loi-giai');
const { round, clamp } = require('../utils');

/** Vai trò của từng phân đoạn: tốc độ nhân thêm và khoảng lặng phía sau (ms). */
const ROLES = {
  MO_DAU: { name: 'mở đầu', rateMul: 1.00, pauseMs: 420 },
  TEN_DANG: { name: 'tên dạng bài', rateMul: 0.96, pauseMs: 520 },
  DE_BAI: { name: 'đọc đề', rateMul: 0.90, pauseMs: 900 },
  SUY_NGHI: { name: 'chỗ nghỉ để suy nghĩ', rateMul: 1.00, pauseMs: 2500 },
  GOI_Y: { name: 'gợi ý', rateMul: 0.94, pauseMs: 1400 },
  BUOC_GIAI: { name: 'bước giải', rateMul: 0.92, pauseMs: 700 },
  CANH_BAO: { name: 'cảnh báo bẫy', rateMul: 0.90, pauseMs: 800 },
  DAP_AN: { name: 'đáp án', rateMul: 0.88, pauseMs: 700 },
  DONG_VIEN: { name: 'động viên', rateMul: 1.00, pauseMs: 300 },
  CONG_BO: { name: 'công bố giọng AI', rateMul: 1.02, pauseMs: 400 },
};

/** Câu mở đầu đổi theo tầng — tầng thấp cần dẫn dắt, tầng cao đi thẳng vào việc. */
const OPENERS = [
  'Chào em. Mình cùng làm một bài nhé.',
  'Chào em. Bài này mình đi từ từ, em bám theo từng bước.',
  'Ta sang bài tiếp theo.',
  'Bài này rèn kỹ năng, em thử tự làm trước.',
  'Bài này ở mức khá, em đọc kỹ đề.',
  'Bài này có bẫy, em cẩn thận chỗ điều kiện.',
  'Bài nâng cao. Em thử nghĩ hướng trước khi nghe chữa.',
  'Bài khó. Em nên vẽ nháp trước.',
  'Bài dạng thi. Em canh giờ như thi thật.',
  'Bài tổng hợp nhiều kỹ năng. Em bình tĩnh tách thành từng phần.',
];

const ENCOURAGE = [
  'Em làm được. Sai cũng không sao, sai ở đâu thì biết chỗ đó.',
  'Chỗ nào chưa rõ em nghe lại bước đó.',
  'Nhớ cách làm quan trọng hơn nhớ kết quả.',
  'Em thử làm lại bài này mà không nghe chữa xem sao.',
];

const clip = (s, n) => (String(s).length > n ? `${String(s).slice(0, n)}…` : String(s));

class NarrationBuilder {
  /**
   * @param {object} o
   * @param {object} [o.bank]      kho bài — để đọc bài theo id
   * @param {object} [o.profiles]  VoiceProfileRegistry
   */
  constructor({ bank = null, profiles = null } = {}) {
    this.bank = bank;
    this.profiles = profiles;
  }

  /** Một phân đoạn kịch bản: chữ để hiển thị + chữ để đọc. */
  _seg(role, text, { rate = 1.0 } = {}) {
    const t = toSpeech(text);
    const spoken = t.ok ? t.text : '';
    const r = ROLES[role] || ROLES.BUOC_GIAI;
    return {
      role,
      roleName: r.name,
      text: String(text),
      spoken,
      mathSpans: t.mathSpans || [],
      rate: round(clamp(rate * r.rateMul, 0.6, 1.5), 3),
      pauseAfterMs: r.pauseMs,
      chars: spoken.length,
    };
  }

  /**
   * Kịch bản đầy đủ cho một bài.
   * @param {object} item bài toán (stem, solutionSteps, hints, traps, answer)
   * @param {object} o
   * @param {number} [o.level]      tầng của học viên — quyết định tốc độ và độ dài
   * @param {string} [o.mode]       'de' (chỉ đọc đề) | 'goi-y' | 'chua' (đầy đủ)
   * @param {boolean} [o.disclose]  có đọc câu công bố giọng AI không
   */
  forItem(item, { level = 3, mode = 'chua', disclose = true, encourage = true } = {}) {
    if (!item || !item.stem) return { ok: false, error: 'THIẾU_BÀI' };

    // Tầng càng thấp đọc càng chậm: tầng 0 chậm 18%, tầng 9 đọc bình thường.
    const baseRate = round(clamp(0.82 + level * 0.02, 0.82, 1.0), 3);
    const segs = [];

    if (disclose) segs.push(this._seg('CONG_BO', 'Giọng đọc sau đây do máy tổng hợp.', { rate: baseRate }));
    segs.push(this._seg('MO_DAU', OPENERS[clamp(level, 0, OPENERS.length - 1)], { rate: baseRate }));
    if (item.formName) segs.push(this._seg('TEN_DANG', `Dạng bài: ${item.formName}.`, { rate: baseRate }));
    segs.push(this._seg('DE_BAI', item.stem, { rate: baseRate }));

    if (mode === 'de') {
      segs.push(this._seg('SUY_NGHI', '', { rate: baseRate }));
      return this._finish(item, segs, { level, mode, baseRate });
    }

    segs.push(this._seg('SUY_NGHI', '', { rate: baseRate }));

    const hints = Array.isArray(item.hints) ? item.hints : [];
    if (hints.length) {
      // Tầng thấp nghe hết gợi ý; tầng cao chỉ nghe gợi ý đầu, để còn tự nghĩ.
      const take = level <= 3 ? hints.length : 1;
      hints.slice(0, take).forEach((h, i) => {
        segs.push(this._seg('GOI_Y', `Gợi ý ${i + 1}. ${h}`, { rate: baseRate }));
      });
    }

    if (mode === 'goi-y') return this._finish(item, segs, { level, mode, baseRate });

    // Đọc THAO TÁC trước, rồi mới đọc CĂN CỨ, và đọc căn cứ chậm hơn một chút.
    // Người nghe cần kịp nối "vì sao được phép làm thế" với thao tác vừa nghe;
    // đọc liền một mạch cùng tốc độ thì hai phần dính vào nhau.
    const steps = cacBuoc(item);
    steps.forEach((b, i) => {
      const label = i === steps.length - 1 ? 'Bước cuối' : `Bước ${i + 1}`;
      segs.push(this._seg('BUOC_GIAI', `${label}. ${b.viec}`, { rate: baseRate }));
      if (b.canCu) segs.push(this._seg('CAN_CU', `Căn cứ: ${b.canCu}`, { rate: baseRate * 0.94 }));
    });

    const traps = Array.isArray(item.traps) ? item.traps : [];
    if (traps.length) {
      segs.push(this._seg('CANH_BAO', `Chú ý chỗ hay sai: ${clip(traps[0], 160)}`, { rate: baseRate }));
    }

    if (item.answer != null && String(item.answer).trim()) {
      segs.push(this._seg('DAP_AN', `Đáp án: ${item.answer}.`, { rate: baseRate }));
    }

    if (encourage) {
      segs.push(this._seg('DONG_VIEN', ENCOURAGE[(item.id || '').length % ENCOURAGE.length], { rate: baseRate }));
    }

    return this._finish(item, segs, { level, mode, baseRate });
  }

  _finish(item, segments, { level, mode, baseRate }) {
    const chars = segments.reduce((s, x) => s + x.chars, 0);
    const pauses = segments.reduce((s, x) => s + x.pauseAfterMs, 0);
    // ~ 4,6 âm tiết mỗi giây ở tốc độ 1.0 với bộ tổng hợp nội bộ.
    const speakMs = segments.reduce((s, x) => s + (x.spoken ? (x.spoken.split(/\s+/).filter(Boolean).length / 4.6) * 1000 / x.rate : 0), 0);
    return {
      ok: true,
      itemId: item.id || null,
      formCode: item.formCode || null,
      level,
      mode,
      baseRate,
      segments,
      totalSegments: segments.length,
      chars,
      estimatedMs: Math.round(speakMs + pauses),
      estimatedSeconds: round((speakMs + pauses) / 1000, 1),
    };
  }

  /** Kịch bản cho một bài lấy từ kho theo mã. */
  forItemId(itemId, opts = {}) {
    if (!this.bank) return { ok: false, error: 'KHÔNG_CÓ_KHO_BÀI' };
    const it = this.bank.get ? this.bank.get(itemId) : null;
    if (!it) return { ok: false, error: 'KHÔNG_TÌM_THẤY_BÀI', itemId };
    return this.forItem(it, opts);
  }

  /** Đọc một đoạn tự do (nhận xét của giáo viên, thông báo…). */
  forText(text, { level = 5, disclose = false } = {}) {
    if (!text || !String(text).trim()) return { ok: false, error: 'THIẾU_NỘI_DUNG' };
    const baseRate = round(clamp(0.82 + level * 0.02, 0.82, 1.0), 3);
    const segs = [];
    if (disclose) segs.push(this._seg('CONG_BO', 'Giọng đọc sau đây do máy tổng hợp.', { rate: baseRate }));
    // Tách theo câu để mỗi câu có khoảng lặng riêng — đọc liền một hơi rất khó nghe.
    const sentences = String(text).split(/(?<=[.!?…:])\s+/).filter((s) => s.trim());
    for (const s of sentences) segs.push(this._seg('BUOC_GIAI', s, { rate: baseRate }));
    return this._finish({ id: null }, segs, { level, mode: 'van-ban', baseRate });
  }

  /**
   * Kịch bản buổi luyện tập: mở đầu chung rồi lần lượt từng bài, chỉ đọc đề.
   * Dùng cho chế độ "nghe đề làm bài" — học viên không nhìn màn hình.
   */
  forSession(items, { level = 3, learnerName = 'em' } = {}) {
    const list = (items || []).filter((x) => x && x.stem);
    if (!list.length) return { ok: false, error: 'BUỔI_HỌC_KHÔNG_CÓ_BÀI' };
    const baseRate = round(clamp(0.82 + level * 0.02, 0.82, 1.0), 3);
    const segs = [this._seg('CONG_BO', 'Giọng đọc sau đây do máy tổng hợp.', { rate: baseRate })];
    segs.push(this._seg('MO_DAU', `Chào ${learnerName}. Buổi này có ${list.length} bài. Mình bắt đầu.`, { rate: baseRate }));
    list.forEach((it, i) => {
      segs.push(this._seg('TEN_DANG', `Bài ${i + 1}.`, { rate: baseRate }));
      segs.push(this._seg('DE_BAI', it.stem, { rate: baseRate }));
      segs.push(this._seg('SUY_NGHI', '', { rate: baseRate }));
    });
    segs.push(this._seg('DONG_VIEN', 'Hết buổi. Em kiểm tra lại đáp án trên màn hình.', { rate: baseRate }));
    const out = this._finish({ id: null }, segs, { level, mode: 'buoi-hoc', baseRate });
    out.items = list.length;
    return out;
  }

  /** Toàn bộ chữ cần đọc của một kịch bản, nối lại thành một chuỗi. */
  static flatten(script) {
    if (!script || !script.ok) return '';
    return script.segments.map((s) => s.spoken).filter(Boolean).join(' ');
  }
}

module.exports = { NarrationBuilder, ROLES, OPENERS, ENCOURAGE };
