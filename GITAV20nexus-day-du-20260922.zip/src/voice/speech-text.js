'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  CHUẨN HOÁ VĂN BẢN ĐỂ ĐỌC THÀNH TIẾNG
 * ═══════════════════════════════════════════════════════════════════════════
 *  Văn bản viết và văn bản ĐỌC là hai thứ khác nhau. "x^{2} - 5x + 6 = 0" mà
 *  đọc theo mặt chữ thì không ai hiểu. Phải đổi thành:
 *      "x bình phương trừ năm x cộng sáu bằng không"
 *
 *  Đây là lớp quyết định học viên nghe có hiểu bài hay không, nên mọi quy tắc
 *  đều viết tay theo cách người Việt thật sự đọc:
 *    · 15 đọc là "mười lăm", KHÔNG phải "mười năm"
 *    · 21 đọc là "hai mươi mốt", KHÔNG phải "hai mươi một"
 *    · 105 đọc là "một trăm lẻ năm"
 *    · x² đọc là "x bình phương", x³ là "x lập phương", x⁴ là "x mũ bốn"
 *    · \dfrac{a}{b} đọc là "a trên b"
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { bocCongThuc } = require('../math/kyhieu');

const DIGITS = ['không', 'một', 'hai', 'ba', 'bốn', 'năm', 'sáu', 'bảy', 'tám', 'chín'];
const SCALES = ['', ' nghìn', ' triệu', ' tỷ', ' nghìn tỷ', ' triệu tỷ'];

/** Đọc một nhóm ba chữ số (0..999). `full` = có đọc cả khi nhóm bắt đầu bằng 0. */
function readGroup(n, full) {
  const tram = Math.floor(n / 100);
  const chuc = Math.floor((n % 100) / 10);
  const donvi = n % 10;
  const out = [];

  if (tram > 0) {
    out.push(`${DIGITS[tram]} trăm`);
  } else if (full && (chuc > 0 || donvi > 0)) {
    out.push('không trăm');
  }

  if (chuc > 1) {
    out.push(`${DIGITS[chuc]} mươi`);
    // 21, 31… đọc "mốt" chứ không đọc "một"
    if (donvi === 1) out.push('mốt');
    // 25, 35… đọc "lăm"
    else if (donvi === 5) out.push('lăm');
    else if (donvi > 0) out.push(DIGITS[donvi]);
  } else if (chuc === 1) {
    out.push('mười');
    if (donvi === 5) out.push('lăm');      // 15 = "mười lăm"
    else if (donvi > 0) out.push(DIGITS[donvi]);
  } else if (donvi > 0) {
    // Hàng chục bằng 0 mà có hàng trăm: chèn "lẻ" (105 = "một trăm lẻ năm")
    if (tram > 0 || full) out.push('lẻ');
    out.push(DIGITS[donvi]);
  }

  return out.join(' ');
}

/** Đọc một số nguyên bất kỳ thành chữ tiếng Việt. */
function readInteger(value) {
  let n = Math.trunc(Math.abs(Number(value)));
  const neg = Number(value) < 0;
  if (!Number.isFinite(n)) return 'không xác định';
  if (n === 0) return neg ? 'âm không' : 'không';

  const groups = [];
  while (n > 0) { groups.push(n % 1000); n = Math.floor(n / 1000); }

  const parts = [];
  for (let i = groups.length - 1; i >= 0; i--) {
    const g = groups[i];
    if (g === 0) continue;
    // Nhóm không phải nhóm cao nhất thì phải đọc đủ ba chữ số ("một triệu không trăm lẻ năm")
    parts.push(readGroup(g, i !== groups.length - 1) + SCALES[i]);
  }
  return (neg ? 'âm ' : '') + parts.join(' ').replace(/\s+/g, ' ').trim();
}

/** Đọc số thập phân: 3.14 → "ba phẩy một bốn". */
function readDecimal(value) {
  const s = String(value).replace(',', '.');
  const neg = s.startsWith('-');
  const [intPart, fracPart] = s.replace('-', '').split('.');
  const head = readInteger(Number(intPart || 0));
  if (fracPart === undefined) return (neg ? 'âm ' : '') + head;
  const tail = [...fracPart].map((d) => DIGITS[Number(d)] ?? d).join(' ');
  return `${neg ? 'âm ' : ''}${head} phẩy ${tail}`;
}

/** Đọc số bất kỳ (nguyên hoặc thập phân). */
function readNumber(value) {
  const s = String(value).trim();
  return /[.,]/.test(s) ? readDecimal(s) : readInteger(s);
}

// ── Ký hiệu toán học ────────────────────────────────────────────────────────

const SYMBOLS = [
  [/\\dfrac|\\tfrac|\\frac/g, ' PHÂNSỐ '],
  [/\\sqrt\s*\[\s*3\s*\]/g, ' căn bậc ba của '],
  [/\\sqrt/g, ' căn bậc hai của '],
  [/\\Delta/g, ' đen-ta '],
  [/\\delta/g, ' đen-ta nhỏ '],
  [/\\pi/g, ' pi '],
  [/\\alpha/g, ' an-pha '], [/\\beta/g, ' bê-ta '], [/\\gamma/g, ' gam-ma '],
  [/\\theta/g, ' tê-ta '], [/\\lambda/g, ' lam-đa '], [/\\mu/g, ' muy '],
  [/\\infty/g, ' vô cực '],
  [/\\le|\\leq|≤/g, ' nhỏ hơn hoặc bằng '],
  [/\\ge|\\geq|≥/g, ' lớn hơn hoặc bằng '],
  [/\\ne|\\neq|≠/g, ' khác '],
  [/\\approx|≈/g, ' xấp xỉ '],
  [/\\pm|±/g, ' cộng trừ '],
  [/\\cdot|\\times|×/g, ' nhân '],
  [/\\div|÷/g, ' chia '],
  [/\\in|∈/g, ' thuộc '],
  [/\\notin|∉/g, ' không thuộc '],
  [/\\subset|⊂/g, ' là tập con của '],
  [/\\cup|∪/g, ' hợp '],
  [/\\cap|∩/g, ' giao '],
  [/\\Rightarrow|⇒/g, ' suy ra '],
  [/\\Leftrightarrow|⇔/g, ' tương đương '],
  [/\\to|→/g, ' tiến tới '],
  [/\\mathbb\s*\{R\}|ℝ/g, ' tập số thực '],
  [/\\mathbb\s*\{N\}|ℕ/g, ' tập số tự nhiên '],
  [/\\mathbb\s*\{Z\}|ℤ/g, ' tập số nguyên '],
  [/\\mathbb\s*\{Q\}|ℚ/g, ' tập số hữu tỉ '],
  [/\\sum|∑/g, ' tổng '],
  [/\\int|∫/g, ' tích phân '],
  [/\\lim/g, ' giới hạn '],
  [/\\sin/g, ' sin '], [/\\cos/g, ' cô-sin '], [/\\tan/g, ' tang '], [/\\cot/g, ' cô-tang '],
  [/\\log/g, ' lô-ga '], [/\\ln/g, ' lô-ga nê-pe '],
  [/\\text\s*\{([^}]*)\}/g, ' $1 '],
  [/\\left|\\right|\\displaystyle|\\quad|\\qquad/g, ' '],
  [/\\begin\s*\{cases\}/g, ' hệ phương trình '],
  [/\\end\s*\{cases\}/g, ' '],
  [/\\\\/g, ' '],
];

/** Đọc luỹ thừa theo cách người Việt nói. */
function readPower(exp) {
  const e = String(exp).trim();
  if (e === '2') return ' bình phương ';
  if (e === '3') return ' lập phương ';
  if (/^-?\d+$/.test(e)) return ` mũ ${readInteger(e)} `;
  return ` mũ ${e} `;
}

/** Đọc nội dung một cặp ngoặc nhọn cân bằng bắt đầu tại i (s[i] === '{'). */
function readBraced(str, i) {
  if (str[i] !== '{') return null;
  let depth = 0;
  for (let j = i; j < str.length; j++) {
    if (str[j] === '{') depth++;
    else if (str[j] === '}') {
      depth--;
      if (depth === 0) return { body: str.slice(i + 1, j), next: j + 1 };
    }
  }
  return null;
}

/** Bóc \dfrac{…}{…} và \sqrt[…]{…} lồng nhiều tầng, từ trong ra ngoài. */
function expandNested(input) {
  let s = input;
  for (let pass = 0; pass < 40; pass++) {
    const mFrac = s.match(/\\(?:dfrac|tfrac|frac)\s*(?=\{)/);
    const mSqrt = s.match(/\\sqrt\s*(?:\[([^\]]*)\])?\s*(?=\{)/);
    const iFrac = mFrac ? mFrac.index : -1;
    const iSqrt = mSqrt ? mSqrt.index : -1;
    if (iFrac < 0 && iSqrt < 0) break;

    // Xử lý cái xuất hiện SAU cùng trước → luôn là cái trong cùng.
    if (iFrac > iSqrt) {
      const start = iFrac + mFrac[0].length;
      const num = readBraced(s, start);
      if (!num) break;
      let k = num.next;
      while (s[k] === ' ') k++;
      const den = readBraced(s, k);
      if (!den) break;
      s = s.slice(0, iFrac) + ` ⟦${num.body}⟧TRÊN⟦${den.body}⟧ ` + s.slice(den.next);
    } else {
      const order = mSqrt[1];
      const start = iSqrt + mSqrt[0].length;
      const body = readBraced(s, start);
      if (!body) break;
      const label = order ? `CĂNBẬC⟦${order}⟧` : 'CĂNBẬCHAI';
      s = s.slice(0, iSqrt) + ` ${label}⟦${body.body}⟧ ` + s.slice(body.next);
    }
  }
  return s;
}

/**
 * Đổi biểu thức toán (LaTeX hoặc viết thường) thành câu đọc được.
 */
function readMath(input) {
  let s = ` ${String(input ?? '')} `;

  // Phân số và căn có thể LỒNG NHAU nhiều tầng, nên phải bóc ngoặc cân bằng
  // chứ không dùng được biểu thức chính quy đơn giản — nếu không thì
  // \dfrac{-b+\sqrt{...}}{2a} sẽ mất luôn chữ "trên".
  s = expandNested(s);

  // Tên phiên âm của ký hiệu có gạch nối ("đen-ta", "cô-sin"). Gạch nối đó là
  // của TỪ, không phải phép trừ. Đổi tạm sang gạch nối không ngắt (U+2011) để
  // bước xử lý dấu trừ phía dưới không đụng tới, cuối hàm trả lại nguyên dạng.
  const NB = '\u2011';
  for (const [re, rep] of SYMBOLS) s = s.replace(re, rep.replace(/-/g, NB));

  // Luỹ thừa và chỉ số dưới
  s = s.replace(/\^\s*\{([^{}]*)\}/g, (_, e) => readPower(e));
  s = s.replace(/\^\s*(-?\w)/g, (_, e) => readPower(e));
  s = s.replace(/_\s*\{([^{}]*)\}/g, (_, e) => ` ${/^\d+$/.test(e) ? readInteger(e) : e} `);
  s = s.replace(/_\s*(\w)/g, (_, e) => ` ${/^\d$/.test(e) ? readInteger(e) : e} `);

  // Dấu phép tính. Dấu trừ đứng đầu là "âm", đứng giữa là "trừ".
  // Dấu trừ đứng ĐẦU biểu thức hoặc ngay sau ( = < > , mới đọc là "âm".
  // Đứng giữa hai số hạng thì đọc là "trừ" — đây là chỗ rất dễ sai.
  s = s.replace(/(^|[(=<>,⟦]|\bbằng\b|\bnhỏ hơn\b|\blớn hơn\b)(\s*)-\s*(?=[\d\w(⟦])/g, '$1$2 âm ');
  s = s.replace(/\+/g, ' cộng ');
  // Tới đây mọi gạch nối còn lại đều là phép trừ: gạch nối của từ đã được
  // đổi sang U+2011 ngay sau bảng ký hiệu.
  s = s.replace(/-/g, ' trừ ');
  s = s.replace(/\*/g, ' nhân ');
  s = s.replace(/(?<!\d)\/(?!\d)/g, ' trên ');
  s = s.replace(/(\d)\s*\/\s*(\d)/g, (_, a, b) => ` ${readInteger(a)} trên ${readInteger(b)} `);
  s = s.replace(/=/g, ' bằng ');
  s = s.replace(/</g, ' nhỏ hơn ');
  s = s.replace(/>/g, ' lớn hơn ');
  s = s.replace(/\|/g, ' trị tuyệt đối ');
  s = s.replace(/[{}$]/g, ' ');
  s = s.replace(/\(/g, ' mở ngoặc ').replace(/\)/g, ' đóng ngoặc ');
  s = s.replace(/%/g, ' phần trăm ');

  // Số → chữ
  s = s.replace(/\d+(?:[.,]\d+)?/g, (m) => ` ${readNumber(m)} `);

  // Trả nhãn tạm về lời đọc thật.
  s = s.replace(/CĂNBẬCHAI/g, ' căn bậc hai của ')
    .replace(/CĂNBẬC⟦([^⟧]*)⟧/g, (_, n) => ` căn bậc ${n} của `)
    .replace(/TRÊN/g, ' trên ')
    .replace(/[⟦⟧]/g, ' ')
    .replace(/PHÂNSỐ/g, ' phân số ')
    .replace(new RegExp(NB, 'g'), '-');

  return s.replace(/\s+/g, ' ').trim();
}

// ── Viết tắt và đơn vị hay gặp ─────────────────────────────────────────────
// Ranh giới \b của JavaScript chỉ hiểu chữ ASCII, nên "\bVN\b" khớp cả trong
// "VNĐ" và "\bĐKXĐ\b" thì không khớp gì cả. Phải tự viết ranh giới có tính
// đến chữ cái tiếng Việt.
const VI_LETTER = 'A-Za-zÀ-ỹĐđ';
const B = (word) => new RegExp(`(?<![${VI_LETTER}])${word}(?![${VI_LETTER}])`, 'g');

const ABBREV = [
  // Cụm dài xếp trước cụm ngắn: VNĐ phải thay trước VN.
  [B('VNĐ|VND'), 'đồng'],
  [B('ĐKXĐ'), 'điều kiện xác định'],
  [B('ƯCLN'), 'ước chung lớn nhất'],
  [B('BCNN'), 'bội chung nhỏ nhất'],
  [B('ĐGNL'), 'đánh giá năng lực'],
  [B('ĐHQG'), 'đại học quốc gia'],
  [B('THCS'), 'trung học cơ sở'],
  [B('THPT'), 'trung học phổ thông'],
  [B('PGS'), 'phó giáo sư'],
  [B('ThS'), 'thạc sĩ'],
  [B('GS'), 'giáo sư'],
  [B('TS'), 'tiến sĩ'],
  [B('GV'), 'giáo viên'],
  [B('HV'), 'học viên'],
  [B('TP'), 'thành phố'],
  [B('VD'), 'ví dụ'],
  [B('VN'), 'Việt Nam'],
  [B('AI'), 'ây ai'],
  [B('km/h'), 'ki-lô-mét trên giờ'],
  [B('m/s'), 'mét trên giây'],
  [/cm²|\bcm2(?![0-9])/g, 'xăng-ti-mét vuông'],
  [/m²|\bm2(?![0-9])/g, 'mét vuông'],
  [/cm³|\bcm3(?![0-9])/g, 'xăng-ti-mét khối'],
  [/m³|\bm3(?![0-9])/g, 'mét khối'],
  [B('kg'), 'ki-lô-gam'],
  [B('km'), 'ki-lô-mét'],
  [B('cm'), 'xăng-ti-mét'],
  [B('mm'), 'mi-li-mét'],
];


// ── Đọc chữ cái đơn lẻ (biến số) ───────────────────────────────────────────
const LETTER_NAME = {
  a: 'a', b: 'bê', c: 'xê', d: 'đê', e: 'e', f: 'ép', g: 'giê', h: 'hát',
  i: 'i', j: 'gi', k: 'ca', l: 'lờ', m: 'mờ', n: 'nờ', o: 'o', p: 'pê',
  q: 'quy', r: 'rờ', s: 'ét', t: 'tê', u: 'u', v: 'vê', w: 'vê kép',
  x: 'ích', y: 'i dài', z: 'dét',
};

/**
 * Chuẩn hoá cả một đoạn văn bản có lẫn công thức trong $…$.
 * @returns {{ok, text, mathSpans, note}}
 */
function toSpeech(input, { readLetters = true } = {}) {
  let s = String(input ?? '');
  const mathSpans = [];

  // 0. Công thức viết ở dạng Unicode phẳng (x², x₁, √, ∆, ⁄) — đây là dạng
  //    hiện trên khung hình video và trên dòng lệnh. Bộ đọc bên dưới chỉ hiểu
  //    LaTeX, nên phải bắc cầu trước: không có bước này thì "x²" đọc thành
  //    "ích" và người nghe mất luôn dấu mũ.
  s = bocCongThuc(s);

  // 1. Công thức trong $…$ đọc bằng bộ đọc toán.
  s = s.replace(/\$\$([\s\S]*?)\$\$|\$([^$]*)\$/g, (_, a, b) => {
    const body = a ?? b ?? '';
    const spoken = readMath(body);
    mathSpans.push({ source: body, spoken });
    return ` ${spoken} `;
  });

  // 2. Viết tắt và đơn vị.
  for (const [re, rep] of ABBREV) s = s.replace(re, rep);

  // 3. Hàm toán viết kiểu ƯCLN(12, 18): dấu phẩy ở đây là dấu NGĂN CÁCH,
  //    không phải dấu thập phân. Đọc nhầm thành "mười hai phẩy mười tám" là
  //    đổi hẳn nghĩa bài toán.
  s = s.replace(/([A-Za-zÀ-ỹĐđ][A-Za-zÀ-ỹĐđ ]{1,30}?)\s*\(\s*([^()]{1,60}?)\s*\)/g, (m, name, args) => {
    if (!/[\d]/.test(args)) return m;                      // không có số thì để nguyên
    const parts = args.split(/\s*[,;]\s*/).filter(Boolean);
    if (parts.length < 2) return m;
    return ` ${name.trim()} của ${parts.map((x) => readMath(x)).join(' và ')} `;
  });

  // 4. Ký hiệu toán còn nằm ngoài $…$ (đề viết tay không đủ dấu $).
  if (/[\\^_×÷≤≥≠∈]/.test(s)) s = s.replace(/[^\s.,;:!?]*[\\^_×÷≤≥≠∈][^\s]*/g, (m) => ` ${readMath(m)} `);

  // Hàm một chữ: f(x), g(2) → "ép của ích", không đọc thành "mở ngoặc".
  s = s.replace(/(?<![A-Za-zÀ-ỹĐđ])([a-zA-Z])\s*\(\s*([^()]{1,20}?)\s*\)/g,
    (_, fn, arg) => ` ${LETTER_NAME[fn.toLowerCase()] || fn} của ${readMath(arg)} `);

  // Tên hình học viết hoa liền nhau: ABC, MNPQ → đọc từng chữ cái.
  s = s.replace(/(?<![A-Za-zÀ-ỹĐđ])([A-Z]{2,5})(?![A-Za-zÀ-ỹĐđ])/g,
    (m) => ` ${[...m].map((c) => LETTER_NAME[c.toLowerCase()] || c).join(' ')} `);

  // Phần trăm và dấu bằng còn sót ngoài công thức.
  s = s.replace(/%/g, ' phần trăm ')
    .replace(/\s=\s/g, ' bằng ');

  // 5. Số còn lại ngoài công thức.
  s = s.replace(/\d+(?:[.,]\d{3})*(?:[.,]\d+)?/g, (m) => {
    const clean = m.replace(/[.,](?=\d{3}\b)/g, '');   // 1.200.000 → 1200000
    return ` ${readNumber(clean)} `;
  });

  // 6. Chữ cái đứng một mình = tên biến, đọc theo tên chữ cái.
  if (readLetters) {
    s = s.replace(/(?<![A-Za-zÀ-ỹĐđ])([A-Za-z])(?![A-Za-zÀ-ỹĐđ])/g,
      (_, c) => ` ${LETTER_NAME[c.toLowerCase()] || c} `);
  }

  // 7. Dọn dẹp, giữ lại dấu câu vì dấu câu điều khiển nhịp nghỉ.
  s = s.replace(/[«»"'`“”]/g, ' ')
    .replace(/\s*([,;:.!?])\s*/g, '$1 ')
    .replace(/\s+/g, ' ')
    .trim();

  return {
    ok: true,
    text: s,
    mathSpans,
    note: mathSpans.length ? `${mathSpans.length} công thức đã được đọc thành lời.` : null,
  };
}

module.exports = {
  readInteger, readDecimal, readNumber, readMath, toSpeech,
  DIGITS, LETTER_NAME, ABBREV,
};
