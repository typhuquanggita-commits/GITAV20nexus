'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  DỊCH VỤ GIỌNG NÓI — cửa duy nhất mà phần còn lại của hệ thống gọi vào
 * ═══════════════════════════════════════════════════════════════════════════
 *  Ghép năm mảnh lại thành một đường đi có trật tự:
 *
 *    văn bản  →  toSpeech (đọc toán, đọc số, đọc viết tắt)
 *             →  phonemize (tách âm đầu / đệm / chính / cuối / thanh)
 *             →  nhà cung cấp (mặc định: bộ tổng hợp formant nội bộ)
 *             →  đóng dấu AI + ghi nhật ký (bắt buộc)
 *             →  WAV trả về học viên
 *
 *  Ba điều không được phép bỏ qua, nên chúng nằm trong hàm chứ không nằm
 *  trong tài liệu:
 *    · chưa qua authorize() thì không có âm thanh
 *    · chưa đóng dấu thì không trả tệp ra ngoài
 *    · mọi lần tạo giọng đều để lại một mắt xích nhật ký
 * ═══════════════════════════════════════════════════════════════════════════
 */

const cfg = require('../config');
const L = require('../logger');
const { sha256, round } = require('../utils');
const { VoiceProfileRegistry, profileFor } = require('./profiles');
const { ProviderRegistry } = require('./providers');
const { VoiceCompliance, DISCLOSURE } = require('./compliance');
const { NarrationBuilder } = require('./narration');
const NV = require('./neural-providers');
const { VietnameseSpeechPipeline } = require('./pipelines/speech');
const { SingingPipeline } = require('./pipelines/singing');
const { ConversionPipeline } = require('./pipelines/conversion');
const { StudioChain } = require('./dsp');
const { parseMelody, parseMidi, midiName, RANGES } = require('./music');
const { toSpeech } = require('./speech-text');
const { phonemize } = require('./phonemizer');
const { fromWav } = require('./synth');
const EN = require('./en-phonemizer');
const ENS = require('./en-speech');

/** Bộ nhớ đệm nhỏ theo kiểu dùng gần nhất — cùng câu, cùng giọng thì không dựng lại. */
class AudioCache {
  constructor(max = cfg.VOICE.cacheMax) {
    this.max = max;
    this.map = new Map();
    this.hits = 0;
    this.misses = 0;
    this.bytes = 0;
  }

  key(text, voiceId, rate) { return sha256(`${voiceId}|${rate}|${text}`).slice(0, 32); }

  get(k) {
    const v = this.map.get(k);
    if (!v) { this.misses++; return null; }
    this.map.delete(k); this.map.set(k, v);   // đẩy lên đầu
    this.hits++;
    return v;
  }

  set(k, v) {
    if (this.map.has(k)) this.map.delete(k);
    this.map.set(k, v);
    this.bytes += v.wav.length;
    while (this.map.size > this.max) {
      const [oldK, oldV] = this.map.entries().next().value;
      this.map.delete(oldK);
      this.bytes -= oldV.wav.length;
    }
  }

  clear() { const n = this.map.size; this.map.clear(); this.bytes = 0; return n; }

  status() {
    const total = this.hits + this.misses;
    return { size: this.map.size, max: this.max, hits: this.hits, misses: this.misses, hitRate: total ? round(this.hits / total, 3) : 0, bytes: this.bytes };
  }
}

class VoiceService {
  /**
   * @param {object} o
   * @param {Array}  o.agents  danh sách 500 agent — mỗi agent một giọng
   * @param {object} [o.db]    Database để lưu đồng ý và nhật ký
   * @param {object} [o.bank]  kho bài, để đọc bài theo mã
   * @param {object} [o.bus]   bus sự kiện
   */
  constructor({ agents = [], db = null, bank = null, bus = null } = {}) {
    this.profiles = new VoiceProfileRegistry({ agents });
    this.providers = new ProviderRegistry();
    this.compliance = new VoiceCompliance({ db });
    this.narration = new NarrationBuilder({ bank, profiles: this.profiles });
    this.cache = new AudioCache();
    this.bus = bus;
    this.bank = bank;

    // ── Ba tuyến chuyên biệt ──
    // Nói và hát là hai việc khác nhau về bản chất (cao độ do thanh điệu hay
    // do nốt nhạc), nên tách hẳn tuyến chứ không nhồi vào một hàm.
    this.neural = {
      soulx: new NV.SoulXSingerProvider(),
      openUtau: new NV.OpenUtauDiffSingerProvider(),
      soVits: new NV.SoVitsSvcProvider(),
    };
    this.speechPipeline = new VietnameseSpeechPipeline({ providers: this.providers, compliance: this.compliance });
    this.singingPipeline = new SingingPipeline({ neural: this.neural, compliance: this.compliance });
    this.conversionPipeline = new ConversionPipeline({ neural: this.neural, compliance: this.compliance });
    this.stats = { requests: 0, denied: 0, tooLong: 0, synthesized: 0, cached: 0, failed: 0, totalMs: 0, totalChars: 0 };
  }

  /** Kiểm tra trước khi đọc: câu này có đọc được không, thiếu âm tiết nào. */
  inspect(text, { voiceId = null } = {}) {
    const t = toSpeech(text);
    if (!t.ok) return { ok: false, error: t.note || 'KHÔNG_ĐỌC_ĐƯỢC' };
    const ph = phonemize(t.text);
    return {
      ok: true,
      original: String(text),
      spoken: t.text,
      mathSpans: t.mathSpans,
      syllables: ph.syllables,
      pauses: ph.pauses,
      unknown: ph.unknown,
      estimatedMs: ph.estimatedMs,
      voice: voiceId ? this.profiles.get(voiceId) : null,
    };
  }

  /**
   * Đọc một đoạn văn bản thành WAV.
   * @returns {Promise<object>} {ok, wav, ms, voiceId, provider, watermarked, disclosure}
   */
  async speak(text, { voiceId = null, agentId = null, division = null, level = null, learnerId = null, rate = null, prefer = null, audible = true, useCache = true, purpose = 'giang-bai', studio = null, preset = null, emotion = 'neutral' } = {}) {
    this.stats.requests++;
    const raw = String(text ?? '').trim();
    if (!raw) return { ok: false, error: 'THIẾU_NỘI_DUNG' };
    if (raw.length > cfg.VOICE.maxChars) {
      this.stats.tooLong++;
      return { ok: false, error: 'QUÁ_DÀI', maxChars: cfg.VOICE.maxChars, have: raw.length, howToFix: 'Dùng /voice/narrate để cắt thành nhiều phân đoạn.' };
    }

    // 1) Cổng pháp lý
    const gate = this.compliance.authorize({ subjectId: learnerId, kind: 'VOICE_LISTEN', purpose: 'đọc bài giảng' });
    if (!gate.ok) { this.stats.denied++; return { ...gate, ok: false }; }

    // 2) Chọn giọng
    const profile = this.profiles.pick({ agentId, division, level, prefer: voiceId });
    if (!profile) return { ok: false, error: 'KHÔNG_CÓ_GIỌNG' };
    const effRate = rate != null ? Number(rate) : profile.params.rate;

    // 3) Chuyển sang dạng đọc được
    const t = toSpeech(raw);
    const spoken = t.ok ? t.text : raw;

    // 4) Bộ nhớ đệm — khoá phải tính cả mục đích và hậu kỳ, vì cùng một câu
    //    đọc cho "phát trực tiếp" và cho "podcast" ra hai tệp khác nhau.
    const key = this.cache.key(`${purpose}|${preset || ''}|${studio}|${spoken}`, profile.voiceId, effRate);
    if (useCache) {
      const hit = this.cache.get(key);
      if (hit) {
        this.stats.cached++;
        return { ...hit, ok: true, cached: true, disclosure: DISCLOSURE };
      }
    }

    // 5) Tổng hợp qua tuyến nói (chọn bộ theo mục đích + hậu kỳ phòng thu)
    const out = await this.speechPipeline.synthesize(raw, { ...profile, params: { ...profile.params, rate: effRate } },
      { purpose, prefer: prefer || voiceId === null ? prefer : null, rate: effRate, emotion, studio, preset });
    if (!out.ok) {
      this.stats.failed++;
      L.warn(`Giọng nói: không tổng hợp được (${out.error})`);
      return { ok: false, error: out.error, tried: out.tried, plan: out.plan };
    }

    // 6) Đóng dấu AI — bắt buộc, kể cả khi nhà cung cấp ngoài trả về sẵn tệp
    let wav = out.wav;
    let stamp = { watermarked: false, reason: 'NGUỒN_KHÔNG_PHẢI_WAV' };
    const pcm = out.mime && out.mime !== 'audio/wav' ? null : fromWav(out.wav);
    if (pcm) {
      stamp = this.compliance.stamp(pcm.samples, {
        voiceId: profile.voiceId, provider: out.provider, text: spoken,
        subjectId: learnerId, sampleRate: pcm.sampleRate, audible,
      });
      wav = stamp.wav;
    } else {
      // Tệp nén (mp3) thì không nhúng được dấu chìm; vẫn phải ghi nhật ký và
      // nói thẳng ra là chưa đóng dấu, chứ không im lặng cho qua.
      const entry = this.compliance.audit.append('TẠO_GIỌNG_KHÔNG_DẤU', {
        subjectId: learnerId, voiceId: profile.voiceId, provider: out.provider,
        textHash: sha256(spoken).slice(0, 16), mime: out.mime,
      });
      stamp.auditId = entry.id;
    }

    const ms = out.ms || Math.round(((wav.length - 44) / 2 / (out.sampleRate || 22050)) * 1000);
    const result = {
      wav,
      mime: out.mime || 'audio/wav',
      ms,
      sampleRate: out.sampleRate || 22050,
      voiceId: profile.voiceId,
      voiceName: profile.displayName,
      gender: profile.gender,
      character: profile.character,
      provider: out.provider,
      fellBackFrom: (out.triedBefore || []).map((x) => x.provider),
      watermarked: !!stamp.watermarked,
      watermarkNote: stamp.reason || null,
      auditId: stamp.auditId || null,
      spoken,
      chars: spoken.length,
      rate: effRate,
      purpose,
      purposeName: out.purposeName,
      studio: out.studio,
    };

    this.stats.synthesized++;
    this.stats.totalMs += ms;
    this.stats.totalChars += spoken.length;
    if (useCache) this.cache.set(key, result);
    this.bus?.safeEmit?.('voice:spoken', { voiceId: profile.voiceId, provider: out.provider, ms, chars: spoken.length });

    return { ...result, ok: true, cached: false, disclosure: DISCLOSURE };
  }

  /**
   * Dựng kịch bản giảng bài cho một bài rồi (tuỳ chọn) đọc luôn thành tệp.
   * Trả kịch bản trước: giao diện có thể hiện lời trong lúc chờ âm thanh.
   */
  async narrateItem(itemOrId, { level = 3, mode = 'chua', learnerId = null, agentId = null, voiceId = null, render = false, disclose = true } = {}) {
    const script = typeof itemOrId === 'string'
      ? this.narration.forItemId(itemOrId, { level, mode, disclose })
      : this.narration.forItem(itemOrId, { level, mode, disclose });
    if (!script.ok) return script;

    const profile = this.profiles.pick({ agentId, level, prefer: voiceId });
    script.voiceId = profile.voiceId;
    script.voiceName = profile.displayName;
    script.disclosure = DISCLOSURE;
    if (!render) return script;

    const gate = this.compliance.authorize({ subjectId: learnerId, kind: 'VOICE_LISTEN', purpose: 'giảng bài' });
    if (!gate.ok) { this.stats.denied++; return { ...gate, ok: false }; }

    const parts = [];
    for (const seg of script.segments) {
      if (!seg.spoken) { parts.push({ role: seg.role, silenceMs: seg.pauseAfterMs }); continue; }
      const r = await this.speak(seg.text, { voiceId: profile.voiceId, rate: seg.rate, learnerId, audible: false });
      if (!r.ok) return r;
      parts.push({ role: seg.role, roleName: seg.roleName, spoken: r.spoken, ms: r.ms, pauseAfterMs: seg.pauseAfterMs, wav: r.wav });
    }
    script.rendered = parts.map(({ wav, ...rest }) => rest);
    script.audio = parts.filter((p) => p.wav);
    script.renderedMs = parts.reduce((s, p) => s + (p.ms || 0) + (p.pauseAfterMs || p.silenceMs || 0), 0);
    return script;
  }

  /** ── HÁT ─────────────────────────────────────────────────────────────── */

  /** Kiểm tra bài hát trước khi dựng: lời khớp nốt chưa, có vượt quãng không. */
  checkSong(input) { return this.singingPipeline.check(input); }

  /**
   * Hát một bài. Đi qua đúng cổng pháp lý như phần nói, và cũng bị đóng dấu AI.
   */
  async sing({ lyrics, melody = null, midi = null, bpm = 90, style = 'pop', range = null,
    voiceId = null, agentId = null, learnerId = null, studio = true, preset = null,
    track = null, channel = null, lang = 'vi', ustxPath = null } = {}) {
    this.stats.requests++;
    if (!lyrics || !String(lyrics).trim()) return { ok: false, error: 'THIẾU_LỜI' };

    const gate = this.compliance.authorize({ subjectId: learnerId, kind: 'VOICE_LISTEN', purpose: 'nghe hát' });
    if (!gate.ok) { this.stats.denied++; return { ...gate, ok: false }; }

    const profile = this.profiles.pick({ agentId, prefer: voiceId });
    if (!profile) return { ok: false, error: 'KHÔNG_CÓ_GIỌNG' };

    const midiBuf = typeof midi === 'string' ? Buffer.from(midi, 'base64') : midi;
    const r = await this.singingPipeline.sing({
      lyrics, melody, midi: midiBuf, bpm, style, range,
      profile: { ...profile.params, seed: profile.params.seed },
      studio, preset, track, channel, lang, ustxPath,
    });
    if (!r.ok) return r;

    // Đóng dấu AI: hát cũng là nội dung do máy tạo, không có ngoại lệ.
    const pcm = fromWav(r.wav);
    const stamp = pcm
      ? this.compliance.stamp(pcm.samples, {
        voiceId: profile.voiceId, provider: `sing:${r.engine}`, text: lyrics,
        subjectId: learnerId, sampleRate: pcm.sampleRate, audible: false,
      })
      : { ok: true, wav: r.wav, watermarked: false, reason: 'NGUỒN_KHÔNG_PHẢI_WAV' };

    this.stats.synthesized++;
    this.stats.totalMs += r.ms;
    this.bus?.safeEmit?.('voice:sang', { voiceId: profile.voiceId, engine: r.engine, style, ms: r.ms });

    return {
      ...r,
      wav: stamp.wav || r.wav,
      ok: true,
      voiceId: profile.voiceId,
      voiceName: profile.displayName,
      gender: profile.gender,
      watermarked: !!stamp.watermarked,
      auditId: stamp.auditId || null,
      disclosure: DISCLOSURE,
    };
  }

  /** Đổi giọng một bản hát thật — cổng pháp lý hai đầu nằm trong tuyến. */
  async convertSinging(input) {
    this.stats.requests++;
    const r = await this.conversionPipeline.convert(input);
    if (!r.ok) { this.stats.denied++; return r; }
    return { ...r, disclosure: DISCLOSURE };
  }

  /** Hậu kỳ một tệp WAV có sẵn — dùng để nghe thử từng cài đặt. */
  master(wavBuffer, { preset = 'giang-bai' } = {}) {
    const pcm = fromWav(wavBuffer);
    if (!pcm) return { ok: false, error: 'KHÔNG_ĐỌC_ĐƯỢC_WAV' };
    const s = StudioChain.process(pcm.samples, pcm.sampleRate, { preset });
    const { toWav } = require('./synth');
    return {
      ok: true, wav: toWav(s.samples, s.sampleRate), preset: s.preset, presetName: s.presetName,
      steps: s.steps, before: s.before, after: s.after, ms: s.ms,
    };
  }

  /** Danh sách giọng cho màn hình quản trị và cho học viên chọn. */
  listVoices(opts = {}) { return this.profiles.list(opts); }

  voice(voiceId) { return this.profiles.get(voiceId); }

  /** Giọng của một agent, dựng tạm nếu agent không nằm trong danh sách ban đầu. */
  voiceOfAgent(agent) {
    if (typeof agent === 'string') return this.profiles.forAgent(agent);
    return this.profiles.forAgent(agent?.id) || profileFor(agent);
  }

  // ══ TIẾNG ANH ═══════════════════════════════════════════════════════════
  // Tiếng Việt và tiếng Anh dùng chung bộ tổng hợp formant nhưng khác hẳn
  // phần cao độ (thanh điệu và trọng âm), nên tách thành nhóm hàm riêng thay
  // vì nhét thêm một tham số "ngôn ngữ" vào speak().

  /** Phiên âm IPA một từ, kèm trọng âm và NGUỒN của dòng phiên âm. */
  phienAmAnh(tu, { giong = 'Anh' } = {}) { return EN.phienAm(tu, { giong }); }

  /** Phiên âm cả câu, kèm chỗ nối âm và dạng yếu của từ chức năng. */
  phienAmCauAnh(text, o = {}) { return EN.phienAmCau(text, o); }

  /** Dự báo trước những chỗ người Việt sẽ đọc sai từ này. */
  chanDoanAnh(tu, o = {}) { return EN.chanDoan(tu, o); }

  /** Dựng một bài dạy phân biệt hai âm dễ lẫn, ví dụ /iː/ với /ɪ/. */
  baiHocAmAnh(am1, am2, o = {}) { return EN.baiHocAm(am1, am2, o); }

  /** Các thế đối lập có sẵn cặp luyện trong kho từ. */
  theDoiLapAnh(o = {}) { return EN.cacTheDoiLap(o); }

  /** Đọc một câu tiếng Anh thành WAV. */
  docAnh(text, o = {}) {
    this.stats.requests++;
    const r = ENS.doc(text, o);
    if (r.ok) { this.stats.synthesized++; this.stats.totalMs += r.ms; this.stats.totalChars += String(text).length; }
    return r;
  }

  /** Đọc chậm một cặp tối thiểu, có khoảng lặng giữa hai từ để tai kịp so sánh. */
  docCapAnh(tu1, tu2, o = {}) {
    this.stats.requests++;
    const r = ENS.docCapToiThieu(tu1, tu2, o);
    if (r.ok) { this.stats.synthesized++; this.stats.totalMs += r.ms; }
    return r;
  }

  /**
   * Bài nghe trong kho học liệu đánh dấu phần lời thoại bằng [NGHE]…[/NGHE].
   * Hàm này rút đúng phần đó ra và đọc thành tiếng, để học viên NGHE chứ không
   * đọc chữ — đúng như một bài nghe phải được dùng.
   */
  docBaiNghe(deBai, o = {}) {
    const m = String(deBai || '').match(/\[NGHE\]([\s\S]*?)\[\/NGHE\]/);
    if (!m) return { ok: false, error: 'ĐỀ_KHÔNG_CÓ_PHẦN_NGHE', howToFix: 'Phần lời thoại phải nằm trong [NGHE]…[/NGHE].' };
    const kich = m[1].trim();
    const r = this.docAnh(kich, { nhanh: true, ...o });
    return r.ok ? { ...r, kichBan: kich } : r;
  }

  status() {
    return {
      tiengAnh: {
        amVi: Object.keys(EN.NGUYEN_AM_DON).length + Object.keys(EN.NGUYEN_AM_DOI).length + Object.keys(EN.PHU_AM).length,
        tuDien: Object.keys(EN.TU_DIEN).length,
        luatChuAm: EN.LUAT.length,
        capToiThieu: EN.khoCapToiThieu().length,
        theDoiLap: EN.cacTheDoiLap().length,
      },
      voices: this.profiles.stats(),
      providers: this.providers.status(),
      pipelines: {
        speech: this.speechPipeline.status(),
        singing: this.singingPipeline.status(),
        conversion: this.conversionPipeline.status(),
      },
      studio: { enabled: cfg.VOICE.studioEnabled, presets: StudioChain.presets(), engine: 'JS_DSP' },
      ranges: Object.entries(RANGES).map(([id, r]) => ({ id, name: r.name, lo: midiName(r.lo), hi: midiName(r.hi) })),
      compliance: this.compliance.status(),
      cache: this.cache.status(),
      limits: { maxChars: cfg.VOICE.maxChars, sampleRate: cfg.VOICE.sampleRate },
      stats: {
        ...this.stats,
        avgMsPerRequest: this.stats.synthesized ? Math.round(this.stats.totalMs / this.stats.synthesized) : 0,
        avgCharsPerRequest: this.stats.synthesized ? Math.round(this.stats.totalChars / this.stats.synthesized) : 0,
      },
    };
  }
}

module.exports = { VoiceService, AudioCache };
