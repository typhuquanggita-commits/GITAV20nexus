'use strict';
/**
 * PIPELINE 2 — HÁT (SVS: tổng hợp giọng hát từ lời + giai điệu)
 *
 * Thứ tự: OpenUtau+DiffSinger (nếu có voicebank tiếng Việt) → SoulX-Singer
 * (chỉ cho lời Anh/Trung) → bộ hát formant nội bộ. Bộ nội bộ luôn chạy được,
 * nên hệ thống hát được ngay cả khi chưa cài mô hình nào.
 *
 * Hát xong luôn qua hậu kỳ: giọng hát tổng hợp thiếu biên độ động và thiếu
 * hài — đó chính là lý do nghe "ra máy". Nén song song và bão hoà hài bù đúng
 * hai thứ đó.
 */

const cfg = require('../../config');
const { SingingVoice, STYLES, prepare } = require('../singing');
const { StudioChain } = require('../dsp');
const { toWav, fromWav } = require('../synth');
const { round } = require('../../utils');

/** Thể loại hát → cài đặt hậu kỳ tương ứng. */
const STYLE_PRESET = { pop: 'hat-pop', ballad: 'hat-ballad', 'dan-ca': 'hat-ballad', 'thieu-nhi': 'hat-pop', 'doc-rap': 'phat-thanh' };

class SingingPipeline {
  constructor({ neural = {}, compliance = null }) {
    this.soulx = neural.soulx || null;
    this.openUtau = neural.openUtau || null;
    this.compliance = compliance;
    this.stats = { songs: 0, notes: 0, ms: 0, byStyle: Object.create(null), byEngine: Object.create(null) };
  }

  engines() {
    const list = [{ id: 'offline-formant', name: 'Bộ hát formant nội bộ', available: true, languages: ['vi'], note: 'Luôn chạy được, không cần cài gì' }];
    if (this.openUtau) { const a = this.openUtau.available(); list.push({ id: this.openUtau.id, name: this.openUtau.name, available: a.ok, reason: a.reason, fix: a.fix, languages: ['vi', 'en', 'ja'], note: this.openUtau.note }); }
    if (this.soulx) { const a = this.soulx.available(); list.push({ id: this.soulx.id, name: this.soulx.name, available: a.ok, reason: a.reason, fix: a.fix, languages: this.soulx.languages, note: this.soulx.note }); }
    return list;
  }

  /** Kiểm tra trước khi hát: lời có khớp nốt không, có vượt quãng giọng không. */
  check({ lyrics, melody = null, midi = null, bpm = 90, range = null, track = null, channel = null }) {
    const p = prepare({ lyrics, melody, midi, bpm, range, track, channel });
    if (!p.ok) return p;
    const seconds = round(p.totalMs / 1000, 1);
    if (seconds > cfg.VOICE.maxSongSeconds) {
      return { ok: false, error: 'BÀI_QUÁ_DÀI', seconds, maxSeconds: cfg.VOICE.maxSongSeconds };
    }
    return {
      ok: true,
      notes: p.notes.length,
      pitched: p.notes.filter((n) => !n.rest).length,
      rests: p.notes.filter((n) => n.rest).length,
      seconds,
      source: p.source,
      transpose: p.transpose,
      fit: p.fit,
      alignment: {
        ok: p.align.ok, syllables: p.align.syllables, notes: p.align.notes,
        melisma: p.align.melisma, warning: p.align.warning,
      },
      styles: Object.entries(STYLES).map(([id, s]) => ({ id, name: s.name })),
    };
  }

  /**
   * Hát một bài.
   * @returns {Promise<object>} {ok, wav, ms, sung, studio, engine}
   */
  async sing({ lyrics, melody = null, midi = null, bpm = 90, range = null, style = 'pop', profile = {}, studio = true, preset = null, track = null, channel = null, lang = 'vi', ustxPath = null }) {
    const chk = this.check({ lyrics, melody, midi, bpm, range, track, channel });
    if (!chk.ok) return chk;
    const p = prepare({ lyrics, melody, midi, bpm, range, track, channel });

    // 1) OpenUtau + DiffSinger nếu người vận hành đã dựng sẵn tệp .ustx
    if (ustxPath && this.openUtau && this.openUtau.available().ok) {
      const r = await this.openUtau.sing({ ustxPath });
      if (r.ok) return this._finish(r.wav, null, { engine: this.openUtau.id, style, studio, preset, check: chk });
    }
    // 2) SoulX-Singer cho lời không phải tiếng Việt
    if (lang !== 'vi' && this.soulx && this.soulx.available().ok && midi) {
      const r = await this.soulx.sing({ lyrics, midiPath: midi, referenceAudio: profile.referenceAudio, style, lang });
      if (r.ok) return this._finish(r.wav, null, { engine: this.soulx.id, style, studio, preset, check: chk });
    }
    // 3) Bộ hát nội bộ — mặc định, luôn chạy
    const voice = new SingingVoice(profile, { style });
    const sung = voice.sing(lyrics, p.notes);
    if (!sung.ok) return sung;

    this.stats.songs++;
    this.stats.notes += sung.notesSung;
    this.stats.ms += sung.ms;
    this.stats.byStyle[style] = (this.stats.byStyle[style] || 0) + 1;
    this.stats.byEngine['offline-formant'] = (this.stats.byEngine['offline-formant'] || 0) + 1;

    return this._finish(null, sung, { engine: 'offline-formant', style, studio, preset, check: chk });
  }

  _finish(wavIn, sung, { engine, style, studio, preset, check }) {
    let samples; let sr;
    if (sung) { samples = sung.samples; sr = sung.sampleRate; } else {
      const pcm = fromWav(wavIn);
      if (!pcm) return { ok: true, wav: wavIn, engine, style, studio: { skipped: 'NGUỒN_KHÔNG_PHẢI_WAV' }, check };
      samples = pcm.samples; sr = pcm.sampleRate;
    }

    let studioReport = null;
    if (studio && cfg.VOICE.studioEnabled) {
      const s = StudioChain.process(samples, sr, { preset: preset || STYLE_PRESET[style] || 'hat-pop' });
      samples = s.samples;
      studioReport = { preset: s.preset, presetName: s.presetName, steps: s.steps, before: s.before, after: s.after, ms: s.ms };
    }

    return {
      ok: true,
      wav: toWav(samples, sr),
      sampleRate: sr,
      ms: Math.round(samples.length / sr * 1000),
      engine,
      style,
      styleName: (STYLES[style] || STYLES.pop).name,
      sung: sung ? sung.sung : null,
      notesSung: sung ? sung.notesSung : null,
      unknown: sung ? sung.unknown : [],
      alignment: sung ? sung.alignment : null,
      studio: studioReport,
      check,
    };
  }

  status() {
    return {
      engines: this.engines(),
      styles: Object.entries(STYLES).map(([id, s]) => ({ id, name: s.name, vibrato: s.vibratoDepth, toneBlend: s.toneBlend })),
      stats: { ...this.stats, byStyle: { ...this.stats.byStyle }, byEngine: { ...this.stats.byEngine } },
      maxSongSeconds: cfg.VOICE.maxSongSeconds,
    };
  }
}

module.exports = { SingingPipeline, STYLE_PRESET };
