'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  ĐỌC TIẾNG ANH — dựng sóng âm từ phiên âm IPA
 * ═══════════════════════════════════════════════════════════════════════════
 *  Dùng chung đúng bộ tổng hợp formant đã dựng cho tiếng Việt: cùng nguồn
 *  thanh, cùng ba cộng hưởng khoang miệng. Chỉ khác phần CAO ĐỘ.
 *
 *    tiếng Việt: cao độ do THANH ĐIỆU quyết định — mỗi âm tiết một đường đi
 *                riêng, sai đường là sai nghĩa.
 *    tiếng Anh : cao độ do TRỌNG ÂM và NGỮ ĐIỆU CÂU quyết định — âm tiết mang
 *                trọng âm cao hơn và dài hơn, cả câu hạ dần về cuối, câu hỏi
 *                dạng có/không thì lên giọng ở cuối.
 *
 *  Vì vậy ở đây không có đường thanh điệu; thay vào đó là hàm cao độ theo
 *  trọng âm và theo vị trí trong câu.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { VoiceSynth, toWav, SAMPLE_RATE } = require('./synth');
const EN = require('./en-phonemizer');

/** Câu hỏi có/không lên giọng cuối câu; câu hỏi bắt đầu bằng từ hỏi thì không. */
function kieuNguDieu(cau) {
  const t = String(cau || '').trim();
  if (!t.endsWith('?')) return t.endsWith('!') ? 'cảm thán' : 'trần thuật';
  return /^(what|where|when|why|who|whose|which|how)\b/i.test(t) ? 'hỏi có từ hỏi' : 'hỏi có không';
}

/**
 * Đọc một từ hoặc một câu tiếng Anh thành WAV.
 * @param {string} text
 * @param {object} o
 *   giong  'Anh' | 'Mỹ'
 *   nhanh  true thì dùng dạng yếu của từ chức năng (nói tự nhiên);
 *          false thì đọc dạng mạnh, chậm và rõ — dùng khi dạy phát âm.
 *   profile hồ sơ giọng (cao độ nền, độ hơi…) như bên tiếng Việt
 */
function doc(text, { giong = 'Anh', nhanh = true, rate = 1.0, profile = {} } = {}) {
  const ph = EN.phienAmCau(text, { giong, nhanh, rate });
  if (!ph.ok) return ph;
  const synth = new VoiceSynth({ f0: 112, f0Range: 0.22, ...profile });
  const nguDieu = kieuNguDieu(text);

  const tuCoAm = ph.items.filter((x) => x.type === 'word');
  const chunks = [];
  let chiSo = 0;

  for (const it of ph.items) {
    if (it.type === 'pause') { chunks.push(synth.silence(it.ms / rate)); continue; }
    if (!it.segments || !it.segments.length) continue;

    // Ngữ điệu câu: hạ dần về cuối. Câu hỏi có/không thì đảo chiều ở từ cuối.
    const viTri = tuCoAm.length > 1 ? chiSo / (tuCoAm.length - 1) : 0;
    let heSo = 1 + synth.p.f0Range * (0.45 - viTri) * 0.9;
    if (nguDieu === 'hỏi có không' && chiSo === tuCoAm.length - 1) heSo = 1 + synth.p.f0Range * 0.85;
    if (nguDieu === 'cảm thán' && chiSo === 0) heSo *= 1.06;

    // Trọng âm từ: âm tiết mang trọng âm cao hơn — đã ghi sẵn trong từng đoạn.
    const segs = it.segments.map((s) => ({ ...s, toneContour: [1, 1, 1, 1] }));
    const f0Base = synth.p.f0 * heSo;
    chunks.push(synth.renderSegments(segs, {
      f0Base,
      f0At: (t, ms, seg) => f0Base * (seg && seg.f0 ? seg.f0 : 1),
    }));
    // Khe hở giữa hai từ: ngắn hơn khe giữa hai âm tiết tiếng Việt, vì tiếng
    // Anh nối từ liền nhau. Chỗ có nối âm thì gần như không có khe.
    const coNoi = ph.noiAm.some((n) => n.truoc === it.tu);
    chunks.push(synth.silence((coNoi ? 6 : 26) / rate));
    chiSo++;
  }

  const tong = chunks.reduce((s, c) => s + c.length, 0);
  const out = new Float32Array(tong);
  let o = 0;
  for (const c of chunks) { out.set(c, o); o += c.length; }
  let dinh = 0;
  for (let i = 0; i < out.length; i++) dinh = Math.max(dinh, Math.abs(out[i]));
  if (dinh > 0) { const k = 0.89 / dinh; for (let i = 0; i < out.length; i++) out[i] *= k; }

  return {
    ok: true,
    wav: toWav(out, SAMPLE_RATE),
    ms: Math.round((out.length / SAMPLE_RATE) * 1000),
    sampleRate: SAMPLE_RATE,
    ipa: ph.ipa,
    tu: ph.tu,
    amTiet: ph.amTiet,
    noiAm: ph.noiAm,
    chuaBiet: ph.chuaBiet,
    nguDieu,
    giong,
    nhanh,
  };
}

/**
 * Đọc CHẬM một cặp tối thiểu để học viên nghe ra chỗ khác nhau:
 * từ thứ nhất — im lặng — từ thứ hai — im lặng — lặp lại.
 * Đây là cách luyện nghe phân biệt thật sự dùng trên lớp.
 */
function docCapToiThieu(tu1, tu2, { giong = 'Anh', lap = 2, profile = {} } = {}) {
  const synth = new VoiceSynth({ f0: 112, f0Range: 0.1, ...profile });
  const chunks = [];
  for (let i = 0; i < lap; i++) {
    for (const w of [tu1, tu2]) {
      const d = EN.doanAm(w, { rate: 0.75, giong });
      if (!d.ok) return d;
      chunks.push(synth.renderSegments(d.segments.map((s) => ({ ...s, toneContour: [1, 1, 1, 1] })), { f0Base: synth.p.f0 }));
      chunks.push(synth.silence(520));
    }
    chunks.push(synth.silence(360));
  }
  const tong = chunks.reduce((s, c) => s + c.length, 0);
  const out = new Float32Array(tong);
  let o = 0;
  for (const c of chunks) { out.set(c, o); o += c.length; }
  let dinh = 0;
  for (let i = 0; i < out.length; i++) dinh = Math.max(dinh, Math.abs(out[i]));
  if (dinh > 0) { const k = 0.89 / dinh; for (let i = 0; i < out.length; i++) out[i] *= k; }
  return {
    ok: true, wav: toWav(out, SAMPLE_RATE), ms: Math.round((out.length / SAMPLE_RATE) * 1000),
    sampleRate: SAMPLE_RATE,
    tu1, ipa1: EN.phienAm(tu1, { giong }).ipa,
    tu2, ipa2: EN.phienAm(tu2, { giong }).ipa,
    lap,
  };
}

module.exports = { doc, docCapToiThieu, kieuNguDieu };
