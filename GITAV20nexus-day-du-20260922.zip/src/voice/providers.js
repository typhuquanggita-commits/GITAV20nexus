'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  TẦNG NHÀ CUNG CẤP GIỌNG
 * ═══════════════════════════════════════════════════════════════════════════
 *  Tài liệu gốc dựng giọng bằng cách gọi
 *      https://translate.google.com/translate_tts?...&client=tw-ob
 *  Đây là cổng KHÔNG CHÍNH THỨC: không có hợp đồng, không có SLA, bị chặn theo
 *  IP, giới hạn ~200 ký tự mỗi lần và vi phạm điều khoản sử dụng. Chính tài
 *  liệu cũng ghi "có thể bị chặn … để production cần thay". Dựng cả hệ thống
 *  dạy học 500 giảng viên lên trên một cổng như vậy là hỏng ngay ngày đầu.
 *
 *  CHỈNH SỬA ĐỂ CHẠY THẬT:
 *    1. Mặc định là OFFLINE_FORMANT — bộ tổng hợp formant tiếng Việt tự dựng
 *       trong src/voice/synth.js. Chạy trong tiến trình, không mạng, không
 *       khoá, không giới hạn ký tự, tất định. Luôn luôn dùng được.
 *    2. Muốn giọng hay hơn thì cắm thêm nhà cung cấp: piper (nơ-ron, cục bộ,
 *       miễn phí), Google Cloud TTS / Azure / ElevenLabs (có hợp đồng, có khoá).
 *    3. Cổng dịch không chính thức vẫn giữ lại NHƯNG tắt sẵn, phải bật tay
 *       bằng VOICE_ALLOW_UNOFFICIAL=1 và tự chịu trách nhiệm.
 *
 *  Mọi nhà cung cấp đều báo cáo TRUNG THỰC: available() nói rõ thiếu gì, và
 *  hệ thống tự lùi về bộ offline thay vì trả lỗi cho học viên.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { execFile } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const cfg = require('../config');
const { VoiceSynth, toWav, SAMPLE_RATE } = require('./synth');

/** Khung chung. Nhà cung cấp nào cũng phải trả đúng hình dạng này. */
class VoiceProvider {
  constructor(id, name, meta = {}) {
    this.id = id;
    this.name = name;
    this.kind = meta.kind || 'local';
    this.needsNetwork = meta.needsNetwork || false;
    this.needsKey = meta.needsKey || false;
    this.official = meta.official !== false;
    this.quality = meta.quality || 'trung bình';
    this.note = meta.note || '';
  }

  /** @returns {{ok:boolean, reason?:string, fix?:string}} */
  available() { return { ok: false, reason: 'NOT_IMPLEMENTED' }; }

  /** @returns {Promise<{ok:boolean, wav?:Buffer, ms?:number, sampleRate?:number, provider:string, error?:string}>} */
  async synthesize() { return { ok: false, provider: this.id, error: 'NOT_IMPLEMENTED' }; }

  describe() {
    const av = this.available();
    return {
      id: this.id,
      name: this.name,
      kind: this.kind,
      official: this.official,
      needsNetwork: this.needsNetwork,
      needsKey: this.needsKey,
      quality: this.quality,
      note: this.note,
      available: av.ok,
      reason: av.reason || null,
      fix: av.fix || null,
    };
  }
}

/** ── 1. Bộ tổng hợp formant tiếng Việt, chạy tại chỗ ─────────────────────── */
class OfflineFormantProvider extends VoiceProvider {
  constructor() {
    super('offline', 'Bộ tổng hợp formant tiếng Việt (nội bộ)', {
      kind: 'in-process',
      quality: 'rõ tiếng, đúng 6 thanh điệu — chưa bằng giọng người thu',
      note: 'Không cần mạng, không cần khoá, không giới hạn ký tự, kết quả tất định.',
    });
  }

  available() { return { ok: true }; }

  async synthesize(text, profile, { rate = 1.0 } = {}) {
    const synth = new VoiceSynth(profile.params || profile);
    const r = synth.render(text, { rate });
    return {
      ok: true,
      provider: this.id,
      wav: toWav(r.samples, r.sampleRate),
      ms: r.ms,
      sampleRate: r.sampleRate,
      syllables: r.syllables,
      unknown: r.unknown,
    };
  }
}

/** ── 2. piper — mô hình nơ-ron chạy cục bộ, miễn phí, chất lượng cao ─────── */
class PiperProvider extends VoiceProvider {
  constructor() {
    super('piper', 'piper (nơ-ron, chạy cục bộ)', {
      kind: 'local-binary',
      quality: 'gần giọng người, chạy offline',
      note: 'Cần cài piper và một mô hình tiếng Việt (vi_VN-*.onnx).',
    });
  }

  available() {
    const bin = cfg.VOICE.piperBin;
    const model = cfg.VOICE.piperModel;
    if (!bin) return { ok: false, reason: 'THIẾU_PIPER_BIN', fix: 'Đặt PIPER_BIN=/đường/dẫn/piper' };
    if (!fs.existsSync(bin)) return { ok: false, reason: 'KHÔNG_TÌM_THẤY_PIPER', fix: `Không có tệp ${bin}` };
    if (!model) return { ok: false, reason: 'THIẾU_PIPER_MODEL', fix: 'Đặt PIPER_MODEL=/đường/dẫn/vi_VN-....onnx' };
    if (!fs.existsSync(model)) return { ok: false, reason: 'KHÔNG_TÌM_THẤY_MODEL', fix: `Không có tệp ${model}` };
    return { ok: true };
  }

  async synthesize(text, profile) {
    const av = this.available();
    if (!av.ok) return { ok: false, provider: this.id, error: av.reason };
    // Tên tệp tạm phải duy nhất nhưng KHÔNG được ngẫu nhiên: cả hệ thống chạy
    // tất định, và một bộ đếm kèm mã tiến trình đã đủ tránh trùng.
    this._seq = (this._seq || 0) + 1;
    const out = path.join(os.tmpdir(), `gita-voice-${process.pid}-${Date.now()}-${this._seq}.wav`);
    const args = ['--model', cfg.VOICE.piperModel, '--output_file', out];
    // piper nhận tốc độ qua length_scale: >1 là chậm lại.
    const rate = (profile.params || profile).rate || 1.0;
    args.push('--length_scale', String(Number((1 / rate).toFixed(3))));
    try {
      await new Promise((resolve, reject) => {
        const child = execFile(cfg.VOICE.piperBin, args, { timeout: 30_000 }, (err) => (err ? reject(err) : resolve()));
        child.stdin.end(text);
      });
      const wav = fs.readFileSync(out);
      fs.unlinkSync(out);
      const ms = Math.round(((wav.length - 44) / 2 / SAMPLE_RATE) * 1000);
      return { ok: true, provider: this.id, wav, ms, sampleRate: SAMPLE_RATE };
    } catch (e) {
      try { if (fs.existsSync(out)) fs.unlinkSync(out); } catch { /* bỏ qua */ }
      return { ok: false, provider: this.id, error: `PIPER_LỖI: ${e.message}` };
    }
  }
}

/** ── 3. Google Cloud Text-to-Speech — có hợp đồng, có khoá ───────────────── */
class GoogleCloudProvider extends VoiceProvider {
  constructor() {
    super('google-cloud', 'Google Cloud Text-to-Speech', {
      kind: 'cloud', needsNetwork: true, needsKey: true,
      quality: 'giọng người (WaveNet/Neural2), có giọng vi-VN',
      note: 'Tính tiền theo ký tự. Cần GOOGLE_TTS_API_KEY.',
    });
  }

  available() {
    if (!cfg.VOICE.googleKey) return { ok: false, reason: 'THIẾU_KHOÁ', fix: 'Đặt GOOGLE_TTS_API_KEY' };
    return { ok: true };
  }

  async synthesize(text, profile) {
    const av = this.available();
    if (!av.ok) return { ok: false, provider: this.id, error: av.reason };
    const p = profile.params || profile;
    const body = {
      input: { text },
      voice: {
        languageCode: 'vi-VN',
        ssmlGender: (profile.gender === 'nam') ? 'MALE' : 'FEMALE',
      },
      audioConfig: {
        audioEncoding: 'LINEAR16',
        sampleRateHertz: cfg.VOICE.sampleRate,
        speakingRate: Math.max(0.25, Math.min(4, p.rate || 1)),
        // Cao độ của Google tính bằng nửa cung (-20..20), quy từ f0 hồ sơ.
        pitch: Math.max(-20, Math.min(20, Math.round(12 * Math.log2((p.f0 || 150) / (profile.gender === 'nam' ? 118 : 205))))),
      },
    };
    try {
      const res = await fetch(`https://texttospeech.googleapis.com/v1/text:synthesize?key=${encodeURIComponent(cfg.VOICE.googleKey)}`, {
        method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body),
        signal: AbortSignal.timeout(20_000),
      });
      if (!res.ok) return { ok: false, provider: this.id, error: `HTTP_${res.status}` };
      const json = await res.json();
      if (!json.audioContent) return { ok: false, provider: this.id, error: 'KHÔNG_CÓ_ÂM_THANH' };
      const wav = Buffer.from(json.audioContent, 'base64');
      return { ok: true, provider: this.id, wav, ms: Math.round(((wav.length - 44) / 2 / cfg.VOICE.sampleRate) * 1000), sampleRate: cfg.VOICE.sampleRate };
    } catch (e) {
      return { ok: false, provider: this.id, error: `MẠNG_LỖI: ${e.message}` };
    }
  }
}

/** ── 4. Azure Speech — nhiều giọng vi-VN, giá tốt cho giáo dục ───────────── */
class AzureProvider extends VoiceProvider {
  constructor() {
    super('azure', 'Microsoft Azure Speech', {
      kind: 'cloud', needsNetwork: true, needsKey: true,
      quality: 'giọng người (HoaiMy, NamMinh)',
      note: 'Cần AZURE_SPEECH_KEY và AZURE_SPEECH_REGION.',
    });
  }

  available() {
    if (!cfg.VOICE.azureKey) return { ok: false, reason: 'THIẾU_KHOÁ', fix: 'Đặt AZURE_SPEECH_KEY' };
    if (!cfg.VOICE.azureRegion) return { ok: false, reason: 'THIẾU_VÙNG', fix: 'Đặt AZURE_SPEECH_REGION' };
    return { ok: true };
  }

  /** SSML có thoát ký tự — không để nội dung bài toán phá cấu trúc thẻ. */
  _ssml(text, profile) {
    const esc = String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const p = profile.params || profile;
    const voice = profile.gender === 'nam' ? 'vi-VN-NamMinhNeural' : 'vi-VN-HoaiMyNeural';
    const ratePct = Math.round(((p.rate || 1) - 1) * 100);
    return `<speak version="1.0" xml:lang="vi-VN"><voice name="${voice}">`
      + `<prosody rate="${ratePct >= 0 ? '+' : ''}${ratePct}%">${esc}</prosody></voice></speak>`;
  }

  async synthesize(text, profile) {
    const av = this.available();
    if (!av.ok) return { ok: false, provider: this.id, error: av.reason };
    try {
      const res = await fetch(`https://${cfg.VOICE.azureRegion}.tts.speech.microsoft.com/cognitiveservices/v1`, {
        method: 'POST',
        headers: {
          'Ocp-Apim-Subscription-Key': cfg.VOICE.azureKey,
          'Content-Type': 'application/ssml+xml',
          'X-Microsoft-OutputFormat': 'riff-22050hz-16bit-mono-pcm',
        },
        body: this._ssml(text, profile),
        signal: AbortSignal.timeout(20_000),
      });
      if (!res.ok) return { ok: false, provider: this.id, error: `HTTP_${res.status}` };
      const wav = Buffer.from(await res.arrayBuffer());
      return { ok: true, provider: this.id, wav, ms: Math.round(((wav.length - 44) / 2 / 22050) * 1000), sampleRate: 22050 };
    } catch (e) {
      return { ok: false, provider: this.id, error: `MẠNG_LỖI: ${e.message}` };
    }
  }
}

/** ── 5. ElevenLabs — giọng tự nhiên nhất, đắt nhất ───────────────────────── */
class ElevenLabsProvider extends VoiceProvider {
  constructor() {
    super('elevenlabs', 'ElevenLabs', {
      kind: 'cloud', needsNetwork: true, needsKey: true,
      quality: 'tự nhiên nhất, có nhân bản giọng',
      note: 'Trả về MP3. Cần ELEVENLABS_API_KEY và voice_id ánh xạ sẵn.',
    });
  }

  available() {
    if (!cfg.VOICE.elevenLabsKey) return { ok: false, reason: 'THIẾU_KHOÁ', fix: 'Đặt ELEVENLABS_API_KEY' };
    return { ok: true };
  }

  async synthesize(text, profile) {
    const av = this.available();
    if (!av.ok) return { ok: false, provider: this.id, error: av.reason };
    const externalId = profile.externalVoiceId;
    if (!externalId) return { ok: false, provider: this.id, error: 'CHƯA_ÁNH_XẠ_VOICE_ID' };
    try {
      const res = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(externalId)}`, {
        method: 'POST',
        headers: { 'xi-api-key': cfg.VOICE.elevenLabsKey, 'content-type': 'application/json' },
        body: JSON.stringify({ text, model_id: 'eleven_multilingual_v2' }),
        signal: AbortSignal.timeout(30_000),
      });
      if (!res.ok) return { ok: false, provider: this.id, error: `HTTP_${res.status}` };
      const audio = Buffer.from(await res.arrayBuffer());
      return { ok: true, provider: this.id, wav: audio, mime: 'audio/mpeg', ms: 0, sampleRate: 44100 };
    } catch (e) {
      return { ok: false, provider: this.id, error: `MẠNG_LỖI: ${e.message}` };
    }
  }
}

/** ── 6. Cổng dịch không chính thức — GIỮ NHƯNG TẮT SẴN ───────────────────── */
class UnofficialTranslateProvider extends VoiceProvider {
  constructor() {
    super('google-translate-unofficial', 'Google Translate TTS (KHÔNG CHÍNH THỨC)', {
      kind: 'cloud', needsNetwork: true, official: false,
      quality: 'khá, nhưng không được phép dùng cho sản phẩm thật',
      note: 'Cổng nội bộ của Google Dịch: không hợp đồng, chặn theo IP, tối đa ~200 ký tự, '
          + 'vi phạm điều khoản. Chỉ bật để thử nghiệm bằng VOICE_ALLOW_UNOFFICIAL=1.',
    });
  }

  available() {
    if (!cfg.VOICE.allowUnofficial) {
      return { ok: false, reason: 'ĐÃ_TẮT_THEO_MẶC_ĐỊNH', fix: 'VOICE_ALLOW_UNOFFICIAL=1 nếu tự chịu trách nhiệm pháp lý' };
    }
    return { ok: true };
  }

  async synthesize(text) {
    const av = this.available();
    if (!av.ok) return { ok: false, provider: this.id, error: av.reason };
    if (String(text).length > 200) return { ok: false, provider: this.id, error: 'QUÁ_200_KÝ_TỰ' };
    try {
      const url = 'https://translate.google.com/translate_tts?ie=UTF-8&tl=vi&client=tw-ob&q='
        + encodeURIComponent(text);
      const res = await fetch(url, { headers: { 'user-agent': 'Mozilla/5.0' }, signal: AbortSignal.timeout(15_000) });
      if (!res.ok) return { ok: false, provider: this.id, error: `HTTP_${res.status}` };
      return { ok: true, provider: this.id, wav: Buffer.from(await res.arrayBuffer()), mime: 'audio/mpeg', ms: 0, sampleRate: 24000 };
    } catch (e) {
      return { ok: false, provider: this.id, error: `MẠNG_LỖI: ${e.message}` };
    }
  }
}

/**
 * Bộ điều phối: chọn nhà cung cấp, tự lùi về bộ offline khi nhà cung cấp
 * ngoài hỏng. Học viên đang học không được nghe thấy lỗi hạ tầng.
 */
class ProviderRegistry {
  constructor() {
    this.providers = new Map();
    // Nạp muộn: neural-providers.js có require ngược lại tệp này để lấy lớp
    // VoiceProvider, nạp sớm là vòng tròn.
    const NV = require('./neural-providers');
    for (const P of [
      OfflineFormantProvider,
      NV.EdgeTtsProvider, NV.ZeroTtsProvider, NV.VieNeuProvider, NV.GOmniVoiceProvider,
      PiperProvider, GoogleCloudProvider, AzureProvider, ElevenLabsProvider,
      UnofficialTranslateProvider,
    ]) {
      const p = new P();
      this.providers.set(p.id, p);
    }
    this.preferred = cfg.VOICE.provider;
    this.stats = { calls: 0, byProvider: Object.create(null), fallbacks: 0, failures: 0 };
  }

  get(id) { return this.providers.get(id) || null; }

  /** Nhà cung cấp thật sự dùng được lúc này, theo thứ tự ưu tiên. */
  chain(prefer = null) {
    const order = [];
    for (const id of [prefer, this.preferred]) {
      if (id && this.providers.has(id) && !order.includes(id)) order.push(id);
    }
    if (!order.includes('offline')) order.push('offline');
    return order.map((id) => this.providers.get(id)).filter((p) => p.available().ok);
  }

  /**
   * Đọc một đoạn văn bản. Luôn trả về âm thanh: nếu nhà cung cấp ưu tiên hỏng
   * thì lùi về bộ offline và ghi rõ đã lùi.
   */
  async synthesize(text, profile, { prefer = null, rate = 1.0 } = {}) {
    this.stats.calls++;
    const chain = this.chain(prefer);
    const tried = [];
    for (const p of chain) {
      const r = await p.synthesize(text, profile, { rate });
      if (r.ok) {
        this.stats.byProvider[p.id] = (this.stats.byProvider[p.id] || 0) + 1;
        if (tried.length) this.stats.fallbacks++;
        return { ...r, triedBefore: tried };
      }
      tried.push({ provider: p.id, error: r.error });
    }
    this.stats.failures++;
    return { ok: false, provider: null, error: 'KHÔNG_NHÀ_CUNG_CẤP_NÀO_CHẠY', tried };
  }

  status() {
    return {
      preferred: this.preferred,
      effective: this.chain()[0]?.id || null,
      providers: [...this.providers.values()].map((p) => p.describe()),
      stats: { ...this.stats, byProvider: { ...this.stats.byProvider } },
    };
  }
}

module.exports = {
  ProviderRegistry, VoiceProvider,
  OfflineFormantProvider, PiperProvider, GoogleCloudProvider,
  AzureProvider, ElevenLabsProvider, UnofficialTranslateProvider,
};
