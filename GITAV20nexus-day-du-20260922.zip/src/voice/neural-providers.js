'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BỘ TỔNG HỢP NƠ-RON TIẾNG VIỆT — bộ chuyển tiếp trung thực
 * ═══════════════════════════════════════════════════════════════════════════
 *  ZeroTTS, VieNeu-TTS v3, G-OmniVoice là ba mô hình tiếng Việt tốt nhất hiện
 *  có. Cả ba đều cần Python, cần tải mô hình hàng GB, phần lớn cần GPU. Máy
 *  chủ này chưa có gì trong số đó.
 *
 *  Nên ở đây không có "mã giả vờ chạy". Mỗi bộ là một BỘ CHUYỂN TIẾP THẬT:
 *    · gọi được theo hai cách — máy chủ HTTP cục bộ, hoặc chạy thẳng Python
 *    · available() kiểm tra tới nơi tới chốn: có thư mục không, có tệp suy
 *      luận không, có biến môi trường không — và nói RÕ thiếu gì
 *    · chưa cài thì báo "chưa sẵn sàng", hệ thống tự lùi về bộ formant nội bộ
 *
 *  Cài xong là chạy, không phải sửa một dòng nào ở đây.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { execFile } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const cfg = require('../config');
const { VoiceProvider } = require('./providers');

let tmpSeq = 0;
const tmpFile = (ext) => path.join(os.tmpdir(), `gita-nv-${process.pid}-${Date.now()}-${++tmpSeq}.${ext}`);

/** Khung chung cho mô hình chạy cục bộ: HTTP trước, Python sau. */
class LocalNeuralProvider extends VoiceProvider {
  constructor(id, name, meta, { url, dir, entry, buildArgs, buildBody }) {
    super(id, name, meta);
    this.url = url;
    this.dir = dir;
    this.entry = entry;
    this.buildArgs = buildArgs;
    this.buildBody = buildBody;
    this.envUrl = meta.envUrl;
    this.envDir = meta.envDir;
  }

  available() {
    if (this.url) return { ok: true, via: 'http' };
    if (!this.dir) {
      return { ok: false, reason: 'CHƯA_CÀI', fix: `Đặt ${this.envUrl} (máy chủ cục bộ) hoặc ${this.envDir} (thư mục mô hình)` };
    }
    if (!fs.existsSync(this.dir)) return { ok: false, reason: 'KHÔNG_TÌM_THẤY_THƯ_MỤC', fix: `Không có ${this.dir}` };
    const script = path.join(this.dir, this.entry);
    if (!fs.existsSync(script)) return { ok: false, reason: 'THIẾU_TỆP_SUY_LUẬN', fix: `Không có ${script}` };
    return { ok: true, via: 'python' };
  }

  async synthesize(text, profile, opts = {}) {
    const av = this.available();
    if (!av.ok) return { ok: false, provider: this.id, error: av.reason };
    return av.via === 'http' ? this._viaHttp(text, profile, opts) : this._viaPython(text, profile, opts);
  }

  async _viaHttp(text, profile, opts) {
    try {
      const res = await fetch(`${this.url.replace(/\/+$/, '')}/synthesize`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(this.buildBody(text, profile, opts)),
        signal: AbortSignal.timeout(60_000),
      });
      if (!res.ok) return { ok: false, provider: this.id, error: `HTTP_${res.status}` };
      const ct = res.headers.get('content-type') || '';
      const buf = Buffer.from(await res.arrayBuffer());
      if (ct.includes('json')) {
        const j = JSON.parse(buf.toString('utf8'));
        if (!j.audio) return { ok: false, provider: this.id, error: 'PHẢN_HỒI_KHÔNG_CÓ_ÂM_THANH' };
        const wav = Buffer.from(j.audio, 'base64');
        return { ok: true, provider: this.id, wav, sampleRate: j.sample_rate || 24000, ms: j.duration_ms || 0, via: 'http' };
      }
      return { ok: true, provider: this.id, wav: buf, sampleRate: 24000, ms: 0, via: 'http' };
    } catch (e) {
      return { ok: false, provider: this.id, error: `MẠNG_LỖI: ${e.message}` };
    }
  }

  async _viaPython(text, profile, opts) {
    const out = tmpFile('wav');
    const args = [path.join(this.dir, this.entry), ...this.buildArgs(text, profile, opts, out)];
    try {
      await new Promise((resolve, reject) => {
        execFile(cfg.VOICE.pythonBin, args, { timeout: 120_000, cwd: this.dir }, (err, stdout, stderr) => (err ? reject(new Error(stderr || err.message)) : resolve(stdout)));
      });
      if (!fs.existsSync(out)) return { ok: false, provider: this.id, error: 'MÔ_HÌNH_KHÔNG_XUẤT_TỆP' };
      const wav = fs.readFileSync(out);
      fs.unlinkSync(out);
      return { ok: true, provider: this.id, wav, sampleRate: 24000, ms: 0, via: 'python' };
    } catch (e) {
      try { if (fs.existsSync(out)) fs.unlinkSync(out); } catch { /* bỏ qua */ }
      return { ok: false, provider: this.id, error: `CHẠY_LỖI: ${String(e.message).slice(0, 200)}` };
    }
  }
}

/** ZeroTTS — WER 1,03%, chạy thời gian thực trên CPU, không cần chuẩn hoá chữ. */
class ZeroTtsProvider extends LocalNeuralProvider {
  constructor() {
    super('zerotts', 'ZeroTTS (nơ-ron, tiếng Việt)', {
      kind: 'local-neural',
      quality: 'WER 1,03% · UTMOS 2,91 · nhân bản giọng từ 3 giây mẫu',
      note: 'Chạy được thời gian thực trên CPU (RTF ~0,5×). Hợp cho giảng bài trực tiếp.',
      envUrl: 'ZEROTTS_URL', envDir: 'ZEROTTS_DIR',
    }, {
      url: cfg.VOICE.zeroTtsUrl, dir: cfg.VOICE.zeroTtsDir, entry: 'infer.py',
      buildArgs: (text, profile, opts, out) => [
        '--text', text, '--output', out,
        '--speed', String((profile.params || profile).rate || 1),
        ...(opts.referenceAudio ? ['--reference', opts.referenceAudio] : []),
      ],
      buildBody: (text, profile, opts) => ({
        text, speed: (profile.params || profile).rate || 1,
        reference: opts.referenceAudio || null, voice: profile.externalVoiceId || null,
      }),
    });
  }
}

/** VieNeu-TTS v3 — 48 kHz, có dấu cảm xúc [cười], [thở dài], hợp bài dài. */
class VieNeuProvider extends LocalNeuralProvider {
  constructor() {
    super('vieneu', 'VieNeu-TTS v3 (nơ-ron, tiếng Việt)', {
      kind: 'local-neural',
      quality: '48 kHz · nhân bản giọng 3–5 giây · dấu cảm xúc · song ngữ Việt–Anh',
      note: 'Chất lượng cao, hợp bài giảng dài và podcast. Cần GPU để chạy nhanh.',
      envUrl: 'VIENEU_URL', envDir: 'VIENEU_DIR',
    }, {
      url: cfg.VOICE.vieNeuUrl, dir: cfg.VOICE.vieNeuDir, entry: 'inference.py',
      buildArgs: (text, profile, opts, out) => [
        '--text', text, '--output', out,
        '--speed', String((profile.params || profile).rate || 1),
        ...(opts.emotion && opts.emotion !== 'neutral' ? ['--emotion', opts.emotion] : []),
        ...(opts.referenceAudio ? ['--ref_audio', opts.referenceAudio] : []),
      ],
      buildBody: (text, profile, opts) => ({
        text, speed: (profile.params || profile).rate || 1,
        emotion: opts.emotion || 'neutral', reference: opts.referenceAudio || null,
      }),
    });
  }
}

/** G-OmniVoice — WER 2,59%, SIM 0,890; cân bằng giữa chính xác và giống giọng. */
class GOmniVoiceProvider extends LocalNeuralProvider {
  constructor() {
    super('gomnivoice', 'G-OmniVoice (nơ-ron, tiếng Việt)', {
      kind: 'local-neural',
      quality: 'WER 2,59% · SIM 0,890 · cân bằng chính xác và độ giống giọng',
      note: 'Hợp việc cần đọc thật chuẩn: đề thi, thông báo, nội dung pháp lý.',
      envUrl: 'GOMNIVOICE_URL', envDir: 'GOMNIVOICE_DIR',
    }, {
      url: cfg.VOICE.gOmniUrl, dir: cfg.VOICE.gOmniDir, entry: 'infer.py',
      buildArgs: (text, profile, opts, out) => ['--text', text, '--out', out, '--speed', String((profile.params || profile).rate || 1)],
      buildBody: (text, profile) => ({ text, speed: (profile.params || profile).rate || 1 }),
    });
  }
}

/**
 * edge-tts — giọng nơ-ron của Microsoft, miễn phí, KHÔNG CẦN KHOÁ.
 *
 * Chất lượng tiếng Việt tốt nhất trong nhóm miễn phí (HoaiMy, NamMinh).
 * Hai điều phải nói rõ:
 *  · vẫn cần mạng — nó gọi về máy chủ của Microsoft, không chạy tại máy;
 *  · nó xuất ra MP3. Lớp đóng dấu chìm và lớp trộn đường tiếng của hệ thống
 *    làm việc trên mẫu PCM, nên bản MP3 đi thẳng tới người dùng được, nhưng
 *    KHÔNG ghép vào video bài giảng được nếu máy không có bộ giải mã MP3.
 *    Cần giọng nơ-ron cho video thì dùng piper hoặc VieNeu — hai bộ đó xuất WAV.
 */
class EdgeTtsProvider extends VoiceProvider {
  constructor() {
    super('edge-tts', 'edge-tts (Microsoft, miễn phí, không cần khoá)', {
      kind: 'local-binary', needsNetwork: true,
      quality: 'giọng nơ-ron tự nhiên, tiếng Việt có HoaiMy và NamMinh',
      note: 'Cài: pip3 install edge-tts. Xuất MP3 nên không nhúng được dấu chìm và '
          + 'không ghép thẳng vào video; dùng cho tệp tiếng rời.',
    });
  }

  available() {
    const bin = cfg.VOICE.edgeBin;
    if (!bin) return { ok: false, reason: 'CHƯA_CẤU_HÌNH', fix: 'Đặt EDGE_TTS_BIN' };
    // Có thể là tên lệnh trong PATH hoặc đường dẫn tuyệt đối.
    if (bin.includes('/') && !fs.existsSync(bin)) {
      return { ok: false, reason: 'KHÔNG_TÌM_THẤY', fix: `Không có tệp ${bin}` };
    }
    if (!bin.includes('/')) {
      const trongPath = (process.env.PATH || '').split(path.delimiter)
        .some((d) => d && fs.existsSync(path.join(d, bin)));
      if (!trongPath) return { ok: false, reason: 'CHƯA_CÀI', fix: 'pip3 install edge-tts' };
    }
    return { ok: true, luuY: 'Cần mạng ra ngoài; xuất MP3.' };
  }

  _giong(profile) {
    if (profile.externalVoiceId) return profile.externalVoiceId;
    return profile.gender === 'nam' ? cfg.VOICE.edgeVoiceNam : cfg.VOICE.edgeVoiceNu;
  }

  async synthesize(text, profile, { rate = 1.0 } = {}) {
    const av = this.available();
    if (!av.ok) return { ok: false, provider: this.id, error: av.reason };
    const out = tmpFile('mp3');
    // edge-tts nhận tốc độ theo phần trăm so với bình thường.
    const phanTram = Math.round((rate - 1) * 100);
    const args = [
      '--voice', this._giong(profile),
      '--text', text,
      '--rate', `${phanTram >= 0 ? '+' : ''}${phanTram}%`,
      '--write-media', out,
    ];
    try {
      await new Promise((resolve, reject) => {
        execFile(cfg.VOICE.edgeBin, args, { timeout: 120_000 }, (err, so, se) => (err ? reject(new Error(se || err.message)) : resolve(so)));
      });
      if (!fs.existsSync(out)) throw new Error('KHÔNG_XUẤT_ĐƯỢC_TỆP');
      const buf = fs.readFileSync(out);
      fs.unlinkSync(out);
      if (buf.length < 500) throw new Error(`TỆP_QUÁ_NHỎ_${buf.length}_BYTE`);
      return { ok: true, provider: this.id, wav: buf, mime: 'audio/mpeg', sampleRate: 24000, ms: 0 };
    } catch (e) {
      try { if (fs.existsSync(out)) fs.unlinkSync(out); } catch { /* bỏ qua */ }
      return { ok: false, provider: this.id, error: `EDGE_TTS_LỖI: ${String(e.message).slice(0, 160)}` };
    }
  }
}

/** ── Hát: tổng hợp giọng hát (SVS) ──────────────────────────────────────── */

class SoulXSingerProvider extends VoiceProvider {
  constructor() {
    super('soulx-singer', 'SoulX-Singer (SVS, chưa có tiếng Việt)', {
      kind: 'local-neural', quality: 'chất lượng phòng thu, điều khiển được MIDI và F0',
      note: 'Huấn luyện trên 42.000 giờ tiếng Quan Thoại · Anh · Quảng Đông. '
          + 'CHƯA hỗ trợ tiếng Việt — dùng cho lời Anh, hoặc dùng SVC cho tiếng Việt.',
    });
    this.languages = ['zh', 'en', 'yue'];
  }

  available() {
    const dir = cfg.VOICE.soulxDir;
    if (!dir) return { ok: false, reason: 'CHƯA_CÀI', fix: 'Đặt SOULX_SINGER_DIR' };
    if (!fs.existsSync(dir)) return { ok: false, reason: 'KHÔNG_TÌM_THẤY_THƯ_MỤC', fix: `Không có ${dir}` };
    if (!fs.existsSync(path.join(dir, 'inference.py'))) return { ok: false, reason: 'THIẾU_TỆP_SUY_LUẬN', fix: `Không có ${dir}/inference.py` };
    return { ok: true };
  }

  supportsLanguage(lang) { return this.languages.includes(lang); }

  async sing({ lyrics, midiPath, referenceAudio, style = 'pop', vibrato = 0.6, lang = 'zh' }) {
    const av = this.available();
    if (!av.ok) return { ok: false, provider: this.id, error: av.reason };
    if (!this.supportsLanguage(lang)) {
      return { ok: false, provider: this.id, error: 'CHƯA_HỖ_TRỢ_NGÔN_NGỮ', detail: `SoulX-Singer chưa có ${lang}; dùng bộ hát nội bộ hoặc So-VITS-SVC.` };
    }
    const out = tmpFile('wav');
    const args = [path.join(cfg.VOICE.soulxDir, 'inference.py'),
      '--lyrics', lyrics, '--melody', midiPath, '--reference', referenceAudio,
      '--style', style, '--vibrato', String(vibrato), '--output', out];
    try {
      await new Promise((resolve, reject) => {
        execFile(cfg.VOICE.pythonBin, args, { timeout: 300_000, cwd: cfg.VOICE.soulxDir }, (err, so, se) => (err ? reject(new Error(se || err.message)) : resolve(so)));
      });
      const wav = fs.readFileSync(out);
      fs.unlinkSync(out);
      return { ok: true, provider: this.id, wav, mode: 'svs' };
    } catch (e) {
      try { if (fs.existsSync(out)) fs.unlinkSync(out); } catch { /* bỏ qua */ }
      return { ok: false, provider: this.id, error: `SVS_LỖI: ${String(e.message).slice(0, 200)}` };
    }
  }
}

class OpenUtauDiffSingerProvider extends VoiceProvider {
  constructor() {
    super('openutau-diffsinger', 'OpenUtau + DiffSinger (SVS, có tiếng Việt)', {
      kind: 'local-binary', quality: 'chất lượng phòng thu, mô hình khuếch tán',
      note: 'Cần OpenUtau và một voicebank tiếng Việt. Đầu vào là tệp .ustx.',
    });
  }

  available() {
    const bin = cfg.VOICE.openUtauBin;
    if (!bin) return { ok: false, reason: 'CHƯA_CÀI', fix: 'Đặt OPENUTAU_BIN' };
    if (!fs.existsSync(bin)) return { ok: false, reason: 'KHÔNG_TÌM_THẤY', fix: `Không có ${bin}` };
    if (!cfg.VOICE.openUtauVoicebank) return { ok: false, reason: 'THIẾU_VOICEBANK', fix: 'Đặt OPENUTAU_VOICEBANK' };
    return { ok: true };
  }

  async sing({ ustxPath }) {
    const av = this.available();
    if (!av.ok) return { ok: false, provider: this.id, error: av.reason };
    if (!ustxPath || !fs.existsSync(ustxPath)) return { ok: false, provider: this.id, error: 'THIẾU_TỆP_USTX' };
    const out = tmpFile('wav');
    try {
      await new Promise((resolve, reject) => {
        execFile(cfg.VOICE.openUtauBin, ['--headless', '--import', ustxPath, '--export', out], { timeout: 300_000 }, (err, so, se) => (err ? reject(new Error(se || err.message)) : resolve(so)));
      });
      const wav = fs.readFileSync(out);
      fs.unlinkSync(out);
      return { ok: true, provider: this.id, wav, mode: 'svs' };
    } catch (e) {
      try { if (fs.existsSync(out)) fs.unlinkSync(out); } catch { /* bỏ qua */ }
      return { ok: false, provider: this.id, error: `OPENUTAU_LỖI: ${String(e.message).slice(0, 200)}` };
    }
  }
}

/** ── Hát: chuyển đổi giọng hát (SVC) ────────────────────────────────────── */

class SoVitsSvcProvider extends VoiceProvider {
  constructor() {
    super('so-vits-svc', 'So-VITS-SVC (chuyển đổi giọng hát, tiếng Việt)', {
      kind: 'local-neural', quality: 'giữ nguyên cách hát, đổi chất giọng',
      note: 'Nhận bản hát thô của người thật rồi đổi sang chất giọng đích. '
          + 'BẮT BUỘC có phiếu đồng ý của CẢ người hát gốc lẫn chủ giọng đích.',
    });
  }

  available() {
    const dir = cfg.VOICE.soVitsDir;
    if (!dir) return { ok: false, reason: 'CHƯA_CÀI', fix: 'Đặt SOVITS_SVC_DIR' };
    if (!fs.existsSync(dir)) return { ok: false, reason: 'KHÔNG_TÌM_THẤY_THƯ_MỤC', fix: `Không có ${dir}` };
    if (!cfg.VOICE.soVitsModel) return { ok: false, reason: 'THIẾU_MÔ_HÌNH', fix: 'Đặt SOVITS_SVC_MODEL' };
    if (!fs.existsSync(cfg.VOICE.soVitsModel)) return { ok: false, reason: 'KHÔNG_TÌM_THẤY_MÔ_HÌNH', fix: `Không có ${cfg.VOICE.soVitsModel}` };
    return { ok: true };
  }

  async convert(sourceWav, { targetVoice = '', pitchShift = 0 } = {}) {
    const av = this.available();
    if (!av.ok) return { ok: false, provider: this.id, error: av.reason };
    const inPath = tmpFile('wav');
    const outPath = tmpFile('wav');
    fs.writeFileSync(inPath, sourceWav);
    const dir = cfg.VOICE.soVitsDir;
    const args = [path.join(dir, 'inference_main.py'),
      '-m', cfg.VOICE.soVitsModel, '-c', path.join(dir, 'config.json'),
      '-i', inPath, '-o', outPath, '-t', String(pitchShift),
      ...(targetVoice ? ['-s', targetVoice] : [])];
    try {
      await new Promise((resolve, reject) => {
        execFile(cfg.VOICE.pythonBin, args, { timeout: 300_000, cwd: dir }, (err, so, se) => (err ? reject(new Error(se || err.message)) : resolve(so)));
      });
      const wav = fs.readFileSync(outPath);
      fs.unlinkSync(inPath); fs.unlinkSync(outPath);
      return { ok: true, provider: this.id, wav, mode: 'svc' };
    } catch (e) {
      for (const f of [inPath, outPath]) { try { if (fs.existsSync(f)) fs.unlinkSync(f); } catch { /* bỏ qua */ } }
      return { ok: false, provider: this.id, error: `SVC_LỖI: ${String(e.message).slice(0, 200)}` };
    }
  }
}

module.exports = {
  LocalNeuralProvider, EdgeTtsProvider,
  ZeroTtsProvider, VieNeuProvider, GOmniVoiceProvider,
  SoulXSingerProvider, OpenUtauDiffSingerProvider, SoVitsSvcProvider,
};
