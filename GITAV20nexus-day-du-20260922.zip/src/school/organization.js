'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  TỔ CHỨC DẠY HỌC — trường → lớp → nhóm → học viên
 * ═══════════════════════════════════════════════════════════════════════════
 *  Lớp ở đây là lớp HỌC THẬT (có giáo viên chủ nhiệm, có sĩ số, có năm học),
 *  khác với "khối lớp" trong chương trình (phân theo trình độ và độ tuổi).
 *  Một học viên thuộc đúng một lớp tại một thời điểm, nhưng có thể vào nhiều
 *  nhóm nhỏ trong lớp — nhóm là đơn vị để giao bài theo trình độ.
 *
 *  Mọi thay đổi biên chế đều ghi lại lịch sử: ai chuyển lớp, khi nào, vì sao.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const bus = require('../kernel/eventbus');
const { round } = require('../utils');
const { blockOfGrade, LEVELS } = require('../curriculum/hierarchy');

const SCHOOL_YEAR_RE = /^\d{4}-\d{4}$/;

function currentSchoolYear(at = Date.now()) {
  const d = new Date(at);
  const y = d.getFullYear();
  // Năm học Việt Nam bắt đầu tháng 8.
  return d.getMonth() >= 7 ? `${y}-${y + 1}` : `${y - 1}-${y}`;
}

class Organization {
  constructor({ schools, classes, learners, users = null, audit = null }) {
    this.schools = schools;
    this.classes = classes;
    this.learners = learners;
    this.users = users;
    this.audit = audit;
    this.stats = { schoolsCreated: 0, classesCreated: 0, enrolled: 0, transferred: 0, removed: 0 };
  }

  _log(action, detail, verdict = 'ALLOW') {
    this.audit?.record({ actor: detail.by || 'system', action, verdict, severity: 0, detail });
  }

  // ── TRƯỜNG / CƠ SỞ ───────────────────────────────────────────────────────

  createSchool({ id = null, name, address = '', phone = '', principal = '', by = 'admin' } = {}) {
    if (!name || !String(name).trim()) return { ok: false, error: 'MISSING_INPUT', need: ['name'] };
    const sid = id || `SCH-${String(this.schools.count() + 1).padStart(3, '0')}`;
    if (this.schools.has(sid)) return { ok: false, error: 'SCHOOL_EXISTS', id: sid };
    const doc = { id: sid, name: String(name).trim(), address, phone, principal, active: true };
    this.schools.put(doc);
    this.stats.schoolsCreated++;
    this._log('school.create', { by, schoolId: sid, name });
    return { ok: true, school: doc };
  }

  listSchools() {
    return this.schools.all().map((s) => ({
      ...s,
      classes: this.classes.by('schoolId', s.id).length,
      learners: this.classes.by('schoolId', s.id).reduce((n, c) => n + (c.learnerIds?.length || 0), 0),
    }));
  }

  // ── LỚP ──────────────────────────────────────────────────────────────────

  createClass({
    id = null, name, grade, schoolId = null, teacherId = null,
    schoolYear = null, capacity = 40, by = 'admin',
  } = {}) {
    if (!name || !String(name).trim()) return { ok: false, error: 'MISSING_INPUT', need: ['name'] };
    const g = Number(grade);
    if (!Number.isInteger(g) || g < 1 || g > 12) return { ok: false, error: 'INVALID_GRADE', hint: 'lớp 1 đến 12' };
    const year = schoolYear || currentSchoolYear();
    if (!SCHOOL_YEAR_RE.test(year)) return { ok: false, error: 'INVALID_SCHOOL_YEAR', hint: 'dạng 2026-2027' };
    if (schoolId && !this.schools.has(schoolId)) return { ok: false, error: 'SCHOOL_NOT_FOUND' };
    if (teacherId && this.users && !this.users.has(teacherId)) return { ok: false, error: 'TEACHER_NOT_FOUND' };
    if (teacherId && this.users) {
      const t = this.users.get(teacherId);
      if (t.role !== 'TEACHER') return { ok: false, error: 'WRONG_ROLE', need: 'TEACHER' };
    }
    const cid = id || `CL-${year.slice(2, 4)}-${String(this.classes.count() + 1).padStart(4, '0')}`;
    if (this.classes.has(cid)) return { ok: false, error: 'CLASS_EXISTS', id: cid };

    const doc = {
      id: cid,
      name: String(name).trim(),
      grade: g,
      block: blockOfGrade(g),
      schoolId,
      teacherId,
      assistantIds: [],
      schoolYear: year,
      capacity: Math.max(1, Math.min(Number(capacity) || 40, 200)),
      learnerIds: [],
      groups: [],
      active: true,
      history: [{ at: Date.now(), action: 'created', by }],
    };
    this.classes.put(doc);
    this.stats.classesCreated++;
    this._log('class.create', { by, classId: cid, name, grade: g, teacherId });
    bus.safeEmit('class:created', { classId: cid });
    return { ok: true, class: this.viewClass(doc) };
  }

  viewClass(c) {
    if (!c) return null;
    const learners = (c.learnerIds || []).map((id) => this.learners.get(id)).filter(Boolean);
    const levels = learners.map((l) => l.level ?? 0);
    return {
      ...c,
      size: learners.length,
      full: learners.length >= c.capacity,
      teacherName: this.users?.get(c.teacherId)?.fullName || null,
      levelSpread: levels.length ? {
        min: Math.min(...levels),
        max: Math.max(...levels),
        avg: round(levels.reduce((a, b) => a + b, 0) / levels.length, 2),
        byLevel: levels.reduce((m, v) => { m[`L${v}`] = (m[`L${v}`] || 0) + 1; return m; }, {}),
      } : null,
    };
  }

  getClass(classId) { return this.viewClass(this.classes.get(classId)); }

  listClasses({ teacherId = null, schoolId = null, grade = null, schoolYear = null, limit = 100, offset = 0 } = {}) {
    const where = (c) => (!teacherId || c.teacherId === teacherId)
      && (!schoolId || c.schoolId === schoolId)
      && (grade == null || c.grade === Number(grade))
      && (!schoolYear || c.schoolYear === schoolYear);
    const page = this.classes.page({ offset, limit, sort: 'name', where });
    return { ...page, items: page.items.map((c) => this.viewClass(c)) };
  }

  assignTeacher(classId, teacherId, by = 'admin') {
    const c = this.classes.get(classId);
    if (!c) return { ok: false, error: 'CLASS_NOT_FOUND' };
    if (this.users) {
      const t = this.users.get(teacherId);
      if (!t) return { ok: false, error: 'TEACHER_NOT_FOUND' };
      if (t.role !== 'TEACHER') return { ok: false, error: 'WRONG_ROLE', need: 'TEACHER' };
    }
    this.classes.patch(classId, {
      teacherId,
      history: [...(c.history || []), { at: Date.now(), action: 'assign_teacher', teacherId, previous: c.teacherId, by }],
    });
    this._log('class.assign_teacher', { by, classId, teacherId, previous: c.teacherId });
    return { ok: true, classId, teacherId };
  }

  // ── BIÊN CHẾ HỌC VIÊN ────────────────────────────────────────────────────

  /** Nhận học viên vào lớp. Đang ở lớp khác thì đây là chuyển lớp, có ghi lịch sử. */
  enroll(classId, learnerId, by = 'admin', reason = '') {
    const c = this.classes.get(classId);
    if (!c) return { ok: false, error: 'CLASS_NOT_FOUND' };
    const ln = this.learners.get(learnerId);
    if (!ln) return { ok: false, error: 'LEARNER_NOT_FOUND' };
    if ((c.learnerIds || []).includes(learnerId)) return { ok: false, error: 'ALREADY_ENROLLED', classId };
    if ((c.learnerIds || []).length >= c.capacity) return { ok: false, error: 'CLASS_FULL', capacity: c.capacity };

    const from = ln.classId || null;
    if (from && from !== classId) {
      const old = this.classes.get(from);
      if (old) {
        this.classes.patch(from, {
          learnerIds: (old.learnerIds || []).filter((x) => x !== learnerId),
          groups: (old.groups || []).map((g) => ({ ...g, learnerIds: g.learnerIds.filter((x) => x !== learnerId) })),
          history: [...(old.history || []), { at: Date.now(), action: 'transfer_out', learnerId, to: classId, by, reason }],
        });
      }
      this.stats.transferred++;
    }

    this.classes.patch(classId, {
      learnerIds: [...(c.learnerIds || []), learnerId],
      history: [...(c.history || []), { at: Date.now(), action: from ? 'transfer_in' : 'enroll', learnerId, from, by, reason }],
    });
    this.learners.patch(learnerId, {
      classId,
      schoolId: c.schoolId,
      enrollment: [...(ln.enrollment || []), { at: Date.now(), classId, from, by, reason }],
    });
    this.stats.enrolled++;
    this._log(from ? 'class.transfer' : 'class.enroll', { by, classId, learnerId, from, reason });
    bus.safeEmit('class:enrolled', { classId, learnerId, from });
    return { ok: true, classId, learnerId, transferredFrom: from };
  }

  remove(classId, learnerId, by = 'admin', reason = '') {
    const c = this.classes.get(classId);
    if (!c) return { ok: false, error: 'CLASS_NOT_FOUND' };
    if (!(c.learnerIds || []).includes(learnerId)) return { ok: false, error: 'NOT_ENROLLED' };
    this.classes.patch(classId, {
      learnerIds: c.learnerIds.filter((x) => x !== learnerId),
      groups: (c.groups || []).map((g) => ({ ...g, learnerIds: g.learnerIds.filter((x) => x !== learnerId) })),
      history: [...(c.history || []), { at: Date.now(), action: 'remove', learnerId, by, reason }],
    });
    const ln = this.learners.get(learnerId);
    if (ln && ln.classId === classId) this.learners.patch(learnerId, { classId: null });
    this.stats.removed++;
    this._log('class.remove', { by, classId, learnerId, reason });
    return { ok: true, classId, learnerId };
  }

  roster(classId) {
    const c = this.classes.get(classId);
    if (!c) return { ok: false, error: 'CLASS_NOT_FOUND' };
    const items = (c.learnerIds || [])
      .map((id) => this.learners.get(id))
      .filter(Boolean)
      .map((l) => ({
        id: l.id,
        fullName: l.fullName,
        grade: l.grade,
        level: l.level ?? 0,
        levelName: LEVELS[l.level ?? 0]?.name || null,
        groupIds: (c.groups || []).filter((g) => g.learnerIds.includes(l.id)).map((g) => g.id),
        userId: l.userId || null,
      }))
      .sort((a, b) => String(a.fullName).localeCompare(String(b.fullName), 'vi'));
    return { ok: true, classId, className: c.name, size: items.length, capacity: c.capacity, items };
  }

  // ── NHÓM TRONG LỚP ───────────────────────────────────────────────────────

  createGroup(classId, { id = null, name, learnerIds = [], purpose = '', by = 'admin' } = {}) {
    const c = this.classes.get(classId);
    if (!c) return { ok: false, error: 'CLASS_NOT_FOUND' };
    if (!name) return { ok: false, error: 'MISSING_INPUT', need: ['name'] };
    const gid = id || `${classId}-G${(c.groups || []).length + 1}`;
    if ((c.groups || []).some((g) => g.id === gid)) return { ok: false, error: 'GROUP_EXISTS' };
    const outside = learnerIds.filter((x) => !(c.learnerIds || []).includes(x));
    if (outside.length) return { ok: false, error: 'LEARNER_NOT_IN_CLASS', learnerIds: outside };
    const g = { id: gid, name, purpose, learnerIds: [...new Set(learnerIds)], createdAt: Date.now() };
    this.classes.patch(classId, { groups: [...(c.groups || []), g] });
    this._log('class.create_group', { by, classId, groupId: gid, size: g.learnerIds.length });
    return { ok: true, group: g };
  }

  setGroupMembers(classId, groupId, learnerIds, by = 'admin') {
    const c = this.classes.get(classId);
    if (!c) return { ok: false, error: 'CLASS_NOT_FOUND' };
    const g = (c.groups || []).find((x) => x.id === groupId);
    if (!g) return { ok: false, error: 'GROUP_NOT_FOUND' };
    const outside = learnerIds.filter((x) => !(c.learnerIds || []).includes(x));
    if (outside.length) return { ok: false, error: 'LEARNER_NOT_IN_CLASS', learnerIds: outside };
    this.classes.patch(classId, {
      groups: c.groups.map((x) => (x.id === groupId ? { ...x, learnerIds: [...new Set(learnerIds)] } : x)),
    });
    this._log('class.set_group', { by, classId, groupId, size: learnerIds.length });
    return { ok: true, groupId, size: learnerIds.length };
  }

  /**
   * Chia nhóm theo tầng trình độ — không chia ngẫu nhiên, không chia theo tên.
   * Học viên cùng tầng vào cùng nhóm để giao bài đúng mức.
   */
  autoGroupByLevel(classId, { maxPerGroup = 8, by = 'admin' } = {}) {
    const c = this.classes.get(classId);
    if (!c) return { ok: false, error: 'CLASS_NOT_FOUND' };
    const roster = (c.learnerIds || []).map((id) => this.learners.get(id)).filter(Boolean);
    if (!roster.length) return { ok: false, error: 'EMPTY_CLASS' };

    const byLevel = new Map();
    for (const l of roster) {
      const lv = l.level ?? 0;
      if (!byLevel.has(lv)) byLevel.set(lv, []);
      byLevel.get(lv).push(l.id);
    }

    const groups = [];
    for (const lv of [...byLevel.keys()].sort((a, b) => a - b)) {
      // Thứ tự tất định: sắp theo mã học viên rồi cắt khúc.
      const ids = byLevel.get(lv).sort();
      for (let i = 0; i < ids.length; i += maxPerGroup) {
        const part = ids.slice(i, i + maxPerGroup);
        const n = groups.length + 1;
        groups.push({
          id: `${classId}-G${n}`,
          name: `Tầng ${LEVELS[lv]?.code || `L${lv}`} · nhóm ${Math.floor(i / maxPerGroup) + 1}`,
          purpose: `Cùng tầng ${LEVELS[lv]?.name || lv} — giao bài đúng mức`,
          level: lv,
          learnerIds: part,
          createdAt: Date.now(),
        });
      }
    }
    this.classes.patch(classId, { groups });
    this._log('class.auto_group', { by, classId, groups: groups.length });
    return { ok: true, classId, groups: groups.map((g) => ({ id: g.id, name: g.name, level: g.level, size: g.learnerIds.length })) };
  }

  status() {
    const classes = this.classes.all();
    const enrolled = classes.reduce((n, c) => n + (c.learnerIds?.length || 0), 0);
    return {
      schools: this.schools.count(),
      classes: classes.length,
      learners: this.learners.count(),
      enrolled,
      unassigned: this.learners.count() - enrolled,
      avgClassSize: classes.length ? round(enrolled / classes.length, 1) : 0,
      byGrade: classes.reduce((m, c) => { m[`Lớp ${c.grade}`] = (m[`Lớp ${c.grade}`] || 0) + 1; return m; }, {}),
      schoolYear: currentSchoolYear(),
      ...this.stats,
    };
  }
}

module.exports = Organization;
module.exports.currentSchoolYear = currentSchoolYear;
