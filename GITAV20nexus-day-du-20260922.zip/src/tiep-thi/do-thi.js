'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  ĐỒ THỊ TRI THỨC HỢP NHẤT — một nguồn sự thật cho cả trò chuyện lẫn nội dung
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Vì sao hai phần này phải dùng CHUNG một đồ thị, chứ không mỗi bên một kho:
 *
 *      Khung chat trả lời phụ huynh một đằng.
 *      Trang giới thiệu viết một nẻo.
 *      Cùng một câu hỏi, hai câu trả lời khác nhau.
 *
 *  Và người dùng bắt gặp điều đó trong vòng một phút, vì họ mở hai tab cạnh
 *  nhau. Dùng chung một đồ thị thì sai vẫn sai được, nhưng sai GIỐNG NHAU —
 *  và một cái sai giống nhau thì sửa một lần là xong, còn hai cái sai lệch
 *  nhau thì không ai biết bên nào mới đúng.
 *
 *  ── VÌ SAO KHÔNG DÙNG MỘT CƠ SỞ DỮ LIỆU ĐỒ THỊ ──────────────────────────
 *
 *  Bản thiết kế gốc dùng Kuzu. Hệ này KHÔNG có phụ thuộc chạy thật nào, và
 *  điều đó không phải để khoe: nó là lý do bản cài đặt trên máy giáo viên mở
 *  lên chạy được ngay, không cần Docker, không cần cài gì.
 *
 *  Quy mô ở đây cũng không cần tới: vài trăm nút, vài nghìn cạnh. Một Map và
 *  một danh sách kề là đủ, và duyệt hết đồ thị này còn nhanh hơn thời gian mở
 *  một kết nối tới máy chủ đồ thị.
 *
 *  Nói thẳng chỗ đổi lại: đồ thị này KHÔNG truy vấn Cypher được và KHÔNG chạy
 *  được đường đi nhiều chặng phức tạp. Khi nào cần tới, đổi ruột chứ không
 *  đổi mặt ngoài — mọi chỗ gọi đều đi qua đúng mấy hàm dưới đây.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { id: newId, round } = require('../utils');

/** Sáu loại nút. Khai cứng: loại lạ thì từ chối chứ không lặng lẽ nhận. */
const LOAI_NUT = {
  nhom: 'Nhóm vấn đề',
  'y-dinh': 'Ý định người dùng',
  'mang-noi-dung': 'Mảng nội dung trên trang',
  'chi-so-seo': 'Chỉ số tìm kiếm',
  'trich-dan': 'Lần được trích dẫn',
  'phan-hoi': 'Phản hồi của người dùng',
};

/** Năm loại cạnh, và mỗi loại chỉ nối đúng hai loại nút đã khai. */
const LOAI_CANH = {
  'thuoc-nhom': ['y-dinh', 'nhom'],
  'tao-ra': ['y-dinh', 'mang-noi-dung'],
  'co-seo': ['mang-noi-dung', 'chi-so-seo'],
  'duoc-trich-dan': ['mang-noi-dung', 'trich-dan'],
  've-mang': ['phan-hoi', 'mang-noi-dung'],
};

class DoThiTriThuc {
  constructor({ bayGio = () => Date.now() } = {}) {
    this.bayGio = bayGio;
    this.nut = new Map();          // id → nút
    this.canh = [];                // {loai, tu, den}
    this.ke = new Map();           // tu → [cạnh]
    this.keNguoc = new Map();      // den → [cạnh]
  }

  themNut(loai, du = {}) {
    if (!LOAI_NUT[loai]) throw new Error(`Loại nút chưa khai: "${loai}"`);
    const id = du.id || newId(loai.slice(0, 3));
    const nut = { id, loai, ...du, ghiLuc: new Date(this.bayGio()).toISOString() };
    this.nut.set(id, nut);
    return nut;
  }

  themCanh(loai, tu, den) {
    const khai = LOAI_CANH[loai];
    if (!khai) throw new Error(`Loại cạnh chưa khai: "${loai}"`);
    const a = this.nut.get(tu);
    const b = this.nut.get(den);
    if (!a) throw new Error(`Cạnh "${loai}" trỏ từ nút không có: ${tu}`);
    if (!b) throw new Error(`Cạnh "${loai}" trỏ tới nút không có: ${den}`);
    if (a.loai !== khai[0] || b.loai !== khai[1]) {
      throw new Error(`Cạnh "${loai}" phải nối ${khai[0]} → ${khai[1]}, đang nối ${a.loai} → ${b.loai}`);
    }
    const c = { loai, tu, den };
    this.canh.push(c);
    if (!this.ke.has(tu)) this.ke.set(tu, []);
    this.ke.get(tu).push(c);
    if (!this.keNguoc.has(den)) this.keNguoc.set(den, []);
    this.keNguoc.get(den).push(c);
    return c;
  }

  /** Đi xuôi một loại cạnh. */
  di(tu, loai) {
    return (this.ke.get(tu) || []).filter((c) => c.loai === loai).map((c) => this.nut.get(c.den));
  }

  /** Đi ngược một loại cạnh. */
  diNguoc(den, loai) {
    return (this.keNguoc.get(den) || []).filter((c) => c.loai === loai).map((c) => this.nut.get(c.tu));
  }

  theoLoai(loai) {
    return [...this.nut.values()].filter((n) => n.loai === loai);
  }

  /** Nội dung đã sinh ra cho một ý định. */
  noiDungCuaYDinh(yDinhId) { return this.di(yDinhId, 'tao-ra'); }

  /** Một mảng nội dung đã được trích dẫn bao nhiêu lần. */
  soLanTrichDan(mangId) { return this.di(mangId, 'duoc-trich-dan').length; }

  /** Phản hồi gắn vào một mảng nội dung. */
  phanHoiCua(mangId) { return this.diNguoc(mangId, 've-mang'); }

  /**
   * Soi chính đồ thị. Canh đúng những chỗ một đồ thị tri thức hỏng lặng lẽ.
   */
  soi() {
    const loi = [];
    for (const c of this.canh) {
      if (!this.nut.has(c.tu)) loi.push(`cạnh ${c.loai} trỏ từ nút đã mất: ${c.tu}`);
      if (!this.nut.has(c.den)) loi.push(`cạnh ${c.loai} trỏ tới nút đã mất: ${c.den}`);
      if (c.tu === c.den) loi.push(`nút tự nối vào chính mình: ${c.tu}`);
    }
    // Mảng nội dung KHÔNG gắn với ý định nào là nội dung viết ra mà không biết
    // để trả lời câu hỏi gì. Đếm và nói ra, không tự nối bừa.
    const mo = this.theoLoai('mang-noi-dung').filter((m) => !this.diNguoc(m.id, 'tao-ra').length);
    return {
      dat: loi.length === 0,
      loi,
      soNut: this.nut.size,
      soCanh: this.canh.length,
      theoLoai: Object.fromEntries(Object.keys(LOAI_NUT).map((l) => [l, this.theoLoai(l).length])),
      mangKhongGanYDinh: mo.map((m) => m.id),
      ghiChu: mo.length
        ? `${mo.length} mảng nội dung chưa gắn với ý định nào — tức là đang viết mà chưa biết để trả lời câu hỏi gì.`
        : null,
    };
  }

  status() {
    const s = this.soi();
    return {
      soLoaiNut: Object.keys(LOAI_NUT).length,
      soLoaiCanh: Object.keys(LOAI_CANH).length,
      soNut: s.soNut, soCanh: s.soCanh, theoLoai: s.theoLoai,
      trongBoNho: true,
      khongLamDuoc: 'Không truy vấn Cypher, không chạy đường đi nhiều chặng phức tạp. '
        + 'Đủ cho quy mô vài trăm nút; cần hơn thì đổi ruột, mặt ngoài giữ nguyên.',
    };
  }
}

module.exports = DoThiTriThuc;
module.exports.LOAI_NUT = LOAI_NUT;
module.exports.LOAI_CANH = LOAI_CANH;
