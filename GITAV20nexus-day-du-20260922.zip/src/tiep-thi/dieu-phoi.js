'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  ĐIỀU PHỐI HỢP NHẤT — một đồ thị, một bộ luật, một vòng cải tiến
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Chỗ này gom trò chuyện và nội dung lại. "Gom" ở đây có nghĩa rất cụ thể,
 *  chứ không phải để hai mô-đun cạnh nhau rồi gọi là hợp nhất:
 *
 *      MỘT đồ thị       cả hai bên đọc và ghi vào cùng một nơi
 *      MỘT bộ luật      luật nội dung dùng lại đúng bộ khuôn của lớp canh
 *                       đường ra — không có bản sao thứ hai để lệch nhau
 *      MỘT vòng         nhật ký chat là đầu vào của việc sửa trang, và
 *                       ngược lại
 *
 *  Mỗi lượt trò chuyện để lại một dấu trong đồ thị; mỗi mảng nội dung soạn ra
 *  được nối với ý định mà nó trả lời. Nhờ thế vòng cải tiến mới có gì để so.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const DoThiTriThuc = require('./do-thi');
const VongCaiTien = require('./vong-cai-tien');
const xuong = require('./xuong-noi-dung');
const luat = require('./luat-noi-dung');
const DieuPhoiTroChuyen = require('../tro-chuyen/dieu-phoi');
const { BANG_VIEC } = require('../tro-chuyen/khien-viec');

/** Ý định nào sinh ra mảng nội dung nào. Khai tay, đọc được, sửa được. */
const Y_DINH_TOI_MANG = {
  'hoi-chung': ['mo-dau', 'loi-moi'],
  'hoi-chuong-trinh': ['lam-duoc-gi', 'hoc-the-nao', 'cau-hoi-thuong-gap'],
  'hoi-hoc-phi': ['cau-hoi-thuong-gap'],
  'xin-goi-y-hoc': ['hoc-the-nao'],
  'bao-truc-trac': ['cau-hoi-thuong-gap'],
  'hoi-tien-do-minh': ['lam-duoc-gi'],
  'hoi-tien-do-con': ['vi-sao-tin', 'cau-hoi-thuong-gap'],
  'hoi-lop': ['lam-duoc-gi'],
};

class DieuPhoiHopNhat {
  constructor({ N, nhacLai = null, khoaRieng = null } = {}) {
    this.N = N;
    this.doThi = new DoThiTriThuc();
    this.choDuyet = [];
    this.vong = new VongCaiTien({ doThi: this.doThi, choDuyet: this.choDuyet });
    this.chat = new DieuPhoiTroChuyen({ N, nhacLai, khoaRieng });
    this.nhatKyChat = [];
    this.trang = null;
    this._gieoYDinh();
  }

  /** Gieo tám ý định và các nhóm vào đồ thị — lấy thẳng từ bảng việc. */
  _gieoYDinh() {
    const nhomTheoPhamVi = new Map();
    for (const [ma, v] of Object.entries(BANG_VIEC)) {
      if (!nhomTheoPhamVi.has(v.chamAi)) {
        nhomTheoPhamVi.set(v.chamAi, this.doThi.themNut('nhom', { id: `nhom-${v.chamAi}`, ten: v.chamAi }));
      }
      this.doThi.themNut('y-dinh', { id: ma, ten: v.ten, chamAi: v.chamAi, vaiToiThieu: v.vaiToiThieu });
      this.doThi.themCanh('thuoc-nhom', ma, `nhom-${v.chamAi}`);
    }
  }

  /** Soạn trang và nối từng mảng với ý định nó trả lời. */
  soanTrang() {
    const t = xuong.soanTrang(this.N);
    // Gỡ nút mảng cũ trước khi soạn lại, để không sinh ra hai bản của một mảng.
    for (const m of this.doThi.theoLoai('mang-noi-dung')) this.doThi.nut.delete(m.id);
    this.doThi.canh = this.doThi.canh.filter((c) => this.doThi.nut.has(c.tu) && this.doThi.nut.has(c.den));
    this.doThi.ke = new Map();
    this.doThi.keNguoc = new Map();
    for (const c of this.doThi.canh) {
      if (!this.doThi.ke.has(c.tu)) this.doThi.ke.set(c.tu, []);
      this.doThi.ke.get(c.tu).push(c);
      if (!this.doThi.keNguoc.has(c.den)) this.doThi.keNguoc.set(c.den, []);
      this.doThi.keNguoc.get(c.den).push(c);
    }

    for (const m of t.mang) {
      this.doThi.themNut('mang-noi-dung', { id: m.ma, ten: m.ten, nhip: m.nhip, chu: m.chu });
    }
    for (const [yDinh, ds] of Object.entries(Y_DINH_TOI_MANG)) {
      for (const ma of ds) {
        if (this.doThi.nut.has(ma) && this.doThi.nut.has(yDinh)) {
          this.doThi.themCanh('tao-ra', yDinh, ma);
        }
      }
    }
    this.trang = t;
    return t;
  }

  /** Một lượt trò chuyện, và ghi dấu lại để vòng cải tiến có gì mà đọc. */
  async hoi(o) {
    const r = await this.chat.hoi(o);
    this.nhatKyChat.push({
      viec: r.viec, biChan: r.biChan, cua: r.cua,
      soCongCuCoDuLieu: r.soCongCuCoDuLieu || 0,
    });
    if (this.nhatKyChat.length > 5000) this.nhatKyChat.shift();
    return r;
  }

  /** Ghi một phản hồi của người đọc về một mảng nội dung. */
  ghiPhanHoi({ mang, sacThai = 'trung', chu = '' }) {
    if (!this.doThi.nut.has(mang)) return { ok: false, error: 'KHONG_CO_MANG', mang };
    const p = this.doThi.themNut('phan-hoi', { sacThai, chu: String(chu).slice(0, 500) });
    this.doThi.themCanh('ve-mang', p.id, mang);
    return { ok: true, id: p.id };
  }

  chayVongCaiTien() { return this.vong.chay({ nhatKyChat: this.nhatKyChat }); }

  /** Soi cả phần hợp nhất. Ba mục, mỗi mục canh một kiểu hỏng riêng. */
  soi() {
    const loi = [];
    const d = this.doThi.soi();
    loi.push(...d.loi);

    // Mảng nội dung nào cũng phải qua được luật nội dung — soi LẠI ở đây, vì
    // xưởng có thể bị sửa mà quên cửa kiểm.
    for (const m of this.doThi.theoLoai('mang-noi-dung')) {
      const k = luat.soi(m.chu, { tenTrang: m.ten });
      if (!k.dat) loi.push(`mảng ${m.id} không qua luật nội dung: ${k.loi.map((x) => x.ma).join(', ')}`);
    }
    // Mọi ý định trong bảng việc phải có mặt trong đồ thị.
    for (const ma of Object.keys(BANG_VIEC)) {
      if (!this.doThi.nut.has(ma)) loi.push(`ý định "${ma}" có trong bảng việc mà vắng trong đồ thị`);
    }
    return {
      dat: loi.length === 0, loi,
      soNut: d.soNut, soCanh: d.soCanh, theoLoai: d.theoLoai,
      mangKhongGanYDinh: d.mangKhongGanYDinh,
    };
  }

  status() {
    return {
      doThi: this.doThi.status(),
      troChuyen: this.chat.status(),
      vongCaiTien: this.vong.status(),
      trang: this.trang
        ? { soMang: this.trang.mang.length, soMangBoQua: this.trang.boQua.length, soLieu: this.trang.soLieu }
        : null,
      soLuotChat: this.nhatKyChat.length,
      dangChoNguoiDuyet: this.choDuyet.length,
    };
  }
}

module.exports = DieuPhoiHopNhat;
module.exports.Y_DINH_TOI_MANG = Y_DINH_TOI_MANG;
