'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  XƯỞNG NỘI DUNG — viết trang công khai TỪ SỐ LIỆU THẬT
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Đây là chỗ dễ nói dối nhất trong cả hệ thống, nên nói trước điều xưởng này
 *  KHÔNG làm:
 *
 *      Nó KHÔNG viết "hơn 10.000 học viên tin dùng" khi kho có 0 học viên.
 *      Nó KHÔNG viết "98% phụ huynh hài lòng" khi chưa ai được hỏi.
 *      Nó KHÔNG viết một lời chứng thực của một phụ huynh không có thật.
 *
 *  Mọi con số trên trang đều đọc thẳng từ kho đang chạy. Kho rỗng thì mảng
 *  ấy KHÔNG ĐƯỢC SINH RA — chứ không sinh ra với số 0, và tuyệt đối không
 *  sinh ra với một con số nghe cho đẹp.
 *
 *  Điều này làm trang giới thiệu lúc mới dựng trông THƯA. Đó là đúng: một
 *  trang thưa nói thật thì sửa được bằng cách làm cho có thật; một trang dày
 *  nói dối thì không sửa được bằng gì cả.
 *
 *  ── BA LOẠI SỐ, VÀ CHỈ MỘT LOẠI ĐƯỢC LÊN TRANG ──────────────────────────
 *
 *      đếm-được    đếm thẳng từ kho     → ĐƯỢC in
 *      chưa-có     kho rỗng             → bỏ hẳn mảng, ghi lý do vào biên bản
 *      nội-bộ      số điều hành         → CẤM, bức tường chặn
 * ═══════════════════════════════════════════════════════════════════════════
 */

const luat = require('./luat-noi-dung');
const { round } = require('../utils');

/**
 * Bảng mảng nội dung. Mỗi mảng khai:
 *   ten     đọc được
 *   nhip    bao lâu soạn lại một lần — lấy từ bảng của bản thiết kế gốc
 *   can     những số liệu BẮT BUỘC phải có thật; thiếu một cái là bỏ mảng
 */
const MANG = {
  'mo-dau': { ten: 'Mảng mở đầu', nhip: 'hàng tuần', can: ['soDang', 'soTang'] },
  'vi-sao-tin': { ten: 'Vì sao tin được', nhip: 'hàng tháng', can: ['soDang', 'soKiemDinh'] },
  'lam-duoc-gi': { ten: 'Hệ thống làm được gì', nhip: 'hàng tuần', can: ['soDang'] },
  'hoc-the-nao': { ten: 'Học thế nào', nhip: 'hàng quý', can: ['soTang'] },
  'cau-hoi-thuong-gap': { ten: 'Câu hỏi thường gặp', nhip: 'hàng tuần', can: ['soDang'] },
  'loi-moi': { ten: 'Lời mời', nhip: 'hàng tuần', can: [] },
};

/**
 * Đọc số liệu THẬT từ hệ đang chạy.
 *
 * Mỗi số đi kèm nguồn — để khi ai hỏi "lấy đâu ra con số này" thì trả lời
 * được bằng một đường dẫn chứ không bằng một cái nhún vai.
 */
function docSoLieu(N) {
  const so = {};
  const nguon = {};
  const ghi = (k, v, ng) => { if (v != null && v !== 0) { so[k] = v; nguon[k] = ng; } };

  try {
    const H = require('../curriculum/hierarchy');
    ghi('soDang', H.FORMS.length, 'src/curriculum/hierarchy · FORMS');
    ghi('soTang', H.LEVELS.length, 'src/curriculum/hierarchy · LEVELS');
    ghi('soKhoi', H.BLOCKS.length, 'src/curriculum/hierarchy · BLOCKS');
    ghi('soBay', H.FORMS.reduce((a, f) => a + (f.traps || []).length, 0), 'src/curriculum/hierarchy · traps');
  } catch { /* chương trình chưa nạp thì không có số, không đoán */ }

  try {
    const S = require('../so-do-tu-duy/so-do');
    const s = S.soi();
    ghi('soQuanHe', s.soCanh, 'src/so-do-tu-duy/so-do · soi()');
  } catch { /* bỏ qua */ }

  if (N && N.bank && typeof N.bank.status === 'function') {
    const b = N.bank.status();
    ghi('soBaiTrongKho', b.total, 'kho học liệu · status().total');
    // Đọc byStatus.PUBLISHED chứ KHÔNG đọc b.published: trường `published`
    // là bộ ĐẾM số lần chuyển trạng thái trong phiên chạy này, nên nó bằng 0
    // trên một hệ vừa khởi động dù kho có đủ 546 bài đã xuất bản. Đọc nhầm
    // trường ấy thì mảng "vì sao tin được" biến mất khỏi trang mà không ai
    // hiểu vì sao.
    ghi('soKiemDinh', (b.byStatus && b.byStatus.PUBLISHED) || null, 'kho học liệu · byStatus.PUBLISHED');
  }
  if (N && N.agents && typeof N.agents.length === 'number') {
    ghi('soTroLy', N.agents.length, 'lực lượng trợ lý AI chuyên môn');
  } else if (N && N.agents && typeof N.agents.count === 'function') {
    ghi('soTroLy', N.agents.count(), 'lực lượng trợ lý AI chuyên môn');
  }
  if (N && N.classes && typeof N.classes.count === 'function') {
    ghi('soLop', N.classes.count(), 'kho lớp');
  }
  if (N && N.learners && typeof N.learners.count === 'function') {
    ghi('soHocVien', N.learners.count(), 'kho học viên');
  }
  return { so, nguon };
}

/** Viết một mảng. Trả null kèm lý do khi thiếu số liệu thật. */
function vietMang(ma, { so, nguon }) {
  const m = MANG[ma];
  if (!m) return { ok: false, loi: 'MANG_CHUA_KHAI', ma };
  const thieu = m.can.filter((k) => so[k] == null);
  if (thieu.length) {
    return {
      ok: false, ma, ten: m.ten, loi: 'THIEU_SO_LIEU_THAT', thieu,
      vi: `Mảng "${m.ten}" cần ${thieu.join(', ')} mà kho chưa có. `
        + 'Mảng này KHÔNG được sinh ra — thà trang thưa còn hơn trang có số bịa.',
    };
  }

  const n = (k) => so[k];
  let chu;
  switch (ma) {
    case 'mo-dau':
      chu = {
        tieu: 'Học toán theo đúng thứ tự kiến thức',
        phu: `Chương trình gồm ${n('soDang')} dạng toán, xếp thành ${n('soTang')} tầng. `
          + 'Mỗi dạng chỉ mở ra khi những dạng cần biết trước đã học xong.',
        nut: 'Xem chương trình',
      };
      break;
    case 'vi-sao-tin':
      chu = {
        tieu: 'Vì sao tin được',
        y: [
          `${n('soDang')} dạng toán do người biên soạn tay, không có bài nào máy sinh hàng loạt.`,
          `${n('soKiemDinh')} bài trong kho đã qua thẩm định trước khi đến tay học viên.`,
          so.soBay ? `${so.soBay} lỗi sai thường gặp được ghi sẵn theo từng dạng.` : null,
          'Mọi con số trên trang này đọc thẳng từ hệ thống đang chạy.',
        ].filter(Boolean),
      };
      break;
    case 'lam-duoc-gi':
      chu = {
        tieu: 'Hệ thống làm được gì',
        muc: [
          { ten: 'Đúng thứ tự', y: `${n('soDang')} dạng nối với nhau bằng quan hệ "cần biết trước"`
            + (so.soQuanHe ? `, tất cả ${so.soQuanHe} quan hệ` : '') + '.' },
          { ten: 'Thấy chỗ hổng', y: 'Sai ở đâu thì chỉ ra đúng dạng cần quay lại, không bắt học lại từ đầu.' },
          { ten: 'Sơ đồ ba chiều', y: 'Cả chương trình xoay được bằng chuột, in ra giấy được.' },
          { ten: 'Bài giảng có tiếng', y: 'Một chủ đề ra một tệp video có hình có giọng đọc.' },
          so.soTroLy ? { ten: 'Trợ lý chuyên môn', y: `${so.soTroLy} trợ lý AI chuyên môn, mỗi trợ lý một việc rõ ràng.` } : null,
        ].filter(Boolean),
      };
      break;
    case 'hoc-the-nao':
      chu = {
        tieu: 'Học thế nào',
        buoc: [
          'Làm một lượt chẩn đoán để biết đang đứng ở đâu.',
          `Hệ thống xếp lộ trình theo ${n('soTang')} tầng, đi từ chỗ đang đứng.`,
          'Mỗi buổi luyện một nhóm dạng, sai thì được chữa ngay tại chỗ.',
          'Cuối tầng có một lượt kiểm tra; chưa đạt thì quay lại đúng dạng còn hổng.',
        ],
      };
      break;
    case 'cau-hoi-thuong-gap':
      chu = {
        tieu: 'Câu hỏi thường gặp',
        hoi: [
          { h: 'Chương trình có bao nhiêu dạng toán?',
            d: `${n('soDang')} dạng, chia thành ${n('soTang')} tầng`
              + (so.soKhoi ? ` và ${so.soKhoi} khối lớp` : '') + '.' },
          { h: 'Bài tập do máy sinh ra à?',
            d: 'Không. Các dạng do người biên soạn tay. Máy chỉ giúp chọn bài nào cho ai, vào lúc nào.' },
          { h: 'Con tôi học bao lâu thì giỏi?',
            d: 'Không ai trả lời được câu này, và chúng tôi không hứa. '
              + 'Điều hệ thống làm được là cho thấy con đang ở đâu và còn thiếu dạng nào.' },
          { h: 'Dữ liệu của con tôi có an toàn không?',
            d: 'Tài khoản đăng nhập được bằng khuôn mặt thật qua phần cứng của máy; '
              + 'hệ thống không giữ ảnh và không giữ đặc trưng khuôn mặt.' },
          { h: 'Không có mạng thì dùng được không?',
            d: 'Được. Có bản cài đặt cho Windows 64-bit, tải về chạy thẳng.' },
        ],
      };
      break;
    case 'loi-moi':
      chu = {
        tieu: 'Xem thử trước khi quyết định',
        phu: 'Mở sơ đồ chương trình và làm thử một lượt chẩn đoán. Không cần trả gì để xem.',
        nut: 'Mở sơ đồ chương trình',
      };
      break;
    default:
      return { ok: false, ma, loi: 'CHUA_VIET' };
  }

  const nguonDung = m.can.map((k) => ({ so: k, giaTri: so[k], nguon: nguon[k] }));
  const kiem = luat.soi(chu, { tenTrang: m.ten });
  if (!kiem.dat) {
    return { ok: false, ma, ten: m.ten, loi: 'KHONG_QUA_LUAT_NOI_DUNG', viPham: kiem.loi };
  }
  return { ok: true, ma, ten: m.ten, nhip: m.nhip, chu, nguonSo: nguonDung };
}

/** Soạn cả trang. */
function soanTrang(N) {
  const sl = docSoLieu(N);
  const ra = [];
  const boQua = [];
  for (const ma of Object.keys(MANG)) {
    const m = vietMang(ma, sl);
    if (m.ok) ra.push(m);
    else boQua.push(m);
  }
  return {
    ok: true,
    mang: ra,
    boQua,
    soLieu: sl.so,
    nguonSoLieu: sl.nguon,
    ghiChu: boQua.length
      ? `${boQua.length} mảng không được sinh ra vì kho chưa có số liệu thật. `
        + 'Trang thưa vì hệ thống chưa có dữ liệu, không phải vì lỗi.'
      : null,
  };
}

module.exports = { soanTrang, vietMang, docSoLieu, MANG };
