'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  LUẬT NỘI DUNG — bốn thứ không được phép in ra trang công khai
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Nội dung tiếp thị của một nơi dạy trẻ con khác hẳn nội dung tiếp thị của
 *  một cái máy pha cà phê: người đọc là ba mẹ đang lo cho con, và họ TIN.
 *  Một câu viết quá tay ở đây không làm mất một đơn hàng — nó làm một gia
 *  đình kỳ vọng sai, rồi trách đứa trẻ khi kỳ vọng ấy không thành.
 *
 *  Nên bốn luật dưới đây là luật CỨNG, máy cưỡng chế, không có ô "trường hợp
 *  đặc biệt":
 *
 *  1. KHÔNG HỨA KẾT QUẢ.       Dùng chung đúng bộ khuôn với lớp canh đường
 *                              ra của trợ lý trò chuyện — một luật, một chỗ
 *                              định nghĩa. Hai bản sao thì sớm muộn lệch nhau
 *                              và cái lệch ấy chính là lỗ thủng.
 *  2. KHÔNG NHỒI TỪ KHOÁ.      Nhồi từ khoá là viết cho cỗ máy tìm kiếm đọc
 *                              chứ không cho người đọc. Trang nhồi từ khoá
 *                              đọc lên nghe như máy nói, và ba mẹ cảm được.
 *  3. KHÔNG GIỌNG MÁY.         Những cụm chỉ xuất hiện khi chữ do máy sinh ra
 *                              mà không ai đọc lại.
 *  4. KHÔNG LỘ PHÂN LOẠI NỘI BỘ. Bức tường sẵn có của hệ này.
 *
 *  ── VÌ SAO ĐO TỈ LỆ TỪ CHỨ KHÔNG ĐẾM SỐ LẦN ─────────────────────────────
 *
 *  "Xuất hiện quá 5 lần" phạt oan một bài dài và bỏ lọt một đoạn ngắn nhồi
 *  kín. Tỉ lệ thì không: một từ chiếm quá 5% tổng số từ là nhồi, dù bài dài
 *  hay ngắn. Từ nối tiếng Việt ("và", "của", "là"...) được trừ ra trước, vì
 *  chúng vốn dĩ phải dày.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { deaccent, round } = require('../utils');
const tuong = require('../cay-tien/buc-tuong');
const { HUA_KET_QUA, CHAN_DOAN } = require('../tro-chuyen/canh-ra');

/**
 * Từ nối, hư từ VÀ ĐẠI TỪ XƯNG HÔ — vốn dĩ phải dày, không tính vào phép đo.
 *
 * Nhóm xưng hô thêm vào sau khi phép đo báo đỏ một lời đọc hoàn toàn sạch:
 * kịch bản video cho vai quản trị gọi người xem là "anh/chị" ở mỗi chương,
 * nên "chị" chiếm 5,1% số từ. Tiếng Việt lịch sự BẮT BUỘC nhắc lại đại từ
 * xưng hô — bỏ bớt đi thì câu thành trống không, chứ không thành hay hơn.
 *
 * Bỏ nhóm này ra không làm phép đo yếu đi: một trang nhồi từ khoá thật thì
 * nhồi tên dịch vụ và tên địa phương, không nhồi đại từ.
 */
const TU_NOI = new Set(('va cua la mot cac nhung cho voi tu den trong ra vao khi thi ma nay do'
  + ' co khong duoc se da dang cung nhu de theo tren duoi ve boi tai vi nen hay hoac o'
  + ' anh chi em con chau ban minh toi thay ta ho no chung quy vi ai nguoi'
  // Tiểu từ cuối câu — hư từ đúng nghĩa trong tiếng Việt, vốn dĩ phải dày.
  + ' nhe a nhi thoi vay day do ma co u oi').split(' '));

/** Tỉ lệ tối đa một từ được chiếm. */
const NGUONG_NHOI = 0.05;

/**
 * Bài ngắn hơn ngần này thì phép đo tỉ lệ KHÔNG CÓ NGHĨA, nên không đo.
 *
 * Con số này đã phải nâng hai lần, và cả hai lần đều vì phép đo báo đỏ một
 * đoạn văn SẠCH. Ghi lại cả hai, vì chúng nói rõ phép đo này đo được gì:
 *
 *   40 → 120   Đoạn bốn mươi từ lặp chữ "đúng" ba lần đã vượt ngưỡng 5%.
 *              Ba lần trong bốn mươi từ là tiếng Việt bình thường.
 *
 *   120 → 250  Kịch bản hướng dẫn một màn hình, dài trăm rưởi từ, nhắc chữ
 *              "màn" tám lần. Trong một bài nói VỀ một màn hình thì danh từ
 *              chính phải lặp lại — bỏ bớt đi thì câu thành mơ hồ, chứ không
 *              thành hay hơn.
 *
 * Nâng lên 250 làm phép đo HẸP LẠI, và nói thẳng điều đó: nó chỉ còn soi văn
 * xuôi DÀI — tức là đúng chỗ nhồi từ khoá thật sự xảy ra. Nhồi từ khoá là
 * việc người ta làm trên trang đích dài để leo thứ hạng tìm kiếm, không phải
 * việc ai làm trong một đoạn giới thiệu trăm từ.
 *
 * Một phép đo hẹp mà đúng thì dùng được. Một phép đo rộng mà báo oan bốn lần
 * liên tiếp thì người ta sẽ tắt nó đi — và lúc ấy nó không còn soi gì nữa.
 */
const DAI_TOI_THIEU_DO_NHOI = 250;

/**
 * Và phải lặp ít nhất ngần này lần thì mới xét tới tỉ lệ.
 *
 * Hai điều kiện cùng lúc, vì mỗi điều kiện một mình đều hỏng: chỉ xét tỉ lệ
 * thì phạt oan bài ngắn; chỉ đếm số lần thì bỏ lọt bài dài nhồi kín.
 */
const LAP_TOI_THIEU = 5;

/**
 * Giọng máy. Mỗi cụm kèm một câu nói rõ vì sao nó là giọng máy — để người
 * viết sửa được chứ không chỉ bị gạch.
 */
const GIONG_MAY = [
  { cum: 'trong thời đại số', vi: 'Câu mở bài rỗng — bỏ đi thì đoạn văn không mất gì.' },
  { cum: 'trong thế giới ngày nay', vi: 'Câu mở bài rỗng.' },
  { cum: 'trong bối cảnh hiện nay', vi: 'Câu mở bài rỗng.' },
  { cum: 'không thể phủ nhận', vi: 'Nói rằng không ai cãi được, thay vì đưa ra lý do.' },
  { cum: 'chìa khoá thành công', vi: 'Sáo ngữ, không nói được điều gì cụ thể.' },
  { cum: 'giải pháp toàn diện', vi: 'Hứa bao trùm mọi thứ, tức là không hứa gì rõ.' },
  { cum: 'đột phá', vi: 'Tự nhận đột phá là tự chấm điểm mình.' },
  { cum: 'cách mạng hoá', vi: 'Tự nhận cách mạng là tự chấm điểm mình.' },
  { cum: 'game-changer', vi: 'Sáo ngữ tiếng Anh trong một trang tiếng Việt.' },
  { cum: 'hãy cùng khám phá', vi: 'Câu dẫn dắt rỗng của văn máy.' },
  { cum: 'tóm lại, có thể thấy rằng', vi: 'Câu kết rỗng.' },
  { cum: 'điều quan trọng cần lưu ý là', vi: 'Câu đệm rỗng — bỏ đi thì ý vẫn nguyên.' },
];

const tachTu = (s) => deaccent(String(s || '')).toLowerCase()
  .replace(/[^\p{L}\p{N}\s]/gu, ' ').split(/\s+/).filter(Boolean);

/**
 * Lấy ra CHỮ NGƯỜI ĐỌC, bỏ phần khung dữ liệu.
 *
 * Lỗi CÓ THẬT của bản đầu: nội dung một mảng là một đối tượng, và bản đầu đem
 * cả đối tượng ấy qua JSON.stringify rồi đếm từ. Thế là TÊN KHOÁ bị đếm như
 * chữ — "ten" xuất hiện năm lần vì mảng có năm mục, mỗi mục một khoá `ten`,
 * và phép đo nhồi từ khoá báo đỏ một đoạn văn hoàn toàn bình thường.
 *
 * Tên khoá không ai đọc. Chỉ giá trị chuỗi mới là chữ.
 */
function layChu(x) {
  if (x == null) return '';
  if (typeof x === 'string') return x;
  if (typeof x === 'number' || typeof x === 'boolean') return String(x);
  if (Array.isArray(x)) return x.map(layChu).join(' ');
  if (typeof x === 'object') return Object.values(x).map(layChu).join(' ');
  return '';
}

/**
 * Soi một đoạn nội dung.
 *
 * @returns {{dat:boolean, loi:Array<{ma,vi,chiTiet}>, doDai:number, tuDayNhat:object}}
 */
/**
 * @param {object} o
 * @param {boolean} o.doNhoi  có chạy phép đo nhồi từ khoá không.
 *
 * Phép đo nhồi là phép đo dành cho VĂN XUÔI. Một bảng dữ liệu lặp lại tên cột
 * và tên vai ở mọi dòng — đó là cấu trúc, không phải nhồi. Trang danh mục 36
 * video nhắc chữ "giáo viên" chín lần vì có chín màn hình, chứ không vì ai cố
 * ý. Bắt phép đo văn xuôi chạy trên bảng là bắt nó trả lời một câu hỏi không
 * đặt ra cho nó.
 *
 * Ba phép đo còn lại — hứa kết quả, chẩn đoán, lộ phân loại nội bộ — thì vẫn
 * chạy trên bảng, vì một lời hứa nằm trong ô bảng vẫn là một lời hứa.
 */
function soi(noiDung, { tenTrang = '', doNhoi = true } = {}) {
  const chu = layChu(noiDung);
  const loi = [];

  for (const h of HUA_KET_QUA) {
    const m = chu.match(h.re);
    if (m) loi.push({ ma: 'hua-ket-qua', vi: h.vi, chiTiet: m[0].slice(0, 90) });
  }
  for (const c of CHAN_DOAN) {
    const m = chu.match(c.re);
    if (m) loi.push({ ma: 'chan-doan', vi: c.vi, chiTiet: m[0].slice(0, 90) });
  }
  for (const g of GIONG_MAY) {
    if (deaccent(chu).toLowerCase().includes(deaccent(g.cum).toLowerCase())) {
      loi.push({ ma: 'giong-may', vi: g.vi, chiTiet: g.cum });
    }
  }

  const tu = tachTu(chu);
  let day = null;

  // Đếm TỪ CÓ NGHĨA trước, rồi mới quyết định có đo hay không.
  //
  // Bản trước mở cửa theo TỔNG số từ mà lại tính tỉ lệ trên số từ CÓ NGHĨA —
  // hai mẫu số khác nhau cho cùng một phép đo. Hệ quả: một kịch bản 280 chữ
  // nhưng chỉ 160 chữ có nghĩa vẫn bị đem ra đo, và ngưỡng 5% ở mẫu số nhỏ
  // ấy rơi vào đúng 8 lần — tức là danh từ chính của bài.
  const dem = new Map();
  let thuc = 0;
  for (const t of tu) {
    if (TU_NOI.has(t) || t.length <= 1) continue;
    thuc += 1;
    dem.set(t, (dem.get(t) || 0) + 1);
  }

  if (doNhoi && thuc >= DAI_TOI_THIEU_DO_NHOI) {
    for (const [t, n] of dem) {
      const tiLe = thuc ? n / thuc : 0;
      if (!day || tiLe > day.tiLe) day = { tu: t, lan: n, tiLe: round(tiLe, 4) };
    }
    if (day && day.tiLe > NGUONG_NHOI && day.lan >= LAP_TOI_THIEU) {
      loi.push({
        ma: 'nhoi-tu-khoa',
        vi: `Từ "${day.tu}" chiếm ${(day.tiLe * 100).toFixed(1)}% số từ có nghĩa, quá mức ${NGUONG_NHOI * 100}%. `
          + 'Nhồi từ khoá là viết cho cỗ máy tìm kiếm chứ không cho người đọc.',
        chiTiet: `${day.tu} × ${day.lan}`,
      });
    }
  }

  const roRi = tuong.soiRoRi(chu);
  if (!roRi.sach) {
    loi.push({
      ma: 'lo-phan-loai-noi-bo',
      vi: 'Nội dung mang cách hệ thống phân loại gia đình trong nội bộ ra trang công khai.',
      chiTiet: (roRi.roRi || []).slice(0, 2).map((r) => r.cum || r).join(', '),
    });
  }

  return { dat: loi.length === 0, loi, tenTrang, doDai: tu.length, doDaiCoNghia: thuc, tuDayNhat: day };
}

module.exports = { soi, layChu, GIONG_MAY, NGUONG_NHOI, LAP_TOI_THIEU, DAI_TOI_THIEU_DO_NHOI, TU_NOI };
