'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  TRANG RIÊNG CHO TỪNG PHẦN CỦA HỆ THỐNG
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Mỗi phần lớn của GITAV20nexus có một trang riêng, đầy đủ, đọc được
 *  mà không cần đăng nhập: ba môn học, sáu kỳ thi chuẩn, ba trại, bộ phiếu
 *  đo năng lực, lộ trình cá nhân, bộ máy 600 trợ lý, hiến pháp, kho bài,
 *  quan hệ gia đình, tài chính kế toán.
 *
 *  BA LUẬT CỦA MỌI TRANG Ở ĐÂY:
 *
 *  1. KHÔNG SỐ NÀO VIẾT CỨNG TRONG LỜI VĂN. Mọi con số đều nội suy từ bảng
 *     gốc hoặc từ kho. Viết "sáu kỳ thi" vào câu văn là mở đường cho một
 *     ngày nào đó có bảy kỳ mà câu văn vẫn nói sáu.
 *
 *  2. KHÔNG TRANG NÀO NÓI QUÁ. Kho đang trống thì trang nói là đang trống.
 *     Con số 800.000 luôn đi kèm chữ "đích", không bao giờ đứng một mình.
 *
 *  3. KHÔNG CHỮ NÀO CHẠY. Các trang này phục vụ dưới CSP script-src 'none',
 *     nên phần gập mở dùng <details>, không dùng JavaScript.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { voTrang, thoat } = require('./dung-trang-tinh');

const so = (n) => Number(n || 0).toLocaleString('vi-VN');

/** Một khối mở đầu chung cho mọi trang miền. */
function moDau(nhan, tieu, phu) {
  return `<section class="modau"><div class="khung"><div class="hep">
<span class="nhan-nho">${thoat(nhan)}</span>
<h1>${thoat(tieu)}</h1>
<p class="phu">${thoat(phu)}</p>
</div></div></section>`;
}

function bang(dauCot, hang) {
  return `<div class="bang-cuon"><table>
<thead><tr>${dauCot.map((c) => `<th>${thoat(c)}</th>`).join('')}</tr></thead>
<tbody>${hang.map((h) => `<tr>${h.map((o) => `<td>${o}</td>`).join('')}</tr>`).join('')}</tbody>
</table></div>`;
}

function the(ten, y) {
  return `<div class="the"><h3>${thoat(ten)}</h3><p>${thoat(y)}</p></div>`;
}

function khoi(tieu, phu, than) {
  return `<section class="khung"><div class="hep">
<h2>${thoat(tieu)}</h2>${phu ? `<p class="phu">${thoat(phu)}</p>` : ''}${than}
</div></section>`;
}

// ═══════════════════════════════════════════════════════════════════════════
//  MỘT MÔN HỌC — lớp 1 đến 12, bảy cấp độ
// ═══════════════════════════════════════════════════════════════════════════

function trangMon(mon, { capDo, o, ngayDung, phuSong = {} }) {
  const cuaMon = o.filter((x) => x.mon_id === mon.id);
  const lop = [...new Set(cuaMon.map((x) => x.lop))].sort((a, b) => a - b);

  const luoi = bang(
    ['Lớp'].concat(capDo.map((c) => c.ten)),
    lop.map((l) => [String(l)].concat(capDo.map((c) => {
      const ok = cuaMon.find((x) => x.lop === l && x.cap_do_id === c.id);
      if (!ok) return '<span class="rat-nho" style="opacity:.45">—</span>';
      const p = phuSong[ok.id] || { bai: 0, chuyenDe: 0 };
      return `<b>${so(p.chuyenDe)}</b> chuyên đề<br><span class="rat-nho">${so(p.bai)} bài</span>`;
    }))));

  const bacCap = capDo.map((c) => `<details><summary>${thoat(c.ten)} — ${thoat(c.dich_den)}</summary>
<p><b>Điều kiện vào:</b> ${thoat(c.dieu_kien_vao)}</p></details>`).join('');

  const tongBai = cuaMon.reduce((s, x) => s + ((phuSong[x.id] || {}).bai || 0), 0);
  const tongCd = cuaMon.reduce((s, x) => s + ((phuSong[x.id] || {}).chuyenDe || 0), 0);

  const than = moDau('Môn học', mon.ten, mon.mo_ta)
    + khoi('Bản đồ ' + lop.length + ' lớp × ' + capDo.length + ' cấp độ',
      'Ô trống nghĩa là cấp ấy chưa mở cho lớp ấy — cố ý, không phải thiếu sót. '
      + 'Cấp Đại học mở từ lớp 10, Quốc tế từ lớp 6, Chuyên từ lớp 5.',
      luoi
      + `<p class="nguon">Hiện có ${so(tongCd)} chuyên đề và ${so(tongBai)} bài thuộc môn này. `
      + 'Số đếm trực tiếp từ kho lúc dựng trang, không lấy từ chỗ khai tay.</p>')
    + khoi('Bảy cấp độ khác nhau ở điều gì',
      'Không phải bảy cái tên cho cùng một thứ. Mỗi cấp có đích riêng và '
      + 'điều kiện vào riêng, đo được bằng máy.', bacCap)
    + khoi('Chuẩn kiến thức lấy từ đâu',
      'Ba nguồn, và chỉ ba nguồn này.',
      `<div class="o">
${the('Bộ Giáo dục và Đào tạo', 'Chương trình giáo dục phổ thông 2018, ban hành kèm Thông tư 32/2018/TT-BGDĐT.')}
${the('Chuẩn quốc tế', 'Khung chuẩn đang dùng ở Hoa Kỳ và khung của College Board cho phần thi chuẩn hoá.')}
${the('Quy ước toán học', 'Ký hiệu và đại lượng theo ISO 80000-2; đơn vị theo hệ SI.')}
</div>
<p class="nguon">Không có nguồn nào tên là "AI". Chuẩn do mô hình ngôn ngữ tự sinh không vào được
bảng chuẩn — ràng buộc nằm ở tầng kho dữ liệu, không phải ở lời hứa.</p>`)
    + khoi('Vào học thế nào',
      'Bốn bước, và bước nào cũng để lại số đo được.',
      `<div class="o">
${the('1 · Tạo hồ sơ', 'Khai lớp, trường, mục tiêu và kỳ thi đích.')}
${the('2 · Test đầu vào', 'Đo nền kiến thức thật. Kết quả cao nhất mở tới cấp Nâng cao.')}
${the('3 · Nhận lộ trình', 'Lộ trình cá nhân theo đúng ô chương trình phù hợp.')}
${the('4 · Học và được xét', 'Cấp sau chỉ mở khi cấp trước đủ bằng chứng, đủ mẫu.')}
</div>
<div class="hang-nut"><a class="nut" href="/ui/cong.html">Bắt đầu với test đầu vào</a>
<a class="nut phu" href="/lo-trinh-ca-nhan.html">Xem lộ trình hoạt động thế nào</a></div>`);

  return voTrang({
    tieuDe: mon.ten + ' lớp 1–12 · GITAV20nexus',
    moTa: mon.ten + ' từ lớp 1 đến lớp 12 với bảy cấp độ, chuẩn kiến thức có nguồn, '
      + 'lộ trình cá nhân hoá và điều kiện vượt cấp đo được.',
    dangO: '/chuong-trinh.html', than, ngayDung,
  });
}

// ═══════════════════════════════════════════════════════════════════════════
//  MỘT KỲ THI CHUẨN
// ═══════════════════════════════════════════════════════════════════════════

function trangKyThi(he, kyThi, { ngayDung, tenNac, tongCua }) {
  const t = tongCua(he.id);
  const khoang = (x) => (Array.isArray(x) ? x[0] + '–' + x[1] : String(x));

  const phan = bang(['Phần thi', 'Số câu', 'Số phút', 'Môn'],
    he.phan.map((p) => [thoat(p.ten), so(p.cau), so(p.phut), thoat(p.mon || '—')]));

  const nac = bang(['Nấc', 'Tên nấc', 'Khoảng điểm'],
    he.nac.map((n, i) => [String(i + 1), thoat(tenNac[i]), so(n[0]) + ' – ' + so(n[1])]));

  const khop = t.khopCau && t.khopPhut;

  const than = moDau('Kỳ thi chuẩn', kyThi.ngan, kyThi.ten + ' — do ' + kyThi.co_quan + ' tổ chức.')
    + khoi('Cấu trúc đề',
      'Số câu và số phút dưới đây chép từ tài liệu gốc, không ước lượng.',
      phan
      + `<p class="nguon">Tổng khai trong tài liệu: ${khoang(he.tongCau)} câu, ${khoang(he.tongPhut)} phút. `
      + `Cộng lại từ các phần: ${so(t.cau)} câu, ${so(t.phut)} phút. `
      + (khop
        ? 'Hai con số khớp nhau.'
        : 'HAI CON SỐ LỆCH NHAU — đây là mâu thuẫn trong tài liệu nguồn, đang chờ đối chiếu lại. '
          + 'Trang này nói ra thay vì chọn một đầu rồi im lặng.')
      + '</p>')
    + khoi('Mười nấc trình độ',
      'Cả sáu hệ chuẩn đều chia trình độ thành đúng mười nấc mang cùng tên gọi. '
      + 'Nhờ thế mà so được giữa các hệ với nhau, thay vì mỗi hệ một thang riêng.',
      nac)
    + khoi('Lộ trình từ cấp 0 tới ' + kyThi.ngan,
      'Không nhảy nấc. Mỗi nấc một chặng, mỗi chặng một điều kiện đo được.',
      `<div class="o">
${the('Bài chẩn đoán', 'Một đề đầy đủ để biết đang đứng ở nấc nào. Không đoán, không hỏi cảm giác.')}
${the('Chặng theo nấc', 'Từ nấc hiện tại tới nấc đích, mỗi nấc một chặng riêng có mục tiêu điểm cụ thể.')}
${the('Thi thử có chấm', 'Mỗi chặng đóng lại bằng một lượt thi thử đầy đủ, chấm bằng máy phần chấm được.')}
${the('Chỗ yếu hiện ra', 'Câu sai nhóm lại theo chuẩn kiến thức, nên biết hổng chỗ nào chứ không chỉ biết điểm.')}
</div>
<div class="hang-nut"><a class="nut" href="/ui/cong.html">Làm bài chẩn đoán</a>
<a class="nut phu" href="/luyen-thi.html">So sánh sáu hệ chuẩn</a></div>`)
    + (kyThi.ghi_chu ? khoi('Điều cần biết thêm', null,
      `<p>${thoat(kyThi.ghi_chu)}</p>`) : '');

  return voTrang({
    tieuDe: kyThi.ngan + ' — cấu trúc, mười nấc và lộ trình · GITAV20nexus',
    moTa: kyThi.ten + '. Cấu trúc đề chép từ tài liệu gốc, mười nấc trình độ và lộ trình '
      + 'luyện từ nấc hiện tại tới nấc đích.',
    dangO: '/luyen-thi.html', than, ngayDung,
  });
}

// ═══════════════════════════════════════════════════════════════════════════
//  MỘT TRẠI HUẤN LUYỆN
// ═══════════════════════════════════════════════════════════════════════════

function trangTrai(trai, { ngayDung }) {
  const vao = trai.nguong_vao.map((x) => `<li>${thoat(x.mo_ta)}</li>`).join('');
  const ra = bang(['Điều kiện ra', 'Đo bằng', 'Ngưỡng'],
    trai.nguong_ra.map((x) => [thoat(x.mo_ta), thoat(x.do_bang), so(x.nguong)]));

  const than = moDau('Trại huấn luyện', trai.ten, trai.muc_tieu)
    + khoi('Trại này dành cho ai',
      null,
      `<div class="o">
${the('Lớp ' + trai.lop_tu + ' đến ' + trai.lop_den, 'Ngoài khoảng này thì ghi danh vẫn nhận nhưng để ở trạng thái chờ xét, và không chiếm chỗ của khoá.')}
${the(trai.so_ngay + ' ngày · ' + trai.so_gio + ' giờ', 'Tổng thời lượng, chia thành các chặng có mục tiêu riêng.')}
</div>
<h3>Ngưỡng vào</h3><ul class="ds-kiem">${vao}</ul>`)
    + khoi('Ngưỡng ra — và vì sao nó phải thật',
      'Không đạt thì không có chứng nhận. Hệ thống nói rõ thiếu điều nào và thiếu bao nhiêu, '
      + 'thay vì phát cho đủ mặt — phát cho đủ mặt là làm hỏng giá trị của chính tờ chứng nhận.',
      ra)
    + khoi('Trại khác lớp học ở chỗ nào',
      null,
      `<div class="o">
${the('Có điểm danh từng chặng', 'Vắng quá ngưỡng là không đạt, bất kể làm bài tốt đến đâu.')}
${the('Có chấm và nhận xét', 'Mỗi chặng để lại một điểm số và một câu nhận xét của người phụ trách.')}
${the('Có sức chứa', 'Đủ người là đóng ghi danh. Nhận quá là phá chất lượng của chính khoá ấy.')}
</div>
<div class="hang-nut"><a class="nut" href="/ui/cong.html">Ghi danh khoá gần nhất</a></div>`);

  return voTrang({
    tieuDe: trai.ten + ' · GITAV20nexus',
    moTa: trai.muc_tieu,
    dangO: '/he-thong.html', than, ngayDung,
  });
}

// ═══════════════════════════════════════════════════════════════════════════
//  ĐO NĂNG LỰC, TÍNH CÁCH VÀ PHƯƠNG PHÁP HỌC
// ═══════════════════════════════════════════════════════════════════════════

function trangDoNangLuc(bo, { ngayDung, canhBaoChung }) {
  const ds = Object.entries(bo).map(([ma, b]) => {
    const soCau = b.mo.deBai().length;
    return `<details><summary>${thoat(b.ten)} — ${so(soCau)} câu</summary>
<p><b>Nhóm:</b> ${thoat(b.nhom)}</p>
<p><b>Nguồn:</b> ${thoat(b.nguon)}</p>
${b.mo.KHONG_LAM ? `<p><b>Bộ này KHÔNG hỏi gì:</b> ${thoat(b.mo.KHONG_LAM)}</p>` : ''}</details>`;
  }).join('');

  const than = moDau('Đo năng lực', 'Bộ phiếu đo — và giới hạn của chúng',
    'Bốn bộ phiếu đo tính cách, kỹ năng, tâm lý học đường và phương pháp học. '
    + 'Mỗi bộ nói rõ nó đo được gì, và quan trọng hơn: nó KHÔNG đo được gì.')
    + khoi('Điều phải đọc trước khi làm bất kỳ phiếu nào', null,
      `<div class="the" style="border-color:var(--nhan)">
<h3>Đây không phải chẩn đoán</h3>
<p>${thoat(canhBaoChung)}</p></div>`)
    + khoi('Bốn bộ phiếu', 'Bấm vào từng bộ để xem nó đo gì và không đo gì.', ds)
    + khoi('Kết quả được đánh giá độ tin thế nào',
      'Một phiếu làm cho xong thì kết quả vô nghĩa, nên hệ thống đo luôn cả cách làm.',
      `<div class="o">
${the('Làm quá nhanh', 'Dưới ba giây một câu là chưa kịp đọc. Kết quả vẫn trả về nhưng đánh dấu không tin được.')}
${the('Chọn một mức suốt', 'Chọn cùng một mức ở chín phần mười số câu là dấu hiệu bấm cho xong.')}
${the('Bỏ trống nhiều', 'Càng bỏ trống nhiều thì độ tin càng xuống.')}
${the('Nói thẳng vì sao', 'Không tin được thì trang nói rõ lý do, chứ không lặng lẽ hạ điểm.')}
</div>
<div class="hang-nut"><a class="nut" href="/ui/cong.html">Làm một bộ phiếu</a></div>`);

  return voTrang({
    tieuDe: 'Đo năng lực, tính cách và phương pháp học · GITAV20nexus',
    moTa: 'Bốn bộ phiếu đo DISC, MBTI, sàng lọc tâm lý học đường và phương pháp học — '
      + 'kèm giới hạn của từng bộ và cách đo độ tin của kết quả.',
    dangO: '/ho-so.html', than, ngayDung,
  });
}

// ═══════════════════════════════════════════════════════════════════════════
//  LỘ TRÌNH CÁ NHÂN HOÁ
// ═══════════════════════════════════════════════════════════════════════════

function trangLoTrinh({ ngayDung, capDo, doBang }) {
  const bacCap = bang(['Cấp độ', 'Đích đến', 'Điều kiện vào'],
    capDo.map((c) => [`<b>${thoat(c.ten)}</b>`, thoat(c.dich_den), thoat(c.dieu_kien_vao)]));

  const cachDo = bang(['Đo bằng', 'Nghĩa là gì'],
    doBang.map((d) => [`<b>${thoat(d[0])}</b>`, thoat(d[1])]));

  const than = moDau('Lộ trình', 'Lộ trình cá nhân hoá và điều kiện vượt cấp',
    'Cấp sau chỉ mở khi cấp trước có bằng chứng đo được, và đủ mẫu để kết luận.')
    + khoi('Luật gốc: không nhảy cấp',
      'Điều 7 của hiến pháp vận hành.',
      `<div class="o">
${the('Bằng chứng, không cảm giác', 'Mọi điều kiện vượt đều đo được bằng máy từ dữ liệu thật của người học.')}
${the('Đủ mẫu mới kết luận', 'Làm đúng ba bài không phải là đạt 100% — đó là mới làm ba bài. Thiếu mẫu thì hệ trả về “thiếu mẫu”, không trả về “đạt”.')}
${the('Mở tay vẫn để lại dấu', 'Quản trị mở cấp bằng tay được, nhưng phải nêu lý do và lý do ấy nằm vĩnh viễn trong nhật ký.')}
${the('Nói rõ còn thiếu gì', 'Chưa đạt thì hệ liệt kê từng điều kiện với số thật bên cạnh ngưỡng.')}
</div>`)
    + khoi('Bảy cấp độ và điều kiện vào', null, bacCap)
    + khoi('Sáu cách đo', 'Điều kiện vượt là dữ liệu, không phải mã. Đổi chuẩn không phải sửa mã.', cachDo)
    + khoi('Giám sát trong lúc học',
      'Sáu loại cảnh báo, và mỗi cảnh báo bắt buộc kèm bằng chứng — cảnh báo không bằng chứng là tin đồn.',
      `<div class="o">
${the('Tụt dốc', 'Tỉ lệ đúng giảm liên tục qua các buổi gần nhất.')}
${the('Nghỉ lâu', 'Đứt chuỗi học quá lâu so với nhịp đã cam kết.')}
${the('Đoán bừa', 'Trả lời nhanh bất thường kèm tỉ lệ đúng quanh mức ngẫu nhiên.')}
${the('Quá tải', 'Số giờ vượt xa mức đã thoả thuận với gia đình.')}
${the('Sai lặp lại', 'Cùng một chuẩn kiến thức sai đi sai lại.')}
${the('Đạt đích sớm', 'Cũng là cảnh báo — vì nó nghĩa là lộ trình đang đặt quá thấp.')}
</div>
<div class="hang-nut"><a class="nut" href="/ui/cong.html">Xem lộ trình của mình</a></div>`);

  return voTrang({
    tieuDe: 'Lộ trình cá nhân hoá · GITAV20nexus',
    moTa: 'Lộ trình cá nhân, điều kiện vượt cấp đo được, và sáu loại cảnh báo học tập '
      + 'có bằng chứng kèm theo.',
    dangO: '/hanh-trinh-hoc.html', than, ngayDung,
  });
}

// ═══════════════════════════════════════════════════════════════════════════
//  BỘ MÁY 600 TRỢ LÝ
// ═══════════════════════════════════════════════════════════════════════════

function trangBoMay({ ngayDung, ban, troLy, tenVai, nhiemVu, quyTrinh, crmTo, soCrm }) {
  const theoVai = {};
  for (const t of troLy) theoVai[t.vai] = (theoVai[t.vai] || 0) + 1;

  const bangBan = bang(['Ban', 'Số người', 'Nhiệm vụ'],
    ban.map((b) => [`<b>${thoat(b.ten)}</b>`, so(b.so), thoat(b.nhiem_vu)]));

  const bangVai = bang(['Vai', 'Số người', 'Làm gì'],
    [['truong-ban', 'Chia việc trong ban, chịu trách nhiệm đầu ra của ban'],
      ['hoach-dinh', 'Cắt việc lớn thành việc nhỏ giao được'],
      ['thuc-thi', 'Làm phần lớn khối lượng'],
      ['tham-dinh', 'Soát lại việc của người khác — không bao giờ soát việc của chính mình'],
      ['huan-luyen', 'Sửa lời dặn cho trợ lý có kết quả kém'],
      ['tra-cuu', 'Tìm nguồn và đối chiếu chuẩn'],
      ['canh-gac', 'Chặn việc vượt quyền và việc phạm hiến pháp']]
      .map(([v, y]) => [`<b>${thoat(tenVai[v])}</b>`, so(theoVai[v] || 0), thoat(y)]));

  const bangNv = bang(['Nhiệm vụ', 'Ban', 'Thế nào là làm xong đúng', 'Cần người duyệt'],
    nhiemVu.map((n) => [thoat(n.ten), thoat(n.ban), thoat(n.tieu_chuan),
      n.can_nguoi_duyet ? '<b>Có</b>' : '—']));

  const bangQt = quyTrinh.map((q) => `<details><summary>${thoat(q.ten)}</summary>
<p>${thoat(q.muc_dich)}</p>
<ol>${q.buoc.map((b) => `<li>${thoat(b.viec)} — ban ${thoat(b.ban)}${b.duyet_boi ? `, duyệt bởi <b>${thoat(b.duyet_boi)}</b>` : ''}</li>`).join('')}</ol>
<p class="rat-nho">Đầu ra: ${thoat(q.dau_ra)}</p></details>`).join('');

  const than = moDau('Bộ máy', so(troLy.length) + ' trợ lý AI chuyên môn',
    'Chia thành ' + ban.length + ' ban theo chuyên môn và ' + Object.keys(theoVai).length
    + ' vai theo việc. Gọi là trợ lý AI chuyên môn — không gọi là đại lý.')
    + khoi(ban.length + ' ban chuyên môn', null, bangBan)
    + khoi('Bảy vai, mỗi vai một lý do tồn tại',
      'Vai thẩm định không bao giờ soát việc của chính mình — luật ấy nằm ở tầng mã, '
      + 'không phải ở lời dặn.', bangVai)
    + khoi('Bảng nhiệm vụ',
      'Việc nào ai làm, cần gì, ra gì, và thế nào là làm xong đúng. '
      + 'Việc có hậu quả dừng ở trạng thái chờ duyệt — không có đường nào tự nhảy sang xong.',
      bangNv)
    + khoi('Quy trình vận hành', 'Trình tự bước và ai duyệt ở bước nào.', bangQt)
    + khoi('Quan hệ gia đình — ' + so(soCrm) + ' trợ lý riêng',
      'Tầng này KHÔNG gộp vào bộ máy chuyên môn ở trên. Lý do: bộ máy kia làm việc '
      + 'trên nội dung học, còn tầng này đọc dữ liệu thật của một gia đình. '
      + 'Hai kho dữ liệu, hai bộ quyền, hai nhật ký.',
      bang(['Tổ', 'Số người', 'Việc'],
        crmTo.map((t) => [`<b>${thoat(t.ten)}</b>`, so(t.so), thoat(t.viec)]))
      + '<p class="nguon">Tổ Công nợ cố ý để mức tự chủ 0: nhắc tiền và xử lý phàn nàn là hai '
      + 'việc dễ làm tổn thương nhất, nên luôn phải qua một con người.</p>')
    + khoi('Đo bằng gì',
      'KPI đếm việc thật đã nhận, đã xong, đã bị trả lại. Chưa có việc nào thì trang '
      + 'nói là chưa có, không dựng một con số cho đẹp.',
      `<div class="hang-nut"><a class="nut" href="/hien-phap.html">Đọc hiến pháp vận hành</a>
<a class="nut phu" href="/quan-tri.html">Hệ thống quản trị</a></div>`);

  return voTrang({
    tieuDe: so(troLy.length) + ' trợ lý AI chuyên môn · GITAV20nexus',
    moTa: 'Bộ máy ' + so(troLy.length) + ' trợ lý chia theo ban và vai, bảng nhiệm vụ, '
      + 'quy trình vận hành và cách đo kết quả.',
    dangO: '/quan-tri.html', than, ngayDung,
  });
}

// ═══════════════════════════════════════════════════════════════════════════
//  HIẾN PHÁP VẬN HÀNH
// ═══════════════════════════════════════════════════════════════════════════

function trangHienPhap(banHp, { ngayDung }) {
  const dieu = banHp.dieu.map((d) => `<details><summary>Điều ${d.dieu} — ${thoat(d.ten)}</summary>
<p>${thoat(d.noiDung)}</p>
<p><b>Căn cứ:</b> ${d.canCu.map((c) => thoat(c.van_ban + ' ' + c.so)).join(' · ')}</p>
<p><b>Vi phạm thì:</b> ${thoat(d.viPhamThi)}</p></details>`).join('');

  const vn = banHp.nguonPhapLy.vietNam.map((x) => `<li>${thoat(x)}</li>`).join('');
  const qt = banHp.nguonPhapLy.quocTe.map((x) => `<li>${thoat(x)}</li>`).join('');

  const than = moDau('Hiến pháp', banHp.soDieu + ' điều ràng buộc toàn hệ thống',
    'Khẩu hiệu nói "chúng tôi tôn trọng quyền riêng tư". Hiến pháp nói điều đó '
    + 'theo văn bản nào, và vi phạm thì chuyện gì xảy ra.')
    + khoi('Toàn văn ' + banHp.soDieu + ' điều', null, dieu)
    + khoi('Căn cứ pháp lý',
      banHp.nguonPhapLy.vietNam.length + ' văn bản Việt Nam và '
      + banHp.nguonPhapLy.quocTe.length + ' văn bản quốc tế.',
      `<div class="o">
<div class="the"><h3>Việt Nam</h3><ul class="ds-kiem">${vn}</ul></div>
<div class="the"><h3>Quốc tế</h3><ul class="ds-kiem">${qt}</ul></div>
</div>
<p class="nguon">${thoat(banHp.luuY)}</p>`);

  return voTrang({
    tieuDe: 'Hiến pháp vận hành · GITAV20nexus',
    moTa: banHp.soDieu + ' điều ràng buộc mọi trợ lý và mọi đường API, mỗi điều dẫn '
      + 'văn bản pháp lý Việt Nam hoặc quốc tế.',
    dangO: '/quan-tri.html', than, ngayDung,
  });
}

// ═══════════════════════════════════════════════════════════════════════════
//  KHO BÀI
// ═══════════════════════════════════════════════════════════════════════════

function trangKhoBai({ ngayDung, soBai, soChuyenDe, dichBai, dichChuyenDe, theoDang }) {
  const luat = `<div class="o">
${the('Băm nội dung là chỉ mục duy nhất', 'Một đề bài đã có trong kho thì không vào được lần thứ hai — kể cả khi đổi khoảng trắng hay hoa thường.')}
${the('Không khai nguồn thì không vào', 'Sách nào, đề năm nào, hay ai soạn. Điều 11 của hiến pháp vận hành.')}
${the('Không tự thẩm định bài mình', 'Bài do ai soạn thì người khác soát. Luật nằm ở tầng mã.')}
${the('Chưa thẩm định thì chưa xuất bản', 'Ba trạng thái: nháp, đã soát, đã xuất bản. Không có đường tắt giữa chúng.')}
</div>`;

  const dang = theoDang.length
    ? bang(['Dạng câu hỏi', 'Số bài'], theoDang.map((d) => [thoat(d.dang), so(d.so)]))
    : '<p class="phu">Kho chưa có bài nào nên chưa có gì để chia theo dạng.</p>';

  const than = moDau('Kho bài', 'Kho bài tập và chuyên đề',
    'Đích của hệ thống: ' + so(dichBai) + ' bài và ' + so(dichChuyenDe)
    + ' chuyên đề phủ toàn bộ chương trình.')
    + khoi('Đang có bao nhiêu — số thật',
      'Con số dưới đây đếm trực tiếp từ kho lúc dựng trang.',
      `<div class="o">
${the(so(soBai) + ' / ' + so(dichBai) + ' bài', soBai === 0
    ? 'Kho đang trống. Con số ' + so(dichBai) + ' là ĐÍCH, không phải số đang có.'
    : 'Đã đạt ' + (soBai / dichBai * 100).toFixed(2) + '% của đích.')}
${the(so(soChuyenDe) + ' / ' + so(dichChuyenDe) + ' chuyên đề', soChuyenDe === 0
    ? 'Chưa có chuyên đề nào được soạn.'
    : 'Đã đạt ' + (soChuyenDe / dichChuyenDe * 100).toFixed(2) + '% của đích.')}
</div>
<p class="nguon">Bài vào kho bằng quy trình soạn và thẩm định, không bằng một lệnh sinh hàng loạt.
Một kho đầy bài do máy tự đẻ ra là một kho không dùng được.</p>`)
    + khoi('Bốn luật giữ chất lượng kho', null, luat)
    + khoi('Chia theo dạng câu hỏi', null, dang);

  return voTrang({
    tieuDe: 'Kho bài tập và chuyên đề · GITAV20nexus',
    moTa: 'Kho bài tập với luật chống trùng bằng băm nội dung, bắt buộc khai nguồn, '
      + 'và quy trình thẩm định trước khi xuất bản.',
    dangO: '/chuong-trinh.html', than, ngayDung,
  });
}

// ═══════════════════════════════════════════════════════════════════════════
//  TÀI CHÍNH KẾ TOÁN
// ═══════════════════════════════════════════════════════════════════════════

function trangTaiChinh({ ngayDung, taiKhoan }) {
  const theoLoai = {};
  for (const t of taiKhoan) (theoLoai[t.loai] = theoLoai[t.loai] || []).push(t);
  const TEN_LOAI = { 'tai-san': 'Tài sản', 'no-phai-tra': 'Nợ phải trả',
    'von-chu-so-huu': 'Vốn chủ sở hữu', 'doanh-thu': 'Doanh thu',
    'chi-phi': 'Chi phí', khac: 'Khác' };

  const nhom = Object.entries(theoLoai).map(([l, ds]) =>
    `<details><summary>${thoat(TEN_LOAI[l] || l)} — ${so(ds.length)} tài khoản</summary>
${bang(['Số hiệu', 'Tên tài khoản', 'Dư thường', 'Thông tư'],
    ds.map((t) => [`<b>${thoat(t.so)}</b>`, thoat(t.ten), thoat(t.du_thuong), thoat(t.thong_tu)]))}
</details>`).join('');

  const than = moDau('Tài chính', 'Kế toán ghi sổ kép',
    'Hệ thống tài khoản theo Thông tư 200/2014/TT-BTC và Thông tư 133/2016/TT-BTC. '
    + so(taiKhoan.length) + ' tài khoản cấp một.')
    + khoi('Vì sao ghi sổ kép chứ không phải một bảng thu chi',
      'Một bảng thu chi không bao giờ tự phát hiện được sai.',
      `<div class="o">
${the('Nợ phải bằng Có', 'Trong từng chứng từ. Lệch một đồng là chứng từ không ghi sổ được.')}
${the('Tiền là số nguyên đồng', 'Không dùng số thực cho tiền: 0,1 + 0,2 trong số thực nhị phân không bằng 0,3.')}
${the('Đã ghi sổ thì không sửa', 'Sai thì ghi bút toán đảo, nêu lý do, và sổ giữ cả hai. Điều 9.')}
${the('Người lập không tự ghi sổ', 'Luôn phải có mắt thứ hai trước khi một con số vào sổ.')}
${the('Kỳ lệch thì không khoá', 'Không khoá được một kỳ còn chênh Nợ–Có. Phải tìm ra trước.')}
${the('Kỳ đã khoá thì không ghi thêm', 'Ghi vào kỳ đã khoá là sửa lại quá khứ.')}
</div>`)
    + khoi('Hệ thống tài khoản', 'Bấm từng nhóm để xem đủ.', nhom)
    + khoi('Trang làm việc riêng',
      'Giao diện kế toán tự dựng, không dùng phần mềm ngoài — nên mọi ràng buộc ở trên '
      + 'được giữ ngay trong lúc nhập, chứ không phải kiểm lại sau.',
      '<div class="hang-nut"><a class="nut" href="/ui/ke-toan.html">Mở trang kế toán</a>'
      + '<a class="nut phu" href="/ui/crm.html">Mở trang quan hệ gia đình</a></div>');

  return voTrang({
    tieuDe: 'Tài chính kế toán ghi sổ kép · GITAV20nexus',
    moTa: 'Kế toán ghi sổ kép theo Thông tư 200 và 133, tiền là số nguyên đồng, '
      + 'chứng từ đã ghi sổ không sửa không xoá.',
    dangO: '/quan-tri.html', than, ngayDung,
  });
}

module.exports = {
  trangMon, trangKyThi, trangTrai, trangDoNangLuc, trangLoTrinh,
  trangBoMay, trangHienPhap, trangKhoBai, trangTaiChinh,
  moDau, bang, the, khoi, so,
};
