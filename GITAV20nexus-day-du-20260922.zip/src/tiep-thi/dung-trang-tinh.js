'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  DỰNG TRANG TĨNH CHO CLOUDFLARE PAGES
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  ── NÓI THẲNG ĐIỀU GÌ CHẠY ĐƯỢC TRÊN CLOUDFLARE VÀ ĐIỀU GÌ KHÔNG ────────
 *
 *  Cloudflare Pages phục vụ TỆP TĨNH. Nó không chạy một tiến trình Node lâu
 *  dài, không có hệ tệp ghi được, không giữ trạng thái giữa hai yêu cầu.
 *  GITAV20nexus thì ngược lại: một máy chủ Node chạy liên tục, ghi xuống
 *  đĩa, giữ 500 trợ lý trong bộ nhớ, dựng video vào thư mục.
 *
 *  Nên nói cho rõ, vì đây là chỗ dễ hứa quá tay nhất:
 *
 *      LÊN ĐƯỢC Cloudflare Pages:
 *        · Toàn bộ trang giới thiệu — dựng sẵn thành HTML lúc build, số liệu
 *          đóng băng tại thời điểm dựng, không gọi API nào
 *        · Sơ đồ tư duy ba chiều dạng ảnh SVG tĩnh
 *        · Kịch bản lời đọc của 36 video hướng dẫn
 *        · Mọi tệp giao diện
 *
 *      KHÔNG LÊN ĐƯỢC, cần máy chủ Node thật:
 *        · Đăng nhập, tài khoản, phiên
 *        · Trợ lý trò chuyện (đọc dữ liệu học viên thật)
 *        · Dựng video, dựng bài giảng
 *        · Mọi thứ ghi xuống đĩa
 *
 *  Cách nối hai phần: Cloudflare phục vụ phần tĩnh; phần động trỏ về máy chủ
 *  Node qua một tên miền con, và Cloudflare Tunnel đưa máy chủ ấy ra mà không
 *  cần mở cổng. Tệp _redirects dựng sẵn đúng đường ấy.
 *
 *  ── SỐ LIỆU ĐÓNG BĂNG, VÀ NÓI RA NGÀY ĐÓNG BĂNG ─────────────────────────
 *
 *  Trang tĩnh mang số liệu của lúc dựng. Nên mỗi trang in rõ ngày dựng. Một
 *  con số không ghi ngày là một con số không kiểm lại được.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const xuong = require('./xuong-noi-dung');
const luat = require('./luat-noi-dung');

const thoat = (s) => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

/**
 * Chính sách nội dung. Chặt hết mức trang này chịu được: không kịch bản, không
 * khung nhúng, không gửi biểu mẫu đi đâu.
 *
 * `script-src 'none'` là một ràng buộc THIẾT KẾ, không phải một hạn chế phải
 * chịu đựng: mọi thứ tương tác trên các trang này phải làm được bằng HTML và
 * CSS thuần. Thẻ <details> lo phần đóng mở; :target lo phần nhảy mục. Không
 * dòng JavaScript nào, nên không có gì để hỏng và không có gì để tấn công.
 */
const CSP = [
  "default-src 'self'",
  "script-src 'none'",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data:",
  "font-src 'self'",
  "connect-src 'self'",
  "frame-ancestors 'none'",
  "form-action 'none'",
  "base-uri 'none'",
  "object-src 'none'",
].join('; ');

/** Lối đi chính. Thứ tự này là thứ tự người mới vào cần đi. */
const LOI_DI = [
  ['/', 'Trang chủ'],
  ['/he-thong.html', 'Hệ thống'],
  ['/hanh-trinh-hoc.html', 'Hành trình học'],
  ['/chuong-trinh.html', 'Chương trình'],
  ['/luyen-thi.html', 'Luyện thi'],
  ['/ho-so.html', 'Hồ sơ'],
  ['/quan-tri.html', 'Quản trị'],
  ['/muc-luc.html', 'Mục lục'],
  ['/ui/cong.html', 'Đăng nhập'],
];

/**
 * Dấu hiệu nhận diện. Vẽ bằng SVG nội tuyến chứ không nhúng tệp ảnh: một dấu
 * hiệu phải hiện ra cùng lúc với chữ, không phải sau một lượt tải thứ hai.
 */
function dauHieu(co = 34) {
  return `<svg class="dh" width="${co}" height="${co}" viewBox="0 0 40 40" aria-hidden="true">
  <defs><linearGradient id="g1" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="#1667d1"/><stop offset="1" stop-color="#5b3ee8"/>
  </linearGradient></defs>
  <rect width="40" height="40" rx="10" fill="url(#g1)"/>
  <path d="M12 11h16v3.2H17.6l6.1 6.1-6.1 6.1H28V29H12v-3l7-7-7-7z" fill="#fff"/>
</svg>`;
}

function kieuChu() {
  return `
:root{
  --nen:#f4f7fc; --nen2:#eaf0fa; --the:#ffffff; --chu:#16203a; --nhat:#5b6b8c;
  --vien:#dfe6f3; --nhan:#1667d1; --nhan2:#5b3ee8; --xanh:#0f9d6b; --vang:#c8890a;
  --bong:0 1px 2px rgba(22,32,58,.06), 0 8px 24px -12px rgba(22,32,58,.18);
  --bong2:0 2px 4px rgba(22,32,58,.08), 0 18px 40px -18px rgba(22,32,58,.28);
}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){
  --nen:#0b1020; --nen2:#121a33; --the:#161f3d; --chu:#e6ecff; --nhat:#8fa0c8;
  --vien:#25335c; --nhan:#4da3ff; --nhan2:#7c5cff; --xanh:#3ddc97; --vang:#f5c542;
  --bong:0 1px 2px rgba(0,0,0,.4), 0 8px 24px -12px rgba(0,0,0,.6);
  --bong2:0 2px 4px rgba(0,0,0,.5), 0 18px 40px -18px rgba(0,0,0,.7);
}}
:root[data-theme="dark"]{--nen:#0b1020;--nen2:#121a33;--the:#161f3d;--chu:#e6ecff;--nhat:#8fa0c8;--vien:#25335c;--nhan:#4da3ff;--nhan2:#7c5cff;--xanh:#3ddc97;--vang:#f5c542}

*,*::before,*::after{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:var(--nen);color:var(--chu);
  font:16px/1.65 system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",sans-serif;
  -webkit-font-smoothing:antialiased}
a{color:var(--nhan)}
:focus-visible{outline:3px solid var(--nhan2);outline-offset:2px;border-radius:4px}

/* ── Đầu trang ── */
.dau{position:sticky;top:0;z-index:50;background:color-mix(in srgb,var(--nen) 88%,transparent);
  backdrop-filter:saturate(1.6) blur(10px);border-bottom:1px solid var(--vien)}
.dau-in{max-width:1120px;margin:0 auto;padding:11px 20px;display:flex;align-items:center;gap:18px;flex-wrap:wrap}
.hieu{display:flex;align-items:center;gap:10px;text-decoration:none;color:inherit;font-weight:800;font-size:17px;letter-spacing:-.01em}
.hieu .dh{flex:0 0 auto;border-radius:10px}
.hieu small{display:block;font-weight:500;font-size:11.5px;color:var(--nhat);letter-spacing:0}
.loidi{display:flex;gap:2px;flex-wrap:wrap;margin-left:auto}
.loidi a,.loidi span{font-size:13.5px;text-decoration:none;border-radius:8px;padding:7px 11px;color:var(--nhat);white-space:nowrap}
.loidi a:hover{background:var(--nen2);color:var(--chu)}
.loidi span[aria-current]{background:var(--nhan);color:#fff;font-weight:650}
.loidi a.noibat{background:linear-gradient(135deg,var(--nhan),var(--nhan2));color:#fff;font-weight:650}

/* ── Bố cục ── */
.khung{max-width:1120px;margin:0 auto;padding:0 20px}
.hep{max-width:820px}
main{padding-bottom:80px}
section{padding:46px 0;border-top:1px solid var(--vien)}
section:first-of-type{border-top:0}
h1{font-size:clamp(30px,4.6vw,46px);line-height:1.12;margin:0 0 14px;letter-spacing:-.025em;font-weight:820}
h2{font-size:clamp(21px,2.6vw,27px);line-height:1.25;margin:0 0 8px;letter-spacing:-.015em;font-weight:760}
h3{font-size:16.5px;margin:0 0 5px;font-weight:700;letter-spacing:-.005em}
p{margin:0 0 13px;max-width:70ch}
.phu{color:var(--nhat)}
.nho{font-size:13px;color:var(--nhat)}
.rat-nho{font-size:11.5px;color:var(--nhat);line-height:1.5}
.nhan-muc{display:inline-block;font-size:11.5px;font-weight:750;letter-spacing:.07em;text-transform:uppercase;
  color:var(--nhan);background:color-mix(in srgb,var(--nhan) 12%,transparent);
  border-radius:20px;padding:4px 11px;margin-bottom:11px}

/* ── Mở đầu ── */
.modau{padding:56px 0 40px}
.modau-lien{display:grid;grid-template-columns:1.05fr .95fr;gap:38px;align-items:center}
@media(max-width:900px){.modau-lien{grid-template-columns:1fr;gap:26px}}
.modau h1 span{background:linear-gradient(120deg,var(--nhan),var(--nhan2));-webkit-background-clip:text;background-clip:text;color:transparent}
.modau p{font-size:17.5px}
.hinh-modau{background:var(--the);border:1px solid var(--vien);border-radius:16px;padding:12px;box-shadow:var(--bong2)}
.hinh-modau svg{display:block;width:100%;height:auto;border-radius:9px}

/* ── Nút ── */
.hang-nut{display:flex;gap:10px;flex-wrap:wrap;margin-top:20px}
.nut{display:inline-flex;align-items:center;gap:7px;text-decoration:none;font-weight:700;font-size:14.5px;
  border-radius:11px;padding:12px 21px;background:linear-gradient(135deg,var(--nhan),var(--nhan2));color:#fff;
  box-shadow:var(--bong);border:1px solid transparent}
.nut:hover{filter:brightness(1.07)}
.nut.phu{background:var(--the);color:var(--chu);border-color:var(--vien)}
.nut.phu:hover{border-color:var(--nhan);color:var(--nhan);filter:none}

/* ── Dải số ── */
.dai-so{display:grid;grid-template-columns:repeat(3,1fr);gap:1px;
  background:var(--vien);border:1px solid var(--vien);border-radius:14px;overflow:hidden;margin-top:26px}
.dai-so div{background:var(--the);padding:16px 15px}
.dai-so b{display:block;font-size:27px;font-weight:820;letter-spacing:-.02em;line-height:1.1}
.dai-so span{display:block;font-size:12.5px;color:var(--nhat);margin-top:3px}
@media(min-width:1000px){.dai-so.sau{grid-template-columns:repeat(3,1fr)}}
@media(max-width:520px){.dai-so{grid-template-columns:repeat(2,1fr)}}

/* ── Thẻ ── */
.o{display:grid;grid-template-columns:repeat(auto-fit,minmax(248px,1fr));gap:14px;margin-top:18px}
.the{background:var(--the);border:1px solid var(--vien);border-radius:14px;padding:18px 19px;box-shadow:var(--bong)}
a.the{text-decoration:none;color:inherit;display:block;transition:transform .16s,box-shadow .16s,border-color .16s}
a.the:hover{transform:translateY(-2px);box-shadow:var(--bong2);border-color:var(--nhan)}
.the .bieu{font-size:21px;line-height:1;margin-bottom:9px;display:block}
.the p{font-size:13.5px;color:var(--nhat);margin:0}
.the .vai{display:inline-block;font-size:11px;font-weight:700;border-radius:6px;padding:2px 7px;margin-top:9px;
  background:var(--nen2);color:var(--nhat)}

/* ── Danh sách kiểm ── */
.ds-kiem{list-style:none;padding:0;margin:8px 0 0;display:grid;gap:9px}
.ds-kiem li{display:flex;gap:10px;align-items:flex-start;font-size:14.5px}
.ds-kiem li::before{content:"✓";flex:0 0 20px;height:20px;border-radius:6px;display:grid;place-items:center;
  background:color-mix(in srgb,var(--xanh) 16%,transparent);color:var(--xanh);font-size:12px;font-weight:800;margin-top:2px}

/* ── Bảng ── */
.bang-ngoai{overflow-x:auto;border:1px solid var(--vien);border-radius:14px;background:var(--the);box-shadow:var(--bong)}
table{border-collapse:collapse;width:100%;font-size:13.5px;min-width:560px}
th,td{text-align:left;padding:11px 14px;border-bottom:1px solid var(--vien);vertical-align:top}
thead th{background:var(--nen2);font-weight:700;font-size:12.5px;color:var(--nhat);
  text-transform:uppercase;letter-spacing:.05em;position:sticky;top:0}
tbody tr:last-child td{border-bottom:0}
td b{font-weight:700}
.dau-cham{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:7px;vertical-align:baseline}

/* ── Hỏi đáp ── */
details{background:var(--the);border:1px solid var(--vien);border-radius:12px;margin-bottom:9px;box-shadow:var(--bong)}
summary{cursor:pointer;padding:14px 18px;font-weight:650;font-size:15px;list-style:none;display:flex;gap:10px;align-items:center}
summary::-webkit-details-marker{display:none}
summary::before{content:"+";flex:0 0 19px;height:19px;border-radius:5px;display:grid;place-items:center;
  background:var(--nen2);color:var(--nhan);font-weight:800;font-size:14px}
details[open] summary::before{content:"−"}
details p{padding:0 18px 15px;margin:0;font-size:14px;color:var(--nhat)}

/* ── Nguồn số ── */
.nguon{font-size:11.5px;color:var(--nhat);margin-top:11px;padding-top:9px;border-top:1px dashed var(--vien)}

/* ── Chân trang ── */
.chan{border-top:1px solid var(--vien);background:var(--nen2);padding:30px 0 40px;margin-top:20px}
.chan-in{max-width:1120px;margin:0 auto;padding:0 20px;display:grid;grid-template-columns:1.3fr 1fr 1fr 1fr;gap:26px}
@media(max-width:980px){.chan-in{grid-template-columns:1fr 1fr}}
@media(max-width:600px){.chan-in{grid-template-columns:1fr}}
.chan h4{font-size:12px;text-transform:uppercase;letter-spacing:.07em;color:var(--nhat);margin:0 0 9px;font-weight:750}
.chan ul{list-style:none;padding:0;margin:0;display:grid;gap:6px}
.chan a{font-size:13.5px;text-decoration:none;color:var(--nhat)}
.chan a:hover{color:var(--nhan)}
@media(max-width:600px){.khung{padding:0 16px}section{padding:34px 0}.modau{padding:34px 0 26px}}
@media(prefers-reduced-motion:reduce){*{transition:none!important;scroll-behavior:auto!important}}
`;
}

/** Vỏ trang dùng chung — đầu, thân, chân. */
function voTrang({ tieuDe, moTa, dangO, than, ngayDung }) {
  const loidi = LOI_DI.map(([d, t]) => (d === dangO
    ? `<span aria-current="page">${thoat(t)}</span>`
    : `<a href="${thoat(d)}"${d === '/ui/cong.html' ? ' class="noibat"' : ''}>${thoat(t)}</a>`)).join('');
  return `<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${thoat(tieuDe)}</title>
<meta name="description" content="${thoat(moTa)}">
<meta name="color-scheme" content="light dark">
<link rel="icon" href="/ui/icon.png">
<style>${kieuChu()}</style>
</head>
<body>
<header class="dau"><div class="dau-in">
  <a class="hieu" href="/">${dauHieu(32)}<span>GITA<small>Học viện GITA</small></span></a>
  <nav class="loidi" aria-label="Lối đi chính">${loidi}</nav>
</div></header>
<main>${than}</main>
<footer class="chan"><div class="chan-in">
  <div>
    <a class="hieu" href="/" style="margin-bottom:9px">${dauHieu(28)}<span>GITA</span></a>
    <p class="rat-nho" style="max-width:34ch">Trang công khai dựng sẵn thành tệp tĩnh. Mọi con số đọc từ hệ thống đang chạy lúc dựng — ${thoat(ngayDung)}.</p>
  </div>
  <div><h4>Học</h4><ul>
    <li><a href="/he-thong.html">Giới thiệu toàn hệ</a></li>
    <li><a href="/chuong-trinh.html">Chương trình học</a></li>
    <li><a href="/mon-toan.html">Toán lớp 1–12</a></li>
    <li><a href="/mon-tieng-anh.html">Tiếng Anh lớp 1–12</a></li>
    <li><a href="/mon-ngu-van.html">Ngữ văn lớp 1–12</a></li>
    <li><a href="/kho-bai.html">Kho bài tập và chuyên đề</a></li>
    <li><a href="/so-do.html">Sơ đồ chương trình</a></li>
    <li><a href="/video-huong-dan.html">Video hướng dẫn</a></li>
  </ul></div>
  <div><h4>Luyện thi và rèn luyện</h4><ul>
    <li><a href="/luyen-thi.html">So sánh sáu hệ chuẩn</a></li>
    <li><a href="/thi-hsa.html">HSA 1300</a></li>
    <li><a href="/thi-tsa.html">TSA 100</a></li>
    <li><a href="/thi-spt.html">SPT 1200</a></li>
    <li><a href="/thi-ielts.html">IELTS 9.0</a></li>
    <li><a href="/thi-sat.html">SAT 1600</a></li>
    <li><a href="/thi-toeic.html">TOEIC 990</a></li>
    <li><a href="/trai-gel-alpha.html">Trại Gel Alpha</a></li>
    <li><a href="/trai-leader-boom.html">Trại Leader Boom</a></li>
    <li><a href="/trai-hoc-gioi.html">Kỹ năng học giỏi</a></li>
  </ul></div>
  <div><h4>Cá nhân và hệ thống</h4><ul>
    <li><a href="/ui/cong.html">Đăng nhập</a></li>
    <li><a href="/ui/bang-tong.html">Bảng quản trị tổng</a></li>
    <li><a href="/hanh-trinh-hoc.html">Hành trình học</a></li>
    <li><a href="/lo-trinh-ca-nhan.html">Lộ trình cá nhân hoá</a></li>
    <li><a href="/do-nang-luc.html">Đo năng lực và tính cách</a></li>
    <li><a href="/ho-so.html">Hồ sơ học viên và gia đình</a></li>
    <li><a href="/ui/crm.html">Quan hệ gia đình</a></li>
    <li><a href="/tai-chinh.html">Tài chính kế toán</a></li>
    <li><a href="/ui/ke-toan.html">Trang kế toán</a></li>
    <li><a href="/bo-may.html">Bộ máy 600 trợ lý</a></li>
    <li><a href="/hien-phap.html">Hiến pháp vận hành</a></li>
    <li><a href="/quan-tri.html">Hệ thống quản trị</a></li>
    <li><a href="/phan-quyen.html">Phân quyền tài khoản</a></li>
    <li><a href="/muc-luc.html">Mục lục toàn trang</a></li>
    <li><a href="/huong-dan.html">Hướng dẫn triển khai</a></li>
  </ul></div>
</div></footer>
</body>
</html>`;
}

// ═══════════════════════════════════════════════════════════════════════════
//  CÁC TRANG
// ═══════════════════════════════════════════════════════════════════════════

/** Một mảng nội dung do xưởng soạn ra, vẽ thành khối HTML. */
function veMang(m) {
  const c = m.chu;
  let t = '';
  if (c.tieu) t += `<h2>${thoat(c.tieu)}</h2>`;
  if (c.phu) t += `<p class="phu">${thoat(c.phu)}</p>`;
  if (c.y) t += `<ul class="ds-kiem">${c.y.map((x) => `<li>${thoat(x)}</li>`).join('')}</ul>`;
  if (c.muc) {
    t += `<div class="o">${c.muc.map((x) => `<div class="the"><h3>${thoat(x.ten)}</h3><p>${thoat(x.y)}</p></div>`).join('')}</div>`;
  }
  if (c.buoc) {
    t += `<div class="o">${c.buoc.map((x, i) => `<div class="the"><span class="bieu">${i + 1}</span><p>${thoat(x)}</p></div>`).join('')}</div>`;
  }
  if (c.hoi) t += c.hoi.map((x) => `<details><summary>${thoat(x.h)}</summary><p>${thoat(x.d)}</p></details>`).join('');
  if (c.nut) t += `<div class="hang-nut"><a class="nut" href="/chuong-trinh.html">${thoat(c.nut)}</a>`
    + '<a class="nut phu" href="/ui/cong.html">Đăng nhập vào hệ thống</a></div>';
  const ng = (m.nguonSo || []).map((n) => `${n.so} = ${n.giaTri} · ${n.nguon}`).join('  |  ');
  if (ng) t += `<p class="nguon">Nguồn số liệu: ${thoat(ng)}</p>`;
  return `<section class="khung"><div class="hep">${t}</div></section>`;
}

/** Trang chủ. */
function trangChu(trang, { ngayDung, banSvg = null, tieuDe = null, moTa = null, dangO = '/' }) {
  const so = trang.soLieu;
  const tieu = tieuDe || 'GITA — Học toán theo đúng thứ tự kiến thức';
  const mo = moTa || `Chương trình ${so.soDang} dạng toán xếp theo ${so.soTang} tầng, `
    + `cùng ${so.soChuan || ''} chuẩn luyện thi đánh giá năng lực và quốc tế.`;

  const dauMang = trang.mang[0];
  const conLai = trang.mang.slice(1);

  const daiSo = [
    [so.soDang, 'dạng toán'],
    [so.soTang, 'tầng học'],
    [so.soKiemDinh, 'bài đã thẩm định'],
    [so.soBay, 'bẫy sai đã ghi'],
    [so.soChuan, 'chuẩn luyện thi'],
    [so.soTroLy, 'trợ lý chuyên môn'],
  ].filter(([v]) => v != null);

  const than = `
<section class="khung modau">
  <div class="modau-lien">
    <div>
      <span class="nhan-muc">Học viện GITA · bản ${thoat(so.phienBan || '')}</span>
      <h1>Học toán theo <span>đúng thứ tự</span> kiến thức</h1>
      <p class="phu">${thoat((dauMang && dauMang.chu.phu) || '')}</p>
      <div class="hang-nut">
        <a class="nut" href="/ui/cong.html">Vào hệ thống</a>
        <a class="nut phu" href="/chuong-trinh.html">Xem chương trình</a>
      </div>
      <div class="dai-so">${daiSo.map(([v, t]) => `<div><b>${thoat(String(v))}</b><span>${thoat(t)}</span></div>`).join('')}</div>
    </div>
    ${banSvg ? `<div class="hinh-modau">${banSvg}<p class="rat-nho" style="margin:9px 4px 2px">Mỗi chấm là một dạng toán có thật; mỗi đường là một quan hệ “cần biết trước” đã khai.</p></div>` : ''}
  </div>
</section>

<section class="khung"><div class="hep">
  <span class="nhan-muc">Bắt đầu ở đâu</span>
  <h2>Bảy lối vào</h2>
  <p class="phu">Mỗi lối dẫn tới một phần khác nhau của hệ thống.</p>
</div>
<div class="o">
  ${[
    ['/muc-luc.html', '☰', 'Mục lục toàn trang', 'Toàn bộ trang và màn hình của hệ thống, xếp theo nhóm.'],
    ['/chuong-trinh.html', '◈', 'Chương trình học', 'Năm khối từ tiểu học tới chuẩn quốc tế.'],
    ['/luyen-thi.html', '◎', 'Luyện thi', 'Thang điểm và cấu trúc thật của từng chuẩn.'],
    ['/so-do.html', '◉', 'Sơ đồ ba chiều', 'Cả chương trình trải trong không gian, xoay được.'],
    ['/phan-quyen.html', '⚿', 'Phân quyền', 'Năm vai, bốn mức quyền, cổng nào mở cho ai.'],
    ['/video-huong-dan.html', '▶', 'Video hướng dẫn', 'Mỗi màn hình một video riêng cho từng vai.'],
    ['/ui/cong.html', '→', 'Đăng nhập', 'Vào góc học tập, phòng giáo viên hoặc trung tâm chỉ huy.'],
  ].map(([d, b, t, m]) => `<a class="the" href="${d}"><span class="bieu">${b}</span><h3>${thoat(t)}</h3><p>${thoat(m)}</p></a>`).join('')}
</div>
</section>

${conLai.map(veMang).join('\n')}`;

  return voTrang({ tieuDe: tieu, moTa: mo, dangO, than, ngayDung });
}

/** Mục lục — trang tổng, liệt kê mọi thứ có trong hệ thống. */
function trangMucLuc({ ngayDung, man = [], soLieu = {} }) {
  const nhom = [
    ['Trang công khai', 'Ai cũng xem được, không cần đăng nhập', [
      ['/', 'Trang chủ', 'Giới thiệu và số liệu thật của hệ thống'],
      ['/he-thong.html', 'Giới thiệu toàn hệ', 'GITAV20nexus là gì — mười phần, một hệ'],
      ['/hanh-trinh-hoc.html', 'Hành trình học', 'Chẩn đoán đầu vào, lộ trình cá nhân, luyện tập, chu kỳ 90 ngày'],
      ['/ho-so.html', 'Hồ sơ học viên và gia đình', 'Chân dung, dấu vết luyện tập, quản lý quan hệ gia đình'],
      ['/quan-tri.html', 'Hệ thống quản trị', 'Két 15 tầng, lực lượng trợ lý, hiến pháp, nhật ký bất biến'],
      ['/muc-luc.html', 'Mục lục', 'Chính trang này'],
      ['/chuong-trinh.html', 'Chương trình học', `Năm khối, ${soLieu.soDang || ''} dạng toán, tiếng Anh, liên môn`],
      ['/luyen-thi.html', 'Luyện thi', 'Các chuẩn đánh giá năng lực và chuẩn quốc tế'],
      ['/so-do.html', 'Sơ đồ chương trình', 'Ảnh tĩnh, năm góc nhìn, in ra giấy được'],
      ['/video-huong-dan.html', 'Video hướng dẫn', 'Danh mục 40 video theo vai'],
      ['/phan-quyen.html', 'Phân quyền tài khoản', 'Vai tài khoản, mức quyền, và cổng nào mở cho ai'],
      ['/huong-dan.html', 'Hướng dẫn triển khai', 'Đưa hệ thống lên Cloudflare'],
      ['/ban-ke.json', 'Bản kê toàn gói', 'Đếm lại sau khi tải lên'],
    ]],
    ['Màn hình của hệ thống', 'Mở ra được ngay; phần dữ liệu cần máy chủ và tài khoản', man.map((m) => [m.duong, m.ten, m.de])],
    ['Tải về', 'Tệp dùng ngoài trình duyệt', [
      ['/so-do/toan-canh-thang.svg', 'Sơ đồ — góc nhìn thẳng', 'Ảnh vector, in khổ lớn không vỡ'],
      ['/so-do/toan-canh-nghieng.svg', 'Sơ đồ — góc nghiêng', 'Thấy rõ chiều sâu các tầng'],
      ['/so-do/toan-canh-nen-sang.svg', 'Sơ đồ — nền sáng', 'Nhúng vào tài liệu nền trắng'],
      ['/so-do-chuong-trinh.svg', 'Sơ đồ khổ lớn', '1100×720, nền tối'],
    ]],
  ];

  const than = `
<section class="khung modau" style="padding-bottom:26px"><div class="hep">
  <span class="nhan-muc">Trang tổng</span>
  <h1>Mục lục</h1>
  <p class="phu">Mọi trang và mọi màn hình của hệ thống, xếp theo nhóm. Dựng ngày ${thoat(ngayDung)}.</p>
</div></section>
${nhom.map(([ten, mo, ds]) => `
<section class="khung">
  <div class="hep"><h2>${thoat(ten)}</h2><p class="phu">${thoat(mo)}</p></div>
  <div class="o">${ds.map(([d, t, m]) => `<a class="the" href="${thoat(d)}"><h3>${thoat(t)}</h3><p>${thoat(m)}</p><span class="vai">${thoat(d)}</span></a>`).join('')}</div>
</section>`).join('')}`;

  return voTrang({
    tieuDe: 'GITA — Mục lục toàn trang',
    moTa: 'Toàn bộ trang công khai và màn hình của hệ thống GITAV20nexus, xếp theo nhóm.',
    dangO: '/muc-luc.html', than, ngayDung,
  });
}

/** Chương trình học — năm khối, dựng từ dữ liệu thật. */
function trangChuongTrinh({ ngayDung, khoi = [], theoTienTo = {}, soLieu = {} }) {
  const MO_KHOI = {
    TIEU_HOC: 'Nền số và phép tính, hình phẳng cơ bản, đo lường.',
    THCS: 'Đại số, hình học chứng minh, hàm số bậc nhất và bậc hai.',
    THPT: 'Hàm số, tích phân, hình không gian toạ độ, xác suất.',
    LUYEN_THI_QG: 'Ba kỳ đánh giá năng lực trong nước, thi bằng máy.',
    QUOC_TE: 'Chuẩn quốc tế cho hồ sơ du học và học bổng.',
  };
  const TEN_TIEN_TO = { M: 'Toán', E: 'Tiếng Anh', X: 'Liên môn' };

  const than = `
<section class="khung modau" style="padding-bottom:22px"><div class="hep">
  <span class="nhan-muc">Chương trình</span>
  <h1>Năm khối, một đường đi liền mạch</h1>
  <p class="phu">Từ lớp một tới chuẩn quốc tế. Mỗi dạng chỉ mở ra khi những dạng cần biết trước đã học xong — không nhảy cóc.</p>
  <div class="dai-so">
    ${Object.entries(theoTienTo).map(([k, v]) => `<div><b>${v}</b><span>dạng ${thoat(TEN_TIEN_TO[k] || k)}</span></div>`).join('')}
    <div><b>${thoat(String(soLieu.soTang || ''))}</b><span>tầng học</span></div>
    <div><b>${thoat(String(soLieu.soQuanHe || ''))}</b><span>quan hệ tiên quyết</span></div>
  </div>
</div></section>

<section class="khung">
  <div class="hep"><h2>Năm khối</h2>
  <p class="phu">Khối là chặng đường; tầng là độ khó bên trong chặng. Một học viên đi theo tầng, không theo tuổi.</p></div>
  <div class="o">${khoi.map((b) => `<div class="the">
    <h3>${thoat(b.name)}</h3>
    <p>${thoat(MO_KHOI[b.id] || '')}</p>
    <span class="vai">${(b.grades || []).map(thoat).join(' · ')}</span>
  </div>`).join('')}</div>
</section>

<section class="khung"><div class="hep">
  <h2>Ba mảng nội dung</h2>
  <p class="phu">Ba mã đầu của một dạng cho biết nó thuộc mảng nào.</p>
</div>
<div class="o">
  <div class="the"><span class="bieu">∑</span><h3>Toán — ${thoat(String(theoTienTo.M || 0))} dạng</h3>
    <p>Mã bắt đầu bằng <b>M</b> kèm số lớp, ví dụ M8.GIAI.LAPPT. Mỗi dạng ghi sẵn những lỗi sai thường gặp.</p></div>
  <div class="the"><span class="bieu">A</span><h3>Tiếng Anh — ${thoat(String(theoTienTo.E || 0))} dạng</h3>
    <p>Mã bắt đầu bằng <b>E</b>. Gồm ngữ pháp, từ vựng, và bốn kỹ năng theo chuẩn IELTS.</p></div>
  <div class="the"><span class="bieu">◈</span><h3>Liên môn — ${thoat(String(theoTienTo.X || 0))} dạng</h3>
    <p>Mã bắt đầu bằng <b>X</b>. Dạng cần dùng cùng lúc kiến thức của nhiều môn.</p></div>
</div>
<div class="hep"><div class="hang-nut">
  <a class="nut" href="/so-do.html">Xem sơ đồ toàn chương trình</a>
  <a class="nut phu" href="/luyen-thi.html">Sang phần luyện thi</a>
</div></div>
</section>

<section class="khung"><div class="hep">
  <h2>Câu hỏi hay gặp về chương trình</h2>
  ${[
    ['Con tôi học lớp mấy thì vào tầng nào?',
      'Không xếp theo lớp. Hệ thống cho làm một lượt chẩn đoán rồi xếp theo chỗ đang đứng thật — có em lớp 8 còn hổng dạng lớp 6, và đó là chuyện bình thường.'],
    ['Bài tập do máy sinh ra à?',
      'Không. Các dạng do người biên soạn tay. Máy chỉ giúp chọn bài nào cho ai, vào lúc nào.'],
    ['Học xong một dạng thì sao biết là đã xong?',
      'Mỗi dạng có chuẩn riêng và một lượt kiểm ở cuối tầng. Chưa đạt thì quay lại đúng dạng còn hổng, không học lại từ đầu.'],
    ['Có học được tiếng Anh song song không?',
      'Được. Hai mảng đi độc lập, mỗi mảng có đường tiên quyết riêng.'],
  ].map(([h, d]) => `<details><summary>${thoat(h)}</summary><p>${thoat(d)}</p></details>`).join('')}
</div></section>`;

  return voTrang({
    tieuDe: 'GITA — Chương trình học',
    moTa: 'Năm khối từ tiểu học tới chuẩn quốc tế, với số dạng toán, tiếng Anh và liên môn có thật trong hệ thống.',
    dangO: '/chuong-trinh.html', than, ngayDung,
  });
}

/** Luyện thi — số liệu lấy thẳng từ bộ chuẩn của hệ, không nhập tay. */
function trangLuyenThi({ ngayDung, chuan = [] }) {
  const khoang = (a) => (Array.isArray(a) ? (a[0] === a[1] ? String(a[0]) : `${a[0]}–${a[1]}`) : String(a ?? '—'));
  // Bảng này phải phủ ĐỦ mọi mã môn có trong bộ chuẩn. Thiếu một mã thì mã
  // thô lọt ra trang công khai — bảng đối chiếu từng in "doc-hieu" và
  // "xa-hoi" cho người đọc xem, giữa một bảng toàn tiếng Việt.
  //
  // Mục soi dưới cuối tệp canh đúng chỗ này, nên thêm chuẩn mới mà quên dịch
  // tên môn thì bản dựng đỏ, không lặng lẽ in mã ra.
  const TEN_MON = {
    toan: 'Toán', 'ngu-van': 'Ngữ văn', 'khoa-hoc': 'Khoa học', 'tieng-anh': 'Tiếng Anh',
    'doc-hieu': 'Đọc hiểu', 'xa-hoi': 'Khoa học xã hội',
  };
  const monThieu = [...new Set(chuan.flatMap((c) => c.monChinh || []))].filter((m) => !TEN_MON[m]);

  const than = `
<section class="khung modau" style="padding-bottom:22px"><div class="hep">
  <span class="nhan-muc">Luyện thi</span>
  <h1>${thoat(String(chuan.length))} chuẩn, thang điểm thật</h1>
  <p class="phu">Các kỳ đánh giá năng lực trong nước và chuẩn quốc tế. Mỗi chuẩn khai đủ thang điểm, số câu, thời gian và các phần thi — không con số nào làm tròn cho đẹp.</p>
</div></section>

<section class="khung">
  <div class="o">${chuan.map((c) => `<div class="the">
    <span class="bieu">◎</span>
    <h3>${thoat(c.ngan || c.id)}</h3>
    <p>${thoat(String(c.ten || '').replace(/^[^—]*—\s*/, ''))}</p>
    <span class="vai">thang ${thoat(khoang(c.thang))} · ${thoat(khoang(c.tongCau))} câu · ${thoat(khoang(c.tongPhut))} phút</span>
  </div>`).join('')}</div>
</section>

<section class="khung"><div class="hep">
  <h2>Đối chiếu đầy đủ</h2>
  <p class="phu">Bảng này đọc thẳng từ bộ chuẩn trong hệ thống, không nhập tay.</p>
</div>
<div class="bang-ngoai"><table>
  <thead><tr><th>Chuẩn</th><th>Thang điểm</th><th>Số câu</th><th>Thời gian</th><th>Nấc</th><th>Môn chính</th></tr></thead>
  <tbody>${chuan.map((c) => `<tr>
    <td><b>${thoat(c.ngan || c.id)}</b></td>
    <td>${thoat(khoang(c.thang))}</td>
    <td>${thoat(khoang(c.tongCau))}</td>
    <td>${thoat(khoang(c.tongPhut))} phút</td>
    <td>${(c.nac || []).length}</td>
    <td>${(c.monChinh || []).map((m) => thoat(TEN_MON[m] || m)).join(' · ')}</td>
  </tr>`).join('')}</tbody>
</table></div>
</section>

${chuan.filter((c) => (c.phan || []).length).map((c) => `
<section class="khung"><div class="hep">
  <h2>${thoat(c.ngan || c.id)} — các phần thi</h2>
  <p class="phu">${thoat(c.ten || '')}</p>
  <ul class="ds-kiem">${(c.phan || []).map((p) => `<li>${thoat(typeof p === 'string' ? p : (p.ten || p.name || ''))}</li>`).join('')}</ul>
  ${(c.nac || []).length ? `<p class="nguon">Thang chia thành ${(c.nac || []).length} nấc, từ ${thoat(String((c.nac[0] || [])[0]))} tới ${thoat(String((c.nac[c.nac.length - 1] || [])[1]))}.</p>` : ''}
</div></section>`).join('')}

${monThieu.length ? `<section class="khung"><div class="hep"><p class="nguon">CHƯA DỊCH TÊN MÔN: ${monThieu.map(thoat).join(', ')}</p></div></section>` : ''}

<section class="khung"><div class="hep">
  <h2>Điều hệ thống không hứa</h2>
  <p>Không ai nói trước được một học viên sẽ đạt bao nhiêu điểm, và chúng tôi không nói. Điều hệ thống làm được là cho thấy đang đứng ở nấc nào trên thang thật của từng chuẩn, và còn hổng những dạng nào.</p>
  <div class="hang-nut"><a class="nut" href="/ui/cong.html">Làm một lượt chẩn đoán</a></div>
</div></section>`;

  return voTrang({
    tieuDe: `GITA — Luyện thi ${chuan.map((c) => (c.ngan || c.id).split(' ')[0]).join(', ')}`,
    moTa: `${chuan.length} chuẩn luyện thi với thang điểm, số câu, thời gian và cấu trúc phần thi lấy từ bộ chuẩn của hệ thống.`,
    dangO: '/luyen-thi.html', than, ngayDung,
  });
}

/** Phân quyền — bảng thật, đọc từ bảng vai và bảng cổng quyền của hệ. */
function trangPhanQuyen({ ngayDung, vai = [], mucTheoVai = {}, nhomCong = [], phanBo = {}, tongCong = 0 }) {
  const MAU_MUC = { 'cong-khai': '#0f9d6b', 'hoc-vien': '#1667d1', 'giao-vien': '#c8890a', 'quan-tri': '#c0392b' };
  const TEN_MUC = {
    'cong-khai': 'Công khai', 'hoc-vien': 'Học viên', 'giao-vien': 'Giáo viên', 'quan-tri': 'Quản trị',
  };
  const cham = (m) => `<span class="dau-cham" style="background:${MAU_MUC[m] || '#888'}"></span>`;

  const than = `
<section class="khung modau" style="padding-bottom:22px"><div class="hep">
  <span class="nhan-muc">Phân quyền</span>
  <h1>Năm vai, bốn mức, mặc định là ĐÓNG</h1>
  <p class="phu">Không phải mỗi cổng một luật riêng. Mỗi nhóm cổng khai một mức, mỗi vai với tới một mức — và nhóm nào quên khai thì rơi vào mức chặt nhất, không phải mức lỏng nhất.</p>
  <div class="dai-so">
    <div><b>${thoat(String(tongCong))}</b><span>cổng API</span></div>
    <div><b>${thoat(String(nhomCong.length))}</b><span>nhóm cổng</span></div>
    <div><b>${thoat(String(vai.length))}</b><span>vai tài khoản</span></div>
    <div><b>4</b><span>mức quyền</span></div>
  </div>
</div></section>

<section class="khung"><div class="hep">
  <h2>Năm vai</h2>
  <p class="phu">Thứ bậc quyết định vai nào với tới mức nào. Vai thấp không bao giờ chạm được cổng của vai cao.</p>
</div>
<div class="bang-ngoai"><table>
  <thead><tr><th>Vai</th><th>Thứ bậc</th><th>Với tới mức</th><th>Làm gì</th></tr></thead>
  <tbody>${vai.map((v) => {
    const m = mucTheoVai[v.id];
    return `<tr>
      <td><b>${thoat(v.name)}</b><br><span class="rat-nho">${thoat(v.id)}</span></td>
      <td>${thoat(String(v.rank))}</td>
      <td>${m ? cham(m) + thoat(TEN_MUC[m] || m) : '<span class="rat-nho">chỉ cổng công khai</span>'}</td>
      <td class="nho">${thoat(v.desc || '')}</td>
    </tr>`;
  }).join('')}</tbody>
</table></div>
<p class="nho" style="margin-top:12px">Super Admin là một lớp RIÊNG, không nằm trong bảng này: nó đi qua két bảo mật mười lăm tầng với mã một lần và chia sẻ bí mật, chứ không qua cổng tài khoản thường.</p>
</section>

<section class="khung"><div class="hep">
  <h2>Bốn mức quyền</h2>
  <p class="phu">Phân bố thật của ${thoat(String(tongCong))} cổng.</p>
</div>
<div class="o">${Object.entries(phanBo).map(([m, n]) => `<div class="the">
  <h3>${cham(m)}${thoat(TEN_MUC[m] || m)}</h3>
  <p><b style="font-size:23px">${thoat(String(n))}</b> cổng</p>
  <span class="vai">${thoat(m)}</span>
</div>`).join('')}</div>
</section>

<section class="khung"><div class="hep">
  <h2>${thoat(String(nhomCong.length))} nhóm cổng</h2>
  <p class="phu">Mỗi nhóm khai đúng một mức duy nhất. Đây là bảng máy đọc khi quyết định cho hay chặn — không có bảng thứ hai.</p>
</div>
<div class="bang-ngoai"><table>
  <thead><tr><th>Nhóm</th><th>Mức</th><th>Nhóm</th><th>Mức</th></tr></thead>
  <tbody>${(() => {
    const ds = [...nhomCong].sort((a, b) => a.nhom.localeCompare(b.nhom));
    const hang = [];
    for (let i = 0; i < ds.length; i += 2) {
      const o = (x) => (x ? `<td><b>${thoat(x.nhom)}</b></td><td>${cham(x.muc)}${thoat(TEN_MUC[x.muc] || x.muc)}</td>` : '<td></td><td></td>');
      hang.push(`<tr>${o(ds[i])}${o(ds[i + 1])}</tr>`);
    }
    return hang.join('');
  })()}</tbody>
</table></div>
</section>

<section class="khung"><div class="hep">
  <h2>Ba luật cứng</h2>
  <ul class="ds-kiem">
    <li><b>Mặc định là ĐÓNG.</b> Thêm một nhóm cổng mới mà quên khai mức thì nó rơi vào mức quản trị, không phải mức công khai.</li>
    <li><b>Lời từ chối không nói cổng thuộc vai nào.</b> Nói ra là vẽ đường cho người dò.</li>
    <li><b>Chưa đăng nhập trả 401, không phải 403.</b> Hai mã khác nghĩa nhau, và trộn lẫn thì người dùng thật không biết phải làm gì.</li>
  </ul>
  <div class="hang-nut"><a class="nut" href="/ui/cong.html">Đăng nhập theo vai của bạn</a></div>
</div></section>`;

  return voTrang({
    tieuDe: 'GITA — Phân quyền tài khoản',
    moTa: `${vai.length} vai tài khoản, 4 mức quyền và ${nhomCong.length} nhóm cổng API của hệ thống GITAV20nexus.`,
    dangO: '/phan-quyen.html', than, ngayDung,
  });
}

/** Sơ đồ chương trình. */
function trangSoDo(svg, { ngayDung, thongKe = {} }) {
  const than = `
<section class="khung modau" style="padding-bottom:20px"><div class="hep">
  <span class="nhan-muc">Sơ đồ</span>
  <h1>Cả chương trình trong một hình</h1>
  <p class="phu">Ảnh tĩnh dựng ngày ${thoat(ngayDung)}. Bản xoay được bằng chuột nằm trong hệ thống, cần đăng nhập.</p>
</div></section>
<section class="khung">
  <div class="the" style="padding:14px">${svg}</div>
  <div class="hep" style="margin-top:14px">
    <p class="nho">Mỗi chấm là một dạng toán có thật trong chương trình; mỗi đường là một quan hệ “cần biết trước” đã khai.
    Sơ đồ này <b>xấu ở đúng những chỗ chương trình còn thưa</b> — một chùm chấm không có đường nối nào nghĩa là mảng ấy chưa ai khai quan hệ tiên quyết.</p>
    <div class="hang-nut">
      <a class="nut" href="/ui/so-do-3d.html">Mở bản xoay được</a>
      <a class="nut phu" href="/so-do/toan-canh-nen-sang.svg" download>Tải ảnh nền sáng</a>
      <a class="nut phu" href="/so-do-chuong-trinh.svg" download>Tải ảnh khổ lớn</a>
    </div>
  </div>
</section>`;
  return voTrang({
    tieuDe: 'GITA — Sơ đồ chương trình',
    moTa: `Sơ đồ ${thongKe.soNut || ''} dạng toán và ${thongKe.soCanh || ''} quan hệ tiên quyết của toàn bộ chương trình.`,
    dangO: '/so-do.html', than, ngayDung,
  });
}

/** Danh mục video hướng dẫn. */
function trangKichBan(danhMuc, { ngayDung }) {
  const than = `
<section class="khung modau" style="padding-bottom:20px"><div class="hep">
  <span class="nhan-muc">Video hướng dẫn</span>
  <h1>${thoat(String(danhMuc.soVideo))} video, mỗi vai một bản riêng</h1>
  <p class="phu">${thoat(String(danhMuc.soMan))} màn hình × ${thoat(String(danhMuc.soVai))} vai. Một giáo viên xem video quay cho học viên sẽ nghe toàn việc mình không làm — nên không có bản dùng chung.</p>
  <div class="dai-so">
    <div><b>${thoat(String(danhMuc.soVideo))}</b><span>video</span></div>
    <div><b>8</b><span>chương mỗi video</span></div>
    <div><b>${thoat(String(danhMuc.soMan))}</b><span>màn hình</span></div>
    <div><b>${thoat(String(danhMuc.soVai))}</b><span>vai người xem</span></div>
  </div>
</div></section>

<section class="khung"><div class="hep">
  <h2>Chương thứ ba đọc từ mã, không khai tay</h2>
  <p class="phu">Chương “quyền của bạn ở đây” là chương dễ nói sai nhất — nói sai thì người xem đi làm một việc họ không có quyền, thất bại, rồi nghĩ hệ thống hỏng. Nên nó được suy ra từ chính mã giao diện, qua đúng bảng cổng quyền.</p>
</div>
<div class="bang-ngoai"><table>
  <thead><tr><th>Màn hình</th><th>Vai</th><th>Quyền màn</th><th>Đủ quyền</th><th>Ước chừng</th></tr></thead>
  <tbody>${danhMuc.muc.map((m) => `<tr>
    <td><b>${thoat(m.ten)}</b></td><td>${thoat(m.tenVai)}</td><td>${thoat(m.mucQuyenMan)}</td>
    <td>${m.duQuyen ? 'có' : 'chưa'}</td><td>${m.giayUocTinh}s</td>
  </tr>`).join('')}</tbody>
</table></div>
<div class="hep"><p class="nguon">Giọng đọc dựng tại máy bằng bộ tổng hợp tiếng Việt của hệ thống — không gọi dịch vụ ngoài, chi phí bằng không. Ai có bản thu người thật thì nạp vào đúng chương.</p></div>
</section>`;
  return voTrang({
    tieuDe: 'GITA — Video hướng dẫn',
    moTa: `Danh mục ${danhMuc.soVideo} video hướng dẫn, mỗi màn hình một bản riêng cho từng vai.`,
    dangO: '/video-huong-dan.html', than, ngayDung,
  });
}

/** Hướng dẫn triển khai. */
function trangHuongDan({ ngayDung, soUi = 0, soKichBan = 0, soTep = 0 }) {
  const than = `
<section class="khung modau" style="padding-bottom:20px"><div class="hep">
  <span class="nhan-muc">Triển khai</span>
  <h1>Gói này chạy được gì trên Cloudflare</h1>
  <p class="phu">Cloudflare Pages phục vụ tệp tĩnh: không chạy tiến trình lâu dài, không có hệ tệp ghi được, không giữ trạng thái giữa hai yêu cầu. Nói rõ ranh giới ấy trước, vì đây là chỗ dễ hứa quá tay nhất.</p>
</div></section>

<section class="khung"><div class="hep">
  <h2>Chạy được ngay</h2>
  <ul class="ds-kiem">
    <li>Toàn bộ trang công khai — dựng sẵn thành HTML, số liệu đóng băng tại ngày dựng</li>
    <li>Sơ đồ chương trình, năm góc nhìn, in ra giấy được</li>
    <li>${thoat(String(soKichBan))} kịch bản lời đọc của bộ video hướng dẫn</li>
    <li><b>Cả ${thoat(String(soUi))} tệp giao diện</b> — toàn bộ màn hình của hệ thống</li>
  </ul>
  <h2 style="margin-top:26px">Cần một máy chủ Node</h2>
  <ul class="ds-kiem" style="--x:1">
    <li>Đăng nhập, tài khoản, phiên làm việc</li>
    <li>Trợ lý trò chuyện — đọc dữ liệu học viên thật</li>
    <li>Dựng video, dựng bài giảng, chụp ảnh hệ thống</li>
    <li>Mọi thứ ghi xuống đĩa</li>
  </ul>
  <p class="nho" style="margin-top:14px">Chưa nối máy chủ thì các màn giao diện <b>vẫn mở ra được</b>, chỉ là phần dữ liệu báo chưa đăng nhập. Đó là đúng, không phải lỗi.</p>
</div></section>

<section class="khung"><div class="hep">
  <h2>Nối hai phần — bốn bước</h2>
  <div class="o" style="grid-template-columns:repeat(auto-fit,minmax(210px,1fr))">
    ${[
      ['Chạy máy chủ', 'npm start — ở bất kỳ máy nào, kể cả một máy trong văn phòng.'],
      ['Đưa ra ngoài', 'cloudflared tunnel --url http://localhost:9999 — không phải mở cổng nào trên tường lửa.'],
      ['Trỏ tên miền', 'Trỏ một tên miền con vào đường hầm ấy, ví dụ app.gitamath.vn.'],
      ['Mở ba dòng', 'Trong tệp _redirects đã viết sẵn ba dòng, đổi tên miền cho đúng rồi bỏ dấu thăng.'],
    ].map(([t, m], i) => `<div class="the"><span class="bieu">${i + 1}</span><h3>${thoat(t)}</h3><p>${thoat(m)}</p></div>`).join('')}
  </div>
</div></section>

<section class="khung"><div class="hep">
  <h2>Đếm lại sau khi tải lên</h2>
  <p>Mở <a href="/ban-ke.json">/ban-ke.json</a> trên tên miền vừa triển khai: nó liệt kê đủ ${thoat(String(soTep))} tệp và số byte của từng tệp. Đối chiếu là biết ngay đã lên đủ chưa.</p>
  <p class="nho">Trang tĩnh mang số liệu của <b>ngày dựng</b>, và mỗi trang in rõ ngày ấy. Số liệu đổi thì dựng lại và đẩy lại — một lệnh.</p>
</div></section>`;
  return voTrang({
    tieuDe: 'GITA — Hướng dẫn triển khai',
    moTa: 'Gói tĩnh này chạy được gì trên Cloudflare Pages, và phần nào cần một máy chủ Node.',
    dangO: '/huong-dan.html', than, ngayDung,
  });
}

/**
 * Giới thiệu toàn hệ — trang trả lời câu "GITAV20nexus là cái gì".
 *
 * Trang chủ cũ nói về CHƯƠNG TRÌNH HỌC và dừng ở đó. Người đọc xong vẫn
 * không biết hệ thống có gì ngoài một danh sách dạng toán — trong khi bên
 * dưới là kho học liệu, bộ chẩn đoán thích ứng, lộ trình cá nhân, hồ sơ gia
 * đình, ban trợ lý, két bảo mật mười lăm tầng và một xưởng video.
 *
 * Một hệ thống có mười phần mà mặt tiền chỉ kể một phần thì chín phần kia
 * coi như không tồn tại với người ngoài.
 */
function trangHeThong({ ngayDung, so = {}, batDau = {}, loTrinh = {}, ket = {}, crm = {}, luc = {} }) {
  const PHAN = [
    ['Chương trình học', '◈', `${so.soDang} dạng toán xếp theo ${so.soTang} tầng, nối nhau bằng ${so.soQuanHe} quan hệ "cần biết trước". Thêm tiếng Anh và liên môn.`, '/chuong-trinh.html'],
    ['Chẩn đoán đầu vào', '◐', `Bộ đề thích ứng ${batDau.minItems}–${batDau.maxItems} câu: câu sau chọn theo câu trước, dừng khi đã đủ chắc chắn.`, '/hanh-trinh-hoc.html'],
    ['Lộ trình cá nhân', '⇢', `${loTrinh.weeks} tuần chia ${(loTrinh.stages || []).length} chặng, có mốc kiểm ở tuần ${(loTrinh.checkpointWeeks || []).join(', ')}.`, '/hanh-trinh-hoc.html'],
    ['Hồ sơ học viên và gia đình', '☷', `Chân dung học viên, tiến độ từng dạng, và ${crm.soMoDun} mô-đun quản lý quan hệ gia đình.`, '/ho-so.html'],
    ['Kho học liệu', '▤', `${so.soKiemDinh} bài đã qua thẩm định, ${so.soBay} lỗi sai thường gặp ghi sẵn theo từng dạng.`, '/chuong-trinh.html'],
    ['Luyện thi', '◎', `${so.soChuan} chuẩn: đánh giá năng lực trong nước và chuẩn quốc tế, thang điểm thật.`, '/luyen-thi.html'],
    ['Sơ đồ tư duy ba chiều', '◉', 'Cả chương trình trải trong không gian, xoay được bằng chuột, in ra giấy được.', '/so-do.html'],
    ['Xưởng video hướng dẫn', '▶', 'Mỗi màn hình một video riêng cho từng vai, giọng đọc dựng tại máy.', '/video-huong-dan.html'],
    ['Trợ lý chuyên môn', '⚙', `${luc.soTroLy} trợ lý AI chia ${luc.soTo} tổ, mỗi trợ lý một việc rõ ràng và một trần quyền.`, '/quan-tri.html'],
    ['Quản trị và bảo mật', '⚿', `Két Super Admin ${ket.layers} tầng, phân quyền ${so.soNhomCong} nhóm cổng, nhật ký bất biến.`, '/quan-tri.html'],
  ];

  const than = `
<section class="khung modau" style="padding-bottom:26px"><div class="hep">
  <span class="nhan-muc">Giới thiệu</span>
  <h1>GITAV20nexus là <span>một hệ thống học</span>, không phải một kho bài tập</h1>
  <p class="phu">Kho bài tập cho bạn bài để làm. Hệ thống này trả lời được câu khó hơn: <b>em này đang đứng ở đâu, còn hổng dạng nào, và tuần tới nên học gì.</b> Trả lời được là vì nó giữ đủ ba thứ — chương trình có thứ tự, dấu vết của từng lượt làm bài, và một bộ luật không cho nhảy cóc.</p>
  <div class="dai-so">
    <div><b>${thoat(String(so.soDang))}</b><span>dạng toán</span></div>
    <div><b>${thoat(String(so.soQuanHe))}</b><span>quan hệ tiên quyết</span></div>
    <div><b>${thoat(String(so.soKiemDinh))}</b><span>bài đã thẩm định</span></div>
    <div><b>${thoat(String(luc.soTroLy))}</b><span>trợ lý chuyên môn</span></div>
    <div><b>${thoat(String(so.soCong))}</b><span>cổng dữ liệu</span></div>
    <div><b>${thoat(String(ket.layers))}</b><span>tầng bảo mật</span></div>
  </div>
</div></section>

<section class="khung">
  <div class="hep"><h2>Mười phần, một hệ</h2>
  <p class="phu">Mỗi phần đứng được một mình, và nối với những phần khác bằng dữ liệu chứ không bằng lời hứa.</p></div>
  <div class="o">${PHAN.map(([t, b, m, d]) => `<a class="the" href="${thoat(d)}"><span class="bieu">${b}</span><h3>${thoat(t)}</h3><p>${thoat(m)}</p></a>`).join('')}</div>
</section>

<section class="khung"><div class="hep">
  <h2>Ba nguyên tắc chạy xuyên cả hệ</h2>
  <ul class="ds-kiem">
    <li><b>Kho rỗng thì nói rỗng.</b> Không một con số nào được đắp thêm cho đẹp. Chưa có dữ liệu thì hệ thống nói chưa có — hai câu "chưa có" và "bằng không" khác hẳn nhau với một phụ huynh đang hỏi con mình.</li>
    <li><b>Không hứa kết quả.</b> Không ai nói trước được một em nhỏ sẽ đạt bao nhiêu điểm. Bộ luật nội dung chặn cứng mọi câu hứa, kể cả khi người dùng xin đúng một câu như thế.</li>
    <li><b>Mặc định là đóng.</b> Thêm một nhóm cổng mới mà quên khai mức thì nó rơi vào mức chặt nhất. Quên là an toàn, không phải là lỗ thủng.</li>
  </ul>
</div></section>

<section class="khung"><div class="hep">
  <h2>Chạy được ở đâu</h2>
  <div class="o" style="grid-template-columns:repeat(auto-fit,minmax(220px,1fr))">
    <div class="the"><h3>Trên web</h3><p>Máy chủ Node, không phụ thuộc gói chạy thật nào. Mở bằng trình duyệt là dùng.</p></div>
    <div class="the"><h3>Trên máy tính</h3><p>Bản cài Windows 64-bit, tải về chạy thẳng. Không cần mạng, không cần cài gì thêm.</p></div>
    <div class="the"><h3>Ngoại tuyến</h3><p>Giọng đọc, dựng video, chấm bài đều chạy tại máy. Không gọi dịch vụ ngoài, chi phí bằng không.</p></div>
  </div>
  <div class="hang-nut"><a class="nut" href="/ui/cong.html">Vào hệ thống</a><a class="nut phu" href="/muc-luc.html">Xem mục lục</a></div>
</div></section>`;

  return voTrang({
    tieuDe: 'GITAV20nexus — Giới thiệu toàn hệ thống',
    moTa: `Hệ thống học gồm ${so.soDang} dạng toán, chẩn đoán đầu vào thích ứng, lộ trình cá nhân ${loTrinh.weeks} tuần, hồ sơ gia đình và két bảo mật ${ket.layers} tầng.`,
    dangO: '/he-thong.html', than, ngayDung,
  });
}

/** Hành trình học — chẩn đoán, lộ trình, luyện tập, đo tiến bộ. */
function trangHanhTrinh({ ngayDung, batDau = {}, loTrinh = {}, chuKy = {}, so = {} }) {
  const chang = loTrinh.stages || [];
  const than = `
<section class="khung modau" style="padding-bottom:22px"><div class="hep">
  <span class="nhan-muc">Hành trình học</span>
  <h1>Bắt đầu từ chỗ em đang đứng, không từ đầu sách</h1>
  <p class="phu">Một em lớp tám còn hổng dạng lớp sáu là chuyện bình thường. Bắt em ấy học lại từ trang một là phí thời gian; bắt em học tiếp mà bỏ qua chỗ hổng là xây trên cát. Hệ thống tìm đúng chỗ hổng rồi vá từ đó.</p>
</div></section>

<section class="khung"><div class="hep">
  <h2>Bước một — Chẩn đoán đầu vào</h2>
  <p class="phu">Không phải một đề cố định. Câu sau chọn theo câu trước: làm đúng thì khó lên, làm sai thì lùi lại dò cho ra đáy.</p>
  <div class="o" style="grid-template-columns:repeat(auto-fit,minmax(190px,1fr))">
    <div class="the"><h3>${thoat(String(batDau.minItems))}–${thoat(String(batDau.maxItems))} câu</h3><p>Không cố định. Đủ chắc chắn thì dừng, không bắt làm cho hết.</p></div>
    <div class="the"><h3>Dừng khi sai số ≤ ${thoat(String(batDau.seTarget))}</h3><p>Dừng theo độ chắc chắn đo được, không theo số câu đã làm.</p></div>
    <div class="the"><h3>Ra một tầng</h3><p>Kết quả là vị trí trên thang ${thoat(String(so.soTang))} tầng, kèm danh sách dạng còn hổng.</p></div>
  </div>
</div></section>

<section class="khung"><div class="hep">
  <h2>Bước hai — Lộ trình cá nhân ${thoat(String(loTrinh.weeks))} tuần</h2>
  <p class="phu">Dựng từ chỗ đang đứng, không phải từ một khuôn chung. Hai em cùng lớp thường nhận hai lộ trình khác nhau.</p>
</div>
<div class="o" style="grid-template-columns:repeat(auto-fit,minmax(220px,1fr))">
  ${chang.map((g, i) => `<div class="the"><span class="bieu">${i + 1}</span><h3>${thoat(g.name)}</h3><p>Tuần ${thoat(String((g.weeks || [])[0]))}–${thoat(String((g.weeks || [])[1]))}</p></div>`).join('')}
</div>
<div class="hep"><p class="nguon">Mốc kiểm ở tuần ${thoat((loTrinh.checkpointWeeks || []).join(', '))} — chưa đạt thì lộ trình được dựng lại, không đẩy tiếp.</p></div>
</section>

<section class="khung"><div class="hep">
  <h2>Bước ba — Luyện tập và chữa tại chỗ</h2>
  <ul class="ds-kiem">
    <li>Mỗi buổi luyện một nhóm dạng, chọn theo chỗ còn yếu chứ không theo thứ tự sách</li>
    <li>Sai thì chỉ ra ngay đang vướng bẫy nào — mỗi dạng có sẵn danh sách lỗi thường gặp</li>
    <li>Làm bài nào thì hệ thống ghi lại bài ấy; tiến bộ đo bằng dấu vết, không bằng cảm giác</li>
    <li>Cuối tầng có một lượt kiểm; chưa đạt thì quay lại đúng dạng còn hổng</li>
  </ul>
</div></section>

<section class="khung"><div class="hep">
  <h2>Bước bốn — Chu kỳ ${thoat(String(chuKy.phases || 3))} giai đoạn, chín mươi ngày</h2>
  <p class="phu">Lộ trình tuần lo việc tuần này. Chu kỳ chín mươi ngày lo câu hỏi dài hơn: ba tháng qua đi được bao xa, và ba tháng tới nên đặt mục tiêu nào.</p>
  <p class="nguon">${thoat(String(chuKy.strategyRules || 0))} luật chiến lược quyết định khi nào tăng tốc, khi nào quay lại củng cố — và chúng đọc được, không phải một con số máy tự chấm.</p>
  <div class="hang-nut"><a class="nut" href="/ui/cong.html">Làm một lượt chẩn đoán</a><a class="nut phu" href="/so-do.html">Xem bản đồ kiến thức</a></div>
</div></section>`;

  return voTrang({
    tieuDe: 'GITAV20nexus — Hành trình học',
    moTa: `Chẩn đoán đầu vào thích ứng ${batDau.minItems}–${batDau.maxItems} câu, lộ trình cá nhân ${loTrinh.weeks} tuần, luyện tập có chữa tại chỗ và chu kỳ chín mươi ngày.`,
    dangO: '/hanh-trinh-hoc.html', than, ngayDung,
  });
}

/** Hồ sơ học viên và gia đình. */
function trangHoSo({ ngayDung, crm = {}, so = {} }) {
  const than = `
<section class="khung modau" style="padding-bottom:22px"><div class="hep">
  <span class="nhan-muc">Hồ sơ</span>
  <h1>Một gia đình, một hồ sơ, đọc lại được</h1>
  <p class="phu">Mỗi lượt trao đổi, mỗi bài đã làm, mỗi lần đổi lộ trình đều để lại vết. Nhờ thế người tiếp theo mở hồ sơ ra là hiểu chuyện, không phải hỏi lại gia đình từ đầu.</p>
</div></section>

<section class="khung"><div class="hep">
  <h2>Hồ sơ học viên</h2>
  <div class="o" style="grid-template-columns:repeat(auto-fit,minmax(215px,1fr))">
    <div class="the"><h3>Chân dung</h3><p>Tầng đang ở, dạng đã thành thạo, dạng còn hổng — cập nhật theo từng lượt làm bài.</p></div>
    <div class="the"><h3>Dấu vết luyện tập</h3><p>Bài nào, lúc nào, đúng hay sai, vướng bẫy gì. Tiến bộ đo bằng cái này.</p></div>
    <div class="the"><h3>Lộ trình đang chạy</h3><p>Tuần hiện tại, chặng hiện tại, mốc kiểm sắp tới.</p></div>
    <div class="the"><h3>Báo cáo</h3><p>Bản tóm tắt cho phụ huynh và cho giáo viên, cùng một nguồn số liệu.</p></div>
  </div>
</div></section>

<section class="khung"><div class="hep">
  <h2>Hồ sơ gia đình</h2>
  <p class="phu">Ban quan hệ gia đình gồm ${thoat(String(crm.soMoDun))} mô-đun và ${thoat(String(crm.soTroLy))} trợ lý chuyên môn chia ${thoat(String(crm.soCap))} cấp. Mỗi trợ lý có một trần quyền cứng.</p>
  <div class="o" style="grid-template-columns:repeat(auto-fit,minmax(215px,1fr))">
    <div class="the"><h3>Thông tin và liên hệ</h3><p>Ba mẹ, các con đã liên kết, lịch sử mọi lần trao đổi.</p></div>
    <div class="the"><h3>Yêu cầu và phiếu hỗ trợ</h3><p>Mở phiếu, theo trạng thái, đóng phiếu — không bước nào nhảy ngược.</p></div>
    <div class="the"><h3>Chỉ số theo dõi</h3><p>${thoat(String(crm.soChiSo))} chỉ số, trong đó ${thoat(String(crm.chiSoDoDuoc))} đo được từ dữ liệu thật; số còn lại khai rõ là chưa nối nguồn.</p></div>
    <div class="the"><h3>Việc chờ người duyệt</h3><p>Mọi việc chạm ra ngoài hệ thống đều dừng lại chờ người. Trợ lý không tự nhắn cho gia đình.</p></div>
  </div>
</div></section>

<section class="khung"><div class="hep">
  <h2>Ai thấy được gì</h2>
  <ul class="ds-kiem">
    <li><b>Học viên</b> thấy hồ sơ của chính mình, không thấy của bạn khác</li>
    <li><b>Phụ huynh</b> thấy hồ sơ con mình, không thấy của gia đình khác</li>
    <li><b>Giáo viên</b> thấy học viên trong lớp được phân công, không thấy lớp khác</li>
    <li><b>Dữ liệu sàng lọc tâm lý</b> của một em nhỏ không một cuộc trò chuyện nào chạm được</li>
  </ul>
  <p class="nguon">Ranh giới này do máy cưỡng chế ở ba chỗ độc lập, không phải một quy ước. Nới một chỗ mà quên hai chỗ kia thì yêu cầu vẫn bị chặn.</p>
  <div class="hang-nut"><a class="nut phu" href="/phan-quyen.html">Xem bảng phân quyền đầy đủ</a></div>
</div></section>`;

  return voTrang({
    tieuDe: 'GITAV20nexus — Hồ sơ học viên và gia đình',
    moTa: `Chân dung học viên, dấu vết luyện tập, và ${crm.soMoDun} mô-đun quản lý quan hệ gia đình với ${crm.soChiSo} chỉ số theo dõi.`,
    dangO: '/ho-so.html', than, ngayDung,
  });
}

/** Hệ thống quản trị. */
function trangQuanTri({ ngayDung, ket = {}, luc = {}, so = {}, crm = {} }) {
  const tang = ket.layerList || [];
  const NHOM_TANG = {
    identity: 'Danh tính', credential: 'Mật khẩu', mfa: 'Xác thực hai lớp', recovery: 'Khôi phục',
    session: 'Phiên làm việc', throttle: 'Giới hạn', anomaly: 'Bất thường', integrity: 'Toàn vẹn',
    authorization: 'Uỷ quyền', audit: 'Nhật ký', governance: 'Hiến pháp',
  };
  const than = `
<section class="khung modau" style="padding-bottom:22px"><div class="hep">
  <span class="nhan-muc">Quản trị</span>
  <h1>Quyền lớn nhất là quyền bị canh chặt nhất</h1>
  <p class="phu">Tài khoản quản trị cao nhất không đi qua cổng đăng nhập thường. Nó đi qua một két ${thoat(String(ket.layers))} tầng, và tầng cuối cùng không phải một mật khẩu — là một bộ luật mà chính quản trị viên cũng không sửa được một mình.</p>
  <div class="dai-so">
    <div><b>${thoat(String(ket.layers))}</b><span>tầng bảo mật</span></div>
    <div><b>${thoat(String(luc.soTroLy))}</b><span>trợ lý AI</span></div>
    <div><b>${thoat(String(luc.soTo))}</b><span>tổ chuyên môn</span></div>
    <div><b>${thoat(String(so.soNhomCong))}</b><span>nhóm cổng</span></div>
    <div><b>${thoat(String(so.soCong))}</b><span>cổng API</span></div>
    <div><b>${thoat(String(crm.soTroLy))}</b><span>trợ lý quan hệ</span></div>
  </div>
</div></section>

<section class="khung"><div class="hep">
  <h2>${thoat(String(ket.layers))} tầng của két Super Admin</h2>
  <p class="phu">Mỗi tầng canh một đường vào khác nhau. Qua được một tầng không có nghĩa là qua được tầng sau.</p>
</div>
<div class="bang-ngoai"><table>
  <thead><tr><th>Tầng</th><th>Canh gì</th><th>Nhóm</th></tr></thead>
  <tbody>${tang.map((l) => `<tr><td><b>${thoat(l.id)}</b></td><td>${thoat(l.name)}</td><td class="nho">${thoat(NHOM_TANG[l.kind] || l.kind)}</td></tr>`).join('')}</tbody>
</table></div>
</section>

<section class="khung"><div class="hep">
  <h2>Điều hành hằng ngày</h2>
  <div class="o" style="grid-template-columns:repeat(auto-fit,minmax(215px,1fr))">
    <div class="the"><h3>Lực lượng trợ lý</h3><p>${thoat(String(luc.soTroLy))} trợ lý chia ${thoat(String(luc.soTo))} tổ. Mỗi trợ lý khai rõ việc làm được, công cụ dùng được và trần quyền.</p></div>
    <div class="the"><h3>Tổng động viên</h3><p>Một lệnh đưa cả lực lượng vào việc, có chất vấn chéo giữa các tổ trước khi kết luận.</p></div>
    <div class="the"><h3>Hiến pháp</h3><p>Bộ luật máy cưỡng chế. Một hành động trái hiến pháp bị chặn, kể cả khi người ra lệnh là quản trị.</p></div>
    <div class="the"><h3>Nhật ký bất biến</h3><p>Móc xích băm: sửa một dòng cũ là mọi dòng sau lệch hết, không giấu được.</p></div>
    <div class="the"><h3>Ảnh chụp và khôi phục</h3><p>Chụp trạng thái theo phiên bản, lui về đúng thời điểm đã chọn.</p></div>
    <div class="the"><h3>Thanh tra tự động</h3><p>Tổ thanh tra soi hệ thống mỗi ngày và ghi biên bản — nó báo động, không tự vá.</p></div>
  </div>
</div></section>

<section class="khung"><div class="hep">
  <h2>Hai luật không ai vượt được</h2>
  <ul class="ds-kiem">
    <li><b>Lệnh huỷ diệt phải có hai người.</b> Xoá dữ liệu, hạ quyền hàng loạt, dừng hệ thống — một người ra lệnh, người thứ hai duyệt. Không có đường tắt cho người vội.</li>
    <li><b>Trợ lý không tự chạm ra ngoài.</b> Gửi thư, nhắn tin, ghi vào sổ nhà — mọi việc chạm ra ngoài đều dừng chờ người duyệt. Đây là luật cứng nhất của cả ban.</li>
  </ul>
  <div class="hang-nut"><a class="nut" href="/ui/index.html">Mở trung tâm chỉ huy</a><a class="nut phu" href="/phan-quyen.html">Xem bảng phân quyền</a></div>
</div></section>`;

  return voTrang({
    tieuDe: 'GITAV20nexus — Hệ thống quản trị',
    moTa: `Két Super Admin ${ket.layers} tầng, ${luc.soTroLy} trợ lý AI chia ${luc.soTo} tổ, hiến pháp cưỡng chế bằng máy và nhật ký bất biến.`,
    dangO: '/quan-tri.html', than, ngayDung,
  });
}

/** Soi tệp đã dựng: bắt đúng những thứ làm hỏng một trang tĩnh. */
function soiTrangTinh(html, { tenTep }) {
  const loi = [];
  if (/<script/i.test(html)) loi.push(`${tenTep}: có thẻ script — chính sách nội dung cấm`);
  if (/\son\w+\s*=/i.test(html)) loi.push(`${tenTep}: có thuộc tính bắt sự kiện`);
  // Chỉ bắt URL nằm trong THUỘC TÍNH — đó mới là thứ trình duyệt đi tải.
  //
  // Bản đầu bắt mọi chuỗi http:// trong cả trang, kể cả trong lời văn. Thế là
  // câu hướng dẫn "chạy cloudflared tunnel --url http://localhost:9999" bị
  // báo là "gọi ra ngoài" — trong khi nó chỉ là chữ, không ai tải gì cả.
  // Một mục kiểm báo đỏ vì một câu văn thì sớm muộn bị tắt đi.
  const ngoai = [...html.matchAll(/(?:href|src|action|data|poster)\s*=\s*"(https?:\/\/[^"]+)"/gi)]
    .map((m) => m[1]).filter((u) => !u.startsWith('http://www.w3.org/'));
  if (ngoai.length) loi.push(`${tenTep}: gọi ra ngoài: ${ngoai.slice(0, 2).join(', ')}`);
  if (!/<title>/i.test(html)) loi.push(`${tenTep}: thiếu tiêu đề`);
  if (!/name="description"/i.test(html)) loi.push(`${tenTep}: thiếu mô tả`);
  if (!/lang="vi"/.test(html)) loi.push(`${tenTep}: thiếu khai ngôn ngữ`);
  if (!/<h1/i.test(html)) loi.push(`${tenTep}: không có tiêu đề cấp một`);
  if (!html.includes('/ui/cong.html')) loi.push(`${tenTep}: không có lối vào hệ thống`);
  if (!html.includes('/muc-luc.html')) loi.push(`${tenTep}: không có lối tới mục lục`);
  if (!html.includes('/he-thong.html')) loi.push(`${tenTep}: không có lối tới trang giới thiệu toàn hệ`);
  if (html.includes('CHƯA DỊCH TÊN MÔN')) {
    const m = html.match(/CHƯA DỊCH TÊN MÔN: ([^<]+)/);
    loi.push(`${tenTep}: in mã thô ra trang công khai — ${m ? m[1] : ''}`);
  }

  // Luật nội dung chạy HAI lượt, vì hai loại chữ khác nhau:
  //   · cả trang, KHÔNG đo nhồi — bắt hứa hẹn, chẩn đoán, lộ phân loại
  //   · riêng phần văn xuôi (bỏ bảng), CÓ đo nhồi
  // Gộp một lượt thì bảng dữ liệu làm phép đo văn xuôi báo đỏ oan.
  const chu = html.replace(/<[^>]+>/g, ' ');
  const vanXuoi = html.replace(/<table[\s\S]*?<\/table>/gi, ' ').replace(/<[^>]+>/g, ' ');
  const kCa = luat.soi(chu, { tenTrang: tenTep, doNhoi: false });
  if (!kCa.dat) loi.push(`${tenTep}: không qua luật nội dung — ${kCa.loi.map((x) => x.ma).join(', ')}`);
  const kVan = luat.soi(vanXuoi, { tenTrang: tenTep, doNhoi: true });
  const chiNhoi = kVan.loi.filter((x) => x.ma === 'nhoi-tu-khoa');
  if (chiNhoi.length) loi.push(`${tenTep}: văn xuôi nhồi từ khoá — ${chiNhoi[0].chiTiet}`);
  return loi;
}

/**
 * Soi CHÍNH TỆP NÀY tìm số viết cứng trong lời văn.
 *
 * Soi ở đây chứ không soi HTML đã dựng, vì HTML đã dựng KHÔNG phân biệt được
 * hai thứ trông giống hệt nhau: "104 dạng" do `${so.soDang} dạng` sinh ra là
 * đúng, còn "104 dạng" gõ thẳng vào lời văn là một quả bom hẹn giờ — nó lệch
 * khỏi dữ liệu ngay lần chương trình thêm một dạng.
 *
 * Bản đầu soi HTML và báo oan đúng ba chỗ đang làm đúng. Một mục kiểm không
 * phân biệt được đúng với sai thì nó không kiểm gì cả.
 *
 * Nên soi mã nguồn, và chỉ bắt SỐ VIẾT BẰNG CHỮ đứng trước một danh từ đếm
 * được — đó mới là thứ không bao giờ tự cập nhật. Lỗi có thật: tiêu đề ghi
 * "Bốn mươi sáu nhóm cổng" trong khi dải số ngay phía trên đếm ra 43.
 */
function soiSoVietCung() {
  const ma = require('node:fs').readFileSync(__filename, 'utf8')
    .split('\n')
    .filter((d) => !/^\s*(\*|\/\/)/.test(d))   // bỏ dòng chú thích
    .join('\n');
  // "một" bị bỏ ra: trong tiếng Việt nó gần như luôn là MẠO TỪ ("một dạng
  // toán", "một video") chứ không phải phép đếm, nên bắt nó là báo oan mọi
  // câu văn bình thường.
  const SO_CHU = 'hai|ba|bốn|năm|sáu|bảy|tám|chín|mười|mươi|trăm|nghìn';
  const DEM = 'nhóm|cổng|màn|video|dạng|bài|vai|mức|tầng|khối|chuẩn|trợ lý|tệp|chương';
  const re = new RegExp(`\\b(?:${SO_CHU})(?:\\s+(?:${SO_CHU}))*\\s+(?:${DEM})\\b`, 'gi');
  const bat = [...new Set((ma.match(re) || [])
    // "Năm vai" và "Bốn mức" là TÊN gọi cố định của mô hình phân quyền, không
    // phải phép đếm — chúng không đổi khi dữ liệu đổi.
    .filter((x) => !/^(năm vai|bốn mức|năm khối|ba mảng|tám chương)$/i.test(x.trim())))];
  return { dat: bat.length === 0, bat };
}

module.exports = {
  soiSoVietCung,
  trangHeThong, trangHanhTrinh, trangHoSo, trangQuanTri,
  trangChu, trangMucLuc, trangChuongTrinh, trangLuyenThi, trangPhanQuyen,
  trangSoDo, trangKichBan, trangHuongDan,
  soiTrangTinh, voTrang, kieuChu, dauHieu, LOI_DI, CSP, thoat,
};
