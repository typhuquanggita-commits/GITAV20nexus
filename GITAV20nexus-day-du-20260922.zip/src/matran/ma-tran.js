'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  MA TRẬN ĐA TẦNG
 * ═══════════════════════════════════════════════════════════════════════════
 *  VẤN ĐỀ MA TRẬN NÀY GIẢI.
 *  Một học viên luyện trong hệ thống thì hệ thống biết em ở TẦNG mấy, thạo
 *  DẠNG nào, làm được tới BẬC SAO nào. Nhưng thứ gia đình hỏi lại là: "thi
 *  HSA được bao nhiêu điểm?", "SAT có nổi 1400 không?", "IELTS mấy chấm?".
 *  Không có cầu nối thì hệ thống và gia đình nói hai thứ tiếng khác nhau, và
 *  mọi con số nội bộ trở thành vô nghĩa với người trả tiền.
 *
 *  SÁU TRỤC.
 *    1. HỆ CHUẨN   — HSA · TSA · SPT · SAT · IELTS, và CEFR cho tiếng Anh nền
 *    2. TẦNG       — mười nấc, xương sống chung của cả sáu trục
 *    3. PHẦN THI   — từng phần của từng hệ, có số câu và số phút thật
 *    4. DẠNG BÀI   — 104 dạng đang có trong chương trình
 *    5. BẬC SAO    — năm bậc độ khó
 *    6. LỚP        — lớp 1 đến lớp 12
 *
 *  Ma trận là chỗ sáu trục ấy cắt nhau. Cắt nhau ở đâu thì ở đó trả lời được
 *  một câu hỏi thật, và mỗi ô đều lần ngược về được tới dữ liệu gốc.
 *
 *  NGUYÊN TẮC KHÔNG ĐƯỢC PHÁ: KHÔNG BỊA ĐIỂM.
 *  Hệ thống KHÔNG nói "em được 1250 điểm HSA". Nó nói "em đang ở tầng 8, mà
 *  tầng 8 ứng với khoảng 1200–1280". Khoảng là thứ đo được; con số đơn lẻ là
 *  thứ bịa. Khi học viên có điểm thi THẬT thì điểm thật thắng mọi ước lượng,
 *  và ma trận quay ngược lại để chỉnh tầng.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { CHUAN, CHUAN_INDEX, TEN_NAC, CEFR, cefrCuaLop, diemTheoTang, tangTheoDiem } = require('./chuan');
const { LEVELS, FORM_INDEX, formsForLevel } = require('../curriculum/hierarchy');

/**
 * Môn của một dạng bài, suy từ mã dạng.
 * M* là toán, E* là tiếng Anh, X* là liên môn — liên môn tính vào cả toán lẫn
 * đọc hiểu vì nó đo đúng hai thứ đó.
 */
function monCuaDang(ma) {
  const m = String(ma || '');
  if (m.startsWith('E.')) return ['tieng-anh'];
  if (m.startsWith('X.')) {
    if (m.startsWith('X.DOCHIEU')) return ['doc-hieu'];
    if (m.startsWith('X.KHTN')) return ['khoa-hoc'];
    if (m.startsWith('X.SOLIEU')) return ['toan', 'doc-hieu'];
    return ['toan', 'doc-hieu'];
  }
  return ['toan'];
}

/** Lớp của một dạng bài, hoặc null với dạng không gắn lớp. */
function lopCuaDang(ma) {
  const m = String(ma || '').match(/^M(\d+)\./);
  return m ? Number(m[1]) : null;
}

/**
 * Ô ma trận: một hệ chuẩn × một tầng.
 * Đây là ô hay dùng nhất — nó trả lời "ở tầng này thì hệ kia cho bao nhiêu".
 */
function o(chuanId, tang) {
  const c = CHUAN_INDEX.get(chuanId);
  const d = diemTheoTang(chuanId, tang);
  if (!c || !d) return null;
  const dang = formsForLevel(tang);
  // Dạng nào của tầng này rơi vào phần thi nào của hệ chuẩn ấy.
  const theoPhan = c.phan.map((p) => {
    const thuoc = dang.filter((f) => monCuaDang(f.code).includes(p.mon));
    return {
      phanId: p.id,
      ten: p.ten,
      cau: p.cau,
      phut: p.phut,
      trongSo: p.trongSo || null,
      soDang: thuoc.length,
      dang: thuoc.map((f) => f.code),
    };
  });
  const phu = theoPhan.filter((p) => p.soDang > 0).length;
  return {
    chuanId, chuanTen: c.ngan,
    tang, tenTang: `${LEVELS[tang].code} — ${LEVELS[tang].name}`,
    tenNac: TEN_NAC[tang],
    diem: { tu: d.tu, den: d.den, thang: c.thang },
    soDangCuaTang: dang.length,
    theoPhan,
    phuPhan: `${phu}/${c.phan.length}`,
    // Phần nào của hệ chuẩn mà chương trình CHƯA có dạng nào — nói thẳng chứ
    // không lặng lẽ bỏ qua, vì đó là chỗ học viên sẽ mất điểm mà không biết.
    thieuPhan: theoPhan.filter((p) => p.soDang === 0).map((p) => p.ten),
  };
}

/** Cả một cột: một hệ chuẩn qua đủ mười tầng. */
function cot(chuanId) {
  const c = CHUAN_INDEX.get(chuanId);
  if (!c) return null;
  return { chuanId, ten: c.ten, ngan: c.ngan, thang: c.thang, o: LEVELS.map((l) => o(chuanId, l.id)) };
}

/** Cả một hàng: một tầng nhìn qua đủ năm hệ chuẩn. */
function hang(tang) {
  const t = Number(tang);
  if (!Number.isInteger(t) || t < 0 || t > 9) return null;
  return {
    tang: t,
    tenTang: `${LEVELS[t].code} — ${LEVELS[t].name}`,
    tenNac: TEN_NAC[t],
    theoChuan: CHUAN.map((c) => {
      const x = o(c.id, t);
      return { chuanId: c.id, ngan: c.ngan, tu: x.diem.tu, den: x.diem.den, phuPhan: x.phuPhan };
    }),
  };
}

/** Toàn bộ ma trận: năm hệ × mười tầng. */
function toanBo() {
  return {
    soChuan: CHUAN.length,
    soTang: LEVELS.length,
    soO: CHUAN.length * LEVELS.length,
    hang: LEVELS.map((l) => hang(l.id)),
  };
}

// ── Quy đổi hai chiều ───────────────────────────────────────────────────────

/**
 * Từ tầng hiện tại, ước lượng điểm ở cả năm hệ.
 * Luôn trả KHOẢNG, và luôn kèm căn cứ để người đọc kiểm lại được.
 */
function duBaoDiem(tang) {
  const t = Number(tang);
  if (!Number.isInteger(t) || t < 0 || t > 9) return null;
  return {
    tang: t,
    tenTang: `${LEVELS[t].code} — ${LEVELS[t].name}`,
    canCu: 'Cả năm hệ chuẩn đều chia trình độ thành mười nấc cùng tên, nên nấc thứ n của mỗi hệ ứng với tầng n của hệ thống.',
    duBao: CHUAN.map((c) => {
      const [tu, den] = c.nac[t];
      return {
        chuanId: c.id, ngan: c.ngan,
        khoang: `${tu}–${den}`,
        tren: c.thang[1],
        canhBao: 'Đây là khoảng ứng với tầng, không phải điểm dự đoán của một lần thi cụ thể.',
      };
    }),
  };
}

/**
 * Có điểm thi THẬT thì lấy điểm thật làm chuẩn và chỉnh lại tầng.
 * Lệch giữa tầng hệ thống ước và tầng suy từ điểm thật là tín hiệu quý: nó
 * chỉ ra hệ thống đang đánh giá cao hay thấp hơn thực tế, ở đúng hệ chuẩn nào.
 */
function chinhTheoDiemThat(tangHeThong, cacDiem = []) {
  const ra = [];
  for (const { chuanId, diem } of cacDiem) {
    const t = tangTheoDiem(chuanId, diem);
    if (!t) continue;
    const lech = t.tang - Number(tangHeThong);
    ra.push({
      chuanId, diem, tangTuDiem: t.tang, tenNac: t.tenNac, lech,
      nhanXet: lech === 0 ? 'khớp với tầng hệ thống đang ghi'
        : lech > 0 ? `điểm thật cao hơn tầng hệ thống ghi ${lech} bậc — hệ thống đang đánh giá THẤP`
          : `điểm thật thấp hơn tầng hệ thống ghi ${-lech} bậc — hệ thống đang đánh giá CAO`,
    });
  }
  const lechTB = ra.length ? ra.reduce((s, x) => s + x.lech, 0) / ra.length : 0;
  return {
    tangHeThong: Number(tangHeThong),
    doiChieu: ra,
    lechTrungBinh: Math.round(lechTB * 100) / 100,
    denghi: !ra.length ? 'chưa có điểm thi thật để đối chiếu'
      : Math.abs(lechTB) < 0.5 ? 'giữ nguyên tầng — hệ thống và điểm thật đang khớp'
        : `chỉnh tầng hệ thống ${lechTB > 0 ? 'lên' : 'xuống'} ${Math.abs(Math.round(lechTB))} bậc`,
  };
}

// ── Chỗ hổng ────────────────────────────────────────────────────────────────

/**
 * Soi toàn ma trận tìm ô hổng: phần thi của một hệ chuẩn mà chương trình chưa
 * có dạng bài nào ở tầng đó.
 *
 * Đây là phép soi quan trọng nhất của cả mô-đun. Ô hổng nghĩa là học viên
 * luyện hết mức trong hệ thống vẫn sẽ gặp phần đó lần đầu ngay trong phòng
 * thi. Nói ra được thì còn vá được; im lặng thì gia đình chỉ biết khi đã thi.
 */
function soiHong() {
  const hong = [];
  for (const c of CHUAN) {
    for (const l of LEVELS) {
      const x = o(c.id, l.id);
      for (const p of x.theoPhan) {
        if (p.soDang === 0) {
          hong.push({ chuanId: c.id, ngan: c.ngan, tang: l.id, phanId: p.phanId, phan: p.ten });
        }
      }
    }
  }
  // Gom theo phần cho dễ đọc: một phần hổng ở chín tầng thì đó là một lỗ
  // hổng chương trình, không phải chín lỗi rời rạc.
  const theoPhan = new Map();
  for (const h of hong) {
    const k = `${h.chuanId}|${h.phanId}`;
    if (!theoPhan.has(k)) theoPhan.set(k, { ...h, tangHong: [] });
    theoPhan.get(k).tangHong.push(h.tang);
  }
  return {
    soO: CHUAN.length * LEVELS.length,
    soOHong: hong.length,
    theoPhan: [...theoPhan.values()].sort((a, b) => b.tangHong.length - a.tangHong.length),
  };
}

/** Tiếng Anh theo lớp: CEFR nào, và chương trình đã có dạng nào cho lớp ấy. */
function tiengAnhTheoLop() {
  const ra = [];
  for (let lop = 1; lop <= 12; lop++) {
    const c = cefrCuaLop(lop);
    const dangAnh = [...FORM_INDEX.values()].filter((f) => f.code.startsWith('E.'));
    ra.push({
      lop,
      cefr: c ? c.id : null,
      cefrTen: c ? c.ten : null,
      tuVungMucTieu: c ? c.tuVung : null,
      gioMucTieu: c ? c.gio : null,
      soDangTiengAnh: dangAnh.length,
    });
  }
  return ra;
}

module.exports = {
  o, cot, hang, toanBo, duBaoDiem, chinhTheoDiemThat, soiHong,
  tiengAnhTheoLop, monCuaDang, lopCuaDang,
};
