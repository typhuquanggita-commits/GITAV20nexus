'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  CHUỖI GIÁ TRỊ 50 Ô — 5 TẦNG × 10 CẤP
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Cây giá trị (src/nha/cay-gia-tri.js) nói học viên LÀM ĐƯỢC GÌ qua năm tầng.
 *  Ma trận đa tầng (src/matran/ma-tran.js) nói mười tầng năng lực quy ra điểm
 *  của năm hệ chuẩn. Tệp này NỐI HAI THỨ ĐÓ: mỗi tầng của cây chia thành mười
 *  cấp, thành một lưới 50 ô, và mỗi ô nói đúng ba điều đo được:
 *
 *      LÀM ĐƯỢC GÌ   ·   BẰNG CHỨNG NÀO   ·   BƯỚC KẾ TIẾP
 *
 *  VÌ SAO PHẢI CÓ MƯỜI CẤP TRONG MỘT TẦNG. Năm tầng là năm bước nhảy lớn, mỗi
 *  bước nhiều tháng. Một học viên ở giữa tầng 2 suốt ba tháng mà bảng vẫn ghi
 *  "tầng 2" thì em ấy không thấy mình đi được chút nào, và mất động lực. Mười
 *  cấp cho em một mốc nhỏ để chạm tới trong vòng một hai tuần.
 *
 *  LUẬT CỦA LƯỚI NÀY, ba điều:
 *    1. Ô nào cũng phải có BẰNG CHỨNG đo được bằng máy hoặc quan sát được ở
 *       nhà. Ô nói "em tự tin hơn" mà không có cách kiểm thì không được vào.
 *    2. KHÔNG nhảy cấp. Cấp n+1 chỉ mở khi cấp n có bằng chứng — vì lưới này
 *       dùng để nói với gia đình rằng con đang ở đâu, và nói sai một lần là
 *       mất lòng tin vào cả năm mươi ô.
 *    3. Cấp 10 của tầng k CHÍNH LÀ cấp 0 của tầng k+1. Không có khoảng trống
 *       giữa hai tầng; chỗ nối là chỗ học viên hay rơi nhất.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { TANG } = require('../nha/cay-gia-tri');

/**
 * Mười cấp trong MỘT tầng, mô tả theo hình dạng chung của việc thạo một thứ.
 * Phần chữ cụ thể của từng tầng nằm ở BUOC_THEO_TANG bên dưới.
 */
const CAP = [
  { cap: 1, ten: 'Nghe qua', y: 'Biết là có việc này, chưa tự làm được.' },
  { cap: 2, ten: 'Làm theo mẫu', y: 'Làm đúng khi có mẫu ngay trước mắt.' },
  { cap: 3, ten: 'Làm có nhắc', y: 'Tự làm được, thỉnh thoảng cần nhắc một bước.' },
  { cap: 4, ten: 'Tự làm được', y: 'Không cần nhắc, nhưng còn chậm.' },
  { cap: 5, ten: 'Làm gọn', y: 'Đúng và đủ nhanh cho bài quen.' },
  { cap: 6, ten: 'Gặp biến thể', y: 'Bài đổi một chi tiết vẫn làm được.' },
  { cap: 7, ten: 'Tự bắt lỗi', y: 'Làm sai thì tự phát hiện, không cần người chấm.' },
  { cap: 8, ten: 'Giải thích được', y: 'Nói được vì sao làm thế, cho người khác hiểu.' },
  { cap: 9, ten: 'Dùng sang chỗ khác', y: 'Mang cách làm này sang một tình huống mới.' },
  { cap: 10, ten: 'Thành nếp', y: 'Làm mà không phải nghĩ tới nữa — và đây là cấp 0 của tầng sau.' },
];

/**
 * Với mỗi tầng: bằng chứng của các cấp, viết theo đúng việc của tầng ấy.
 * Ba mốc 3 · 6 · 10 là ba mốc phải có bằng chứng CỨNG; các cấp còn lại suy ra
 * bằng nội suy có kiểm soát (xem bangChung()).
 */
const BUOC_THEO_TANG = {
  1: { // Nhìn thật
    viec: 'nhìn đúng chỗ mình đang đứng',
    mocCung: {
      3: { chung: 'Làm xong bài đo đầu vào, máy chấm được, không bỏ dở.', do: 'placement.finish' },
      6: { chung: 'Nói được tên ba phần mình yếu, khớp với ba phần máy đo ra.', do: 'so khớp lời học viên với mastery.weakest' },
      10: { chung: 'Trước mỗi buổi tự chọn đúng phần cần luyện, không cần ai chỉ.', do: 'tỉ lệ buổi tự chọn đúng phần yếu ≥ 70%' },
    },
  },
  2: { // Chắc gốc
    viec: 'vá xong lỗ hổng lớp dưới',
    mocCung: {
      3: { chung: 'Làm lại đúng bài đã sai ngay trong buổi.', do: 'attempt.correct sau REVIEW_MISTAKE' },
      6: { chung: 'Bài cũ làm lại sau một tuần vẫn đúng.', do: 'ôn giãn cách 7 ngày, đúng ≥ 80%' },
      10: { chung: 'Bài cũ sau hai tuần vẫn đúng, không xem lại lời giải.', do: 'ôn 14 ngày, đúng ≥ 80%, peeked = false' },
    },
  },
  3: { // Đi đều
    viec: 'biến việc học thành nếp',
    mocCung: {
      3: { chung: 'Học được ba buổi trong một tuần.', do: 'sessions ≥ 3 trong 7 ngày' },
      6: { chung: 'Giữ nhịp hai tuần liền, kể cả tuần bận.', do: 'sessions ≥ 3/tuần × 2 tuần liên tiếp' },
      10: { chung: 'Bốn tuần liền tự ngồi vào bàn, không ai giục.', do: 'sessions đều 4 tuần và skipRate ≤ 10%' },
    },
  },
  4: { // Làm được đề thật
    viec: 'làm trọn đề trong đúng giờ',
    mocCung: {
      3: { chung: 'Làm hết nửa đề trong nửa thời gian quy định.', do: 'exam: hoàn thành ≥ 50% trong ≤ 50% giờ' },
      6: { chung: 'Làm hết đề trong giờ, không bỏ trắng phần cuối.', do: 'exam: 100% câu có trả lời, đúng giờ' },
      10: { chung: 'Đạt ngưỡng qua cửa cả tổng đề lẫn riêng phần vận dụng cao.', do: 'chamCua(): qua = true' },
    },
  },
  5: { // Tự đi
    viec: 'tự học được khi không còn hệ thống',
    mocCung: {
      3: { chung: 'Làm bài mới mà chỉ xin một gợi ý.', do: 'hintsUsed ≤ 1 trên bài chưa gặp' },
      6: { chung: 'Làm bài chưa gặp mà không xin gợi ý, không xem lời giải trước.', do: 'hintRate ≤ 15% và peekRate ≤ 10%' },
      10: { chung: 'Giải được bài ngoài chương trình và viết được căn cứ từng bước.', do: 'bài mở, có phần căn cứ, người chấm xác nhận' },
    },
  },
};

/**
 * LÁ VÀ QUẢ CỦA TỪNG Ô.
 *
 *   la  — nhiệm vụ học viên LÀM ở cấp ấy. Đây là phần học viên thấy mình
 *          phải động tay vào, nên viết bằng động từ và viết cụ thể tới mức
 *          đọc xong là biết mở máy lên làm gì.
 *   qua — thứ GIA ĐÌNH NHẬN ĐƯỢC khi cấp ấy xong. Viết bằng thay đổi quan
 *          sát được ở nhà, KHÔNG viết bằng điểm số và không hứa thứ hệ
 *          thống không giữ được.
 *
 * Năm mươi cặp dưới đây viết tay từng cặp theo đúng việc của từng tầng.
 * Không dùng khuôn chung rồi thay tên tầng: một cái cây mà lá nào cũng
 * giống lá nào thì nhìn là biết không ai trồng nó thật.
 */
const LA_VA_QUA = {
  1: [
    { cap: 1, la: 'Nghe giải thích vì sao buổi đầu không dạy bài mới mà đi đo.', qua: 'Gia đình hết sốt ruột vì buổi đầu “chưa học gì”.' },
    { cap: 2, la: 'Làm năm câu mẫu có đáp án hiện ngay, để quen cách nhập và cách chấm.', qua: 'Vào bài đo thật không mất điểm vì lạ cách làm.' },
    { cap: 3, la: 'Làm trọn bài đo đầu vào, không bỏ dở câu nào.', qua: 'Có bản đồ năng lực đầu tiên, đo bằng bài làm chứ không bằng cảm giác.' },
    { cap: 4, la: 'Đọc bản đồ năng lực của mình, chỉ ra ba ô yếu nhất.', qua: 'Con chỉ được vào màn hình và nói “chỗ này con hổng”.' },
    { cap: 5, la: 'Đối chiếu ba ô yếu ấy với bài kiểm tra gần nhất ở trường.', qua: 'Gia đình thấy kết quả đo khớp với điểm thật ở lớp.' },
    { cap: 6, la: 'Tự nói ra ba phần mình yếu TRƯỚC khi mở bản đồ.', qua: 'Con nói được tên phần yếu, thay vì nói chung chung “con kém toán”.' },
    { cap: 7, la: 'Làm một bài rồi tự đoán mình sai câu nào trước khi xem chấm.', qua: 'Con biết lúc nào mình chắc, lúc nào mình đang đoán.' },
    { cap: 8, la: 'Giải thích cho bố mẹ nghe bản đồ năng lực của mình nói gì.', qua: 'Bữa cơm nói chuyện học bằng chỗ mạnh chỗ yếu, không bằng điểm số.' },
    { cap: 9, la: 'Dùng đúng cách đọc bản đồ ấy cho một môn khác.', qua: 'Con biết tự hỏi “mình đang hổng gì” ở mọi môn.' },
    { cap: 10, la: 'Trước mỗi buổi, tự chọn phần cần luyện rồi mới bắt đầu.', qua: 'Con mở máy là biết hôm nay học gì, không chờ ai xếp.' },
  ],
  2: [
    { cap: 1, la: 'Xem lại danh sách bài đã sai, chưa làm lại vội.', qua: 'Con thấy lỗi của mình gom về vài dạng, không phải sai lung tung.' },
    { cap: 2, la: 'Làm lại bài sai ngay bên cạnh lời giải mẫu.', qua: 'Con biết bước nào mình hụt, không chỉ biết là mình sai.' },
    { cap: 3, la: 'Làm lại đúng bài đã sai ngay trong buổi, không mở lời giải.', qua: 'Lỗi vừa mắc được vá ngay, không kịp thành thói quen.' },
    { cap: 4, la: 'Làm bài cùng dạng nhưng đổi số.', qua: 'Con hết “thuộc bài” mà vẫn không hiểu.' },
    { cap: 5, la: 'Làm bài có đúng cái bẫy mình từng mắc.', qua: 'Con nhận ra bẫy trước khi bước vào.' },
    { cap: 6, la: 'Làm lại bài cũ sau một tuần.', qua: 'Kiến thức cũ trụ được qua một tuần, không rơi ngay sau buổi học.' },
    { cap: 7, la: 'Tự chấm bài của mình rồi đối chiếu với máy.', qua: 'Con tự biết mình sai ở đâu mà không cần ai chấm.' },
    { cap: 8, la: 'Giảng lại cho người khác đúng chỗ mình từng hổng.', qua: 'Chỗ từng yếu nhất thành chỗ con giảng được cho bạn.' },
    { cap: 9, la: 'Dùng phần nền vừa vá vào một bài của chương đang học ở lớp.', qua: 'Bài mới ở lớp bớt nặng vì gốc đã chắc.' },
    { cap: 10, la: 'Làm lại bài cũ sau hai tuần, không xem lời giải.', qua: 'Bài cũ sau hai tuần vẫn đúng — nền đã thật sự chắc.' },
  ],
  3: [
    { cap: 1, la: 'Chọn khung giờ học cố định cùng gia đình.', qua: 'Nhà có một giờ học ai cũng biết, hết cảnh mỗi hôm một kiểu.' },
    { cap: 2, la: 'Học theo lịch, còn cần người nhắc.', qua: 'Con quen với việc đến giờ là ngồi vào bàn.' },
    { cap: 3, la: 'Học đủ ba buổi trong một tuần.', qua: 'Tuần đầu tiên có nhịp thật, không phải học dồn cuối tuần.' },
    { cap: 4, la: 'Tự bấm giờ buổi học và tự đóng buổi.', qua: 'Con giữ được trọn buổi tập trung mà không cần ai canh.' },
    { cap: 5, la: 'Giữ nhịp trong một tuần có bài kiểm tra ở trường.', qua: 'Nhịp học không vỡ mỗi khi trường có việc.' },
    { cap: 6, la: 'Giữ nhịp hai tuần liền, kể cả tuần bận.', qua: 'Gia đình thôi phải nhắc; nhịp đứng được bằng chính nó.' },
    { cap: 7, la: 'Tự nhận ra hôm nào mình học hời hợt và học bù.', qua: 'Con tự sửa nhịp của mình, không đợi ai phát hiện.' },
    { cap: 8, la: 'Nói được vì sao khung giờ ấy hợp với mình.', qua: 'Con giữ nếp vì hiểu, không vì bị bắt.' },
    { cap: 9, la: 'Giữ nếp ấy cả trong kỳ nghỉ.', qua: 'Kỳ nghỉ thôi là chỗ rơi mất mấy tháng.' },
    { cap: 10, la: 'Bốn tuần liền tự ngồi vào bàn, không ai giục.', qua: 'Học thành nếp — thứ khó tạo nhất và bền nhất trong cả năm tầng.' },
  ],
  4: [
    { cap: 1, la: 'Xem ma trận đề thật: đề có mấy phần, mỗi phần mấy câu.', qua: 'Con hết bất ngờ về cấu trúc đề khi vào phòng thi.' },
    { cap: 2, la: 'Làm một phần của đề, có ma trận mở bên cạnh.', qua: 'Con biết mỗi phần đáng bao nhiêu phút.' },
    { cap: 3, la: 'Làm hết nửa đề trong nửa thời gian quy định.', qua: 'Con biết tốc độ thật của mình bằng số phút, không bằng cảm giác.' },
    { cap: 4, la: 'Làm trọn đề, chưa bấm giờ gắt.', qua: 'Con đi hết được một đề mà không đuối ở phần cuối.' },
    { cap: 5, la: 'Làm trọn đề đúng giờ, được phép bỏ qua câu khó.', qua: 'Con biết bỏ câu khó đúng lúc, thay vì mắc kẹt ở đó.' },
    { cap: 6, la: 'Làm hết đề trong giờ, không bỏ trắng phần cuối.', qua: 'Con không còn mất điểm oan ở những câu chưa kịp đọc.' },
    { cap: 7, la: 'Soi lại đề vừa làm, chỉ ra chỗ mất giờ.', qua: 'Mỗi lần thi thử là một lần con tự rút ngắn thời gian.' },
    { cap: 8, la: 'Giải thích được vì sao chọn thứ tự làm bài ấy.', qua: 'Con có chiến thuật làm bài của riêng mình và nói ra được.' },
    { cap: 9, la: 'Làm đề của một hệ chuẩn khác.', qua: 'Con chuyển được cách làm sang dạng đề lạ.' },
    { cap: 10, la: 'Đạt ngưỡng qua cửa cả tổng đề lẫn riêng phần vận dụng cao.', qua: 'Vào phòng thi thật với một con số đã kiểm chứng, không phải một hy vọng.' },
  ],
  5: [
    { cap: 1, la: 'Làm bài mới với gợi ý mở sẵn.', qua: 'Con dám bắt đầu một bài chưa từng gặp.' },
    { cap: 2, la: 'Làm bài mới, chỉ mở gợi ý khi bí quá.', qua: 'Con quen với cảm giác bí mà vẫn ngồi lại.' },
    { cap: 3, la: 'Làm bài mới mà chỉ xin một gợi ý.', qua: 'Con tự đi được phần lớn quãng đường của một bài lạ.' },
    { cap: 4, la: 'Viết ra hướng mình chọn TRƯỚC khi giải.', qua: 'Con có thói quen nghĩ trước khi viết.' },
    { cap: 5, la: 'Tự soát lại bài trước khi nộp.', qua: 'Con tự bắt được lỗi của mình trước khi ai chấm.' },
    { cap: 6, la: 'Làm bài chưa gặp: không gợi ý, không xem lời giải trước.', qua: 'Con tự học được một bài mới từ đầu đến cuối.' },
    { cap: 7, la: 'Tự tìm thêm một cách giải khác cho bài đã làm.', qua: 'Con thấy một bài có nhiều đường, không chỉ một đường thuộc lòng.' },
    { cap: 8, la: 'Viết căn cứ từng bước cho người khác đọc hiểu.', qua: 'Con trình bày được lập luận, không chỉ đưa ra đáp số.' },
    { cap: 9, la: 'Mang cách làm ấy sang một bài của môn khác.', qua: 'Cách học này theo con sang mọi môn, không chỉ môn đang luyện.' },
    { cap: 10, la: 'Giải bài ngoài chương trình và viết được căn cứ từng bước.', qua: 'Rời hệ thống, con vẫn tự học được — đây là đích của cả cây.' },
  ],
};

const LA_VA_QUA_INDEX = new Map();
for (const [t, ds] of Object.entries(LA_VA_QUA)) for (const x of ds) LA_VA_QUA_INDEX.set(`T${t}C${x.cap}`, x);

/**
 * Bằng chứng của một ô.
 *
 * Ba mốc cứng 3 · 6 · 10 lấy nguyên văn. Các cấp khác nội suy: nói rõ nó nằm
 * giữa hai mốc nào, và ĐÁNH DẤU là mốc mềm. Không giả vờ rằng cấp 7 có một
 * phép đo riêng — nó không có, và nói thẳng thì người dùng biết tin tới đâu.
 */
function bangChung(tang, cap) {
  const b = BUOC_THEO_TANG[tang];
  if (!b) return null;
  if (b.mocCung[cap]) return { ...b.mocCung[cap], loai: 'moc-cung' };
  const cacMoc = Object.keys(b.mocCung).map(Number).sort((x, y) => x - y);
  const duoi = [...cacMoc].reverse().find((m) => m < cap) || null;
  const tren = cacMoc.find((m) => m > cap) || null;
  return {
    loai: 'moc-mem',
    chung: duoi && tren
      ? `Đang giữa mốc ${duoi} và mốc ${tren} của việc ${b.viec}.`
      : `Mới bắt đầu việc ${b.viec}.`,
    do: duoi ? `nội suy giữa mốc ${duoi} và ${tren || 10}` : 'chưa có mốc cứng phía dưới',
    canDo: 'Mốc mềm: dùng để thấy mình đang nhích, KHÔNG dùng để báo cáo đã đạt.',
  };
}

/** Một ô của lưới. */
function o(tang, cap) {
  const t = TANG.find((x) => x.thu === Number(tang));
  const c = CAP.find((x) => x.cap === Number(cap));
  if (!t || !c) return null;
  const bc = bangChung(Number(tang), Number(cap));
  const keTiep = Number(cap) < 10
    ? { tang: Number(tang), cap: Number(cap) + 1 }
    : (Number(tang) < 5 ? { tang: Number(tang) + 1, cap: 1 } : null);
  const lq = LA_VA_QUA_INDEX.get(`T${tang}C${cap}`) || null;
  return {
    ma: `T${tang}C${cap}`,
    tang: Number(tang), tenTang: t.ten, viecCuaTang: t.duoc,
    cap: Number(cap), tenCap: c.ten, yCap: c.y,
    lamDuocGi: `${c.y} — trong việc ${BUOC_THEO_TANG[tang].viec}.`,
    // LÁ là việc học viên làm; QUẢ là thứ gia đình nhận được. Hai thứ khác
    // nhau, và tách ra vì người học cần cái thứ nhất còn người trả tiền cho
    // việc học cần cái thứ hai — gộp lại là mất một trong hai.
    la: lq ? lq.la : null,
    qua: lq ? lq.qua : null,
    bangChung: bc,
    keTiep,
    // Chỗ nối giữa hai tầng là chỗ hay rơi nhất, nên đánh dấu riêng.
    laChoNoi: Number(cap) === 10,
  };
}

/** Cả lưới 50 ô. */
function luoi() {
  const ra = [];
  for (let t = 1; t <= 5; t++) for (let c = 1; c <= 10; c++) ra.push(o(t, c));
  return {
    soTang: 5, soCapMoiTang: 10, soO: ra.length,
    cap: CAP.map((x) => ({ ...x })),
    o: ra,
    soMocCung: ra.filter((x) => x.bangChung.loai === 'moc-cung').length,
    soMocMem: ra.filter((x) => x.bangChung.loai === 'moc-mem').length,
    luat: [
      'Ô nào cũng phải có bằng chứng đo được bằng máy hoặc quan sát được ở nhà.',
      'Không nhảy cấp: cấp n+1 chỉ mở khi cấp n có bằng chứng.',
      'Cấp 10 của tầng k chính là cấp 0 của tầng k+1 — không có khoảng trống giữa hai tầng.',
    ],
    ghiChu: `${ra.filter((x) => x.bangChung.loai === 'moc-cung').length}/50 ô có mốc CỨNG (đo bằng máy). `
      + `${ra.filter((x) => x.bangChung.loai === 'moc-mem').length} ô còn lại là mốc MỀM — dùng để thấy mình đang nhích, `
      + 'không dùng để báo cáo đã đạt.',
  };
}

/** Quy một vị trí trên lưới ra số ô đã đi, để vẽ thanh tiến độ. */
function tienDo(tang, cap) {
  const t = Number(tang);
  const c = Number(cap);
  if (!(t >= 1 && t <= 5 && c >= 1 && c <= 10)) return null;
  const daDi = (t - 1) * 10 + c;
  return { daDi, tong: 50, tiLe: Math.round(daDi / 50 * 100) / 100, o: `T${t}C${c}` };
}

module.exports = { CAP, BUOC_THEO_TANG, LA_VA_QUA, LA_VA_QUA_INDEX, bangChung, o, luoi, tienDo };
