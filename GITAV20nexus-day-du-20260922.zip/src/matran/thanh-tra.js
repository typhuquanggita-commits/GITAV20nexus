'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  THANH TRA MA TRẬN ĐA TẦNG
 * ═══════════════════════════════════════════════════════════════════════════
 *  Hai nhà khoa học của hệ thống đi soi toàn diện, mỗi người một trục:
 *
 *  NHÀ KHOA HỌC TOÁN soi trục chuẩn — chương trình có phủ đủ các phần của
 *  HSA, TSA, SPT và SAT không, ở tầng nào thì hổng, và hổng bao nhiêu phần
 *  trăm số câu của đề thật.
 *
 *  NHÀ KHOA HỌC NGÔN NGỮ soi trục tiếng Anh — bốn kỹ năng của IELTS, hai
 *  phần của SAT, và bậc CEFR ứng với từng lớp từ một đến mười hai.
 *
 *  NGUYÊN TẮC: BÁO Ổ HỔNG THEO SỐ CÂU, KHÔNG THEO SỐ Ô.
 *  Một phần hổng ở mười tầng nghe như mười lỗi, nhưng thực ra là MỘT lỗ hổng
 *  chương trình. Ngược lại, một phần chiếm năm mươi câu trên hai trăm câu của
 *  đề mà hổng thì nặng hơn hẳn một phần hai mươi câu. Nên thước đo đúng là
 *  PHẦN TRĂM SỐ CÂU CỦA ĐỀ THẬT mà học viên sẽ gặp lần đầu ngay trong phòng
 *  thi — con số đó mới nói đúng mức thiệt hại.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { CHUAN, CHUAN_INDEX, CEFR, cefrCuaLop } = require('./chuan');
const maTran = require('./ma-tran');
const { LEVELS, FORM_INDEX } = require('../curriculum/hierarchy');

/**
 * Nhà khoa học toán đi soi: mỗi hệ chuẩn còn hổng bao nhiêu phần trăm đề.
 */
function soiChuan() {
  const ra = [];
  for (const c of CHUAN) {
    const tongCau = c.phan.reduce((s, p) => s + (p.cau || 0), 0);
    const phanHong = [];
    for (const p of c.phan) {
      // Một phần coi là hổng khi KHÔNG tầng nào có dạng bài thuộc phần đó.
      const coONaoDo = LEVELS.some((l) => {
        const x = maTran.o(c.id, l.id);
        const y = x.theoPhan.find((z) => z.phanId === p.id);
        return y && y.soDang > 0;
      });
      const tangCo = LEVELS.filter((l) => {
        const y = maTran.o(c.id, l.id).theoPhan.find((z) => z.phanId === p.id);
        return y && y.soDang > 0;
      }).map((l) => l.id);
      if (!coONaoDo) {
        phanHong.push({ phanId: p.id, ten: p.ten, cau: p.cau, mon: p.mon, hongHoanToan: true, tangCo: [] });
      } else if (tangCo.length < LEVELS.length) {
        phanHong.push({
          phanId: p.id, ten: p.ten, cau: p.cau, mon: p.mon,
          hongHoanToan: false,
          tangCo,
          tangThieu: LEVELS.map((l) => l.id).filter((i) => !tangCo.includes(i)),
        });
      }
    }
    const cauHongHoanToan = phanHong.filter((p) => p.hongHoanToan).reduce((s, p) => s + p.cau, 0);
    ra.push({
      chuanId: c.id, ngan: c.ngan, tongCau,
      soPhan: c.phan.length,
      phanHong,
      cauHongHoanToan,
      tiLeHong: tongCau ? Math.round((cauHongHoanToan / tongCau) * 100) : 0,
      danhGia: cauHongHoanToan === 0 ? 'phủ đủ mọi phần của đề'
        : `còn ${cauHongHoanToan}/${tongCau} câu thuộc phần chương trình chưa dạy`,
    });
  }
  return ra.sort((a, b) => b.tiLeHong - a.tiLeHong);
}

/**
 * Nhà khoa học ngôn ngữ đi soi trục tiếng Anh.
 * Ba câu hỏi: bốn kỹ năng có đủ dạng bài không, mỗi lớp có bậc CEFR rõ ràng
 * không, và dạng nào còn trống hoàn toàn.
 */
function soiTiengAnh() {
  const dangAnh = [...FORM_INDEX.values()].filter((f) => f.code.startsWith('E.'));
  let blueprintsForForm = () => [];
  try { ({ blueprintsForForm } = require('../content/blueprint')); } catch { /* chạy được khi thiếu kho */ }

  const KY_NANG = {
    nghe: ['E.LISTENING'], doc: ['E.READING'], viet: ['E.WRITING'],
    noi: ['E.SPEAKING'], nen: ['E.GRAMMAR', 'E.VOCAB'],
  };
  const theoKyNang = Object.entries(KY_NANG).map(([ky, tien]) => {
    const thuoc = dangAnh.filter((f) => tien.some((t) => f.code.startsWith(t)));
    const coHocLieu = thuoc.filter((f) => blueprintsForForm(f.code).length > 0);
    return {
      kyNang: ky,
      soDang: thuoc.length,
      soDangCoHocLieu: coHocLieu.length,
      trong: thuoc.filter((f) => blueprintsForForm(f.code).length === 0).map((f) => f.code),
    };
  });

  const theoLop = [];
  for (let lop = 1; lop <= 12; lop++) {
    const c = cefrCuaLop(lop);
    theoLop.push({ lop, cefr: c ? c.id : null, ten: c ? c.ten : null, tuVung: c ? c.tuVung : null });
  }
  const lopThieuCefr = theoLop.filter((x) => !x.cefr).map((x) => x.lop);

  // IELTS chấm Writing và Speaking theo đúng bốn tiêu chí chính thức. Kiểm
  // xem hệ thống có khai đủ tiêu chí không — thiếu là chấm theo thang tự nghĩ.
  const ielts = CHUAN_INDEX.get('ielts');
  const tieuChi = ielts.tieuChiCham || {};
  const duTieuChi = (tieuChi.viet || []).length === 4 && (tieuChi.noi || []).length === 4;

  return {
    soDangTiengAnh: dangAnh.length,
    theoKyNang,
    kyNangTrong: theoKyNang.filter((k) => k.soDangCoHocLieu === 0).map((k) => k.kyNang),
    soDangTrong: theoKyNang.reduce((s, k) => s + k.trong.length, 0),
    dangTrong: theoKyNang.flatMap((k) => k.trong),
    theoLop,
    lopThieuCefr,
    bacCefr: CEFR.length,
    duTieuChiIelts: duTieuChi,
    tieuChiViet: tieuChi.viet || [],
    tieuChiNoi: tieuChi.noi || [],
  };
}

/**
 * Biên bản thanh tra đầy đủ — gộp hai nhà khoa học lại.
 * `dat` chỉ bật khi KHÔNG còn phần nào hổng hoàn toàn; hổng một phần thì vẫn
 * báo nhưng không chặn, vì đó là việc bồi dần chứ không phải lỗ thủng.
 */
function bienBan() {
  const chuan = soiChuan();
  const anh = soiTiengAnh();
  const hong = maTran.soiHong();
  const nangNhat = chuan.filter((c) => c.tiLeHong > 0);
  return {
    luc: Date.now(),
    soChuan: CHUAN.length,
    soTang: LEVELS.length,
    soO: hong.soO,
    soOHong: hong.soOHong,
    chuan,
    tiengAnh: anh,
    nangNhat,
    dat: nangNhat.length === 0 && anh.kyNangTrong.length === 0,
    ketLuan: nangNhat.length === 0
      ? 'Mọi phần của mọi hệ chuẩn đều có dạng bài tương ứng.'
      : `${nangNhat.length} hệ chuẩn còn phần chương trình chưa dạy: `
        + nangNhat.map((c) => `${c.ngan} thiếu ${c.tiLeHong}% số câu`).join(' · '),
  };
}

module.exports = { soiChuan, soiTiengAnh, bienBan };
