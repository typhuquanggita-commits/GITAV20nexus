'use strict';
/**
 * CHÂN DUNG HỌC VIÊN — hồ sơ tổng hợp, cập nhật liên tục từ 4 lớp quan sát.
 * Đây là cái mà Super Admin, giáo viên và agent cùng nhìn để ra quyết định.
 */

const { round, clamp } = require('../utils');
const { FORM_INDEX, LEVELS, blockOfGrade, formsForLevel } = require('../curriculum/hierarchy');
const standards = require('../curriculum/standards');

class ProfileStore {
  /**
   * @param {object} o
   * @param {object} [o.repo] Kho bền vững cho học viên. Có repo thì hồ sơ sống
   *   sót khởi động lại VÀ dùng chung một nguồn với lớp học, nhập/xuất, báo cáo.
   *   Trước đây hồ sơ chỉ nằm trong bộ nhớ còn lớp học đọc từ kho — hai bên
   *   nhìn thấy hai tập học viên khác nhau, biên chế vào lớp luôn báo không tìm thấy.
   */
  constructor({ telemetry, mastery, repo = null }) {
    this.telemetry = telemetry;
    this.mastery = mastery;
    this.repo = repo;
    this.learners = new Map();
    if (repo) for (const d of repo.all()) this.learners.set(d.userId || d.id, this._hydrate(d));
  }

  _hydrate(doc) {
    return {
      levelHistory: [], exitExams: {}, notes: [], sessionsPassedAtLevel: 0,
      ...doc,
      userId: doc.userId || doc.id,
      currentLevel: doc.currentLevel ?? doc.level ?? 0,
    };
  }

  /** Ghi hồ sơ xuống kho. Gọi sau mỗi lần đổi thứ đáng giữ (tầng, biên chế…). */
  save(userId) {
    if (!this.repo) return { ok: false, error: 'NO_REPO' };
    const rec = this.learners.get(userId);
    if (!rec) return { ok: false, error: 'NOT_FOUND' };
    const prev = this.repo.get(userId) || {};
    this.repo.put({
      ...prev,
      ...rec,
      id: userId,
      userId,
      level: rec.currentLevel ?? 0,     // tên trường mà lớp học và báo cáo dùng
    });
    return { ok: true, userId };
  }

  persistAll() {
    if (!this.repo) return { ok: false, error: 'NO_REPO' };
    let n = 0;
    for (const id of this.learners.keys()) { this.save(id); n++; }
    return { ok: true, saved: n };
  }

  register(userId, { fullName, grade, targetTrack = 'math', targetLevel = 5, startedAt = Date.now() } = {}) {
    if (!userId || !String(userId).trim()) return { ok: false, error: 'MISSING_INPUT', need: ['userId'] };
    userId = String(userId).trim();
    const block = typeof grade === 'number' ? blockOfGrade(grade) : null;
    const rec = {
      userId,
      fullName: fullName || userId,
      grade,
      block,
      targetTrack,
      targetLevel,
      currentLevel: 0,
      startedAt,
      levelHistory: [],
      exitExams: {},          // level -> score 0..1
      sessionsPassedAtLevel: 0,
      notes: [],
    };
    this.learners.set(userId, rec);
    this.save(userId);
    return { ok: true, learner: rec };
  }

  get(userId) {
    const hit = this.learners.get(userId);
    if (hit) return hit;
    // Có trong kho mà chưa nạp vào bộ nhớ (vừa khởi động lại, hoặc được tạo
    // từ luồng nhập tệp) thì nạp lên chứ không báo là không có.
    const doc = this.repo?.get(userId);
    if (!doc) return null;
    const rec = this._hydrate(doc);
    this.learners.set(userId, rec);
    return rec;
  }

  /** Bằng chứng để chấm chuẩn tầng. */
  evidence(userId, level) {
    const rec = this.get(userId);
    if (!rec) return null;
    const attempts = this.telemetry.attemptsOf(userId).map((a) => ({
      formCode: a.formCode, correct: a.correct, ms: a.ms, at: a.at,
    }));
    const lowerLevelStatus = [];
    for (let l = 0; l < level; l++) {
      const r = standards.evaluate(l, {
        masteryByForm: this.mastery.map(userId),
        attempts,
        sessionsPassed: rec.sessionsPassedAtLevel,
        exitExamScore: rec.exitExams[l] ?? 0,
        lowerLevelStatus: [],
      });
      lowerLevelStatus.push({ level: l, meets: r.ok });
    }
    return {
      masteryByForm: this.mastery.map(userId),
      attempts,
      sessionsPassed: rec.sessionsPassedAtLevel,
      exitExamScore: rec.exitExams[level] ?? 0,
      lowerLevelStatus,
    };
  }

  /** Chấm điều kiện lên tầng hiện tại. */
  evaluateLevel(userId, level = null) {
    const rec = this.get(userId);
    if (!rec) return { ok: false, error: 'LEARNER_NOT_FOUND' };
    const lv = level ?? rec.currentLevel;
    return standards.evaluate(lv, this.evidence(userId, lv));
  }

  /** Lên tầng — CHỈ khi đủ cả 7 tiêu chí. Không có ngoại lệ, không có duyệt tay. */
  promote(userId) {
    const rec = this.get(userId);
    if (!rec) return { ok: false, error: 'LEARNER_NOT_FOUND' };
    const ev = this.evaluateLevel(userId);
    if (!ev.ok) return { ok: false, error: 'STANDARDS_NOT_MET', evaluation: ev };
    if (rec.currentLevel >= LEVELS.length - 1) return { ok: false, error: 'MAX_LEVEL' };

    const from = rec.currentLevel;
    rec.currentLevel++;
    rec.sessionsPassedAtLevel = 0;
    rec.levelHistory.push({ from, to: rec.currentLevel, at: Date.now(), score: ev.score });
    return { ok: true, from, to: rec.currentLevel, levelName: LEVELS[rec.currentLevel].name };
  }

  recordExitExam(userId, level, score01) {
    const rec = this.get(userId);
    if (!rec) return { ok: false, error: 'LEARNER_NOT_FOUND' };
    rec.exitExams[level] = clamp(score01, 0, 1);
    return { ok: true, level, score: rec.exitExams[level] };
  }

  recordSessionPassed(userId, passed) {
    const rec = this.get(userId);
    if (!rec) return { ok: false, error: 'LEARNER_NOT_FOUND' };
    rec.sessionsPassedAtLevel = passed ? rec.sessionsPassedAtLevel + 1 : 0;
    return { ok: true, consecutive: rec.sessionsPassedAtLevel };
  }

  /** ── CHÂN DUNG ĐẦY ĐỦ ───────────────────────────────────────────────── */
  portrait(userId) {
    const rec = this.get(userId);
    if (!rec) return { ok: false, error: 'LEARNER_NOT_FOUND' };

    const beh = this.telemetry.behaviors(userId);
    const m = beh.metrics;
    const mas = this.mastery.summary(userId);
    const ev = this.evaluateLevel(userId);
    const lv = LEVELS[rec.currentLevel];
    const levelForms = formsForLevel(rec.currentLevel);

    // Sáu trục năng lực, mỗi trục 0..1 — dùng vẽ radar trên giao diện
    const axes = {
      kienThuc: round(mas.avgMastery, 3),
      chinhXac: round(m.accuracy || 0, 3),
      tocDo: round(clamp(m.medianSpeedRatio ? 1 / Math.max(m.medianSpeedRatio, 0.2) : 0, 0, 1), 3),
      tuLuc: round(clamp(1 - (m.hintRate || 0), 0, 1), 3),
      kienTri: round(clamp(1 - (m.skipRate || 0), 0, 1), 3),
      chieuSau: round(clamp((m.avgThinkingSteps || 0) / 5, 0, 1), 3),
    };
    const overall = round(Object.values(axes).reduce((a, b) => a + b, 0) / 6, 3);

    const strengths = this.mastery.zpd(userId, { lo: 0.85, hi: 1.01, limit: 5 })
      .map((x) => ({ formCode: x.formCode, name: FORM_INDEX.get(x.formCode)?.name, p: x.p }));

    return {
      ok: true,
      // ── Định danh ──
      userId: rec.userId,
      fullName: rec.fullName,
      grade: rec.grade,
      block: rec.block,
      targetTrack: rec.targetTrack,
      daysEnrolled: round((Date.now() - rec.startedAt) / 86400000, 1),

      // ── Vị trí hiện tại ──
      level: { id: rec.currentLevel, code: lv.code, name: lv.name, desc: lv.desc },
      targetLevel: rec.targetLevel,
      formsAtLevel: levelForms.length,
      levelHistory: rec.levelHistory,

      // ── Sáu trục năng lực ──
      axes,
      overall,
      grade5Star: overall >= 0.9 ? 5 : overall >= 0.78 ? 4 : overall >= 0.62 ? 3 : overall >= 0.45 ? 2 : 1,
      levelName: lv ? `${lv.code} — ${lv.name}` : null,
      // Mức thạo từng dạng kèm tên dạng — giao diện học viên và giáo viên đều
      // cần bảng này, không nên bắt mỗi bên tự tra lại danh mục.
      masteryByForm: this.mastery.map(userId),
      formNames: Object.fromEntries(Object.keys(this.mastery.map(userId))
        .map((c) => [c, FORM_INDEX.get(c)?.name || c])),

      // ── Điều kiện lên tầng ──
      promotion: {
        ready: ev.ok,
        score: ev.score,
        failed: ev.failed,
        verdict: ev.verdict,
        criteria: ev.criteria,
      },

      // ── Học lực chi tiết ──
      mastery: mas,
      strengths,
      weaknesses: this.mastery.weakest(userId, 5),
      dueForReview: this.mastery.due(userId, { limit: 10 }),
      zpd: this.mastery.zpd(userId, { limit: 8 }),

      // ── Hành vi & suy nghĩ ──
      behaviorMetrics: m,
      behaviors: beh.behaviors,
      misconceptions: this.telemetry.topMisconceptions(userId, 8),

      // ── Khuyến nghị đối ứng ──
      recommendations: this._recommend(rec, beh, ev),
    };
  }

  _recommend(rec, beh, ev) {
    const out = [];
    for (const b of beh.behaviors) out.push({ source: 'hành vi', trigger: b.name, action: b.advice });
    if (!ev.ok) {
      for (const g of standards.gaps(rec.currentLevel, this.evidence(rec.userId, rec.currentLevel)).gaps || []) {
        out.push({ source: 'chuẩn tầng', trigger: g.criterion, action: g.action });
      }
    }
    const weak = this.mastery.weakest(rec.userId, 3);
    for (const w of weak) {
      if (w.p < 0.5) out.push({ source: 'học lực', trigger: w.formName || w.formCode, action: `Ưu tiên luyện lại dạng ${w.formCode} (mức thạo ${w.p})` });
    }
    return out;
  }

  list({ limit = 50 } = {}) {
    return [...this.learners.values()].slice(0, limit).map((r) => ({
      userId: r.userId, fullName: r.fullName, grade: r.grade, level: r.currentLevel, targetLevel: r.targetLevel,
    }));
  }

  status() {
    const byLevel = Object.create(null);
    for (const r of this.learners.values()) byLevel[r.currentLevel] = (byLevel[r.currentLevel] || 0) + 1;
    return { learners: this.learners.size, byLevel };
  }
}

module.exports = ProfileStore;
