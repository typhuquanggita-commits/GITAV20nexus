'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  CHU KỲ 90 NGÀY — ba chặng, có mốc đo, kết chu kỳ thì DỊCH CHUYỂN CHIẾN LƯỢC
 * ═══════════════════════════════════════════════════════════════════════════
 *   Chặng 1 (ngày 1–30)  NỀN TẢNG    vá lỗ hổng, đóng bẫy hay mắc
 *   Chặng 2 (ngày 31–60) TĂNG TỐC    mở rộng độ phủ dạng, nâng tốc độ
 *   Chặng 3 (ngày 61–90) BỨT PHÁ     bài khó, thi thử, chốt tầng
 *
 *  Cuối mỗi chu kỳ: so sánh trước/sau trên 6 trục, đối chiếu mục tiêu,
 *  rồi CHỌN CHIẾN LƯỢC CHO CHU KỲ SAU theo luật tường minh (không đoán).
 * ═══════════════════════════════════════════════════════════════════════════
 */

const bus = require('../kernel/eventbus');
const { round, clamp, id: newId } = require('../utils');
const { FORM_INDEX, formsForLevel, LEVELS } = require('../curriculum/hierarchy');
const standards = require('../curriculum/standards');

const PHASES = [
  {
    id: 1, name: 'Nền tảng', days: [1, 30],
    goal: 'Vá lỗ hổng và đóng các bẫy sai hay mắc',
    mix: { review: 0.45, weak: 0.40, new: 0.15 },   // tỉ lệ bài ôn / bài yếu / bài mới
    starMix: { 1: 0.15, 2: 0.35, 3: 0.35, 4: 0.15, 5: 0 },
    targets: { accuracy: 0.75, coverage: 0.60, misconceptionDrop: 0.40 },
  },
  {
    id: 2, name: 'Tăng tốc', days: [31, 60],
    goal: 'Mở rộng độ phủ dạng và rút ngắn thời gian làm bài',
    mix: { review: 0.25, weak: 0.30, new: 0.45 },
    starMix: { 1: 0.05, 2: 0.20, 3: 0.40, 4: 0.30, 5: 0.05 },
    targets: { accuracy: 0.80, coverage: 0.80, speedRatio: 1.2 },
  },
  {
    id: 3, name: 'Bứt phá', days: [61, 90],
    goal: 'Bài khó, thi thử, đủ điều kiện chốt tầng',
    mix: { review: 0.20, weak: 0.20, new: 0.60 },
    starMix: { 1: 0, 2: 0.10, 3: 0.30, 4: 0.40, 5: 0.20 },
    targets: { accuracy: 0.85, coverage: 0.90, exitExam: 0.80 },
  },
];

/**
 * Luật dịch chuyển chiến lược. Xét theo thứ tự, luật đầu tiên khớp thì áp dụng.
 * Mỗi luật nêu rõ điều kiện đo được và hành động cụ thể cho chu kỳ sau.
 */
const STRATEGY_RULES = [
  {
    id: 'S1_SUA_NEN',
    when: (d) => d.accuracy < 0.6,
    name: 'Quay lại củng cố nền',
    shift: { levelDelta: -1, mix: { review: 0.55, weak: 0.35, new: 0.10 }, starCap: 3 },
    reason: 'Tỉ lệ đúng dưới 60% — học tiếp ở tầng hiện tại sẽ tích lỗ hổng',
  },
  {
    id: 'S2_DONG_BAY',
    when: (d) => d.misconceptionRate > 0.35,
    name: 'Chiến dịch đóng bẫy',
    shift: { levelDelta: 0, mix: { review: 0.30, weak: 0.55, new: 0.15 }, focusMisconceptions: true },
    reason: 'Hơn 35% lượt sai rơi vào đúng các bẫy đã biết của dạng',
  },
  {
    id: 'S3_TU_LUC',
    when: (d) => d.hintRate > 0.5,
    name: 'Cai gợi ý',
    shift: { levelDelta: 0, hintDelaySec: 90, requireWorkBeforeHint: true },
    reason: 'Phụ thuộc gợi ý trên 50% số bài — năng lực thật chưa hình thành',
  },
  {
    id: 'S4_TOC_DO',
    when: (d) => d.accuracy >= 0.8 && d.speedRatio > 1.3,
    name: 'Luyện tốc độ',
    shift: { levelDelta: 0, timedDrills: true, starMixBias: 'giu', sessionCap: 25 },
    reason: 'Làm đúng nhưng chậm hơn chuẩn 30% — nút thắt là tốc độ, không phải kiến thức',
  },
  {
    id: 'S5_MO_RONG',
    when: (d) => d.accuracy >= 0.8 && d.coverage < 0.7,
    name: 'Mở rộng độ phủ',
    shift: { levelDelta: 0, mix: { review: 0.15, weak: 0.25, new: 0.60 } },
    reason: 'Làm tốt nhưng mới chạm dưới 70% số dạng của tầng',
  },
  {
    id: 'S6_LEN_TANG',
    when: (d) => d.promotionReady,
    name: 'Lên tầng',
    shift: { levelDelta: +1, mix: { review: 0.30, weak: 0.25, new: 0.45 } },
    reason: 'Đã đạt đủ 7 tiêu chuẩn của tầng hiện tại',
  },
  {
    id: 'S7_NANG_DO_KHO',
    when: (d) => d.accuracy >= 0.9 && d.speedRatio <= 1.0,
    name: 'Nâng độ khó',
    shift: { levelDelta: 0, starMixBias: 'kho', starFloor: 3 },
    reason: 'Đúng trên 90% và nhanh hơn chuẩn — bài hiện tại đã quá dễ',
  },
  {
    id: 'S8_GIU_NHIP',
    when: () => true,
    name: 'Giữ nhịp',
    shift: { levelDelta: 0 },
    reason: 'Các chỉ số trong vùng bình thường, tiếp tục kế hoạch hiện tại',
  },
];

class Cycle90 {
  constructor({ telemetry, mastery, profiles }) {
    this.telemetry = telemetry;
    this.mastery = mastery;
    this.profiles = profiles;
    this.cycles = new Map(); // userId -> [cycle]
  }

  _list(userId) {
    if (!this.cycles.has(userId)) this.cycles.set(userId, []);
    return this.cycles.get(userId);
  }

  /** Mở chu kỳ mới. Nếu có chu kỳ trước thì kế thừa chiến lược đã chọn. */
  start(userId, { startAt = Date.now(), strategy = null } = {}) {
    const p = this.profiles.get(userId);
    if (!p) return { ok: false, error: 'LEARNER_NOT_FOUND' };
    const list = this._list(userId);
    const prev = list[list.length - 1];
    if (prev && !prev.closedAt) return { ok: false, error: 'CYCLE_ALREADY_OPEN', cycleId: prev.id };

    const cycle = {
      id: newId('CY'),
      index: list.length + 1,
      userId,
      startAt,
      endAt: startAt + 90 * 86400000,
      closedAt: null,
      levelAtStart: p.currentLevel,
      strategy: strategy || prev?.nextStrategy || STRATEGY_RULES.find((r) => r.id === 'S8_GIU_NHIP'),
      baseline: this._snapshotMetrics(userId),
      phaseLog: [],
      nextStrategy: null,
    };
    list.push(cycle);
    bus.safeEmit('cycle90:started', { userId, cycleId: cycle.id, index: cycle.index });
    return { ok: true, cycle: this.view(userId) };
  }

  _snapshotMetrics(userId) {
    const b = this.telemetry.behaviors(userId);
    const m = b.metrics;
    const p = this.profiles.get(userId);
    const level = p ? p.currentLevel : 0;
    const forms = formsForLevel(level).map((f) => f.code);
    const mm = this.mastery.map(userId);
    const std = standards.standardFor(level);
    const mastered = forms.filter((c) => (mm[c] ?? 0) >= (std?.mastery ?? 0.85)).length;

    const attempts = this.telemetry.attemptsOf(userId);
    const wrong = attempts.filter((a) => !a.correct);
    const withMis = wrong.filter((a) => (a.thinking?.misconceptions || []).length > 0);

    return {
      at: Date.now(),
      level,
      accuracy: m.accuracy || 0,
      hintRate: m.hintRate || 0,
      skipRate: m.skipRate || 0,
      speedRatio: m.medianSpeedRatio || 0,
      coverage: forms.length ? round(mastered / forms.length, 3) : 0,
      avgMastery: this.mastery.summary(userId).avgMastery,
      misconceptionRate: attempts.length ? round(withMis.length / attempts.length, 3) : 0,
      items: attempts.length,
      sessions: m.sessions || 0,
    };
  }

  /** Chặng hiện tại theo số ngày đã trôi. */
  currentPhase(cycle, now = Date.now()) {
    const day = Math.floor((now - cycle.startAt) / 86400000) + 1;
    const phase = PHASES.find((p) => day >= p.days[0] && day <= p.days[1]) || PHASES[PHASES.length - 1];
    return { day: clamp(day, 1, 90), phase, daysLeft: Math.max(0, 90 - day) };
  }

  /** Kế hoạch buổi học hôm nay: trộn bài theo chặng + chiến lược đang áp dụng. */
  todayPlan(userId, { itemsPerSession = 20 } = {}) {
    const list = this._list(userId);
    const cycle = list[list.length - 1];
    if (!cycle || cycle.closedAt) return { ok: false, error: 'NO_OPEN_CYCLE' };

    const { day, phase, daysLeft } = this.currentPhase(cycle);
    const sh = cycle.strategy?.shift || {};
    const mix = sh.mix || phase.mix;
    const level = clamp((this.profiles.get(userId)?.currentLevel ?? 0), 0, LEVELS.length - 1);

    const due = this.mastery.due(userId, { limit: 50 }).map((x) => x.formCode);
    const weak = this.mastery.weakest(userId, 20).map((x) => x.formCode);
    const levelForms = formsForLevel(level).map((f) => f.code);
    const seen = new Set([...due, ...weak]);
    const fresh = levelForms.filter((c) => !seen.has(c));

    const take = (arr, n) => arr.slice(0, Math.max(0, n));
    const nReview = Math.round(itemsPerSession * mix.review);
    const nWeak = Math.round(itemsPerSession * mix.weak);
    const nNew = itemsPerSession - nReview - nWeak;

    // Phân bổ độ khó: theo chặng, có điều chỉnh bởi chiến lược
    const starMix = { ...phase.starMix };
    if (sh.starCap) for (const s of Object.keys(starMix)) if (Number(s) > sh.starCap) starMix[s] = 0;
    if (sh.starFloor) for (const s of Object.keys(starMix)) if (Number(s) < sh.starFloor) starMix[s] = 0;
    if (sh.starMixBias === 'kho') { starMix[4] = (starMix[4] || 0) + 0.15; starMix[5] = (starMix[5] || 0) + 0.10; }
    const total = Object.values(starMix).reduce((a, b) => a + b, 0) || 1;
    for (const s of Object.keys(starMix)) starMix[s] = round(starMix[s] / total, 3);

    const focusTraps = sh.focusMisconceptions
      ? this.telemetry.topMisconceptions(userId, 5)
      : [];

    return {
      ok: true,
      cycleId: cycle.id,
      cycleIndex: cycle.index,
      day, daysLeft,
      phase: { id: phase.id, name: phase.name, goal: phase.goal },
      strategy: { id: cycle.strategy?.id, name: cycle.strategy?.name, reason: cycle.strategy?.reason },
      level,
      itemsPerSession,
      composition: {
        review: { count: nReview, forms: take(due, nReview) },
        weak: { count: nWeak, forms: take(weak, nWeak) },
        new: { count: nNew, forms: take(fresh, nNew) },
      },
      starMix,
      constraints: {
        hintDelaySec: sh.hintDelaySec || 0,
        requireWorkBeforeHint: !!sh.requireWorkBeforeHint,
        timedDrills: !!sh.timedDrills,
        sessionCap: sh.sessionCap || null,
      },
      focusTraps,
      phaseTargets: phase.targets,
    };
  }

  /** Ghi mốc cuối mỗi chặng để so sánh về sau. */
  logPhase(userId) {
    const list = this._list(userId);
    const cycle = list[list.length - 1];
    if (!cycle || cycle.closedAt) return { ok: false, error: 'NO_OPEN_CYCLE' };
    const { day, phase } = this.currentPhase(cycle);
    cycle.phaseLog.push({ at: Date.now(), day, phaseId: phase.id, metrics: this._snapshotMetrics(userId) });
    return { ok: true, logged: cycle.phaseLog.length };
  }

  /** Chọn chiến lược cho chu kỳ sau theo luật — tường minh, kiểm chứng được. */
  decideStrategy(userId) {
    const m = this._snapshotMetrics(userId);
    const promo = this.profiles.evaluateLevel(userId);
    const d = { ...m, promotionReady: !!promo.ok };
    const rule = STRATEGY_RULES.find((r) => r.when(d));
    return { rule, decisionInput: d, allRulesEvaluated: STRATEGY_RULES.map((r) => ({ id: r.id, matched: r.when(d) })) };
  }

  /** Đóng chu kỳ: so sánh trước/sau, kết luận, chọn chiến lược kế tiếp. */
  close(userId) {
    const list = this._list(userId);
    const cycle = list[list.length - 1];
    if (!cycle || cycle.closedAt) return { ok: false, error: 'NO_OPEN_CYCLE' };

    const final = this._snapshotMetrics(userId);
    const base = cycle.baseline;
    const delta = {};
    for (const k of ['accuracy', 'coverage', 'avgMastery', 'speedRatio', 'hintRate', 'skipRate', 'misconceptionRate']) {
      delta[k] = round((final[k] || 0) - (base[k] || 0), 4);
    }
    // Tiến bộ thật: tăng ở chỉ số càng cao càng tốt, giảm ở chỉ số càng thấp càng tốt
    const improved = (delta.accuracy > 0.03) + (delta.coverage > 0.05) + (delta.avgMastery > 0.05)
      + (delta.speedRatio < -0.05) + (delta.hintRate < -0.05) + (delta.misconceptionRate < -0.05);

    const { rule, decisionInput, allRulesEvaluated } = this.decideStrategy(userId);
    cycle.nextStrategy = rule;
    cycle.closedAt = Date.now();
    cycle.final = final;
    cycle.delta = delta;
    cycle.improvedAxes = improved;
    cycle.levelAtEnd = this.profiles.get(userId)?.currentLevel ?? cycle.levelAtStart;

    bus.safeEmit('cycle90:closed', { userId, cycleId: cycle.id, improved, nextStrategy: rule.id });

    return {
      ok: true,
      cycleId: cycle.id,
      index: cycle.index,
      durationDays: round((cycle.closedAt - cycle.startAt) / 86400000, 1),
      levelAtStart: cycle.levelAtStart,
      levelAtEnd: cycle.levelAtEnd,
      levelGain: cycle.levelAtEnd - cycle.levelAtStart,
      baseline: base,
      final,
      delta,
      improvedAxes: improved,
      outOfAxes: 6,
      verdict: improved >= 4 ? 'XUẤT SẮC' : improved >= 3 ? 'ĐẠT' : improved >= 1 ? 'CẦN ĐIỀU CHỈNH' : 'KHÔNG TIẾN BỘ',
      nextStrategy: { id: rule.id, name: rule.name, reason: rule.reason, shift: rule.shift },
      decisionInput,
      rulesEvaluated: allRulesEvaluated,
    };
  }

  view(userId) {
    const list = this._list(userId);
    const cycle = list[list.length - 1];
    if (!cycle) return { ok: false, error: 'NO_CYCLE' };
    const cur = this.currentPhase(cycle);
    return {
      ok: true,
      cycleId: cycle.id,
      index: cycle.index,
      open: !cycle.closedAt,
      startAt: new Date(cycle.startAt).toISOString(),
      endAt: new Date(cycle.endAt).toISOString(),
      day: cur.day,
      daysLeft: cur.daysLeft,
      phase: cur.phase,
      strategy: cycle.strategy,
      levelAtStart: cycle.levelAtStart,
      baseline: cycle.baseline,
      phaseLog: cycle.phaseLog,
      history: list.filter((c) => c.closedAt).map((c) => ({
        index: c.index, levelGain: (c.levelAtEnd ?? 0) - c.levelAtStart,
        improvedAxes: c.improvedAxes, nextStrategy: c.nextStrategy?.id,
      })),
    };
  }

  status() {
    let open = 0, closed = 0;
    for (const list of this.cycles.values()) {
      for (const c of list) (c.closedAt ? closed++ : open++);
    }
    return { learners: this.cycles.size, openCycles: open, closedCycles: closed, phases: PHASES.length, strategyRules: STRATEGY_RULES.length };
  }
}

module.exports = Cycle90;
module.exports.PHASES = PHASES;
module.exports.STRATEGY_RULES = STRATEGY_RULES;
