'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  LỘ TRÌNH 90 NGÀY — sinh từ chân dung, chỉnh lại mỗi tuần
 * ═══════════════════════════════════════════════════════════════════════════
 *  Chu kỳ 90 ngày chia 13 tuần. Mỗi tuần có:
 *   · DẠNG TRỌNG TÂM   lấy theo thứ tự tiên quyết, vá lỗ hổng trước
 *   · MỤC TIÊU ĐO ĐƯỢC mức thạo phải đạt, không phải "cố gắng hơn"
 *   · KHỐI LƯỢNG      số buổi và số bài mỗi buổi, lấy từ NGƯỠNG CHÚ Ý đo được
 *   · MỐC KIỂM        tuần 4, 8, 13 có bài kiểm; tuần 13 là thi cuối tầng
 *
 *  Lộ trình KHÔNG cố định. Mỗi tuần hệ thống đối chiếu thực tế với kế hoạch
 *  rồi chỉnh phần còn lại: chậm thì giãn, nhanh thì siết, sai nhiều thì lùi.
 *  Mỗi lần chỉnh đều ghi lý do, để sau này còn xem lại được vì sao đổi.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const bus = require('../kernel/eventbus');
const { id: newId, round, clamp } = require('../utils');
const { LEVELS, FORM_INDEX, formsForLevel, learningOrder } = require('../curriculum/hierarchy');
const { standardFor } = require('../curriculum/standards');
const { MASTERY_THRESHOLD } = require('./mastery');

const WEEKS = 13;
const CHECKPOINT_WEEKS = [4, 8, 13];
const DEFAULT_SESSIONS_PER_WEEK = 4;
const MIN_ITEMS = 6;
const MAX_ITEMS = 20;

/** Ba chặng của chu kỳ, ánh xạ sang tuần. */
const STAGES = [
  { id: 1, name: 'Nền tảng', weeks: [1, 4], goal: 'Vá lỗ hổng, đóng bẫy sai hay mắc', newShare: 0.15 },
  { id: 2, name: 'Tăng tốc', weeks: [5, 9], goal: 'Mở rộng độ phủ dạng, rút ngắn thời gian', newShare: 0.45 },
  { id: 3, name: 'Kết tinh', weeks: [10, 13], goal: 'Luyện đề tổng hợp, ổn định phong độ trước kỳ thi', newShare: 0.20 },
];

const stageOfWeek = (w) => STAGES.find((s) => w >= s.weeks[0] && w <= s.weeks[1]) || STAGES[STAGES.length - 1];

class RoadmapService {
  constructor({ profiles, mastery, telemetry, behavior = null, bank = null, practices = null, audit = null }) {
    this.profiles = profiles;
    this.mastery = mastery;
    this.telemetry = telemetry;
    this.behavior = behavior;
    this.bank = bank;
    this.practices = practices;
    this.audit = audit;
    this.roadmaps = new Map();      // learnerId -> roadmap
    this.stats = { generated: 0, reviewed: 0, adjusted: 0 };
  }

  // ── Sinh lộ trình ────────────────────────────────────────────────────────

  /**
   * @param {object} o {learnerId, startAt, sessionsPerWeek, targetLevel}
   */
  generate({ learnerId, startAt = Date.now(), sessionsPerWeek = DEFAULT_SESSIONS_PER_WEEK, targetLevel = null } = {}) {
    const rec = this.profiles?.get(learnerId);
    if (!rec) return { ok: false, error: 'LEARNER_NOT_FOUND' };

    const level = rec.currentLevel ?? 0;
    const target = clamp(targetLevel ?? (level + 1), 0, 9);
    const mastMap = this.mastery?.map(learnerId) || {};

    // 1. Dạng phải học trong chu kỳ: lỗ hổng tiên quyết trước, rồi dạng của tầng.
    // Dạng "thuộc về" tầng này: dạng BẮT ĐẦU xuất hiện ở tầng hiện tại hoặc
    // ngay trước đó. Một dạng lớp 1 tuy vẫn "hợp tầng 3" nhưng không phải việc
    // của chu kỳ này — đưa vào chỉ làm loãng lộ trình.
    const levelForms = formsForLevel(level)
      .filter((f) => f.levelRange[0] >= level - 1)
      .map((f) => f.code);

    // Lỗ hổng: tiên quyết của những dạng sắp học mà mức thạo ĐO ĐƯỢC còn thấp.
    const gapForms = new Set();
    for (const c of levelForms) {
      for (const pr of FORM_INDEX.get(c)?.prereq || []) {
        if (FORM_INDEX.has(pr) && (mastMap[pr] ?? 0) < MASTERY_THRESHOLD) gapForms.add(pr);
      }
    }
    const notYet = levelForms.filter((c) => (mastMap[c] ?? 0) < MASTERY_THRESHOLD);
    const wanted = learningOrder([...gapForms, ...notYet]).order;

    // Cắt theo SỨC CHỨA THẬT: mỗi dạng cần tối thiểu ~12 bài mới thạo được.
    // Ôm hết rồi học qua loa là tự lừa mình; phần dư để sang chu kỳ sau.
    const itemBudget = sessionsPerWeek * WEEKS * (this.behavior?.attentionSpan(learnerId)?.enough
      ? clamp(this.behavior.attentionSpan(learnerId).recommendedSessionItems, MIN_ITEMS, MAX_ITEMS)
      : 12);
    const capacityForms = Math.max(3, Math.floor(itemBudget / 12));
    const ordered = wanted.slice(0, capacityForms);
    const deferred = wanted.slice(capacityForms);

    // 2. Khối lượng mỗi buổi: lấy từ ngưỡng chú ý ĐO ĐƯỢC, không đoán.
    const attention = this.behavior?.attentionSpan(learnerId);
    const itemsPerSession = attention?.enough
      ? clamp(attention.recommendedSessionItems, MIN_ITEMS, MAX_ITEMS)
      : 12;
    const attentionNote = attention?.enough
      ? `Số bài mỗi buổi lấy theo ngưỡng chú ý đo được: ${attention.evidence}`
      : 'Chưa đủ dữ liệu để đo ngưỡng chú ý — tạm dùng 12 bài/buổi, sẽ chỉnh sau tuần đầu.';

    // 3. Rải dạng vào 13 tuần. Tuần mốc dành chỗ cho kiểm tra nên nhận ít dạng mới hơn.
    const capacity = [];
    for (let w = 1; w <= WEEKS; w++) {
      const st = stageOfWeek(w);
      const isCheck = CHECKPOINT_WEEKS.includes(w);
      capacity.push({ week: w, stage: st, slots: isCheck ? 1 : (st.id === 1 ? 2 : 3), isCheck });
    }
    const totalSlots = capacity.reduce((s, c) => s + c.slots, 0);
    const perSlot = Math.max(1, Math.ceil(ordered.length / totalSlots));

    const weeks = [];
    let cursor = 0;
    for (const cap of capacity) {
      const focus = [];
      for (let k = 0; k < cap.slots && cursor < ordered.length; k++) {
        for (let j = 0; j < perSlot && cursor < ordered.length; j++) focus.push(ordered[cursor++]);
      }
      const std = standardFor(level);
      const week = {
        week: cap.week,
        stage: { id: cap.stage.id, name: cap.stage.name, goal: cap.stage.goal },
        focusForms: focus.map((c) => ({
          code: c,
          name: FORM_INDEX.get(c)?.name || c,
          startingMastery: round(mastMap[c] ?? 0, 3),
          isGap: gapForms.has(c),
        })),
        sessions: sessionsPerWeek,
        itemsPerSession,
        totalItems: sessionsPerWeek * itemsPerSession,
        newShare: cap.stage.newShare,
        targetMastery: round(clamp(0.55 + 0.03 * cap.week, 0, std?.mastery ?? 0.85), 3),
        targetAccuracy: round(clamp(0.6 + 0.02 * cap.week, 0, 0.95), 3),
        checkpoint: cap.isCheck
          ? (cap.week === WEEKS
            ? { kind: 'EXIT_EXAM', note: `Thi cuối tầng ${LEVELS[level].code} để xét lên ${LEVELS[target].code}` }
            : { kind: 'PROGRESS_TEST', note: `Kiểm tra giữa chặng ${cap.stage.name}` })
          : null,
        status: 'PLANNED',
      };
      weeks.push(week);
    }

    const leftover = [...ordered.slice(cursor), ...deferred];
    const roadmap = {
      id: newId('RM'),
      learnerId,
      level,
      levelName: `${LEVELS[level].code} — ${LEVELS[level].name}`,
      targetLevel: target,
      targetLevelName: `${LEVELS[target].code} — ${LEVELS[target].name}`,
      startAt,
      endAt: startAt + 90 * 86400000,
      sessionsPerWeek,
      itemsPerSession,
      attentionNote,
      formsPlanned: ordered.length,
      formsWanted: wanted.length,
      formsDeferred: deferred.length,
      gapForms: [...gapForms].filter((c) => ordered.includes(c)),
      weeks,
      leftoverForms: leftover,
      adjustments: [],
      createdAt: Date.now(),
      feasibility: this._feasibility(ordered.length, sessionsPerWeek * itemsPerSession * WEEKS, leftover.length, wanted.length),
    };

    this.roadmaps.set(learnerId, roadmap);
    this.stats.generated++;
    this.audit?.record({
      actor: learnerId, action: 'roadmap.generated', verdict: 'ALLOW', severity: 0,
      detail: { roadmapId: roadmap.id, level, forms: ordered.length },
    });
    bus.safeEmit('roadmap:generated', { learnerId, roadmapId: roadmap.id, level });
    return { ok: true, ...roadmap };
  }

  /** Lộ trình có khả thi không — nói thẳng nếu ôm quá nhiều dạng. */
  _feasibility(formsPlanned, itemBudget, leftover, wanted = null) {
    const itemsPerForm = formsPlanned ? round(itemBudget / formsPlanned, 1) : 0;
    const ok = itemsPerForm >= 12;
    const parts = [];
    parts.push(ok
      ? `Khả thi: ${formsPlanned} dạng, mỗi dạng khoảng ${itemsPerForm} bài.`
      : `Mỗi dạng chỉ được khoảng ${itemsPerForm} bài — quá mỏng để thạo. Nên tăng số buổi mỗi tuần.`);
    if (leftover > 0) {
      parts.push(`Còn ${leftover} dạng${wanted ? ` trên tổng ${wanted}` : ''} phải để sang chu kỳ sau — `
        + `ôm hết trong 90 ngày là học qua loa.`);
    }
    return { ok, itemsPerForm, leftoverForms: leftover, formsWanted: wanted, verdict: parts.join(' ') };
  }

  get(learnerId) { return this.roadmaps.get(learnerId) || null; }

  /** Tuần hiện tại theo mốc bắt đầu. */
  currentWeek(learnerId, now = Date.now()) {
    const rm = this.roadmaps.get(learnerId);
    if (!rm) return null;
    const w = Math.floor((now - rm.startAt) / (7 * 86400000)) + 1;
    return clamp(w, 1, WEEKS);
  }

  /** Việc của tuần này, kèm tiến độ đang tới đâu. */
  thisWeek(learnerId, now = Date.now()) {
    const rm = this.roadmaps.get(learnerId);
    if (!rm) return { ok: false, error: 'NO_ROADMAP' };
    const w = this.currentWeek(learnerId, now);
    const week = rm.weeks[w - 1];
    const mastMap = this.mastery?.map(learnerId) || {};
    return {
      ok: true,
      roadmapId: rm.id,
      week: w,
      weeksLeft: WEEKS - w,
      daysLeft: Math.max(0, Math.ceil((rm.endAt - now) / 86400000)),
      stage: week.stage,
      focusForms: week.focusForms.map((f) => ({
        ...f,
        currentMastery: round(mastMap[f.code] ?? 0, 3),
        reached: (mastMap[f.code] ?? 0) >= week.targetMastery,
      })),
      sessions: week.sessions,
      itemsPerSession: week.itemsPerSession,
      targetMastery: week.targetMastery,
      targetAccuracy: week.targetAccuracy,
      checkpoint: week.checkpoint,
      status: week.status,
    };
  }

  // ── Rà soát và chỉnh hằng tuần ───────────────────────────────────────────

  /**
   * Đối chiếu thực tế với kế hoạch rồi chỉnh phần còn lại. Mỗi lần chỉnh ghi lý do.
   */
  weeklyReview(learnerId, { week = null, now = Date.now() } = {}) {
    const rm = this.roadmaps.get(learnerId);
    if (!rm) return { ok: false, error: 'NO_ROADMAP' };
    const w = week ?? this.currentWeek(learnerId, now);
    const target = rm.weeks[w - 1];
    if (!target) return { ok: false, error: 'INVALID_WEEK', week: w };

    this.stats.reviewed++;
    const mastMap = this.mastery?.map(learnerId) || {};
    const since = rm.startAt + (w - 1) * 7 * 86400000;
    const attempts = (this.telemetry?.attemptsOf(learnerId) || []).filter((a) => (a.at || 0) >= since && (a.at || 0) < since + 7 * 86400000);

    const done = attempts.length;
    const planned = target.totalItems;
    const accuracy = done ? round(attempts.filter((a) => a.correct).length / done, 3) : 0;
    const reached = target.focusForms.filter((f) => (mastMap[f.code] ?? 0) >= target.targetMastery);
    const stuck = target.focusForms.filter((f) => (mastMap[f.code] ?? 0) < target.targetMastery * 0.6);

    const volumeRatio = planned ? round(done / planned, 3) : 0;
    const verdict = volumeRatio >= 0.8 && accuracy >= target.targetAccuracy ? 'ĐÚNG TIẾN ĐỘ'
      : volumeRatio < 0.5 ? 'CHẬM TIẾN ĐỘ'
        : accuracy < target.targetAccuracy * 0.8 ? 'LÀM ĐỦ NHƯNG CHƯA VỮNG'
          : 'CẦN THEO DÕI THÊM';

    const changes = [];

    // a) Làm quá ít → giãn dạng sang các tuần sau, đừng dồn cục
    if (volumeRatio < 0.5 && done >= 0) {
      const moved = target.focusForms.filter((f) => !reached.some((r) => r.code === f.code));
      if (moved.length && w < WEEKS) {
        rm.weeks[w].focusForms = [...rm.weeks[w].focusForms, ...moved];
        changes.push({
          kind: 'DỜI_DẠNG',
          detail: `Dời ${moved.length} dạng chưa đạt sang tuần ${w + 1}.`,
          reason: `Tuần ${w} chỉ làm ${done}/${planned} bài (${Math.round(volumeRatio * 100)}%).`,
        });
      }
    }

    // b) Sai nhiều → giảm tỉ lệ dạng mới ở các tuần còn lại, tăng ôn
    if (accuracy > 0 && accuracy < target.targetAccuracy * 0.8) {
      for (let i = w; i < WEEKS; i++) {
        rm.weeks[i].newShare = round(Math.max(0.05, rm.weeks[i].newShare - 0.15), 3);
      }
      changes.push({
        kind: 'GIẢM_DẠNG_MỚI',
        detail: 'Giảm 15% tỉ lệ bài dạng mới cho các tuần còn lại, dồn cho ôn và củng cố.',
        reason: `Độ chính xác tuần ${w} chỉ ${Math.round(accuracy * 100)}%, dưới mục tiêu ${Math.round(target.targetAccuracy * 100)}%.`,
      });
    }

    // c) Vượt tiến độ → nâng độ khó
    if (volumeRatio >= 1 && accuracy >= 0.9) {
      for (let i = w; i < WEEKS; i++) {
        rm.weeks[i].newShare = round(Math.min(0.6, rm.weeks[i].newShare + 0.1), 3);
      }
      changes.push({
        kind: 'TĂNG_DẠNG_MỚI',
        detail: 'Tăng 10% tỉ lệ bài dạng mới cho các tuần còn lại.',
        reason: `Tuần ${w} làm ${done}/${planned} bài, đúng ${Math.round(accuracy * 100)}% — còn dư sức.`,
      });
    }

    // d) Ngưỡng chú ý đã đo được → chỉnh lại số bài mỗi buổi
    const attention = this.behavior?.attentionSpan(learnerId);
    if (attention?.enough) {
      const rec = clamp(attention.recommendedSessionItems, MIN_ITEMS, MAX_ITEMS);
      if (Math.abs(rec - rm.itemsPerSession) >= 2) {
        const from = rm.itemsPerSession;
        rm.itemsPerSession = rec;
        for (let i = w; i < WEEKS; i++) {
          rm.weeks[i].itemsPerSession = rec;
          rm.weeks[i].totalItems = rm.weeks[i].sessions * rec;
        }
        changes.push({
          kind: 'CHỈNH_KHỐI_LƯỢNG',
          detail: `Đổi số bài mỗi buổi từ ${from} sang ${rec}.`,
          reason: attention.evidence,
        });
      }
    }

    // e) Dạng tắc quá lâu → hạ xuống dạng tiên quyết
    for (const f of stuck) {
      const prereq = (FORM_INDEX.get(f.code)?.prereq || []).filter((p) => FORM_INDEX.has(p));
      const weakPrereq = prereq.filter((p) => (mastMap[p] ?? 0) < MASTERY_THRESHOLD);
      if (weakPrereq.length && w < WEEKS) {
        const add = weakPrereq
          .filter((p) => !rm.weeks[w].focusForms.some((x) => x.code === p))
          .map((p) => ({ code: p, name: FORM_INDEX.get(p)?.name || p, startingMastery: round(mastMap[p] ?? 0, 3), isGap: true }));
        if (add.length) {
          rm.weeks[w].focusForms = [...add, ...rm.weeks[w].focusForms];
          changes.push({
            kind: 'LÙI_VỀ_NỀN',
            detail: `Chen dạng tiên quyết vào tuần ${w + 1}: ${add.map((a) => a.name).join('; ')}.`,
            reason: `Dạng "${f.name}" tắc ở mức thạo ${Math.round((mastMap[f.code] ?? 0) * 100)}% — nguyên nhân nằm ở nền.`,
          });
        }
      }
    }

    target.status = verdict === 'ĐÚNG TIẾN ĐỘ' ? 'DONE' : 'BEHIND';
    const review = {
      at: now, week: w, verdict,
      itemsDone: done, itemsPlanned: planned, volumeRatio,
      accuracy, targetAccuracy: target.targetAccuracy,
      formsReached: reached.map((f) => f.code),
      formsStuck: stuck.map((f) => f.code),
      changes,
    };
    rm.adjustments.push(review);
    if (changes.length) this.stats.adjusted++;

    this.audit?.record({
      actor: learnerId, action: 'roadmap.weekly_review', verdict: 'ALLOW', severity: 0,
      detail: { roadmapId: rm.id, week: w, result: verdict, changes: changes.length },
    });
    bus.safeEmit('roadmap:reviewed', { learnerId, week: w, verdict });

    return {
      ok: true,
      roadmapId: rm.id,
      week: w,
      verdict,
      itemsDone: done,
      itemsPlanned: planned,
      volumeRatio,
      accuracy,
      targetAccuracy: target.targetAccuracy,
      formsReached: reached.map((f) => ({ code: f.code, name: f.name })),
      formsStuck: stuck.map((f) => ({ code: f.code, name: f.name, mastery: round(mastMap[f.code] ?? 0, 3) })),
      changes,
      summary: changes.length
        ? `${verdict}. Đã chỉnh ${changes.length} điểm trong lộ trình: ${changes.map((c) => c.detail).join(' ')}`
        : `${verdict}. Lộ trình giữ nguyên.`,
    };
  }

  /** Nhìn lại cả chu kỳ: đã đi được bao nhiêu phần đường. */
  progress(learnerId, now = Date.now()) {
    const rm = this.roadmaps.get(learnerId);
    if (!rm) return { ok: false, error: 'NO_ROADMAP' };
    const mastMap = this.mastery?.map(learnerId) || {};
    const all = rm.weeks.flatMap((w) => w.focusForms.map((f) => f.code));
    const uniq = [...new Set(all)];
    const mastered = uniq.filter((c) => (mastMap[c] ?? 0) >= MASTERY_THRESHOLD);
    const w = this.currentWeek(learnerId, now);

    return {
      ok: true,
      roadmapId: rm.id,
      week: w,
      weeksLeft: WEEKS - w,
      timeElapsed: round(w / WEEKS, 3),
      formsPlanned: uniq.length,
      formsMastered: mastered.length,
      contentProgress: uniq.length ? round(mastered.length / uniq.length, 3) : 0,
      onTrack: uniq.length ? (mastered.length / uniq.length) >= (w / WEEKS) * 0.8 : null,
      adjustments: rm.adjustments.length,
      checkpoints: rm.weeks.filter((x) => x.checkpoint).map((x) => ({ week: x.week, ...x.checkpoint, status: x.status })),
      feasibility: rm.feasibility,
    };
  }

  status() {
    return {
      ...this.stats,
      roadmaps: this.roadmaps.size,
      weeks: WEEKS,
      checkpointWeeks: CHECKPOINT_WEEKS,
      stages: STAGES.map((s) => ({ id: s.id, name: s.name, weeks: s.weeks })),
    };
  }
}

module.exports = RoadmapService;
module.exports.WEEKS = WEEKS;
module.exports.STAGES = STAGES;
module.exports.CHECKPOINT_WEEKS = CHECKPOINT_WEEKS;
