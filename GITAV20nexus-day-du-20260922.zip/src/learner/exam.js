'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  THI CUỐI TẦNG & QUYẾT ĐỊNH LÊN TẦNG
 * ═══════════════════════════════════════════════════════════════════════════
 *  Đây là cửa ải, không phải thủ tục. Nguyên tắc:
 *
 *   · ĐỀ PHỦ ĐỦ DẠNG của tầng, không dồn vào vài dạng dễ. Mỗi dạng của tầng
 *     đều phải có mặt; thiếu dạng nào thì đề ghi rõ là thiếu.
 *   · ĐỀ TRỘN ĐỘ KHÓ theo ma trận cố định (nhận biết → thách thức), không
 *     phải nhặt bài ngẫu nhiên.
 *   · KHÔNG DÙNG BÀI VỪA LUYỆN. Bài đã làm trong 30 ngày gần nhất bị loại,
 *     nếu không thì đo trí nhớ ngắn hạn chứ không đo năng lực.
 *   · CÓ GIỚI HẠN THỜI GIAN tính từ thời gian chuẩn của từng bài.
 *   · LÊN TẦNG PHẢI ĐỦ CẢ 7 TIÊU CHÍ, không có ngoại lệ, không làm tròn lên.
 *     Điểm thi cao mà thiếu tiêu chí khác thì vẫn KHÔNG lên.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const bus = require('../kernel/eventbus');
const { id: newId, round, clamp } = require('../utils');
const { LEVELS, FORM_INDEX, formsForLevel } = require('../curriculum/hierarchy');
const { evaluate, gaps, standardFor } = require('../curriculum/standards');

/** Tên gọi của từng bậc sao, dùng chung cho mọi ma trận. */
const STAR_NAMES = { 1: 'Nhận biết', 2: 'Thông hiểu', 3: 'Vận dụng', 4: 'Vận dụng cao', 5: 'Thách thức' };

/**
 * MA TRẬN ĐỀ THEO TẦNG.
 *
 * Trước đây mọi tầng dùng chung một ma trận cố định 15/25/30/20/10. Ma trận đó
 * sai ở hai đầu và sai theo hai hướng ngược nhau:
 *
 *   · Ở tầng 0–1 (lớp 1, lớp 2) nó đòi 10% câu "Thách thức". Học viên sáu tuổi
 *     không có câu thách thức nào là đúng chuyên môn; ép cho có thì hoặc phải
 *     bịa ra bài quá sức, hoặc phải gắn nhãn 5 sao cho một bài 3 sao. Cả hai
 *     đều là nói dối về độ khó.
 *   · Ở tầng 7–9 (Chuyên, Tinh hoa, Đỉnh cao) nó vẫn giữ 15% câu "Nhận biết".
 *     Một đề tuyển chọn mà 15% là câu nhắc lại công thức thì không phân loại
 *     được ai, vì gần như mọi thí sinh đều làm đúng phần đó.
 *
 * Nên ma trận được chia theo BỐN CHẶNG, trọng tâm dịch dần từ nhận biết sang
 * thách thức. Trong mỗi chặng tỉ lệ vẫn CỐ ĐỊNH, không đổi theo từng học viên,
 * nên hai người cùng tầng vẫn nhận đề cùng cấu trúc.
 *
 * Tổng mỗi hàng đúng bằng 1 — có kiểm thử giữ ràng buộc này.
 */
const MATRIX_BY_BAND = [
  {
    id: 'KHOI_DONG', levels: [0, 1], name: 'Khởi động và nền tảng',
    why: 'Tầng đầu đo xem học viên có nắm chắc phần cốt lõi không, chưa phải lúc phân loại.',
    rows: [
      { stars: 1, share: 0.35 }, { stars: 2, share: 0.40 }, { stars: 3, share: 0.25 },
    ],
  },
  {
    id: 'VUNG', levels: [2, 3], name: 'Vững và thành thạo',
    why: 'Bắt đầu có câu vận dụng cao để tách người làm được với người mới chỉ thuộc quy trình.',
    rows: [
      { stars: 1, share: 0.20 }, { stars: 2, share: 0.30 }, { stars: 3, share: 0.30 },
      { stars: 4, share: 0.20 },
    ],
  },
  {
    id: 'NANG_CAO', levels: [4, 6], name: 'Nâng cao, giỏi, xuất sắc',
    why: 'Đủ năm bậc. Đây là ma trận gần nhất với đề thi tốt nghiệp và đề thi học sinh giỏi cấp trường.',
    rows: [
      { stars: 1, share: 0.10 }, { stars: 2, share: 0.20 }, { stars: 3, share: 0.30 },
      { stars: 4, share: 0.30 }, { stars: 5, share: 0.10 },
    ],
  },
  {
    id: 'CHUYEN', levels: [7, 9], name: 'Chuyên, tinh hoa, đỉnh cao',
    why: 'Đề tuyển chọn. Phần nhận biết co lại còn một câu để kiểm tra nền, phần thách thức nở ra để phân loại.',
    rows: [
      { stars: 1, share: 0.05 }, { stars: 2, share: 0.15 }, { stars: 3, share: 0.25 },
      { stars: 4, share: 0.35 }, { stars: 5, share: 0.20 },
    ],
  },
];

/** Ma trận của một tầng, đã gắn sẵn tên bậc. */
function matrixForLevel(level) {
  const lv = Number(level);
  const band = MATRIX_BY_BAND.find((b) => lv >= b.levels[0] && lv <= b.levels[1]) || MATRIX_BY_BAND[2];
  return band.rows.map((r) => ({ ...r, name: STAR_NAMES[r.stars] }));
}

/**
 * Ma trận trung bình của cả hệ, chỉ dùng cho chỗ cần MỘT con số tổng quát
 * (ví dụ trang giới thiệu). Không dùng để dựng đề — dựng đề luôn đi theo tầng.
 */
const BLUEPRINT_MATRIX = [1, 2, 3, 4, 5].map((stars) => {
  const tong = MATRIX_BY_BAND.reduce((s, b) => {
    const r = b.rows.find((x) => x.stars === stars);
    const soTang = b.levels[1] - b.levels[0] + 1;
    return s + (r ? r.share * soTang : 0);
  }, 0);
  return { stars, share: round(tong / 10, 4), name: STAR_NAMES[stars] };
});

const COOLDOWN_DAYS = 30;
/**
 * Một lượt thi 20 câu. Con số này không tuỳ tiện: với ma trận bốn chặng thì 20
 * là số nhỏ nhất chia được cho MỌI tỉ lệ trong bảng mà không phải làm tròn
 * (0.05 → 1 câu, 0.35 → 7 câu). Lấy 12 câu như trước thì 5% thành 0,6 câu,
 * phần dư phải chia tay và cấu trúc đề lệch đi so với bảng công bố.
 */
const DEFAULT_SIZE = 20;
const TIME_FACTOR = 1.2;        // cho rộng hơn thời gian chuẩn 20%
const RETAKE_WAIT_DAYS = 3;

class ExamService {
  constructor({ bank, mastery, telemetry, profiles, attempts = null, exams = null, verifier = null, audit = null }) {
    this.bank = bank;
    this.mastery = mastery;
    this.telemetry = telemetry;
    this.profiles = profiles;
    this.attemptsRepo = attempts;
    this.exams = exams;
    this.verifier = verifier;
    this.audit = audit;
    this.sessions = new Map();
    this.stats = { built: 0, started: 0, submitted: 0, passed: 0, failed: 0, promoted: 0, blocked: 0 };
  }

  // ── Dựng đề ──────────────────────────────────────────────────────────────

  /**
   * Dựng đề thi cuối tầng theo ma trận, phủ đủ dạng, tránh bài vừa luyện.
   */
  build({ learnerId, level, size = DEFAULT_SIZE, cooldownDays = COOLDOWN_DAYS } = {}) {
    const lv = Number(level);
    if (!Number.isInteger(lv) || lv < 0 || lv > 9) return { ok: false, error: 'INVALID_LEVEL' };
    const forms = formsForLevel(lv);
    if (!forms.length) return { ok: false, error: 'NO_FORMS_AT_LEVEL', level: lv };

    const n = clamp(Number(size) || DEFAULT_SIZE, 6, 40);

    // Bài học viên đã làm gần đây — loại ra để không đo trí nhớ ngắn hạn.
    const since = Date.now() - cooldownDays * 86400000;
    const recent = new Set(
      (this.attemptsRepo?.by?.('learnerId', learnerId) || [])
        .filter((a) => (a.at || 0) >= since)
        .map((a) => a.itemId),
    );

    // Số câu cho mỗi bậc sao theo ma trận (chia phần dư theo thứ tự ma trận).
    const want = matrixForLevel(lv).map((m) => ({ ...m, count: Math.floor(n * m.share) }));
    let left = n - want.reduce((s, w) => s + w.count, 0);
    for (let i = 0; left > 0; i = (i + 1) % want.length, left--) want[i].count++;

    const picked = [];
    const used = new Set();
    const formCursor = new Map();

    /** Ngân sách còn lại của một bậc sao. */
    const conCho = (stars) => {
      const w = want.find((x) => x.stars === stars);
      if (!w) return 0;                        // bậc sao không nằm trong ma trận của tầng này
      return w.count - picked.filter((it) => it.stars === stars).length;
    };

    // Lấy bài của một dạng, đã lọc bài vừa luyện và bài đã dùng, sắp xếp tất định.
    const kho = (dieuKien) => this.bank.query({ status: 'PUBLISHED', ...dieuKien })
      .filter((it) => !used.has(it.id) && !recent.has(it.id))
      .sort((a, b) => a.id.localeCompare(b.id));

    const nhan = (it) => {
      used.add(it.id);
      picked.push(it);
      formCursor.set(it.formCode, (formCursor.get(it.formCode) || 0) + 1);
    };

    // ── Vòng 1: PHỦ DẠNG, NHƯNG KHÔNG PHÁ MA TRẬN ──────────────────────────
    // Mỗi dạng góp một bài, đi theo thứ tự tất định. Bài chỉ được nhận khi bậc
    // sao của nó còn ngân sách — nếu không thì vòng này sẽ đẩy đề vượt số câu
    // và làm cấu trúc đề khác hẳn bảng đã công bố.
    for (const f of [...forms].sort((a, b) => a.code.localeCompare(b.code))) {
      if (picked.length >= n) break;
      const pool = kho({ formCode: f.code, level: lv, limit: 80 })
        .filter((it) => conCho(it.stars) > 0)
        // Ưu tiên bậc sao đang thiếu nhiều nhất, để vòng 1 tự cân bằng sẵn ma trận.
        .sort((a, b) => conCho(b.stars) - conCho(a.stars) || a.id.localeCompare(b.id));
      if (pool.length) nhan(pool[0]);
    }

    // ── Vòng 2: LẤP ĐỦ TỪNG BẬC SAO ────────────────────────────────────────
    // Trong mỗi bậc, ưu tiên dạng chưa xuất hiện hoặc xuất hiện ít nhất, để đề
    // không dồn nhiều câu vào một dạng trong khi dạng khác vắng mặt.
    for (const w of want) {
      while (conCho(w.stars) > 0 && picked.length < n) {
        const pool = kho({ level: lv, stars: w.stars, limit: 400 })
          .filter((it) => forms.some((f) => f.code === it.formCode))
          .sort((a, b) => (formCursor.get(a.formCode) || 0) - (formCursor.get(b.formCode) || 0)
            || a.id.localeCompare(b.id));
        if (!pool.length) break;
        nhan(pool[0]);
      }
    }

    // ── Vòng 3: BÙ PHẦN KHÔNG LẤP ĐƯỢC, CÓ GHI SỔ ──────────────────────────
    // Một bậc sao có thể không đủ bài trong kho. Khi đó đề vẫn phải đủ số câu,
    // nhưng KHÔNG được im lặng: phần bù được ghi lại để báo cáo ra ngoài, vì
    // nó làm đề lệch khỏi bảng ma trận đã công bố với người học.
    const buTru = [];
    if (picked.length < n) {
      const thieuTheoBac = want
        .map((w) => ({ stars: w.stars, name: w.name, thieu: conCho(w.stars) }))
        .filter((x) => x.thieu > 0);
      while (picked.length < n) {
        const pool = kho({ level: lv, limit: 600 })
          .filter((it) => forms.some((f) => f.code === it.formCode))
          .sort((a, b) => (formCursor.get(a.formCode) || 0) - (formCursor.get(b.formCode) || 0)
            || a.id.localeCompare(b.id));
        if (!pool.length) break;
        nhan(pool[0]);
      }
      for (const x of thieuTheoBac) buTru.push(x);
    }

    const coveredForms = new Set(picked.map((it) => it.formCode));
    const missingForms = forms.filter((f) => !coveredForms.has(f.code)).map((f) => ({ code: f.code, name: f.name }));
    // Một đề n câu KHÔNG THỂ phủ quá n dạng. Ở tầng 3 có 81 dạng mà đề 20 câu
    // thì 61 dạng vắng mặt là chuyện số học, không phải khuyết tật của đề. Nên
    // phải phân biệt hai chuyện khác hẳn nhau:
    //   · phuToiDa  = số dạng nhiều nhất mà một đề cỡ này phủ nổi
    //   · thieuThat = số dạng đáng lẽ phủ được mà đề lại bỏ sót
    const phuToiDa = Math.min(n, forms.length);
    const thieuThat = Math.max(0, phuToiDa - coveredForms.size);
    const byStars = {};
    for (const it of picked) byStars[it.stars] = (byStars[it.stars] || 0) + 1;

    const timeLimitSec = Math.round(picked.reduce((s, it) => s + (it.normSeconds || 180), 0) * TIME_FACTOR);
    this.stats.built++;

    return {
      ok: picked.length > 0,
      level: lv,
      levelName: `${LEVELS[lv].code} — ${LEVELS[lv].name}`,
      size: picked.length,
      requested: n,
      items: picked,
      timeLimitSec,
      matrix: want.map((w) => ({ stars: w.stars, name: w.name, planned: w.count, actual: byStars[w.stars] || 0 })),
      formsAtLevel: forms.length,
      formsCovered: coveredForms.size,
      formsCoverable: phuToiDa,
      missingForms,
      shortfall: buTru,
      excludedRecent: recent.size,
      warning: [
        thieuThat
          ? `Đề mới phủ ${coveredForms.size}/${phuToiDa} dạng mà cỡ đề này phủ được. Kết quả thi chỉ phản ánh phần đã phủ.`
          : null,
        buTru.length
          ? `Kho chưa đủ bài ở bậc ${buTru.map((x) => `${x.stars}★ (thiếu ${x.thieu} câu)`).join(', ')}; `
            + 'phần thiếu đã lấy bù từ bậc khác nên cấu trúc đề lệch so với bảng ma trận.'
          : null,
        forms.length > n
          ? `Tầng này có ${forms.length} dạng, đề ${n} câu chỉ phủ được tối đa ${phuToiDa} dạng — phần còn lại sẽ vào các đề sau.`
          : null,
      ].filter(Boolean).join(' ') || null,
    };
  }

  // ── Làm bài ──────────────────────────────────────────────────────────────

  start({ learnerId, level = null, size = DEFAULT_SIZE } = {}) {
    if (!learnerId) return { ok: false, error: 'MISSING_INPUT', need: ['learnerId'] };
    const rec = this.profiles?.get(learnerId);
    const lv = level ?? rec?.currentLevel ?? 0;

    // Chặn thi lại quá dày: thi trượt hôm nay rồi mai thi lại là học tủ, không phải tiến bộ.
    const last = this._lastExam(learnerId, lv);
    if (last && !last.passed) {
      const waited = (Date.now() - last.at) / 86400000;
      if (waited < RETAKE_WAIT_DAYS) {
        return {
          ok: false, error: 'RETAKE_TOO_SOON',
          waitDays: round(RETAKE_WAIT_DAYS - waited, 1),
          hint: `Lần thi trước chưa đạt. Cần ít nhất ${RETAKE_WAIT_DAYS} ngày luyện lại trước khi thi tiếp.`,
        };
      }
    }

    const paper = this.build({ learnerId, level: lv, size });
    if (!paper.ok) return { ok: false, error: 'CANNOT_BUILD_PAPER', detail: paper.error || 'kho chưa đủ bài', level: lv };

    const s = {
      id: newId('EX'),
      learnerId,
      level: lv,
      items: paper.items.map((it) => it.id),
      answers: new Map(),
      startedAt: Date.now(),
      deadlineAt: Date.now() + paper.timeLimitSec * 1000,
      state: 'RUNNING',
      paper,
    };
    this.sessions.set(s.id, s);
    this.stats.started++;
    this.telemetry?.action(learnerId, 'EXAM_START', { examId: s.id, level: lv, size: paper.size });
    bus.safeEmit('exam:started', { examId: s.id, learnerId, level: lv });

    return {
      ok: true,
      examId: s.id,
      level: lv,
      levelName: paper.levelName,
      size: paper.size,
      timeLimitSec: paper.timeLimitSec,
      deadlineAt: new Date(s.deadlineAt).toISOString(),
      matrix: paper.matrix,
      formsCovered: paper.formsCovered,
      formsAtLevel: paper.formsAtLevel,
      warning: paper.warning,
      // Đề gửi trọn gói: thi thì được xem lại và làm theo thứ tự tuỳ ý.
      items: paper.items.map((it, i) => ({
        index: i + 1, itemId: it.id, formCode: it.formCode, formName: it.formName,
        stars: it.stars, stem: it.stem, normSeconds: it.normSeconds,
      })),
    };
  }

  /** Nộp từng câu. Không chấm ngay để không ảnh hưởng tâm lý làm bài. */
  submitAnswer({ examId, itemId, answer = null, correct = null, ms = null } = {}) {
    const s = this.sessions.get(examId);
    if (!s) return { ok: false, error: 'EXAM_NOT_FOUND' };
    if (s.state !== 'RUNNING') return { ok: false, error: 'EXAM_FINISHED', state: s.state };
    if (!s.items.includes(itemId)) return { ok: false, error: 'ITEM_NOT_IN_PAPER' };
    if (Date.now() > s.deadlineAt) {
      const r = this.submit({ examId, reason: 'HẾT_GIỜ' });
      return { ok: false, error: 'TIME_UP', result: r };
    }
    s.answers.set(itemId, { answer, correct, ms, at: Date.now() });
    return {
      ok: true, answered: s.answers.size, total: s.items.length,
      remainingSec: Math.max(0, Math.round((s.deadlineAt - Date.now()) / 1000)),
    };
  }

  // ── Chấm và quyết định ───────────────────────────────────────────────────

  submit({ examId, reason = 'NỘP_BÀI' } = {}) {
    const s = this.sessions.get(examId);
    if (!s) return { ok: false, error: 'EXAM_NOT_FOUND' };
    if (s.state !== 'RUNNING') return { ok: false, error: 'EXAM_FINISHED', state: s.state };
    s.state = 'GRADED';
    s.finishedAt = Date.now();
    this.stats.submitted++;

    const details = [];
    let correctCount = 0;
    let pending = 0;

    for (const itemId of s.items) {
      const it = this.bank.get(itemId);
      const a = s.answers.get(itemId);
      if (!a) {
        details.push({ itemId, formCode: it?.formCode, stars: it?.stars, answered: false, correct: false, note: 'Không làm' });
        continue;
      }
      let isCorrect = a.correct;
      let method = 'DECLARED';
      let note = '';
      if (isCorrect === null || isCorrect === undefined) {
        const g = this._grade(it, a.answer);
        isCorrect = g.correct;
        method = g.method;
        note = g.reason;
      }
      if (isCorrect === null) { pending++; details.push({ itemId, formCode: it.formCode, stars: it.stars, answered: true, correct: null, method, note }); continue; }
      if (isCorrect) correctCount++;
      details.push({ itemId, formCode: it.formCode, stars: it.stars, answered: true, correct: !!isCorrect, method, note, ms: a.ms });

      // Bài thi cũng là bằng chứng học tập: đưa vào mức thạo và nhật ký.
      this.mastery?.update(s.learnerId, { formCode: it.formCode, stars: it.stars, correct: !!isCorrect, hintsUsed: 0 });
      this.telemetry?.attempt(s.learnerId, { itemId, formCode: it.formCode, correct: !!isCorrect, ms: a.ms, hintsUsed: 0, stars: it.stars });
      this.attemptsRepo?.put({
        id: `AT-${s.id}-${itemId}`, learnerId: s.learnerId, sessionId: s.id, itemId,
        formCode: it.formCode, correct: !!isCorrect, ms: a.ms, hintsUsed: 0, exam: true, at: Date.now(),
      });
    }

    const graded = details.filter((d) => d.correct !== null).length;
    const score = graded ? round(correctCount / graded, 3) : 0;

    // Điểm theo trọng số bậc sao — làm đúng bài khó phải có giá hơn.
    const weightOf = (st) => ({ 1: 1, 2: 1.2, 3: 1.5, 4: 2, 5: 2.5 }[st] || 1);
    const wTotal = details.filter((d) => d.correct !== null).reduce((n, d) => n + weightOf(d.stars), 0);
    const wGot = details.filter((d) => d.correct).reduce((n, d) => n + weightOf(d.stars), 0);
    const weightedScore = wTotal ? round(wGot / wTotal, 3) : 0;

    const byForm = {};
    for (const d of details) {
      if (d.correct === null) continue;
      const f = (byForm[d.formCode] ??= { formCode: d.formCode, name: FORM_INDEX.get(d.formCode)?.name, total: 0, correct: 0 });
      f.total++;
      if (d.correct) f.correct++;
    }

    const std = standardFor(s.level);
    const passedExam = weightedScore >= (std?.exitExam ?? 0.8);

    const result = {
      ok: true,
      examId: s.id,
      learnerId: s.learnerId,
      level: s.level,
      levelName: `${LEVELS[s.level].code} — ${LEVELS[s.level].name}`,
      reason,
      size: s.items.length,
      answered: s.answers.size,
      graded,
      pendingManual: pending,
      correct: correctCount,
      score,
      weightedScore,
      requiredScore: std?.exitExam ?? 0.8,
      passedExam,
      minutes: round((s.finishedAt - s.startedAt) / 60000, 1),
      byForm: Object.values(byForm).map((f) => ({ ...f, accuracy: round(f.correct / f.total, 3) }))
        .sort((a, b) => a.accuracy - b.accuracy),
      details,
      matrix: s.paper.matrix,
    };

    this[passedExam ? 'stats' : 'stats'].passed += passedExam ? 1 : 0;
    if (!passedExam) this.stats.failed++;

    this.exams?.put({
      id: s.id, learnerId: s.learnerId, kind: 'EXIT_EXAM', level: s.level,
      at: s.finishedAt, passed: passedExam, score: weightedScore, result,
    });
    this.audit?.record({
      actor: s.learnerId, action: 'exam.submitted', verdict: 'ALLOW', severity: 0,
      detail: { examId: s.id, level: s.level, weightedScore, passedExam },
    });
    bus.safeEmit('exam:graded', { examId: s.id, learnerId: s.learnerId, score: weightedScore, passed: passedExam });
    return result;
  }

  _grade(item, submitted) {
    if (!item) return { correct: null, method: 'NO_ITEM', reason: 'Không tìm thấy bài' };
    const got = String(submitted ?? '').trim();
    if (!got) return { correct: false, method: 'EMPTY', reason: 'Không làm' };
    const norm = (x) => String(x).replace(/\s+/g, ' ').replace(/\$/g, '').toLowerCase();
    if (norm(item.answer) === norm(got)) return { correct: true, method: 'EXACT', reason: 'Khớp đáp án chuẩn' };
    if (this.verifier) {
      if (item.check?.equation) {
        const r = this.verifier.checkRoots(item.check.equation, got, item.check.variable || 'x');
        if (r.ok) return { correct: r.correct, method: 'ROOT_SET', reason: r.reason };
      }
      const eq = this.verifier.equivalent(item.answer, got);
      if (eq.ok && eq.equal !== null) {
        return { correct: eq.equal === true, method: 'EQUIVALENT', reason: eq.equal ? 'Tương đương đáp án chuẩn' : eq.reason };
      }
    }
    return { correct: null, method: 'MANUAL', reason: 'Cần giáo viên chấm' };
  }

  // ── Quyết định lên tầng ──────────────────────────────────────────────────

  /**
   * Xét lên tầng theo ĐỦ 7 tiêu chí. Điểm thi chỉ là MỘT trong bảy.
   */
  evaluatePromotion(learnerId, level = null) {
    const rec = this.profiles?.get(learnerId);
    if (!rec) return { ok: false, error: 'LEARNER_NOT_FOUND' };
    const lv = level ?? rec.currentLevel ?? 0;

    const lastExam = this._lastExam(learnerId, lv);
    const attempts = (this.attemptsRepo?.by?.('learnerId', learnerId) || [])
      .sort((a, b) => (a.at || 0) - (b.at || 0))
      .map((a) => ({ formCode: a.formCode, correct: a.correct, ms: a.ms, at: a.at }));

    // Không tụt lùi: kiểm lại các tầng dưới có còn đạt chuẩn không.
    const lowerLevelStatus = [];
    for (let l = 0; l < lv; l++) {
      const codes = formsForLevel(l).map((f) => f.code);
      if (!codes.length) continue;
      const map = this.mastery?.map(learnerId) || {};
      const touched = codes.filter((c) => (map[c] ?? 0) > 0);
      if (!touched.length) continue;
      const avg = touched.reduce((s, c) => s + (map[c] ?? 0), 0) / touched.length;
      lowerLevelStatus.push({ level: l, meets: avg >= (standardFor(l)?.mastery ?? 0.7), avgMastery: round(avg, 3) });
    }

    const ev = {
      masteryByForm: this.mastery?.map(learnerId) || {},
      attempts,
      sessionsPassed: rec.sessionsPassed ?? this._countGoodSessions(learnerId),
      exitExamScore: lastExam?.score ?? 0,
      lowerLevelStatus,
    };

    const verdict = evaluate(lv, ev);
    const todo = gaps(lv, ev);

    return {
      ok: true,
      learnerId,
      level: lv,
      levelName: `${LEVELS[lv].code} — ${LEVELS[lv].name}`,
      eligible: verdict.ok,
      criteria: verdict.criteria,
      failed: verdict.failed,
      score: verdict.score,
      verdict: verdict.verdict,
      lastExam: lastExam ? { at: new Date(lastExam.at).toISOString(), score: lastExam.score, passed: lastExam.passed } : null,
      todo: Array.isArray(todo) ? todo : [],
      note: verdict.ok
        ? 'Đủ cả 7 tiêu chí. Được lên tầng.'
        : `Chưa lên được: thiếu ${verdict.failed.length}/7 tiêu chí. Điểm thi cao cũng không bù được tiêu chí khác.`,
    };
  }

  /** Lên tầng. Chỉ chạy khi đủ điều kiện; thiếu tiêu chí nào cũng chặn. */
  promote(learnerId, { by = 'system', force = false } = {}) {
    const ev = this.evaluatePromotion(learnerId);
    if (!ev.ok) return ev;
    const rec = this.profiles.get(learnerId);

    if (!ev.eligible && !force) {
      this.stats.blocked++;
      this.audit?.record({
        actor: by, action: 'learner.promote_blocked', verdict: 'DENY', severity: 1,
        detail: { learnerId, level: ev.level, failed: ev.failed },
      });
      return { ok: false, error: 'NOT_ELIGIBLE', failed: ev.failed, criteria: ev.criteria, todo: ev.todo, note: ev.note };
    }
    if (force && !ev.eligible) {
      // Cho phép người có thẩm quyền quyết định khác máy, nhưng PHẢI để lại dấu vết.
      this.audit?.record({
        actor: by, action: 'learner.promote_forced', verdict: 'ALLOW', severity: 2,
        detail: { learnerId, level: ev.level, failed: ev.failed, note: 'Lên tầng do người quyết định, chưa đủ tiêu chí máy' },
      });
    }

    const from = rec.currentLevel ?? 0;
    const to = Math.min(9, from + 1);
    rec.currentLevel = to;
    rec.levelHistory = [...(rec.levelHistory || []), {
      at: Date.now(), level: to, from, by, forced: force && !ev.eligible,
      criteriaScore: ev.score,
    }];
    this.profiles.save?.(learnerId);
    this.stats.promoted++;
    bus.safeEmit('learner:promoted', { learnerId, from, to, forced: force && !ev.eligible });
    this.audit?.record({
      actor: by, action: 'learner.promoted', verdict: 'ALLOW', severity: 0,
      detail: { learnerId, from, to, criteriaScore: ev.score },
    });
    return {
      ok: true, learnerId, from, to,
      levelName: `${LEVELS[to].code} — ${LEVELS[to].name}`,
      forced: force && !ev.eligible,
      criteriaScore: ev.score,
    };
  }

  _lastExam(learnerId, level = null) {
    const rows = (this.exams?.by?.('learnerId', learnerId) || [])
      .filter((e) => e.kind === 'EXIT_EXAM' && (level == null || e.level === level))
      .sort((a, b) => (b.at || 0) - (a.at || 0));
    return rows[0] || null;
  }

  _countGoodSessions(learnerId) {
    // Phiên "đạt" = độ chính xác ≥ 0.8 trong các phiên luyện gần đây.
    const rows = (this.exams?.by?.('learnerId', learnerId) || []);
    return rows.filter((r) => r.kind === 'PRACTICE' && (r.accuracy ?? 0) >= 0.8).length;
  }

  get(examId) {
    const s = this.sessions.get(examId);
    if (!s) return null;
    return {
      id: s.id, learnerId: s.learnerId, level: s.level, state: s.state,
      size: s.items.length, answered: s.answers.size,
      startedAt: new Date(s.startedAt).toISOString(),
      deadlineAt: new Date(s.deadlineAt).toISOString(),
    };
  }

  status() {
    return {
      ...this.stats,
      running: [...this.sessions.values()].filter((s) => s.state === 'RUNNING').length,
      matrix: BLUEPRINT_MATRIX,
      matrixByBand: MATRIX_BY_BAND,
      cooldownDays: COOLDOWN_DAYS,
      retakeWaitDays: RETAKE_WAIT_DAYS,
    };
  }
}

module.exports = ExamService;
module.exports.BLUEPRINT_MATRIX = BLUEPRINT_MATRIX;
module.exports.MATRIX_BY_BAND = MATRIX_BY_BAND;
module.exports.matrixForLevel = matrixForLevel;
module.exports.STAR_NAMES = STAR_NAMES;
module.exports.DEFAULT_SIZE = DEFAULT_SIZE;
module.exports.COOLDOWN_DAYS = COOLDOWN_DAYS;
module.exports.RETAKE_WAIT_DAYS = RETAKE_WAIT_DAYS;
