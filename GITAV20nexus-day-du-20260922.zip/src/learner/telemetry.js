'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  QUAN SÁT HỌC VIÊN — 4 lớp dữ liệu
 * ═══════════════════════════════════════════════════════════════════════════
 *   THAO TÁC   từng sự kiện thô trên giao diện (mở bài, gõ, xoá, xin gợi ý…)
 *   HÀNH VI    mẫu hình rút ra từ chuỗi thao tác (phụ thuộc gợi ý, vội, bỏ cuộc…)
 *   SUY NGHĨ   lời giải học viên nhập vào → đối chiếu bẫy của DẠNG → nhãn hiểu sai
 *   KẾT QUẢ    đúng/sai, điểm, thời gian, biến thiên mức thạo
 *
 *  Bốn lớp này là đầu vào để dịch chuyển chiến lược ở cuối mỗi chu kỳ 90 ngày.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const bus = require('../kernel/eventbus');
const { round, clamp, percentile, viKey } = require('../utils');
const { FORM_INDEX } = require('../curriculum/hierarchy');

/** Thao tác được ghi nhận. Danh sách đóng — thêm loại mới phải khai báo ở đây. */
const ACTIONS = {
  ITEM_OPEN: 'ITEM_OPEN',
  INPUT_TYPE: 'INPUT_TYPE',
  INPUT_CLEAR: 'INPUT_CLEAR',
  HINT_REQUEST: 'HINT_REQUEST',
  SOLUTION_PEEK: 'SOLUTION_PEEK',
  SUBMIT: 'SUBMIT',
  SKIP: 'SKIP',
  PAUSE: 'PAUSE',
  RESUME: 'RESUME',
  SESSION_START: 'SESSION_START',
  SESSION_END: 'SESSION_END',
  REVIEW_MISTAKE: 'REVIEW_MISTAKE',
};

/** Mẫu hình hành vi, mỗi mẫu có điều kiện phát hiện và khuyến nghị đối ứng. */
const BEHAVIOR_PATTERNS = {
  HINT_DEPENDENT: {
    name: 'Phụ thuộc gợi ý',
    detect: (m) => m.items >= 10 && m.hintRate > 0.6,
    advice: 'Khoá gợi ý 1 trong 90 giây đầu; yêu cầu viết bước 1 trước khi được gợi ý',
  },
  RUSHING: {
    name: 'Làm vội',
    detect: (m) => m.items >= 10 && m.fastWrongRate > 0.4,
    advice: 'Bắt buộc nhập ít nhất một bước lập luận trước khi nộp',
  },
  GIVING_UP: {
    name: 'Dễ bỏ cuộc',
    detect: (m) => m.items >= 10 && m.skipRate > 0.25,
    advice: 'Hạ một bậc độ khó, tăng dần trở lại sau 3 bài đúng liên tiếp',
  },
  PERSISTENT: {
    name: 'Kiên trì',
    detect: (m) => m.items >= 10 && m.retryRate > 0.3 && m.skipRate < 0.1,
    advice: 'Có thể nâng độ khó sớm hơn lộ trình chuẩn',
  },
  PEEKER: {
    name: 'Xem lời giải sớm',
    detect: (m) => m.items >= 10 && m.peekRate > 0.35,
    advice: 'Ẩn lời giải cho tới khi đã nộp ít nhất một lần',
  },
  CARELESS: {
    name: 'Sai do ẩu',
    detect: (m) => m.items >= 15 && m.carelessRate > 0.3,
    advice: 'Thêm bước tự kiểm tra bắt buộc: thử lại nghiệm, soát đơn vị',
  },
  STEADY: {
    name: 'Ổn định',
    detect: (m) => m.items >= 15 && m.accuracy >= 0.75 && m.skipRate < 0.1 && m.hintRate < 0.3,
    advice: 'Giữ nhịp hiện tại, tăng tỉ lệ bài 4★',
  },
  NIGHT_OWL: {
    name: 'Học khuya',
    detect: (m) => m.sessions >= 5 && m.lateNightRate > 0.5,
    advice: 'Đề xuất chuyển khung giờ: độ chính xác ban đêm thường thấp hơn',
  },
};

class Telemetry {
  constructor({ maxEventsPerUser = 20000 } = {}) {
    this.events = new Map();    // userId -> [event]
    this.sessions = new Map();  // userId -> [session]
    this.attempts = new Map();  // userId -> [attempt]
    this.maxEvents = maxEventsPerUser;
    this.stats = { events: 0, attempts: 0, sessions: 0, misconceptions: 0 };
  }

  _arr(map, userId) {
    if (!map.has(userId)) map.set(userId, []);
    return map.get(userId);
  }

  // ── LỚP 1: THAO TÁC ──────────────────────────────────────────────────────
  action(userId, type, payload = {}) {
    if (!ACTIONS[type]) return { ok: false, error: 'UNKNOWN_ACTION', type };
    const ev = { t: Date.now(), type, ...payload };
    const arr = this._arr(this.events, userId);
    arr.push(ev);
    if (arr.length > this.maxEvents) arr.splice(0, arr.length - this.maxEvents);
    this.stats.events++;

    if (type === ACTIONS.SESSION_START) {
      this._arr(this.sessions, userId).push({ start: ev.t, end: null, items: 0, correct: 0 });
      this.stats.sessions++;
    }
    if (type === ACTIONS.SESSION_END) {
      const s = this._arr(this.sessions, userId).slice(-1)[0];
      if (s && !s.end) { s.end = ev.t; s.minutes = round((s.end - s.start) / 60000, 1); }
    }
    return { ok: true, event: ev };
  }

  // ── LỚP 3: SUY NGHĨ — đối chiếu lời giải học viên với bẫy của dạng ────────
  analyzeThinking(formCode, studentWork) {
    const form = FORM_INDEX.get(formCode);
    if (!form || !studentWork) return { steps: 0, misconceptions: [], depth: 0 };

    const lines = String(studentWork).split('\n').map((s) => s.trim()).filter(Boolean);
    const key = viKey(studentWork);

    // Nhãn hiểu sai: bẫy nào của dạng KHÔNG được học viên nhắc tới/xử lý
    const misconceptions = [];
    for (const trap of form.traps) {
      const trapKey = viKey(trap);
      const words = trapKey.split(' ').filter((w) => w.length > 3);
      const mentioned = words.some((w) => key.includes(w));
      if (!mentioned) misconceptions.push({ trap, addressed: false });
    }
    if (misconceptions.length) this.stats.misconceptions += misconceptions.length;

    return {
      steps: lines.length,
      chars: String(studentWork).length,
      depth: clamp(lines.length / 5, 0, 1),
      misconceptions,
      addressedTraps: form.traps.length - misconceptions.length,
      totalTraps: form.traps.length,
    };
  }

  // ── LỚP 4: KẾT QUẢ ───────────────────────────────────────────────────────
  /**
   * @param {object} a {itemId, formCode, level, stars, correct, ms, hintsUsed,
   *                    peeked, skipped, retries, studentWork}
   */
  attempt(userId, a) {
    const form = FORM_INDEX.get(a.formCode);
    const norm = (form?.norm || 180) * 1000;
    const thinking = this.analyzeThinking(a.formCode, a.studentWork);

    const rec = {
      at: Date.now(),
      itemId: a.itemId,
      formCode: a.formCode,
      level: a.level,
      stars: a.stars,
      correct: !!a.correct,
      ms: a.ms || 0,
      speedRatio: a.ms ? round(a.ms / norm, 3) : null,
      hintsUsed: a.hintsUsed || 0,
      peeked: !!a.peeked,
      skipped: !!a.skipped,
      retries: a.retries || 0,
      thinking,
      // Sai do ẩu: làm rất nhanh, không xin gợi ý, mà vẫn sai
      careless: !a.correct && a.ms > 0 && a.ms < norm * 0.4 && !a.hintsUsed,
    };

    const arr = this._arr(this.attempts, userId);
    arr.push(rec);
    if (arr.length > this.maxEvents) arr.splice(0, arr.length - this.maxEvents);
    this.stats.attempts++;

    const s = this._arr(this.sessions, userId).slice(-1)[0];
    if (s && !s.end) { s.items++; if (rec.correct) s.correct++; }

    bus.safeEmit('learner:attempt', { userId, formCode: a.formCode, correct: rec.correct });
    return { ok: true, attempt: rec };
  }

  // ── LỚP 2: HÀNH VI — rút mẫu hình từ thao tác + kết quả ──────────────────
  metrics(userId, { window = 100 } = {}) {
    const all = this._arr(this.attempts, userId);
    const at = all.slice(-window);
    const sessions = this._arr(this.sessions, userId).filter((s) => s.end);
    const n = at.length;
    if (!n) return { items: 0, sessions: sessions.length };

    const done = at.filter((x) => !x.skipped);
    const wrong = done.filter((x) => !x.correct);
    const lateNight = sessions.filter((s) => {
      const h = new Date(s.start).getHours();
      return h >= 23 || h < 5;
    }).length;

    return {
      items: n,
      sessions: sessions.length,
      accuracy: done.length ? round(done.filter((x) => x.correct).length / done.length, 3) : 0,
      hintRate: round(at.filter((x) => x.hintsUsed > 0).length / n, 3),
      peekRate: round(at.filter((x) => x.peeked).length / n, 3),
      skipRate: round(at.filter((x) => x.skipped).length / n, 3),
      retryRate: round(at.filter((x) => x.retries > 0).length / n, 3),
      carelessRate: wrong.length ? round(wrong.filter((x) => x.careless).length / wrong.length, 3) : 0,
      fastWrongRate: n ? round(at.filter((x) => !x.correct && x.speedRatio != null && x.speedRatio < 0.4).length / n, 3) : 0,
      medianSpeedRatio: percentile(at.map((x) => x.speedRatio).filter((x) => x != null), 50),
      avgThinkingSteps: round(at.reduce((s, x) => s + (x.thinking?.steps || 0), 0) / n, 2),
      avgSessionMinutes: sessions.length ? round(sessions.reduce((s, x) => s + (x.minutes || 0), 0) / sessions.length, 1) : 0,
      lateNightRate: sessions.length ? round(lateNight / sessions.length, 3) : 0,
    };
  }

  behaviors(userId) {
    const m = this.metrics(userId);
    const found = [];
    for (const [id, p] of Object.entries(BEHAVIOR_PATTERNS)) {
      if (p.detect(m)) found.push({ id, name: p.name, advice: p.advice });
    }
    return { metrics: m, behaviors: found };
  }

  /** Bẫy nào học viên hay bỏ qua nhất — đầu vào trực tiếp cho lộ trình sửa lỗi. */
  topMisconceptions(userId, limit = 10) {
    const counts = new Map();
    for (const a of this._arr(this.attempts, userId)) {
      if (a.correct) continue;
      for (const mc of a.thinking?.misconceptions || []) {
        const k = `${a.formCode}::${mc.trap}`;
        counts.set(k, (counts.get(k) || 0) + 1);
      }
    }
    return [...counts.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, limit)
      .map(([k, n]) => {
        const [formCode, trap] = k.split('::');
        return { formCode, trap, occurrences: n };
      });
  }

  attemptsOf(userId) { return this._arr(this.attempts, userId); }
  eventsOf(userId, limit = 200) { return this._arr(this.events, userId).slice(-limit); }
  sessionsOf(userId) { return this._arr(this.sessions, userId); }

  status() {
    return { ...this.stats, users: this.attempts.size, actionTypes: Object.keys(ACTIONS).length, patterns: Object.keys(BEHAVIOR_PATTERNS).length };
  }
}

module.exports = Telemetry;
module.exports.ACTIONS = ACTIONS;
module.exports.BEHAVIOR_PATTERNS = BEHAVIOR_PATTERNS;
