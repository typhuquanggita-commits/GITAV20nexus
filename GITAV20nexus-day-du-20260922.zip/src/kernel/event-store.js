'use strict';
/** Event store append-only + audit chain bất biến (điều A08, A34 hiến pháp). */

const { sha256 } = require('../utils');
const bus = require('./eventbus');

const GENESIS = '0'.repeat(64);

class EventStore {
  constructor({ store, maxBuffer = 20000 } = {}) {
    this.store = store;
    this.maxBuffer = maxBuffer;
    this.log = [];
    this.head = GENESIS;
    this.seq = 0;
    this.stats = { appended: 0, verified: 0, tampered: 0 };
  }

  /** Ghi một sự kiện; băm móc xích vào bản ghi trước để không thể sửa hồi tố. */
  async append(stream, type, payload = {}) {
    this.seq++;
    const record = {
      seq: this.seq,
      stream,
      type,
      payload,
      at: Date.now(),
      prev: this.head,
    };
    record.hash = sha256(`${record.seq}|${record.prev}|${stream}|${type}|${JSON.stringify(payload)}|${record.at}`);
    this.head = record.hash;
    this.log.push(record);
    if (this.log.length > this.maxBuffer) this.log.splice(0, this.log.length - this.maxBuffer);
    this.stats.appended++;
    bus.safeEmit('eventstore:appended', { stream, type, seq: record.seq });
    if (this.store) {
      await this.store.set(`es:head`, this.head).catch(() => {});
    }
    return { ok: true, seq: record.seq, hash: record.hash };
  }

  /** Kiểm tra toàn vẹn chuỗi băm. */
  verify() {
    this.stats.verified++;
    let prev = this.log.length ? this.log[0].prev : GENESIS;
    for (const r of this.log) {
      const expect = sha256(`${r.seq}|${prev}|${r.stream}|${r.type}|${JSON.stringify(r.payload)}|${r.at}`);
      if (expect !== r.hash || r.prev !== prev) {
        this.stats.tampered++;
        return { ok: false, brokenAt: r.seq, expected: expect, got: r.hash };
      }
      prev = r.hash;
    }
    return { ok: true, records: this.log.length, head: this.head };
  }

  read({ stream = null, type = null, limit = 100 } = {}) {
    let items = this.log;
    if (stream) items = items.filter((r) => r.stream === stream);
    if (type) items = items.filter((r) => r.type === type);
    return { ok: true, count: items.length, items: items.slice(-limit).reverse() };
  }

  status() {
    return { ...this.stats, buffered: this.log.length, head: this.head, seq: this.seq };
  }
}

module.exports = EventStore;
module.exports.GENESIS = GENESIS;
