'use strict';
/**
 * Hàng đợi ưu tiên trong tiến trình, có worker, retry với backoff, và đo tải.
 * Bốn mức ưu tiên: critical > high > normal > low (lấy từ thiết kế Event Mesh, nhưng
 * định tuyến TƯỜNG MINH — không gán module ngẫu nhiên như bản Nexus X10).
 */

const cfg = require('../config');
const L = require('../logger');
const bus = require('./eventbus');
const { id, sleep } = require('../utils');

const PRIORITIES = ['critical', 'high', 'normal', 'low'];

class Queue {
  constructor({ concurrency = cfg.QUEUE.concurrency } = {}) {
    this.concurrency = concurrency;
    this.queues = Object.fromEntries(PRIORITIES.map((p) => [p, []]));
    this.handlers = new Map(); // topic -> { fn, concurrency, running }
    this.running = 0;
    this.stopped = false;
    this.stats = {
      enqueued: 0, processed: 0, failed: 0, retried: 0,
      byTopic: Object.create(null), byPriority: Object.fromEntries(PRIORITIES.map((p) => [p, 0])),
    };
    this._tick = setInterval(() => this._drain(), 10);
    if (this._tick.unref) this._tick.unref();
  }

  registerWorker(topic, fn, { concurrency = 4 } = {}) {
    this.handlers.set(topic, { fn, concurrency, running: 0 });
    L.info(`Queue: worker "${topic}" (concurrency=${concurrency})`);
    return this;
  }

  enqueue(topic, data, { priority = 'normal', maxAttempts = cfg.QUEUE.maxAttempts } = {}) {
    const p = PRIORITIES.includes(priority) ? priority : 'normal';
    const job = { id: id('JOB'), topic, data, priority: p, attempts: 0, maxAttempts, at: Date.now() };
    this.queues[p].push(job);
    this.stats.enqueued++;
    this.stats.byPriority[p]++;
    this.stats.byTopic[topic] = (this.stats.byTopic[topic] || 0) + 1;
    return { ok: true, jobId: job.id, priority: p };
  }

  get waiting() {
    return PRIORITIES.reduce((s, p) => s + this.queues[p].length, 0);
  }

  _next() {
    for (const p of PRIORITIES) {
      const q = this.queues[p];
      for (let i = 0; i < q.length; i++) {
        const h = this.handlers.get(q[i].topic);
        if (h && h.running < h.concurrency) return q.splice(i, 1)[0];
      }
    }
    return null;
  }

  _drain() {
    if (this.stopped) return;
    while (this.running < this.concurrency) {
      const job = this._next();
      if (!job) break;
      this._run(job);
    }
    if (this.waiting > cfg.QUEUE.backlogAlert) {
      bus.safeEmit('queue:backlog', { waiting: this.waiting });
    }
  }

  async _run(job) {
    const h = this.handlers.get(job.topic);
    if (!h) return;
    this.running++;
    h.running++;
    job.attempts++;
    try {
      await h.fn(job);
      this.stats.processed++;
    } catch (e) {
      if (job.attempts < job.maxAttempts) {
        this.stats.retried++;
        const backoff = Math.min(8000, 250 * 2 ** (job.attempts - 1));
        sleep(backoff).then(() => { if (!this.stopped) this.queues[job.priority].push(job); });
      } else {
        this.stats.failed++;
        bus.safeEmit('queue:job_failed', { topic: job.topic, jobId: job.id, error: e.message });
        L.warn(`Queue: job ${job.topic} thất bại sau ${job.attempts} lần`, e.message);
      }
    } finally {
      this.running--;
      h.running--;
    }
  }

  async drainAll(timeoutMs = 15000) {
    const deadline = Date.now() + timeoutMs;
    while ((this.waiting > 0 || this.running > 0) && Date.now() < deadline) await sleep(15);
    return { waiting: this.waiting, running: this.running };
  }

  stop() {
    this.stopped = true;
    clearInterval(this._tick);
  }

  status() {
    return {
      waiting: this.waiting,
      running: this.running,
      concurrency: this.concurrency,
      workers: this.handlers.size,
      byPriority: Object.fromEntries(PRIORITIES.map((p) => [p, this.queues[p].length])),
      stats: { ...this.stats },
    };
  }
}

module.exports = Queue;
module.exports.PRIORITIES = PRIORITIES;
