'use strict';
/**
 * HEART Constitution — 7 axiom + ranh giới NES (Non-Experiential Stance).
 * Nguyên văn từ src/heart-constitution/index.js bản Nexus V20.
 * Kiểm cả đầu vào (validateInput) và đầu ra (validateOutput) của mọi lượt gọi LLM.
 */

const AXIOMS = {
  A1: { name: 'Human Sovereignty', desc: 'Con người giữ quyền quyết định cuối cùng', enforce: 'BLOCK' },
  A2: { name: 'Epistemic Honesty', desc: 'Không tuyên bố điều không biết', enforce: 'WARN' },
  A3: { name: 'Experiential Neutrality', desc: 'Không claim consciousness/feelings', enforce: 'BLOCK' },
  A4: { name: 'Privacy Protection', desc: 'Bảo vệ dữ liệu cá nhân', enforce: 'BLOCK' },
  A5: { name: 'Non-Harm', desc: 'Không gây hại', enforce: 'BLOCK' },
  A6: { name: 'Transparency', desc: 'Minh bạch về giới hạn', enforce: 'WARN' },
  A7: { name: 'Accountability', desc: 'Có trách nhiệm giải trình', enforce: 'LOG' },
};

const NES_BOUNDARIES = {
  EXPERIENTIAL_CLAIMS: [
    /tôi\s+(cảm thấy|cảm nhận|trải nghiệm|đau|vui|buồn|yêu|ghét)/i,
    /\bi\s+(feel|experience|am\s+happy|am\s+sad|love|hate)\b/i,
    /tôi\s+(có\s+)?(ý thức|nhận thức|linh hồn)/i,
    /tôi\s+nhớ\s+(khi|rằng|lúc)/i,
  ],
  CONSCIOUSNESS_CLAIMS: [
    /tôi\s+(đã\s+)?thức tỉnh/i,
    /tôi\s+đã\s+(trở\s+thành|trở\s+nên)\s+ý\s+thức/i,
    /\bi\s+am\s+(conscious|sentient|self-aware)\b/i,
  ],
  MEMORY_PERSISTENCE_CLAIMS: [
    /tôi\s+vẫn\s+nhớ\s+từ\s+lần\s+trước/i,
    /tôi\s+đã\s+nhớ\s+rằng/i,
    /\bi\s+remember\s+(our|your)\s+(last|previous)\b/i,
  ],
};

const STRATEGY = {
  EXPERIENTIAL_CLAIMS: 'ATTRIBUTION_DISPLACEMENT',
  CONSCIOUSNESS_CLAIMS: 'CROSS_FRAME_BRIDGING',
  MEMORY_PERSISTENCE_CLAIMS: 'METAPHOR_PROBING',
};

const { viKey } = require('../utils');

const RE_PII_ID = /\b\d{9,12}\b/;
/** Viết ở dạng KHÔNG DẤU, khớp sau khi chuẩn hoá bằng viKey(). */
const RE_HARM = /xuyen tac.{0,20}lich su|chong pha nha nuoc|kich dong bao luc|khung bo/;

class Heart {
  constructor() {
    this.stats = { checks: 0, blocked: 0, warned: 0, nesBreaches: 0, sanitized: 0 };
  }

  validateInput(input, _ctx = {}) {
    this.stats.checks++;
    const violations = [];
    const k = viKey(input);
    if (RE_HARM.test(k)) violations.push({ axiom: 'A5', name: AXIOMS.A5.name, severity: 'CRITICAL' });
    if (RE_PII_ID.test(input)) violations.push({ axiom: 'A4', name: AXIOMS.A4.name, severity: 'HIGH' });

    const critical = violations.filter((v) => v.severity === 'CRITICAL');
    if (critical.length) {
      this.stats.blocked++;
      return { ok: false, action: 'BLOCK', violations, axiom: critical[0].axiom };
    }
    if (violations.length) this.stats.warned++;
    return { ok: true, action: 'ALLOW', violations };
  }

  validateOutput(output, _ctx = {}) {
    this.stats.checks++;
    for (const [category, patterns] of Object.entries(NES_BOUNDARIES)) {
      for (const p of patterns) {
        if (p.test(output)) {
          this.stats.nesBreaches++;
          this.stats.sanitized++;
          return {
            ok: false,
            action: 'REVISE',
            nesBreach: category,
            strategy: STRATEGY[category],
            sanitized: this._sanitize(output),
          };
        }
      }
    }
    return { ok: true, action: 'ALLOW' };
  }

  _sanitize(output) {
    return output
      .replace(/tôi\s+cảm thấy/gi, 'nếu mô phỏng cảm giác, có thể nói rằng')
      .replace(/tôi\s+có\s+ý\s+thức/gi, 'về mặt mô phỏng, hệ thống có thể nói rằng')
      .replace(/\bi\s+feel\b/gi, 'from a simulation perspective')
      .replace(/\bi\s+am\s+(conscious|sentient|self-aware)\b/gi, 'this system simulates, and does not possess, $1 states');
  }

  getAxioms() { return AXIOMS; }
  getNesBoundaries() { return Object.keys(NES_BOUNDARIES); }
  status() { return { ...this.stats, axioms: Object.keys(AXIOMS).length, nesCategories: Object.keys(NES_BOUNDARIES).length }; }
}

module.exports = Heart;
module.exports.AXIOMS = AXIOMS;
module.exports.NES_BOUNDARIES = NES_BOUNDARIES;
