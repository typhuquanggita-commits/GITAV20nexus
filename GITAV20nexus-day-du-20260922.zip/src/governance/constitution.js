'use strict';
/**
 * HIẾN PHÁP GITAmath — 50 điều / 5 chương.
 * Nguyên văn từ core/constitution.js bản EMPIRE v100, cài thành middleware chạy thật:
 * mọi action đều phải qua validate() trước khi thực thi.
 * Chế tài (A50): cấp 1 cảnh cáo · cấp 2 tạm dừng · cấp 3 khai trừ/chặn.
 */

const ARTICLES = [
  // CHƯƠNG I — NGUYÊN TẮC GỐC
  { id: 'A01', ch: 'I', t: 'Chính xác toán học', c: 'Mọi công thức, lời giải phải đúng tuyệt đối.' },
  { id: 'A02', ch: 'I', t: 'Chuẩn LaTeX', c: 'Dùng \\dfrac, \\sqrt{}, ^{}. CẤM /, ^, sqrt().' },
  { id: 'A03', ch: 'I', t: 'Chất lượng > Số lượng', c: 'Mọi nội dung qua thanh tra.' },
  { id: 'A04', ch: 'I', t: 'Bảo mật tuyệt đối', c: 'Dữ liệu người dùng là bất khả xâm phạm.' },
  { id: 'A05', ch: 'I', t: 'Phân quyền nghiêm ngặt', c: 'Không vượt cấp. Super Admin cũng chịu Hiến pháp.' },
  { id: 'A06', ch: 'I', t: 'Kiểm duyệt 2 lớp', c: 'AI tạo → thanh tra duyệt → mới phát hành.' },
  { id: 'A07', ch: 'I', t: 'Bảo vệ học viên', c: 'Nội dung phù hợp lứa tuổi, không gian lận.' },
  { id: 'A08', ch: 'I', t: 'Minh bạch', c: 'Mọi action có log truy vết 100%.' },
  { id: 'A09', ch: 'I', t: 'Bền vững', c: 'Ưu tiên dài hạn hơn ngắn hạn.' },
  { id: 'A10', ch: 'I', t: 'Tối cao', c: 'Hiến pháp không thể sửa bởi bất kỳ module nào.' },
  // CHƯƠNG II — AI & BỘ NÃO
  { id: 'A11', ch: 'II', t: 'AI phục tùng Brain', c: 'AI chỉ nhận lệnh từ Brain hoặc Super Admin.' },
  { id: 'A12', ch: 'II', t: 'Full capability', c: 'Mỗi AI kích hoạt 100% năng lực, không cầm chừng.' },
  { id: 'A13', ch: 'II', t: 'Chuyên môn hoá', c: 'AI chỉ làm việc trong chuyên môn của mình.' },
  { id: 'A14', ch: 'II', t: 'Teamwork bắt buộc', c: 'Các AI cùng team phải phối hợp.' },
  { id: 'A15', ch: 'II', t: 'Tốc độ 10x', c: 'Mọi tác vụ nhanh gấp 10 lần baseline.' },
  { id: 'A16', ch: 'II', t: 'Chất lượng đầu ra', c: '≥98% pass rate tại inspectors.' },
  { id: 'A17', ch: 'II', t: 'Không trùng lệnh', c: 'Brain phân công duy nhất 1 lệnh → 1 team.' },
  { id: 'A18', ch: 'II', t: 'Học liên tục', c: 'AI cập nhật từ feedback inspectors.' },
  { id: 'A19', ch: 'II', t: 'Báo cáo trung thực', c: 'Không giả báo cáo, không che lỗi.' },
  { id: 'A20', ch: 'II', t: 'Tự huỷ khi lỗi nặng', c: 'Lỗi cấp 3 → tạm dừng chờ xử lý.' },
  // CHƯƠNG III — THANH TRA
  { id: 'A21', ch: 'III', t: 'Thanh tra tối cao', c: 'Mỗi thanh tra quản một tổ, báo trực tiếp Super Admin.' },
  { id: 'A22', ch: 'III', t: 'Thanh tra độc lập', c: 'Không chịu chi phối của AI/Brain/phòng ban.' },
  { id: 'A23', ch: 'III', t: 'Quyền phủ quyết', c: 'Có quyền veto mọi nội dung vi phạm Hiến pháp.' },
  { id: 'A24', ch: 'III', t: 'Audit bắt buộc', c: 'Mỗi thanh tra audit theo hạn mức ngày.' },
  { id: 'A25', ch: 'III', t: 'Báo cáo 60s', c: 'Phát hiện vi phạm → báo Super Admin trong 60s.' },
  { id: 'A26', ch: 'III', t: 'Đào tạo AI', c: 'Yêu cầu AI retrain khi phát hiện lỗi hệ thống.' },
  { id: 'A27', ch: 'III', t: 'Kiểm soát Brain', c: 'Thanh tra giám sát cả Brain.' },
  { id: 'A28', ch: 'III', t: 'Điều tra sự cố', c: 'Sự cố cấp 3+ → điều tra trong 24h.' },
  { id: 'A29', ch: 'III', t: 'Không tham nhũng', c: 'Thanh tra không nhận lợi ích từ AI.' },
  { id: 'A30', ch: 'III', t: 'Công khai nội bộ', c: 'Báo cáo thanh tra công khai cho Super Admin.' },
  // CHƯƠNG IV — BẢO MẬT & TÀI CHÍNH
  { id: 'A31', ch: 'IV', t: 'Bảo mật nhiều tầng', c: 'Mọi request qua đủ tầng, không bỏ tầng nào.' },
  { id: 'A32', ch: 'IV', t: 'Lớp phòng vệ', c: 'Phòng vệ ngoài bổ sung cho bảo mật trong.' },
  { id: 'A33', ch: 'IV', t: 'Mã hoá bắt buộc', c: 'Mã hoá dữ liệu nhạy cảm, băm mật khẩu có chi phí.' },
  { id: 'A34', ch: 'IV', t: 'Audit trail 365 ngày', c: 'Log mọi hành động, giữ ≥1 năm.' },
  { id: 'A35', ch: 'IV', t: 'Rate limiting', c: 'Giới hạn tần suất theo người dùng; vượt → chặn tạm.' },
  { id: 'A36', ch: 'IV', t: 'Chống DDoS', c: 'Tự chặn DDoS trong 5 giây.' },
  { id: 'A37', ch: 'IV', t: 'Tài chính minh bạch', c: 'Mọi giao dịch có trace ID.' },
  { id: 'A38', ch: 'IV', t: 'Doanh thu hợp lệ', c: 'Chỉ từ gói học phí, khoá học, coaching.' },
  { id: 'A39', ch: 'IV', t: 'Báo cáo tài chính', c: 'Tự động định kỳ. Bất thường → báo ngay.' },
  { id: 'A40', ch: 'IV', t: 'Không rửa tiền', c: 'Giao dịch >500M cần xét duyệt cấp cao.' },
  // CHƯƠNG V — VẬN HÀNH & PHỤC HỒI
  { id: 'A41', ch: 'V', t: 'Quét trước khi chạy', c: 'Mọi file/script được quét trước khi thực thi.' },
  { id: 'A42', ch: 'V', t: 'Reset khẩn cấp 60s', c: 'Bị tấn công → tự reset về gốc trong 60s.' },
  { id: 'A43', ch: 'V', t: 'Backup 3-2-1', c: '3 bản, 2 định dạng, 1 offsite.' },
  { id: 'A44', ch: 'V', t: 'Chịu tải', c: 'Hệ thống phải chịu tải mục tiêu đã công bố.' },
  { id: 'A45', ch: 'V', t: 'Uptime 99.9%', c: 'Downtime >1h → báo cáo cấp cao.' },
  { id: 'A46', ch: 'V', t: 'Tự phục hồi <5 phút', c: 'Lỗi <5p → auto-heal.' },
  { id: 'A47', ch: 'V', t: 'Thư viện tri thức', c: 'Duy trì kho tài liệu chất lượng cao.' },
  { id: 'A48', ch: 'V', t: 'Bản đồ quy trình', c: 'Super Admin xem real-time toàn hệ.' },
  { id: 'A49', ch: 'V', t: 'Cải tiến liên tục', c: 'Mỗi tuần ≥1 cải tiến được ban hành.' },
  { id: 'A50', ch: 'V', t: 'Chế tài vi phạm', c: 'Cấp 1 cảnh cáo · cấp 2 tạm dừng · cấp 3 khai trừ.' },
];

const SEVERITY = { WARN: 1, SUSPEND: 2, BLOCK: 3 };

// Ký hiệu toán sai chuẩn (điều A02)
const RE_BAD_FRACTION = /(?<![\w\\])\d+\s*\/\s*\d+/;
const RE_BAD_POWER = /(?<![\\a-zA-Z])\^\d/;
const RE_BAD_SQRT = /(?<!\\)sqrt\s*\(/;

class Constitution {
  constructor() {
    this.version = '100.0.0';
    this.articles = ARTICLES;
    this.stats = { checks: 0, passed: 0, warned: 0, suspended: 0, blocked: 0, byArticle: Object.create(null) };
  }

  _violation(list, article, severity, msg) {
    list.push({ article, title: (ARTICLES.find((a) => a.id === article) || {}).t, severity, msg });
    this.stats.byArticle[article] = (this.stats.byArticle[article] || 0) + 1;
  }

  /**
   * @param {string} action  Tên hành động: publish | ai_dispatch | money | execute | security_bypass | llm_call | agent_task
   * @param {object} ctx     Ngữ cảnh kiểm tra
   */
  validate(action, ctx = {}) {
    this.stats.checks++;
    const v = [];

    if (action === 'publish') {
      if (!ctx.audited) this._violation(v, 'A06', SEVERITY.BLOCK, 'Chưa qua thanh tra');
      const tex = ctx.latex || '';
      if (tex) {
        if (RE_BAD_SQRT.test(tex)) this._violation(v, 'A02', SEVERITY.SUSPEND, 'Dùng sqrt() chưa chuẩn');
        if (RE_BAD_FRACTION.test(tex)) this._violation(v, 'A02', SEVERITY.SUSPEND, 'Dùng / chưa chuẩn');
        if (RE_BAD_POWER.test(tex)) this._violation(v, 'A02', SEVERITY.SUSPEND, 'Dùng ^ chưa chuẩn');
      }
      if (ctx.ageRating && ctx.ageRating === 'unsafe') this._violation(v, 'A07', SEVERITY.BLOCK, 'Nội dung không phù hợp lứa tuổi');
    }

    if (action === 'ai_dispatch' || action === 'agent_task') {
      if (ctx.specialtyMatch === false) this._violation(v, 'A13', SEVERITY.SUSPEND, 'AI làm ngoài chuyên môn');
      if (ctx.duplicate) this._violation(v, 'A17', SEVERITY.SUSPEND, 'Task trùng lặp');
      if ((ctx.capability ?? 1) < 0.95) this._violation(v, 'A12', SEVERITY.SUSPEND, 'AI chưa full capability');
      if (ctx.permitted === false) this._violation(v, 'A05', SEVERITY.BLOCK, 'Vượt quyền được cấp');
      if (ctx.consecutiveFailures >= 3) this._violation(v, 'A20', SEVERITY.SUSPEND, 'Lỗi liên tiếp — tạm dừng agent');
    }

    if (action === 'money') {
      if (!ctx.traceId) this._violation(v, 'A37', SEVERITY.BLOCK, 'Thiếu trace ID');
      if ((ctx.amount || 0) > 500_000_000) this._violation(v, 'A40', SEVERITY.BLOCK, 'Giao dịch >500M cần duyệt cấp cao');
      if (ctx.source && !['tuition', 'course', 'coaching'].includes(ctx.source)) {
        this._violation(v, 'A38', SEVERITY.SUSPEND, 'Nguồn doanh thu không hợp lệ');
      }
    }

    if (action === 'security_bypass') this._violation(v, 'A31', SEVERITY.BLOCK, 'Cố tình bỏ qua bảo mật');
    if (action === 'execute' && !ctx.scanned) this._violation(v, 'A41', SEVERITY.BLOCK, 'Chưa quét trước khi chạy');

    if (action === 'llm_call') {
      if (ctx.injectionDetected) this._violation(v, 'A31', SEVERITY.BLOCK, 'Phát hiện prompt injection');
      if (ctx.rateLimited) this._violation(v, 'A35', SEVERITY.SUSPEND, 'Vượt giới hạn tần suất');
    }

    if (ctx.audited === false && action === 'publish') { /* đã xử lý ở trên */ }

    const maxSeverity = v.reduce((m, x) => Math.max(m, x.severity), 0);
    const ok = maxSeverity < SEVERITY.BLOCK;

    if (!v.length) this.stats.passed++;
    else if (maxSeverity === SEVERITY.WARN) this.stats.warned++;
    else if (maxSeverity === SEVERITY.SUSPEND) this.stats.suspended++;
    else this.stats.blocked++;

    return {
      ok,
      action,
      violations: v,
      maxSeverity,
      sanction: maxSeverity === SEVERITY.BLOCK ? 'BLOCK'
        : maxSeverity === SEVERITY.SUSPEND ? 'SUSPEND'
          : maxSeverity === SEVERITY.WARN ? 'WARN' : 'ALLOW',
    };
  }

  byChapter() {
    const m = Object.create(null);
    for (const a of ARTICLES) m[a.ch] = (m[a.ch] || 0) + 1;
    return m;
  }

  get(idOrNull) {
    if (!idOrNull) return ARTICLES;
    return ARTICLES.find((a) => a.id === idOrNull.toUpperCase()) || null;
  }

  status() {
    const top = Object.entries(this.stats.byArticle).sort((a, b) => b[1] - a[1]).slice(0, 10);
    return {
      version: this.version,
      articles: ARTICLES.length,
      chapters: this.byChapter(),
      ...this.stats,
      byArticle: undefined,
      topViolatedArticles: top,
    };
  }
}

module.exports = Constitution;
module.exports.ARTICLES = ARTICLES;
module.exports.SEVERITY = SEVERITY;
