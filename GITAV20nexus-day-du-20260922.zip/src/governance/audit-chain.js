'use strict';
/**
 * Audit Chain — nhật ký quản trị bất biến (điều A08, A34: giữ ≥365 ngày).
 * Ghi vào stream 'audit' của EventStore; mọi bản ghi móc xích băm, sửa một bản là vỡ toàn chuỗi.
 */

const cfg = require('../config');

class AuditChain {
  constructor({ eventStore, guardrails }) {
    this.es = eventStore;
    this.guardrails = guardrails;
    this.retentionDays = cfg.AUDIT_RETENTION_DAYS;
    this.stats = { records: 0, denials: 0, sanctions: 0 };
  }

  /**
   * @param {object} entry {actor, action, target, verdict, severity, detail}
   */
  async record(entry) {
    const safe = {
      actor: entry.actor || 'system',
      actorRole: entry.actorRole || null,
      action: entry.action,
      target: entry.target || null,
      verdict: entry.verdict || 'ALLOW',
      severity: entry.severity || 0,
      detail: this.guardrails ? this.guardrails.redact(JSON.stringify(entry.detail ?? {})) : entry.detail,
    };
    this.stats.records++;
    if (safe.verdict !== 'ALLOW') this.stats.denials++;
    if (safe.severity >= 2) this.stats.sanctions++;
    return this.es.append('audit', safe.action, safe);
  }

  verify() { return this.es.verify(); }

  query({ actor = null, action = null, verdict = null, limit = 100 } = {}) {
    const all = this.es.read({ stream: 'audit', limit: 100000 }).items;
    let items = all;
    if (actor) items = items.filter((r) => r.payload.actor === actor);
    if (action) items = items.filter((r) => r.payload.action === action);
    if (verdict) items = items.filter((r) => r.payload.verdict === verdict);
    return { ok: true, total: items.length, items: items.slice(0, limit) };
  }

  /** Báo cáo tuân thủ — dùng cho hồ sơ Luật AI VN 134/2025 và kiểm toán nội bộ. */
  report() {
    const all = this.es.read({ stream: 'audit', limit: 100000 }).items;
    const byAction = Object.create(null);
    const byVerdict = Object.create(null);
    for (const r of all) {
      byAction[r.payload.action] = (byAction[r.payload.action] || 0) + 1;
      byVerdict[r.payload.verdict] = (byVerdict[r.payload.verdict] || 0) + 1;
    }
    const chain = this.verify();
    return {
      ok: true,
      generatedAt: new Date().toISOString(),
      retentionDays: this.retentionDays,
      totalRecords: all.length,
      byAction,
      byVerdict,
      chainIntegrity: chain.ok ? 'INTACT' : 'BROKEN',
      chainDetail: chain,
      legalBasis: [
        'Luật AI VN 134/2025/QH15',
        'Luật An ninh mạng 116/2025/QH15',
        'Luật Bảo vệ dữ liệu cá nhân 91/2025/QH15',
        'EU AI Act 2024/1689',
      ],
    };
  }

  status() { return { ...this.stats, retentionDays: this.retentionDays }; }
}

module.exports = AuditChain;
