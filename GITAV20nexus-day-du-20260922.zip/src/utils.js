'use strict';
/** Tiện ích dùng chung. Mọi hàm "ngẫu nhiên" đều tất định theo seed — không dùng Math.random() cho cấu hình hệ thống. */

// Nạp lười: tầng Cloudflare Workers dùng lại các mô-đun bên dưới (bức
// tường cây tiền, bộ canh đường ra) nhưng ở đó không có node:crypto trừ
// khi bật cờ nodejs_compat. Chỉ hai hàm dưới đây cần nó, và chúng không
// chạy trên Workers — nên nạp đúng lúc gọi thay vì lúc nạp mô-đun.
let _crypto = null;
function crypto_() {
  if (!_crypto) _crypto = require('node:crypto');
  return _crypto;
}

/** FNV-1a 32-bit: hash tất định, dùng cho phân bổ ổn định giữa các lần khởi động. */
function fnv1a(str) {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h >>> 0;
}

/** Bộ sinh số giả ngẫu nhiên tất định (mulberry32) — cùng seed cho cùng chuỗi. */
function seededRandom(seed) {
  let a = typeof seed === 'string' ? fnv1a(seed) : seed >>> 0;
  return function next() {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function sha256(input) {
  return crypto_().createHash('sha256').update(String(input)).digest('hex');
}

function shortHash(input, len = 16) {
  return sha256(input).slice(0, len);
}

function id(prefix) {
  return `${prefix}-${Date.now().toString(36).toUpperCase()}-${crypto_().randomBytes(4).toString('hex')}`;
}

function clamp(v, lo, hi) {
  return Math.min(hi, Math.max(lo, v));
}

function round(v, d = 4) {
  const f = 10 ** d;
  return Math.round(v * f) / f;
}

/** Phân vị từ mảng số (đã hoặc chưa sắp xếp). */
function percentile(values, p) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = clamp(Math.ceil((p / 100) * sorted.length) - 1, 0, sorted.length - 1);
  return sorted[idx];
}

/** Trung bình trượt hàm mũ. */
function ema(prev, next, alpha = 0.1) {
  return prev === null || prev === undefined || prev === 0 ? next : prev * (1 - alpha) + next * alpha;
}

/**
 * Phân bổ theo phương pháp phần dư lớn nhất (largest remainder).
 * Bảo đảm tổng phân bổ đúng bằng `total`, tất định khi có ràng buộc thứ tự.
 */
function largestRemainder(weights, total) {
  const sum = weights.reduce((a, b) => a + b, 0);
  if (sum === 0) return weights.map(() => 0);
  const exact = weights.map((w) => (w / sum) * total);
  const base = exact.map(Math.floor);
  let left = total - base.reduce((a, b) => a + b, 0);
  const order = exact
    .map((v, i) => ({ i, rem: v - Math.floor(v) }))
    .sort((a, b) => b.rem - a.rem || a.i - b.i);
  for (let k = 0; k < order.length && left > 0; k++, left--) base[order[k].i]++;
  return base;
}


/**
 * Bỏ dấu tiếng Việt để so khớp. Người dùng Việt Nam gõ không dấu rất thường xuyên,
 * nên mọi bộ luật phân loại/chặn đều phải khớp được cả hai dạng.
 *   "phương trình" → "phuong trinh" · "Đ" → "D"
 */
function deaccent(str) {
  return String(str)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\u0111/g, 'd')
    .replace(/\u0110/g, 'D');
}

/** Chuẩn hoá để so khớp: bỏ dấu + chữ thường + gộp khoảng trắng. */
function viKey(str) {
  return deaccent(str).toLowerCase().replace(/\s+/g, ' ').trim();
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Chạy fn với giới hạn thời gian; ném lỗi TIMEOUT nếu quá hạn. */
async function withTimeout(promise, ms, label = 'TIMEOUT') {
  let timer;
  try {
    return await Promise.race([
      promise,
      new Promise((_, rej) => {
        timer = setTimeout(() => rej(new Error(label)), ms);
      }),
    ]);
  } finally {
    clearTimeout(timer);
  }
}

function pad(n, width) {
  return String(n).padStart(width, '0');
}

module.exports = {
  fnv1a, seededRandom, sha256, shortHash, id,
  clamp, round, percentile, ema, largestRemainder,
  deaccent, viKey,
  sleep, withTimeout, pad,
};
