'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  TIÊU CHUẨN TẦNG — khắt khe, không có ngoại lệ
 * ═══════════════════════════════════════════════════════════════════════════
 *  Lên tầng chỉ khi đạt ĐỦ 7 tiêu chí. Thiếu một tiêu chí là ở lại tầng.
 *  Không làm tròn lên, không "gần đạt", không ưu tiên thâm niên.
 *
 *   1. mastery        — xác suất thạo (BKT) trung bình trên các dạng của tầng
 *   2. accuracy       — tỉ lệ đúng trên N bài gần nhất của tầng
 *   3. speed          — thời gian trung vị ≤ hệ số × thời gian chuẩn của dạng
 *   4. consistency    — số phiên liên tiếp đạt chuẩn accuracy
 *   5. coverage       — % số DẠNG của tầng đã đạt ngưỡng thạo
 *   6. exitExam       — điểm bài kiểm tra chốt tầng (đề riêng, không lặp bài đã luyện)
 *   7. noRegression   — không tụt dưới chuẩn ở bất kỳ tầng nào đã qua
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { LEVELS, formsForLevel } = require('./hierarchy');
const { round, clamp } = require('../utils');

/**
 * Chuẩn tăng dần theo tầng. Tầng càng cao, yêu cầu càng ngặt trên mọi chiều.
 * speedFactor giảm dần: L0 được chậm gấp đôi chuẩn, L9 phải nhanh hơn chuẩn.
 */
const LEVEL_STANDARDS = LEVELS.map((lv) => {
  const t = lv.id / 9; // 0 … 1
  return {
    level: lv.id,
    code: lv.code,
    name: lv.name,
    mastery: round(0.70 + 0.25 * t, 3),        // 0.700 → 0.950
    accuracy: round(0.70 + 0.25 * t, 3),       // 0.700 → 0.950
    window: 20 + Math.round(20 * t),           // 20 → 40 bài gần nhất
    speedFactor: round(2.0 - 1.1 * t, 3),      // ×2.00 → ×0.90 thời gian chuẩn
    consistency: 2 + Math.round(3 * t),        // 2 → 5 phiên liên tiếp
    coverage: round(0.60 + 0.35 * t, 3),       // 60% → 95% số dạng của tầng
    exitExam: round(0.70 + 0.25 * t, 3),       // 7.0 → 9.5 trên thang 10
    minItemsPerForm: 3 + Math.round(5 * t),    // 3 → 8 bài/dạng mới tính là đã học
  };
});

const STD_INDEX = new Map(LEVEL_STANDARDS.map((s) => [s.level, s]));

const CRITERIA = ['mastery', 'accuracy', 'speed', 'consistency', 'coverage', 'exitExam', 'noRegression'];

/**
 * Chấm một học viên so với chuẩn của tầng.
 * @param {number} level
 * @param {object} ev Bằng chứng đo được:
 *   { masteryByForm: {code: p}, attempts: [{formCode, correct, ms, at}],
 *     sessionsPassed: n, exitExamScore: 0..1, lowerLevelStatus: [{level, meets}] }
 * @returns {{ok, level, criteria, failed, score}}
 */
function evaluate(level, ev = {}) {
  const std = STD_INDEX.get(level);
  if (!std) return { ok: false, error: 'UNKNOWN_LEVEL', level };

  const forms = formsForLevel(level);
  const formCodes = forms.map((f) => f.code);
  const normByForm = new Map(forms.map((f) => [f.code, f.norm]));
  const masteryByForm = ev.masteryByForm || {};
  const attempts = (ev.attempts || []).filter((a) => formCodes.includes(a.formCode));
  const recent = attempts.slice(-std.window);

  // 1. mastery — trung bình trên các dạng ĐÃ học đủ số bài tối thiểu
  const learned = formCodes.filter((c) => attempts.filter((a) => a.formCode === c).length >= std.minItemsPerForm);
  const masteryVals = learned.map((c) => masteryByForm[c] ?? 0);
  const mastery = masteryVals.length ? masteryVals.reduce((a, b) => a + b, 0) / masteryVals.length : 0;

  // 2. accuracy — trên cửa sổ bài gần nhất
  const accuracy = recent.length ? recent.filter((a) => a.correct).length / recent.length : 0;

  // 3. speed — trung vị tỉ lệ thời gian thực / thời gian chuẩn
  const ratios = recent
    .filter((a) => a.ms > 0 && normByForm.has(a.formCode))
    .map((a) => (a.ms / 1000) / normByForm.get(a.formCode))
    .sort((x, y) => x - y);
  const speedRatio = ratios.length ? ratios[Math.floor(ratios.length / 2)] : Infinity;

  // 4. consistency
  const consistency = ev.sessionsPassed || 0;

  // 5. coverage — % dạng đạt ngưỡng thạo của tầng
  const mastered = formCodes.filter((c) => (masteryByForm[c] ?? 0) >= std.mastery);
  const coverage = formCodes.length ? mastered.length / formCodes.length : 0;

  // 6. exitExam
  const exitExam = ev.exitExamScore ?? 0;

  // 7. noRegression
  const lower = ev.lowerLevelStatus || [];
  const noRegression = lower.every((l) => l.meets !== false);

  const criteria = {
    mastery: { value: round(mastery, 3), required: std.mastery, pass: mastery >= std.mastery },
    accuracy: { value: round(accuracy, 3), required: std.accuracy, pass: accuracy >= std.accuracy, samples: recent.length, needSamples: std.window },
    speed: { value: Number.isFinite(speedRatio) ? round(speedRatio, 3) : null, required: std.speedFactor, pass: speedRatio <= std.speedFactor },
    consistency: { value: consistency, required: std.consistency, pass: consistency >= std.consistency },
    coverage: { value: round(coverage, 3), required: std.coverage, pass: coverage >= std.coverage, mastered: mastered.length, total: formCodes.length },
    exitExam: { value: round(exitExam, 3), required: std.exitExam, pass: exitExam >= std.exitExam },
    noRegression: { value: noRegression, required: true, pass: noRegression, regressedAt: lower.filter((l) => l.meets === false).map((l) => l.level) },
  };

  // Cửa sổ mẫu chưa đủ thì KHÔNG được coi là đạt, dù tỉ lệ đúng cao.
  if (recent.length < std.window) criteria.accuracy.pass = false;

  const failed = CRITERIA.filter((k) => !criteria[k].pass);
  const score = round(CRITERIA.filter((k) => criteria[k].pass).length / CRITERIA.length, 3);

  return {
    ok: failed.length === 0,
    level,
    levelName: std.name,
    standard: std,
    criteria,
    failed,
    score,
    verdict: failed.length === 0 ? 'ĐỦ ĐIỀU KIỆN LÊN TẦNG' : `Còn thiếu ${failed.length}/7 tiêu chí: ${failed.join(', ')}`,
  };
}

/** Khoảng cách tới chuẩn — dùng để sinh việc cần làm tiếp. */
function gaps(level, ev) {
  const r = evaluate(level, ev);
  if (r.error) return r;
  const out = [];
  for (const k of r.failed) {
    const c = r.criteria[k];
    out.push({
      criterion: k,
      current: c.value,
      required: c.required,
      action: ACTION_FOR[k](c, r.standard),
    });
  }
  return { ok: true, level, failed: r.failed, gaps: out };
}

const ACTION_FOR = {
  mastery: (c) => `Luyện thêm các dạng dưới ngưỡng thạo ${c.required}`,
  accuracy: (c) => c.samples < c.needSamples
    ? `Cần thêm ${c.needSamples - c.samples} bài để đủ cửa sổ đánh giá`
    : `Rà soát lỗi sai, nâng tỉ lệ đúng lên ${c.required}`,
  speed: (c) => `Luyện tốc độ: đang ×${c.value}, cần ≤ ×${c.required} thời gian chuẩn`,
  consistency: (c) => `Cần ${c.required - c.value} phiên đạt chuẩn liên tiếp nữa`,
  coverage: (c) => `Còn ${c.total - c.mastered} dạng chưa đạt ngưỡng thạo`,
  exitExam: (c) => `Thi chốt tầng, cần đạt ${(c.required * 10).toFixed(1)}/10`,
  noRegression: (c) => `Ôn lại tầng đã tụt: ${c.regressedAt.join(', ')}`,
};

function standardFor(level) { return STD_INDEX.get(level) || null; }

function validateStandards() {
  const errors = [];
  for (let i = 1; i < LEVEL_STANDARDS.length; i++) {
    const a = LEVEL_STANDARDS[i - 1], b = LEVEL_STANDARDS[i];
    if (b.mastery < a.mastery) errors.push(`mastery không tăng dần tại ${b.code}`);
    if (b.accuracy < a.accuracy) errors.push(`accuracy không tăng dần tại ${b.code}`);
    if (b.coverage < a.coverage) errors.push(`coverage không tăng dần tại ${b.code}`);
    if (b.exitExam < a.exitExam) errors.push(`exitExam không tăng dần tại ${b.code}`);
    if (b.speedFactor > a.speedFactor) errors.push(`speedFactor không siết dần tại ${b.code}`);
    if (b.window < a.window) errors.push(`window không tăng dần tại ${b.code}`);
  }
  const last = LEVEL_STANDARDS[LEVEL_STANDARDS.length - 1];
  if (last.mastery < 0.94) errors.push('Tầng cao nhất phải yêu cầu mastery ≥ 0.94');
  if (last.speedFactor > 1.0) errors.push('Tầng cao nhất phải yêu cầu nhanh hơn thời gian chuẩn');
  return { ok: errors.length === 0, errors, levels: LEVEL_STANDARDS.length, criteria: CRITERIA.length };
}

module.exports = { LEVEL_STANDARDS, CRITERIA, evaluate, gaps, standardFor, validateStandards };
