'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  HỆ PHÂN CẤP GITAmath — 5 tầng phân loại, biên soạn bài bản
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   KHỐI     →  LỚP      →  TẦNG (level)   →  CẤP ĐỘ (sao)  →  DẠNG (form)
 *   Block       Grade       10 tầng           1★ … 5★          mã định danh
 *
 *  Nguyên tắc:
 *   · Mỗi DẠNG là một đơn vị kiến thức có thể kiểm tra độc lập, biên soạn tay,
 *     có tiền đề (prereq) rõ ràng — KHÔNG sinh bằng tổ hợp máy móc.
 *   · Mỗi TẦNG có chuẩn vào/ra khắt khe (xem standards.js); thiếu một tiêu chí
 *     là không lên tầng, không có ngoại lệ.
 *   · Mã DẠNG là khoá bất biến dùng xuyên suốt: item bank, mastery, lộ trình,
 *     báo cáo. Đổi tên hiển thị được, đổi mã thì không.
 * ═══════════════════════════════════════════════════════════════════════════
 */

// ── KHỐI ────────────────────────────────────────────────────────────────────
const BLOCKS = {
  TIEU_HOC: { id: 'TIEU_HOC', name: 'Tiểu học', grades: [1, 2, 3, 4, 5], order: 1 },
  THCS: { id: 'THCS', name: 'Trung học cơ sở', grades: [6, 7, 8, 9], order: 2 },
  THPT: { id: 'THPT', name: 'Trung học phổ thông', grades: [10, 11, 12], order: 3 },
  LUYEN_THI_QG: { id: 'LUYEN_THI_QG', name: 'Luyện thi ĐGNL trong nước', grades: ['HSA', 'TSA', 'SPT'], order: 4 },
  QUOC_TE: { id: 'QUOC_TE', name: 'Chuẩn quốc tế', grades: ['IELTS', 'SAT', 'OLYMPIAD'], order: 5 },
};

// ── TẦNG (LEVEL) — 10 tầng năng lực, dùng chung cho mọi lớp ─────────────────
const LEVELS = [
  { id: 0, code: 'L0', name: 'Khởi động', desc: 'Nhận diện dạng, làm theo mẫu có hướng dẫn' },
  { id: 1, code: 'L1', name: 'Nền tảng', desc: 'Làm đúng dạng cơ bản, không cần gợi ý' },
  { id: 2, code: 'L2', name: 'Vững', desc: 'Làm đúng ổn định, trình bày đủ bước' },
  { id: 3, code: 'L3', name: 'Thành thạo', desc: 'Nhanh và chính xác, tự phát hiện lỗi' },
  { id: 4, code: 'L4', name: 'Nâng cao', desc: 'Giải bài biến thể, nhiều bước, có bẫy' },
  { id: 5, code: 'L5', name: 'Giỏi', desc: 'Tổng hợp liên dạng, chọn được cách tối ưu' },
  { id: 6, code: 'L6', name: 'Xuất sắc', desc: 'Bài khó cấp trường/quận, lập luận chặt' },
  { id: 7, code: 'L7', name: 'Chuyên', desc: 'Chuẩn thi chuyên, sáng tạo hướng giải' },
  { id: 8, code: 'L8', name: 'Tinh hoa', desc: 'Cấp tỉnh/quốc gia, bài mở, chứng minh khó' },
  { id: 9, code: 'L9', name: 'Đỉnh cao', desc: 'Olympic/quốc tế, bài chưa từng gặp' },
];

// ── CẤP ĐỘ KHÓ (trong mỗi tầng) ────────────────────────────────────────────
const DIFFICULTY = [
  { stars: 1, code: 'D1', name: 'Nhận biết', pTarget: 0.90, steps: '1-2' },
  { stars: 2, code: 'D2', name: 'Thông hiểu', pTarget: 0.80, steps: '2-3' },
  { stars: 3, code: 'D3', name: 'Vận dụng', pTarget: 0.65, steps: '3-5' },
  { stars: 4, code: 'D4', name: 'Vận dụng cao', pTarget: 0.45, steps: '5-8' },
  { stars: 5, code: 'D5', name: 'Thách thức', pTarget: 0.25, steps: '>8' },
];

/**
 * ── DẠNG (FORM) ────────────────────────────────────────────────────────────
 * Danh mục biên soạn tay. Mỗi dạng:
 *   code        mã bất biến  MÔN.LỚP.CHỦĐỀ.DẠNG
 *   name        tên hiển thị
 *   levelRange  [tầng thấp nhất, tầng cao nhất] mà dạng này xuất hiện
 *   prereq      các dạng phải thạo trước
 *   traps       lỗi sai điển hình — dùng để gắn nhãn hiểu sai của học viên
 *   norm        thời gian chuẩn (giây) để tính tốc độ
 */
const FORMS = require('./forms');

const FORM_INDEX = new Map(FORMS.map((f) => [f.code, f]));

/** Môn suy ra từ tiền tố mã dạng. */
const SUBJECT_OF = { M: 'math', E: 'english', X: 'aptitude' };

function subjectOf(code) { return SUBJECT_OF[code[0]] || 'other'; }

/** Lớp suy ra từ mã: M9.* → 9 · E.* → null (dùng chung) · X.* → null */
function gradeOf(code) {
  const m = code.match(/^M(\d{1,2})\./);
  return m ? Number(m[1]) : null;
}

function blockOfGrade(grade) {
  for (const b of Object.values(BLOCKS)) if (b.grades.includes(grade)) return b.id;
  return null;
}

function formsForLevel(level, { subject = null, grade = null } = {}) {
  return FORMS.filter((f) => {
    if (level < f.levelRange[0] || level > f.levelRange[1]) return false;
    if (subject && subjectOf(f.code) !== subject) return false;
    if (grade != null && gradeOf(f.code) != null && gradeOf(f.code) !== grade) return false;
    return true;
  });
}

/** Thứ tự học tôn trọng tiền đề — sắp xếp tô-pô, phát hiện chu trình. */
function learningOrder(codes = FORMS.map((f) => f.code)) {
  const want = new Set(codes);
  const visited = new Set();
  const visiting = new Set();
  const out = [];
  const cycles = [];

  const visit = (code, path) => {
    if (visited.has(code)) return;
    if (visiting.has(code)) { cycles.push([...path, code]); return; }
    visiting.add(code);
    const f = FORM_INDEX.get(code);
    if (f) for (const p of f.prereq) if (want.has(p)) visit(p, [...path, code]);
    visiting.delete(code);
    visited.add(code);
    out.push(code);
  };

  for (const c of codes) visit(c, []);
  return { order: out, cycles };
}

/** Kiểm tra tính toàn vẹn của danh mục — chạy lúc khởi động và trong test. */
function validateHierarchy() {
  const errors = [];
  const seen = new Set();
  for (const f of FORMS) {
    if (seen.has(f.code)) errors.push(`Trùng mã dạng: ${f.code}`);
    seen.add(f.code);
    if (!/^[MEX]\.?/.test(f.code)) errors.push(`Mã dạng sai quy ước: ${f.code}`);
    const [lo, hi] = f.levelRange;
    if (!(lo >= 0 && hi <= 9 && lo <= hi)) errors.push(`Khoảng tầng sai: ${f.code} [${lo},${hi}]`);
    if (!f.traps || !f.traps.length) errors.push(`Thiếu lỗi điển hình: ${f.code}`);
    if (!(f.norm > 0)) errors.push(`Thiếu thời gian chuẩn: ${f.code}`);
    for (const p of f.prereq) {
      if (!FORM_INDEX.has(p)) errors.push(`Tiền đề không tồn tại: ${f.code} → ${p}`);
      else if (FORM_INDEX.get(p).levelRange[0] > f.levelRange[0]) {
        errors.push(`Tiền đề nằm ở tầng cao hơn: ${f.code}(L${f.levelRange[0]}) → ${p}(L${FORM_INDEX.get(p).levelRange[0]})`);
      }
    }
  }
  const { cycles } = learningOrder();
  for (const c of cycles) errors.push(`Chu trình tiền đề: ${c.join(' → ')}`);

  // Mọi tầng phải có ít nhất một dạng, nếu không lộ trình sẽ đứt quãng.
  for (const lv of LEVELS) {
    if (!formsForLevel(lv.id).length) errors.push(`Tầng ${lv.code} không có dạng nào`);
  }
  return { ok: errors.length === 0, errors, forms: FORMS.length, levels: LEVELS.length };
}

module.exports = {
  BLOCKS, LEVELS, DIFFICULTY, FORMS, FORM_INDEX,
  subjectOf, gradeOf, blockOfGrade, formsForLevel, learningOrder, validateHierarchy,
};
