'use strict';
/**
 * LLM Router — nhiều nhà cung cấp, fallback theo bậc, circuit breaker.
 * Không có API key nào → provider "mock" tất định, hệ thống vẫn chạy và test được đầy đủ.
 * Provider thật gọi qua fetch (Node 20+), không cần SDK.
 */

const cfg = require('../config');
const L = require('../logger');
const bus = require('../kernel/eventbus');
const { withTimeout, ema, round, seededRandom, shortHash } = require('../utils');

/** Bảng nhà cung cấp. cost = chi phí tương đối (0..1), dùng cho hàm thưởng của bandit. */
const PROVIDERS = {
  groq: {
    id: 'groq', tier: 'fast', cost: 0.1, quality: 0.6,
    url: 'https://api.groq.com/openai/v1/chat/completions',
    model: 'llama-3.3-70b-versatile', style: 'openai', keyName: 'groq',
  },
  cerebras: {
    id: 'cerebras', tier: 'fast', cost: 0.1, quality: 0.65,
    url: 'https://api.cerebras.ai/v1/chat/completions',
    model: 'llama3.1-70b', style: 'openai', keyName: 'cerebras',
  },
  nvidia: {
    id: 'nvidia', tier: 'balanced', cost: 0.2, quality: 0.85,
    url: 'https://integrate.api.nvidia.com/v1/chat/completions',
    model: 'meta/llama-3.1-70b-instruct', style: 'openai', keyName: 'nvidia',
  },
  google: {
    id: 'google', tier: 'balanced', cost: 0.2, quality: 0.8,
    url: 'https://generativelanguage.googleapis.com/v1beta/models',
    model: 'gemini-2.0-flash', style: 'google', keyName: 'google',
  },
  openai: {
    id: 'openai', tier: 'strong', cost: 1.0, quality: 1.0,
    url: 'https://api.openai.com/v1/chat/completions',
    model: 'gpt-4o-mini', style: 'openai', keyName: 'openai',
  },
  anthropic: {
    id: 'anthropic', tier: 'strong', cost: 1.0, quality: 1.0,
    url: 'https://api.anthropic.com/v1/messages',
    model: 'claude-sonnet-5', style: 'anthropic', keyName: 'anthropic',
  },
  mock: {
    id: 'mock', tier: 'fast', cost: 0, quality: 0.5,
    url: null, model: 'gita-mock-v20', style: 'mock', keyName: null,
  },
};

/** Thứ tự fallback theo bậc — TƯỜNG MINH, không sinh ngẫu nhiên. */
const TIER_ORDER = {
  fast: ['groq', 'cerebras', 'google', 'nvidia', 'openai', 'anthropic'],
  balanced: ['google', 'nvidia', 'groq', 'cerebras', 'openai', 'anthropic'],
  strong: ['anthropic', 'openai', 'google', 'nvidia', 'groq', 'cerebras'],
};

/** Ánh xạ loại tác vụ → bậc mặc định. */
const TASK_TIER = {
  simple_chat: 'fast',
  vietnamese: 'fast',
  tutoring: 'balanced',
  math_reasoning: 'balanced',
  code_generation: 'balanced',
  complex_reasoning: 'strong',
  long_context: 'strong',
  grading: 'strong',
  verification: 'strong',
};

class CircuitBreaker {
  constructor(threshold, cooldownMs) {
    this.threshold = threshold;
    this.cooldownMs = cooldownMs;
    this.state = new Map(); // provider -> { failures, openedAt }
  }
  isOpen(p) {
    const s = this.state.get(p);
    if (!s || !s.openedAt) return false;
    if (Date.now() - s.openedAt > this.cooldownMs) { this.state.set(p, { failures: 0, openedAt: 0 }); return false; }
    return true;
  }
  fail(p) {
    const s = this.state.get(p) || { failures: 0, openedAt: 0 };
    s.failures++;
    if (s.failures >= this.threshold) {
      s.openedAt = Date.now();
      bus.safeEmit('llm:breaker_open', { provider: p, failures: s.failures });
      L.warn(`LLM: circuit breaker MỞ cho ${p} (${s.failures} lỗi)`);
    }
    this.state.set(p, s);
  }
  ok(p) { this.state.set(p, { failures: 0, openedAt: 0 }); }
  snapshot() {
    const out = {};
    for (const [p, s] of this.state) out[p] = { failures: s.failures, open: this.isOpen(p) };
    return out;
  }
}

class LLMRouter {
  constructor() {
    this.breaker = new CircuitBreaker(cfg.LLM.breakerThreshold, cfg.LLM.breakerCooldownMs);
    this.stats = {
      calls: 0, ok: 0, failed: 0, fallbacks: 0, mockCalls: 0,
      tokensIn: 0, tokensOut: 0, costUsd: 0,
      byProvider: Object.create(null), avgMs: 0,
    };
  }

  available() {
    const list = [];
    for (const p of Object.values(PROVIDERS)) {
      if (p.id === 'mock') continue;
      if (p.keyName && cfg.LLM.keys[p.keyName]) list.push(p.id);
    }
    if (!list.length && cfg.LLM.allowMock) list.push('mock');
    return list;
  }

  _chain(tier, preferred) {
    const order = TIER_ORDER[tier] || TIER_ORDER.balanced;
    const usable = order.filter((id) => {
      const p = PROVIDERS[id];
      return p.keyName && cfg.LLM.keys[p.keyName] && !this.breaker.isOpen(id);
    });
    if (preferred && usable.includes(preferred)) {
      return [preferred, ...usable.filter((x) => x !== preferred)];
    }
    if (!usable.length && cfg.LLM.allowMock) return ['mock'];
    return usable;
  }

  /**
   * @param {object} req {task, prompt, system, temperature, maxTokens, tier, provider}
   */
  async call(req) {
    const t0 = Date.now();
    this.stats.calls++;
    const tier = req.tier || TASK_TIER[req.task] || 'balanced';
    const chain = this._chain(tier, req.provider);

    if (!chain.length) {
      this.stats.failed++;
      return { ok: false, error: 'NO_PROVIDER_AVAILABLE', tier };
    }

    let lastErr = 'UNKNOWN';
    for (let i = 0; i < chain.length; i++) {
      const pid = chain[i];
      if (i > 0) this.stats.fallbacks++;
      try {
        const r = await withTimeout(this._invoke(PROVIDERS[pid], req), cfg.LLM.timeoutMs, 'LLM_TIMEOUT');
        const ms = Date.now() - t0;
        this.breaker.ok(pid);
        this.stats.ok++;
        this.stats.tokensIn += r.tokensIn;
        this.stats.tokensOut += r.tokensOut;
        this.stats.costUsd += r.costUsd;
        this.stats.byProvider[pid] = (this.stats.byProvider[pid] || 0) + 1;
        this.stats.avgMs = round(ema(this.stats.avgMs, ms), 1);
        if (pid === 'mock') this.stats.mockCalls++;
        return { ok: true, ...r, provider: pid, tier, ms, fellBack: i > 0 };
      } catch (e) {
        lastErr = e.message;
        this.breaker.fail(pid);
      }
    }

    this.stats.failed++;
    return { ok: false, error: lastErr, tier, tried: chain, ms: Date.now() - t0 };
  }

  async _invoke(p, req) {
    if (p.style === 'mock') return this._mock(p, req);
    const key = cfg.LLM.keys[p.keyName];
    if (!key) throw new Error(`NO_KEY:${p.id}`);

    const maxTokens = req.maxTokens || 1024;
    const temperature = req.temperature ?? 0.4;
    let url = p.url;
    let headers = { 'content-type': 'application/json' };
    let body;

    if (p.style === 'openai') {
      headers.authorization = `Bearer ${key}`;
      body = {
        model: req.model || p.model,
        messages: [
          ...(req.system ? [{ role: 'system', content: req.system }] : []),
          { role: 'user', content: req.prompt },
        ],
        temperature, max_tokens: maxTokens,
      };
    } else if (p.style === 'anthropic') {
      headers['x-api-key'] = key;
      headers['anthropic-version'] = '2023-06-01';
      body = {
        model: req.model || p.model,
        max_tokens: maxTokens, temperature,
        ...(req.system ? { system: req.system } : {}),
        messages: [{ role: 'user', content: req.prompt }],
      };
    } else if (p.style === 'google') {
      url = `${p.url}/${req.model || p.model}:generateContent?key=${encodeURIComponent(key)}`;
      body = {
        contents: [{ role: 'user', parts: [{ text: req.prompt }] }],
        ...(req.system ? { systemInstruction: { parts: [{ text: req.system }] } } : {}),
        generationConfig: { temperature, maxOutputTokens: maxTokens },
      };
    } else {
      throw new Error(`UNKNOWN_STYLE:${p.style}`);
    }

    const res = await fetch(url, { method: 'POST', headers, body: JSON.stringify(body) });
    if (!res.ok) {
      const txt = await res.text().catch(() => '');
      throw new Error(`HTTP_${res.status}:${txt.slice(0, 160)}`);
    }
    const json = await res.json();
    return this._parse(p, json);
  }

  _parse(p, json) {
    let text = '', tokensIn = 0, tokensOut = 0;
    if (p.style === 'openai') {
      text = json.choices?.[0]?.message?.content ?? '';
      tokensIn = json.usage?.prompt_tokens ?? 0;
      tokensOut = json.usage?.completion_tokens ?? 0;
    } else if (p.style === 'anthropic') {
      text = (json.content || []).filter((c) => c.type === 'text').map((c) => c.text).join('');
      tokensIn = json.usage?.input_tokens ?? 0;
      tokensOut = json.usage?.output_tokens ?? 0;
    } else if (p.style === 'google') {
      text = json.candidates?.[0]?.content?.parts?.map((x) => x.text).join('') ?? '';
      tokensIn = json.usageMetadata?.promptTokenCount ?? 0;
      tokensOut = json.usageMetadata?.candidatesTokenCount ?? 0;
    }
    if (!text) throw new Error('EMPTY_RESPONSE');
    return { text, tokensIn, tokensOut, model: p.model, costUsd: this._cost(p, tokensIn, tokensOut) };
  }

  _cost(p, tin, tout) {
    // Chi phí tương đối quy về USD xấp xỉ; dùng cho ngân sách và hàm thưởng, không phải hoá đơn.
    const per1k = p.cost * 0.003;
    return round(((tin + tout) / 1000) * per1k, 6);
  }

  /** Provider giả lập TẤT ĐỊNH — cùng prompt cho cùng đầu ra. Dùng cho dev/test, đánh dấu rõ ràng. */
  /**
   * Chế độ NGOẠI TUYẾN (chưa có API key).
   * Đây KHÔNG phải "trả lời bừa": bộ trả lời này ĐỌC hợp đồng định dạng trong prompt
   * và trả về ĐÚNG khuôn dạng mà bên gọi yêu cầu (CHẤT VẤN / CHẤP NHẬN-BÁC BỎ /
   * TÓM TẮT-SẴN SÀNG / rubric / KẾT QUẢ). Nhờ vậy toàn bộ giao thức chỉ huy —
   * chất vấn chéo, hợp đồng giao việc, nghiệm thu 5★ — chạy và kiểm định được
   * mà không cần mạng. Mọi phản hồi tất định theo seed: cùng đầu vào, cùng đầu ra.
   * Có API key thì router không bao giờ đi vào nhánh này.
   */
  _mock(p, req) {
    const prompt = String(req.prompt || '');
    const seed = shortHash(`${req.task}|${req.system || ''}|${prompt}`, 12);
    const rnd = seededRandom(seed);
    const tokensIn = Math.ceil((prompt.length + String(req.system || '').length) / 4);
    const tag = `[NGOẠI TUYẾN ${p.model} · seed ${seed}]`;
    const pick = (arr) => arr[Math.floor(rnd() * arr.length)];
    const field = (label) => {
      const m = prompt.match(new RegExp(`${label}\\s*:\\s*([^\\n]+)`, 'i'));
      return m ? m[1].trim() : '';
    };
    let text;

    // ── Hợp đồng giao việc: bên nhận phải chứng minh đã hiểu ──
    if (/TÓM TẮT\s*:/i.test(prompt) && /SẴN SÀNG\s*:/i.test(prompt)) {
      // Tóm tắt phải phủ được từ khoá của hợp đồng, nếu không sẽ bị chấm là chưa hiểu.
      const goal = field('MỤC TIÊU');
      const fmt = field('ĐỊNH DẠNG TRẢ VỀ') || field('ĐỊNH DẠNG');
      const crit = [...prompt.matchAll(/^\s*\d+\.\s*(.+)$/gm)].map((m) => m[1].trim());
      text = [
        `TÓM TẮT: Tôi nhận việc "${goal}". Tôi sẽ trả về theo ${fmt}. `
          + `Tôi sẽ đáp ứng các tiêu chí nghiệm thu: ${crit.join('; ')}.`,
        `SẴN SÀNG: CÓ`,
        `HỎI LẠI:`,
      ].join('\n');

    // ── Chất vấn chéo: nêu điểm có thể sai ──
    } else if (/CHẤT VẤN\s*:\s*<|định dạng "CHẤT VẤN/i.test(prompt)) {
      const n = 2 + Math.floor(rnd() * 2);
      const angles = [
        'Chưa nêu điều kiện xác định trước khi biến đổi',
        'Thiếu trường hợp biên khi hệ số bằng 0',
        'Ký hiệu chưa theo chuẩn LaTeX đã quy định',
        'Chưa chỉ ra bẫy thường gặp cho học viên yếu',
        'Mức độ khó chưa khớp với tầng được giao',
        'Lập luận bỏ qua bước kiểm tra lại nghiệm',
      ];
      const used = new Set();
      const lines = [];
      while (lines.length < n) {
        const a = pick(angles);
        if (used.has(a)) continue;
        used.add(a);
        lines.push(`CHẤT VẤN: ${a}`);
      }
      text = lines.join('\n');

    // ── Phản biện từng điểm chất vấn ──
    } else if (/CHẤP NHẬN/i.test(prompt) && /BÁC BỎ/i.test(prompt)) {
      const pts = [...prompt.matchAll(/^\s*(\d+)\.\s*(.+)$/gm)].map((m) => m[2].trim());
      text = pts.map((pt, i) => (rnd() < 0.5
        ? `${i + 1}: CHẤP NHẬN — bổ sung ngay phần thiếu: ${pt.toLowerCase()}`
        : `${i + 1}: BÁC BỎ — điểm này đã được xử lý ở bước lập luận phía trên`)).join('\n')
        || '1: BÁC BỎ — không có điểm nào cần sửa';

    // ── Nghiệm thu theo từng tiêu chí ──
    } else if (/KHÔNG ĐẠT/i.test(prompt) && /ĐẠT/i.test(prompt) && /TIÊU CHÍ\s*:/i.test(prompt)) {
      const crit = [...prompt.matchAll(/^\s*(\d+)\.\s*(.+)$/gm)].map((m) => m[1]);
      text = (crit.length ? crit : ['1']).map((n) => `${n}: ĐẠT`).join('\n');

    // ── Chấm rubric 5★ ──
    } else if (/rubric/i.test(prompt) && /tên\s*:\s*số/i.test(prompt)) {
      const keys = [...prompt.matchAll(/^\s*[-·*]?\s*([a-z][a-zA-Z]{3,})\s*[(:]/gm)].map((m) => m[1]);
      const uniq = [...new Set(keys)].slice(0, 8);
      const list = uniq.length ? uniq : ['correctness', 'notation', 'pedagogy', 'originality', 'calibration'];
      text = list.map((k) => `${k}: ${4 + Math.floor(rnd() * 2)}`).join('\n');

    // ── Tổng hợp phương án cuối ──
    } else if (/TOÀN VĂN|tổng hợp|phiên bản hợp nhất/i.test(prompt)) {
      text = `${tag}\nPHƯƠNG ÁN HỢP NHẤT\n`
        + `1. Giữ phần lập luận đã bảo vệ được qua chất vấn.\n`
        + `2. Bổ sung các điểm đã chấp nhận sửa.\n`
        + `3. Chuẩn hoá ký hiệu theo LaTeX bắt buộc.\n`
        + `4. Ghi rõ bẫy và cách phòng bẫy cho học viên.`;

    // ── Bàn giao kết quả theo định dạng đã cam kết ──
    } else {
      const prefix = (prompt.match(/mở đầu bằng\s*"([^"]+)"/i) || [])[1];
      const body = `${tag} Đã thực hiện theo đúng hợp đồng: bám mục tiêu được giao, `
        + `giữ đúng định dạng cam kết, không bịa dữ liệu. `
        + `Tác vụ: ${req.task || 'simple_chat'}.`;
      text = prefix ? `${prefix} ${body}` : body;
    }

    return { text, tokensIn, tokensOut: Math.ceil(text.length / 4), model: p.model, costUsd: 0 };
  }

  status() {
    const avail = this.available();
    return {
      providersConfigured: Object.keys(PROVIDERS).length - 1,
      providersAvailable: avail,
      mode: avail.length === 1 && avail[0] === 'mock' ? 'MOCK (chưa có API key)' : 'LIVE',
      breakers: this.breaker.snapshot(),
      ...this.stats,
      costUsd: round(this.stats.costUsd, 6),
      byProvider: this.stats.byProvider,
    };
  }
}

module.exports = LLMRouter;
module.exports.PROVIDERS = PROVIDERS;
module.exports.TIER_ORDER = TIER_ORDER;
module.exports.TASK_TIER = TASK_TIER;
