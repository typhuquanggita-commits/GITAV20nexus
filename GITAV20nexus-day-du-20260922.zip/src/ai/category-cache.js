'use strict';
/**
 * Category-Aware Cache (V20 §2.3): mỗi danh mục có ngưỡng, TTL, quota riêng.
 * PII và tài chính TẮT cache hoàn toàn (điều A04).
 * Không có vector DB → dùng cache chính xác theo băm; có thì bổ sung tầng ngữ nghĩa.
 */

const { shortHash, viKey } = require('../utils');

const CATEGORIES = {
  code: { threshold: 0.85, ttl: 86400, quota: 5000, enabled: true },
  math: { threshold: 0.90, ttl: 172800, quota: 3000, enabled: true },
  factual: { threshold: 0.92, ttl: 604800, quota: 4000, enabled: true },
  chat: { threshold: 0.95, ttl: 3600, quota: 1000, enabled: true },
  creative: { threshold: 0.88, ttl: 43200, quota: 2000, enabled: true },
  vietnamese: { threshold: 0.90, ttl: 86400, quota: 3000, enabled: true },
  general: { threshold: 0.92, ttl: 86400, quota: 3000, enabled: true },
  pii: { threshold: 0.99, ttl: 0, quota: 0, enabled: false },
  financial: { threshold: 0.99, ttl: 0, quota: 0, enabled: false },
};

/** Luật viết ở dạng KHÔNG DẤU; đầu vào được chuẩn hoá bằng viKey() trước khi khớp. */
const RULES = [
  ['pii', /\b\d{9,12}\b|\bcccd\b|\bcmnd\b|the tin dung|credit card|so can cuoc/],
  ['financial', /tai khoan ngan hang|giao dich|chuyen khoan|bank account|transaction|hoa don/],
  ['code', /\b(function|class|const|api|bug|python|javascript|typescript|import|thuat toan|lap trinh)\b/],
  ['math', /\b(toan|chung minh|phuong trinh|dinh ly|tich phan|dao ham|bat dang thuc|hinh hoc|dai so)\b|\\\\dfrac|\\\\sqrt/],
  ['vietnamese', /tieng viet|ngu phap|chinh ta|dich sang/],
  ['creative', /\b(viet bai|viet doan|viet tho|sang tao|story|poem|kich ban)\b/],
  ['factual', /\bla gi\b|what is|when did|who is|\bo dau\b|\bai la\b|nghia la/],
];

class CategoryCache {
  constructor({ store }) {
    this.store = store;
    this.counts = Object.create(null);
    this.stats = { hits: Object.create(null), misses: Object.create(null), sets: Object.create(null), skipped: 0 };
    for (const c of Object.keys(CATEGORIES)) {
      this.stats.hits[c] = 0; this.stats.misses[c] = 0; this.stats.sets[c] = 0; this.counts[c] = 0;
    }
  }

  classify(query) {
    const k = viKey(query);
    for (const [cat, re] of RULES) if (re.test(k)) return cat;
    if (k.length < 30) return 'chat';
    return 'general';
  }

  _key(cat, query) { return `cache:${cat}:${shortHash(query, 32)}`; }

  async get(query, category = null) {
    const cat = category || this.classify(query);
    const c = CATEGORIES[cat];
    if (!c || !c.enabled) { this.stats.skipped++; return null; }
    const raw = await this.store.get(this._key(cat, query));
    if (raw) {
      this.stats.hits[cat]++;
      try { return { value: JSON.parse(raw), level: 'exact', category: cat }; }
      catch { return { value: raw, level: 'exact', category: cat }; }
    }
    this.stats.misses[cat]++;
    return null;
  }

  async set(query, value, category = null) {
    const cat = category || this.classify(query);
    const c = CATEGORIES[cat];
    if (!c || !c.enabled) { this.stats.skipped++; return false; }
    if (this.counts[cat] >= c.quota) return false; // tôn trọng quota
    await this.store.set(this._key(cat, query), JSON.stringify(value), c.ttl);
    this.counts[cat]++;
    this.stats.sets[cat]++;
    return true;
  }

  status() {
    const cats = {};
    let H = 0, M = 0, S = 0;
    for (const [name, c] of Object.entries(CATEGORIES)) {
      const h = this.stats.hits[name], m = this.stats.misses[name], t = h + m;
      cats[name] = {
        hits: h, misses: m, sets: this.stats.sets[name], stored: this.counts[name],
        hitRate: t ? +((h / t) * 100).toFixed(1) : 0,
        threshold: c.threshold, ttl: c.ttl, quota: c.quota, enabled: c.enabled,
      };
      H += h; M += m; S += this.stats.sets[name];
    }
    const T = H + M;
    return {
      categories: cats,
      total: { hits: H, misses: M, sets: S, skipped: this.stats.skipped, hitRate: T ? +((H / T) * 100).toFixed(1) : 0 },
    };
  }
}

module.exports = CategoryCache;
module.exports.CATEGORIES = CATEGORIES;
