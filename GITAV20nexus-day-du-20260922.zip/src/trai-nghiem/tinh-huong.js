'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BỐN MƯƠI TÌNH HUỐNG CÓ THẬT TRONG ĐỜI MỘT KHÁCH HÀNG
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Đây KHÔNG phải danh sách "các trường hợp có thể xảy ra". Mỗi tình huống ở
 *  đây phải qua được ba cửa, không qua thì không được vào:
 *
 *    1. PHÁT HIỆN ĐƯỢC. Có một tín hiệu thật trong hệ thống hoặc một người
 *       thật báo vào. Tình huống chỉ "cảm thấy" được thì không ai xử lý được,
 *       và nó chỉ làm dài thêm tài liệu.
 *    2. CÓ NGƯỜI CHỊU. Mỗi tình huống ghi rõ AI xử. Tình huống không có chủ
 *       là tình huống không ai làm.
 *    3. CÓ MỤC CẤM LÀM. Chỗ này quan trọng nhất và hay bị bỏ nhất — phần lớn
 *       khách hàng mất không phải vì sự cố, mà vì cách người trực xử lý sự cố.
 *
 *  BA ĐIỀU TỆP NÀY KHÔNG LÀM
 *    · Không xếp hạng gia đình. Việc ấy nằm sau bức tường ở src/cay-tien/ và
 *      không một chữ nào của nó được xuất hiện ở đây.
 *    · Không hứa điểm số trong bất kỳ kịch bản nào.
 *    · Không bịa tín hiệu. Trường `doDuoc: false` nghĩa là hệ thống CHƯA đo
 *      được tín hiệu ấy và phải chờ người báo — nói thẳng còn hơn để người
 *      trực tưởng máy đang canh hộ.
 * ═══════════════════════════════════════════════════════════════════════════
 */

/** Bảy nhóm. Nhóm quyết định ai trực và xử trong bao lâu. */
const NHOM = {
  NHIP: { ma: 'NHIP', ten: 'Nhịp học', y: 'Đều hay không đều — thứ hỏng trước tiên khi khách sắp rời bỏ.' },
  CHAT_LUONG: { ma: 'CHAT_LUONG', ten: 'Chất lượng học', y: 'Có học nhưng học chưa vào — sửa được bằng cách dạy khác.' },
  CAM_XUC: { ma: 'CAM_XUC', ten: 'Cảm xúc và an toàn', y: 'Việc của người lớn, không phải việc của máy.' },
  GIA_DINH: { ma: 'GIA_DINH', ten: 'Quan hệ với gia đình', y: 'Phụ huynh mua hành trình của con, không mua khoá học.' },
  SU_CO: { ma: 'SU_CO', ten: 'Sự cố hệ thống', y: 'Lỗi của chúng ta. Cách xử lý quyết định khách ở hay đi.' },
  MOC: { ma: 'MOC', ten: 'Mốc và ăn mừng', y: 'Chỗ duy nhất được phép làm vượt kỳ vọng mà không tốn gì.' },
  ROI_BO: { ma: 'ROI_BO', ten: 'Rời bỏ và quay lại', y: 'Giữ một nhà sắp đi rẻ hơn tìm một nhà mới rất nhiều.' },
};

/** Mức khẩn — quyết định trong bao lâu phải chạm tới khách. */
const MUC = {
  DO: { ma: 'DO', ten: 'Đỏ', trongBaoLau: 'trong 2 giờ', y: 'Chậm một ngày là hỏng việc thật.' },
  CAM: { ma: 'CAM', ten: 'Cam', trongBaoLau: 'trong 24 giờ', y: 'Để qua ba ngày thì thành đỏ.' },
  VANG: { ma: 'VANG', ten: 'Vàng', trongBaoLau: 'trong 3 ngày', y: 'Không gấp, nhưng bỏ quên thì dồn lại.' },
  XANH: { ma: 'XANH', ten: 'Xanh', trongBaoLau: 'trong tuần', y: 'Việc nên làm, làm được thì hơn.' },
};

const TINH_HUONG = [
  // ── A. NHỊP HỌC ───────────────────────────────────────────────────────
  {
    ma: 'TH01', ten: 'Vắng ba ngày sau một giai đoạn đều', nhom: 'NHIP', muc: 'VANG',
    dauHieu: { nguon: 'telemetry', dieuKien: 'sessions = 0 trong 3 ngày, mà 14 ngày trước đó ≥ 3 buổi/tuần', doDuoc: true },
    aiXuLy: 'Cố vấn đồng hành',
    lamNgay: [
      'Xem buổi cuối cùng: em dừng ở bài nào, có dấu hiệu bí ở đó không.',
      'Nhắn một câu hỏi thăm KHÔNG nhắc tới việc vắng — hỏi về bài đang dở.',
    ],
    camLam: ['CẤM nhắn "sao mấy hôm nay con không học?" — câu ấy biến việc học thành việc bị kiểm tra.'],
    doBang: 'có buổi học trong 3 ngày kế tiếp',
  },
  {
    ma: 'TH02', ten: 'Vắng bảy ngày', nhom: 'NHIP', muc: 'CAM',
    dauHieu: { nguon: 'telemetry', dieuKien: 'sessions = 0 trong 7 ngày', doDuoc: true },
    aiXuLy: 'Cố vấn đồng hành, báo giáo viên phụ trách',
    lamNgay: [
      'Gọi cho gia đình, hỏi trước về hoàn cảnh chứ không hỏi về việc học.',
      'Hỏi đúng một câu: tuần này nhà mình bận gì, có cần giãn lịch không.',
      'Nếu gia đình muốn giãn: chốt luôn một lịch nhẹ hơn, đừng để trống.',
    ],
    camLam: [
      'CẤM nhắn tin thay cho gọi. Bảy ngày im lặng là lúc cần nghe giọng.',
      'CẤM đề nghị học bù dồn. Học dồn làm em sợ quay lại hơn.',
    ],
    doBang: 'có buổi học trong 7 ngày kế tiếp, hoặc có một lịch mới được chốt',
  },
  {
    ma: 'TH03', ten: 'Vắng mười bốn ngày', nhom: 'NHIP', muc: 'DO',
    dauHieu: { nguon: 'telemetry', dieuKien: 'sessions = 0 trong 14 ngày', doDuoc: true },
    aiXuLy: 'Người phụ trách lớp; nếu không liên lạc được thì báo quản lý',
    lamNgay: [
      'Gọi. Không được thì nhắn hẹn một giờ gọi cụ thể.',
      'Chuẩn bị sẵn ba phương án trước khi gọi: giãn lịch · đổi cố vấn · tạm dừng có hẹn quay lại.',
      'Nói thẳng là hệ thống đang giữ nguyên lộ trình của con, không mất gì.',
    ],
    camLam: [
      'CẤM gọi mà chưa chuẩn bị phương án — cuộc gọi ấy thành ra đòi nợ.',
      'CẤM để hai tuần nữa trôi qua rồi mới gọi lần hai.',
    ],
    doBang: 'liên lạc được và có một quyết định rõ ràng của gia đình',
  },
  {
    ma: 'TH04', ten: 'Buổi học ngắn dần', nhom: 'NHIP', muc: 'VANG',
    dauHieu: { nguon: 'telemetry', dieuKien: 'avgSessionMinutes tụt ≥ 30% so với hai tuần trước, mà số buổi không đổi', doDuoc: true },
    aiXuLy: 'Cố vấn đồng hành',
    lamNgay: [
      'Xem em bỏ dở ở chỗ nào trong buổi: đầu, giữa hay cuối.',
      'Bỏ ở cuối thì bài đang quá dài — cắt mục tiêu buổi xuống.',
      'Bỏ ở đầu thì bài đang quá khó — hạ một bậc rồi đi lên lại.',
    ],
    camLam: ['CẤM nhắc "con học chưa đủ giờ". Giờ không phải mục tiêu; việc làm xong mới là mục tiêu.'],
    doBang: 'avgSessionMinutes ổn định lại trong hai tuần',
  },
  {
    ma: 'TH05', ten: 'Học khuya thường xuyên', nhom: 'NHIP', muc: 'CAM',
    dauHieu: { nguon: 'telemetry', dieuKien: 'lateNightRate > 0.5 với sessions ≥ 5 (mẫu hình LATE_NIGHT)', doDuoc: true },
    aiXuLy: 'Cố vấn đồng hành, nói với NGƯỜI LỚN chứ không nói với em',
    lamNgay: [
      'Báo gia đình bằng số liệu: mấy buổi, khung giờ nào.',
      'Đề nghị dời khung giờ học cố định lên sớm hơn, chốt cùng gia đình.',
      'Xem cùng lúc miền giấc ngủ trong sàng lọc tâm lý nếu có.',
    ],
    camLam: [
      'CẤM nói riêng với em rằng "học khuya là xấu" — em sẽ giấu bằng cách không đăng nhập.',
      'CẤM coi học khuya là chăm chỉ. Đây là tín hiệu lịch đang vỡ.',
    ],
    doBang: 'lateNightRate giảm dưới 0.3 trong hai tuần',
  },
  {
    ma: 'TH06', ten: 'Quay lại sau một đợt gián đoạn', nhom: 'NHIP', muc: 'XANH',
    dauHieu: { nguon: 'telemetry', dieuKien: 'có buổi học sau ≥ 7 ngày không buổi nào', doDuoc: true },
    aiXuLy: 'Hệ thống chào trong buổi; cố vấn nhắn sau buổi đầu',
    lamNgay: [
      'Buổi đầu quay lại KHÔNG dạy bài mới: cho làm lại một bài em từng làm đúng.',
      'Nói rõ lộ trình còn nguyên, không ai xoá gì.',
      'Chốt lại một lịch nhẹ hơn lịch cũ.',
    ],
    camLam: [
      'CẤM nhắc tới quãng nghỉ dù chỉ một câu đùa.',
      'CẤM giao bài bù. Quay lại mà gặp núi bài thì lần sau không quay lại nữa.',
    ],
    doBang: 'có buổi thứ hai trong vòng 5 ngày',
  },

  // ── B. CHẤT LƯỢNG HỌC ────────────────────────────────────────────────
  {
    ma: 'TH07', ten: 'Phụ thuộc gợi ý', nhom: 'CHAT_LUONG', muc: 'VANG',
    dauHieu: { nguon: 'telemetry', dieuKien: 'hintRate > 0.6 với items ≥ 10 (mẫu hình HINT_DEPENDENT)', doDuoc: true },
    aiXuLy: 'Giáo viên phụ trách',
    lamNgay: [
      'Khoá gợi ý trong 90 giây đầu mỗi bài.',
      'Bắt viết bước 1 trước khi được mở gợi ý.',
      'Hạ độ khó một bậc để em có chỗ thắng mà không cần gợi ý.',
    ],
    camLam: ['CẤM tắt gợi ý hoàn toàn. Mất chỗ bám thì em bỏ bài, và ta mất luôn tín hiệu.'],
    doBang: 'hintRate xuống dưới 0.4 trên 20 bài kế tiếp',
  },
  {
    ma: 'TH08', ten: 'Xem lời giải trước khi làm', nhom: 'CHAT_LUONG', muc: 'VANG',
    dauHieu: { nguon: 'telemetry', dieuKien: 'peekRate > 0.35 với items ≥ 10 (mẫu hình PEEK_EARLY)', doDuoc: true },
    aiXuLy: 'Giáo viên phụ trách',
    lamNgay: [
      'Ẩn lời giải cho tới khi có một lần nộp.',
      'Cho em nộp "chưa biết làm" như một lựa chọn hợp lệ — để không cần lách bằng cách xem lời giải.',
    ],
    camLam: ['CẤM gọi đó là gian lận. Xem lời giải sớm gần như luôn là dấu hiệu bài quá khó, không phải dấu hiệu lười.'],
    doBang: 'peekRate xuống dưới 0.2 trên 20 bài kế tiếp',
  },
  {
    ma: 'TH09', ten: 'Làm vội và sai nhiều', nhom: 'CHAT_LUONG', muc: 'VANG',
    dauHieu: { nguon: 'telemetry', dieuKien: 'fastWrongRate > 0.4 với items ≥ 10 (mẫu hình RUSHING)', doDuoc: true },
    aiXuLy: 'Giáo viên phụ trách',
    lamNgay: [
      'Bắt buộc một bước "đọc lại đề" trước khi nộp, với ô nhập lại con số đề cho.',
      'Giảm số bài mỗi buổi xuống một nửa, giữ nguyên thời lượng.',
    ],
    camLam: ['CẤM thêm bài để "luyện cho cẩn thận". Nhiều bài hơn chỉ làm nhanh ẩu hơn.'],
    doBang: 'fastWrongRate xuống dưới 0.25 trên 20 bài kế tiếp',
  },
  {
    ma: 'TH10', ten: 'Sai do ẩu lặp lại', nhom: 'CHAT_LUONG', muc: 'VANG',
    dauHieu: { nguon: 'telemetry', dieuKien: 'carelessRate > 0.3 với items ≥ 15', doDuoc: true },
    aiXuLy: 'Giáo viên phụ trách',
    lamNgay: [
      'Lấy đúng năm bài em sai ẩu gần nhất, cho em tự tìm lỗi mà không nói lỗi ở đâu.',
      'Dựng một danh sách soát riêng cho em, do chính em viết.',
    ],
    camLam: ['CẤM nói "con cẩn thận hơn nhé". Câu ấy không đổi được hành vi nào.'],
    doBang: 'carelessRate xuống dưới 0.2 và danh sách soát được dùng thật',
  },
  {
    ma: 'TH11', ten: 'Hay bỏ bài giữa chừng', nhom: 'CHAT_LUONG', muc: 'CAM',
    dauHieu: { nguon: 'telemetry', dieuKien: 'skipRate > 0.25 với items ≥ 10 (mẫu hình GIVE_UP)', doDuoc: true },
    aiXuLy: 'Giáo viên phụ trách, báo cố vấn',
    lamNgay: [
      'Xem em bỏ ở dạng nào: một dạng thì là lỗ hổng, mọi dạng thì là chuyện khác ngoài bài.',
      'Chèn hai bài chắc chắn làm được trước bài khó.',
      'Nếu bỏ ở mọi dạng: chuyển sang nhóm cảm xúc, hỏi người lớn.',
    ],
    camLam: ['CẤM ép làm cho xong bài đã bỏ. Cưỡng chế một lần là mất nhịp cả tuần.'],
    doBang: 'skipRate xuống dưới 0.15 trên 20 bài kế tiếp',
  },
  {
    ma: 'TH12', ten: 'Sai đi sai lại đúng một bẫy', nhom: 'CHAT_LUONG', muc: 'CAM',
    dauHieu: { nguon: 'telemetry', dieuKien: 'cùng một cặp (dạng bài, bẫy) xuất hiện ≥ 3 lần trong topTraps', doDuoc: true },
    aiXuLy: 'Giáo viên phụ trách',
    lamNgay: [
      'Dừng dạy tiếp. Quay lại đúng khái niệm dưới cái bẫy ấy.',
      'Cho một bài có bẫy ấy và một bài không có, đặt cạnh nhau, bắt chỉ ra khác nhau ở đâu.',
    ],
    camLam: ['CẤM cho thêm bài cùng dạng. Lặp lại một lỗi không sửa được lỗi, chỉ làm nó thành thói quen.'],
    doBang: 'bẫy ấy không xuất hiện lại trong 10 bài cùng dạng',
  },
  {
    ma: 'TH13', ten: 'Đứng yên một cấp quá lâu', nhom: 'CHAT_LUONG', muc: 'CAM',
    dauHieu: { nguon: 'cay-50', dieuKien: 'ở cùng một ô của lưới 50 ô ≥ 21 ngày, không có bằng chứng mới', doDuoc: true },
    aiXuLy: 'Giáo viên phụ trách và cố vấn cùng xem',
    lamNgay: [
      'Đọc lại bằng chứng mà cấp ấy đòi: đòi hỏi có hợp lý với em không.',
      'Chia cấp ấy thành hai bước nhỏ và công nhận bước một.',
      'Nói với gia đình trước khi họ tự nhận ra — nói sau là mất thế.',
    ],
    camLam: [
      'CẤM hạ chuẩn của cấp để cho qua. Hạ chuẩn một lần là cả lưới 50 ô mất giá trị.',
      'CẤM im lặng chờ em tự vượt.',
    ],
    doBang: 'có bằng chứng mới trong 14 ngày, hoặc có một quyết định đổi cách dạy được ghi lại',
  },

  // ── C. CẢM XÚC VÀ AN TOÀN ────────────────────────────────────────────
  {
    ma: 'TH14', ten: 'Sàng lọc tâm lý báo cần người lớn ngay', nhom: 'CAM_XUC', muc: 'DO',
    dauHieu: { nguon: 'khao-sat', dieuKien: 'miền AN_TOAN của sàng lọc tâm lý học đường vượt ngưỡng canNguoiNgay', doDuoc: true },
    aiXuLy: 'Người có thẩm quyền đã được chỉ định trước, KHÔNG phải người trực ca',
    lamNgay: [
      'Chuyển ngay cho người đã được chỉ định. Không tự xử lý.',
      'Không để em một mình với màn hình: dừng phần giao bài.',
      'Ghi lại đúng giờ chuyển và ai nhận.',
    ],
    camLam: [
      'CẤM tự tư vấn. Đây là sàng lọc, không phải chẩn đoán, và người trực không phải người có chuyên môn.',
      'CẤM nhắn kết quả sàng lọc qua tin nhắn cho gia đình.',
      'CẤM chờ hết ca rồi bàn giao.',
    ],
    doBang: 'có tên người lớn đã nhận và thời điểm nhận',
    kichBanSuCo: 'KB04',
  },
  {
    ma: 'TH15', ten: 'Căng thẳng thi cử tăng', nhom: 'CAM_XUC', muc: 'CAM',
    dauHieu: { nguon: 'khao-sat', dieuKien: 'miền lo âu thi cử của sàng lọc tâm lý ở mức cao, hoặc người lớn báo', doDuoc: true },
    aiXuLy: 'Cố vấn đồng hành, có người lớn trong nhà cùng biết',
    lamNgay: [
      'Giảm số đề bấm giờ trong hai tuần, giữ nguyên bài luyện thường.',
      'Cho một đề ngắn đúng sức để em thấy mình làm được.',
      'Nói với gia đình: hai tuần này không so điểm.',
    ],
    camLam: ['CẤM tăng cường độ luyện đề để "quen áp lực". Đó là cách làm hỏng cả kỳ thi lẫn đứa trẻ.'],
    doBang: 'em làm hết được một đề đúng sức và gia đình xác nhận nhà đỡ căng',
  },
  {
    ma: 'TH16', ten: 'Dấu hiệu thiếu ngủ', nhom: 'CAM_XUC', muc: 'CAM',
    dauHieu: { nguon: 'khao-sat + telemetry', dieuKien: 'miền giấc ngủ ở mức nặng, hoặc lateNightRate cao kèm accuracy tụt', doDuoc: true },
    aiXuLy: 'Cố vấn đồng hành, nói với người lớn',
    lamNgay: [
      'Nói bằng số: mấy buổi sau 22 giờ, độ chính xác chênh bao nhiêu so với buổi sớm.',
      'Đề nghị một khung giờ học sớm và một giờ tắt máy, chốt cùng gia đình.',
    ],
    camLam: ['CẤM xếp lịch học tối muộn cho em này, dù gia đình đề nghị. Nói rõ vì sao.'],
    doBang: 'không còn buổi nào sau 22 giờ trong hai tuần',
  },
  {
    ma: 'TH17', ten: 'Em tự nói mình kém, mình chán', nhom: 'CAM_XUC', muc: 'CAM',
    dauHieu: { nguon: 'nguoi-bao', dieuKien: 'giáo viên, cố vấn hoặc gia đình ghi nhận — hệ thống KHÔNG đo được câu nói', doDuoc: false },
    aiXuLy: 'Cố vấn đồng hành',
    lamNgay: [
      'Mở bản đồ năng lực và chỉ ra ba thứ em làm được mà ba tháng trước chưa làm được.',
      'Hỏi em một câu: phần nào làm con thấy nản nhất — rồi bỏ đúng phần ấy ra khỏi tuần này.',
    ],
    camLam: [
      'CẤM an ủi bằng câu chung chung "con giỏi mà". Em biết là không đúng, và lần sau em không nói nữa.',
      'CẤM kể thành tích của bạn khác.',
    ],
    doBang: 'em nêu được tên một việc mình làm được, và tuần sau vẫn học',
  },
  {
    ma: 'TH18', ten: 'Gia đình đang gây áp lực điểm số', nhom: 'CAM_XUC', muc: 'CAM',
    dauHieu: { nguon: 'nguoi-bao', dieuKien: 'ghi nhận từ buổi gặp hoặc từ chính em — không đo được bằng máy', doDuoc: false },
    aiXuLy: 'Người phụ trách lớp nói với người lớn trong nhà',
    lamNgay: [
      'Nói chuyện riêng với người lớn, không có em ở đó.',
      'Đưa bằng chứng tiến bộ theo mốc cứng, không đưa điểm.',
      'Thống nhất một câu mà cả nhà dùng khi hỏi về việc học, thay cho câu hỏi điểm.',
    ],
    camLam: [
      'CẤM đứng về phía em trước mặt người lớn. Làm thế là mất cả hai.',
      'CẤM hứa một mức điểm để người lớn yên tâm.',
    ],
    doBang: 'gia đình dùng câu đã thống nhất, và em nói ở nhà bớt căng',
  },

  // ── D. QUAN HỆ VỚI GIA ĐÌNH ──────────────────────────────────────────
  {
    ma: 'TH19', ten: 'Gia đình hỏi tiến độ', nhom: 'GIA_DINH', muc: 'VANG',
    dauHieu: { nguon: 'nguoi-bao', dieuKien: 'gia đình nhắn hoặc gọi hỏi', doDuoc: false },
    aiXuLy: 'Cố vấn đồng hành',
    lamNgay: [
      'Trả lời bằng MỐC CỨNG gần nhất đã qua, kèm ngày.',
      'Nói rõ cấp đang đi và bằng chứng cấp ấy đòi.',
      'Kèm một việc cụ thể gia đình quan sát được ở nhà trong tuần này.',
    ],
    camLam: [
      'CẤM trả lời bằng mốc mềm như thể đã đạt.',
      'CẤM trả lời bằng phần trăm hoàn thành khoá học — con số ấy không nói lên năng lực nào.',
    ],
    doBang: 'gia đình nhắc lại đúng mốc ấy trong lần trao đổi sau',
  },
  {
    ma: 'TH20', ten: 'Gia đình hỏi bao giờ con được điểm cao', nhom: 'GIA_DINH', muc: 'VANG',
    dauHieu: { nguon: 'nguoi-bao', dieuKien: 'gia đình hỏi thẳng về mốc điểm hoặc mốc thi', doDuoc: false },
    aiXuLy: 'Người phụ trách lớp',
    lamNgay: [
      'Nói thẳng: hệ thống không hứa điểm, và giải thích vì sao lời hứa ấy không ai giữ được.',
      'Đổi câu hỏi sang thứ hứa được: con sẽ làm được gì, đo bằng gì, vào khoảng nào.',
      'Đưa mốc cứng kế tiếp và điều kiện của nó.',
    ],
    camLam: [
      'CẤM đưa một con số để gia đình yên tâm. Con số ấy quay lại làm chứng chống mình.',
      'CẤM nói "tuỳ vào con" — đó là đẩy trách nhiệm.',
    ],
    doBang: 'gia đình chấp nhận cách đo bằng mốc và nhắc lại được mốc kế tiếp',
  },
  {
    ma: 'TH21', ten: 'Gia đình không tin số liệu', nhom: 'GIA_DINH', muc: 'CAM',
    dauHieu: { nguon: 'nguoi-bao', dieuKien: 'gia đình nói số liệu không khớp với những gì họ thấy ở nhà', doDuoc: false },
    aiXuLy: 'Người phụ trách lớp',
    lamNgay: [
      'Coi đó là một báo lỗi, không phải một lời phàn nàn. Đi kiểm tra thật.',
      'Mở đúng bài làm của em cho gia đình xem, không mở bảng tổng hợp.',
      'Nếu số liệu sai thật: nhận, sửa, và nói ai đã sửa.',
    ],
    camLam: [
      'CẤM giải thích cách tính chỉ số để chứng minh mình đúng.',
      'CẤM nói "phần mềm tính tự động" — câu ấy nghĩa là không ai chịu trách nhiệm.',
    ],
    doBang: 'có kết luận đúng hay sai bằng bài làm cụ thể, và gia đình xác nhận đã xem',
  },
  {
    ma: 'TH22', ten: 'Gia đình muốn đổi người đồng hành', nhom: 'GIA_DINH', muc: 'CAM',
    dauHieu: { nguon: 'nguoi-bao', dieuKien: 'gia đình đề nghị đổi giáo viên hoặc cố vấn', doDuoc: false },
    aiXuLy: 'Quản lý phụ trách, KHÔNG phải người đang bị đề nghị đổi',
    lamNgay: [
      'Đổi trước, tìm hiểu sau. Giữ người để chứng minh mình đúng là mất cả nhà.',
      'Bàn giao bằng hồ sơ: người mới phải biết em đang ở cấp nào và từng vấp ở đâu.',
      'Sau khi đổi xong mới hỏi người cũ để rút kinh nghiệm.',
    ],
    camLam: [
      'CẤM để người đang bị đề nghị đổi tự đi thuyết phục gia đình.',
      'CẤM bắt gia đình nêu lý do như một điều kiện để được đổi.',
    ],
    doBang: 'người mới nhận việc trong 3 ngày và em không lỡ buổi nào',
  },
  {
    ma: 'TH23', ten: 'Gia đình im lặng, không mở báo cáo', nhom: 'GIA_DINH', muc: 'VANG',
    dauHieu: { nguon: 'he-thong', dieuKien: 'không có phiên đăng nhập của tài khoản phụ huynh trong 30 ngày', doDuoc: true },
    aiXuLy: 'Cố vấn đồng hành',
    lamNgay: [
      'Đừng gửi thêm báo cáo. Gọi một cuộc ngắn và kể ba câu.',
      'Hỏi gia đình muốn nhận tin theo cách nào — có nhà chỉ muốn nghe, không muốn đọc.',
      'Ghi lại cách họ chọn và làm đúng như thế.',
    ],
    camLam: ['CẤM tăng tần suất gửi báo cáo. Im lặng không phải do thiếu thông tin.'],
    doBang: 'gia đình chọn được một cách nhận tin và dùng nó ít nhất một lần',
  },
  {
    ma: 'TH24', ten: 'Gia đình giới thiệu người quen', nhom: 'GIA_DINH', muc: 'XANH',
    dauHieu: { nguon: 'nguoi-bao', dieuKien: 'gia đình nhắc tới một nhà khác, hoặc nhà mới nói được ai giới thiệu', doDuoc: false },
    aiXuLy: 'Người phụ trách lớp',
    lamNgay: [
      'Cảm ơn bằng một việc cho CHÍNH CON HỌ, không bằng quà hay chiết khấu.',
      'Ghi lại nguồn giới thiệu để biết việc đồng hành nào đang thật sự có giá trị.',
      'Nhà được giới thiệu phải được đón bởi người biết trước hoàn cảnh.',
    ],
    camLam: [
      'CẤM biến gia đình thành người bán hàng.',
      'CẤM để nhà mới kể lại từ đầu những gì người giới thiệu đã kể.',
    ],
    doBang: 'nhà mới đi hết được buổi đo đầu vào',
  },
  {
    ma: 'TH25', ten: 'Gia đình yêu cầu xoá dữ liệu', nhom: 'GIA_DINH', muc: 'CAM',
    dauHieu: { nguon: 'nguoi-bao', dieuKien: 'gia đình yêu cầu bằng văn bản hoặc lời nói', doDuoc: false },
    aiXuLy: 'Quản trị hệ thống, có người phụ trách lớp cùng biết',
    lamNgay: [
      'Xác minh đúng người có quyền yêu cầu.',
      'Nói rõ xoá gì và không xoá được gì, kèm lý do pháp lý nếu có.',
      'Làm trong thời hạn đã cam kết và gửi xác nhận đã làm.',
    ],
    camLam: [
      'CẤM thuyết phục gia đình đổi ý trước khi xử lý yêu cầu.',
      'CẤM xoá bản ghi kiểm toán về chính việc xoá ấy.',
    ],
    doBang: 'có xác nhận đã xoá kèm thời điểm, và nhật ký kiểm toán còn nguyên',
    kichBanSuCo: 'KB07',
  },

  // ── E. SỰ CỐ HỆ THỐNG ────────────────────────────────────────────────
  {
    ma: 'TH26', ten: 'Học liệu sai đáp số lọt tới học viên', nhom: 'SU_CO', muc: 'DO',
    dauHieu: { nguon: 'he-thong + nguoi-bao', dieuKien: 'mục soi bằng chứng học liệu báo lỗi, hoặc học viên/giáo viên báo', doDuoc: true },
    aiXuLy: 'Quản trị học liệu',
    lamNgay: [
      'Gỡ bài khỏi kho ngay, trước khi tìm nguyên nhân.',
      'Tìm đúng những em đã làm bài ấy và sửa lại kết quả của các em.',
      'Nói với từng nhà: bài sai là lỗi của chúng tôi, không phải con làm sai.',
    ],
    camLam: [
      'CẤM im lặng sửa rồi cho qua. Em nào đã bị chấm sai sẽ nhớ rất lâu.',
      'CẤM đổ cho mô hình sinh đề.',
    ],
    doBang: 'bài đã gỡ, danh sách em bị ảnh hưởng đã được liên hệ hết',
    kichBanSuCo: 'KB05',
  },
  {
    ma: 'TH27', ten: 'Hệ thống gián đoạn giữa buổi học', nhom: 'SU_CO', muc: 'DO',
    dauHieu: { nguon: 'he-thong', dieuKien: 'mục kiểm sức khoẻ báo không phục vụ được, hoặc buổi học đứt giữa chừng', doDuoc: true },
    aiXuLy: 'Trực hạ tầng, cố vấn báo gia đình',
    lamNgay: [
      'Giữ nguyên tiến độ buổi đang dở, không bắt làm lại từ đầu.',
      'Nhắn cho những nhà có buổi bị đứt, trong ngày, nói rõ đã mất gì và không mất gì.',
      'Xếp lại buổi bù vào giờ gia đình chọn, không tự xếp.',
    ],
    camLam: [
      'CẤM chờ gia đình hỏi rồi mới nói.',
      'CẤM nói "lỗi mạng của nhà mình" khi chưa kiểm tra.',
    ],
    doBang: 'mọi buổi bị đứt đều có một buổi bù đã được chốt',
    kichBanSuCo: 'KB06',
  },
  {
    ma: 'TH28', ten: 'Chấm sai hoặc hiển thị sai kết quả', nhom: 'SU_CO', muc: 'DO',
    dauHieu: { nguon: 'nguoi-bao', dieuKien: 'học viên hoặc gia đình báo kết quả không đúng với bài làm', doDuoc: false },
    aiXuLy: 'Giáo viên phụ trách, báo quản trị học liệu',
    lamNgay: [
      'Mở lại bài làm gốc, đối chiếu từng bước, trong ngày.',
      'Sai thì sửa và nói rõ đã sửa gì; đúng thì giải thích bằng chính bài làm.',
      'Xem có bao nhiêu em khác cùng dạng bài ấy bị như vậy.',
    ],
    camLam: ['CẤM trả lời "hệ thống chấm tự động nên không sai" trước khi mở bài ra xem.'],
    doBang: 'có kết luận bằng bài làm cụ thể trong 24 giờ',
  },
  {
    ma: 'TH29', ten: 'Trợ lý AI chuyên môn không trả lời được', nhom: 'SU_CO', muc: 'CAM',
    dauHieu: { nguon: 'he-thong', dieuKien: 'mục soi sức khoẻ đội hình báo trợ lý treo, hoặc yêu cầu quá hạn', doDuoc: true },
    aiXuLy: 'Trực hệ thống',
    lamNgay: [
      'Chuyển việc sang tuyến người thật, đừng để học viên chờ.',
      'Nói thẳng với em là phần này đang do người phụ trách, không giả vờ vẫn là máy.',
    ],
    camLam: ['CẤM để màn hình quay vòng chờ quá một phút mà không nói gì.'],
    doBang: 'việc được người thật nhận trong 10 phút',
    kichBanSuCo: 'KB06',
  },
  {
    ma: 'TH30', ten: 'Nghi mất dữ liệu buổi học', nhom: 'SU_CO', muc: 'DO',
    dauHieu: { nguon: 'he-thong', dieuKien: 'mục soi bền vững dữ liệu báo lệch, hoặc học viên báo bài đã làm biến mất', doDuoc: true },
    aiXuLy: 'Quản trị hệ thống',
    lamNgay: [
      'Dừng ghi, sao lưu nguyên thư mục dữ liệu trước khi làm bất cứ gì.',
      'Nói với gia đình trong ngày, kể cả khi chưa biết mất bao nhiêu.',
      'Khôi phục xong thì nói rõ đã khôi phục được gì và mất gì.',
    ],
    camLam: [
      'CẤM khởi động lại "xem thử".',
      'CẤM nói "chắc con chưa nộp" khi chưa kiểm tra nhật ký.',
    ],
    doBang: 'có biên bản nêu rõ mất gì, khôi phục được gì',
    kichBanSuCo: 'KB01',
  },

  // ── F. MỐC VÀ ĂN MỪNG ────────────────────────────────────────────────
  {
    ma: 'TH31', ten: 'Vừa qua một mốc cứng', nhom: 'MOC', muc: 'XANH',
    dauHieu: { nguon: 'cay-50', dieuKien: 'bằng chứng của cấp 3, 6 hoặc 10 vừa đủ điều kiện', doDuoc: true },
    aiXuLy: 'Hệ thống báo trong buổi; cố vấn nhắn gia đình trong ngày',
    lamNgay: [
      'Nói đúng việc em vừa làm được, bằng câu của cấp ấy — không nói chung chung là "giỏi lắm".',
      'Gửi cho gia đình kèm bằng chứng: bài nào, ngày nào.',
      'Nói luôn cấp kế tiếp đòi gì, để đà không đứt.',
    ],
    camLam: ['CẤM chúc mừng mốc mềm như mốc cứng. Làm một lần là cả 50 ô mất giá trị.'],
    doBang: 'gia đình mở tin ấy, và em bắt đầu cấp kế tiếp trong 7 ngày',
  },
  {
    ma: 'TH32', ten: 'Vừa lên một tầng', nhom: 'MOC', muc: 'XANH',
    dauHieu: { nguon: 'cay-50', dieuKien: 'qua cấp 10 của một tầng — chỗ nối sang tầng sau', doDuoc: true },
    aiXuLy: 'Người phụ trách lớp',
    lamNgay: [
      'Gọi, đừng nhắn. Đây là một trong vài dịp đáng một cuộc gọi.',
      'Kể lại chặng vừa qua bằng ba mốc cứng, theo thứ tự thời gian.',
      'Nói trước rằng tầng mới sẽ khó hơn và chậm hơn — để nhà không hoang mang ở tuần thứ ba.',
    ],
    camLam: ['CẤM để chỗ nối trôi qua không ai nhắc. Đây là chỗ học viên rơi nhiều nhất.'],
    doBang: 'gia đình nhắc lại được tên tầng mới, và em có buổi đầu của tầng mới trong 7 ngày',
  },
  {
    ma: 'TH33', ten: 'Buổi học thứ 10, 50, 100', nhom: 'MOC', muc: 'XANH',
    dauHieu: { nguon: 'telemetry', dieuKien: 'tổng số buổi chạm đúng 10, 50 hoặc 100', doDuoc: true },
    aiXuLy: 'Hệ thống nói trong buổi',
    lamNgay: [
      'Nói bằng việc, không bằng con số: "100 buổi này con đã vá xong N lỗ hổng" — lấy số thật.',
      'Cho em xem lại một bài từ buổi đầu mà giờ em làm được dễ dàng.',
    ],
    camLam: ['CẤM chúc mừng suông chỉ vì đủ số buổi. Đi đủ buổi mà không tiến là chuyện cần nói, không phải chuyện để mừng.'],
    doBang: 'em xem lại bài cũ ấy',
  },
  {
    ma: 'TH34', ten: 'Vá xong một lỗ hổng kéo dài', nhom: 'MOC', muc: 'XANH',
    dauHieu: { nguon: 'mastery', dieuKien: 'một dạng từng ở mức yếu ≥ 30 ngày nay đạt ngưỡng thạo', doDuoc: true },
    aiXuLy: 'Giáo viên phụ trách',
    lamNgay: [
      'Gọi tên đúng lỗ hổng ấy và nhắc lại nó đã kéo dài bao lâu.',
      'Nói cho gia đình biết, vì đây là thứ họ đã nghe phàn nàn nhiều tháng.',
    ],
    camLam: ['CẤM xếp ngay bài khó hơn trong cùng buổi. Để em ở lại chỗ vừa thắng thêm một buổi.'],
    doBang: 'dạng ấy vẫn đạt ngưỡng sau 14 ngày',
  },
  {
    ma: 'TH35', ten: 'Lần đầu tự làm được bài chưa từng gặp', nhom: 'MOC', muc: 'XANH',
    dauHieu: { nguon: 'telemetry', dieuKien: 'bài thuộc dạng chưa từng làm, đúng, hintsUsed = 0, không xem lời giải', doDuoc: true },
    aiXuLy: 'Hệ thống nói ngay trong buổi',
    lamNgay: [
      'Nói đúng cái em vừa làm: tự chọn hướng cho một bài chưa từng gặp.',
      'Lưu lại bài ấy vào chỗ em xem lại được — đây là bằng chứng của tầng 5.',
    ],
    camLam: ['CẤM giao thêm ba bài cùng loại ngay sau đó để "kiểm tra xem có may không".'],
    doBang: 'có thêm một lần như vậy trong 30 ngày',
  },

  // ── G. RỜI BỎ VÀ QUAY LẠI ────────────────────────────────────────────
  {
    ma: 'TH36', ten: 'Nhiều dấu hiệu sắp rời bỏ cùng lúc', nhom: 'ROI_BO', muc: 'DO',
    dauHieu: { nguon: 'telemetry', dieuKien: 'từ hai tín hiệu trở lên cùng lúc: vắng dài, buổi ngắn dần, bỏ bài nhiều', doDuoc: true },
    aiXuLy: 'Người phụ trách lớp, không uỷ quyền xuống',
    lamNgay: [
      'Gọi trong ngày. Đây là việc gấp nhất trong cả bảng này.',
      'Hỏi về hoàn cảnh nhà, không hỏi về việc học.',
      'Mang theo ba phương án và để gia đình chọn, kể cả phương án tạm dừng.',
    ],
    camLam: [
      'CẤM chào mời gói mới hay ưu đãi. Nhà đang muốn đi mà bị chào bán thì đi nhanh hơn.',
      'CẤM để việc này cho người chưa từng nói chuyện với nhà ấy.',
    ],
    doBang: 'có một quyết định rõ ràng của gia đình được ghi lại',
  },
  {
    ma: 'TH37', ten: 'Gia đình nói thẳng muốn dừng', nhom: 'ROI_BO', muc: 'DO',
    dauHieu: { nguon: 'nguoi-bao', dieuKien: 'gia đình nói hoặc nhắn muốn dừng', doDuoc: false },
    aiXuLy: 'Quản lý phụ trách',
    lamNgay: [
      'Hỏi một câu duy nhất và nghe hết: điều gì khiến nhà mình quyết định như vậy.',
      'Nếu lý do là thứ sửa được, nói rõ sửa thế nào và trong bao lâu — rồi để họ chọn.',
      'Nếu họ vẫn dừng: bàn giao lại hồ sơ học tập của em cho gia đình, đầy đủ.',
    ],
    camLam: [
      'CẤM giữ bằng ưu đãi.',
      'CẤM làm khó khi bàn giao dữ liệu. Nhà đi trong tử tế là nhà còn giới thiệu người khác.',
    ],
    doBang: 'có biên bản lý do và hồ sơ đã bàn giao',
  },
  {
    ma: 'TH38', ten: 'Đã dừng, nay quay lại', nhom: 'ROI_BO', muc: 'CAM',
    dauHieu: { nguon: 'he-thong', dieuKien: 'tài khoản đã ngừng hoạt động ≥ 60 ngày nay đăng nhập lại', doDuoc: true },
    aiXuLy: 'Người phụ trách lớp',
    lamNgay: [
      'Đo lại. Không giả định em còn ở cấp cũ — mấy tháng không học thì nền đã tụt.',
      'Nói rõ việc đo lại là để không dạy nhầm chỗ, không phải để đánh giá.',
      'Hỏi lý do quay lại và xếp lộ trình quanh lý do ấy.',
    ],
    camLam: [
      'CẤM nối tiếp lộ trình cũ từ đúng chỗ đã dừng.',
      'CẤM nhắc chuyện đã nghỉ như một lời trách.',
    ],
    doBang: 'có kết quả đo lại và một lộ trình mới được gia đình đồng ý',
  },
  {
    ma: 'TH39', ten: 'Hết chặng, chưa quyết đi tiếp hay không', nhom: 'ROI_BO', muc: 'CAM',
    dauHieu: { nguon: 'lo-trinh', dieuKien: 'đã qua bài thi tổng kết của chặng cuối, chưa có chặng kế tiếp sau 14 ngày', doDuoc: true },
    aiXuLy: 'Người phụ trách lớp',
    lamNgay: [
      'Đưa bản tổng kết bằng mốc cứng: vào với cái gì, ra với cái gì.',
      'Nói thẳng em còn thiếu gì nếu muốn đi tầng tiếp theo.',
      'Nếu em đã đủ thứ gia đình cần: nói ra điều đó, kể cả khi nghĩa là họ dừng.',
    ],
    camLam: ['CẤM tạo cảm giác chưa xong để giữ nhà lại. Bị phát hiện một lần là mất vĩnh viễn.'],
    doBang: 'gia đình có một quyết định và nói được lý do',
  },
  {
    ma: 'TH40', ten: 'Đổi mục tiêu giữa đường', nhom: 'ROI_BO', muc: 'CAM',
    dauHieu: { nguon: 'nguoi-bao', dieuKien: 'gia đình đổi hệ chuẩn hoặc đổi mục tiêu thi', doDuoc: false },
    aiXuLy: 'Người phụ trách lớp và giáo viên cùng xem',
    lamNgay: [
      'Chỉ ra phần đã học còn dùng được cho mục tiêu mới — thường là phần lớn.',
      'Dựng lại ma trận đề theo hệ chuẩn mới, nói rõ phần nào phải học thêm.',
      'Giữ nguyên vị trí trên lưới 50 ô: nền và nếp học không mất khi đổi mục tiêu.',
    ],
    camLam: ['CẤM nói công sức cũ là bỏ đi. Vừa sai vừa làm gia đình hối hận vì đã theo mình.'],
    doBang: 'có lộ trình mới kèm bảng đối chiếu phần giữ được và phần học thêm',
  },
];

const INDEX = new Map(TINH_HUONG.map((t) => [t.ma, t]));

/** Bảng tra: nhóm → danh sách tình huống. */
function theoNhom(maNhom) {
  return TINH_HUONG.filter((t) => t.nhom === String(maNhom).toUpperCase());
}

/** Bảng tra: mức khẩn → danh sách. */
function theoMuc(maMuc) {
  return TINH_HUONG.filter((t) => t.muc === String(maMuc).toUpperCase());
}

/**
 * Tình huống nào máy tự phát hiện được, tình huống nào phải chờ người báo.
 * Con số này quan trọng hơn vẻ ngoài của nó: mỗi tình huống `doDuoc: false`
 * là một chỗ hệ thống KHÔNG canh hộ, và người trực phải biết điều đó.
 */
function banDoPhatHien() {
  const may = TINH_HUONG.filter((t) => t.dauHieu.doDuoc);
  const nguoi = TINH_HUONG.filter((t) => !t.dauHieu.doDuoc);
  return {
    tong: TINH_HUONG.length,
    mayTuThay: may.length,
    phaiChoNguoiBao: nguoi.length,
    danhSachChoNguoi: nguoi.map((t) => ({ ma: t.ma, ten: t.ten, nhom: t.nhom })),
    nhac: 'Tình huống phải chờ người báo thì KHÔNG có ai canh hộ lúc 11 giờ đêm. '
      + 'Đừng xếp lịch trực như thể máy đang trông cả bốn mươi.',
  };
}

module.exports = { NHOM, MUC, TINH_HUONG, INDEX, theoNhom, theoMuc, banDoPhatHien };
