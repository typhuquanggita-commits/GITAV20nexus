'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  LƯỚI ĐIỂM CHẠM — 50 VỊ TRÍ × 40 TÌNH HUỐNG × 5 KÊNH = 10.000 Ô
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  NÓI THẲNG VỀ CON SỐ 10.000 TRƯỚC KHI NÓI GÌ KHÁC.
 *
 *  Mười nghìn ô này KHÔNG phải mười nghìn kịch bản viết tay. Chúng là tích của
 *  ba trục, mỗi trục viết tay từng mục:
 *
 *      50 vị trí   — lưới 5 tầng × 10 cấp, mỗi ô một chiếc lá và một quả
 *      40 tình huống — mỗi tình huống có dấu hiệu, người chịu, việc làm, việc cấm
 *      5 kênh      — mỗi kênh khai rõ nó hợp với mức khẩn nào
 *
 *  Tổng số mục viết tay là 95, không phải 10.000. Nói ngược lại là nói dối, và
 *  người đọc sẽ phát hiện ra ngay ở ô thứ mười.
 *
 *  VẬY MƯỜI NGHÌN Ô NÀY CÓ THẬT KHÔNG? Có, và đây là lý do: cùng một tình
 *  huống "vắng bảy ngày", xử ở cấp T1C2 khác hẳn xử ở cấp T4C6 — vì thứ em
 *  đang dở khác nhau, thứ gia đình đang chờ khác nhau, và câu để mở lời khác
 *  nhau. Mỗi ô lấy chữ thật của đúng cấp ấy, đúng tình huống ấy, đúng kênh ấy.
 *
 *  VÀ KHÔNG PHẢI Ô NÀO CŨNG ĐƯỢC PHÉP DÙNG. Kênh báo cáo theo chặng không dùng
 *  cho việc mức đỏ; tin nhắn không dùng cho kết quả sàng lọc tâm lý. Những ô
 *  ấy vẫn nằm trong lưới nhưng trả về lời TỪ CHỐI kèm kênh đúng phải dùng —
 *  vì "đừng làm thế, hãy làm thế này" cũng là một câu trả lời, và là câu trả
 *  lời hay bị thiếu nhất.
 *
 *  BA MỨC CỦA MỘT ĐIỂM CHẠM
 *      NỀN  — không làm là lỗi. Đây là thứ khách đã trả tiền để có.
 *      TỐT  — làm đúng chuẩn đã hứa.
 *      WOW  — vượt điều khách chờ đợi.
 *
 *  WOW ĐỨNG TRÊN NỀN, KHÔNG THAY CHO NỀN. Hệ thống TỪ CHỐI đưa ra mức wow khi
 *  mức nền của chính ô ấy chưa làm được. Một bất ngờ dễ thương đặt trên một
 *  lời hứa chưa giữ không phải là dịch vụ tốt — nó là trò đánh lạc hướng, và
 *  khách hàng nhận ra nhanh hơn ta tưởng.
 *
 *  NHÓM CẢM XÚC VÀ AN TOÀN KHÔNG CÓ MỨC WOW. Không phải vì thiếu ý tưởng, mà
 *  vì sáng tạo trong nhóm ấy là đem một đứa trẻ ra thử nghiệm.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const C50 = require('../matran/cay-50');
const TH = require('./tinh-huong');
const KENH = require('./kenh');

/**
 * Cách vượt kỳ vọng của từng nhóm tình huống.
 * Mỗi hàm nhận ô của lưới 50 và trả về một việc CỤ THỂ, lấy chữ từ chính ô ấy.
 * Trả về null nghĩa là nhóm này không có mức wow.
 */
const CACH_WOW = {
  NHIP: (o) => ({
    viec: `Mở lại đúng chỗ em đang dở và nói tên việc ấy: "${o.la}" — rồi nói rõ chỗ ấy vẫn còn nguyên.`,
    viSao: 'Người vắng lâu sợ nhất là quay lại thấy mình mất chỗ. Gọi tên đúng việc đang dở là cách nói "chỗ của con còn đây" mà không phải nói câu ấy.',
    tonGi: 'Không tốn gì ngoài việc đọc lại buổi cuối trước khi nhắn.',
  }),
  CHAT_LUONG: (o) => ({
    viec: `Cho em xem chính bài em từng vấp ở cấp này, kèm ngày, rồi làm lại bài ấy: "${o.la}".`,
    viSao: 'So với chính mình cách đây một tháng là thước đo duy nhất học viên tin. So với bạn khác thì em chỉ thấy mình kém.',
    tonGi: 'Một lần tra lịch sử bài làm.',
  }),
  CAM_XUC: null,          // Nhóm này KHÔNG có wow — xem phần đầu tệp.
  GIA_DINH: (o) => ({
    viec: `Gửi kèm CHÍNH BÀI LÀM của con ở cấp này, không gửi bảng tổng hợp, và chỉ vào đúng dòng cho thấy: ${o.qua}`,
    viSao: 'Gia đình không nghi ngờ bài làm của con mình. Họ nghi ngờ bảng tổng hợp do người bán dịch vụ dựng ra.',
    tonGi: 'Thêm một phút chọn đúng bài.',
  }),
  SU_CO: (o) => ({
    viec: `Nói trước khi gia đình kịp hỏi, và nói rõ việc ở cấp này còn hay mất: "${o.la}".`,
    viSao: 'Khách tha thứ cho sự cố, không tha thứ cho việc phải tự phát hiện ra sự cố.',
    tonGi: 'Một tin nhắn sớm, trước khi có ai hỏi.',
  }),
  MOC: (o) => ({
    viec: `Đặt cạnh nhau: bài em làm hôm nay ở cấp "${o.tenCap}" và một bài cùng dạng em từng không làm được. Để hai bài tự nói.`,
    viSao: 'Lời khen chóng quên. Hai bài đặt cạnh nhau thì em tự nhìn ra, và thứ tự nhìn ra thì giữ được lâu.',
    tonGi: 'Một lần tra lịch sử bài làm.',
  }),
  ROI_BO: (o) => ({
    viec: 'Bàn giao trọn hồ sơ học tập cho gia đình — bản đồ năng lực, các mốc đã qua, phần còn dở — kể cả khi họ quyết định đi.',
    viSao: 'Nhà đi trong tử tế là nhà còn nói tốt về mình, và là nhà có thể quay lại. Giữ dữ liệu làm con tin chỉ đổi được vài ngày.',
    tonGi: 'Một lần xuất hồ sơ.',
  }),
};

/** Giọng của từng kênh — cùng một việc, nói dài ngắn khác nhau. */
const GIONG = {
  K1: { mo: 'Nói ngay trên màn hình, trong lúc em còn đang học', dai: '1–2 câu, xưng hô với em' },
  K2: { mo: 'Nhắn cho gia đình trong ngày', dai: '3–5 câu, có một việc nhà quan sát được' },
  K3: { mo: 'Gọi cho gia đình, đã chuẩn bị phương án trước khi bấm số', dai: '5–10 phút, chốt lại bằng một tin nhắn tóm tắt' },
  K4: { mo: 'Hẹn một buổi ngồi cùng nhau, mở bài làm thật ra xem', dai: '20–40 phút, kết thúc bằng một việc cả nhà cùng làm' },
  K5: { mo: 'Đưa vào báo cáo cuối chặng, có người đọc lại trước khi gửi', dai: 'Một trang: mốc cứng trước, phần chưa đạt sau' },
};

/**
 * Một điểm chạm.
 *   tang 1..5 · cap 1..10 · maTinhHuong TH01..TH40 · maKenh K1..K5
 */
function diemCham(tang, cap, maTinhHuong, maKenh) {
  const o = C50.o(tang, cap);
  const t = TH.INDEX.get(String(maTinhHuong).toUpperCase());
  const k = KENH.INDEX.get(String(maKenh).toUpperCase());
  if (!o || !t || !k) return null;

  const ma = `${o.ma}·${t.ma}·${k.ma}`;
  const cong = KENH.dungDuoc(k.ma, t.muc);

  // Ô bị chặn vẫn là một câu trả lời — và là câu hay thiếu nhất.
  if (!cong.ok) {
    return {
      ma, viTri: o.ma, tinhHuong: t.ma, kenh: k.ma,
      hopLe: false,
      lyDo: cong.lyDo,
      dungKenhNao: cong.dungKenhNao,
      nhac: `Việc "${t.ten}" ở mức ${TH.MUC[t.muc].ten} phải chạm tới khách ${TH.MUC[t.muc].trongBaoLau}.`,
    };
  }

  const cungHayMem = o.bangChung.loai === 'moc-cung';
  const nen = [
    `${GIONG[k.ma].mo}. ${GIONG[k.ma].dai}.`,
    `Người làm: ${t.aiXuLy}. Hạn: ${TH.MUC[t.muc].trongBaoLau}.`,
    t.lamNgay[0],
  ];
  // Ô mốc cứng: lời của cấp và bằng chứng của cấp gần như trùng nhau, nên nói
  // bằng chứng rồi nói THỨ NHẬN ĐƯỢC. Ô mốc mềm: nói việc đang làm, và nói rõ
  // chưa được coi là đã đạt. Hai nhánh này khác nhau để không có dòng nào lặp
  // lại dòng nào — một kịch bản có hai dòng y hệt là kịch bản chưa ai đọc lại.
  const tot = cungHayMem
    ? [
      ...t.lamNgay.slice(1),
      `Nói đúng bằng chứng cấp ${o.cap} tầng ${o.tang} (${o.tenTang}) đòi: ${o.bangChung.chung}`,
      `Và nói thứ gia đình nhận được khi qua cấp này: ${o.qua}`,
    ]
    : [
      ...t.lamNgay.slice(1),
      `Việc em đang làm ở cấp ${o.cap} tầng ${o.tang} (${o.tenTang}): ${o.la}`,
      'Cấp này là MỐC MỀM — nói em đang nhích tới đâu, và KHÔNG nói là đã đạt.',
    ];

  const cachWow = CACH_WOW[t.nhom];
  const wow = cachWow ? cachWow(o) : null;

  return {
    ma, viTri: o.ma, tinhHuong: t.ma, kenh: k.ma,
    hopLe: true,
    tang: o.tang, tenTang: o.tenTang, cap: o.cap, tenCap: o.tenCap,
    la: o.la, qua: o.qua,
    loaiMoc: o.bangChung.loai,
    tenTinhHuong: t.ten, nhom: t.nhom, muc: t.muc, hanChot: TH.MUC[t.muc].trongBaoLau,
    tenKenh: k.ten, nguoiNhan: k.nguoiNhan,
    aiLam: t.aiXuLy,
    kichBan: {
      nen: { ten: 'NỀN — không làm là lỗi', viec: nen },
      tot: { ten: 'TỐT — đúng chuẩn đã hứa', viec: tot },
      wow: wow
        ? { ten: 'WOW — vượt điều khách chờ đợi', ...wow,
          dieuKien: 'CHỈ làm khi mức NỀN của chính ô này đã làm xong. Wow đặt trên một lời hứa chưa giữ là trò đánh lạc hướng.' }
        : { ten: 'KHÔNG CÓ MỨC WOW',
          viSao: `Nhóm "${TH.NHOM[t.nhom].ten}" không có mức wow: sáng tạo ở đây là đem một đứa trẻ ra thử nghiệm. `
            + 'Làm đúng mức NỀN và chuyển cho người có thẩm quyền.' },
    },
    camLam: [...t.camLam, ...k.camLam],
    doBang: t.doBang,
    dauHieu: t.dauHieu,
    kichBanSuCo: t.kichBanSuCo || null,
  };
}

/**
 * Kiểm tra mức wow có được phép bật không.
 * Đây là cái cổng, không phải lời khuyên: nền chưa xong thì wow bị TỪ CHỐI.
 */
function xinWow(tang, cap, maTinhHuong, maKenh, { nenDaXong = false } = {}) {
  const d = diemCham(tang, cap, maTinhHuong, maKenh);
  if (!d) return { ok: false, lyDo: 'Không có ô này trong lưới.' };
  if (!d.hopLe) return { ok: false, lyDo: d.lyDo, dungKenhNao: d.dungKenhNao };
  if (!d.kichBan.wow.viec) return { ok: false, lyDo: d.kichBan.wow.viSao };
  if (!nenDaXong) {
    return {
      ok: false,
      lyDo: 'Mức NỀN của ô này chưa làm xong. Wow đặt trên một lời hứa chưa giữ không phải là dịch vụ tốt — '
        + 'nó là trò đánh lạc hướng, và khách hàng nhận ra nhanh hơn ta tưởng.',
      phaiLamTruoc: d.kichBan.nen.viec,
    };
  }
  return { ok: true, wow: d.kichBan.wow };
}

/**
 * Cả lưới. Trả về thống kê thật, không làm tròn lên cho đẹp.
 * `mau` giới hạn số ô trả về chi tiết — lưới đầy đủ là 10.000 ô, in hết ra thì
 * không ai đọc, và nhồi cả vào một phản hồi API thì nặng vô ích.
 */
function luoi({ mau = 0 } = {}) {
  let tong = 0;
  let dung = 0;
  let chan = 0;
  let coWow = 0;
  const theoNhom = {};
  const theoKenh = {};
  const mauO = [];
  for (let t = 1; t <= 5; t++) {
    for (let c = 1; c <= 10; c++) {
      for (const th of TH.TINH_HUONG) {
        for (const k of KENH.KENH) {
          const d = diemCham(t, c, th.ma, k.ma);
          tong++;
          if (d.hopLe) {
            dung++;
            if (d.kichBan.wow.viec) coWow++;
            theoNhom[th.nhom] = (theoNhom[th.nhom] || 0) + 1;
            theoKenh[k.ma] = (theoKenh[k.ma] || 0) + 1;
          } else chan++;
          if (mau && mauO.length < mau) mauO.push(d);
        }
      }
    }
  }
  return {
    soViTri: 50, soTinhHuong: TH.TINH_HUONG.length, soKenh: KENH.KENH.length,
    tong, dungDuoc: dung, biChan: chan, coMucWow: coWow,
    theoNhom, theoKenh,
    mucVietTay: 50 + TH.TINH_HUONG.length + KENH.KENH.length,
    ghiChu: `${tong} ô là TÍCH của ba trục, không phải ${tong} kịch bản viết tay. `
      + `Số mục viết tay là ${50 + TH.TINH_HUONG.length + KENH.KENH.length}. `
      + `${chan} ô bị chặn vì kênh không hợp với mức khẩn — ô bị chặn vẫn trả lời, `
      + 'bằng cách nói rõ phải dùng kênh nào thay thế.',
    mau: mauO,
  };
}

module.exports = { CACH_WOW, GIONG, diemCham, xinWow, luoi };
