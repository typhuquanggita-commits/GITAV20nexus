'use strict';
/**
 * ĐO DỊCH VỤ — NỘI BỘ ĐIỀU HÀNH, KHÁCH HÀNG KHÔNG ĐỌC TỆP NÀY
 *
 * ⚠ Tệp này nằm SAU bức tường, cùng phía với src/cay-tien/. Không phải vì nó
 * bí mật, mà vì nó nói bằng ngôn ngữ thương mại: giá trị vòng đời, chi phí
 * phục vụ một khách, giờ chăm sóc. Đó là ngôn ngữ của người điều hành, không
 * phải ngôn ngữ để một gia đình đọc về con mình.
 *
 * Chính bộ soi của bức tường đã bắt tệp này khi nó suýt bị xếp nhầm sang mặt
 * khách hàng — và đó là lần bức tường làm đúng việc của nó. Đừng nới bảng từ
 * cấm để tệp này "qua được"; hãy để nó ở đúng bên này.
 *
 * Các cổng API của nó đều ở mức quyền 'quan-tri'. Có mục kiểm canh điều đó.
 *
 * Chuỗi lý thuyết là: dịch vụ tốt → khách trung thành → khách ở lại, mua thêm,
 * giới thiệu người khác → lợi nhuận. Chuỗi ấy đúng, nhưng nó chỉ có ích khi
 * từng mắt xích ĐO ĐƯỢC. Một bảng chỉ số mà nửa số ô là ước lượng thì nó
 * không dùng để quyết định được, và tệ hơn: nó làm người đọc tưởng là dùng được.
 *
 * Nên tệp này chia thẳng làm hai phần, và phần CHƯA ĐO ĐƯỢC in trước.
 * Cùng một luật với sổ cái dòng tiền: chỗ mù nêu tên trước con số.
 */

/** Chỉ số đo được từ dữ liệu hệ thống đang có thật. */
const DO_DUOC = [
  { ma: 'nhip', ten: 'Nhịp học đều', doBang: 'số buổi mỗi tuần, tỉ lệ tuần đạt nhịp',
    nguon: 'telemetry.sessions', yNghia: 'Tín hiệu sớm nhất của việc khách sắp rời bỏ. Nhịp vỡ trước khi người ta nói lời chia tay.' },
  { ma: 'quay-lai', ten: 'Quay lại sau gián đoạn', doBang: 'tỉ lệ học viên có buổi mới sau ≥ 7 ngày vắng',
    nguon: 'telemetry.sessions', yNghia: 'Đo đúng việc đồng hành có tác dụng hay không, vì đây là lúc khó nhất.' },
  { ma: 'moc-cung', ten: 'Mốc cứng đã qua', doBang: 'số mốc cứng đạt được trong một chặng',
    nguon: 'cay-50 + mastery', yNghia: 'Thứ duy nhất được dùng để nói với gia đình là "con đã đạt".' },
  { ma: 'dung-cap', ten: 'Thời gian đứng yên một cấp', doBang: 'số ngày ở cùng một ô của lưới 50 ô',
    nguon: 'cay-50', yNghia: 'Đứng lâu là dấu hiệu dạy sai chỗ, không phải dấu hiệu em kém.' },
  { ma: 'chat-luong-hoc', ten: 'Chất lượng học', doBang: 'accuracy · hintRate · peekRate · skipRate · carelessRate',
    nguon: 'telemetry.metrics', yNghia: 'Học nhiều mà không vào thì mọi chỉ số nhịp đều vô nghĩa.' },
  { ma: 'gia-dinh-doc', ten: 'Gia đình có theo dõi không', doBang: 'phiên đăng nhập của tài khoản phụ huynh',
    nguon: 'accounts.sessions', yNghia: 'Gia đình thôi mở báo cáo là tín hiệu sớm hơn cả việc học viên vắng.' },
  { ma: 'su-co', ten: 'Sự cố chạm tới khách', doBang: 'số lần mục soi báo lỗi có ảnh hưởng học viên',
    nguon: 'tổ thanh tra', yNghia: 'Cách xử lý sự cố quyết định khách ở hay đi nhiều hơn bản thân sự cố.' },
];

/**
 * Chỉ số CHƯA đo được. Mỗi mục nói rõ thiếu gì — thiếu thì đi nối, chứ không
 * ước lượng rồi đưa lên bảng điều khiển.
 */
const CHUA_DO_DUOC = [
  { ma: 'giu-chan', ten: 'Tỉ lệ giữ chân (retention)',
    thieu: 'Chưa có khái niệm "đang là khách hàng" trong dữ liệu: không có hợp đồng, kỳ hạn, hay trạng thái đăng ký.',
    lamGiDeCo: 'Nối dữ liệu đăng ký và kỳ hạn học.' },
  { ma: 'clv', ten: 'Giá trị vòng đời khách hàng (CLV)',
    thieu: 'Chưa nối dữ liệu thanh toán. Sổ cái dòng tiền đang khai doanh thu là khoản CHƯA CÓ NGUỒN.',
    lamGiDeCo: 'Nối hệ thống thanh toán, rồi mới tính được.' },
  { ma: 'gioi-thieu', ten: 'Tỉ lệ giới thiệu (referral)',
    thieu: 'Chưa có chỗ ghi nguồn giới thiệu khi một nhà mới vào.',
    lamGiDeCo: 'Thêm trường nguồn giới thiệu lúc tạo hồ sơ, và hỏi thật chứ không suy đoán.' },
  { ma: 'hai-long', ten: 'Mức hài lòng (CSAT/NPS)',
    thieu: 'Chưa có bộ hỏi sau điểm chạm. Và hỏi mà không ai đọc trả lời thì còn hại hơn không hỏi.',
    lamGiDeCo: 'Thiết kế bộ hỏi ngắn sau các điểm chạm mức CAM và ĐỎ, kèm người chịu trách nhiệm đọc.' },
  { ma: 'chi-phi-phuc-vu', ten: 'Chi phí phục vụ một khách (cost-to-serve)',
    thieu: 'Chưa nối bảng lương và chưa có sổ giờ chăm sóc theo từng nhà.',
    lamGiDeCo: 'Ghi giờ cố vấn thật theo từng nhà trước đã.' },
];

/**
 * Bảng đo. In phần CHƯA ĐO ĐƯỢC trước — có chủ ý, cùng luật với sổ cái dòng tiền.
 */
function bangDo() {
  return {
    chuaDoDuoc: CHUA_DO_DUOC,
    doDuoc: DO_DUOC,
    tiLeDoDuoc: Math.round(DO_DUOC.length / (DO_DUOC.length + CHUA_DO_DUOC.length) * 100) / 100,
    ketLuan: `${DO_DUOC.length}/${DO_DUOC.length + CHUA_DO_DUOC.length} nhóm chỉ số đo được từ dữ liệu thật. `
      + `${CHUA_DO_DUOC.length} nhóm còn lại — giữ chân, CLV, giới thiệu, hài lòng, chi phí phục vụ — `
      + 'CHƯA nối được nguồn. Không ước lượng, không đưa lên bảng điều khiển, và không dùng để báo cáo.',
    nhac: 'Chuỗi "dịch vụ → trung thành → lợi nhuận" hiện mới đo được đoạn đầu. '
      + 'Nói rằng đã đo được cả chuỗi là nói quá, và người đầu tiên phát hiện ra sẽ là người trả tiền.',
  };
}

/** Cờ khai rõ tệp này thuộc phía nào của bức tường. Mục kiểm đọc cờ này. */
const NOI_BO = true;

module.exports = { DO_DUOC, CHUA_DO_DUOC, bangDo, NOI_BO };
