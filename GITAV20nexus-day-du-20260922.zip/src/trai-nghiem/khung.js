'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  KHUNG QUẢN TRỊ TRẢI NGHIỆM — MƯỜI TẦNG, TỪ Ý ĐỊNH TỚI SỐ ĐO
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Khung này chuyển một ý tưởng quản trị dịch vụ thành bộ phận CHẠY ĐƯỢC của
 *  hệ thống. Điều đáng giữ nhất của ý tưởng ấy không phải "hãy phục vụ tận
 *  tâm", mà là: dịch vụ tốt là một HỆ THỐNG, không phải một thái độ. Thái độ
 *  không nhân bản được và không bàn giao được; hệ thống thì có.
 *
 *  Mỗi tầng dưới đây trỏ tới tệp mã ĐANG CHẠY làm việc của tầng ấy. Tầng nào
 *  chưa có tệp thì khai `moduleFile: null` và nói rõ còn thiếu gì — một khung
 *  quản trị mà tầng nào cũng "đã có" thì đó là khung vẽ trên giấy.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const TANG = [
  {
    thu: 1, ten: 'Lời hứa dịch vụ',
    cauHoiQuanTri: 'Ta muốn gia đình nhớ điều gì về mình?',
    nguyenTac: 'Hứa năng lực, không hứa điểm số. Lời hứa nào không kiểm chứng được thì không được hứa.',
    trongHeThong: 'Cây giá trị năm tầng — thứ gia đình ĐƯỢC BIẾT khi đi hết hành trình.',
    moduleFile: 'src/nha/cay-gia-tri.js',
    doBang: 'mục kiểm bắt mọi lời hứa phải có dấu hiệu quan sát được ở nhà',
  },
  {
    thu: 2, ten: 'Hiểu khách hàng',
    cauHoiQuanTri: 'Ta biết gì về nhà này, và biết bằng căn cứ nào?',
    nguyenTac: 'Sáu mặt để riêng, không gộp thành một chỉ số. Miền nặng nhất quyết định, không phải trung bình.',
    trongHeThong: 'Bộ phân tích khảo sát sáu công cụ, có luật đo đứng trên chúng.',
    moduleFile: 'src/khao-sat/phan-tich.js',
    doBang: 'mục kiểm bắt một miền nặng không được năm miền còn lại kéo về mức ổn',
  },
  {
    thu: 3, ten: 'Hành trình',
    cauHoiQuanTri: 'Khách đi qua những đâu, và đang đứng ở đâu?',
    nguyenTac: 'Vị trí chỉ được ghi khi có bằng chứng. Không đoán lên cho đẹp.',
    trongHeThong: 'Lưới 50 ô: 5 tầng × 10 cấp, 15 mốc cứng đo bằng máy.',
    moduleFile: 'src/matran/cay-50.js',
    doBang: 'mục kiểm bắt mốc mềm phải tự khai là không dùng để báo đã đạt',
  },
  {
    thu: 4, ten: 'Tình huống',
    cauHoiQuanTri: 'Chuyện gì có thể xảy ra, và ai xử?',
    nguyenTac: 'Tình huống phải phát hiện được, có người chịu, và có mục CẤM LÀM.',
    trongHeThong: 'Bốn mươi tình huống trong đời một khách hàng, chia bảy nhóm.',
    moduleFile: 'src/trai-nghiem/tinh-huong.js',
    doBang: 'mục kiểm bắt mọi tình huống có đủ ba phần và khai rõ máy có đo được dấu hiệu không',
  },
  {
    thu: 5, ten: 'Kênh',
    cauHoiQuanTri: 'Nói qua đường nào cho đúng việc?',
    nguyenTac: 'Mỗi kênh khai rõ nó hợp với mức khẩn nào. Kênh sai làm hỏng nội dung đúng.',
    trongHeThong: 'Năm kênh, có cổng chặn kênh không hợp với mức khẩn.',
    moduleFile: 'src/trai-nghiem/kenh.js',
    doBang: 'gọi cổng và xem nó có chặn thật không',
  },
  {
    thu: 6, ten: 'Điểm chạm',
    cauHoiQuanTri: 'Ở vị trí này, tình huống này, kênh này thì làm gì?',
    nguyenTac: 'Ba mức NỀN → TỐT → WOW. Wow đứng trên nền, không thay cho nền.',
    trongHeThong: 'Lưới 10.000 ô = 50 vị trí × 40 tình huống × 5 kênh.',
    moduleFile: 'src/trai-nghiem/luoi-cham.js',
    doBang: 'cổng xinWow từ chối khi mức nền chưa xong',
  },
  {
    thu: 7, ten: 'Trao quyền',
    cauHoiQuanTri: 'Người trực được quyết gì ngay, tới mức nào?',
    nguyenTac: 'Mọi quyền có trần cứng. Trần là thứ cho phép trao quyền mà không phải hỏi ai.',
    trongHeThong: 'Mười quyền, chín dùng được, một còn treo vì chưa nối dữ liệu thanh toán.',
    moduleFile: 'src/trai-nghiem/trao-quyen.js',
    doBang: 'mục kiểm bắt quyền còn treo phải tự khai là chưa dùng được',
  },
  {
    thu: 8, ten: 'Phục hồi sau sự cố',
    cauHoiQuanTri: 'Hỏng việc rồi thì gỡ thế nào?',
    nguyenTac: 'Mười bước, thứ tự bắt buộc. Nhảy sang giải pháp khi khách chưa thấy mình được nghe thì giải pháp đúng cũng bị từ chối.',
    trongHeThong: 'Thang mười bước, có bộ đếm từ chối nhảy bước.',
    moduleFile: 'src/trai-nghiem/phuc-hoi.js',
    doBang: 'gọi buocKeTiep với một dãy nhảy cóc và xem nó có cảnh báo không',
  },
  {
    thu: 9, ten: 'Đo lường',
    cauHoiQuanTri: 'Dịch vụ có tốt lên không, và ta biết bằng gì?',
    nguyenTac: 'Chỗ mù nêu tên TRƯỚC con số. Chưa đo được thì nói chưa đo được, không ước lượng.',
    trongHeThong: 'Bảy nhóm chỉ số đo được, năm nhóm khai rõ là chưa nối nguồn.',
    moduleFile: 'src/trai-nghiem/do-luong.js',
    doBang: 'mục kiểm bắt bảng đo phải in phần chưa đo được trước',
  },
  {
    thu: 10, ten: 'Kiểm soát và cải tiến',
    cauHoiQuanTri: 'Ai canh cho hệ thống này không mục ruỗng?',
    nguyenTac: 'Tổ thanh tra ghi biên bản và báo động, không tự vá. Sổ tay quy trình nói làm gì khi báo động.',
    trongHeThong: 'Tổ 10 trợ lý AI chuyên môn × 10 lượt mỗi ngày, và tám kịch bản trực sự cố.',
    moduleFile: 'src/thanh-tra/to-thanh-tra.js',
    doBang: 'chạy gita to-thanh-tra --ca-ngay và đọc biên bản ngày',
  },
];

/** Mười bài học rút gọn — thứ đáng nhớ khi không kịp đọc cả khung. */
const BAI_HOC = [
  { thu: 1, bai: 'Dịch vụ là hệ thống, không phải thái độ',
    viSao: 'Thái độ không bàn giao được. Người giỏi nghỉ việc là dịch vụ tụt theo.',
    trongHeThong: 'Mười tầng của khung này, mỗi tầng một tệp mã chạy được.' },
  { thu: 2, bai: 'Gia đình mua hành trình của con, không mua khoá học',
    viSao: 'Bán khoá học thì hết khoá là hết quan hệ.',
    trongHeThong: 'Cây giá trị năm tầng và lưới 50 ô nói bằng việc làm được, không bằng số buổi.' },
  { thu: 3, bai: 'Nhất quán quan trọng hơn xuất sắc từng lúc',
    viSao: 'Một buổi tuyệt vời không cứu được mười buổi lỡ hẹn.',
    trongHeThong: 'Mức NỀN của mọi điểm chạm là bắt buộc; wow bị từ chối khi nền chưa xong.' },
  { thu: 4, bai: 'Khiếu nại là dữ liệu, không phải phiền phức',
    viSao: 'Nhà chịu nói là nhà còn muốn ở lại. Nhà im lặng mới là nhà đã quyết định đi.',
    trongHeThong: 'Bước 9 và 10 của thang phục hồi bắt buộc tìm gốc và sửa hệ thống.' },
  { thu: 5, bai: 'Trao quyền phải kèm trần rõ ràng',
    viSao: '"Hãy chủ động" mà không có trần nghĩa là "tự chịu nếu sai".',
    trongHeThong: 'Mười quyền, mỗi quyền một trần cứng, một quyền tự khai là còn treo.' },
  { thu: 6, bai: 'Kênh sai làm hỏng nội dung đúng',
    viSao: 'Báo kết quả sàng lọc tâm lý qua tin nhắn là sai, dù nội dung chính xác tới đâu.',
    trongHeThong: '4.400/10.000 ô của lưới bị chặn kèm lý do và kênh đúng phải dùng.' },
  { thu: 7, bai: 'Nói trước khi khách kịp hỏi',
    viSao: 'Khách tha thứ cho sự cố, không tha thứ cho việc phải tự phát hiện ra sự cố.',
    trongHeThong: 'Nhóm sự cố có mức wow là "nói trước khi gia đình kịp hỏi".' },
  { thu: 8, bai: 'Không sáng tạo ở chỗ liên quan tới an toàn của trẻ',
    viSao: 'Sáng tạo ở đó là đem một đứa trẻ ra thử nghiệm.',
    trongHeThong: 'Nhóm cảm xúc và an toàn KHÔNG có mức wow, và cổng xinWow từ chối.' },
  { thu: 9, bai: 'Đo được thì mới quản được — nhưng đừng bịa số để có gì mà đo',
    viSao: 'Một bảng chỉ số nửa thật nửa ước lượng tệ hơn không có bảng nào.',
    trongHeThong: 'Bảng đo in năm nhóm CHƯA đo được trước bảy nhóm đo được.' },
  { thu: 10, bai: 'Nói thẳng khi khách đã đủ và có thể dừng',
    viSao: 'Giữ một nhà không còn cần mình là bán thứ họ không cần. Phát hiện một lần là mất vĩnh viễn.',
    trongHeThong: 'Quyền Q10 cho phép người phụ trách lớp nói câu ấy.' },
];

/** Khung đầy đủ, kèm kiểm tra tệp mã khai ra có tồn tại thật không. */
function khung() {
  return {
    soTang: TANG.length,
    tang: TANG,
    baiHoc: BAI_HOC,
    congThuc: 'Hiểu đúng học viên → Hiểu đúng gia đình → Cá nhân hoá lộ trình → Chủ động đồng hành '
      + '→ Xử lý sự cố tử tế → Đo bằng bằng chứng → Cải tiến liên tục.',
    nhac: 'Khung này chỉ có giá trị khi mỗi tầng trỏ vào một tệp mã ĐANG CHẠY. '
      + 'Có mục kiểm đòi mọi đường dẫn khai ở đây phải tồn tại thật.',
  };
}

module.exports = { TANG, BAI_HOC, khung };
