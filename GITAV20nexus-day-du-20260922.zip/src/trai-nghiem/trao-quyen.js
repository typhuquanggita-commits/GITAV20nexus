'use strict';
/**
 * TRAO QUYỀN — QUYẾT ĐỊNH ĐƯỢC PHÉP RA NGAY, VÀ GIỚI HẠN CỦA NÓ
 *
 * Trao quyền không phải khẩu hiệu "hãy chủ động". Nó là một bảng ghi rõ: việc
 * nào ra quyết định ngay được, tới mức nào, và chỗ nào thì phải dừng lại hỏi.
 * Không có bảng ấy thì "hãy chủ động" nghĩa là "tự chịu nếu sai", và không ai
 * dám chủ động lần thứ hai.
 *
 * MỖI QUYỀN Ở ĐÂY CÓ TRẦN CỨNG. Trần không phải để nghi ngờ người trực; trần
 * là thứ cho phép trao quyền mà không phải hỏi ai. Bỏ trần đi thì quyền này
 * phải xin duyệt từng lần, và lúc ấy khách đã đi rồi.
 */

const QUYEN = [
  {
    ma: 'Q01', viec: 'Xin lỗi và nhận đó là lỗi của mình',
    aiDuoc: 'Bất kỳ ai tiếp nhận',
    tran: 'Không có trần. Không cần hỏi ai.',
    viSao: 'Chờ duyệt để được xin lỗi là cách biến một sự cố nhỏ thành một vụ việc.',
    camLam: 'CẤM xin lỗi thay cho việc sửa. Xin lỗi xong vẫn phải có người làm tiếp.',
  },
  {
    ma: 'Q02', viec: 'Mở lại một bài đã khoá cho học viên làm lại',
    aiDuoc: 'Giáo viên phụ trách, cố vấn đồng hành',
    tran: 'Tối đa 3 bài mỗi học viên mỗi tuần.',
    viSao: 'Mở lại là việc nhỏ nhưng gỡ được thế bí ngay trong buổi. Quá 3 bài là dấu hiệu bài đang sai độ khó, phải xem lại lộ trình chứ không mở thêm.',
    camLam: 'CẤM mở lại bài thi tổng kết của chặng. Việc đó thuộc người phụ trách lớp.',
  },
  {
    ma: 'Q03', viec: 'Giãn lịch học cho một gia đình',
    aiDuoc: 'Cố vấn đồng hành',
    tran: 'Giãn tối đa 2 tuần. Dài hơn thì báo người phụ trách lớp.',
    viSao: 'Nhà đang bận mà phải chờ duyệt để được giãn lịch thì họ nghỉ luôn, và im lặng.',
    camLam: 'CẤM giãn lịch mà không chốt ngày quay lại.',
  },
  {
    ma: 'Q04', viec: 'Đổi cách dạy một dạng bài cho một học viên',
    aiDuoc: 'Giáo viên phụ trách',
    tran: 'Trong phạm vi chương trình của lớp em đang học.',
    viSao: 'Người dạy trực tiếp thấy chỗ em vấp trước mọi bảng thống kê.',
    camLam: 'CẤM hạ chuẩn bằng chứng của một cấp để em qua cho nhanh.',
  },
  {
    ma: 'Q05', viec: 'Tặng thêm một buổi kèm riêng',
    aiDuoc: 'Người phụ trách lớp',
    tran: 'Tối đa 2 buổi mỗi học viên mỗi chặng.',
    viSao: 'Có những lúc một buổi kèm đúng chỗ giữ được cả một gia đình.',
    camLam: 'CẤM dùng buổi tặng để bù cho việc mình đã hứa mà chưa làm. Cái đó là nợ, không phải quà.',
  },
  {
    ma: 'Q06', viec: 'Đổi người đồng hành theo yêu cầu gia đình',
    aiDuoc: 'Quản lý phụ trách',
    tran: 'Đổi ngay, không cần gia đình nêu lý do.',
    viSao: 'Bắt gia đình biện hộ cho yêu cầu của họ là cách chắc chắn để mất họ.',
    camLam: 'CẤM để chính người bị đề nghị đổi đi thuyết phục gia đình.',
  },
  {
    ma: 'Q07', viec: 'Dừng một bài học liệu khỏi kho',
    aiDuoc: 'Bất kỳ giáo viên nào phát hiện lỗi',
    tran: 'Không có trần với việc GỠ. Việc đưa trở lại cần người duyệt.',
    viSao: 'Gỡ nhầm một bài đúng tốn vài phút; để một bài sai đáp số chạy tiếp thì mỗi giờ thêm một em bị chấm sai.',
    camLam: 'CẤM sửa thẳng đáp án trên kho đang chạy. Gỡ trước, sửa sau, duyệt rồi mới trả lại.',
  },
  {
    ma: 'Q08', viec: 'Hoàn tiền hoặc bù giá trị',
    aiDuoc: 'Quản lý phụ trách',
    tran: 'CHƯA CÓ TRẦN — hệ thống chưa nối dữ liệu thanh toán.',
    viSao: 'Sổ cái dòng tiền đang khai rõ ba khoản chưa nối nguồn, trong đó có doanh thu. Đặt một trần bằng tiền ở đây là đặt một con số không ai kiểm được.',
    camLam: 'CẤM hứa mức bù bằng tiền khi chưa có người có thẩm quyền xác nhận. Nói được rồi rút lại còn tệ hơn không nói.',
    chuaSanSang: true,
  },
  {
    ma: 'Q09', viec: 'Quyết định về một tình huống cảm xúc, an toàn của trẻ',
    aiDuoc: 'CHỈ người đã được chỉ định trước',
    tran: 'Người trực KHÔNG có quyền này, dù tình huống có vẻ nhẹ.',
    viSao: 'Sàng lọc không phải chẩn đoán. Người trực không có chuyên môn, và một câu nói sai ở đây không rút lại được.',
    camLam: 'CẤM tự tư vấn. CẤM chờ hết ca rồi bàn giao.',
  },
  {
    ma: 'Q10', viec: 'Nói với gia đình rằng con họ đã đủ, có thể dừng',
    aiDuoc: 'Người phụ trách lớp',
    tran: 'Khi bằng chứng mốc cứng cho thấy điều gia đình cần đã đạt.',
    viSao: 'Đây là quyền khó dùng nhất và là quyền chứng minh cả hệ thống này tử tế. Giữ một nhà không còn cần mình là bán thứ họ không cần.',
    camLam: 'CẤM tạo cảm giác chưa xong để giữ nhà lại. Bị phát hiện một lần là mất vĩnh viễn.',
  },
];

const INDEX = new Map(QUYEN.map((q) => [q.ma, q]));

/** Quyền nào đã dùng được, quyền nào còn treo vì thiếu dữ liệu. */
function trangThai() {
  const treo = QUYEN.filter((q) => q.chuaSanSang);
  return {
    tong: QUYEN.length,
    dungDuoc: QUYEN.length - treo.length,
    conTreo: treo.map((q) => ({ ma: q.ma, viec: q.viec, viSao: q.viSao })),
    nhac: treo.length
      ? 'Quyền còn treo thì người trực PHẢI biết là mình không có quyền ấy. Để họ tưởng mình có rồi hứa với khách là cách tạo ra một lời hứa không ai giữ.'
      : 'Mọi quyền đều có trần rõ ràng.',
  };
}

module.exports = { QUYEN, INDEX, trangThai };
