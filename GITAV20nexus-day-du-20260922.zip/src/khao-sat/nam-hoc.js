'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  ĐỀ ĐÁNH GIÁ NĂNG LỰC MÔN HỌC THEO KHUNG THỜI GIAN NĂM HỌC
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  BÀI TOÁN. Một đề kiểm tra ở trường thường cho học sinh giỏi 9–9,5 điểm.
 *  Con số ấy nói được rất ít: trong nhóm cùng 9,25 có em vững thật và có em
 *  vừa đủ vượt qua phần dễ. Đề nào cũng chỉ phân loại được ở chỗ nó ĐẶT CÂU
 *  HỎI KHÓ, mà đề trường đặt phần lớn câu hỏi ở mức nhận biết và thông hiểu.
 *
 *  CÁCH LÀM. Bộ đề ở đây giữ nguyên PHẠM VI kiến thức theo đúng tuần của năm
 *  học — không hỏi thứ chưa dạy — nhưng dồn trọng số sang VẬN DỤNG và VẬN
 *  DỤNG CAO, đúng chỗ nhóm 9–9,5 thật sự khác nhau.
 *
 *  HỆ QUẢ PHẢI NÓI TRƯỚC, nếu không gia đình sẽ hoảng: một em giỏi thật làm
 *  đề này thường đúng khoảng 55–70%, KHÔNG phải 90%. Con số trên đề này KHÔNG
 *  PHẢI điểm trường và không quy thẳng ra điểm trường được. Nên mọi kết quả
 *  đều đi kèm phép quy đổi ngược có ghi rõ là ước lượng, và đi kèm câu nhắc
 *  rằng đúng 60% ở đây không phải "học lực trung bình".
 *
 *  KHUNG THỜI GIAN. Năm học phổ thông Việt Nam chia hai học kỳ, tổng 35 tuần
 *  dạy. Sáu mốc dưới đây là sáu thời điểm nhà trường thật sự dừng lại để đánh
 *  giá, nên đề bám đúng sáu mốc ấy thay vì chia đều theo tháng.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { FORM_INDEX, gradeOf, subjectOf } = require('../curriculum/hierarchy');

/**
 * Sáu mốc của năm học.
 *   tuan       [tuần bắt đầu, tuần kết thúc] tính từ tuần 1 của năm học
 *   phuPhamVi  tỉ lệ chương trình cả năm đã dạy xong tới mốc này
 *   vaiTro     mốc này dùng để làm gì
 */
const MOC = [
  {
    ma: 'DAU_HK1', ten: 'Đầu học kỳ I', thang: 'tháng 9', tuan: [1, 4], phuPhamVi: 0.10,
    vaiTro: 'Đo nền mang từ năm trước sang. Đây là mốc quan trọng nhất mà các nơi hay bỏ qua: '
      + 'lỗ hổng năm trước không tự lành, và phát hiện ở tuần 4 thì còn cả năm để vá.',
  },
  {
    ma: 'GIUA_HK1', ten: 'Giữa học kỳ I', thang: 'tháng 10 – 11', tuan: [5, 9], phuPhamVi: 0.28,
    vaiTro: 'Đối chiếu với đề giữa kỳ của trường, nhưng ở mức phân loại cao hơn.',
  },
  {
    ma: 'CUOI_HK1', ten: 'Cuối học kỳ I', thang: 'tháng 12 – 1', tuan: [10, 18], phuPhamVi: 0.50,
    vaiTro: 'Chốt nửa chương trình. Mốc quyết định có phải đổi lộ trình cho học kỳ II hay không.',
  },
  {
    ma: 'DAU_HK2', ten: 'Đầu học kỳ II', thang: 'tháng 1 – 2', tuan: [19, 22], phuPhamVi: 0.58,
    vaiTro: 'Kiểm phần học kỳ I có còn giữ được sau kỳ nghỉ không — đây là chỗ rơi vãi nhiều nhất.',
  },
  {
    ma: 'GIUA_HK2', ten: 'Giữa học kỳ II', thang: 'tháng 3', tuan: [23, 28], phuPhamVi: 0.78,
    vaiTro: 'Mốc cuối còn kịp sửa lộ trình trước kỳ thi cuối năm.',
  },
  {
    ma: 'CUOI_HK2', ten: 'Cuối học kỳ II', thang: 'tháng 4 – 5', tuan: [29, 35], phuPhamVi: 1.00,
    vaiTro: 'Tổng kết cả năm ở mức vận dụng cao. Đây là đề thi tổng kết của lộ trình.',
  },
];

const MOC_INDEX = new Map(MOC.map((m) => [m.ma, m]));

/**
 * MA TRẬN ĐỀ PHÂN LOẠI NHÓM GIỎI.
 *
 * So với ma trận đề trường (thường 40% nhận biết · 30% thông hiểu · 20% vận
 * dụng · 10% vận dụng cao), ma trận này dồn 65% vào hai mức trên cùng. Lý do
 * thuần kỹ thuật: một câu mà 95% thí sinh làm đúng gần như không mang thông
 * tin phân loại nào. Muốn tách hai em cùng 9,25 thì phải hỏi ở chỗ hai em ấy
 * khác nhau.
 *
 * Vẫn giữ 10% ở mức 2★, không bỏ hẳn: một đề mà câu đầu đã khó sẽ làm học
 * viên mất bình tĩnh ngay từ đầu, và cái mất ấy không phải thứ đề muốn đo.
 */
const MA_TRAN_GIOI = [
  { sao: 1, ten: 'Nhận biết', share: 0.00 },
  { sao: 2, ten: 'Thông hiểu', share: 0.10 },
  { sao: 3, ten: 'Vận dụng', share: 0.25 },
  { sao: 4, ten: 'Vận dụng cao', share: 0.40 },
  { sao: 5, ten: 'Thách thức', share: 0.25 },
];

/** Ma trận đề trường, để đặt cạnh cho thấy khác chỗ nào. */
const MA_TRAN_TRUONG = [
  { sao: 1, ten: 'Nhận biết', share: 0.40 },
  { sao: 2, ten: 'Thông hiểu', share: 0.30 },
  { sao: 3, ten: 'Vận dụng', share: 0.20 },
  { sao: 4, ten: 'Vận dụng cao', share: 0.10 },
  { sao: 5, ten: 'Thách thức', share: 0.00 },
];

/**
 * QUY ĐỔI NGƯỢC — tỉ lệ đúng trên đề này ước lượng ra học lực nào ở thang
 * trường.
 *
 * Bảng này là ƯỚC LƯỢNG, và phải luôn được gọi đúng tên như vậy. Nó dựng từ
 * một suy luận nêu rõ ở đây để ai cũng kiểm lại được: nếu một em làm đúng gần
 * hết phần 2★ và 3★ của đề này (35% số câu) và được một phần phần 4★, thì trên
 * một đề trường — nơi 70% số câu nằm ở mức 1★–2★ — em ấy gần như chắc chắn
 * đúng hết phần dễ. Bảng dừng lại ở mức "ước lượng" và không bao giờ in ra một
 * con số điểm trường cụ thể, vì không đề trường nào giống đề trường nào.
 */
const QUY_DOI = [
  { tu: 0.80, den: 1.01, hocLuc: 'Giỏi vững, dư sức cho đề nâng cao', truong: 'thường trên 9,5 ở đề trường' },
  { tu: 0.65, den: 0.80, hocLuc: 'Giỏi thật, chắc phần vận dụng', truong: 'thường 9,0 – 9,5 ở đề trường' },
  { tu: 0.50, den: 0.65, hocLuc: 'Giỏi phần nền, còn hụt ở vận dụng cao', truong: 'thường 8,5 – 9,0 ở đề trường' },
  { tu: 0.35, den: 0.50, hocLuc: 'Khá, cần vá phần vận dụng', truong: 'thường 7,5 – 8,5 ở đề trường' },
  { tu: 0.20, den: 0.35, hocLuc: 'Nền chưa chắc, phần khó chưa với tới', truong: 'thường 6,5 – 7,5 ở đề trường' },
  { tu: 0.00, den: 0.20, hocLuc: 'Cần quay lại phần nền trước khi luyện nâng cao', truong: 'chưa ước lượng được, nên đo lại bằng đề đúng tầng' },
];

const NHAC = 'Đề này KHÔNG phải đề trường. Một em giỏi thật thường đúng khoảng 55–70% ở đây. '
  + 'Đúng 60% trên đề này không có nghĩa là học lực trung bình — nó nghĩa là em đang đứng vững ở mức vận dụng '
  + 'và còn chỗ để đi tiếp ở mức vận dụng cao.';

/** Quy đổi tỉ lệ đúng ra ước lượng học lực. Luôn kèm chữ "ước lượng". */
function quyDoiHocLuc(tiLeDung) {
  const t = Number(tiLeDung);
  if (!Number.isFinite(t) || t < 0 || t > 1) return { ok: false, error: 'TỈ_LỆ_PHẢI_TRONG_KHOẢNG_0_ĐẾN_1' };
  const h = QUY_DOI.find((x) => t >= x.tu && t < x.den) || QUY_DOI[QUY_DOI.length - 1];
  return {
    ok: true, tiLeDung: Math.round(t * 1000) / 1000,
    hocLuc: h.hocLuc, uocLuongTruong: h.truong,
    laUocLuong: true,
    ghiChu: `Đây là ƯỚC LƯỢNG, không phải điểm trường — không đề trường nào giống đề trường nào. ${NHAC}`,
  };
}

/**
 * Phạm vi dạng bài được phép hỏi ở một mốc.
 *
 * Nguyên tắc: KHÔNG hỏi thứ chưa dạy. Dạng bài của lớp được xếp theo thứ tự
 * học (chính là thứ tự khai báo trong chương trình), rồi cắt theo tỉ lệ phủ
 * của mốc. Phần đã học từ LỚP TRƯỚC thì luôn nằm trong phạm vi — vì đề này đo
 * thực lực, mà thực lực thì không quên phần nền.
 */
function phamVi({ lop, mocMa, mon = 'math' } = {}) {
  const moc = MOC_INDEX.get(mocMa);
  if (!moc) return { ok: false, error: 'KHÔNG_CÓ_MỐC_NÀY', mocMa };
  const l = Number(lop);
  if (!Number.isInteger(l) || l < 1 || l > 12) return { ok: false, error: 'LỚP_PHẢI_TỪ_1_ĐẾN_12' };

  const cungLop = [];
  const lopTruoc = [];
  for (const f of FORM_INDEX.values()) {
    if (subjectOf(f.code) !== mon) continue;
    const g = gradeOf(f.code);
    if (g == null) continue;
    if (g === l) cungLop.push(f.code);
    else if (g < l && g >= l - 2) lopTruoc.push(f.code);
  }
  const soDayToiMoc = Math.max(1, Math.round(cungLop.length * moc.phuPhamVi));
  const trongLop = cungLop.slice(0, soDayToiMoc);

  return {
    ok: true,
    moc: moc.ma, tenMoc: moc.ten, thang: moc.thang, tuan: moc.tuan.slice(),
    phuPhamVi: moc.phuPhamVi,
    dangCungLop: trongLop,
    dangLopTruoc: lopTruoc,
    dangChuaDay: cungLop.slice(soDayToiMoc),
    tongDangDuocHoi: trongLop.length + lopTruoc.length,
    quyTac: `Chỉ hỏi ${trongLop.length}/${cungLop.length} dạng của lớp ${l} đã dạy tới ${moc.ten}, `
      + `cộng ${lopTruoc.length} dạng nền của hai lớp trước. Không hỏi ${cungLop.length - trongLop.length} dạng chưa dạy.`,
  };
}

/**
 * Bảng phân bổ số câu theo mức khó cho một đề.
 * Làm tròn xuống rồi bù phần dư vào mức 4★ — mức mang thông tin phân loại
 * nhiều nhất cho nhóm mục tiêu.
 */
function phanBo(soCau) {
  const n = Math.max(8, Math.min(Math.trunc(Number(soCau) || 20), 60));
  const ra = MA_TRAN_GIOI.map((m) => ({ ...m, soCau: Math.floor(n * m.share) }));
  const du = n - ra.reduce((s, x) => s + x.soCau, 0);
  const bon = ra.find((x) => x.sao === 4);
  bon.soCau += du;
  return { tongCau: n, theoMuc: ra, du };
}

/** Bản mô tả đề cho một lớp tại một mốc — dùng cho lộ trình và cho báo cáo. */
function moTaDe({ lop, mocMa, mon = 'math', soCau = 20 } = {}) {
  const pv = phamVi({ lop, mocMa, mon });
  if (!pv.ok) return pv;
  const pb = phanBo(soCau);
  const moc = MOC_INDEX.get(mocMa);
  return {
    ok: true,
    lop: Number(lop), mon,
    moc: moc.ma, tenMoc: moc.ten, thang: moc.thang, vaiTro: moc.vaiTro,
    tongCau: pb.tongCau,
    theoMuc: pb.theoMuc,
    phamVi: {
      dangCungLop: pv.dangCungLop.length, dangLopTruoc: pv.dangLopTruoc.length,
      dangChuaDay: pv.dangChuaDay.length, quyTac: pv.quyTac,
      danhSach: pv.dangCungLop.concat(pv.dangLopTruoc),
    },
    soSanh: {
      deTruong: MA_TRAN_TRUONG.map((m) => `${m.ten} ${Math.round(m.share * 100)}%`).join(' · '),
      deNay: MA_TRAN_GIOI.map((m) => `${m.ten} ${Math.round(m.share * 100)}%`).join(' · '),
      viSao: 'Một câu mà gần như ai cũng làm đúng thì không phân loại được ai. '
        + 'Muốn tách hai em cùng 9,25 thì phải hỏi ở chỗ hai em ấy khác nhau.',
    },
    nhac: NHAC,
  };
}

module.exports = {
  MOC, MOC_INDEX, MA_TRAN_GIOI, MA_TRAN_TRUONG, QUY_DOI, NHAC,
  quyDoiHocLuc, phamVi, phanBo, moTaDe,
};
