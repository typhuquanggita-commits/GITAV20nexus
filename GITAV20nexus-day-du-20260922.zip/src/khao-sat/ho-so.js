'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  HỒ SƠ KHẢO SÁT — gộp sáu công cụ, nhưng KHÔNG trộn sức nặng của chúng
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Cái bẫy của mọi "hồ sơ toàn diện": in sáu kết quả cạnh nhau, cùng cỡ chữ,
 *  cùng một màu, rồi người đọc tự hiểu rằng sáu thứ ấy nặng như nhau. Điểm
 *  bài kiểm tra toán và con số thần số học nằm cùng một trang thì người đọc
 *  sẽ dùng cả hai như nhau, dù trang đó có in cảnh báo ở đâu đó phía dưới.
 *
 *  Nên hồ sơ này KHÔNG xếp sáu phần bằng nhau. Nó chia ba tầng theo đúng luật
 *  đo (src/khao-sat/hien-phap-do.js):
 *
 *    TẦNG 1 — QUYẾT ĐỊNH NỘI DUNG   đề năng lực môn · phương pháp học
 *    TẦNG 2 — ĐIỀU CHỈNH CÁCH LÀM   tâm lý học đường · DISC · MBTI
 *    TẦNG 3 — KHÔNG DÙNG VÀO VIỆC   thần số học
 *
 *  Và mỗi phần đều mang theo `duocDungDe` — danh sách miền nó được phép chạm.
 *  Bộ dựng lộ trình đọc đúng trường đó, không đọc tên công cụ.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { CONG_CU_INDEX, luatDo } = require('./hien-phap-do');

const TANG = {
  1: { so: 1, ten: 'Quyết định nội dung học', giaiThich: 'Có đúng sai, hoặc đối chiếu được với dấu vết thật.' },
  2: { so: 2, ten: 'Điều chỉnh cách làm việc với học viên', giaiThich: 'Là điều học viên tự nói về mình — dùng để nói chuyện, không dùng để xếp bài.' },
  3: { so: 3, ten: 'Không dùng vào việc gì', giaiThich: 'Không đo gì cả. Có mặt vì gia đình hỏi, và được nói thẳng là không dùng.' },
};

/** Công cụ nào thuộc tầng nào — suy từ luật đo, không khai tay hai lần. */
function tangCua(ma) {
  const c = CONG_CU_INDEX.get(ma);
  if (!c) return null;
  if (c.anhHuong.length === 0) return 3;
  return c.anhHuong.includes('noi-dung') ? 1 : 2;
}

/**
 * Dựng hồ sơ.
 *
 * @param {object} o
 *   hocVienId, hoTen, lop
 *   ketQua: { NANG_LUC_MON, PHUONG_PHAP_HOC, DISC, MBTI, THAN_SO, TAM_LY_HOC_DUONG }
 *           — mỗi trường là đầu ra của hàm cham()/tinh() tương ứng, hoặc thiếu
 */
function dungHoSo({ hocVienId, hoTen = '', lop = null, ketQua = {} } = {}) {
  if (!hocVienId) return { ok: false, error: 'THIẾU_MÃ_HỌC_VIÊN' };

  const phan = [];
  for (const [ma, c] of CONG_CU_INDEX) {
    const kq = ketQua[ma] || null;
    const t = tangCua(ma);
    phan.push({
      ma, ten: c.ten, loai: c.loai, tang: t, tenTang: TANG[t].ten,
      coKetQua: !!kq,
      duocDungDe: c.anhHuong.slice(),
      doDuoc: c.doDuoc,
      khongDoDuoc: c.khongDoDuoc,
      canNguoi: c.canNguoi,
      ghiChu: c.ghiChu,
      ketQua: kq,
    });
  }
  phan.sort((a, b) => a.tang - b.tang || a.ma.localeCompare(b.ma));

  const thieu = phan.filter((p) => !p.coKetQua).map((p) => p.ten);
  const quyetNoiDung = phan.filter((p) => p.tang === 1 && p.coKetQua);

  // Cờ cần người lớn: lấy thẳng từ kết quả sàng lọc tâm lý, không suy đoán.
  const tl = ketQua.TAM_LY_HOC_DUONG || null;
  const canNguoiLonNgay = !!(tl && tl.canNguoiLonNgay);

  return {
    ok: true,
    hocVienId, hoTen, lop,
    luc: Date.now(),
    luatDo: luatDo(),
    tang: Object.values(TANG),
    phan,
    soCoKetQua: phan.filter((p) => p.coKetQua).length,
    soThieu: thieu.length,
    thieu,
    // Hai cờ này là thứ người đọc phải thấy trước tiên.
    canNguoiLonNgay,
    duDeDungLoTrinh: quyetNoiDung.length > 0,
    ketLuan: canNguoiLonNgay
      ? 'CẦN NGƯỜI LỚN NÓI CHUYỆN TRƯỚC. Sàng lọc tâm lý có miền vượt ngưỡng cần báo ngay — '
        + 'việc đó đi trước mọi chuyện lộ trình.'
      : quyetNoiDung.length === 0
        ? 'Chưa dựng được lộ trình: chưa có công cụ nào thuộc tầng 1 (đề năng lực môn học hoặc khảo sát phương pháp học).'
        : `Đủ căn cứ dựng lộ trình từ ${quyetNoiDung.length} công cụ tầng 1.`
          + (thieu.length ? ` Còn thiếu ${thieu.length} phần: ${thieu.join(', ')}.` : ''),
  };
}

module.exports = { TANG, tangCua, dungHoSo };
