'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  KHO KẾT QUẢ KHẢO SÁT — lưu có kiểm soát, không lưu bừa
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  VÌ SAO TỆP NÀY RA ĐỜI. Bản dựng đầu của bộ khảo sát KHÔNG lưu gì cả, và tôi
 *  đã gọi đó là "bảo đảm riêng tư mạnh nhất". Bản rà soát cho thấy đó là một
 *  lời biện hộ cho một việc chưa làm xong: không lưu thì học viên làm xong bài
 *  khảo sát rồi kết quả bay mất, hồ sơ vĩnh viễn rỗng, và trang lộ trình cá
 *  nhân hoá vĩnh viễn hiện "CHƯA_ĐỦ_CĂN_CỨ" cho mọi tài khoản thật.
 *
 *  Riêng tư đúng nghĩa là KIỂM SOÁT TRUY CẬP, không phải mất dữ liệu.
 *
 *  BỐN LUẬT CỦA KHO NÀY
 *    1. Ai đọc được — khai tường minh theo từng công cụ, không theo cả kho.
 *       Kết quả sàng lọc tâm lý chặt hơn kết quả DISC, vì nó nhạy cảm hơn.
 *    2. Lưu CÂU TRẢ LỜI THÔ hay không — cũng khai tường minh. Với sàng lọc tâm
 *       lý, hệ thống chỉ lưu ĐIỂM MIỀN và kết luận, KHÔNG lưu từng câu. Biết
 *       "miền giấc ngủ ở mức đáng chú ý" là đủ để hành động; biết em trả lời
 *       câu nào mấy điểm thì không thêm gì cho việc giúp em, mà lại là thứ
 *       nặng nhất nếu lộ.
 *    3. Mỗi lần làm là một BẢN GHI MỚI. Không ghi đè: xu hướng qua ba tháng
 *       nói nhiều hơn một lát cắt, và ghi đè là xoá mất xu hướng ấy.
 *    4. Xoá được. Gia đình yêu cầu xoá thì xoá thật, và việc xoá có dấu vết.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { CONG_CU_INDEX } = require('./hien-phap-do');

/**
 * Luật riêng tư của từng công cụ.
 *   aiDoc      vai được đọc kết quả (ngoài chính học viên đó)
 *   luuCauTho  có lưu từng câu trả lời không
 *   viSao      lý do, viết ra để lần sau ai sửa còn biết mình đang đổi gì
 */
const RIENG_TU = {
  NANG_LUC_MON: {
    aiDoc: ['phu-huynh', 'giao-vien', 'co-van'], luuCauTho: true,
    viSao: 'Bài có đáp án đúng sai; giáo viên cần xem từng câu để biết em hổng dạng nào.',
  },
  PHUONG_PHAP_HOC: {
    aiDoc: ['phu-huynh', 'giao-vien', 'co-van'], luuCauTho: true,
    viSao: 'Cần câu thô để đối chiếu lời tự khai với dấu vết thật ở lần sau.',
  },
  DISC: {
    aiDoc: ['phu-huynh', 'giao-vien', 'co-van'], luuCauTho: true,
    viSao: 'Phong cách hành vi trong học tập, không nhạy cảm, và cần câu thô để chấm lại nếu đổi cách chấm.',
  },
  MBTI: {
    aiDoc: ['phu-huynh', 'giao-vien', 'co-van'], luuCauTho: true,
    viSao: 'Thiên hướng lựa chọn trong học tập, không nhạy cảm. Cần câu thô vì bộ này hay được làm lại '
      + 'sau vài tháng, và chỉ có câu thô mới so được hai lần làm với nhau.',
  },
  THAN_SO: {
    aiDoc: ['phu-huynh'], luuCauTho: false,
    viSao: 'Không đo gì cả, nên không có lý do để giáo viên đọc. Càng ít người thấy con số này càng tốt.',
  },
  TAM_LY_HOC_DUONG: {
    // Giáo viên bộ môn KHÔNG nằm trong danh sách. Người cần biết là người có
    // thể làm gì đó: gia đình và cố vấn.
    aiDoc: ['phu-huynh', 'co-van'], luuCauTho: false,
    viSao: 'Chỉ lưu điểm miền và kết luận. Biết miền nào vượt ngưỡng là đủ để hành động; '
      + 'lưu từng câu không giúp gì thêm mà lại là thứ nặng nhất nếu lộ.',
  },
};

/** Bỏ phần không được phép lưu khỏi một kết quả trước khi ghi xuống. */
function gotTruocKhiLuu(congCuMa, ketQua) {
  const lt = RIENG_TU[congCuMa];
  if (!lt) return { ok: false, error: 'KHÔNG_CÓ_CÔNG_CỤ_NÀY', congCuMa };
  const kq = JSON.parse(JSON.stringify(ketQua || {}));
  if (congCuMa === 'TAM_LY_HOC_DUONG') {
    // Giữ điểm miền và kết luận, bỏ mọi thứ có thể lần ra câu trả lời từng câu.
    delete kq.loi;
    if (Array.isArray(kq.mien)) {
      kq.mien = kq.mien.map((m) => ({
        ma: m.ma, ten: m.ten, duCanCu: m.duCanCu, muc: m.muc,
        diemTrungBinh: m.diemTrungBinh, canNguoiNgay: m.canNguoiNgay,
        khiCao: m.khiCao, lamGi: m.lamGi,
      }));
    }
    delete kq.soCauTraLoi;
  }
  return { ok: true, ketQua: kq };
}

class KhoKhaoSat {
  /** @param {object} o {repo} — bộ sưu tập bền vững, có thể null khi chạy trong bộ nhớ */
  constructor({ repo = null } = {}) {
    if (repo) this._kiemRepo(repo);
    this.repo = repo;
    this.trongBoNho = [];
    this.stats = { luu: 0, doc: 0, xoa: 0, tuChoi: 0 };
  }

  /**
   * Kiểm kho bền vững có đúng hình dạng không, NGAY LÚC DỰNG.
   *
   * Bản trước gọi repo.insert(), repo.find({}), repo.remove() — ba tên không
   * hề tồn tại trong Repository (đúng tên là put / filter / delete). Mỗi lời
   * gọi nằm trong một try/catch, nên TypeError bị nuốt sạch và kho lặng lẽ
   * rơi về bộ nhớ: luu() vẫn trả ok:true, status() vẫn khoe benVung:true, mà
   * đĩa trống trơn. Tắt máy là mất hết, và không một dòng cảnh báo nào.
   *
   * Nên giờ kho KIỂM HÌNH DẠNG ngay lúc dựng và NÉM LỖI nếu sai. Hỏng lúc
   * khởi động thì ai cũng thấy; hỏng âm thầm thì sáu tháng sau mới biết, lúc
   * gia đình hỏi dữ liệu của con họ đâu.
   */
  _kiemRepo(repo) {
    const can = ['put', 'filter', 'delete', 'count'];
    const thieu = can.filter((m) => typeof repo[m] !== 'function');
    if (thieu.length) {
      throw new Error(`KhoKhaoSat: kho bền vững thiếu phương thức ${thieu.join(', ')} — `
        + 'không được im lặng rơi về bộ nhớ, vì như thế là mất dữ liệu mà không ai biết.');
    }
  }

  _tatCa() {
    if (this.repo) return this.repo.filter(() => true);
    return this.trongBoNho;
  }

  /**
   * Lưu một lần làm bài.
   * @param {object} o {hocVienId, congCu, ketQua, cauTraLoi, nguoiLam}
   */
  luu({ hocVienId, congCu, ketQua, cauTraLoi = null, nguoiLam = null } = {}) {
    if (!hocVienId) return { ok: false, error: 'THIẾU_MÃ_HỌC_VIÊN' };
    if (!CONG_CU_INDEX.has(congCu)) return { ok: false, error: 'KHÔNG_CÓ_CÔNG_CỤ_NÀY', congCu };
    const got = gotTruocKhiLuu(congCu, ketQua);
    if (!got.ok) return got;

    const lt = RIENG_TU[congCu];
    const ban = {
      id: `KS-${congCu}-${hocVienId}-${Date.now()}`,
      hocVienId, congCu,
      luc: Date.now(),
      nguoiLam: nguoiLam || hocVienId,
      ketQua: got.ketQua,
      // Câu thô chỉ được lưu khi luật của công cụ ấy cho phép.
      cauTraLoi: lt.luuCauTho && cauTraLoi ? cauTraLoi : null,
      khongLuuCauTho: !lt.luuCauTho,
      aiDoc: lt.aiDoc.slice(),
    };
    if (this.repo) {
      // KHÔNG bọc try/catch nuốt lỗi ở đây. Ghi hỏng là chuyện phải biết ngay,
      // không phải chuyện lặng lẽ đổi sang ghi vào bộ nhớ rồi báo thành công.
      this.repo.put(ban);
    } else {
      this.trongBoNho.push(ban);
    }
    this.stats.luu++;
    return { ok: true, id: ban.id, luc: ban.luc, khongLuuCauTho: ban.khongLuuCauTho };
  }

  /**
   * Đọc kết quả MỚI NHẤT của mỗi công cụ cho một học viên.
   *
   * @param {string} hocVienId
   * @param {object} o {vaiNguoiDoc, laChinhChu} — quyết định đọc được phần nào
   */
  moiNhat(hocVienId, { vaiNguoiDoc = null, laChinhChu = false } = {}) {
    this.stats.doc++;
    const cua = this._tatCa().filter((x) => x.hocVienId === hocVienId);
    const ra = {};
    const bịChan = [];
    for (const [ma] of CONG_CU_INDEX) {
      const ds = cua.filter((x) => x.congCu === ma).sort((a, b) => b.luc - a.luc);
      if (!ds.length) continue;
      const duocDoc = laChinhChu || (vaiNguoiDoc && RIENG_TU[ma].aiDoc.includes(vaiNguoiDoc));
      if (!duocDoc) { bịChan.push(ma); this.stats.tuChoi++; continue; }
      ra[ma] = ds[0];
    }
    return { ketQua: ra, soCo: Object.keys(ra).length, bịChan, tongBanGhi: cua.length };
  }

  /** Lịch sử một công cụ, để nhìn xu hướng thay vì một lát cắt. */
  lichSu(hocVienId, congCu) {
    return this._tatCa()
      .filter((x) => x.hocVienId === hocVienId && x.congCu === congCu)
      .sort((a, b) => a.luc - b.luc);
  }

  /** Xoá theo yêu cầu của gia đình. Xoá thật, và trả về số bản đã xoá. */
  xoa(hocVienId, { congCu = null } = {}) {
    const hop = (x) => x.hocVienId === hocVienId && (!congCu || x.congCu === congCu);
    let so = 0;
    if (this.repo) {
      for (const x of this._tatCa().filter(hop)) { this.repo.delete(x.id); so++; }
    }
    const truoc = this.trongBoNho.length;
    this.trongBoNho = this.trongBoNho.filter((x) => !hop(x));
    so += truoc - this.trongBoNho.length;
    this.stats.xoa += so;
    return { ok: true, daXoa: so };
  }

  status() {
    // benVung nói THẬT: không chỉ "có gắn kho" mà "kho ấy đang giữ được bao
    // nhiêu bản ghi". Con số này đối chiếu được với tệp trên đĩa.
    return {
      banGhi: this._tatCa().length,
      ...this.stats,
      benVung: !!this.repo,
      banGhiTrenDia: this.repo ? this.repo.count() : 0,
    };
  }
}

module.exports = KhoKhaoSat;
module.exports.RIENG_TU = RIENG_TU;
module.exports.gotTruocKhiLuu = gotTruocKhiLuu;
