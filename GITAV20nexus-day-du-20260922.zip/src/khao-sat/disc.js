'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  DISC — PHONG CÁCH HÀNH VI TRONG HỌC TẬP
 * ═══════════════════════════════════════════════════════════════════════════
 *  Bốn nhóm, đặt tên bằng tiếng Việt học đường thay vì bê nguyên thuật ngữ:
 *    D (Dứt khoát)  — muốn kết quả nhanh, thích thử thách, ngại vòng vo
 *    I (Ảnh hưởng)  — học bằng trao đổi, thích kể lại, cần khán giả
 *    S (Ổn định)    — cần nhịp đều, ngại thay đổi đột ngột, kiên trì
 *    C (Cẩn trọng)  — cần đúng và đủ, soi kỹ, khó chịu khi mơ hồ
 *
 *  ĐỊNH DẠNG: tứ bộ ép chọn. Mỗi câu cho bốn phát biểu, mỗi phát biểu thuộc
 *  một nhóm; người làm chọn ĐÚNG NHẤT và ÍT ĐÚNG NHẤT. Chọn kiểu này vì thang
 *  Likert thường (đồng ý 1–5) ở lứa tuổi học sinh gần như lúc nào cũng ra
 *  "cái gì cũng hơi đúng", và một hồ sơ mà bốn nhóm đều 25% thì không dùng
 *  được vào việc gì.
 *
 *  CÁI GIÁ CỦA ĐỊNH DẠNG NÀY, nói thẳng: điểm ra là điểm IPSATIVE — bốn nhóm
 *  so với NHAU trong cùng một người. Hai học viên cùng ra "D cao nhất" không
 *  có nghĩa là hai em dứt khoát như nhau; chỉ có nghĩa là trong mỗi em, D nổi
 *  hơn ba nhóm còn lại. Vì vậy hệ thống KHÔNG xếp hạng học viên theo DISC và
 *  KHÔNG so DISC giữa các em. Xem src/khao-sat/hien-phap-do.js.
 *
 *  Hai mươi tứ bộ dưới đây viết tay cho bối cảnh học tập, không dịch máy từ
 *  bộ tiếng Anh. Mỗi tứ bộ là một TÌNH HUỐNG HỌC CỤ THỂ, vì hỏi "bạn có quyết
 *  đoán không" thì ai cũng trả lời theo hình ảnh mình muốn có.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const NHOM = {
  D: {
    ma: 'D', ten: 'Dứt khoát', mau: 'cam',
    moTa: 'Muốn thấy kết quả nhanh, thích bài khó, ngại phần dẫn nhập dài.',
    khiHoc: 'Vào thẳng bài khó nhất trước, rồi mới quay lại phần nền.',
    deMatDiem: 'Bỏ bước trình bày vì thấy mất thời gian, nên mất điểm ở chỗ không đáng.',
  },
  I: {
    ma: 'I', ten: 'Ảnh hưởng', mau: 'hong',
    moTa: 'Học bằng cách nói ra, thích giảng lại cho người khác, cần được ghi nhận.',
    khiHoc: 'Giảng lại bài vừa học cho một người là cách ôn hiệu quả nhất với nhóm này.',
    deMatDiem: 'Học nhóm thành buổi trò chuyện, hết giờ mà chưa làm được bài nào.',
  },
  S: {
    ma: 'S', ten: 'Ổn định', mau: 'luc',
    moTa: 'Cần nhịp đều và báo trước, ngại đổi kế hoạch đột ngột, bền bỉ.',
    khiHoc: 'Giữ được lịch học dài hơi hơn ba nhóm kia, nếu lịch không bị xáo.',
    deMatDiem: 'Ở lại quá lâu trong vùng dễ vì ngại bước sang dạng mới.',
  },
  C: {
    ma: 'C', ten: 'Cẩn trọng', mau: 'lam',
    moTa: 'Cần biết đủ và đúng trước khi làm, soi kỹ lời giải, khó chịu khi đề mơ hồ.',
    khiHoc: 'Tự soát lại tốt, hiếm khi sai do ẩu.',
    deMatDiem: 'Dừng quá lâu ở một câu vì muốn chắc chắn, hết giờ ở phần cuối đề.',
  },
};

/**
 * Hai mươi tứ bộ. Mỗi phần tử: [tình huống, {D,I,S,C}].
 * Thứ tự bốn lựa chọn trong đề hiển thị được xoay theo chỉ số câu (xem deBai)
 * để vị trí không thành gợi ý.
 */
const TU_BO = [
  ['Cô giao một bài khó chưa từng gặp, còn mười lăm phút', {
    D: 'Lao vào làm ngay, sai thì sửa',
    I: 'Quay sang hỏi bạn bên cạnh xem bạn nghĩ gì',
    S: 'Làm lại một bài tương tự đã biết cho chắc trước',
    C: 'Đọc kỹ đề hai lần, gạch chân dữ kiện rồi mới viết',
  }],
  ['Điểm bài kiểm tra thấp hơn mình nghĩ', {
    D: 'Hỏi ngay bài sau bao giờ thi lại',
    I: 'Kể cho bạn nghe mình sai chỗ nào',
    S: 'Lặng lẽ làm lại đúng dạng đó vài hôm',
    C: 'Dò từng câu xem mình mất điểm ở bước nào',
  }],
  ['Được chọn cách ôn cho kỳ thi tháng sau', {
    D: 'Làm thẳng đề thi thật, bấm giờ',
    I: 'Rủ hai bạn học chung, thay nhau giảng',
    S: 'Chia đều mỗi ngày một ít, theo đúng lịch',
    C: 'Lập bảng các dạng, đánh dấu dạng nào chưa chắc',
  }],
  ['Thầy đổi lịch kiểm tra sớm hơn một tuần', {
    D: 'Tốt, thi sớm cho xong',
    I: 'Hỏi cả lớp xem mọi người tính sao',
    S: 'Thấy khó chịu vì kế hoạch bị xáo',
    C: 'Hỏi lại thầy phạm vi kiểm tra có đổi không',
  }],
  ['Làm bài nhóm mà một bạn không làm phần của mình', {
    D: 'Nói thẳng với bạn ấy',
    I: 'Rủ bạn ấy làm cùng cho vui',
    S: 'Làm hộ phần đó cho xong việc',
    C: 'Ghi lại ai làm phần nào rồi báo cô',
  }],
  ['Gặp một bài có hai cách giải', {
    D: 'Chọn cách nào ra đáp số nhanh hơn',
    I: 'Hỏi xem bạn mình làm cách nào',
    S: 'Dùng cách cô đã dạy trên lớp',
    C: 'Thử cả hai để biết cách nào chặt hơn',
  }],
  ['Khi ngồi vào bàn học buổi tối', {
    D: 'Mở luôn phần khó nhất',
    I: 'Nhắn tin cho bạn xem hôm nay học gì',
    S: 'Làm đúng thứ tự như mọi hôm',
    C: 'Soạn đủ vở, bút, máy tính rồi mới bắt đầu',
  }],
  ['Cô hỏi cả lớp một câu khó', {
    D: 'Giơ tay trả lời dù chưa chắc',
    I: 'Nói to suy nghĩ của mình cho bạn bên cạnh nghe',
    S: 'Chờ xem bạn khác trả lời thế nào',
    C: 'Nghĩ cho chắc rồi mới giơ tay',
  }],
  ['Bài tập về nhà có phần tự chọn', {
    D: 'Chọn phần nhiều điểm nhất',
    I: 'Chọn phần có thể làm cùng bạn',
    S: 'Chọn phần giống bài đã làm trên lớp',
    C: 'Chọn phần có hướng dẫn rõ ràng nhất',
  }],
  ['Lúc gần hết giờ làm bài mà còn hai câu', {
    D: 'Làm nhanh cả hai, chấp nhận ẩu',
    I: 'Sốt ruột, nhìn quanh xem bạn xong chưa',
    S: 'Làm tiếp câu đang dở, không đổi',
    C: 'Soát lại phần đã làm thay vì làm thêm',
  }],
  ['Được khen trước lớp', {
    D: 'Nghĩ ngay tới mục tiêu tiếp theo',
    I: 'Thấy rất vui, nhớ rất lâu',
    S: 'Hơi ngại nhưng thấy ấm lòng',
    C: 'Tự hỏi mình có xứng đáng chưa',
  }],
  ['Khi phải học một môn mình không thích', {
    D: 'Học cho xong phần bắt buộc, tập trung vào môn mạnh',
    I: 'Tìm cách làm nó vui hơn, học cùng bạn',
    S: 'Vẫn học đều như các môn khác',
    C: 'Tìm hiểu kỹ xem môn này dùng vào đâu',
  }],
  ['Thấy bạn cùng bàn làm sai', {
    D: 'Nói luôn là sai rồi',
    I: 'Chỉ cho bạn cách mình làm',
    S: 'Im lặng, sợ bạn ngại',
    C: 'Kiểm lại mình có đúng không rồi mới nói',
  }],
  ['Được giao làm nhóm trưởng', {
    D: 'Chia việc ngay và đặt hạn',
    I: 'Họp nhóm cho mọi người quen nhau trước',
    S: 'Hỏi xem ai muốn làm phần nào',
    C: 'Lập bảng công việc và tiêu chí xong',
  }],
  ['Khi ôn trước kỳ thi một ngày', {
    D: 'Làm một đề thật xem được bao nhiêu điểm',
    I: 'Gọi bạn hỏi bài qua lại',
    S: 'Đọc lại vở theo đúng thứ tự bài',
    C: 'Rà danh sách dạng, tìm dạng còn hổng',
  }],
  ['Cô trả bài và giảng lại câu sai', {
    D: 'Nghe phần kết luận, bỏ phần dẫn',
    I: 'Hỏi lại ngay tại chỗ cho rõ',
    S: 'Chép đầy đủ lời giảng vào vở',
    C: 'Đối chiếu lời giảng với bài mình đã làm',
  }],
  ['Khi kế hoạch học tuần bị vỡ vì bận việc nhà', {
    D: 'Bỏ phần phụ, giữ phần chính',
    I: 'Nhắn cho bạn học cùng biết',
    S: 'Thấy tiếc, cố làm bù cho đủ',
    C: 'Lập lại kế hoạch mới cho phần còn lại',
  }],
  ['Đứng trước một dạng bài hoàn toàn mới', {
    D: 'Thử làm trước khi đọc lý thuyết',
    I: 'Xem người khác làm rồi bắt chước',
    S: 'Chờ cô dạy xong mới làm',
    C: 'Đọc hết lý thuyết rồi mới làm bài đầu tiên',
  }],
  ['Khi phải chọn giữa điểm cao và hiểu sâu', {
    D: 'Chọn điểm cao, hiểu sau cũng được',
    I: 'Chọn cách nào kể lại cho người khác được',
    S: 'Chọn cách nào yên tâm hơn',
    C: 'Chọn hiểu sâu, điểm sẽ theo sau',
  }],
  ['Khi bài giải của mình khác đáp án', {
    D: 'Tin mình, làm tiếp bài khác',
    I: 'Hỏi bạn xem bạn ra bao nhiêu',
    S: 'Làm lại theo đáp án cho giống',
    C: 'Dò từng bước tới khi tìm ra chỗ lệch',
  }],
];

const MA_NHOM = ['D', 'I', 'S', 'C'];

/**
 * Sinh đề. Thứ tự bốn lựa chọn XOAY theo chỉ số câu — tất định, không random —
 * để nhóm D không nằm lì ở vị trí đầu suốt hai mươi câu.
 */
function deBai() {
  return TU_BO.map(([tinhHuong, lua], i) => ({
    so: i + 1,
    tinhHuong,
    luaChon: MA_NHOM.map((_, k) => MA_NHOM[(k + i) % 4]).map((ma) => ({ ma, chu: lua[ma] })),
  }));
}

/**
 * Chấm.
 * @param {Array<{so:number, dungNhat:string, itDungNhat:string}>} traLoi
 */
function cham(traLoi = []) {
  const diem = { D: 0, I: 0, S: 0, C: 0 };
  const loi = [];
  const daTraLoi = new Set();
  for (const t of traLoi) {
    const so = Number(t.so);
    if (!Number.isInteger(so) || so < 1 || so > TU_BO.length) { loi.push(`câu ${t.so} không có trong đề`); continue; }
    if (daTraLoi.has(so)) { loi.push(`câu ${so} trả lời hai lần`); continue; }
    if (!MA_NHOM.includes(t.dungNhat) || !MA_NHOM.includes(t.itDungNhat)) { loi.push(`câu ${so} chọn nhóm không có thật`); continue; }
    if (t.dungNhat === t.itDungNhat) { loi.push(`câu ${so} chọn cùng một ý cho cả "đúng nhất" và "ít đúng nhất"`); continue; }
    daTraLoi.add(so);
    diem[t.dungNhat] += 1;
    diem[t.itDungNhat] -= 1;
  }

  const soCau = daTraLoi.size;
  // Dưới hai phần ba số câu thì KHÔNG chấm. Một hồ sơ dựng trên bảy câu trả
  // lời trông y hệt một hồ sơ dựng trên hai mươi câu, và đó mới là chỗ nguy.
  const doi = Math.ceil(TU_BO.length * 2 / 3);
  if (soCau < doi) {
    return {
      ok: false, duCanCu: false, soCau, soCauCanToiThieu: doi, loi,
      ghiChu: `Mới trả lời ${soCau}/${TU_BO.length} câu, cần ít nhất ${doi} câu mới chấm được. `
        + 'Chấm thiếu câu thì bảng vẫn ra bốn con số, nhưng bốn con số ấy không nói lên điều gì.',
    };
  }

  const xep = MA_NHOM.map((ma) => ({ ma, ten: NHOM[ma].ten, diem: diem[ma] }))
    .sort((a, b) => b.diem - a.diem || MA_NHOM.indexOf(a.ma) - MA_NHOM.indexOf(b.ma));
  const troi = xep[0];
  const thu2 = xep[1];
  // Cách nhau dưới hai điểm là KHÔNG có nhóm trội. Ép ra một nhãn trong trường
  // hợp đó là gán cho học viên một tính cách mà dữ liệu không nói.
  const coTroi = troi.diem - thu2.diem >= 2;

  return {
    ok: true, duCanCu: true, soCau,
    diem, xep,
    nhomTroi: coTroi ? troi.ma : null,
    tenNhomTroi: coTroi ? troi.ten : null,
    moTa: coTroi ? NHOM[troi.ma].moTa : null,
    khiHoc: coTroi ? NHOM[troi.ma].khiHoc : null,
    deMatDiem: coTroi ? NHOM[troi.ma].deMatDiem : null,
    ghiChu: coTroi
      ? `Nhóm ${troi.ten} nổi hơn ba nhóm còn lại TRONG CHÍNH EM NÀY. `
        + 'Đây không phải thang so được giữa hai học viên, và không nói gì về năng lực.'
      : `Bốn nhóm cách nhau dưới hai điểm (${xep.map((x) => `${x.ma} ${x.diem}`).join(', ')}) nên KHÔNG có nhóm trội. `
        + 'Điều này hoàn toàn bình thường; ép ra một nhãn lúc này là gán cho em một tính cách mà bài làm không nói.',
    loi,
  };
}

module.exports = { NHOM, TU_BO, MA_NHOM, deBai, cham };
