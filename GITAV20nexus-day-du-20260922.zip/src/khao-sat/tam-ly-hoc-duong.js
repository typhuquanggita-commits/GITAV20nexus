'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  SÀNG LỌC TÂM LÝ HỌC ĐƯỜNG
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  ĐÂY LÀ SÀNG LỌC, KHÔNG PHẢI CHẨN ĐOÁN. Một bảng hỏi hai mươi tư câu không
 *  thay được một người có chuyên môn ngồi xuống nói chuyện. Vượt ngưỡng ở đây
 *  nghĩa là "cần một người lớn hỏi han", KHÔNG nghĩa là có bệnh, và hệ thống
 *  không bao giờ được in ra một cái tên bệnh.
 *
 *  ĐIỀU HỆ THỐNG CỐ Ý KHÔNG LÀM — và đây là quyết định quan trọng nhất của
 *  tệp này: KHÔNG sàng lọc ý định tự hại. Sàng lọc tự hại bằng một bảng hỏi
 *  tự động, trong một sản phẩm học tập không có người trực, là việc nguy hiểm:
 *  câu hỏi được đặt ra mà không ai ở đó để đỡ câu trả lời. Việc ấy cần người
 *  được đào tạo, có quy trình và có mặt thật. Hệ thống nói thẳng là mình không
 *  làm, thay vì làm nửa vời rồi để một câu trả lời nặng rơi vào khoảng không.
 *
 *  AI ĐƯỢC ĐỌC KẾT QUẢ: phụ huynh và cố vấn của chính học viên đó. Không hiện
 *  trên bảng xếp hạng, không so giữa các em, không vào hồ sơ dùng cho việc xếp
 *  lớp. Sáu miền dưới đây đều hỏi về TẦN SUẤT trong hai tuần gần nhất, vì hỏi
 *  "em có hay lo lắng không" thì câu trả lời phụ thuộc vào hôm đó em thấy thế
 *  nào hơn là vào hai tuần vừa rồi.
 * ═══════════════════════════════════════════════════════════════════════════
 */

/** Thang tần suất, 0..4. */
const THANG = [
  { diem: 0, chu: 'Không hôm nào' },
  { diem: 1, chu: 'Một vài hôm' },
  { diem: 2, chu: 'Khoảng một nửa số hôm' },
  { diem: 3, chu: 'Phần lớn các hôm' },
  { diem: 4, chu: 'Gần như mỗi ngày' },
];

/**
 * Sáu miền.
 *   canNguoiNgay  true → vượt ngưỡng là báo NGAY cho người lớn, không chờ đủ bộ
 *   nguong        [nhẹ, đáng chú ý] trên thang điểm trung bình 0..4
 */
const MIEN = {
  AP_LUC: {
    ma: 'AP_LUC', ten: 'Áp lực học tập', nguong: [1.5, 2.5], canNguoiNgay: false,
    khiCao: 'Em đang thấy khối lượng học vượt sức mình trong hai tuần qua.',
    lamGi: 'Giảm tải một bậc trong hai tuần, cắt bớt mục tiêu tuần, và hỏi em phần nào nặng nhất.',
  },
  LO_THI: {
    ma: 'LO_THI', ten: 'Lo âu thi cử', nguong: [1.5, 2.5], canNguoiNgay: false,
    khiCao: 'Em lo trước và trong lúc làm bài tới mức ảnh hưởng đến kết quả.',
    lamGi: 'Luyện đề có bấm giờ trong điều kiện quen thuộc, tách hẳn "bài luyện" khỏi "bài chấm điểm".',
  },
  GIAC_NGU: {
    ma: 'GIAC_NGU', ten: 'Giấc ngủ', nguong: [1.5, 2.5], canNguoiNgay: false,
    khiCao: 'Em khó ngủ hoặc ngủ không đủ trong hai tuần qua.',
    lamGi: 'Chuyển buổi luyện cuối cùng lên sớm hơn, và bỏ hẳn buổi học sau 22 giờ.',
  },
  DONG_LUC: {
    ma: 'DONG_LUC', ten: 'Động lực học', nguong: [1.5, 2.5], canNguoiNgay: false,
    khiCao: 'Em đang thấy việc học mất ý nghĩa hoặc không còn muốn cố.',
    lamGi: 'Quay lại mục tiêu do chính em chọn, và cho em thấy một tiến bộ cụ thể đã đạt được.',
  },
  BAN_BE: {
    ma: 'BAN_BE', ten: 'Quan hệ bạn bè', nguong: [1.5, 2.5], canNguoiNgay: false,
    khiCao: 'Em đang thấy cô đơn hoặc khó hoà nhập ở lớp.',
    lamGi: 'Người lớn hỏi han riêng; cân nhắc hình thức học có bạn cùng nhóm.',
  },
  AN_TOAN: {
    ma: 'AN_TOAN', ten: 'Cảm giác an toàn ở trường', nguong: [0.5, 1.5], canNguoiNgay: true,
    khiCao: 'Em đang thấy không an toàn, bị trêu chọc hoặc bị cô lập.',
    lamGi: 'Báo ngay cho phụ huynh và giáo viên chủ nhiệm. Đây là việc của người lớn, không phải việc em tự xoay.',
  },
};

/** [miền, câu hỏi]. Mỗi miền bốn câu, hỏi về tần suất trong hai tuần gần nhất. */
const CAU = [
  ['AP_LUC', 'Em thấy bài vở nhiều hơn mức mình làm nổi'],
  ['AP_LUC', 'Em phải bỏ bữa hoặc bỏ nghỉ ngơi để kịp bài'],
  ['AP_LUC', 'Em thấy mệt ngay từ lúc mới ngồi vào bàn học'],
  ['AP_LUC', 'Em nghĩ về bài vở cả lúc đang làm việc khác'],

  ['LO_THI', 'Trước hôm kiểm tra, em thấy bồn chồn khó chịu'],
  ['LO_THI', 'Vào phòng thi, em quên mất thứ mình vừa ôn'],
  ['LO_THI', 'Em làm bài kiểm tra kém hơn hẳn lúc luyện ở nhà'],
  ['LO_THI', 'Em sợ bị so sánh điểm với bạn'],

  ['GIAC_NGU', 'Em khó vào giấc dù đã lên giường'],
  ['GIAC_NGU', 'Em ngủ dưới bảy tiếng một đêm'],
  ['GIAC_NGU', 'Sáng dậy em vẫn thấy chưa đủ giấc'],
  ['GIAC_NGU', 'Em học hoặc dùng điện thoại tới sát giờ ngủ'],

  ['DONG_LUC', 'Em thấy học mãi mà không khá lên'],
  ['DONG_LUC', 'Em không rõ mình học để làm gì'],
  ['DONG_LUC', 'Em phải có người giục mới ngồi vào bàn'],
  ['DONG_LUC', 'Em thấy chán ngay cả với môn trước đây mình thích'],

  ['BAN_BE', 'Ở lớp em thấy mình lạc lõng'],
  ['BAN_BE', 'Em không có ai để hỏi bài khi bí'],
  ['BAN_BE', 'Giờ ra chơi em thường ở một mình dù không muốn thế'],
  ['BAN_BE', 'Em ngại rủ bạn học cùng'],

  ['AN_TOAN', 'Có bạn trêu chọc em theo cách làm em khó chịu'],
  ['AN_TOAN', 'Em thấy sợ khi đến một nơi nào đó ở trường'],
  ['AN_TOAN', 'Có người nói hoặc làm gì đó khiến em thấy bị hạ thấp'],
  ['AN_TOAN', 'Em thấy nếu có chuyện thì chẳng biết nói với ai'],
];

const MA_MIEN = Object.keys(MIEN);
/** Mỗi miền phải trả lời ít nhất bấy nhiêu câu mới chấm miền đó. */
const CAU_TOI_THIEU_MOI_MIEN = 3;

const KHONG_LAM = 'Bộ sàng lọc này KHÔNG hỏi về ý định tự hại. Việc đó cần người được đào tạo, có quy trình và có mặt thật — '
  + 'đặt câu hỏi ấy trong một bảng hỏi tự động là mở ra một câu trả lời mà không ai ở đó để đỡ. '
  + 'Nếu gia đình hoặc nhà trường lo về điều này, hãy liên hệ chuyên viên tâm lý học đường hoặc cơ sở y tế.';

function deBai() {
  return CAU.map(([mien, hoi], i) => ({
    so: i + 1, mien, tenMien: MIEN[mien].ten, hoi, thang: THANG.map((t) => ({ ...t })),
  }));
}

/**
 * Chấm.
 * @param {Array<{so:number, diem:number}>} traLoi
 * @returns kết quả KHÔNG bao giờ chứa tên bệnh, và luôn nói ai cần biết.
 */
function cham(traLoi = []) {
  const gom = {};
  for (const k of MA_MIEN) gom[k] = [];
  const loi = [];
  const da = new Set();

  for (const t of traLoi) {
    const so = Number(t.so);
    const c = CAU[so - 1];
    if (!c) { loi.push(`câu ${t.so} không có trong đề`); continue; }
    if (da.has(so)) { loi.push(`câu ${so} trả lời hai lần`); continue; }
    const d = Number(t.diem);
    if (!Number.isInteger(d) || d < 0 || d > 4) { loi.push(`câu ${so} có điểm ${t.diem} ngoài thang 0–4`); continue; }
    da.add(so);
    gom[c[0]].push(d);
  }

  const mien = MA_MIEN.map((k) => {
    const m = MIEN[k];
    const ds = gom[k];
    if (ds.length < CAU_TOI_THIEU_MOI_MIEN) {
      return {
        ma: k, ten: m.ten, duCanCu: false, soCau: ds.length,
        ghiChu: `Mới trả lời ${ds.length}/4 câu, cần ít nhất ${CAU_TOI_THIEU_MOI_MIEN} câu mới chấm miền này.`,
      };
    }
    const tb = ds.reduce((s, x) => s + x, 0) / ds.length;
    const muc = tb >= m.nguong[1] ? 'dang-chu-y' : tb >= m.nguong[0] ? 'nhe' : 'binh-thuong';
    return {
      ma: k, ten: m.ten, duCanCu: true, soCau: ds.length,
      diemTrungBinh: Math.round(tb * 100) / 100,
      muc,
      canNguoiNgay: m.canNguoiNgay && muc !== 'binh-thuong',
      khiCao: muc === 'binh-thuong' ? null : m.khiCao,
      lamGi: muc === 'binh-thuong' ? null : m.lamGi,
    };
  });

  const chamDuoc = mien.filter((x) => x.duCanCu);
  const dangChuY = chamDuoc.filter((x) => x.muc === 'dang-chu-y');
  const baoNgay = chamDuoc.filter((x) => x.canNguoiNgay);

  return {
    ok: true,
    soCauTraLoi: da.size, tongCau: CAU.length,
    mien,
    soMienChamDuoc: chamDuoc.length,
    // Ba trường dưới đây là phần người lớn đọc trước tiên.
    canNguoiLonNgay: baoNgay.length > 0,
    aiCanBiet: baoNgay.length ? ['phụ huynh', 'giáo viên chủ nhiệm', 'cố vấn'] : (dangChuY.length ? ['phụ huynh', 'cố vấn'] : []),
    ketLuan: baoNgay.length
      ? `Cần người lớn hỏi han NGAY về: ${baoNgay.map((x) => x.ten).join(', ')}. `
        + 'Đây là việc của người lớn, không phải việc em tự xoay.'
      : dangChuY.length
        ? `${dangChuY.length} miền ở mức đáng chú ý: ${dangChuY.map((x) => x.ten).join(', ')}. `
          + 'Nên có một người lớn ngồi xuống nói chuyện trong tuần này.'
        : chamDuoc.length
          ? 'Không miền nào ở mức đáng chú ý trong hai tuần vừa qua.'
          : 'Chưa đủ câu trả lời để chấm miền nào.',
    // Hai câu bắt buộc đi kèm mọi lần in kết quả.
    khongPhaiChanDoan: 'Đây là SÀNG LỌC, không phải chẩn đoán. Kết quả này không phải một cái tên bệnh, '
      + 'và không được dùng để xếp lớp hay so sánh giữa các em.',
    khongLam: KHONG_LAM,
    loi,
  };
}

module.exports = { THANG, MIEN, CAU, MA_MIEN, KHONG_LAM, deBai, cham };
