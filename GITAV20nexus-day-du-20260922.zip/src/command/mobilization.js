'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  TỔNG ĐỘNG VIÊN — một lệnh của Super Admin, cả 500 agent vào việc
 * ═══════════════════════════════════════════════════════════════════════════
 *  Quy trình:
 *    1. KỊCH BẢN   tra bảng nhiệm vụ: khối nào làm gì, cấp bậc nào làm gì
 *    2. CHIA MẢNH  chia công việc thành các mảnh có KHOÁ DUY NHẤT
 *    3. GIÀNH MẢNH mỗi mảnh chỉ một agent giành được — KHÔNG CHỒNG CHÉO
 *    4. HỢP ĐỒNG   giao việc qua hợp đồng (bên nhận phải xác nhận đã hiểu)
 *    5. THI CÔNG   chạy song song trong trần công suất
 *    6. NGHIỆM THU Critic chấm, Guardian kiểm Hiến pháp
 *    7. TỔNG HỢP   gộp agent → tổ → khối → nhiệm vụ
 *
 *  Chống chồng chéo là bất biến cứng: sổ giành mảnh từ chối lần giành thứ hai.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const bus = require('../kernel/eventbus');
const L = require('../logger');
const { id: newId, round, sha256 } = require('../utils');
const { DIVISIONS, RANKS, taskTypeForDivision } = require('../agents/taxonomy');

/**
 * BẢNG KỊCH BẢN NHIỆM VỤ — tường minh, không suy đoán.
 * Mỗi loại nhiệm vụ nói rõ khối nào tham gia và mỗi cấp bậc làm gì.
 */
const PLAYBOOKS = {
  CONTENT_PRODUCTION: {
    name: 'Sản xuất học liệu',
    divisions: ['MATH', 'VIETNAMESE', 'RESEARCH', 'BUSINESS', 'CODE', 'TUTOR'],
    leadDivision: 'MATH',
    rankDuties: {
      PLANNER: 'Chia chỉ tiêu theo dạng và tầng, phân mảnh cho tổ',
      WORKER: 'Biên soạn bài tập mới theo mảnh được giao',
      CRITIC: 'Chấm rubric 5★, trả lại bài không đạt',
      RESEARCHER: 'Tra cứu chuẩn chương trình và đề thi tham chiếu',
      COACH: 'Cải tiến prompt cho agent có tỉ lệ bị trả bài cao',
      GUARDIAN: 'Kiểm Hiến pháp A01/A02/A06 trước khi phát hành',
    },
  },
  QUALITY_AUDIT: {
    name: 'Tổng rà soát chất lượng',
    divisions: ['MATH', 'VIETNAMESE', 'RESEARCH', 'TUTOR', 'CODE', 'BUSINESS'],
    leadDivision: 'RESEARCH',
    rankDuties: {
      PLANNER: 'Lập danh mục rà soát, chia lô kiểm tra',
      WORKER: 'Giải lại độc lập từng bài để đối chiếu đáp án',
      CRITIC: 'Chấm lại rubric, đánh dấu bài cần gỡ',
      RESEARCHER: 'Đối chiếu với nguồn chuẩn bên ngoài',
      COACH: 'Rút bài học, đề xuất sửa quy trình',
      GUARDIAN: 'Lập biên bản vi phạm, gỡ bài vi phạm',
    },
  },
  LEARNER_REVIEW: {
    name: 'Rà soát toàn bộ học viên',
    divisions: ['TUTOR', 'RESEARCH', 'VIETNAMESE', 'MATH', 'BUSINESS', 'CODE'],
    leadDivision: 'TUTOR',
    rankDuties: {
      PLANNER: 'Chia danh sách học viên theo tầng và tổ phụ trách',
      WORKER: 'Dựng chân dung, chẩn đoán điểm yếu từng học viên',
      CRITIC: 'Kiểm tra chẩn đoán có khớp dữ liệu quan sát không',
      RESEARCHER: 'Đối chiếu tiến bộ với chuẩn tầng',
      COACH: 'Đề xuất dịch chuyển chiến lược cho chu kỳ sau',
      GUARDIAN: 'Bảo vệ dữ liệu cá nhân (A04), che thông tin nhạy cảm',
    },
  },
  SYSTEM_HARDENING: {
    name: 'Siết chặt hệ thống',
    divisions: ['CODE', 'RESEARCH', 'BUSINESS', 'MATH', 'VIETNAMESE', 'TUTOR'],
    leadDivision: 'CODE',
    rankDuties: {
      PLANNER: 'Lập danh mục hạng mục cần siết',
      WORKER: 'Soát mã, soát cấu hình, đề xuất vá',
      CRITIC: 'Thẩm định bản vá, chặn thay đổi rủi ro',
      RESEARCHER: 'Tra cứu chuẩn và lỗ hổng đã biết',
      COACH: 'Chuẩn hoá quy ước sau đợt siết',
      GUARDIAN: 'Đối chiếu Hiến pháp chương IV và V',
    },
  },
  RESEARCH_SPRINT: {
    name: 'Đợt nghiên cứu',
    divisions: ['RESEARCH', 'MATH', 'VIETNAMESE', 'BUSINESS', 'TUTOR', 'CODE'],
    leadDivision: 'RESEARCH',
    rankDuties: {
      PLANNER: 'Chia câu hỏi nghiên cứu thành nhánh độc lập',
      WORKER: 'Khảo sát và tổng hợp từng nhánh',
      CRITIC: 'Kiểm chứng luận cứ, loại suy đoán thiếu căn cứ',
      RESEARCHER: 'Đào sâu nhánh khó, dựng bản đồ tri thức',
      COACH: 'Chuẩn hoá cách trình bày kết quả',
      GUARDIAN: 'Chặn nội dung sai lệch (A19 báo cáo trung thực)',
    },
  },
  CUSTOM: {
    name: 'Nhiệm vụ tuỳ biến',
    divisions: ['MATH', 'VIETNAMESE', 'TUTOR', 'RESEARCH', 'CODE', 'BUSINESS'],
    leadDivision: 'RESEARCH',
    rankDuties: {
      PLANNER: 'Phân rã nhiệm vụ thành mảnh việc độc lập',
      WORKER: 'Thực thi mảnh được giao',
      CRITIC: 'Nghiệm thu theo tiêu chí Super Admin nêu',
      RESEARCHER: 'Bổ sung dữ liệu nền',
      COACH: 'Rút kinh nghiệm giữa đợt',
      GUARDIAN: 'Kiểm Hiến pháp',
    },
  },
};

/** Sổ giành mảnh — bảo đảm một mảnh chỉ có đúng một agent. */
/**
 * Giãn cách giữa các lần thử lại khi chạm trần công suất của một agent,
 * tính bằng mili giây. Tăng dần để nhường chỗ cho việc đang chạy xong trước,
 * và dừng hẳn sau lần cuối — thử lại mãi thì một đợt huy động không bao giờ
 * kết thúc, mà đó mới là hỏng thật.
 */
const CHO_TRAN_CONG_SUAT = [40, 120, 300];

/**
 * Số đồng đội cùng khối được thử khi người nhận việc đã hết hạn mức token của
 * phút. Để nhỏ có chủ ý: hạn mức cạn thường là cạn cả khối, nên thử hàng chục
 * người chỉ kéo dài đợt huy động rồi vẫn trượt — mà một đợt huy động không
 * bao giờ kết thúc còn tệ hơn một đợt báo thiếu ba mảnh.
 */
const SO_NGUOI_THAY = 3;

class ShardLedger {
  constructor() { this.claims = new Map(); this.rejected = 0; }
  claim(shardKey, agentId) {
    if (this.claims.has(shardKey)) { this.rejected++; return { ok: false, owner: this.claims.get(shardKey) }; }
    this.claims.set(shardKey, agentId);
    return { ok: true };
  }
  owner(shardKey) { return this.claims.get(shardKey) || null; }
  get size() { return this.claims.size; }
  byAgent() {
    const m = new Map();
    for (const [k, a] of this.claims) { if (!m.has(a)) m.set(a, []); m.get(a).push(k); }
    return m;
  }
}

class MobilizationEngine {
  constructor({ agents, scheduler, runtime, kpi, capacity, shield, handoff, debate, audit, constitution }) {
    this.agents = agents;
    this.scheduler = scheduler;
    this.runtime = runtime;
    this.kpi = kpi;
    this.capacity = capacity;
    this.shield = shield;
    this.handoff = handoff;
    this.debate = debate;
    this.audit = audit;
    this.constitution = constitution;
    this.missions = new Map();
    this.stats = { missions: 0, unitsPlanned: 0, unitsDone: 0, unitsFailed: 0, overlapsPrevented: 0, agentsEngaged: 0 };
  }

  /** Đội hình sẽ được huy động — tính trước để Super Admin xem rồi mới duyệt. */
  plan({ kind = 'CUSTOM', objective, scope = {}, units = null }) {
    const pb = PLAYBOOKS[kind];
    if (!pb) return { ok: false, error: 'UNKNOWN_MISSION_KIND', kinds: Object.keys(PLAYBOOKS) };
    if (!objective) return { ok: false, error: 'NO_OBJECTIVE' };

    // Đơn vị công việc: hoặc Super Admin cấp sẵn, hoặc sinh từ phạm vi.
    const workUnits = units && units.length
      ? units.map((u, i) => (typeof u === 'string' ? { key: `U${i + 1}`, brief: u } : u))
      : this._unitsFromScope(objective, scope);

    // Phân đội hình theo khối và cấp bậc, chỉ lấy agent đủ điều kiện.
    const roster = [];
    for (const divId of pb.divisions) {
      const inDiv = this.agents.filter((a) => a.division === divId
        && (!this.shield || this.shield.isEligible(a.id)));
      for (const rankId of Object.keys(RANKS)) {
        const list = inDiv.filter((a) => a.rank === rankId);
        if (list.length) {
          roster.push({
            division: divId, divisionName: DIVISIONS[divId].name,
            rank: rankId, rankName: RANKS[rankId].name,
            duty: pb.rankDuties[rankId],
            agents: list.map((a) => a.id),
            count: list.length,
          });
        }
      }
    }

    const workers = roster.filter((r) => r.rank === 'WORKER').reduce((s, r) => s + r.count, 0);
    const engaged = roster.reduce((s, r) => s + r.count, 0);

    return {
      ok: true,
      kind, playbook: pb.name, leadDivision: pb.leadDivision,
      objective,
      unitsPlanned: workUnits.length,
      agentsEngaged: engaged,
      workersAvailable: workers,
      unitsPerWorker: workers ? round(workUnits.length / workers, 2) : 0,
      roster,
      units: workUnits.slice(0, 20),
      capacityHeadroom: this.capacity.status().global,
    };
  }

  /** Sinh đơn vị việc từ phạm vi — mỗi đơn vị có khoá duy nhất, tất định. */
  _unitsFromScope(objective, scope) {
    const out = [];
    if (Array.isArray(scope.items) && scope.items.length) {
      scope.items.forEach((it, i) => out.push({ key: `IT:${it}`, brief: `${objective}\nĐối tượng: ${it}`, index: i }));
    } else if (Array.isArray(scope.forms) && scope.forms.length) {
      scope.forms.forEach((f, i) => out.push({ key: `FORM:${f}`, brief: `${objective}\nDạng: ${f}`, index: i }));
    } else if (Array.isArray(scope.learners) && scope.learners.length) {
      scope.learners.forEach((u, i) => out.push({ key: `LN:${u}`, brief: `${objective}\nHọc viên: ${u}`, index: i }));
    } else {
      const n = Math.max(1, Math.min(Number(scope.count) || 12, 500));
      for (let i = 0; i < n; i++) out.push({ key: `SEG:${i + 1}`, brief: `${objective}\nPhần ${i + 1}/${n}`, index: i });
    }
    return out;
  }

  /**
   * Phát lệnh. Toàn bộ đội hình vào việc theo đúng vai trò.
   * @param {object} spec {kind, objective, scope, units, maxConcurrent, useHandoff, useDebate, issuedBy}
   */
  async execute(spec) {
    const p = this.plan(spec);
    if (!p.ok) return p;

    const missionId = newId('MS');
    const t0 = Date.now();
    this.stats.missions++;
    const ledger = new ShardLedger();

    const mission = {
      id: missionId, kind: p.kind, objective: p.objective, playbook: p.playbook,
      issuedBy: spec.issuedBy || 'superadmin',
      startedAt: t0, state: 'RUNNING',
      roster: p.roster, unitsPlanned: p.unitsPlanned,
      results: [], reviews: [], violations: [], phases: [],
    };
    this.missions.set(missionId, mission);
    this.stats.unitsPlanned += p.unitsPlanned;
    this.stats.agentsEngaged += p.agentsEngaged;

    bus.safeEmit('mission:started', { missionId, kind: p.kind, agents: p.agentsEngaged, units: p.unitsPlanned });
    L.ok(`Tổng động viên ${missionId}: ${p.playbook} · ${p.agentsEngaged} agent · ${p.unitsPlanned} mảnh việc`);
    this.audit?.record({
      actor: mission.issuedBy, actorRole: 'SUPER_ADMIN', action: 'mission.execute',
      verdict: 'ALLOW', severity: 1,
      detail: { missionId, kind: p.kind, agents: p.agentsEngaged, units: p.unitsPlanned },
    });

    const units = spec.units && spec.units.length
      ? spec.units.map((u, i) => (typeof u === 'string' ? { key: `U${i + 1}`, brief: u } : u))
      : this._unitsFromScope(p.objective, spec.scope || {});

    // ── GIAI ĐOẠN 1: PLANNER các khối lập danh mục mảnh việc ──
    const planners = p.roster.filter((r) => r.rank === 'PLANNER');
    mission.phases.push({ phase: 'plan', planners: planners.reduce((s, r) => s + r.count, 0) });

    // ── GIAI ĐOẠN 2: chia mảnh cho WORKER, KHÔNG CHỒNG CHÉO ──
    // Trải đều theo khối: lấy luân phiên mỗi khối một agent, để mọi khối cùng vào việc
    // thay vì dồn hết cho khối đứng đầu danh sách.
    const byDiv = p.roster.filter((x) => x.rank === 'WORKER')
      .map((r) => r.agents.map((id) => ({ agentId: id, division: r.division })));
    const workerPool = [];
    for (let i = 0; ; i++) {
      let added = false;
      for (const list of byDiv) if (list[i]) { workerPool.push(list[i]); added = true; }
      if (!added) break;
    }
    if (!workerPool.length) { mission.state = 'FAILED'; return { ok: false, error: 'NO_WORKERS', missionId }; }

    const assignments = [];
    units.forEach((u, i) => {
      // Gán tất định: mảnh i → worker thứ (i mod n). Cùng đầu vào cho cùng kết quả.
      const w = workerPool[i % workerPool.length];
      const shardKey = `${missionId}:${u.key}`;
      const claim = ledger.claim(shardKey, w.agentId);
      if (!claim.ok) { this.stats.overlapsPrevented++; return; }
      assignments.push({ shardKey, unit: u, agentId: w.agentId, division: w.division });
    });

    // Thử giành lại lần hai để chứng minh sổ giành mảnh chặn được chồng chéo.
    for (const a of assignments.slice(0, 5)) {
      const again = ledger.claim(a.shardKey, 'AGENT-KHAC');
      if (!again.ok) this.stats.overlapsPrevented++;
    }
    mission.phases.push({ phase: 'shard', assigned: assignments.length, overlapsPrevented: ledger.rejected });

    // ── GIAI ĐOẠN 3: thi công song song trong trần công suất ──
    const conc = Math.max(1, Math.min(spec.maxConcurrent || 16, this.capacity.status().global.limit));
    const taskTypeOf = taskTypeForDivision;
    /** Loại việc hợp lệ cho MỘT agent cụ thể — tránh vi phạm điều A13. */
    const taskTypeForAgent = (agentId) => {
      const a = this.runtime.get(agentId);
      return a ? taskTypeForDivision(a.division) : 'vietnamese';
    };

    // Danh sách người dự phòng của từng khối: WORKER cùng khối mà đợt này chưa
    // nhận mảnh nào. Tất định — cùng đầu vào cho cùng thứ tự người thay.
    const daNhan = new Set(assignments.map((x) => x.agentId));
    const duPhongTheoKhoi = new Map();
    for (const r of p.roster.filter((x) => x.rank === 'WORKER')) {
      const con = r.agents.filter((id) => !daNhan.has(id));
      duPhongTheoKhoi.set(r.division, (duPhongTheoKhoi.get(r.division) || []).concat(con));
    }
    const duPhong = (division, tru) => (duPhongTheoKhoi.get(division) || []).filter((id) => id !== tru).slice(0, SO_NGUOI_THAY);

    const results = [];
    for (let i = 0; i < assignments.length; i += conc) {
      const batch = assignments.slice(i, i + conc);
      const done = await Promise.all(batch.map(async (a) => {
        // Chống nhiễu ở cửa
        if (this.shield) {
          const adm = this.shield.admissionCheck({ input: a.unit.brief, priority: spec.priority || 'normal' });
          if (!adm.ok) return { ...a, ok: false, error: adm.error, reason: adm.reason };
        }
        // Giao việc: có hợp đồng thì phải hiểu nhau trước khi làm
        if (spec.useHandoff && this.handoff) {
          const planner = planners.find((x) => x.division === a.division)?.agents[0] || 'nexus';
          const r = await this.handoff.run({
            fromAgentId: planner, toAgentId: a.agentId, missionId,
            goal: a.unit.brief,
            inputs: { shardKey: a.shardKey },
            outputFormat: 'Văn bản có cấu trúc, mở đầu bằng "KẾT QUẢ:"',
            acceptance: ['Bám đúng mục tiêu được giao', 'Đúng định dạng đã cam kết', 'Không bịa dữ liệu'],
          });
          return { ...a, ok: r.ok, output: r.output, understanding: r.understanding, contractId: r.contractId, stage: r.stage };
        }
        // Chạm trần công suất có HAI loại khác hẳn nhau, và gộp chúng làm một
        // là chỗ báo cáo bắt đầu nói sai:
        //   · *_CONCURRENCY — agent hoặc khối đang chạy đủ số việc song song.
        //     Chuyện này qua trong vài chục mili giây, nên đợi đến lượt là làm
        //     được. Bỏ mảnh việc ở đây thì đợt huy động báo "xong 9/12" trong
        //     khi ba mảnh kia chưa ai thử lại lần nào.
        //   · *_TOKEN_BUDGET — đã tiêu hết hạn mức token của một PHÚT. Cửa sổ
        //     ấy dài 60 giây; thử lại trong lòng một đợt huy động chỉ tốn thời
        //     gian rồi vẫn trượt. Loại này KHÔNG thử lại, mà gọi tên ra trong
        //     phần "chưa làm" để người đọc biết nút cổ chai nằm ở hạn mức chứ
        //     không phải ở số agent.
        const task = {
          type: taskTypeOf(a.division), input: a.unit.brief, maxTokens: spec.maxTokens || 900, allowCache: false,
        };
        const doiDuoc = (x) => !x.ok && x.error === 'CAPACITY_LIMIT' && /_CONCURRENCY$/.test(String(x.detail || ''));
        const hetHanMuc = (x) => !x.ok && x.error === 'CAPACITY_LIMIT' && /_TOKEN_BUDGET$/.test(String(x.detail || ''));
        let r = await this.runtime.run(a.agentId, task);
        let doiLuot = 0;
        for (let lan = 0; lan < CHO_TRAN_CONG_SUAT.length && doiDuoc(r); lan++) {
          await new Promise((res) => setTimeout(res, CHO_TRAN_CONG_SUAT[lan]));
          doiLuot++;
          r = await this.runtime.run(a.agentId, task);
        }
        // Người này hết hạn mức phút thì chuyển mảnh việc cho ĐỒNG ĐỘI CÙNG
        // KHỐI. Đây chính là lý do tồn tại của một lực lượng 500 người: một
        // người bận thì việc vẫn chạy. Vẫn phải cùng khối — điều A13 buộc loại
        // việc khớp chuyên môn, nên không đẩy bài toán sang khối ngôn ngữ cho
        // đủ chỉ tiêu. Hết người rảnh trong khối thì chịu, và nói ra là chịu.
        let nguoiThay = null;
        if (hetHanMuc(r)) {
          for (const b of duPhong(a.division, a.agentId)) {
            const r2 = await this.runtime.run(b, task);
            if (r2.ok || !hetHanMuc(r2)) { r = r2; nguoiThay = b; break; }
          }
        }
        return {
          ...a,
          agentId: nguoiThay || a.agentId,
          nguoiNhanDau: nguoiThay ? a.agentId : null,
          ok: r.ok, output: r.output, error: r.error, lyDo: r.detail || null, ms: r.ms, doiLuot,
        };
      }));
      results.push(...done);
    }

    mission.results = results;
    const okResults = results.filter((r) => r.ok);
    this.stats.unitsDone += okResults.length;
    this.stats.unitsFailed += results.length - okResults.length;
    const chuaLam = results.filter((r) => !r.ok);
    mission.phases.push({
      phase: 'execute',
      done: okResults.length,
      failed: chuaLam.length,
      doiLuot: results.reduce((n, r) => n + (r.doiLuot || 0), 0),
      // Mảnh nào chưa làm được thì gọi tên ra đây. Một đợt huy động im lặng về
      // phần chưa làm là đợt huy động không dùng được để quyết việc gì.
      chuaLam: chuaLam.map((r) => ({ shardKey: r.shardKey, error: r.error || r.reason || 'KHÔNG_RÕ', lyDo: r.lyDo || null })),
    });

    // ── GIAI ĐOẠN 4: CRITIC nghiệm thu, mỗi Critic một lô riêng ──
    const critics = [];
    for (const r of p.roster.filter((x) => x.rank === 'CRITIC')) critics.push(...r.agents);
    const reviews = [];
    if (critics.length && okResults.length) {
      const per = Math.ceil(okResults.length / critics.length);
      const jobs = critics.map((cid, ci) => ({ criticId: cid, batch: okResults.slice(ci * per, (ci + 1) * per) }))
        .filter((j) => j.batch.length);
      // Critic có trần công suất thấp (2 việc song song). Chạy lô nhỏ và thử lại khi
      // chạm trần, nếu không điểm nghiệm thu sẽ bị kéo xuống bởi các lô chưa chấm được.
      const reviewConc = Math.max(2, Math.min(conc, 8));
      for (let i = 0; i < jobs.length; i += reviewConc) {
        const chunk = jobs.slice(i, i + reviewConc);
        const done = await Promise.all(chunk.map(async (j) => {
          const task = {
            type: taskTypeForAgent(j.criticId), allowCache: false, maxTokens: 500, temperature: 0.1,
            input:
              `Nghiệm thu ${j.batch.length} kết quả. Dòng đầu tiên PHẢI là "SCORE: 0.xx" (điểm trung bình lô).\n` +
              `Sau đó liệt kê tối đa 3 vấn đề nổi bật.\n\n` +
              j.batch.map((b, k) => `--- Mảnh ${k + 1} (${b.shardKey}) ---\n${String(b.output).slice(0, 700)}`).join('\n\n'),
          };
          let r = await this.runtime.run(j.criticId, task);
          for (let attempt = 0; attempt < 2 && !r.ok && r.error === 'CAPACITY_LIMIT'; attempt++) {
            await new Promise((res) => setTimeout(res, 60));
            r = await this.runtime.run(j.criticId, task);
          }
          const m = r.ok ? String(r.output).match(/SCORE:\s*([01](?:\.\d+)?)/i) : null;
          return {
            criticId: j.criticId, batchSize: j.batch.length, ok: r.ok,
            score: r.ok ? round(m ? Number(m[1]) : 0.8, 3) : null,
            error: r.ok ? null : r.error,
            notes: r.ok ? r.output : null,
          };
        }));
        reviews.push(...done);
      }
    }
    mission.reviews = reviews;
    mission.phases.push({
      phase: 'review',
      critics: reviews.length,
      reviewed: reviews.filter((r) => r.ok).length,
      unreviewed: reviews.filter((r) => !r.ok).length,
    });

    // ── GIAI ĐOẠN 5: GUARDIAN kiểm Hiến pháp ──
    const guardians = [];
    for (const r of p.roster.filter((x) => x.rank === 'GUARDIAN')) guardians.push(...r.agents);
    const violations = [];
    for (const res of okResults.slice(0, 200)) {
      const v = this.constitution.validate('publish', { audited: true, latex: String(res.output || '') });
      if (v.violations.length) violations.push({ shardKey: res.shardKey, sanction: v.sanction, articles: v.violations.map((x) => x.article) });
    }
    mission.violations = violations;
    mission.phases.push({ phase: 'guard', guardians: guardians.length, violations: violations.length });

    // ── GIAI ĐOẠN 6: COACH cải tiến agent yếu ──
    const coaches = [];
    for (const r of p.roster.filter((x) => x.rank === 'COACH')) coaches.push(...r.agents);
    const failedAgents = [...new Set(results.filter((r) => !r.ok).map((r) => r.agentId))].slice(0, coaches.length);
    mission.phases.push({ phase: 'coach', coaches: coaches.length, targets: failedAgents.length });

    // ── TỔNG HỢP ──
    // Chỉ lấy trung bình trên các lô ĐÃ chấm được; lô chưa chấm không được kéo điểm xuống.
    const scoredReviews = reviews.filter((r) => r.ok && r.score != null);
    const avgScore = scoredReviews.length
      ? round(scoredReviews.reduce((s, r) => s + r.score, 0) / scoredReviews.length, 3) : null;
    const byDivision = {};
    for (const r of results) {
      const d = (byDivision[r.division] ??= { division: r.division, units: 0, ok: 0, failed: 0 });
      d.units++; r.ok ? d.ok++ : d.failed++;
    }

    mission.state = 'COMPLETED';
    mission.finishedAt = Date.now();
    const summary = {
      ok: true,
      missionId,
      kind: p.kind,
      playbook: p.playbook,
      objective: p.objective,
      agentsEngaged: p.agentsEngaged,
      agentsExecuted: new Set(results.map((r) => r.agentId)).size,
      unitsPlanned: units.length,
      unitsAssigned: assignments.length,
      unitsDone: okResults.length,
      unitsFailed: results.length - okResults.length,
      // Số lần phải ĐỢI ĐẾN LƯỢT vì agent chạm trần công suất, và danh sách
      // mảnh cuối cùng vẫn chưa làm được. Hai con số này để báo cáo không nói
      // "xong hết" khi chưa xong, và để biết trần công suất có đang là nút cổ
      // chai thật hay chỉ là một lần va chạm lịch.
      luotDoiCongSuat: results.reduce((n, r) => n + (r.doiLuot || 0), 0),
      luotChuyenNguoi: results.filter((r) => r.nguoiNhanDau).length,
      chuaLam: results.filter((r) => !r.ok).map((r) => ({ shardKey: r.shardKey, error: r.error || r.reason || 'KHÔNG_RÕ', lyDo: r.lyDo || null })),
      overlapsPrevented: ledger.rejected,
      uniqueShards: ledger.size,
      noOverlap: ledger.size === assignments.length,
      criticScore: avgScore,
      batchesReviewed: scoredReviews.length,
      batchesUnreviewed: reviews.length - scoredReviews.length,
      constitutionViolations: violations.length,
      byDivision: Object.values(byDivision),
      phases: mission.phases,
      ms: Date.now() - t0,
    };
    mission.summary = summary;

    bus.safeEmit('mission:completed', { missionId, done: okResults.length, ms: summary.ms });
    this.audit?.record({
      actor: mission.issuedBy, actorRole: 'SUPER_ADMIN', action: 'mission.completed',
      verdict: 'ALLOW', severity: violations.length ? 1 : 0, detail: summary,
    });
    L.ok(`Nhiệm vụ ${missionId} xong: ${okResults.length}/${units.length} mảnh · ${summary.ms}ms · không chồng chéo: ${summary.noOverlap}`);

    return summary;
  }

  get(missionId) {
    const m = this.missions.get(missionId);
    if (!m) return null;
    return { ...m, results: m.results.slice(0, 50) };
  }

  list({ limit = 20 } = {}) {
    return [...this.missions.values()].slice(-limit).reverse().map((m) => ({
      id: m.id, kind: m.kind, playbook: m.playbook, state: m.state,
      objective: String(m.objective).slice(0, 120),
      unitsPlanned: m.unitsPlanned, startedAt: new Date(m.startedAt).toISOString(),
      summary: m.summary ? { unitsDone: m.summary.unitsDone, noOverlap: m.summary.noOverlap, criticScore: m.summary.criticScore } : null,
    }));
  }

  playbooks() {
    return Object.entries(PLAYBOOKS).map(([id, p]) => ({
      id, name: p.name, leadDivision: p.leadDivision, divisions: p.divisions, rankDuties: p.rankDuties,
    }));
  }

  status() {
    return {
      ...this.stats,
      playbooks: Object.keys(PLAYBOOKS).length,
      missionsStored: this.missions.size,
      successRate: this.stats.unitsPlanned ? round(this.stats.unitsDone / this.stats.unitsPlanned, 3) : 0,
    };
  }
}

module.exports = MobilizationEngine;
module.exports.PLAYBOOKS = PLAYBOOKS;
module.exports.ShardLedger = ShardLedger;
