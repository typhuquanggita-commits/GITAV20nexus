'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  CHẤT VẤN CHÉO — "500 Agent được chất vấn nhau để tạo phiên bản hoàn hảo nhất"
 * ═══════════════════════════════════════════════════════════════════════════
 *  Một vòng gồm 4 bước:
 *    1. ĐỀ XUẤT   mỗi agent đưa một phương án độc lập
 *    2. CHẤT VẤN  vòng tròn: A chất vấn B, B chất vấn C, … KHÔNG ai tự chất vấn mình
 *    3. PHẢN BIỆN tác giả trả lời từng chất vấn: CHẤP NHẬN / BÁC BỎ + lý do
 *    4. TỔNG HỢP  gộp phần đã được bảo vệ + phần đã sửa → phiên bản mới
 *
 *  Lặp tới khi HỘI TỤ (không còn chất vấn nào được chấp nhận) hoặc hết số vòng.
 *  Critic chấm phiên bản cuối theo rubric 5★; dưới chuẩn thì trả về, không phát hành.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const bus = require('../kernel/eventbus');
const { id: newId, round } = require('../utils');
const quality = require('../content/quality');

const MAX_ROUNDS = 3;
const MIN_PARTICIPANTS = 2;

class DebateEngine {
  constructor({ runtime, scheduler, audit }) {
    this.runtime = runtime;
    this.scheduler = scheduler;
    this.audit = audit;
    this.debates = new Map();
    this.stats = { debates: 0, rounds: 0, challenges: 0, accepted: 0, rejected: 0, converged: 0 };
  }

  /**
   * @param {object} spec
   *   topic        yêu cầu cần giải quyết
   *   taskType     loại việc (quyết định khối phụ trách)
   *   participants số agent tham gia (mặc định 3)
   *   rounds       số vòng tối đa
   */
  async run(spec) {
    const { topic, taskType = 'vietnamese', participants = 3, rounds = MAX_ROUNDS } = spec;
    if (!topic) return { ok: false, error: 'NO_TOPIC' };

    const debateId = newId('DB');
    const t0 = Date.now();
    this.stats.debates++;

    // ── Chọn người tham gia: khác nhau, cùng khối chuyên môn ──
    const chosen = [];
    for (let i = 0; i < participants; i++) {
      const a = this.scheduler.select(taskType, { rank: 'WORKER', exclude: chosen });
      if (!a) break;
      chosen.push(a.id);
    }
    if (chosen.length < MIN_PARTICIPANTS) {
      return { ok: false, error: 'NOT_ENOUGH_AGENTS', have: chosen.length, need: MIN_PARTICIPANTS };
    }

    const log = [];
    let versions = null;

    // ── BƯỚC 1: đề xuất độc lập ──
    const proposals = await Promise.all(chosen.map(async (id) => {
      const r = await this.runtime.run(id, {
        type: taskType, allowCache: false, maxTokens: 1000, temperature: 0.6,
        input: `Đưa phương án của bạn cho yêu cầu sau. Trình bày ngắn gọn, có lập luận, dùng LaTeX cho công thức.\n\nYÊU CẦU:\n${topic}`,
      });
      return { agentId: id, ok: r.ok, text: r.ok ? r.output : null };
    }));
    versions = proposals.filter((p) => p.ok);
    if (!versions.length) return { ok: false, error: 'ALL_PROPOSALS_FAILED', debateId };
    log.push({ round: 0, phase: 'propose', agents: versions.map((v) => v.agentId) });

    let converged = false;
    let roundNo = 0;
    let roundsRun = 0;

    for (roundNo = 1; roundNo <= rounds && versions.length > 1 && !converged; roundNo++) {
      roundsRun++;
      this.stats.rounds++;

      // ── BƯỚC 2: chất vấn vòng tròn, không ai tự chất vấn mình ──
      const challenges = await Promise.all(versions.map(async (v, i) => {
        const target = versions[(i + 1) % versions.length];
        if (target.agentId === v.agentId) return null;
        this.stats.challenges++;
        const r = await this.runtime.run(v.agentId, {
          type: taskType, allowCache: false, maxTokens: 600, temperature: 0.3,
          input:
            `Chất vấn phương án của đồng nghiệp. Chỉ nêu điểm CÓ THỂ SAI hoặc THIẾU, tối đa 3 điểm.\n` +
            `Mỗi dòng một điểm, định dạng "CHẤT VẤN: <nội dung>". Không khen, không diễn giải thừa.\n\n` +
            `YÊU CẦU GỐC:\n${topic}\n\nPHƯƠNG ÁN BỊ CHẤT VẤN:\n${String(target.text).slice(0, 2500)}`,
        });
        if (!r.ok) return null;
        const points = [...String(r.output).matchAll(/CHẤT VẤN\s*:\s*(.+)/gi)].map((m) => m[1].trim());
        return { by: v.agentId, against: target.agentId, points };
      }));
      const validChallenges = challenges.filter((c) => c && c.points.length);
      log.push({ round: roundNo, phase: 'challenge', count: validChallenges.reduce((s, c) => s + c.points.length, 0) });

      if (!validChallenges.length) { converged = true; break; }

      // ── BƯỚC 3: tác giả phản biện từng điểm ──
      const rebuttals = await Promise.all(validChallenges.map(async (c) => {
        const author = versions.find((v) => v.agentId === c.against);
        if (!author) return null;
        const r = await this.runtime.run(author.agentId, {
          type: taskType, allowCache: false, maxTokens: 800, temperature: 0.3,
          input:
            `Phương án của bạn bị chất vấn. Trả lời TỪNG điểm, mỗi dòng một điểm:\n` +
            `"n: CHẤP NHẬN — <sửa thế nào>" nếu chất vấn đúng\n` +
            `"n: BÁC BỎ — <lý do>" nếu chất vấn sai\n\n` +
            `PHƯƠNG ÁN CỦA BẠN:\n${String(author.text).slice(0, 2000)}\n\n` +
            `CÁC CHẤT VẤN:\n${c.points.map((p, i) => `${i + 1}. ${p}`).join('\n')}`,
        });
        if (!r.ok) return null;
        const accepted = [], rejected = [];
        c.points.forEach((p, i) => {
          const m = String(r.output).match(new RegExp(`^\\s*${i + 1}\\s*:\\s*(CHẤP NHẬN|BÁC BỎ)\\s*[—-]?\\s*(.*)$`, 'im'));
          if (m && /CHẤP NHẬN/i.test(m[1])) accepted.push({ point: p, fix: m[2] });
          else rejected.push({ point: p, reason: m?.[2] || 'giữ nguyên' });
        });
        this.stats.accepted += accepted.length;
        this.stats.rejected += rejected.length;
        return { agentId: author.agentId, accepted, rejected };
      }));
      const validRebuttals = rebuttals.filter(Boolean);
      const totalAccepted = validRebuttals.reduce((s, r) => s + r.accepted.length, 0);
      log.push({ round: roundNo, phase: 'rebut', accepted: totalAccepted, rejected: validRebuttals.reduce((s, r) => s + r.rejected.length, 0) });

      // Không chất vấn nào được chấp nhận → đã hội tụ
      if (totalAccepted === 0) { converged = true; break; }

      // ── BƯỚC 4: tác giả sửa lại phương án theo phần đã chấp nhận ──
      versions = await Promise.all(versions.map(async (v) => {
        const reb = validRebuttals.find((r) => r.agentId === v.agentId);
        if (!reb || !reb.accepted.length) return v;
        const r = await this.runtime.run(v.agentId, {
          type: taskType, allowCache: false, maxTokens: 1200, temperature: 0.3,
          input:
            `Sửa lại phương án của bạn theo các điểm bạn đã CHẤP NHẬN. Giữ nguyên phần bạn đã bảo vệ được.\n` +
            `Trả về TOÀN VĂN phương án sau khi sửa, không giải thích quá trình.\n\n` +
            `PHƯƠNG ÁN CŨ:\n${String(v.text).slice(0, 2500)}\n\n` +
            `CÁC ĐIỂM PHẢI SỬA:\n${reb.accepted.map((a, i) => `${i + 1}. ${a.point} → ${a.fix}`).join('\n')}`,
        });
        return r.ok ? { ...v, text: r.output, revised: (v.revised || 0) + 1 } : v;
      }));
      log.push({ round: roundNo, phase: 'revise', revised: versions.filter((v) => v.revised).length });
    }

    if (converged) this.stats.converged++;

    // ── TỔNG HỢP: một Planner gộp các phương án đã qua chất vấn ──
    const planner = this.scheduler.select(taskType, { rank: 'PLANNER' });
    let final = versions[0].text;
    if (planner && versions.length > 1) {
      const r = await this.runtime.run(planner.id, {
        type: taskType, allowCache: false, maxTokens: 1600, temperature: 0.2,
        input:
          `Tổng hợp ${versions.length} phương án đã qua chất vấn thành MỘT phiên bản tốt nhất.\n` +
          `Giữ lập luận đã được bảo vệ, loại phần đã bị bác bỏ. Không nhắc tới quá trình tranh luận.\n\n` +
          `YÊU CẦU GỐC:\n${topic}\n\n` +
          versions.map((v, i) => `### Phương án ${i + 1} (${v.agentId})\n${String(v.text).slice(0, 2000)}`).join('\n\n'),
      });
      if (r.ok) final = r.output;
    }

    // ── NGHIỆM THU: Critic chấm rubric 5★ ──
    const critic = this.scheduler.select(taskType, { rank: 'CRITIC', exclude: chosen });
    let scored = null;
    if (critic) {
      const r = await this.runtime.run(critic.id, {
        type: taskType, allowCache: false, maxTokens: 600, temperature: 0.1,
        input:
          `Chấm phiên bản cuối theo rubric. Mỗi dòng một chiều, định dạng "tên: số".\n\n` +
          `RUBRIC:\n${quality.rubricPrompt()}\n\nPHIÊN BẢN:\n${String(final).slice(0, 3500)}`,
      });
      if (r.ok) {
        const cs = {};
        for (const k of quality.DIM_KEYS) {
          const m = String(r.output).match(new RegExp(`${k}\\s*:\\s*([1-5])`, 'i'));
          if (m) cs[k] = Number(m[1]);
        }
        scored = quality.score({ stem: final, solutionSteps: String(final).split('\n').filter(Boolean), hints: [], traps: [], stars: 3 }, cs);
      }
    }

    const result = {
      ok: true,
      debateId,
      topic,
      taskType,
      participants: chosen,
      rounds: roundsRun,
      converged,
      revisions: versions.reduce((s, v) => s + (v.revised || 0), 0),
      challengesRaised: this.stats.challenges,
      finalVersion: final,
      quality: scored,
      criticId: critic?.id || null,
      plannerId: planner?.id || null,
      log,
      ms: Date.now() - t0,
    };
    this.debates.set(debateId, result);
    bus.safeEmit('debate:finished', { debateId, converged, rounds: result.rounds });
    this.audit?.record({
      actor: 'nexus', action: 'debate.run', verdict: 'ALLOW', severity: 0,
      detail: { debateId, participants: chosen.length, rounds: result.rounds, converged },
    });
    return result;
  }

  get(debateId) { return this.debates.get(debateId) || null; }

  status() {
    return {
      ...this.stats,
      stored: this.debates.size,
      maxRounds: MAX_ROUNDS,
      convergenceRate: this.stats.debates ? round(this.stats.converged / this.stats.debates, 3) : 0,
      challengeAcceptRate: (this.stats.accepted + this.stats.rejected)
        ? round(this.stats.accepted / (this.stats.accepted + this.stats.rejected), 3) : 0,
    };
  }
}

module.exports = DebateEngine;
module.exports.MAX_ROUNDS = MAX_ROUNDS;
