'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  TỔ TRƯỞNG — ghép nhiều trợ lý vào một lượt qua BẢNG CHUNG
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Một trợ lý trả lời một mình thì nhanh và rẻ. Nhưng có những câu hỏi mà
 *  người biết rõ nhất lại không phải người trả lời: hỏi công nợ thì chuyên
 *  viên công nợ biết từng khoản, còn trưởng ban học phí biết gia đình nào
 *  đang khó — thiếu vế sau thì lời nhắc gửi đi đúng số mà sai người.
 *
 *  BA KIỂU GHÉP, chọn theo số người chứ không theo ý thích:
 *
 *      mot-nguoi     một trợ lý. Mặc định.
 *      co-nguoi-phu  một người phụ chạy trước, đặt ngữ cảnh lên bảng chung,
 *                    rồi người chính trả lời khi đã có ngữ cảnh ấy.
 *      phan-bien     hai người phụ, mỗi người một góc, rồi người chính gộp.
 *
 *  TRẦN BA NGƯỜI. Bốn người trở lên thì thời gian nhân lên mà ý mới không
 *  thêm bao nhiêu — và mỗi người là một lượt gọi mô hình có thật.
 *
 *  BẢNG CHUNG LÀ CHỖ DUY NHẤT HỌ NÓI VỚI NHAU. Không có trợ lý nào gọi thẳng
 *  trợ lý nào. Ai viết gì lên bảng thì ký tên ở đó, nên đọc lại là biết ý nào
 *  từ đâu ra — điều không làm được nếu để họ gọi chéo nhau tự do.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const TRAN_NGUOI = 3;

class ToTruong {
  /**
   * @param {object} o
   * @param {object} o.llm       LLMRouter
   * @param {object} o.congCu    KhoCongCu
   * @param {object} o.hopTac    HopTac — để trợ lý xin lực lượng 500 giúp
   */
  constructor({ llm = null, congCu = null, hopTac = null } = {}) {
    this.llm = llm;
    this.congCu = congCu;
    this.hopTac = hopTac;
  }

  _kieuGhep(soNguoi) {
    if (soNguoi <= 1) return 'mot-nguoi';
    if (soNguoi === 2) return 'co-nguoi-phu';
    return 'phan-bien';
  }

  /**
   * Chạy một trợ lý.
   *
   * Trình tự: đọc dữ liệu bằng công cụ TRƯỚC, rồi mới hỏi mô hình. Làm ngược
   * lại — hỏi mô hình rồi để nó tự quyết gọi công cụ nào — là cách bản thiết
   * kế gốc làm, và nó mở đường cho mô hình bịa ra một câu trả lời trước khi
   * nhìn thấy số. Ở đây số có trước, lời có sau.
   */
  async chayMotTroLy(troLy, { cauHoi, boiCanh, mucThat, bangChung }) {
    const t0 = Date.now();
    const daGoi = [];
    const soLieu = {};

    // 1) Đọc dữ liệu bằng mọi công cụ trong tầm mức được phép.
    for (const ten of troLy.congCu) {
      const muc = this.congCu.mucCua(ten);
      if (muc > mucThat) {
        daGoi.push({ ten, chay: false, lyDo: `cần mức ${muc}, lượt này chỉ có mức ${mucThat}` });
        continue;
      }
      if (muc > 1) continue;   // chỉ TỰ ĐỘNG gọi công cụ chỉ đọc
      const r = await this.congCu.goi(ten, this._thamSoTuBoiCanh(ten, boiCanh), boiCanh);
      daGoi.push({ ten, chay: r.ok, muc });
      if (r.ok) soLieu[ten] = r.ketQua;
    }

    // 2) Hỏi mô hình, kèm số liệu đã đọc.
    const heThong = this._loiDan(troLy, mucThat);
    const nhacViec = this._dungLoiNhac(cauHoi, soLieu, bangChung);
    let traLoi = null;
    let moHinh = null;
    if (this.llm) {
      const r = await this.llm.call({
        task: 'business_analysis',
        system: heThong,
        prompt: nhacViec,
        temperature: 0.2,
        maxTokens: 900,
      });
      if (r.ok) { traLoi = r.text; moHinh = r.provider; }
      else traLoi = `Không hỏi được mô hình ngôn ngữ (${r.error}). Số liệu đã đọc vẫn ở dưới.`;
    } else {
      traLoi = 'Chưa nối mô hình ngôn ngữ. Đây là số liệu thô đã đọc được.';
    }

    return {
      troLyMa: troLy.ma, troLyTen: troLy.ten, cap: troLy.cap,
      traLoi, soLieu, congCuDaGoi: daGoi, moHinh,
      ms: Date.now() - t0,
    };
  }

  /** Rút tham số cho công cụ từ bối cảnh. Không đoán — không có thì để trống. */
  _thamSoTuBoiCanh(ten, bc) {
    const t = {};
    if (bc.giaDinhId) t.giaDinhId = bc.giaDinhId;
    if (bc.hocVienId) t.hocVienId = bc.hocVienId;
    if (ten === 'doc_tinh_huong' && bc.tuKhoa) t.tuKhoa = bc.tuKhoa;
    return t;
  }

  _loiDan(troLy, mucThat) {
    return [
      `Bạn là ${troLy.ten}, trợ lý AI chuyên môn cấp ${troLy.cap} của ban quản trị quan hệ gia đình GITAmath.`,
      '',
      `Việc của bạn: ${troLy.moTa}`,
      `Khung nghiệp vụ bạn theo: ${troLy.khungNghiepVu.join(' · ')}`,
      `Mức được phép trong lượt này: ${mucThat} trên 4.`,
      '',
      'Luật bắt buộc:',
      '1. Chỉ nói những con số có trong phần SỐ LIỆU dưới đây. Không có thì nói là chưa có.',
      '2. Không bao giờ nêu tên riêng hay câu trả lời khảo sát của một em nhỏ.',
      '3. Không hứa kết quả học tập theo mốc thời gian.',
      '4. Viết tiếng Việt có dấu, không viết tắt, không dùng giọng máy.',
      '5. Trả lời ngắn: kết luận trước, căn cứ sau, rồi việc nên làm tiếp.',
    ].join('\n');
  }

  _dungLoiNhac(cauHoi, soLieu, bangChung) {
    const phan = [];
    if (bangChung && Object.keys(bangChung).length) {
      phan.push('## Đồng nghiệp đã ghi lên bảng chung');
      for (const [ma, y] of Object.entries(bangChung)) {
        phan.push(`- ${ma}: ${String(y).slice(0, 600)}`);
      }
      phan.push('');
    }
    phan.push('## SỐ LIỆU đọc được từ hệ thống');
    if (!Object.keys(soLieu).length) {
      phan.push('(không đọc được số liệu nào — hãy nói thẳng điều đó thay vì ước lượng)');
    } else {
      for (const [ten, kq] of Object.entries(soLieu)) {
        phan.push(`### ${ten}`);
        phan.push(JSON.stringify(kq, null, 0).slice(0, 1500));
      }
    }
    phan.push('');
    phan.push(`## CÂU HỎI\n${cauHoi}`);
    return phan.join('\n');
  }

  /**
   * Chạy cả tổ.
   * @returns {{traLoiCuoi:string, cacLuot:object[], kieuGhep:string, ms:number}}
   */
  async chayTo({ troLyChinh, troLyPhu = [], cauHoi, boiCanh = {}, mucThat = 1 }) {
    const t0 = Date.now();
    const phu = troLyPhu.slice(0, TRAN_NGUOI - 1);
    const kieuGhep = this._kieuGhep(1 + phu.length);
    const bangChung = {};
    const cacLuot = [];

    // Người phụ chạy trước, ghi lên bảng chung.
    for (const p of phu) {
      const r = await this.chayMotTroLy(p, {
        cauHoi: `Bạn đứng phụ cho lượt này. Hãy bổ sung ĐÚNG GÓC CỦA BẠN cho câu hỏi sau, ngắn gọn, đừng trả lời thay người chính.\n\n${cauHoi}`,
        boiCanh, mucThat, bangChung: {},
      });
      cacLuot.push({ ...r, vai: 'phu' });
      bangChung[p.ten] = r.traLoi;
    }

    // Người chính chạy sau, đã có bảng chung.
    const chinh = await this.chayMotTroLy(troLyChinh, { cauHoi, boiCanh, mucThat, bangChung });
    cacLuot.push({ ...chinh, vai: 'chinh' });

    // Gộp. Một người thì không có gì để gộp.
    let traLoiCuoi = chinh.traLoi;
    if (phu.length) traLoiCuoi = await this._gop(cauHoi, chinh, cacLuot.filter((x) => x.vai === 'phu'));

    return {
      traLoiCuoi,
      cacLuot,
      kieuGhep,
      chuoiTroLy: cacLuot.map((x) => x.troLyMa),
      congCuGoi: [...new Set(cacLuot.flatMap((x) => x.congCuDaGoi.filter((c) => c.chay).map((c) => c.ten)))],
      moHinh: chinh.moHinh,
      ms: Date.now() - t0,
    };
  }

  /**
   * Gộp lời người chính với góc nhìn người phụ.
   *
   * Gộp hỏng thì KHÔNG mất bài: trả về lời người chính cộng phần bổ sung ghép
   * thẳng. Một lần gọi mô hình hỏng không được phép xoá công của cả tổ.
   */
  async _gop(cauHoi, chinh, phu) {
    const boSung = phu.map((p) => `**Từ ${p.troLyTen}:**\n${String(p.traLoi).slice(0, 700)}`).join('\n\n');
    if (!this.llm) return `${chinh.traLoi}\n\n---\n**Góc nhìn bổ sung**\n\n${boSung}`;
    const r = await this.llm.call({
      task: 'content_editing',
      system: 'Bạn gộp nhiều ý kiến thành một câu trả lời liền mạch. Giữ nguyên mọi con số. '
        + 'Không thêm số mới. Viết tiếng Việt có dấu, không viết tắt.',
      prompt: `Câu hỏi: ${cauHoi}\n\n## Phân tích chính (${chinh.troLyTen})\n${chinh.traLoi}\n\n`
        + `## Góc nhìn bổ sung\n${boSung}\n\n`
        + 'Gộp thành một câu trả lời hoàn chỉnh. Nếu góc bổ sung có ý quan trọng thì thêm một mục riêng cuối bài.',
      temperature: 0.2,
      maxTokens: 1200,
    });
    if (!r.ok || !r.text) return `${chinh.traLoi}\n\n---\n**Góc nhìn bổ sung**\n\n${boSung}`;
    return r.text;
  }
}

module.exports = ToTruong;
module.exports.TRAN_NGUOI = TRAN_NGUOI;
