'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  HÀNG CHỜ DUYỆT — chỗ việc dừng lại để một người thật gật đầu
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Bản thiết kế gốc để "cần phê duyệt" là một dòng chữ trong câu trả lời.
 *  Dòng chữ ấy không chờ ai, không ai duyệt được, và việc thì trôi qua. Ở đây
 *  nó là một bản ghi có thật, sống qua lần khởi động lại, có người duyệt tên
 *  gì, duyệt lúc nào, và vì sao.
 *
 *  BỐN TRẠNG THÁI, và chỉ đi một chiều:
 *      cho  →  dong-y | tu-choi | het-han
 *  Đã quyết rồi thì không quyết lại. Muốn đổi thì mở một việc mới — vì lịch
 *  sử duyệt là thứ người ta sẽ đọc lại khi có chuyện, và một bản ghi bị sửa
 *  đè thì không đọc lại được nữa.
 *
 *  HẾT HẠN KHÔNG PHẢI LÀ ĐỒNG Ý. Việc chờ quá lâu thì đóng lại ở trạng thái
 *  het-han. Im lặng không bao giờ được diễn giải thành cho phép — đó là chỗ
 *  nhiều hệ thống duyệt tự động trượt dài thành không duyệt gì cả.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { id: newId } = require('../utils');

const TRANG_THAI = ['cho', 'dong-y', 'tu-choi', 'het-han'];
const HAN_MAC_DINH_MS = 72 * 3600_000;   // ba ngày

class ChoDuyet {
  /**
   * @param {object} o
   * @param {object} o.repo    bộ sưu tập crm-duyet
   * @param {object} o.nhatKy  AuditChain
   * @param {number} o.hanMs   bao lâu thì hết hạn
   * @param {function} o.bayGio
   */
  constructor({ repo, nhatKy = null, hanMs = HAN_MAC_DINH_MS, bayGio = () => Date.now() } = {}) {
    if (!repo) throw new Error('ChoDuyet cần một bộ sưu tập');
    this.repo = repo;
    this.nhatKy = nhatKy;
    this.hanMs = hanMs;
    this.bayGio = bayGio;
  }

  /**
   * Xin duyệt một việc.
   * @param {object} o
   * @param {string} o.phienId
   * @param {string} o.troLyMa      trợ lý nào xin
   * @param {string} o.troLyTen
   * @param {string} o.viec         một câu: xin làm gì
   * @param {object[]} o.deXuat     các việc cụ thể sẽ chạy nếu được đồng ý
   * @param {number} o.diemRuiRo
   * @param {string} o.lyDo         vì sao phải hỏi người
   */
  xin({ phienId, troLyMa, troLyTen = null, viec, deXuat = [], diemRuiRo = 0, lyDo = null, giaDinhId = null } = {}) {
    if (!viec || String(viec).trim().length < 5) {
      return { ok: false, loi: 'THIEU_VIEC', lyDo: 'Phải nói rõ xin duyệt việc gì.' };
    }
    if (!Array.isArray(deXuat) || deXuat.length === 0) {
      return {
        ok: false, loi: 'THIEU_DE_XUAT',
        lyDo: 'Xin duyệt mà không kèm việc cụ thể thì người duyệt đang gật đầu với một khoảng trống.',
      };
    }
    const luc = this.bayGio();
    const d = {
      id: newId('DUYET'),
      phienId: phienId || null,
      troLyMa: troLyMa || null,
      troLyTen: troLyTen || null,
      giaDinhId: giaDinhId || null,
      viec: String(viec).slice(0, 1000),
      deXuat: deXuat.slice(0, 20),
      diemRuiRo: Number(diemRuiRo) || 0,
      lyDo: lyDo || null,
      trangThai: 'cho',
      xinLuc: luc,
      hetHanLuc: luc + this.hanMs,
      nguoiQuyet: null, quyetLuc: null, ghiChuQuyet: null,
    };
    this.repo.put(d);
    this._vet('crm.duyet.xin', d.id, { troLyMa, diemRuiRo: d.diemRuiRo, soDeXuat: d.deXuat.length });
    return { ok: true, viecCho: d };
  }

  /**
   * Quyết một việc đang chờ.
   *
   * Ghi tên người quyết là BẮT BUỘC. Một chữ ký "he-thong" trên một việc chạm
   * tới gia đình thì không phải chữ ký, và nhật ký kiểm toán sau này chỉ
   * đọc được một khoảng trống.
   */
  quyet(id, { trangThai, nguoiQuyet, ghiChu = null } = {}) {
    const d = this.repo.get(id);
    if (!d) return { ok: false, loi: 'KHONG_CO_VIEC' };
    if (d.trangThai !== 'cho') {
      return {
        ok: false, loi: 'DA_QUYET_ROI',
        lyDo: `Việc này đã ở trạng thái "${d.trangThai}" từ trước. Mở một việc mới nếu cần đổi.`,
        viecCho: d,
      };
    }
    if (!['dong-y', 'tu-choi'].includes(trangThai)) {
      return { ok: false, loi: 'TRANG_THAI_LA', lyDo: 'Chỉ quyết được là đồng ý hoặc từ chối.' };
    }
    if (!nguoiQuyet || String(nguoiQuyet).trim().length < 2) {
      return { ok: false, loi: 'THIEU_NGUOI_QUYET', lyDo: 'Phải ghi tên người quyết. Chữ ký trống không phải chữ ký.' };
    }
    const luc = this.bayGio();
    if (d.hetHanLuc && luc > d.hetHanLuc) {
      d.trangThai = 'het-han';
      d.quyetLuc = luc;
      this.repo.put(d);
      this._vet('crm.duyet.het-han', id, { xinLuc: d.xinLuc });
      return { ok: false, loi: 'DA_HET_HAN', lyDo: 'Việc này đã quá hạn chờ. Im lặng không được tính là đồng ý.', viecCho: d };
    }
    d.trangThai = trangThai;
    d.nguoiQuyet = String(nguoiQuyet).slice(0, 120);
    d.quyetLuc = luc;
    d.ghiChuQuyet = ghiChu ? String(ghiChu).slice(0, 1000) : null;
    this.repo.put(d);
    this._vet('crm.duyet.quyet', id, { trangThai, nguoiQuyet: d.nguoiQuyet, choBaoLau: luc - d.xinLuc });
    return { ok: true, viecCho: d };
  }

  /** Quét và đóng những việc đã quá hạn. Gọi định kỳ từ lịch việc. */
  donHetHan() {
    const luc = this.bayGio();
    const qua = this.repo.filter((d) => d.trangThai === 'cho' && d.hetHanLuc && d.hetHanLuc < luc);
    for (const d of qua) {
      d.trangThai = 'het-han';
      d.quyetLuc = luc;
      this.repo.put(d);
      this._vet('crm.duyet.het-han', d.id, { xinLuc: d.xinLuc });
    }
    return { daDong: qua.length };
  }

  get(id) { return this.repo.get(id) || null; }

  dangCho({ troLyMa = null, gioiHan = 50 } = {}) {
    let ds = this.repo.filter((d) => d.trangThai === 'cho');
    if (troLyMa) ds = ds.filter((d) => d.troLyMa === troLyMa);
    return ds.sort((a, b) => b.diemRuiRo - a.diemRuiRo).slice(0, gioiHan);
  }

  /**
   * Bảng đo của chính hàng chờ. Con số đáng lo nhất không phải "bao nhiêu việc
   * đang chờ" mà là "bao nhiêu việc đã chết vì hết hạn" — việc hết hạn nghĩa
   * là có người đang đợi mà không ai tới.
   */
  bangDo() {
    const ds = this.repo.all();
    const theoTrangThai = Object.fromEntries(TRANG_THAI.map((t) => [t, ds.filter((d) => d.trangThai === t).length]));
    const daQuyet = ds.filter((d) => d.quyetLuc && d.trangThai !== 'het-han');
    const choTB = daQuyet.length
      ? Math.round(daQuyet.reduce((t, d) => t + (d.quyetLuc - d.xinLuc), 0) / daQuyet.length / 60000)
      : null;
    const tong = ds.length;
    return {
      tong,
      theoTrangThai,
      thoiGianChoTrungBinhPhut: choTB,
      tyLeHetHan: tong ? Math.round((theoTrangThai['het-han'] / tong) * 100) : 0,
      canhBao: theoTrangThai['het-han'] > 0
        ? `${theoTrangThai['het-han']} việc đã hết hạn mà không ai quyết. Im lặng không phải là đồng ý, nên những việc ấy đã KHÔNG chạy.`
        : null,
    };
  }

  _vet(hanhDong, dich, chiTiet) {
    if (!this.nhatKy) return;
    Promise.resolve(this.nhatKy.record({
      actor: 'crm-duyet', action: hanhDong, target: dich, verdict: 'ALLOW', detail: chiTiet,
    })).catch(() => {});
  }

  status() {
    return { hanGio: Math.round(this.hanMs / 3600_000), ...this.bangDo() };
  }
}

module.exports = ChoDuyet;
module.exports.TRANG_THAI = TRANG_THAI;
module.exports.HAN_MAC_DINH_MS = HAN_MAC_DINH_MS;
