'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  MỤC QUẢN TRỊ CRM — bàn điều khiển dành riêng cho Super Admin
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Ba mươi trợ lý CRM đọc dữ liệu gia đình và chạm tới học phí. Một ban như
 *  vậy mà không có ai nắm dây cương thì sớm muộn cũng có một lượt chạy mà
 *  không ai biết vì sao nó chạy. Tệp này là dây cương ấy.
 *
 *  BẢY VIỆC SUPER ADMIN LÀM ĐƯỢC Ở ĐÂY:
 *
 *      1. Xem ai đang được làm gì            (bangQuyen)
 *      2. Hạ mức tự chủ của một trợ lý       (hanMuc)
 *      3. Khoá hẳn một trợ lý                (khoa / moKhoa)
 *      4. Siết hoặc nới ngưỡng cần người     (datNguong)
 *      5. Dừng toàn ban trong một lệnh       (dungToanBan)
 *      6. Duyệt hoặc từ chối việc đang chờ   (qua ChoDuyet)
 *      7. Đọc bảng điểm và nhật ký           (bangDieuKhien)
 *
 *  BỐN LUẬT KHÔNG AI NỚI ĐƯỢC, kể cả Super Admin:
 *
 *      · Không nâng mức tự chủ của trợ lý VƯỢT trần đã khai trong sổ. Hạ thì
 *        được, nâng thì không — vì trần trong sổ là kết quả của một lần cân
 *        nhắc có ghi lý do, còn một lệnh nâng lúc đang gấp thì không.
 *      · Không cấp mức 4. Việc chạm ra ngoài hệ thống luôn qua người duyệt.
 *      · Không tắt được nhật ký kiểm toán.
 *      · Không xoá được một việc đã quyết ở hàng chờ.
 *
 *  Bốn luật ấy không nằm trong giao diện để "nhớ đừng bấm" — chúng nằm trong
 *  hàm, và hàm từ chối. Một luật chỉ dựa vào trí nhớ của người trực thì không
 *  phải luật.
 *
 *  MỌI LỆNH ĐỀU GHI TÊN NGƯỜI RA LỆNH. Không có lệnh nào "của hệ thống".
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { DS: SO_TRO_LY, INDEX, CAP, MUC_PHAI_CO_NGUOI } = require('./so-tro-ly');

/** Mức trần tuyệt đối — không lệnh nào vượt được. */
const TRAN_TUYET_DOI = MUC_PHAI_CO_NGUOI - 1;   // = 3

class QuanTriCRM {
  /**
   * @param {object} o
   * @param {object} o.nhatKy   AuditChain
   * @param {object} o.mucTuChu MucTuChu — để siết hoặc nới ngưỡng
   * @param {object} o.choDuyet ChoDuyet
   * @param {object} o.kpi      KpiCRM
   * @param {object} o.kho      KhoCRM
   */
  constructor({ nhatKy = null, mucTuChu = null, choDuyet = null, kpi = null, kho = null } = {}) {
    this.nhatKy = nhatKy;
    this.mucTuChu = mucTuChu;
    this.choDuyet = choDuyet;
    this.kpi = kpi;
    this.kho = kho;

    /** Mức hạ thủ công: mã trợ lý → mức trần mới. Không có nghĩa là theo sổ. */
    this.hanMucTay = new Map();
    /** Trợ lý bị khoá: mã → {boi, luc, lyDo}. */
    this.daKhoa = new Map();
    /** Cả ban có đang dừng không. */
    this.toanBanDung = null;

    this.lichSuLenh = [];
  }

  _ghiLenh(lenh, boi, chiTiet) {
    const ban = { lenh, boi, luc: Date.now(), chiTiet };
    this.lichSuLenh.push(ban);
    if (this.lichSuLenh.length > 500) this.lichSuLenh.shift();
    if (this.nhatKy) {
      Promise.resolve(this.nhatKy.record({
        actor: boi, actorRole: 'SUPER_ADMIN', action: `crm.quan-tri.${lenh}`,
        target: (chiTiet && chiTiet.troLyMa) || 'toan-ban',
        verdict: 'ALLOW', severity: 1, detail: chiTiet,
      })).catch(() => {});
    }
    return ban;
  }

  _doiNguoiRaLenh(boi) {
    if (!boi || String(boi).trim().length < 2) {
      return { ok: false, loi: 'THIEU_NGUOI_RA_LENH', lyDo: 'Mọi lệnh quản trị đều phải ghi tên người ra lệnh.' };
    }
    return null;
  }

  // ── 1 · XEM AI ĐANG ĐƯỢC LÀM GÌ ─────────────────────────────────────────

  /** Mức thật của một trợ lý sau khi tính cả hạn mức tay và trạng thái khoá. */
  mucThatCua(troLyMa) {
    const t = INDEX.get(troLyMa);
    if (!t) return null;
    if (this.toanBanDung) return { muc: 0, vi: 'toàn ban đang dừng' };
    if (this.daKhoa.has(troLyMa)) return { muc: 0, vi: 'trợ lý đang bị khoá' };
    const tay = this.hanMucTay.get(troLyMa);
    if (tay != null && tay < t.tuChuToiDa) return { muc: tay, vi: 'Super Admin đã hạ mức' };
    return { muc: t.tuChuToiDa, vi: 'theo sổ trợ lý' };
  }

  bangQuyen() {
    return {
      toanBanDung: this.toanBanDung,
      hang: SO_TRO_LY.map((t) => {
        const m = this.mucThatCua(t.ma);
        return {
          ma: t.ma, ten: t.ten, cap: t.cap, mien: t.mien,
          tranTheoSo: t.tuChuToiDa,
          tranTheoCap: CAP[t.cap].tranTuChu,
          mucThat: m.muc,
          vi: m.vi,
          khoa: this.daKhoa.has(t.ma),
          soCongCu: t.congCu.length,
        };
      }),
      tomTat: {
        tong: SO_TRO_LY.length,
        dangKhoa: this.daKhoa.size,
        daHaMuc: this.hanMucTay.size,
        tranTuyetDoi: TRAN_TUYET_DOI,
      },
    };
  }

  // ── 2 · HẠ MỨC ──────────────────────────────────────────────────────────

  /**
   * Hạ mức tự chủ của một trợ lý. CHỈ HẠ ĐƯỢC.
   */
  hanMuc(troLyMa, mucMoi, { boi, lyDo = null } = {}) {
    const chan = this._doiNguoiRaLenh(boi); if (chan) return chan;
    const t = INDEX.get(troLyMa);
    if (!t) return { ok: false, loi: 'KHONG_CO_TRO_LY' };
    const m = Number(mucMoi);
    if (!Number.isInteger(m) || m < 1 || m > TRAN_TUYET_DOI) {
      return { ok: false, loi: 'MUC_KHONG_HOP_LE', lyDo: `Mức nằm trong khoảng 1 tới ${TRAN_TUYET_DOI}. Mức ${MUC_PHAI_CO_NGUOI} không cấp cho ai.` };
    }
    if (m > t.tuChuToiDa) {
      return {
        ok: false, loi: 'KHONG_NANG_DUOC',
        lyDo: `Sổ trợ lý ghi trần của "${t.ten}" là ${t.tuChuToiDa}. Bàn điều khiển chỉ hạ được, không nâng được. `
          + 'Muốn nâng thì sửa sổ và sửa cả lý do đi kèm, rồi chạy lại mục kiểm.',
      };
    }
    this.hanMucTay.set(troLyMa, m);
    this._ghiLenh('han-muc', boi, { troLyMa, tu: t.tuChuToiDa, xuong: m, lyDo });
    return { ok: true, troLyMa, mucMoi: m, tranTheoSo: t.tuChuToiDa };
  }

  boHanMuc(troLyMa, { boi } = {}) {
    const chan = this._doiNguoiRaLenh(boi); if (chan) return chan;
    if (!INDEX.has(troLyMa)) return { ok: false, loi: 'KHONG_CO_TRO_LY' };
    const co = this.hanMucTay.delete(troLyMa);
    this._ghiLenh('bo-han-muc', boi, { troLyMa, coHanMucTruocDo: co });
    return { ok: true, troLyMa, troVe: INDEX.get(troLyMa).tuChuToiDa };
  }

  // ── 3 · KHOÁ VÀ MỞ ──────────────────────────────────────────────────────

  khoa(troLyMa, { boi, lyDo = null } = {}) {
    const chan = this._doiNguoiRaLenh(boi); if (chan) return chan;
    if (!INDEX.has(troLyMa)) return { ok: false, loi: 'KHONG_CO_TRO_LY' };
    if (!lyDo || String(lyDo).trim().length < 5) {
      return { ok: false, loi: 'THIEU_LY_DO', lyDo: 'Khoá một trợ lý là chuyện lớn. Phải ghi vì sao, để người sau đọc lại hiểu được.' };
    }
    this.daKhoa.set(troLyMa, { boi, luc: Date.now(), lyDo: String(lyDo).slice(0, 500) });
    this._ghiLenh('khoa', boi, { troLyMa, lyDo });
    return { ok: true, troLyMa, daKhoa: true };
  }

  moKhoa(troLyMa, { boi } = {}) {
    const chan = this._doiNguoiRaLenh(boi); if (chan) return chan;
    if (!this.daKhoa.has(troLyMa)) return { ok: false, loi: 'KHONG_BI_KHOA' };
    const cu = this.daKhoa.get(troLyMa);
    this.daKhoa.delete(troLyMa);
    this._ghiLenh('mo-khoa', boi, { troLyMa, khoaBoi: cu.boi, khoaBaoLauMs: Date.now() - cu.luc });
    return { ok: true, troLyMa, daKhoa: false };
  }

  // ── 4 · NGƯỠNG CẦN NGƯỜI ────────────────────────────────────────────────

  /**
   * Siết hoặc nới ngưỡng cần người duyệt.
   *
   * Nới có hạn: không nới quá 0,60. Trên mức ấy thì gần như mọi việc tự chạy,
   * và hàng chờ duyệt trở thành một cái hộp rỗng — đúng chỗ mà hệ thống duyệt
   * tự động hay chết mà không ai để ý.
   */
  datNguong({ canNguoi = null, chan = null, boi } = {}) {
    const ch = this._doiNguoiRaLenh(boi); if (ch) return ch;
    if (!this.mucTuChu) return { ok: false, loi: 'CHUA_CO_BO_CAN_MUC' };
    const cu = { canNguoi: this.mucTuChu.nguongCanNguoi, chan: this.mucTuChu.nguongChan };
    if (canNguoi != null) {
      const v = Number(canNguoi);
      if (!(v > 0 && v <= 0.60)) {
        return { ok: false, loi: 'NGUONG_NGOAI_KHOANG', lyDo: 'Ngưỡng cần người nằm trong khoảng lớn hơn 0 tới 0,60. Nới cao hơn thì hàng chờ duyệt thành hộp rỗng.' };
      }
      this.mucTuChu.nguongCanNguoi = v;
    }
    if (chan != null) {
      const v = Number(chan);
      if (!(v >= 0.70 && v <= 1)) {
        return { ok: false, loi: 'NGUONG_NGOAI_KHOANG', lyDo: 'Ngưỡng chặn nằm trong khoảng 0,70 tới 1.' };
      }
      if (v <= this.mucTuChu.nguongCanNguoi) {
        return { ok: false, loi: 'NGUONG_LON_XON', lyDo: 'Ngưỡng chặn phải cao hơn ngưỡng cần người.' };
      }
      this.mucTuChu.nguongChan = v;
    }
    const moi = { canNguoi: this.mucTuChu.nguongCanNguoi, chan: this.mucTuChu.nguongChan };
    this._ghiLenh('dat-nguong', boi, { cu, moi });
    return { ok: true, cu, moi };
  }

  // ── 5 · DỪNG TOÀN BAN ───────────────────────────────────────────────────

  /**
   * Công tắc lớn. Dùng khi nghi có chuyện và chưa biết chuyện gì: dừng trước,
   * tìm hiểu sau. Dừng KHÔNG xoá gì — việc đang chờ duyệt vẫn nằm nguyên.
   */
  dungToanBan({ boi, lyDo = null } = {}) {
    const chan = this._doiNguoiRaLenh(boi); if (chan) return chan;
    if (!lyDo || String(lyDo).trim().length < 5) {
      return { ok: false, loi: 'THIEU_LY_DO', lyDo: 'Dừng cả ban thì phải ghi vì sao.' };
    }
    this.toanBanDung = { boi, luc: Date.now(), lyDo: String(lyDo).slice(0, 500) };
    this._ghiLenh('dung-toan-ban', boi, { lyDo });
    return { ok: true, dung: true, tuLuc: this.toanBanDung.luc };
  }

  chayLaiToanBan({ boi } = {}) {
    const chan = this._doiNguoiRaLenh(boi); if (chan) return chan;
    if (!this.toanBanDung) return { ok: false, loi: 'KHONG_DANG_DUNG' };
    const cu = this.toanBanDung;
    this.toanBanDung = null;
    this._ghiLenh('chay-lai-toan-ban', boi, { dungBoi: cu.boi, dungBaoLauMs: Date.now() - cu.luc });
    return { ok: true, dung: false, daDungMs: Date.now() - cu.luc };
  }

  // ── 7 · BÀN ĐIỀU KHIỂN ──────────────────────────────────────────────────

  /** Một màn hình đủ để biết ban này đang ở đâu. */
  banDieuKhien() {
    const q = this.bangQuyen();
    return {
      trangThai: this.toanBanDung
        ? { chay: false, lyDo: this.toanBanDung.lyDo, dungBoi: this.toanBanDung.boi, tuLuc: this.toanBanDung.luc }
        : { chay: true },
      quyen: q.tomTat,
      nguong: this.mucTuChu ? this.mucTuChu.status() : null,
      hangCho: this.choDuyet ? this.choDuyet.bangDo() : null,
      diem: this.kpi ? this.kpi.status() : null,
      kho: this.kho ? this.kho.tongQuan() : null,
      lenhGanDay: this.lichSuLenh.slice(-10).reverse(),
      viecCanLamNgay: this._viecCanLamNgay(),
    };
  }

  /**
   * Ba việc đáng làm nhất lúc này — sắp theo mức cấp bách thật, không theo
   * thứ tự mục trên màn hình.
   */
  _viecCanLamNgay() {
    const ra = [];
    if (this.toanBanDung) {
      ra.push({ muc: 'cao', viec: `Cả ban đang dừng từ ${new Date(this.toanBanDung.luc).toISOString()} vì: ${this.toanBanDung.lyDo}` });
    }
    if (this.choDuyet) {
      const bd = this.choDuyet.bangDo();
      if (bd.theoTrangThai && bd.theoTrangThai['het-han'] > 0) {
        ra.push({ muc: 'cao', viec: `${bd.theoTrangThai['het-han']} việc đã hết hạn chờ mà không ai quyết — những việc ấy đã không chạy.` });
      }
      if (bd.theoTrangThai && bd.theoTrangThai.cho > 0) {
        ra.push({ muc: 'vua', viec: `${bd.theoTrangThai.cho} việc đang chờ người duyệt.` });
      }
    }
    if (this.kpi) {
      const b = this.kpi.bangDiem();
      if (b.canKem && b.canKem.length) {
        ra.push({ muc: 'vua', viec: `${b.canKem.length} trợ lý dưới ngưỡng đạt: ${b.canKem.slice(0, 3).map((c) => c.ten).join(', ')}` });
      }
      if (b.doPhuChiSo && b.doPhuChiSo.chuaNoiNguon > 0) {
        ra.push({ muc: 'thap', viec: `${b.doPhuChiSo.chuaNoiNguon} trên ${b.doPhuChiSo.tong} chỉ số KPI chưa nối được nguồn đo.` });
      }
    }
    if (this.daKhoa.size) {
      ra.push({ muc: 'thap', viec: `${this.daKhoa.size} trợ lý đang bị khoá.` });
    }
    return ra.length ? ra : [{ muc: 'thap', viec: 'Không có việc nào cần Super Admin xử lý ngay.' }];
  }

  status() {
    return {
      dangDung: !!this.toanBanDung,
      soTroLyBiKhoa: this.daKhoa.size,
      soTroLyDaHaMuc: this.hanMucTay.size,
      soLenhDaGhi: this.lichSuLenh.length,
      luatKhongNoiDuoc: [
        'Không nâng mức tự chủ vượt trần đã khai trong sổ trợ lý.',
        `Không cấp mức ${MUC_PHAI_CO_NGUOI} cho bất kỳ trợ lý nào.`,
        'Không tắt được nhật ký kiểm toán.',
        'Không xoá được một việc đã quyết ở hàng chờ duyệt.',
      ],
    };
  }
}

module.exports = QuanTriCRM;
module.exports.TRAN_TUYET_DOI = TRAN_TUYET_DOI;
