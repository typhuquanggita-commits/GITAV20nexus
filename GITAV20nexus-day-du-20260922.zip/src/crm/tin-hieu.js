'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  TÍN HIỆU — mỗi lượt chạy để lại gì cho lần sau
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Vòng học của hệ này KHÔNG huấn luyện lại mô hình nào. Nó làm một việc hẹp
 *  hơn và trung thực hơn: ghi lại đủ để trả lời bốn câu hỏi mà không phải đoán.
 *
 *      · lối định tuyến nào đọc đúng nhiều hơn
 *      · trợ lý nào bị người duyệt từ chối nhiều
 *      · công cụ nào gọi rồi mà không dùng tới kết quả
 *      · lượt nào chậm, chậm ở khúc nào
 *
 *  KHÔNG GHI NỘI DUNG GIA ĐÌNH. Tín hiệu giữ mã, nhãn, số đo — không giữ câu
 *  chữ của phụ huynh hay của em nhỏ. Một kho tín hiệu phình lên thành bản sao
 *  thứ hai của dữ liệu gia đình là một kho rò rỉ đang chờ ngày xảy ra, và nó
 *  nằm ngoài mọi luật riêng tư đã viết cho kho chính.
 *
 *  PHẢN HỒI CỦA NGƯỜI LÀ TÍN HIỆU QUÝ NHẤT. Người duyệt bấm từ chối là họ đang
 *  nói hệ thống sai ở đâu đó. Vì vậy mỗi lần quyết ở hàng chờ đều chảy ngược
 *  về đây.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { id: newId, round } = require('../utils');

class TinHieu {
  constructor({ repo, gioiHanGiu = 20000 } = {}) {
    if (!repo) throw new Error('TinHieu cần một bộ sưu tập');
    this.repo = repo;
    this.gioiHanGiu = gioiHanGiu;
  }

  /**
   * Ghi một lượt.
   * @param {object} o
   * @param {string} o.phienId
   * @param {string} o.yDinh          nhãn ý định đã đọc ra
   * @param {string} o.nguonDinhTuyen 'tu-khoa' | 'mo-hinh' | 'tu-khoa-du-phong'
   * @param {number} o.doTin
   * @param {string[]} o.chuoiTroLy   mã các trợ lý đã chạy, theo thứ tự
   * @param {string} o.kieuGhep       'mot-nguoi' | 'co-nguoi-phu' | 'phan-bien'
   * @param {string[]} o.congCuGoi
   * @param {number} o.msTong
   * @param {number} o.diemRuiRo
   * @param {boolean} o.canNguoi
   * @param {string|null} o.moHinh
   */
  ghi(o = {}) {
    const d = {
      id: newId('TH'),
      phienId: o.phienId || null,
      yDinh: o.yDinh || null,
      nguonDinhTuyen: o.nguonDinhTuyen || null,
      doTin: o.doTin == null ? null : round(Number(o.doTin), 3),
      chuoiTroLy: Array.isArray(o.chuoiTroLy) ? o.chuoiTroLy.slice(0, 5) : [],
      troLyMa: (Array.isArray(o.chuoiTroLy) && o.chuoiTroLy.length) ? o.chuoiTroLy[o.chuoiTroLy.length - 1] : null,
      kieuGhep: o.kieuGhep || null,
      congCuGoi: Array.isArray(o.congCuGoi) ? o.congCuGoi.slice(0, 20) : [],
      soChuGoc: o.soChuGoc == null ? null : Number(o.soChuGoc),
      msTong: Number(o.msTong) || 0,
      diemRuiRo: o.diemRuiRo == null ? null : round(Number(o.diemRuiRo), 3),
      canNguoi: !!o.canNguoi,
      moHinh: o.moHinh || null,
      // Hai trường dưới đây điền sau, khi người duyệt quyết.
      nguoiPhanHoi: null,
      viecChayThat: null,
      luc: Date.now(),
    };
    this.repo.put(d);
    this._tia();
    return d.id;
  }

  /** Người duyệt đã quyết — chảy ngược về lượt đã sinh ra việc ấy. */
  ghiPhanHoi(phienId, phanHoi, { viecChayThat = null } = {}) {
    const ds = this.repo.by('phienId', phienId);
    if (!ds.length) return { ok: false, loi: 'KHONG_CO_TIN_HIEU' };
    for (const d of ds) {
      d.nguoiPhanHoi = phanHoi;
      if (viecChayThat != null) d.viecChayThat = !!viecChayThat;
      this.repo.put(d);
    }
    return { ok: true, daCapNhat: ds.length };
  }

  /** Giữ kho khỏi phình vô hạn: quá giới hạn thì bỏ những bản cũ nhất. */
  _tia() {
    const n = this.repo.count();
    if (n <= this.gioiHanGiu) return 0;
    const ds = this.repo.all().sort((a, b) => a.luc - b.luc);
    const bo = ds.slice(0, n - this.gioiHanGiu);
    for (const d of bo) this.repo.delete(d.id);
    return bo.length;
  }

  /** Bảng tổng. Mọi tỷ lệ đều kèm MẪU SỐ — tỷ lệ không mẫu số là tỷ lệ vô nghĩa. */
  bangTong() {
    const ds = this.repo.all();
    if (!ds.length) {
      return { tong: 0, loiNhan: 'Chưa có lượt nào chạy qua CRM.' };
    }
    const theoNguon = {};
    for (const d of ds) {
      const k = d.nguonDinhTuyen || 'khong-ro';
      theoNguon[k] = (theoNguon[k] || 0) + 1;
    }
    const theoKieu = {};
    for (const d of ds) {
      const k = d.kieuGhep || 'khong-ro';
      theoKieu[k] = (theoKieu[k] || 0) + 1;
    }
    const coPhanHoi = ds.filter((d) => d.nguoiPhanHoi);
    const dongY = coPhanHoi.filter((d) => d.nguoiPhanHoi === 'dong-y').length;
    const ms = ds.map((d) => d.msTong).sort((a, b) => a - b);
    return {
      tong: ds.length,
      theoNguonDinhTuyen: theoNguon,
      theoKieuGhep: theoKieu,
      canNguoi: ds.filter((d) => d.canNguoi).length,
      phanHoiCuaNguoi: {
        soLuotCoPhanHoi: coPhanHoi.length,
        dongY,
        tuChoi: coPhanHoi.length - dongY,
        tyLeDongY: coPhanHoi.length ? round(dongY / coPhanHoi.length, 3) : null,
        ghiChu: coPhanHoi.length ? null : 'Chưa có lượt nào được người quyết, nên chưa có tỷ lệ đồng ý.',
      },
      thoiGian: {
        msTrungVi: ms[Math.floor(ms.length / 2)],
        msPhanVi90: ms[Math.floor(ms.length * 0.9)],
        msLonNhat: ms[ms.length - 1],
      },
    };
  }

  /** Trợ lý nào bị từ chối nhiều nhất — chỗ đáng sửa trước. */
  troLyBiTuChoi(gioiHan = 10) {
    const ds = this.repo.filter((d) => d.nguoiPhanHoi);
    const gom = new Map();
    for (const d of ds) {
      if (!d.troLyMa) continue;
      const g = gom.get(d.troLyMa) || { troLyMa: d.troLyMa, tong: 0, tuChoi: 0 };
      g.tong++;
      if (d.nguoiPhanHoi === 'tu-choi') g.tuChoi++;
      gom.set(d.troLyMa, g);
    }
    return [...gom.values()]
      .map((g) => ({ ...g, tyLeTuChoi: round(g.tuChoi / g.tong, 3) }))
      .sort((a, b) => b.tyLeTuChoi - a.tyLeTuChoi || b.tong - a.tong)
      .slice(0, gioiHan);
  }

  /** Ý định nào lối tất định không đọc được — chỗ đáng bổ sung từ khoá. */
  yDinhPhaiHoiMoHinh(gioiHan = 10) {
    const ds = this.repo.filter((d) => d.nguonDinhTuyen === 'mo-hinh');
    const gom = new Map();
    for (const d of ds) gom.set(d.yDinh, (gom.get(d.yDinh) || 0) + 1);
    return [...gom.entries()]
      .map(([yDinh, so]) => ({ yDinh, soLuotPhaiHoiMoHinh: so }))
      .sort((a, b) => b.soLuotPhaiHoiMoHinh - a.soLuotPhaiHoiMoHinh)
      .slice(0, gioiHan);
  }

  status() {
    return { soTinHieu: this.repo.count(), gioiHanGiu: this.gioiHanGiu };
  }
}

module.exports = TinHieu;
