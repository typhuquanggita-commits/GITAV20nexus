'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  KHO CÔNG CỤ CRM — hai mươi công cụ, KHÔNG công cụ nào trả dữ liệu giả lập
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  ĐÂY LÀ CHỖ BẢN THIẾT KẾ GỐC PHẢI ĐỔI NHIỀU NHẤT. Bản gốc cho mỗi công cụ
 *  một hàm trả dữ liệu dựng sẵn — "Công ty ABC, 500 triệu, giai đoạn thương
 *  lượng" — kèm lời hứa sẽ thay bằng API thật sau. Lời hứa ấy không giữ được:
 *  hệ chạy được ngay nên không ai thấy cần thay, và tới lúc có người thật đọc
 *  thì họ đọc phải những con số chưa từng tồn tại.
 *
 *  Ở đây mỗi công cụ đọc dữ liệu THẬT của hệ thống. Khi chưa có dữ liệu, công
 *  cụ trả về ĐÚNG CÂU ẤY — "chưa có bản ghi nào" — chứ không đắp một con số
 *  vào cho bảng đỡ trống. Kho rỗng là một sự thật; một con số bịa thì không.
 *
 *  BỐN MỨC ĐỘNG CHẠM (xem src/crm/so-tro-ly.js):
 *      1 chỉ đọc · 2 soạn nháp · 3 ghi vào sổ nhà · 4 chạm ra ngoài
 *  Công cụ mức 4 KHÔNG BAO GIỜ tự chạy. Nó trả về một bản đề xuất và đẩy việc
 *  sang hàng chờ duyệt. Một trợ lý AI không được phép nhắn tin cho mẹ của một
 *  đứa trẻ mà không có người lớn nào gật đầu.
 *
 *  HAI LỚP SOÁT TRƯỚC KHI CHỮ RỜI HỆ THỐNG. Bản thảo nào cũng đi qua:
 *      · bức tường Cây Tiền — chặn phân loại nội bộ lọt ra ngoài
 *      · bộ soát tiếng Việt — chặn giọng máy, viết tắt, sai chính tả
 *  Không đạt thì công cụ trả về lỗi kèm chỗ sai, không trả bản thảo.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const tuong = require('../cay-tien/buc-tuong');
const { TINH_HUONG, INDEX: TH_INDEX, theoNhom } = require('../trai-nghiem/tinh-huong');
const { luoi, diemCham } = require('../trai-nghiem/luoi-cham');
const { soiRuiRo } = require('../chien-luoc/rui-ro');
const { anToanTaiChinh, anToanPhapLy } = require('../chien-luoc/an-toan');
const { theDiem } = require('../chien-luoc/the-diem');
const { viKey } = require('../utils');

/** Một công cụ. */
class CongCu {
  constructor({ ten, moTa, thamSo, mucDongCham, chay }) {
    this.ten = ten;
    this.moTa = moTa;
    this.thamSo = thamSo;
    this.mucDongCham = mucDongCham;
    this.chay = chay;
  }

  luocDo() {
    return { ten: this.ten, moTa: this.moTa, thamSo: this.thamSo, mucDongCham: this.mucDongCham };
  }
}

/** Câu trả lời chuẩn khi kho có thật nhưng chưa có bản ghi nào. */
const khoRong = (cai, goiY) => ({
  ok: true, coDuLieu: false,
  loiNhan: `Chưa có ${cai} nào trong kho.`,
  lamGiTiepTheo: goiY,
});

class KhoCongCu {
  /**
   * @param {object} o
   * @param {object} o.N     Nexus — nguồn dữ liệu thật
   * @param {object} o.kho   KhoCRM
   */
  constructor({ N, kho }) {
    this.N = N;
    this.kho = kho;
    this._ds = new Map();
    this._dungKy();
  }

  dangKy(cc) { this._ds.set(cc.ten, cc); return this; }
  co(ten) { return this._ds.has(ten); }
  luocDo(ten) { const c = this._ds.get(ten); return c ? c.luocDo() : null; }
  mucCua(ten) { const c = this._ds.get(ten); return c ? c.mucDongCham : 4; }
  danhSach() { return [...this._ds.values()].map((c) => c.luocDo()); }

  /**
   * Chạy một công cụ.
   *
   * KHÔNG kiểm quyền ở đây — kiểm quyền là việc của src/crm/dieu-phoi.js, và
   * để một chỗ thì không có chỗ thứ hai quên mất. Ở đây chỉ chạy và bắt lỗi.
   */
  async goi(ten, thamSo = {}, boiCanh = {}) {
    const cc = this._ds.get(ten);
    if (!cc) {
      return { ok: false, loi: 'KHONG_CO_CONG_CU', lyDo: `Không có công cụ tên "${ten}".`, coSan: [...this._ds.keys()] };
    }
    try {
      const kq = await cc.chay(thamSo || {}, boiCanh || {});
      return { ok: true, ten, mucDongCham: cc.mucDongCham, ketQua: kq };
    } catch (e) {
      return { ok: false, ten, loi: 'CONG_CU_HONG', lyDo: e.message };
    }
  }

  // ═══════════════════════════════════════════════════════════════════════
  //  HAI LỚP SOÁT CHUNG
  // ═══════════════════════════════════════════════════════════════════════

  /**
   * Soi một bản thảo trước khi cho nó rời khỏi công cụ.
   * @returns {{dat:boolean, loi:string[]}}
   */
  _soatBanThao(chu) {
    const loi = [];
    // Cờ là "sach"; "roRi" là danh sách cụm bắt được. Đọc nhầm hai trường này
    // thì hoặc chặn hết, hoặc không chặn gì — cả hai đều hỏng lặng lẽ.
    const soi = tuong.soiRoRi(String(chu));
    if (!soi.sach) {
      loi.push(`Bản thảo chứa phân loại nội bộ: ${soi.roRi.map((r) => r.cum).slice(0, 3).join(', ')}`);
    }
    if (this.N && this.N.linguist && typeof this.N.linguist.soat === 'function') {
      try {
        const s = this.N.linguist.soat(String(chu), { loai: 'tu-do' });
        const chan = (s.loi || []).filter((l) => l.muc === 'chan' || l.nang === true);
        for (const l of chan.slice(0, 3)) loi.push(`Tiếng Việt: ${l.thongBao || l.moTa || l.ma}`);
      } catch { /* bộ soát hỏng thì không được phép chặn việc; lớp tường vẫn giữ */ }
    }
    return { dat: loi.length === 0, loi };
  }

  // ═══════════════════════════════════════════════════════════════════════
  //  ĐĂNG KÝ HAI MƯƠI CÔNG CỤ
  // ═══════════════════════════════════════════════════════════════════════

  _dungKy() {
    const K = this.kho;
    const N = this.N;

    // ── MỨC 1 · CHỈ ĐỌC ──────────────────────────────────────────────────

    this.dangKy(new CongCu({
      ten: 'doc_toan_canh',
      moTa: 'Đọc toàn cảnh hệ thống: số gia đình theo chặng, công nợ, yêu cầu đang mở.',
      thamSo: {},
      mucDongCham: 1,
      chay: async () => {
        const tq = K.tongQuan();
        const kpiHe = N && N.kpi ? N.kpi.system() : null;
        return {
          crm: tq,
          hocVienDangCo: N && N.learners ? N.learners.count() : null,
          taiKhoan: N && N.users ? N.users.count() : null,
          lucLuongTroLy: N && N.agents ? N.agents.length : null,
          kpiHeThong: kpiHe ? { soViec: kpiHe.tasks, tyLeDat: kpiHe.successRate } : null,
          nguon: 'Đếm trực tiếp trên kho dữ liệu đang chạy',
        };
      },
    }));

    this.dangKy(new CongCu({
      ten: 'doc_gia_dinh',
      moTa: 'Đọc hồ sơ gia đình: chặng đang ở, điểm đã chấm, học phí, tương tác gần đây.',
      thamSo: { giaDinhId: 'mã gia đình', chang: 'lọc theo chặng', gioiHan: 'số bản ghi tối đa' },
      mucDongCham: 1,
      chay: async ({ giaDinhId = null, chang = null, gioiHan = 20 }) => {
        if (giaDinhId) {
          const gd = K.giaDinh.get(giaDinhId);
          if (!gd) return { ok: false, loi: 'KHONG_CO_GIA_DINH', giaDinhId };
          return {
            giaDinh: gd,
            diem: K.diemCua(giaDinhId),
            hocPhi: K.congNo({ giaDinhId }),
            yeuCauDangMo: K.yeuCau.by('giaDinhId', giaDinhId)
              .filter((y) => y.trangThai !== 'xong' && y.trangThai !== 'dong').length,
            tuongTacGanDay: K.tuongTac.by('giaDinhId', giaDinhId).slice(-5),
            nguon: 'Kho gia đình CRM',
          };
        }
        const ds = chang ? K.giaDinh.by('chang', chang) : K.giaDinh.all();
        if (!ds.length) {
          return khoRong('hồ sơ gia đình', 'Mở hồ sơ bằng POST /crm/gia-dinh, hoặc nối từ tài khoản đã có.');
        }
        return {
          ok: true, coDuLieu: true, tong: ds.length,
          danhSach: ds.slice(0, Math.min(gioiHan, 50)).map((g) => ({
            id: g.id, tenGoi: g.tenGoi, chang: g.chang, capNhatLuc: g.capNhatLuc,
          })),
          nguon: 'Kho gia đình CRM',
        };
      },
    }));

    this.dangKy(new CongCu({
      ten: 'doc_hoc_phi',
      moTa: 'Đọc học phí: đã thu, còn thiếu, quá hạn — theo gia đình hoặc toàn hệ.',
      thamSo: { giaDinhId: 'mã gia đình, bỏ trống để xem toàn hệ' },
      mucDongCham: 1,
      chay: async ({ giaDinhId = null }) => {
        const t = K.congNo({ giaDinhId });
        if (t.soKy === 0) {
          return khoRong('kỳ học phí', 'Ghi kỳ đầu tiên bằng POST /crm/hoc-phi khi đã có thoả thuận với gia đình.');
        }
        return { ok: true, coDuLieu: true, ...t, donVi: 'đồng', nguon: 'Kho học phí CRM' };
      },
    }));

    this.dangKy(new CongCu({
      ten: 'doc_so_cai',
      moTa: 'Đọc sổ cái dòng tiền vận hành, kèm mức tin cậy của từng khoản.',
      thamSo: {},
      mucDongCham: 1,
      chay: async () => {
        if (!N || !N.soCai) return { ok: false, loi: 'CHUA_CO_SO_CAI' };
        const bb = N.soCai.bienBan();
        return {
          ok: true, bienBan: bb,
          canhBao: bb.ketLuan && /KHÔNG dựng được/.test(bb.ketLuan)
            ? 'Sổ cái tự khai là chưa dựng được báo cáo lợi nhuận. Đừng dùng số ở đây như số doanh thu.'
            : null,
          nguon: 'src/dong-tien/so-cai.js — mỗi khoản khai rõ nguồn đo',
        };
      },
    }));

    this.dangKy(new CongCu({
      ten: 'doc_khao_sat',
      moTa: 'Đọc KẾT LUẬN khảo sát của một học viên. Không trả về câu trả lời thô.',
      thamSo: { hocVienId: 'mã học viên' },
      mucDongCham: 1,
      chay: async ({ hocVienId = null }) => {
        if (!hocVienId) return { ok: false, loi: 'THIEU_HOC_VIEN' };
        if (!N || !N.khaoSat) return { ok: false, loi: 'CHUA_CO_KHO_KHAO_SAT' };
        // Kho khảo sát tự giữ luật riêng tư: nó KHÔNG trả câu thô ra ngoài.
        // CRM gọi đúng cửa ấy chứ không đọc thẳng bộ sưu tập, vì đọc thẳng là
        // đi vòng qua luật.
        const ds = typeof N.khaoSat.cuaHocVien === 'function'
          ? N.khaoSat.cuaHocVien(hocVienId)
          : null;
        if (!ds || (Array.isArray(ds) && !ds.length)) {
          return khoRong('bài khảo sát của học viên này', 'Mời em làm bài ở /nha/khao-sat.');
        }
        return { ok: true, coDuLieu: true, ketQua: ds, nguon: 'Kho khảo sát, đọc qua cửa có luật riêng tư' };
      },
    }));

    this.dangKy(new CongCu({
      ten: 'doc_lo_trinh',
      moTa: 'Đọc lộ trình học và mức hiện tại của một học viên.',
      thamSo: { hocVienId: 'mã học viên' },
      mucDongCham: 1,
      chay: async ({ hocVienId = null }) => {
        if (!hocVienId) return { ok: false, loi: 'THIEU_HOC_VIEN' };
        const hv = N && N.learners ? N.learners.get(hocVienId) : null;
        if (!hv) return { ok: false, loi: 'KHONG_CO_HOC_VIEN', hocVienId };
        let loTrinh = null;
        try { loTrinh = N.roadmap ? N.roadmap.get(hocVienId) : null; } catch { loTrinh = null; }
        return {
          ok: true, coDuLieu: true,
          hocVien: { id: hv.id, ten: hv.fullName, lop: hv.grade, mucHienTai: hv.currentLevel, mucDich: hv.targetLevel },
          loTrinh: loTrinh || null,
          ghiChu: loTrinh ? null : 'Chưa dựng lộ trình cho em này.',
          nguon: 'Kho học viên và dịch vụ lộ trình',
        };
      },
    }));

    this.dangKy(new CongCu({
      ten: 'doc_yeu_cau',
      moTa: 'Đọc yêu cầu hỗ trợ của gia đình, kèm số bước phục hồi đã chạy.',
      thamSo: { giaDinhId: 'lọc theo gia đình', trangThai: 'lọc theo trạng thái' },
      mucDongCham: 1,
      chay: async ({ giaDinhId = null, trangThai = null }) => {
        let ds = giaDinhId ? K.yeuCau.by('giaDinhId', giaDinhId) : K.yeuCau.all();
        if (trangThai) ds = ds.filter((y) => y.trangThai === trangThai);
        if (!ds.length) return khoRong('yêu cầu hỗ trợ', 'Ghi yêu cầu bằng POST /crm/yeu-cau khi gia đình liên hệ.');
        const { BUOC } = require('../trai-nghiem/phuc-hoi');
        return {
          ok: true, coDuLieu: true, tong: ds.length,
          danhSach: ds.slice(0, 30).map((y) => ({
            id: y.id, nhom: y.nhom, khan: y.khan, trangThai: y.trangThai,
            buocDaChay: (y.buocPhucHoi || []).length, tongBuoc: BUOC.length,
            moLuc: y.moLuc,
          })),
          nguon: 'Kho yêu cầu CRM',
        };
      },
    }));

    this.dangKy(new CongCu({
      ten: 'doc_chien_dich',
      moTa: 'Đọc chiến dịch tuyển sinh và hiệu quả đo được — hoặc lý do chưa tính được.',
      thamSo: { chienDichId: 'mã chiến dịch, bỏ trống để xem tất cả' },
      mucDongCham: 1,
      chay: async ({ chienDichId = null }) => {
        if (chienDichId) return K.hieuQuaChienDich(chienDichId);
        const ds = K.chienDich.all();
        if (!ds.length) return khoRong('chiến dịch', 'Mở chiến dịch bằng POST /crm/chien-dich, nhớ khai nguồn của con số chi phí.');
        return {
          ok: true, coDuLieu: true, tong: ds.length,
          danhSach: ds.map((c) => ({ ...c, hieuQua: K.hieuQuaChienDich(c.id) })),
          nguon: 'Kho chiến dịch CRM',
        };
      },
    }));

    this.dangKy(new CongCu({
      ten: 'doc_the_diem',
      moTa: 'Đọc thẻ điểm cân bằng bốn viễn cảnh của hệ thống.',
      thamSo: {},
      mucDongCham: 1,
      chay: async () => ({ ok: true, theDiem: theDiem(), nguon: 'src/chien-luoc/the-diem.js' }),
    }));

    this.dangKy(new CongCu({
      ten: 'doc_rui_ro',
      moTa: 'Đọc sổ rủi ro và cách chặn đã viết cho từng mục.',
      thamSo: {},
      mucDongCham: 1,
      chay: async () => ({ ok: true, soi: soiRuiRo(), nguon: 'src/chien-luoc/rui-ro.js' }),
    }));

    this.dangKy(new CongCu({
      ten: 'doc_an_toan_tai_chinh',
      moTa: 'Đọc cửa an toàn tài chính: hệ thống còn đủ điều kiện mở rộng hay chưa.',
      thamSo: {},
      mucDongCham: 1,
      chay: async () => ({ ok: true, ketQua: anToanTaiChinh(), nguon: 'src/chien-luoc/an-toan.js' }),
    }));

    this.dangKy(new CongCu({
      ten: 'doc_an_toan_phap_ly',
      moTa: 'Đọc nghĩa vụ pháp lý và trạng thái từng nghĩa vụ.',
      thamSo: {},
      mucDongCham: 1,
      chay: async () => ({ ok: true, ketQua: anToanPhapLy(), nguon: 'src/chien-luoc/an-toan.js' }),
    }));

    this.dangKy(new CongCu({
      ten: 'doc_tinh_huong',
      moTa: 'Tra kịch bản cho một tình huống đã lường trước.',
      thamSo: { tuKhoa: 'từ khoá mô tả tình huống', nhom: 'lọc theo nhóm' },
      mucDongCham: 1,
      chay: async ({ tuKhoa = null, nhom = null }) => {
        if (nhom) {
          const ds = theoNhom(nhom);
          return ds.length
            ? { ok: true, coDuLieu: true, tong: ds.length, tinhHuong: ds, nguon: 'src/trai-nghiem/tinh-huong.js' }
            : { ok: false, loi: 'NHOM_LA', lyDo: `Không có nhóm tình huống tên "${nhom}".` };
        }
        if (!tuKhoa) {
          return { ok: true, coDuLieu: true, tong: TINH_HUONG.length, danhSachNgan: TINH_HUONG.map((t) => ({ ma: t.ma, ten: t.ten })) };
        }
        // Khớp không phân biệt dấu — phụ huynh gõ không dấu là chuyện thường.
        const khoa = viKey(String(tuKhoa));
        const hop = TINH_HUONG.filter((t) => viKey(`${t.ten} ${t.moTa || ''}`).includes(khoa));
        if (!hop.length) {
          return {
            ok: true, coDuLieu: false,
            loiNhan: `Không có tình huống nào khớp "${tuKhoa}" trong ${TINH_HUONG.length} tình huống đã lường.`,
            lamGiTiepTheo: 'Chuyển cho người phụ trách. Tình huống chưa lường thì không được ứng biến bằng máy.',
          };
        }
        return { ok: true, coDuLieu: true, tong: hop.length, tinhHuong: hop.slice(0, 5), nguon: 'src/trai-nghiem/tinh-huong.js' };
      },
    }));

    this.dangKy(new CongCu({
      ten: 'doc_diem_cham',
      moTa: 'Tra điểm chạm nên dùng cho một ô của lưới mười nghìn ô.',
      thamSo: { tang: 'tầng 1-5', cap: 'cấp 1-10', tinhHuong: 'mã tình huống', kenh: 'mã kênh' },
      mucDongCham: 1,
      chay: async ({ tang = null, cap = null, tinhHuong = null, kenh = null }) => {
        if (tang == null || cap == null) {
          const l = luoi();
          return { ok: true, luoi: { tongO: l.tongO || l.tong, moTa: l.moTa || null }, nguon: 'src/trai-nghiem/luoi-cham.js' };
        }
        const o = diemCham({ tang: Number(tang), cap: Number(cap), tinhHuong, kenh });
        return { ok: true, coDuLieu: !!o, diemCham: o, nguon: 'src/trai-nghiem/luoi-cham.js' };
      },
    }));

    // ── MỨC 2 · SOẠN NHÁP ────────────────────────────────────────────────

    this.dangKy(new CongCu({
      ten: 'soan_thu',
      moTa: 'Soạn bản thảo thư gửi gia đình. Soạn xong KHÔNG gửi.',
      thamSo: { giaDinhId: 'gia đình nhận', viec: 'việc cần nói', yKien: 'ý chính muốn truyền đạt' },
      mucDongCham: 2,
      chay: async ({ giaDinhId = null, viec = 'chung', yKien = '' }, boiCanh = {}) => {
        if (!yKien || String(yKien).trim().length < 10) {
          return { ok: false, loi: 'THIEU_Y_KIEN', lyDo: 'Phải nói rõ muốn truyền đạt điều gì thì mới soạn được.' };
        }
        const gd = giaDinhId ? K.giaDinh.get(giaDinhId) : null;
        const xung = gd && gd.tenGoi ? `Kính gửi ${gd.tenGoi}` : 'Kính gửi quý phụ huynh';
        const than = String(yKien).trim();
        const banThao = `${xung},\n\n${than}\n\nTrân trọng,\nBan đồng hành GITAmath`;
        const soat = this._soatBanThao(banThao);
        if (!soat.dat) return { ok: false, loi: 'BAN_THAO_KHONG_DAT', choSai: soat.loi };
        return {
          ok: true, banThao, viec,
          giaDinhId: giaDinhId || null,
          daSoat: ['bức tường phân loại nội bộ', 'bộ soát tiếng Việt'],
          canLam: 'Bản thảo này chưa gửi. Muốn gửi thì gọi công cụ gui_thu, và việc ấy phải qua người duyệt.',
        };
      },
    }));

    this.dangKy(new CongCu({
      ten: 'soan_noi_dung',
      moTa: 'Soạn nội dung truyền thông tuyển sinh. Soạn xong KHÔNG đăng.',
      thamSo: { chuDe: 'chủ đề', doDai: 'số câu mong muốn' },
      mucDongCham: 2,
      chay: async ({ chuDe = '', doDai = 3 }) => {
        if (!chuDe || String(chuDe).trim().length < 5) return { ok: false, loi: 'THIEU_CHU_DE' };
        const soCau = Math.max(1, Math.min(Number(doDai) || 3, 10));
        const kq = N && N.llm
          ? await N.llm.call({
            task: 'vietnamese',
            system: 'Bạn viết nội dung cho một hệ thống dạy toán. Viết tiếng Việt có dấu, không viết tắt, '
              + 'không hứa kết quả chưa đo được, không nêu con số nếu không được cung cấp.',
            prompt: `Viết ${soCau} câu về chủ đề: ${String(chuDe).trim()}`,
            maxTokens: 400,
          })
          : { ok: false, error: 'CHUA_CO_MO_HINH' };
        if (!kq.ok) return { ok: false, loi: 'MO_HINH_KHONG_TRA_LOI', lyDo: kq.error };
        const soat = this._soatBanThao(kq.text);
        if (!soat.dat) return { ok: false, loi: 'BAN_THAO_KHONG_DAT', choSai: soat.loi, banThaoHong: kq.text.slice(0, 300) };
        return {
          ok: true, banThao: kq.text, chuDe,
          moHinh: kq.provider,
          daSoat: ['bức tường phân loại nội bộ', 'bộ soát tiếng Việt'],
          canLam: 'Bản thảo này chưa đăng.',
        };
      },
    }));

    // ── MỨC 3 · GHI VÀO SỔ NHÀ ───────────────────────────────────────────

    this.dangKy(new CongCu({
      ten: 'ghi_tuong_tac',
      moTa: 'Ghi lại một lần trao đổi với gia đình.',
      thamSo: { giaDinhId: 'mã gia đình', kieu: 'gọi điện / nhắn tin / gặp mặt', tomTat: 'tóm tắt', viecPhaiLam: 'danh sách việc' },
      mucDongCham: 3,
      chay: async ({ giaDinhId = null, kieu = 'khac', tomTat = '', viecPhaiLam = [] }, boiCanh = {}) => {
        if (!tomTat || String(tomTat).trim().length < 5) return { ok: false, loi: 'THIEU_TOM_TAT' };
        if (giaDinhId && !K.giaDinh.get(giaDinhId)) return { ok: false, loi: 'KHONG_CO_GIA_DINH' };
        const { id: newId } = require('../utils');
        const d = {
          id: newId('TT'),
          giaDinhId: giaDinhId || null,
          phienId: boiCanh.phienId || null,
          troLyMa: boiCanh.troLyMa || null,
          kieu, tomTat: String(tomTat).slice(0, 2000),
          viecPhaiLam: Array.isArray(viecPhaiLam) ? viecPhaiLam.map(String).slice(0, 20) : [],
          luc: Date.now(),
        };
        K.tuongTac.put(d);
        return { ok: true, daGhi: d.id, giaDinhId: d.giaDinhId, soViecPhaiLam: d.viecPhaiLam.length };
      },
    }));

    this.dangKy(new CongCu({
      ten: 'cap_nhat_diem',
      moTa: 'Chấm hoặc cập nhật một loại điểm cho gia đình. Bắt buộc kèm dấu hiệu.',
      thamSo: { giaDinhId: 'mã gia đình', loai: 'muc-quan-tam / muc-gan-bo / nguy-co-dung', giaTri: '0-100', dauHieu: 'danh sách dấu hiệu quan sát được' },
      mucDongCham: 3,
      chay: async ({ giaDinhId = null, loai = null, giaTri = null, dauHieu = [] }, boiCanh = {}) => {
        const r = K.chamDiem({
          giaDinhId, loai, giaTri: Number(giaTri), dauHieu,
          boi: boiCanh.troLyMa || 'crm',
        });
        return r.ok ? { ok: true, diem: r.diem } : { ok: false, loi: r.loi, lyDo: r.lyDo };
      },
    }));

    this.dangKy(new CongCu({
      ten: 'ghi_ho_so',
      moTa: 'Sửa một trường trong hồ sơ gia đình. Không có nhánh xoá.',
      thamSo: { giaDinhId: 'mã gia đình', truong: 'tenGoi hoặc chang', giaTri: 'giá trị mới' },
      mucDongCham: 3,
      chay: async ({ giaDinhId = null, truong = null, giaTri = null }, boiCanh = {}) => {
        const CHO_SUA = new Set(['tenGoi', 'chang']);
        if (!CHO_SUA.has(truong)) {
          return {
            ok: false, loi: 'TRUONG_KHONG_CHO_SUA',
            lyDo: `Chỉ sửa được: ${[...CHO_SUA].join(', ')}. Các trường khác là khoá nối sang kho khác, sửa là đứt nối.`,
          };
        }
        if (truong === 'chang') {
          const r = K.chuyenChang(giaDinhId, String(giaTri), { boi: boiCanh.troLyMa || 'crm' });
          return r.ok ? { ok: true, daSua: 'chang', giaTri } : { ok: false, loi: r.loi, lyDo: r.lyDo };
        }
        const gd = K.giaDinh.get(giaDinhId);
        if (!gd) return { ok: false, loi: 'KHONG_CO_GIA_DINH' };
        gd.tenGoi = String(giaTri).slice(0, 120);
        gd.capNhatLuc = Date.now();
        K.giaDinh.put(gd);
        return { ok: true, daSua: 'tenGoi', giaTri: gd.tenGoi };
      },
    }));

    // ── MỨC 4 · CHẠM RA NGOÀI ────────────────────────────────────────────

    this.dangKy(new CongCu({
      ten: 'gui_thu',
      moTa: 'Gửi thư thật tới gia đình. LUÔN phải có người duyệt, không có ngoại lệ.',
      thamSo: { giaDinhId: 'gia đình nhận', tieuDe: 'tiêu đề', noiDung: 'nội dung đã soạn' },
      mucDongCham: 4,
      chay: async ({ giaDinhId = null, tieuDe = '', noiDung = '' }) => {
        // Công cụ này KHÔNG tự gửi, kể cả khi được gọi thẳng. Tầng điều phối đã
        // chặn ở trên, nhưng chặn hai lần ở hai tầng khác nhau là cố ý: một
        // ngày nào đó ai đó gọi thẳng vào đây và quên mất tầng trên.
        const soat = this._soatBanThao(`${tieuDe}\n${noiDung}`);
        if (!soat.dat) return { ok: false, loi: 'NOI_DUNG_KHONG_DAT', choSai: soat.loi };
        const gd = giaDinhId ? K.giaDinh.get(giaDinhId) : null;
        if (!gd) return { ok: false, loi: 'KHONG_CO_GIA_DINH' };
        return {
          ok: false,
          loi: 'PHAI_CO_NGUOI_DUYET',
          lyDo: 'Không một trợ lý AI nào được tự gửi thư tới một gia đình. Việc này đã được đưa vào hàng chờ duyệt.',
          deXuat: { giaDinhId, tieuDe: String(tieuDe).slice(0, 200), noiDung: String(noiDung).slice(0, 4000) },
        };
      },
    }));
  }

  status() {
    const theoMuc = {};
    for (const c of this._ds.values()) theoMuc[c.mucDongCham] = (theoMuc[c.mucDongCham] || 0) + 1;
    return { tong: this._ds.size, theoMucDongCham: theoMuc };
  }
}

module.exports = KhoCongCu;
module.exports.CongCu = CongCu;
