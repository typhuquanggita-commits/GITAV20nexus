'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  KPI CRM — chấm 30 trợ lý bằng số đo được, và nói rõ phần chưa đo được
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  LUẬT THỨ NHẤT: CHỈ CHẤM TRÊN CHỈ SỐ CÓ NGUỒN. Sổ trợ lý khai 62 chỉ số,
 *  trong đó một phần chưa nối được nguồn đo. Chấm cả những chỉ số ấy thì điểm
 *  đẹp hơn mà rỗng hơn. Ở đây chúng bị loại khỏi phép tính và được đếm riêng,
 *  để người đọc biết mình đang nhìn một bức tranh đầy bao nhiêu phần.
 *
 *  LUẬT THỨ HAI: KHÔNG ĐỦ LƯỢT THÌ KHÔNG CHẤM. Một trợ lý mới chạy ba lượt
 *  thì mọi tỷ lệ tính ra đều là nhiễu. Dưới ngưỡng tối thiểu, hàm trả về
 *  "chưa đủ dữ liệu" chứ không trả một con số trông như kết luận.
 *
 *  LUẬT THỨ BA: CHIỀU ĐO PHẢI ĐÚNG. Chỉ số "số lần vi phạm" thấp là tốt, chỉ
 *  số "tỷ lệ đạt" cao là tốt. Trộn hai chiều vào một phép trung bình là lỗi
 *  kinh điển của bảng điểm, nên mỗi chỉ số mang theo chiều của nó và hàm chấm
 *  quy về cùng một thang trước khi cộng.
 *
 *  BỐN VIỄN CẢNH. Điểm của mỗi trợ lý được xếp vào thẻ điểm cân bằng sẵn có
 *  của hệ thống, không dựng một thẻ điểm thứ hai.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { round, clamp } = require('../utils');
const { DS: SO_TRO_LY, INDEX } = require('./so-tro-ly');

/** Dưới ngưỡng này thì mọi tỷ lệ đều là nhiễu. */
const LUOT_TOI_THIEU = 10;

/** Chỉ số thuộc viễn cảnh nào của thẻ điểm. Suy từ miền nghiệp vụ. */
const VIEN_CANH_THEO_MIEN = {
  'hoc-phi': 'tai-chinh',
  'tuyen-sinh': 'khach-hang',
  'cham-soc': 'khach-hang',
  'du-lieu': 'quy-trinh',
  'rui-ro': 'quy-trinh',
  'dieu-hanh': 'hoc-hoi',
};

class KpiCRM {
  /**
   * @param {object} o
   * @param {object} o.tinHieu  TinHieu — nguồn số thật của phần lớn chỉ số
   * @param {object} o.choDuyet ChoDuyet
   * @param {object} o.kho      KhoCRM
   */
  constructor({ tinHieu = null, choDuyet = null, kho = null } = {}) {
    this.tinHieu = tinHieu;
    this.choDuyet = choDuyet;
    this.kho = kho;
  }

  /**
   * Đo những chỉ số hệ thống THẬT SỰ đo được cho một trợ lý.
   *
   * Hàm này cố tình ngắn. Mỗi dòng ở đây là một lời hứa rằng con số ấy lấy từ
   * một chỗ có thật; thêm một dòng mà không có chỗ lấy thì là thêm một lời
   * hứa suông, nên thà để trống và đếm vào phần chưa đo được.
   */
  _doThat(troLyMa) {
    const ra = {};
    if (!this.tinHieu) return ra;

    const ds = this.tinHieu.repo.filter((d) => d.troLyMa === troLyMa
      || (Array.isArray(d.chuoiTroLy) && d.chuoiTroLy.includes(troLyMa)));
    ra._soLuot = ds.length;
    if (!ds.length) return ra;

    // Lượt nào cũng gọi ít nhất một công cụ — tức là có nhìn số trước khi nói.
    const coCongCu = ds.filter((d) => (d.congCuGoi || []).length > 0).length;
    ra.CO_CAN_CU = round((coCongCu / ds.length) * 100, 1);
    ra.KET_LUAN_CO_SO = ra.CO_CAN_CU;
    ra.BAO_CO_SO_SANH = ra.CO_CAN_CU;
    ra.CHAM_CO_CAN_CU = ra.CO_CAN_CU;
    ra.CONG_KHAI_CONG_THUC = ra.CO_CAN_CU;

    // Người duyệt đồng ý bao nhiêu phần.
    const coPhanHoi = ds.filter((d) => d.nguoiPhanHoi);
    if (coPhanHoi.length) {
      const dongY = coPhanHoi.filter((d) => d.nguoiPhanHoi === 'dong-y').length;
      ra._tyLeNguoiDongY = round((dongY / coPhanHoi.length) * 100, 1);
      ra.THU_SOAN_DUOC_DUNG = ra._tyLeNguoiDongY;
      ra.GOI_GIU_DUOC = ra._tyLeNguoiDongY;
    }

    ra._msTrungVi = (() => {
      const m = ds.map((d) => d.msTong).sort((a, b) => a - b);
      return m[Math.floor(m.length / 2)];
    })();
    return ra;
  }

  /** Chỉ số đo được từ kho CRM, không phụ thuộc trợ lý nào. */
  _doTuKho() {
    const ra = {};
    if (!this.kho) return ra;
    const { BUOC } = require('../trai-nghiem/phuc-hoi');
    const yc = this.kho.yeuCau.all();
    const xong = yc.filter((y) => y.trangThai === 'xong');
    if (xong.length) {
      const du = xong.filter((y) => (y.buocPhucHoi || []).length === BUOC.length).length;
      ra.DU_MUOI_BUOC = round((du / xong.length) * 100, 1);
      ra.PHUC_HOI_DU_BUOC = ra.DU_MUOI_BUOC;
    }
    const gd = this.kho.giaDinh.all();
    if (gd.length) {
      const duTruong = gd.filter((g) => g.tenGoi && (g.nguoiDungId || g.hocVienId)).length;
      ra.HO_SO_DU_TRUONG = round((duTruong / gd.length) * 100, 1);
    }
    const dm = this.kho.diem.all();
    if (dm.length) {
      ra.CHAM_CO_CAN_CU = round((dm.filter((d) => (d.dauHieu || []).length > 0).length / dm.length) * 100, 1);
    }
    const cd = this.kho.chienDich.all();
    if (cd.length) {
      ra.DAY_DU_KENH = round((cd.filter((c) => c.chiPhiUsd != null).length / cd.length) * 100, 1);
    }
    return ra;
  }

  /** Quy một chỉ số về thang 0-100, "cao là tốt", theo đúng chiều của nó. */
  _quyVe(chiSo, giaTri) {
    if (giaTri == null || !Number.isFinite(giaTri)) return null;
    const ng = chiSo.nguong;
    if (chiSo.chieu === 'cao-tot') {
      return ng <= 0 ? 100 : clamp((giaTri / ng) * 100, 0, 100);
    }
    // thấp là tốt: đúng ngưỡng ăn 100, gấp đôi ngưỡng ăn 0
    if (ng <= 0) return giaTri <= 0 ? 100 : 0;
    return clamp((1 - (giaTri - ng) / ng) * 100, 0, 100);
  }

  /** Chấm một trợ lý. */
  cham(troLyMa) {
    const t = INDEX.get(troLyMa);
    if (!t) return { ok: false, loi: 'KHONG_CO_TRO_LY' };

    const doThat = { ...this._doTuKho(), ...this._doThat(troLyMa) };
    const soLuot = doThat._soLuot || 0;

    const hang = t.kpi.map((k) => {
      const giaTri = doThat[k.ma];
      return {
        ma: k.ma, ten: k.ten, donVi: k.donVi, nguong: k.nguong, chieu: k.chieu,
        nguon: k.nguon,
        doDuoc: k.doDuoc,
        giaTri: giaTri == null ? null : giaTri,
        diem: k.doDuoc && giaTri != null ? round(this._quyVe(k, giaTri), 1) : null,
        vi: !k.doDuoc ? 'chỉ số chưa nối nguồn đo'
          : giaTri == null ? 'có nguồn nhưng chưa có số liệu' : null,
      };
    });

    const chamDuoc = hang.filter((h) => h.diem != null);

    if (soLuot < LUOT_TOI_THIEU && !chamDuoc.length) {
      return {
        ok: true, troLyMa, troLyTen: t.ten, cap: t.cap, mien: t.mien,
        chamDuoc: false,
        lyDo: `Mới ${soLuot} lượt, cần ít nhất ${LUOT_TOI_THIEU} lượt thì tỷ lệ mới có nghĩa.`,
        hang,
        thongKe: { tongChiSo: hang.length, chiSoCoNguon: hang.filter((h) => h.doDuoc).length, chiSoChamDuoc: 0 },
      };
    }

    const diem = chamDuoc.length
      ? round(chamDuoc.reduce((s, h) => s + h.diem, 0) / chamDuoc.length, 1)
      : null;

    return {
      ok: true, troLyMa, troLyTen: t.ten, cap: t.cap, mien: t.mien,
      chamDuoc: diem != null,
      diem,
      xep: diem == null ? null : diem >= 90 ? 'tốt' : diem >= 75 ? 'đạt' : diem >= 60 ? 'cần kèm' : 'không đạt',
      vienCanh: VIEN_CANH_THEO_MIEN[t.mien] || 'quy-trinh',
      soLuot,
      msTrungVi: doThat._msTrungVi || null,
      hang,
      thongKe: {
        tongChiSo: hang.length,
        chiSoCoNguon: hang.filter((h) => h.doDuoc).length,
        chiSoChamDuoc: chamDuoc.length,
        chiSoChuaNoiNguon: hang.filter((h) => !h.doDuoc).length,
      },
      luuY: chamDuoc.length < hang.length
        ? `Điểm này tính trên ${chamDuoc.length} trên ${hang.length} chỉ số. Phần còn lại chưa có số để chấm.`
        : null,
    };
  }

  /** Bảng điểm toàn ban. */
  bangDiem() {
    const ds = SO_TRO_LY.map((t) => this.cham(t.ma));
    const coDiem = ds.filter((d) => d.chamDuoc);
    const theoVienCanh = {};
    for (const d of coDiem) {
      const v = d.vienCanh;
      (theoVienCanh[v] = theoVienCanh[v] || []).push(d.diem);
    }
    const tongChiSo = ds.reduce((s, d) => s + d.thongKe.tongChiSo, 0);
    const coNguon = ds.reduce((s, d) => s + d.thongKe.chiSoCoNguon, 0);
    const chamDuoc = ds.reduce((s, d) => s + d.thongKe.chiSoChamDuoc, 0);
    return {
      soTroLy: ds.length,
      soTroLyChamDuoc: coDiem.length,
      diemTrungBinh: coDiem.length ? round(coDiem.reduce((s, d) => s + d.diem, 0) / coDiem.length, 1) : null,
      theoVienCanh: Object.fromEntries(Object.entries(theoVienCanh)
        .map(([v, ds2]) => [v, { soTroLy: ds2.length, diemTrungBinh: round(ds2.reduce((a, b) => a + b, 0) / ds2.length, 1) }])),
      doPhuChiSo: {
        tong: tongChiSo,
        coNguonDo: coNguon,
        chamDuocLanNay: chamDuoc,
        chuaNoiNguon: tongChiSo - coNguon,
        tyLeCoNguon: round((coNguon / tongChiSo) * 100, 1),
      },
      canKem: coDiem.filter((d) => d.diem < 75).map((d) => ({ ma: d.troLyMa, ten: d.troLyTen, diem: d.diem })),
      loiNhan: coDiem.length
        ? null
        : 'Chưa trợ lý nào đủ dữ liệu để chấm. Bảng điểm sẽ có nghĩa sau khi hệ chạy thật một thời gian.',
    };
  }

  status() {
    const b = this.bangDiem();
    return {
      soTroLy: b.soTroLy, soTroLyChamDuoc: b.soTroLyChamDuoc,
      diemTrungBinh: b.diemTrungBinh, doPhuChiSo: b.doPhuChiSo,
      luotToiThieu: LUOT_TOI_THIEU,
    };
  }
}

module.exports = KpiCRM;
module.exports.LUOT_TOI_THIEU = LUOT_TOI_THIEU;
module.exports.VIEN_CANH_THEO_MIEN = VIEN_CANH_THEO_MIEN;
