'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  LỊCH VIỆC CRM — việc chạy nền, không cần lịch của hệ điều hành
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  NĂM VIỆC, và mỗi việc trả lời một câu hỏi có người thật đang chờ:
 *
 *      ban-tin-sang      7 giờ  — sáng nay ban này cần biết gì
 *      soi-cong-no       mỗi 6 giờ — kỳ nào vừa quá hạn
 *      quet-bat-thuong   mỗi giờ — có con số nào lệch khỏi thói quen không
 *      don-het-han       mỗi giờ — việc nào chờ duyệt quá lâu thì đóng lại
 *      cham-kpi          mỗi 24 giờ — bảng điểm tuần của ba mươi trợ lý
 *
 *  BA LUẬT CỦA LỊCH NÀY:
 *
 *  1. KHÔNG CHỒNG LƯỢT. Một việc đang chạy thì lần tới bỏ qua, không xếp
 *     hàng. Việc chạy chậm mà cứ xếp hàng thì tới lúc nào đó cả hàng cùng
 *     chạy một lúc và ăn hết tài nguyên.
 *
 *  2. HỎNG THÌ GHI, KHÔNG NGÃ. Một việc ném lỗi không được phép kéo sập vòng
 *     lặp; nhưng cũng không được nuốt lặng, vì một việc chết âm thầm thì sổ
 *     tay vẫn ghi là nó đang chạy.
 *
 *  3. ĐẾM GIỜ KHÔNG GIỮ TIẾN TRÌNH. Bộ đếm giờ dùng unref, nên nó không giữ
 *     cho tiến trình sống mãi khi mọi việc khác đã xong.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const L = require('../logger');

const NHIP_MS = 60_000;   // xem có việc nào tới lượt không, mỗi phút một lần

class MotViec {
  constructor({ ma, ten, moTa, moiMs = null, moiNgayLuc = null, chay }) {
    this.ma = ma;
    this.ten = ten;
    this.moTa = moTa;
    this.moiMs = moiMs;
    this.moiNgayLuc = moiNgayLuc;   // {gio, phut} theo giờ máy
    this.chay = chay;
    this.lanCuoi = null;
    this.soLan = 0;
    this.soLoi = 0;
    this.loiCuoi = null;
    this.dangChay = false;
    this.msLanCuoi = null;
  }

  toiLuotChua(bayGio) {
    if (this.dangChay) return false;
    if (this.moiNgayLuc) {
      const d = new Date(bayGio);
      const moc = new Date(bayGio);
      moc.setHours(this.moiNgayLuc.gio, this.moiNgayLuc.phut || 0, 0, 0);
      if (d < moc) return false;
      if (this.lanCuoi && new Date(this.lanCuoi).toDateString() === d.toDateString()) return false;
      return true;
    }
    if (this.moiMs) {
      if (!this.lanCuoi) return true;
      return bayGio - this.lanCuoi >= this.moiMs;
    }
    return false;
  }

  trangThai() {
    return {
      ma: this.ma, ten: this.ten, moTa: this.moTa,
      moiMs: this.moiMs, moiNgayLuc: this.moiNgayLuc,
      lanCuoi: this.lanCuoi, soLan: this.soLan, soLoi: this.soLoi,
      loiCuoi: this.loiCuoi, dangChay: this.dangChay, msLanCuoi: this.msLanCuoi,
    };
  }
}

class LichViec {
  /**
   * @param {object} o
   * @param {object} o.crm      DieuPhoiCRM
   * @param {function} o.bayGio
   */
  constructor({ crm, bayGio = () => Date.now() } = {}) {
    if (!crm) throw new Error('LichViec cần bộ điều phối CRM');
    this.crm = crm;
    this.bayGio = bayGio;
    this.viec = new Map();
    this._timer = null;
    this.banTinGanNhat = null;
    this._dungKy();
  }

  them(v) { this.viec.set(v.ma, v); return this; }

  _dungKy() {
    const crm = this.crm;

    this.them(new MotViec({
      ma: 'ban-tin-sang',
      ten: 'Bản tin sáng cho ban điều hành',
      moTa: 'Ba con số chính, ba việc cần làm ngay, tính từ dữ liệu thật lúc chạy.',
      moiNgayLuc: { gio: 7, phut: 0 },
      chay: async () => {
        const tq = crm.kho.tongQuan();
        const bd = crm.quanTri.banDieuKhien();
        const tin = {
          luc: this.bayGio(),
          baConSo: [
            { ten: 'Gia đình đang học', so: tq.theoChang['dang-hoc'] || 0 },
            { ten: 'Tiền học phí còn thiếu', so: tq.hocPhi.tienChuaThu, donVi: 'đồng' },
            { ten: 'Yêu cầu đang mở', so: tq.yeuCau.dangMo },
          ],
          viecCanLam: bd.viecCanLamNgay,
          nguon: 'Đếm trực tiếp trên kho CRM lúc chạy, không lấy từ bản tin trước.',
        };
        this.banTinGanNhat = tin;
        return tin;
      },
    }));

    this.them(new MotViec({
      ma: 'soi-cong-no',
      ten: 'Soi kỳ học phí vừa quá hạn',
      moTa: 'Chuyển trạng thái kỳ tới hạn thành quá hạn, và đếm lại công nợ.',
      moiMs: 6 * 3600_000,
      chay: async () => {
        const bayGio = this.bayGio();
        const toiHan = crm.kho.hocPhi.filter((d) => d.trangThai !== 'da-thu' && d.trangThai !== 'da-mien'
          && d.trangThai !== 'qua-han' && d.hanLuc && d.hanLuc < bayGio);
        for (const d of toiHan) crm.kho.capNhatHocPhi(d.id, 'qua-han', { boi: 'lich-viec' });
        return { daChuyenSangQuaHan: toiHan.length, congNo: crm.kho.congNo({}) };
      },
    }));

    this.them(new MotViec({
      ma: 'quet-bat-thuong',
      ten: 'Quét bất thường',
      moTa: 'So số hôm nay với chính hệ thống trong quá khứ, không so với số ngành.',
      moiMs: 3600_000,
      chay: async () => {
        const bao = [];
        const bd = crm.choDuyet.bangDo();
        if (bd.theoTrangThai && bd.theoTrangThai['het-han'] > 0) {
          bao.push({ muc: 'cao', viec: `${bd.theoTrangThai['het-han']} việc hết hạn chờ duyệt.`, nen: 'Xem ai đang chịu trách nhiệm duyệt.' });
        }
        const th = crm.tinHieu.bangTong();
        if (th.tong > 20 && th.thoiGian && th.thoiGian.msPhanVi90 > 15000) {
          bao.push({ muc: 'vua', viec: `Chín trên mười lượt xong dưới ${th.thoiGian.msPhanVi90} mili giây — chậm hơn thường lệ.`, nen: 'Xem lối định tuyến có đang phải hỏi mô hình nhiều không.' });
        }
        const bd2 = crm.kho.congNo({});
        if (bd2.soKy > 0 && bd2.tienQuaHan > bd2.tienChuaThu * 0.5) {
          bao.push({ muc: 'cao', viec: 'Quá nửa số tiền chưa thu đã quá hạn.', nen: 'Xem lại nhịp nhắc học phí.' });
        }
        return { soBaoDong: bao.length, baoDong: bao, mocSoSanh: 'chính hệ thống ở lần quét trước' };
      },
    }));

    this.them(new MotViec({
      ma: 'don-het-han',
      ten: 'Đóng việc chờ duyệt quá hạn',
      moTa: 'Im lặng không bao giờ được tính là đồng ý.',
      moiMs: 3600_000,
      chay: async () => crm.choDuyet.donHetHan(),
    }));

    this.them(new MotViec({
      ma: 'cham-kpi',
      ten: 'Chấm bảng điểm ba mươi trợ lý',
      moTa: 'Chấm trên chỉ số có nguồn, và nói rõ còn bao nhiêu chỉ số chưa nối nguồn.',
      moiMs: 24 * 3600_000,
      chay: async () => crm.kpi.bangDiem(),
    }));
  }

  async _chayMot(v) {
    v.dangChay = true;
    const t0 = this.bayGio();
    try {
      const kq = await v.chay();
      v.lanCuoi = this.bayGio();
      v.soLan++;
      v.msLanCuoi = v.lanCuoi - t0;
      v.ketQuaCuoi = kq;
      return kq;
    } catch (e) {
      v.soLoi++;
      v.loiCuoi = e.message;
      v.lanCuoi = this.bayGio();
      L.warn(`Lịch việc CRM: "${v.ten}" hỏng — ${e.message}`);
      return null;
    } finally {
      v.dangChay = false;
    }
  }

  _nhip() {
    const bayGio = this.bayGio();
    for (const v of this.viec.values()) {
      if (v.toiLuotChua(bayGio)) this._chayMot(v);
    }
  }

  bat() {
    if (this._timer) return this;
    this._timer = setInterval(() => this._nhip(), NHIP_MS);
    if (this._timer.unref) this._timer.unref();
    L.ok(`Lịch việc CRM: ${this.viec.size} việc chạy nền, nhịp ${NHIP_MS / 1000} giây`);
    return this;
  }

  tat() { if (this._timer) { clearInterval(this._timer); this._timer = null; } }

  /** Chạy tay một việc, không chờ tới lượt. */
  async chayNgay(ma) {
    const v = this.viec.get(ma);
    if (!v) return { ok: false, loi: 'KHONG_CO_VIEC', coSan: [...this.viec.keys()] };
    if (v.dangChay) return { ok: false, loi: 'DANG_CHAY' };
    const kq = await this._chayMot(v);
    return { ok: kq != null, ma, ketQua: kq, loi: kq == null ? v.loiCuoi : null };
  }

  status() {
    return {
      dangChay: !!this._timer,
      nhipGiay: NHIP_MS / 1000,
      soViec: this.viec.size,
      viec: [...this.viec.values()].map((v) => v.trangThai()),
      banTinGanNhat: this.banTinGanNhat,
    };
  }
}

module.exports = LichViec;
module.exports.MotViec = MotViec;
module.exports.NHIP_MS = NHIP_MS;
