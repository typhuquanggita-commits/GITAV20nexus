'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  KHÔNG GIAN BA CHIỀU — toán chiếu, viết tay, không một gói ngoài nào
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Vẽ ba chiều không cần thư viện đồ hoạ. Nó cần đúng bốn việc, và cả bốn đều
 *  là hình học phổ thông:
 *
 *      1. Xoay điểm quanh trục dọc và trục ngang
 *      2. Chiếu phối cảnh: xa thì nhỏ lại
 *      3. Xếp theo chiều sâu: vẽ xa trước, gần sau, để gần che xa
 *      4. Mờ dần theo xa: cho mắt đọc được chiều sâu
 *
 *  TẤT ĐỊNH TUYỆT ĐỐI. Không Math.random, không thời gian hệ thống. Cùng một
 *  sơ đồ và cùng một góc nhìn thì ra cùng một tệp ảnh tới từng chữ số. Đây là
 *  luật của cả hệ này, và ở đây nó còn có lợi riêng: ảnh dựng ở máy chủ đem
 *  so được với ảnh dựng ở trình duyệt, nên lệch một chút là biết ngay.
 *
 *  VÌ SAO KHÔNG DÙNG WebGL. Trình duyệt có sẵn WebGL, nhưng nó cần một thư
 *  viện để dùng cho ra hồn, cần card màn hình chạy được — mà máy tính trường
 *  học thì thường không — và KHÔNG dựng được ở máy chủ. Sơ đồ ở đây phải in
 *  ra giấy được, phải nhúng vào báo cáo được, phải mở được trên máy cũ. SVG
 *  làm được cả ba; WebGL không làm được cái nào.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { round } = require('../utils');

/** Khoảng cách từ mắt tới màn hình. Lớn thì phối cảnh nhẹ, nhỏ thì méo mạnh. */
const TIEU_CU = 900;

/**
 * Xoay một điểm quanh trục DỌC (trái phải) rồi quanh trục NGANG (lên xuống).
 *
 * Thứ tự có nghĩa: xoay dọc trước rồi ngang sau cho cảm giác "xoay quả địa
 * cầu" — đúng cách tay người quen xoay một vật. Đảo thứ tự thì cùng hai góc
 * ấy ra một tư thế khác, và người dùng sẽ thấy nó lạ tay.
 */
function xoay({ x, y, z }, gocDoc, gocNgang) {
  const cd = Math.cos(gocDoc);
  const sd = Math.sin(gocDoc);
  const x1 = x * cd - z * sd;
  const z1 = x * sd + z * cd;

  const cn = Math.cos(gocNgang);
  const sn = Math.sin(gocNgang);
  const y2 = y * cn - z1 * sn;
  const z2 = y * sn + z1 * cn;

  return { x: x1, y: y2, z: z2 };
}

/**
 * Chiếu một điểm ba chiều xuống mặt phẳng hai chiều.
 *
 * Điểm ở SAU mắt thì không chiếu được — chia cho một số âm ra một điểm lật
 * ngược, và trên màn hình nó thành một vệt bay ngang qua giữa hình. Trả về
 * null để chỗ gọi bỏ điểm ấy đi, thay vì vẽ ra một thứ vô nghĩa.
 */
function chieu({ x, y, z }, { tieuCu = TIEU_CU, tamX = 0, tamY = 0 } = {}) {
  const d = tieuCu + z;
  if (d <= 1) return null;
  const k = tieuCu / d;
  return { x: tamX + x * k, y: tamY + y * k, k, z };
}

/**
 * Chiếu cả một danh sách điểm và XẾP THEO CHIỀU SÂU.
 *
 * Xa vẽ trước, gần vẽ sau — trong SVG thì thứ vẽ sau nằm đè lên thứ vẽ trước,
 * nên xếp đúng thứ tự này là có che khuất mà không cần bộ đệm chiều sâu.
 */
function chieuDanhSach(diem, { gocDoc = 0, gocNgang = 0, tieuCu = TIEU_CU, tamX = 0, tamY = 0 } = {}) {
  const ra = [];
  for (const d of diem) {
    const q = xoay(d, gocDoc, gocNgang);
    const p = chieu(q, { tieuCu, tamX, tamY });
    if (!p) continue;
    ra.push({ ...d, man: { x: round(p.x, 2), y: round(p.y, 2) }, tiLe: round(p.k, 4), sau: round(q.z, 2) });
  }
  // Số lớn = xa hơn = vẽ trước.
  return ra.sort((a, b) => b.sau - a.sau);
}

/**
 * Độ mờ theo chiều sâu.
 *
 * Mắt đọc chiều sâu bằng ba dấu hiệu: to nhỏ, che khuất, và độ tương phản.
 * Hai cái đầu đã có sẵn từ phép chiếu; cái thứ ba phải tự làm. Không có nó
 * thì hình trông như một mớ phẳng chồng lên nhau.
 *
 * Sàn 0,25 có chủ ý: mờ hơn nữa thì chữ không đọc được, mà một sơ đồ kiến
 * thức không đọc được thì không còn là sơ đồ kiến thức.
 */
function moTheoSau(sau, { gan = -400, xa = 400, sanMo = 0.25 } = {}) {
  if (sau <= gan) return 1;
  if (sau >= xa) return sanMo;
  const t = (sau - gan) / (xa - gan);
  return round(1 - t * (1 - sanMo), 3);
}

/**
 * Xếp các nút lên một hình trụ xoắn.
 *
 * VÌ SAO HÌNH TRỤ, KHÔNG PHẢI HÌNH CẦU. Kiến thức ở đây có một trục tự nhiên:
 * đi từ dễ tới khó. Trục ấy phải nhìn thấy được, nên nó thành trục dọc của
 * hình trụ — nhìn từ bên cạnh là thấy ngay đường đi lên. Hình cầu thì đẹp hơn
 * nhưng mất hẳn trục ấy, và mất trục thì người học không biết mình đang ở đâu.
 *
 * Trong mỗi tầng, các nút rải đều quanh vòng tròn. Góc lệch giữa hai tầng kề
 * nhau để tầng trên không che đúng tầng dưới.
 *
 * @param {number} i      thứ tự nút trong tầng
 * @param {number} tong   tổng số nút trong tầng
 * @param {number} tang   tầng thứ mấy, 0 là thấp nhất
 * @param {number} soTang tổng số tầng
 */
function viTriTruXoan(i, tong, tang, soTang, { banKinh = 260, cao = 520, lechTang = 0.38 } = {}) {
  const goc = tong <= 1 ? 0 : (i / tong) * Math.PI * 2;
  const gocThat = goc + tang * lechTang;
  // Tầng mỏng thì kéo bán kính vào trong: một tầng có hai nút mà trải rộng
  // bằng tầng hai mươi nút thì nhìn rỗng và lệch.
  const r = banKinh * (tong <= 2 ? 0.45 : tong <= 5 ? 0.72 : 1);
  const y = soTang <= 1 ? 0 : (tang / (soTang - 1) - 0.5) * cao;
  return {
    x: round(Math.cos(gocThat) * r, 2),
    y: round(-y, 2),                    // trục y của màn hình hướng xuống
    z: round(Math.sin(gocThat) * r, 2),
  };
}

module.exports = { xoay, chieu, chieuDanhSach, moTheoSau, viTriTruXoan, TIEU_CU };
