'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  KHO VĂN BẢN TIẾNG ANH — viết tay, không sinh bằng máy
 * ═══════════════════════════════════════════════════════════════════════════
 *  Bốn dạng đọc hiểu ý chính, đọc hiểu suy luận, viết luận và nói theo chủ đề
 *  KHÔNG ghép được bằng máy: ghép câu ra một đoạn không có ý chính nào để hỏi.
 *  Nên phần văn bản của bốn dạng đó nằm ở đây, từng đoạn một, viết tay.
 *
 *  Điều máy vẫn làm được — và làm rất nghiêm — là KIỂM CHẤT LƯỢNG ĐỀ: đọc lại
 *  chính đoạn văn rồi đo quan hệ giữa từng phương án với văn bản. Xem
 *  src/lang/en-verifier.js. Mỗi đơn vị dưới đây đều phải qua phép đo ấy trước
 *  khi vào kho; đơn vị nào không qua thì sửa VĂN BẢN, không hạ ngưỡng đo.
 *
 *  Quy ước viết đoạn, để phép đo có chỗ bấu víu:
 *    · đoạn tránh các từ phạm vi (all, every, always, never, only) và các từ
 *      phủ định (not, no, never, without) — nhờ vậy nhiễu "quá rộng" và nhiễu
 *      "trái bài" nhận ra được bằng chính sự có mặt của những từ đó;
 *    · phương án đúng là một câu TỔNG HỢP, nói lại ý của nhiều câu, nên không
 *      câu nào của đoạn chứa đủ nó;
 *    · nhiễu "chi tiết" lấy đúng từ ngữ của MỘT câu trong đoạn.
 *
 *  Cấp lớp ghi theo thang Mỹ (grade), đã đối chiếu độ dài câu và vốn từ.
 * ═══════════════════════════════════════════════════════════════════════════
 */

// ── ĐỌC HIỂU Ý CHÍNH ────────────────────────────────────────────────────────
const DOAN_Y_CHINH = [
  {
    ma: 'YC01', lop: 4, chuDe: 'school garden',
    doan: 'The garden behind Lincoln Middle School began as a patch of weeds. '
      + 'Two science teachers asked their students to clear the ground and build raised beds from scrap lumber. '
      + 'Sixth graders planted lettuce and beans in the spring and measured the seedlings each week. '
      + 'In the fall the class harvested enough vegetables to supply the cafeteria salad bar for a month. '
      + 'The teachers say the garden is where students watch the science lessons in their textbook turn real.',
    dung: 'A school garden that students planted became a source of vegetables for the cafeteria and a place for science lessons.',
    nhieu: [
      { y: 'Sixth graders measured lettuce and bean seedlings each week in the spring.', loai: 'chi-tiet' },
      { y: 'The principal hired a professional chef to redesign the lunch menu.', loai: 'ngoai-bai' },
      { y: 'Every middle school in the country grows the vegetables its cafeteria serves.', loai: 'qua-rong' },
    ],
  },
  {
    ma: 'YC02', lop: 4, chuDe: 'public library',
    doan: 'The Riverside public library used to close at four in the afternoon. '
      + 'Parents told the city council that their children had nowhere quiet to study after school. '
      + 'Last year the library began staying open until seven on weekdays. '
      + 'A reading room on the second floor now holds thirty students most evenings. '
      + 'Librarians report that the number of books borrowed by teenagers has doubled since the change.',
    dung: 'Staying open until seven gave students a quiet place to study after school, and the number of books borrowed by teenagers doubled.',
    nhieu: [
      { y: 'A reading room on the second floor holds thirty students most evenings.', loai: 'chi-tiet' },
      { y: 'The council voted to demolish the old swimming pool near the harbour.', loai: 'ngoai-bai' },
      { y: 'Every public library should always stay open until seven in the evening.', loai: 'qua-rong' },
    ],
  },
  {
    ma: 'YC03', lop: 5, chuDe: 'bicycle lanes',
    doan: 'Five years ago the streets around the town centre carried heavy traffic and few bicycles. '
      + 'The council painted protected lanes along four main roads and added racks outside the shops. '
      + 'Counters buried in the road show that bicycle trips have risen by half since the lanes appeared. '
      + 'Shop owners at first worried about losing parking spaces for cars. '
      + 'Sales figures from the same shops have climbed, because a bicycle rack holds ten riders in the space one car needs.',
    dung: 'Protected lanes and racks brought many more riders into the town centre, and the shops there sold more rather than less.',
    nhieu: [
      { y: 'Counters buried in the road show bicycle trips have risen by half.', loai: 'chi-tiet' },
      { y: 'The mayor announced a new railway station beside the football stadium.', loai: 'ngoai-bai' },
      { y: 'Every town that paints bicycle lanes always sees its shops earn more.', loai: 'qua-rong' },
    ],
  },
  {
    ma: 'YC04', lop: 6, chuDe: 'teenage sleep',
    doan: 'During adolescence the body clock shifts, and most teenagers grow sleepy about two hours later than younger children. '
      + 'Schools that open at half past seven ask those students to learn while their bodies are still resting. '
      + 'A district in Minnesota moved its start time to half past eight and tracked the results for three years. '
      + 'Attendance rose, and crashes involving student drivers fell by a fifth. '
      + 'Teachers in the district describe first period as a lesson their class can finally follow.',
    dung: 'Because the adolescent body clock shifts later, a school that starts later sees better attendance, fewer crashes and classes that can follow the lesson.',
    nhieu: [
      { y: 'Attendance rose and crashes involving student drivers fell by a fifth.', loai: 'chi-tiet' },
      { y: 'Coaches asked the league to move football practice to the weekend.', loai: 'ngoai-bai' },
      { y: 'Every school district everywhere should always begin the day at half past eight.', loai: 'qua-rong' },
    ],
  },
  {
    ma: 'YC05', lop: 5, chuDe: 'recycling bottles',
    doan: 'A plastic bottle thrown into a household bin is buried in the ground for centuries. '
      + 'The same bottle, washed and sorted, returns as fibre for a jacket or as another bottle. '
      + 'Sorting is the step that decides which of those two futures the bottle meets. '
      + 'A single greasy food container can spoil a whole load at the recycling plant. '
      + 'Workers there say a rinsed container costs a household ten seconds and saves a tonne of material.',
    dung: 'The sorting and rinsing a household does decides whether a plastic bottle is buried for centuries or returns as fibre.',
    nhieu: [
      { y: 'A single greasy food container can spoil a whole load at the recycling plant.', loai: 'chi-tiet' },
      { y: 'Scientists have invented an engine that runs on seawater and sunlight.', loai: 'ngoai-bai' },
      { y: 'Every plastic bottle in the world is always recycled into a jacket.', loai: 'qua-rong' },
    ],
  },
  {
    ma: 'YC06', lop: 6, chuDe: 'peer tutoring',
    doan: 'At Fairview High a group of seniors spends two lunch periods a week helping ninth graders with algebra. '
      + 'The seniors receive no payment and sign up for a full semester. '
      + 'Ninth graders in the programme raised their course grades by an average of nine points. '
      + 'The surprise came from the tutors themselves, whose own test scores rose as well. '
      + 'Explaining a method out loud forces a tutor to find the gaps in what they understand.',
    dung: 'A tutoring programme run by seniors lifted the grades of the ninth graders and, because explaining exposes gaps, the scores of the tutors as well.',
    nhieu: [
      { y: 'The seniors receive no payment and sign up for a full semester.', loai: 'chi-tiet' },
      { y: 'The district bought tablets for the elementary school computer laboratory.', loai: 'ngoai-bai' },
      { y: 'Every student who tutors another student always earns a higher score.', loai: 'qua-rong' },
    ],
  },
  {
    ma: 'YC07', lop: 6, chuDe: 'honeybees',
    doan: 'A honeybee visiting a flower is gathering food for its hive rather than working for the farmer. '
      + 'Pollen caught in the hairs of the bee travels to the next blossom and fertilises it. '
      + 'Roughly a third of the crops on an American dinner plate depend on that accidental delivery. '
      + 'Almond orchards in California rent two million hives each February for three weeks of bloom. '
      + 'Growers who lose their bees lose the harvest, whatever the weather does.',
    dung: 'A bee gathering food for its hive fertilises the next blossom, and a third of the American dinner plate depends on that accidental delivery.',
    nhieu: [
      { y: 'Almond orchards in California rent two million hives each February for three weeks of bloom.', loai: 'chi-tiet' },
      { y: 'Researchers designed a robot that repairs underwater pipelines.', loai: 'ngoai-bai' },
      { y: 'Every crop grown anywhere always depends entirely on honeybees.', loai: 'qua-rong' },
    ],
  },
  {
    ma: 'YC08', lop: 7, chuDe: 'desert plants',
    doan: 'Rain falls on the Sonoran Desert for a few hours in July and again in December. '
      + 'A saguaro cactus meets those two short gifts with roots that spread sideways just below the surface. '
      + 'Within a day the trunk swells and stores water in pleats that open like an accordion. '
      + 'A waxy skin and spines instead of leaves hold that water against the sun. '
      + 'The plant then lives on the stored supply through eleven dry months.',
    dung: 'The saguaro survives eleven dry months by catching brief rain with shallow roots, storing the water in its pleated trunk and holding it with a waxy skin.',
    nhieu: [
      { y: 'A waxy skin and spines instead of leaves hold water against the sun.', loai: 'chi-tiet' },
      { y: 'Geologists discovered a copper deposit beneath the frozen tundra.', loai: 'ngoai-bai' },
      { y: 'Every desert plant everywhere stores all of its water in a pleated trunk.', loai: 'qua-rong' },
    ],
  },
  {
    ma: 'YC09', lop: 7, chuDe: 'Roman roads',
    doan: 'Roman engineers laid their roads in four layers, beginning with a bed of heavy stone. '
      + 'Above it came gravel, then sand, then a surface of fitted slabs raised in the middle. '
      + 'The raised crown sent rainwater into ditches dug along both sides. '
      + 'Water is what destroys a road, and the Roman design removed it at once. '
      + 'Stretches of that pavement carry traffic in Italy and Spain after twenty centuries.',
    dung: 'Roman roads have lasted twenty centuries because their four layers and raised crown sent water into side ditches instead of into the pavement.',
    nhieu: [
      { y: 'Gravel, sand and a surface of fitted slabs were raised in the middle above it.', loai: 'chi-tiet' },
      { y: 'Archaeologists translated a merchant contract written on bamboo strips.', loai: 'ngoai-bai' },
      { y: 'Every road the Romans built anywhere is still completely in use.', loai: 'qua-rong' },
    ],
  },
  {
    ma: 'YC10', lop: 7, chuDe: 'weather balloons',
    doan: 'Twice a day, at the same hour worldwide, meteorologists release hydrogen balloons from eight hundred stations. '
      + 'A small instrument package hanging below each balloon radios back temperature, humidity and wind. '
      + 'The balloon expands as the air thins and bursts near thirty kilometres above the ground. '
      + 'Forecast models swallow those readings and redraw the atmosphere every six hours. '
      + 'Satellites photograph clouds from above, yet the balloons supply the column of numbers inside them.',
    dung: 'Balloons released worldwide twice a day radio back readings from inside the atmosphere, and forecast models redraw the air from those numbers.',
    nhieu: [
      { y: 'The balloon expands as the air thins and bursts near thirty kilometres up.', loai: 'chi-tiet' },
      { y: 'Engineers repaired a telescope mirror damaged during transport.', loai: 'ngoai-bai' },
      { y: 'Every forecast issued anywhere always comes entirely from weather balloons.', loai: 'qua-rong' },
    ],
  },
  {
    ma: 'YC11', lop: 5, chuDe: 'lunch waste',
    doan: 'A study at Oakmont Elementary weighed what the students threw away at lunch for a fortnight. '
      + 'Fruit and vegetables made up the greatest share of the waste. '
      + 'Staff then moved recess to the period before lunch rather than after it. '
      + 'Children who had already run outside came to the table hungry and ate what was on it. '
      + 'The scales at the end of the second fortnight showed a third of the waste gone.',
    dung: 'Weighing the lunch waste and then moving recess before lunch sent hungrier children to the table and cut the waste by a third.',
    nhieu: [
      { y: 'Fruit and vegetables made up the greatest share of the waste.', loai: 'chi-tiet' },
      { y: 'The school board approved a contract for a new gymnasium roof.', loai: 'ngoai-bai' },
      { y: 'Every school that moves recess always eliminates all of its lunch waste.', loai: 'qua-rong' },
    ],
  },
  {
    ma: 'YC12', lop: 8, chuDe: 'migrating birds',
    doan: 'An Arctic tern hatched in Greenland reaches the seas near Antarctica by December. '
      + 'The bird weighs about a hundred grams and covers seventy thousand kilometres in a year. '
      + 'Geolocators the size of a fingernail recorded a route that follows the wind rather than the shortest line. '
      + 'Terns cross the Atlantic in a long curve, riding systems that push them along. '
      + 'The detour costs distance and saves the one thing the bird cannot carry, which is fuel.',
    dung: 'Terns fly a curving route rather than the shortest line because riding the wind saves the fuel a hundred gram bird cannot carry.',
    nhieu: [
      { y: 'Geolocators the size of a fingernail recorded a route following the wind rather than the shortest line.', loai: 'chi-tiet' },
      { y: 'Marine biologists tagged a shark population near the Galapagos trench.', loai: 'ngoai-bai' },
      { y: 'Every migrating bird everywhere always follows the wind instead of a straight line.', loai: 'qua-rong' },
    ],
  },
  {
    ma: 'YC13', lop: 8, chuDe: 'volcanic soil',
    doan: 'Ash from an eruption smothers the fields around a volcano and ends a season of farming. '
      + 'The same ash carries potassium, phosphorus and minerals ground fine enough for roots to reach. '
      + 'Rain weathers the deposit over a few decades into soil of unusual richness. '
      + 'Java supports a thousand people on each square kilometre of such land. '
      + 'Villages rebuild on the slope because the danger and the harvest come from one mountain.',
    dung: 'The ash that ruins a season also weathers into rich soil, which is why villages accept the danger and rebuild on the slope.',
    nhieu: [
      { y: 'Java supports a thousand people on each square kilometre of such land.', loai: 'chi-tiet' },
      { y: 'Astronomers measured the orbit of a comet approaching Jupiter.', loai: 'ngoai-bai' },
      { y: 'Every volcano in the world always produces completely fertile soil.', loai: 'qua-rong' },
    ],
  },
  {
    ma: 'YC14', lop: 8, chuDe: 'maps and memory',
    doan: 'Drivers following a phone hear an instruction and obey it one turn at a time. '
      + 'Drivers reading a paper map first build a picture of how the streets fit together. '
      + 'In a study at Nottingham the map group drew the district afterwards with far greater accuracy. '
      + 'The phone group arrived sooner and remembered the route poorly. '
      + 'Attention spent on a single instruction leaves little for the shape of the city.',
    dung: 'A phone gets a driver there sooner, while reading a map builds the picture of the city that turn by turn instructions leave behind.',
    nhieu: [
      { y: 'The phone group arrived sooner and remembered the route poorly.', loai: 'chi-tiet' },
      { y: 'A publisher released an atlas printed on waterproof fabric.', loai: 'ngoai-bai' },
      { y: 'Every driver who uses a phone always forgets every street completely.', loai: 'qua-rong' },
    ],
  },
  {
    ma: 'YC15', lop: 6, chuDe: 'sea turtles and light',
    doan: 'A loggerhead hatchling digs out of the sand at night and heads for the brightest horizon. '
      + 'For a hundred million years that horizon was the sea under the moon. '
      + 'Hotels along the Florida coast now throw more light landward than the water reflects. '
      + 'Hatchlings turn inland towards the car parks and die before morning. '
      + 'Counties that shield their lamps and switch to amber bulbs return the brightest horizon to the sea.',
    dung: 'Hatchlings head for the brightest horizon, so hotel light turns them inland until a county shields its lamps and returns that horizon to the sea.',
    nhieu: [
      { y: 'Hotels along the Florida coast throw more light landward than the water reflects.', loai: 'chi-tiet' },
      { y: 'A shipping company redesigned its containers to stack more tightly.', loai: 'ngoai-bai' },
      { y: 'Every hatchling on every beach always dies because of hotel lamps.', loai: 'qua-rong' },
    ],
  },
  {
    ma: 'YC16', lop: 5, chuDe: 'rainwater tanks',
    doan: 'A roof of a hundred square metres sheds ten thousand litres in a year of modest rainfall. '
      + 'Most of that water runs into a drain within minutes of landing. '
      + 'A tank beside the house catches the flow and holds it for the dry weeks. '
      + 'Households in Adelaide that installed tanks cut their mains use by a third. '
      + 'The saving grows in the months when the garden is thirstiest and the reservoir is lowest.',
    dung: 'A tank beside the house keeps roof water that would run into a drain, and households using one cut their mains supply by a third.',
    nhieu: [
      { y: 'Households in Adelaide that installed tanks cut their mains use by a third.', loai: 'chi-tiet' },
      { y: 'A factory began bottling mineral water from a mountain spring.', loai: 'ngoai-bai' },
      { y: 'Every house everywhere can always supply all of its water from one tank.', loai: 'qua-rong' },
    ],
  },
  {
    ma: 'YC17', lop: 4, chuDe: 'chess club',
    doan: 'The chess club at Carter Elementary opened with six members and a single board. '
      + 'A retired engineer came on Thursdays to teach the pieces and the rules. '
      + 'By the second year forty children were playing and the club ran a ladder tournament. '
      + 'Teachers noticed that the members were finishing their written work more carefully. '
      + 'A child who learns to look three moves ahead begins to check an answer before handing it in.',
    dung: 'A chess club that opened with six members and one board reached forty children, and teachers noticed those members finishing written work more carefully.',
    nhieu: [
      { y: 'A retired engineer came on Thursdays to teach the pieces and the rules.', loai: 'chi-tiet' },
      { y: 'The town opened a skate park beside the fire station last summer.', loai: 'ngoai-bai' },
      { y: 'Every child who plays chess always becomes completely careful at school.', loai: 'qua-rong' },
    ],
  },
  {
    ma: 'YC18', lop: 9, chuDe: 'coral reefs',
    doan: 'A coral animal houses algae in its tissue and lives on the sugar they make. '
      + 'Water a degree above the summer average for several weeks turns that partnership harmful. '
      + 'The coral expels the algae, loses its colour and stands white on the reef. '
      + 'A bleached colony survives for a few weeks and recovers if the water cools. '
      + 'Reefs struck twice within a decade lose the slow growing species and keep the weedy ones.',
    dung: 'Warm water breaks the partnership between the coral and its algae, and a reef struck twice within a decade keeps weedy species instead of slow growing ones.',
    nhieu: [
      { y: 'A bleached colony survives for a few weeks and recovers if the water cools.', loai: 'chi-tiet' },
      { y: 'A university opened a laboratory studying volcanic vents in Iceland.', loai: 'ngoai-bai' },
      { y: 'Every reef in every ocean is always completely destroyed by warm water.', loai: 'qua-rong' },
    ],
  },
];

// ── ĐỌC HIỂU SUY LUẬN ───────────────────────────────────────────────────────
//  Phương án đúng KHÔNG có sẵn trong câu nào của đoạn: nó nối hai dữ kiện lại.
//  Ba nhiễu hỏng theo ba kiểu khác nhau — nhắc lại điều bài đã nêu thẳng, nói
//  chuyện ngoài bài, hoặc phủ định điều bài khẳng định.
const DOAN_SUY_LUAN = [
  {
    ma: 'SL01', lop: 4, chuDe: 'missing the bus',
    doan: 'Maya leaves her house at seven each morning. '
      + 'The school bus reaches the corner at ten past seven. '
      + 'On Tuesday the bus came early and pulled away while Maya was walking down her street. '
      + 'Maya arrived at the corner at nine past seven and looked at the empty road. '
      + 'She sat down in her classroom after the first bell rang.',
    dung: 'On Tuesday the bus reached the corner before Maya did.',
    nhieu: [
      { y: 'Maya arrived at the corner at nine past seven.', loai: 'da-neu' },
      { y: 'Her father drives her to the swimming pool on Saturdays.', loai: 'ngoai-bai' },
      { y: 'Maya did not leave her house on Tuesday morning.', loai: 'trai-bai' },
    ],
  },
  {
    ma: 'SL02', lop: 5, chuDe: 'the bakery',
    doan: 'The bakery on Cross Street opens at six and bakes forty loaves of sourdough each day. '
      + 'A sign in the window says that bread is sold until it runs out. '
      + 'Customers who come at eight find the shelf of sourdough already bare. '
      + 'The owner has kept the same count of forty loaves for eleven years.',
    dung: 'The bakery has sold its forty loaves of sourdough before customers come at eight.',
    nhieu: [
      { y: 'The owner has kept the same count of forty loaves for eleven years.', loai: 'da-neu' },
      { y: 'A cousin of the owner runs a flower stall beside the railway platform.', loai: 'ngoai-bai' },
      { y: 'The bakery cannot sell its sourdough to customers at eight.', loai: 'trai-bai' },
    ],
  },
  {
    ma: 'SL03', lop: 5, chuDe: 'the soil test',
    doan: 'A farmer pushes a probe into the field and draws out a core of soil each spring. '
      + 'The laboratory returns a figure for nitrogen within a week. '
      + 'This spring the figure came back higher than the figure from last spring. '
      + 'The farmer ordered half the usual quantity of fertiliser for the field.',
    dung: 'The farmer buys fertiliser according to the nitrogen figure the laboratory returns.',
    nhieu: [
      { y: 'The laboratory returns a figure for nitrogen within a week.', loai: 'da-neu' },
      { y: 'His neighbour bought a second tractor at the county auction.', loai: 'ngoai-bai' },
      { y: 'The farmer did not order any fertiliser for the field this spring.', loai: 'trai-bai' },
    ],
  },
  {
    ma: 'SL04', lop: 6, chuDe: 'the lighthouse',
    doan: 'The lighthouse at Cape Ann was staffed by a keeper until 1988. '
      + 'An automatic lamp and a radio beacon were installed that autumn. '
      + 'The keeper cottage has stood empty since the installation. '
      + 'Ships passing the cape still report the same beam sweeping the water every twelve seconds.',
    dung: 'The beam at Cape Ann has kept sweeping since the keeper left the cottage.',
    nhieu: [
      { y: 'An automatic lamp and a radio beacon were installed that autumn.', loai: 'da-neu' },
      { y: 'A ferry company opened a restaurant on the harbour pier.', loai: 'ngoai-bai' },
      { y: 'Ships passing the cape no longer report any beam on the water.', loai: 'trai-bai' },
    ],
  },
  {
    ma: 'SL05', lop: 5, chuDe: 'snow and buses',
    doan: 'The district cancels school when eight centimetres of snow fall before five in the morning. '
      + 'Thirty centimetres came down between midnight and four on Thursday. '
      + 'The superintendent recorded the depth at half past four. '
      + 'Buses stayed in the depot on Thursday and the telephone tree carried the news to families.',
    dung: 'The thirty centimetres of snow before five on Thursday is why the district cancels school.',
    nhieu: [
      { y: 'The superintendent recorded the depth at half past four.', loai: 'da-neu' },
      { y: 'A hardware shop sold out of garden hoses that weekend.', loai: 'ngoai-bai' },
      { y: 'The snow on Thursday was not deep enough to keep buses in the depot.', loai: 'trai-bai' },
    ],
  },
  {
    ma: 'SL06', lop: 6, chuDe: 'the book drop',
    doan: 'The library charges a fee for a book returned after its due date. '
      + 'Items placed in the outside drop are checked in with the date of the previous evening. '
      + 'Tom pushed his novel through the drop at nine on Saturday morning. '
      + 'The novel had been due on Friday and Tom paid nothing.',
    dung: 'The drop credited Tom with returning the novel on Friday evening.',
    nhieu: [
      { y: 'The novel had been due on Friday and Tom paid nothing.', loai: 'da-neu' },
      { y: 'A cafe beside the museum began selling second hand comics.', loai: 'ngoai-bai' },
      { y: 'The library does not charge a fee for any book returned late.', loai: 'trai-bai' },
    ],
  },
  {
    ma: 'SL07', lop: 6, chuDe: 'training log',
    doan: 'A runner keeps a log of the distance she covers each week. '
      + 'Her coach raises the weekly distance by a tenth whenever the previous week felt easy. '
      + 'The log shows forty kilometres in March and sixty four kilometres in June. '
      + 'She reported an easy week to her coach on nine occasions in that period.',
    dung: 'The coach raised her weekly distance several times between March and June.',
    nhieu: [
      { y: 'The log shows forty kilometres in March and sixty four kilometres in June.', loai: 'da-neu' },
      { y: 'She bought a bicycle and joined a swimming club in April.', loai: 'ngoai-bai' },
      { y: 'Her coach never raises the weekly distance after an easy week.', loai: 'trai-bai' },
    ],
  },
  {
    ma: 'SL08', lop: 4, chuDe: 'ants before rain',
    doan: 'The ants in the yard carry their eggs up from the lower tunnels when the air grows heavy. '
      + 'Water fills those lower tunnels during a storm. '
      + 'On Sunday afternoon the ants were streaming upward with eggs on their backs. '
      + 'Rain reached the yard on Sunday evening and stood in pools until Monday.',
    dung: 'The ants moved their eggs upward on Sunday before the storm water reached the lower tunnels.',
    nhieu: [
      { y: 'Water fills those lower tunnels during a storm.', loai: 'da-neu' },
      { y: 'A gardener planted tulip bulbs along the fence in October.', loai: 'ngoai-bai' },
      { y: 'The ants did not carry any eggs upward on Sunday afternoon.', loai: 'trai-bai' },
    ],
  },
  {
    ma: 'SL09', lop: 7, chuDe: 'the shop that moved',
    doan: 'A shoe shop stood beside the bus station for thirty years. '
      + 'The city moved the station to the edge of town in 2019. '
      + 'Takings at the shoe shop fell by half during the following year. '
      + 'The owner signed a lease on a unit facing the new station in 2021.',
    dung: 'The owner signed a lease facing the new station because takings at the shoe shop fell after the city moved it.',
    nhieu: [
      { y: 'Takings at the shoe shop fell by half during the following year.', loai: 'da-neu' },
      { y: 'A dentist opened a clinic above the supermarket that summer.', loai: 'ngoai-bai' },
      { y: 'The city did not move the bus station away from the shoe shop.', loai: 'trai-bai' },
    ],
  },
  {
    ma: 'SL10', lop: 7, chuDe: 'the timetable',
    doan: 'The number nine bus runs every twenty minutes from six in the morning until midnight. '
      + 'A service update in January removed the buses between ten and midnight. '
      + 'Workers at the hospital finish the late shift at half past ten. '
      + 'Taxi journeys from the hospital rose sharply in February.',
    dung: 'Hospital workers on the late shift began paying for taxis after the January update.',
    nhieu: [
      { y: 'Workers at the hospital finish the late shift at half past ten.', loai: 'da-neu' },
      { y: 'A cycling club organised a charity ride along the canal.', loai: 'ngoai-bai' },
      { y: 'The update in January did not remove any buses from the timetable.', loai: 'trai-bai' },
    ],
  },
  {
    ma: 'SL11', lop: 6, chuDe: 'camping trip',
    doan: 'The group packed a tent rated for temperatures down to five degrees. '
      + 'The forecast for the valley promised a low of eight degrees on Friday night. '
      + 'A cold front arrived early and the thermometer at the campsite read one degree at dawn. '
      + 'Two members of the group sat in the car with the heater running until sunrise.',
    dung: 'The group packed a tent rated for temperatures above the one the campsite reached at dawn.',
    nhieu: [
      { y: 'The forecast for the valley promised a low of eight degrees on Friday night.', loai: 'da-neu' },
      { y: 'They cooked a stew of beans and smoked sausage over the fire.', loai: 'ngoai-bai' },
      { y: 'The thermometer at the campsite did not fall below eight degrees.', loai: 'trai-bai' },
    ],
  },
  {
    ma: 'SL12', lop: 7, chuDe: 'science fair',
    doan: 'Judges at the fair award points for method, for presentation and for the record book. '
      + 'A project earns the method points when the student repeats each trial five times. '
      + 'Lena repeated her trial twice and wrote a handsome record book. '
      + 'She finished fourth and the judges praised her presentation.',
    dung: 'Lena lost the method points at the fair although her book and presentation earned praise.',
    nhieu: [
      { y: 'She finished fourth and the judges praised her presentation.', loai: 'da-neu' },
      { y: 'Her brother entered a photograph in the county art competition.', loai: 'ngoai-bai' },
      { y: 'The judges do not award any points for the record book.', loai: 'trai-bai' },
    ],
  },
  {
    ma: 'SL13', lop: 8, chuDe: 'tide pools',
    doan: 'The pools on the rock shelf are cut off from the sea for six hours between high tides. '
      + 'Sun on a shallow pool in July raises the water several degrees above the ocean. '
      + 'Snails in the upper pools close their shells and hold a film of water inside. '
      + 'Snails of the same species in the lower pools stay open and continue feeding.',
    dung: 'Closing the shell is how the upper snails survive the hours when the sun heats a cut off pool.',
    nhieu: [
      { y: 'Sun on a shallow pool in July raises the water several degrees above the ocean.', loai: 'da-neu' },
      { y: 'A survey counted seabird nests along the cliff path each June.', loai: 'ngoai-bai' },
      { y: 'Snails in the upper pools do not close their shells at low tide.', loai: 'trai-bai' },
    ],
  },
  {
    ma: 'SL14', lop: 8, chuDe: 'the new bridge',
    doan: 'Drivers crossing the river once queued for forty minutes at the single old bridge. '
      + 'A second bridge opened two kilometres downstream in 2020. '
      + 'Traffic counts in 2021 showed the same total of vehicles crossing the river each day. '
      + 'The queue at the old bridge lasted eleven minutes in the 2021 survey.',
    dung: 'The second bridge cut the queue at the old bridge although the same total of vehicles crossed the river.',
    nhieu: [
      { y: 'A second bridge opened two kilometres downstream in 2020.', loai: 'da-neu' },
      { y: 'The council repaved the car park beside the sports centre.', loai: 'ngoai-bai' },
      { y: 'The number of vehicles crossing the river did not stay the same in 2021.', loai: 'trai-bai' },
    ],
  },
  {
    ma: 'SL15', lop: 7, chuDe: 'the water bill',
    doan: 'The town charges each household a fixed sum for the first ten cubic metres of water and a steep rate above that. '
      + 'The Ortega family used eighteen cubic metres in June and thirty in July. '
      + 'Their July bill was more than twice the June bill. '
      + 'The family installed a timer on the garden sprinkler in August.',
    dung: 'The steep rate above ten cubic metres is what pushed the July bill so far past the June bill.',
    nhieu: [
      { y: 'The Ortega family used eighteen cubic metres in June and thirty in July.', loai: 'da-neu' },
      { y: 'A cousin visited from Seville and repainted the kitchen ceiling.', loai: 'ngoai-bai' },
      { y: 'The town does not charge a steep rate above ten cubic metres.', loai: 'trai-bai' },
    ],
  },
  {
    ma: 'SL16', lop: 5, chuDe: 'the bird feeder',
    doan: 'Sparrows fed at the wooden feeder in the garden through the spring. '
      + 'A cat from the next house began sitting under the feeder in May. '
      + 'The family hung the feeder from a thin branch above the shed in June. '
      + 'Sparrows returned to the garden in the last week of June.',
    dung: 'The family hung the feeder above the shed and the cat stopped sitting under it.',
    nhieu: [
      { y: 'A cat from the next house began sitting under the feeder in May.', loai: 'da-neu' },
      { y: 'A carpenter repaired the porch steps before the holiday.', loai: 'ngoai-bai' },
      { y: 'The sparrows did not return to the garden at the end of June.', loai: 'trai-bai' },
    ],
  },
  {
    ma: 'SL17', lop: 8, chuDe: 'the used book shelf',
    doan: 'A bookshop sets aside one shelf for used copies priced at a third of the new price. '
      + 'Students buy the used copies of the set texts within days of the term starting. '
      + 'The manager orders new copies of a title whenever the used shelf empties. '
      + 'Orders for new copies of the biology text arrived in the shop each September for four years.',
    dung: 'The used shelf empties every September because students clear the set texts at the start of term.',
    nhieu: [
      { y: 'A bookshop sets aside one shelf for used copies priced at a third of the new price.', loai: 'da-neu' },
      { y: 'The owner rents the upstairs room to a chess society on Wednesdays.', loai: 'ngoai-bai' },
      { y: 'Students do not buy the used copies of the set texts.', loai: 'trai-bai' },
    ],
  },
  {
    ma: 'SL18', lop: 9, chuDe: 'the museum queue',
    doan: 'The museum sells a timed ticket online and a plain ticket at the door. '
      + 'Holders of a timed ticket enter through the side entrance at the hour printed on it. '
      + 'The queue at the door on Saturday stretched around the block by eleven. '
      + 'A visitor who booked online on Saturday walked in at the side entrance at ten past eleven.',
    dung: 'Booking online on Saturday let a visitor pass the queue that stretched around the block.',
    nhieu: [
      { y: 'The queue at the door on Saturday stretched around the block by eleven.', loai: 'da-neu' },
      { y: 'A school group toured the aquarium across the park that afternoon.', loai: 'ngoai-bai' },
      { y: 'The museum does not sell any timed ticket online.', loai: 'trai-bai' },
    ],
  },
];

// ── VIẾT LUẬN HỌC THUẬT (IELTS Task 2 / SAT) ────────────────────────────────
//  Việc kiểm được bằng máy ở đây KHÔNG phải chấm bài luận — chấm bài luận cần
//  người. Việc kiểm được là bước TRƯỚC KHI VIẾT, và cũng là bước hỏng nhiều
//  điểm nhất: đọc chữ của đề để biết đề hỏi dạng gì, rồi chọn câu chủ đề phục
//  vụ đúng dạng đó. Viết hay mà lạc dạng thì mất điểm tiêu chí Task Response.
const DE_LUAN = [
  {
    ma: 'DL01', lop: 10, dang: 'dong-y',
    de: 'Some people believe that secondary schools should teach personal finance as a required subject. To what extent do you agree or disagree?',
    dung: 'I agree that personal finance should be required, because a school leaver signs a rental contract long before anyone explains interest to them.',
    nhieu: [
      { y: 'This essay will look at the advantages and the drawbacks of teaching personal finance in schools.' },
      { y: 'Personal finance is an important subject that many secondary schools around the world now offer.' },
      { y: 'I agree with this proposal and the essay below will explain my position in two body paragraphs.' },
    ],
  },
  {
    ma: 'DL02', lop: 10, dang: 'dong-y',
    de: 'Working from home is better for employees than working in an office. To what extent do you agree or disagree?',
    dung: 'I disagree that home working suits employees better, because a junior worker learns the job by overhearing the desks around them.',
    nhieu: [
      { y: 'There are strong arguments on each side of the question of home working.' },
      { y: 'Home working has grown quickly since 2020 and now covers a third of office roles.' },
      { y: 'I disagree with the statement, and this essay sets out my two main points in turn.' },
    ],
  },
  {
    ma: 'DL03', lop: 11, dang: 'dong-y',
    de: 'Museums and art galleries should be free to enter for everyone. To what extent do you agree or disagree?',
    dung: 'I agree that entry should be free, since a charge at the door removes the visitors a public collection exists to reach.',
    nhieu: [
      { y: 'Free entry brings both benefits and costs, which this essay will weigh against each other.' },
      { y: 'Many national museums in Britain dropped their entry charge in the year 2001.' },
      { y: 'The question of free entry is complex and reasonable people take different views on it.' },
    ],
  },
  {
    ma: 'DL04', lop: 11, dang: 'dong-y',
    de: 'Governments should spend more on public transport than on new roads. To what extent do you agree or disagree?',
    dung: 'I agree that public transport deserves the larger share, because a new lane fills with traffic within a few years of opening.',
    nhieu: [
      { y: 'Spending on roads and spending on public transport each carry advantages and disadvantages.' },
      { y: 'Transport budgets in most countries are divided between roads, rail and bus services.' },
      { y: 'I agree with the statement above and will present evidence in the paragraphs that follow.' },
    ],
  },
  {
    ma: 'DL05', lop: 11, dang: 'hai-quan-diem',
    de: 'Some argue that university tuition should be paid by the state, while others say students should pay their own fees. Discuss both views and give your own opinion.',
    dung: 'While state funding widens access, the fee system lets a university answer to its students, and I believe a mixed model keeps the strengths of each.',
    nhieu: [
      { y: 'I believe the state should pay for university tuition because education is a public good.' },
      { y: 'Tuition fees in several countries have risen faster than average household income.' },
      { y: 'Although both sides raise fair points, the answer depends on the country in question.' },
    ],
  },
  {
    ma: 'DL06', lop: 12, dang: 'hai-quan-diem',
    de: 'Some people think children should start formal schooling at five, while others prefer seven. Discuss both views and give your own opinion.',
    dung: 'While an early start builds reading habits sooner, later entry protects the play that builds attention, and I would begin formal lessons at six.',
    nhieu: [
      { y: 'I think children should start school at seven because play develops the brain.' },
      { y: 'Finland begins formal schooling at seven and Britain begins it at five.' },
      { y: 'Although the debate continues, most parents follow whatever the local system decides.' },
    ],
  },
  {
    ma: 'DL07', lop: 12, dang: 'hai-quan-diem',
    de: 'Some believe that news should be read from printed papers, while others prefer online sources. Discuss both views and give your own opinion.',
    dung: 'While a printed paper edits what reaches the reader, an online feed reaches them faster, and I think the two serve different hours of the day.',
    nhieu: [
      { y: 'I think online news is better because it reaches readers within minutes of an event.' },
      { y: 'Printed circulation has fallen every year since online news became widely available.' },
      { y: 'Although each source has merits, readers will choose the one that costs them least.' },
    ],
  },
  {
    ma: 'DL08', lop: 10, dang: 'van-de-giai-phap',
    de: 'More and more people in large cities live alone. What problems does this create, and what solutions can you suggest?',
    dung: 'Living alone creates the problems of loneliness and of housing pressure, and the clearest solutions are shared housing schemes and neighbourhood centres.',
    nhieu: [
      { y: 'This trend creates serious problems for city planners and for the people themselves.' },
      { y: 'The number of single person households in Tokyo passed half of the total in 2020.' },
      { y: 'Several solutions have been tried in European cities over the past two decades.' },
    ],
  },
  {
    ma: 'DL09', lop: 11, dang: 'van-de-giai-phap',
    de: 'Many students spend long hours on their phones during lessons. What problems does this create, and what solutions can you suggest?',
    dung: 'Phones in lessons create the problems of broken attention and of copied work, and the workable solutions are a locked pouch and a phone free first hour.',
    nhieu: [
      { y: 'Phones in class create a number of problems that teachers around the world describe.' },
      { y: 'A survey of teenagers found an average of seven hours of screen time each day.' },
      { y: 'Possible solutions range from school rules to changes in the design of the devices.' },
    ],
  },
  {
    ma: 'DL10', lop: 12, dang: 'van-de-giai-phap',
    de: 'Tourism has grown rapidly in small historic towns. What problems does this create, and what solutions can you suggest?',
    dung: 'Rapid tourism creates the problems of crowding and of rising rents, and the solutions that work are timed entry tickets and a cap on holiday lets.',
    nhieu: [
      { y: 'Mass tourism creates well known problems in the historic centres of small towns.' },
      { y: 'Venice received twenty million visitors in a year against fifty thousand residents.' },
      { y: 'Local councils have proposed solutions ranging from taxes to building restrictions.' },
    ],
  },
  {
    ma: 'DL11', lop: 11, dang: 'nguyen-nhan-giai-phap',
    de: 'Fewer young people are entering skilled trades such as plumbing and carpentry. What are the causes of this trend, and what measures could address it?',
    dung: 'The causes are the prestige attached to a degree and the weak supply of apprenticeships, and the measures that would help are paid training places and trade teaching inside secondary school.',
    nhieu: [
      { y: 'This trend has several causes that researchers in the field have documented carefully.' },
      { y: 'The average age of a working plumber in Germany has risen above fifty.' },
      { y: 'A number of measures have been proposed by industry groups in recent years.' },
    ],
  },
  {
    ma: 'DL12', lop: 12, dang: 'nguyen-nhan-giai-phap',
    de: 'Household food waste has increased in many wealthy countries. What are the causes of this trend, and what measures could address it?',
    dung: 'The causes are oversized packaging and confusion over date labels, and the measures with the best record are loose produce aisles and a single clear use by date.',
    nhieu: [
      { y: 'The causes of household food waste are complex and differ from country to country.' },
      { y: 'A British household throws away food worth about seven hundred pounds each year.' },
      { y: 'Governments have introduced measures aimed at retailers rather than at shoppers.' },
    ],
  },
  {
    ma: 'DL13', lop: 10, dang: 'hai-mat',
    de: 'Many companies now allow staff to work a four day week on full pay. Do the advantages outweigh the disadvantages?',
    dung: 'The advantage of a rested workforce outweighs the disadvantage of thinner cover on busy days, provided the company staggers which day each team takes.',
    nhieu: [
      { y: 'A four day week brings clear benefits to staff and clear costs to the employer.' },
      { y: 'Trials of the four day week in Iceland covered a tenth of the working population.' },
      { y: 'This essay will argue that the four day week should be adopted more widely.' },
    ],
  },
  {
    ma: 'DL14', lop: 11, dang: 'hai-mat',
    de: 'Children in many countries own a smartphone before the age of ten. Do the advantages outweigh the disadvantages?',
    dung: 'The advantage of reaching a child at any moment does not outweigh the disadvantage of an unsupervised feed, so a simple handset serves a ten year old better.',
    nhieu: [
      { y: 'Early smartphone ownership brings gains in safety and losses in sleep and attention.' },
      { y: 'Roughly half of British children own a smartphone by the age of eleven.' },
      { y: 'This essay will consider ownership from the point of view of parents and of schools.' },
    ],
  },
];

// ── NÓI THEO CHỦ ĐỀ (IELTS Part 2) ──────────────────────────────────────────
//  Thẻ đề Part 2 có ĐÚNG bốn gạch đầu dòng và hai phút để nói. Lỗi mất điểm
//  nhiều nhất là bỏ sót một gạch, hoặc nói sang chuyện khác cho trôi hai phút.
//  Máy tách bốn gạch đầu dòng rồi đối chiếu từng gạch với dàn ý — chạm thiếu
//  một gạch là thấy ngay.
const THE_NOI = [
  {
    ma: 'TN01', lop: 9,
    the: 'Describe a journey that you still recall.\n'
      + '· where it began and where it ended\n'
      + '· how you travelled\n'
      + '· who your companions were\n'
      + '· and explain what stays in your memory',
    dung: 'The journey began in Hue and ended in Da Nang. I travelled by train along the coast. My two cousins were my companions. What stays in my memory is the window full of sea.',
    nhieu: [
      { y: 'The journey began in Hue and ended in Da Nang. I travelled by train along the coast. What stays in my memory is the window full of sea.', loai: 'bo-sot' },
      { y: 'My favourite dish is a bowl of noodles that my grandmother prepares on Sunday with pork and fresh herbs.', loai: 'lac-de' },
      { y: 'The journey began in Hue and ended in Da Nang. My two cousins were my companions. What stays in my memory is the window full of sea.', loai: 'bo-sot' },
    ],
  },
  {
    ma: 'TN02', lop: 10,
    the: 'Describe a teacher who influenced you.\n'
      + '· what subject this person taught\n'
      + '· how long you studied together\n'
      + '· what the lessons were like\n'
      + '· and explain what changed in you afterwards',
    dung: 'The teacher taught chemistry as my subject. We studied together for two years. The lessons were built around an experiment we had to predict. What changed in me afterwards was the habit of guessing a result first.',
    nhieu: [
      { y: 'The teacher taught chemistry as my subject and we studied together for two years. The laboratory smelled of gas on winter mornings.', loai: 'bo-sot' },
      { y: 'The city park near my house has a lake, a running path and a row of old trees that turn red in November.', loai: 'lac-de' },
      { y: 'The teacher taught chemistry as my subject. The lessons were built around an experiment. What changed in me afterwards was a habit of checking.', loai: 'bo-sot' },
    ],
  },
  {
    ma: 'TN03', lop: 10,
    the: 'Describe a skill you learned outside school.\n'
      + '· what the skill involves\n'
      + '· who taught you\n'
      + '· how much practice it needed\n'
      + '· and explain where you apply it now',
    dung: 'The skill involves making bread by hand. My uncle taught me during a summer at his bakery. It needed practice every morning for three months. I apply it now whenever friends come to eat.',
    nhieu: [
      { y: 'The skill involves making bread by hand, and my uncle taught me at his bakery. The kitchen was hot and the radio played all day.', loai: 'bo-sot' },
      { y: 'The national museum holds a collection of bronze drums and a hall of photographs from the last century.', loai: 'lac-de' },
      { y: 'The skill involves making bread. It needed practice for three months and I apply it now at weekends. The result was worth the effort.', loai: 'bo-sot' },
    ],
  },
  {
    ma: 'TN04', lop: 9,
    the: 'Describe a place where you like to read.\n'
      + '· where this place is\n'
      + '· which day of the week you go there\n'
      + '· what it looks like\n'
      + '· and explain why it suits you',
    dung: 'The place is the balcony of my flat. Saturday is the day of the week I go there.'
      + ' It looks out over a courtyard with two mango trees. It suits me because the street noise arrives softened.',
    nhieu: [
      { y: 'The place is the balcony of my flat and it looks out over a courtyard with two mango trees. The chair there is an old one.', loai: 'bo-sot' },
      { y: 'My brother repairs motorbikes in a workshop beside the market and he has taught three apprentices this year.', loai: 'lac-de' },
      { y: 'The place is the balcony of my flat. Saturday is the day of the week I go there. It suits me because the traffic arrives softened.', loai: 'bo-sot' },
    ],
  },
  {
    ma: 'TN05', lop: 11,
    the: 'Describe a decision that took you a long time.\n'
      + '· what you had to choose between\n'
      + '· how many months you considered it\n'
      + '· who gave you advice\n'
      + '· and explain how you feel about it now',
    dung: 'The decision was to choose between a local college and a course in another city. I considered it for four months. My aunt gave me advice from her own experience. I feel settled about it now, because the city taught me to live alone.',
    nhieu: [
      { y: 'The decision was to choose between a local college and a course in another city, and I considered it for four months. The forms were due in March.', loai: 'bo-sot' },
      { y: 'The football stadium on the edge of town fills on Sunday and the supporters sing from the first whistle.', loai: 'lac-de' },
      { y: 'The decision was hard. My aunt gave me advice, and I feel settled about it now. The whole business lasted longer than I expected.', loai: 'bo-sot' },
    ],
  },
  {
    ma: 'TN06', lop: 11,
    the: 'Describe a machine you use often.\n'
      + '· what the machine does\n'
      + '· which year you obtained it\n'
      + '· how you learned to operate it\n'
      + '· and explain what you produce with it',
    dung: 'The machine sews cloth and it does that quietly. I obtained it at a market in the year 2022.'
      + ' I learned to operate it from a printed manual and a neighbour. It lets me produce a jacket rather than buy one.',
    nhieu: [
      { y: 'The machine sews cloth and does that quietly. I obtained it at a market in the year 2022. The metal body weighs a great deal.', loai: 'bo-sot' },
      { y: 'The bus station is being rebuilt and the works have closed the road beside the old hospital.', loai: 'lac-de' },
      { y: 'The machine is a small one. I learned to operate it from a manual, and it lets me produce a jacket. The thread costs almost nothing.', loai: 'bo-sot' },
    ],
  },
  {
    ma: 'TN07', lop: 10,
    the: 'Describe a meal you cooked for other people.\n'
      + '· what you prepared\n'
      + '· who ate with you\n'
      + '· how many hours the cooking took\n'
      + '· and explain what you would change next time',
    dung: 'The meal I prepared was a fish soup with a plate of greens. Four neighbours ate with me. The cooking took three hours. I would change the order next time and start the broth first.',
    nhieu: [
      { y: 'The meal I prepared was a fish soup, and four neighbours ate with me. The kitchen filled with steam until somebody opened a window.', loai: 'bo-sot' },
      { y: 'The library near the river opened a study room last year and students queue there during the examination weeks.', loai: 'lac-de' },
      { y: 'The meal was a simple one. The cooking took three hours and I would change the order next time. Everybody stayed until quite late.', loai: 'bo-sot' },
    ],
  },
  {
    ma: 'TN08', lop: 12,
    the: 'Describe a problem you solved at work.\n'
      + '· what went wrong\n'
      + '· who else was involved\n'
      + '· what steps you took\n'
      + '· and explain what the outcome was',
    dung: 'The problem at work was a rota that went wrong and left Friday evening uncovered. Two colleagues were involved with me. The steps I took were a shared calendar and a swap rule. The outcome was a full month without a gap.',
    nhieu: [
      { y: 'The problem at work was a rota that went wrong and left Friday uncovered, and two colleagues were involved. The manager was away that week.', loai: 'bo-sot' },
      { y: 'My cousin studies marine biology and spends each summer counting fish along a stretch of reef.', loai: 'lac-de' },
      { y: 'The problem at work was a rota. The steps I took were a shared calendar and a swap rule, and the outcome was a month without a gap.', loai: 'bo-sot' },
    ],
  },
  {
    ma: 'TN09', lop: 9,
    the: 'Describe a photograph you keep.\n'
      + '· what it shows\n'
      + '· who pressed the shutter\n'
      + '· where you store it\n'
      + '· and explain why it matters to you',
    dung: 'The photograph shows my grandfather beside his bicycle. My mother pressed the shutter in 1994.'
      + ' I store it inside a book on the shelf. It matters to me because the bicycle is the one I ride today.',
    nhieu: [
      { y: 'The photograph shows my grandfather beside his bicycle, and my mother pressed the shutter in 1994. The paper has yellowed at one corner.', loai: 'bo-sot' },
      { y: 'The night market sells grilled corn and sugar cane juice from about six until midnight.', loai: 'lac-de' },
      { y: 'The photograph is an old one. My mother pressed the shutter. I store it inside a book on the shelf.', loai: 'bo-sot' },
    ],
  },
  {
    ma: 'TN10', lop: 12,
    the: 'Describe a change you would make to your town.\n'
      + '· what the change involves\n'
      + '· why the town needs it\n'
      + '· who would pay for it\n'
      + '· and explain how daily life would improve',
    dung: 'The change involves a covered market on the empty lot. The town needs it because the stalls now stand in the rain. The council and the traders would pay for it together. Daily life would improve because shopping would stop depending on the weather.',
    nhieu: [
      { y: 'The change involves a covered market on the empty lot, and the town needs it because the stalls stand in the rain. The lot has been empty since 2016.', loai: 'bo-sot' },
      { y: 'My favourite film follows a postman who walks the same mountain route for thirty years.', loai: 'lac-de' },
      { y: 'The change involves a covered market. The council and the traders would pay for it, and daily life would improve a great deal.', loai: 'bo-sot' },
    ],
  },
  {
    ma: 'TN11', lop: 11,
    the: 'Describe a habit you have changed.\n'
      + '· what the habit was\n'
      + '· which month you began to change it\n'
      + '· what helped you\n'
      + '· and explain what the result has been',
    dung: 'The habit was checking messages before I got out of bed. I began to change it in the month of January. A charger left in the next room helped me. The result has been half an hour of quiet each morning.',
    nhieu: [
      { y: 'The habit was checking messages in bed, and I began to change it in the month of January. The screen was the first thing I saw.', loai: 'bo-sot' },
      { y: 'The river path floods twice a year and the council closes the gate at both ends until the water falls.', loai: 'lac-de' },
      { y: 'The habit was an old one. A charger left in the next room helped me, and the result has been half an hour of quiet.', loai: 'bo-sot' },
    ],
  },
  {
    ma: 'TN12', lop: 10,
    the: 'Describe a shop you visit regularly.\n'
      + '· what it sells\n'
      + '· how far it stands from your home\n'
      + '· who serves there\n'
      + '· and explain why you return to it',
    dung: 'The shop sells vegetables and dried goods. It stands two hundred metres from my home. An elderly couple serves there. I return to it because they keep the coriander I ask for.',
    nhieu: [
      { y: 'The shop sells vegetables and dried goods, and it stands two hundred metres from my home. The front is painted green.', loai: 'bo-sot' },
      { y: 'The sports centre added a climbing wall last spring and a coach runs a class for beginners.', loai: 'lac-de' },
      { y: 'The shop is a small one. An elderly couple serves there and I return to it because of the coriander. The shelves are tidy.', loai: 'bo-sot' },
    ],
  },
  {
    ma: 'TN13', lop: 12,
    the: 'Describe an article you read that stayed with you.\n'
      + '· what subject it covered\n'
      + '· where you came across it\n'
      + '· how long ago you finished it\n'
      + '· and explain what it made you reconsider',
    dung: 'The article covered the subject of cheap clothing and its real cost. I came across it in a magazine at the dentist. I finished it about a year ago. It made me reconsider how often I replace a shirt.',
    nhieu: [
      { y: 'The article covered the subject of cheap clothing, and I came across it in a magazine at the dentist. The photographs were taken in Dhaka.', loai: 'bo-sot' },
      { y: 'My neighbour keeps four beehives on his roof and collects honey at the end of each summer.', loai: 'lac-de' },
      { y: 'The article was a long one. I finished it about a year ago, and it made me reconsider how often I replace a shirt.', loai: 'bo-sot' },
    ],
  },
  {
    ma: 'TN14', lop: 9,
    the: 'Describe a game you played as a child.\n'
      + '· what the rules were\n'
      + '· where you played it\n'
      + '· who joined in\n'
      + '· and explain why you enjoyed it',
    dung: 'The game had simple rules: one person counted while the rest hid. We played it in the lane behind our houses. My sister and four neighbours joined in. I enjoyed it because the lane held a hundred corners.',
    nhieu: [
      { y: 'The game had simple rules, with one person counting while the rest hid, and we played it in the lane behind our houses. Dusk ended it.', loai: 'bo-sot' },
      { y: 'The train to the coast leaves at six and arrives before the cafes along the promenade open.', loai: 'lac-de' },
      { y: 'The game was an old one. My sister and four neighbours joined in, and I enjoyed it because of the corners.', loai: 'bo-sot' },
    ],
  },
];

module.exports = { DOAN_Y_CHINH, DOAN_SUY_LUAN, DE_LUAN, THE_NOI };
