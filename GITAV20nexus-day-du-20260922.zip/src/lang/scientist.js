'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  NHÀ KHOA HỌC NGÔN NGỮ — chuẩn tiếng Việt cho toàn bộ học liệu
 * ═══════════════════════════════════════════════════════════════════════════
 *  Song song với nhà khoa học toán: bên kia lo ĐÚNG, bên này lo ĐỌC ĐƯỢC.
 *
 *  Bốn cấp soát, xếp theo cùng một lối nghĩ với bên toán:
 *    Cấp 1 — CHÍNH TẢ   âm tiết có đúng luật cấu tạo, dấu thanh có đúng chỗ
 *    Cấp 2 — VĂN PHONG  giọng máy, viết tắt, biểu tượng cảm xúc
 *    Cấp 3 — ĐỘ ĐỌC     câu có vừa sức lớp đó không
 *    Cấp 4 — TỪ VỰNG    có dùng từ mà chương trình chỉ dạy ở lớp trên không
 *
 *  Cấp 3 và cấp 4 là hai cấp mà một bộ soát chính tả thông thường không có,
 *  và lại là hai cấp quan trọng nhất với học liệu: một đề toán lớp 3 viết
 *  bằng câu bốn mươi tiếng, dùng từ của lớp 9, thì học sinh trượt ở khâu ĐỌC
 *  chứ không phải khâu TOÁN — mà nhìn vào điểm số thì không ai thấy điều đó.
 *
 *  Bốn kỹ năng nghe-nói-đọc-viết được dựng từ CHÍNH học liệu đã thẩm định:
 *  bài đọc là đề bài thật, bài nghe là lời giảng thật, bài nói là những tiếng
 *  khó thật trong bài, bài viết là khung trình bày lời giải thật. Không có
 *  đoạn văn nào do máy bịa ra rồi gọi là học liệu.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { soatChinhTa, chuanHoaChinhTa, cacCau, cacTieng, datLaiDauThanh } = require('./chinhta');
const { cacBuoc, vanBanDayDu } = require('../content/loi-giai');
const { doDoc, hopVoiLop, doanLop, thongKeTheoLop, vanKho, NGUONG_LOP } = require('./docde');
const { TuVung } = require('./tuvung');
const { kiemVanPhong } = require('../math/vanphong');
const { parseSyllable, TONES } = require('../voice/phonemizer');
const { FORM_INDEX } = require('../curriculum/hierarchy');
const { round } = require('../utils');

/** Loại câu, nhận biết bằng dấu câu và từ mở đầu. */
const TU_CAU_KHIEN = ['tính', 'giải', 'tìm', 'chứng minh', 'cho', 'vẽ', 'lập', 'viết',
  'so sánh', 'rút gọn', 'phân tích', 'xác định', 'hãy', 'nêu', 'biến đổi', 'đặt', 'thực hiện'];
const TU_NGHI_VAN = ['hỏi', 'bao nhiêu', 'mấy', 'nào', 'gì', 'sao', 'đâu', 'có phải', 'liệu'];

function loaiCau(cau) {
  const s = String(cau).trim().toLowerCase();
  if (/\?$/.test(s) || TU_NGHI_VAN.some((t) => s.includes(t))) return 'nghi vấn';
  if (TU_CAU_KHIEN.some((t) => s.startsWith(t))) return 'cầu khiến';
  return 'trần thuật';
}


/**
 * Lớp dùng để chấm ĐỘ ĐỌC của lời văn trong một dạng bài.
 *
 * Dạng toán mang sẵn lớp trong mã (M9.… là lớp 9). Dạng liên môn (X.…) và
 * dạng tiếng Anh (E.…) thì KHÔNG thuộc lớp nào — chúng trải dài nhiều lớp và
 * được xếp theo TẦNG NĂNG LỰC. Nhưng ngưỡng độ đọc lại tính theo lớp, nên
 * phải quy đổi.
 *
 * Bảng quy đổi dưới đây là QUY ƯỚC BIÊN TẬP, không phải số đo: lấy tầng thấp
 * nhất của dạng — tức lứa học viên SỚM NHẤT gặp dạng này — rồi gán lớp tương
 * ứng. Ghi rõ ở đây để người sau biết con số từ đâu ra mà sửa, thay vì tưởng
 * là kết quả đo được.
 */
const TANG_SANG_LOP = [3, 3, 6, 6, 8, 8, 10, 10, 11, 11];

/**
 * Lớp để soi một BÀI cụ thể.
 *
 * Trước đây mọi bài của một dạng đều bị soi theo lớp SÀN của dạng đó. Với dạng
 * trải rộng như "Suy luận logic nhiều bước" (tầng 3 đến tầng 9) thì bài dành
 * cho học viên tầng 9 vẫn bị đo bằng thước lớp 6, nên câu nào cũng bị báo
 * "quá dài" và "nhiều vần khó" — báo động giả, và lỗi thật thì chìm nghỉm.
 *
 * Lớp đúng để soi một bài là lớp ứng với TẦNG của chính bài đó, nhưng không
 * bao giờ thấp hơn lớp sàn của dạng, vì dạng chưa dạy thì bài không nên có.
 */
/**
 * Gỡ phần NGUỒN TIẾNG ANH ra khỏi đề trước khi chấm tiếng Việt.
 *
 * Bài đọc hiểu tiếng Anh có một đoạn văn tiếng Anh nằm giữa đề. Bộ soát tiếng
 * Việt nhìn đoạn ấy và báo "câu viết không dấu" — báo đúng luật nhưng sai chỗ:
 * đoạn văn tiếng Anh KHÔNG PHẢI văn tiếng Việt viết thiếu dấu, nó là ngữ liệu
 * của môn học. Hạ ngưỡng "viết không dấu" để cho qua thì mọi bài tiếng Việt gõ
 * thiếu dấu cũng lọt theo, nên cách đúng là cắt đúng phần ngữ liệu ra, rồi chấm
 * phần LỜI DẪN TIẾNG VIỆT còn lại theo đúng chuẩn cũ, không nới một ly nào.
 *
 * Cắt theo chuỗi mà chính bài đã KHAI BÁO ở check.english — không đoán theo
 * "trông giống tiếng Anh", vì đoán như thế thì một câu tiếng Việt gõ thiếu dấu
 * cũng trông giống tiếng Anh.
 */
function goNguonNgoaiNgu(item = {}) {
  const de = String(item.stem || '');
  const ck = (item.check || {}).english;
  if (!ck) return de;
  const manh = [];
  for (const k of ['doan', 'de', 'the', 'nguon', 'nguonA', 'nguonB', 'cauChinh', 'dapAnDung']) {
    if (ck[k]) manh.push(String(ck[k]));
  }
  for (const n of ck.nhieu || []) if (n && n.y) manh.push(String(n.y));
  let ra = de;
  for (const m of manh.sort((a, b) => b.length - a.length)) {
    for (const dong of m.split('\n')) {
      const d = dong.trim();
      if (d.length < 4) continue;
      // Mẩu nào đã nằm trong ngoặc kép thì để boNgoaiNgu lo: nó thay cả cụm
      // bằng một ký hiệu MANG THEO DẤU CHẤM, nhờ vậy câu vẫn kết thúc đúng
      // chỗ. Cắt trắng ở đây sẽ nối hai câu thành một câu dài giả tạo.
      if (ra.includes(`"${d}"`)) continue;
      ra = ra.split(d).join(' ');
    }
  }
  return ra.split('\n')
    .map((d) => d.replace(/^\s*(?:[A-D]\.|·)\s*/, '').replace(/\s{2,}/g, ' ').trim())
    .filter(Boolean)
    .join('\n');
}

function lopCuaBai(f, item) {
  const san = lopChuanCuaDang(f);
  const tang = Number(item && item.level);
  if (!Number.isInteger(tang)) return san;
  const theoTang = TANG_SANG_LOP[tang];
  return theoTang ? Math.max(san, theoTang) : san;
}

function lopChuanCuaDang(f) {
  const m = Number((f.code.match(/^M(\d+)/) || [])[1]);
  if (m >= 1 && m <= 12) return m;
  const tu = TANG_SANG_LOP[f.levelRange[0]] || 6;
  // Lời VIỆT của bài tiếng Anh buộc phải dùng thuật ngữ ngữ pháp — "thì",
  // "trạng ngữ", "mệnh đề quan hệ". Đó là vốn từ của cấp hai, dù bài tập
  // tiếng Anh tương ứng có thể giao từ tầng thấp. Nên lấy sàn là lớp 6.
  return f.code.startsWith('E.') ? Math.max(6, tu) : tu;
}


/**
 * Bỏ phần KHÔNG PHẢI TIẾNG VIỆT trước khi soát tiếng Việt.
 *
 * Đề bài tiếng Anh, đoạn kịch bản nghe, câu trích dẫn nguyên văn — tất cả đều
 * là DỮ LIỆU của bài, không phải lời văn của người soạn. Đem thước tiếng Việt
 * ra đo chúng thì kết quả vô nghĩa: câu tiếng Anh nào cũng bị báo "thiếu dấu"
 * và "câu quá dài", còn lỗi thật trong phần lời Việt thì chìm nghỉm giữa đống
 * báo động giả. Nguyên tắc này đã áp dụng cho công thức toán trong $…$; ngoại
 * ngữ cũng thuộc cùng một loại.
 *
 * Chỉ bỏ những đoạn CHẮC CHẮN là ngoại ngữ: nằm trong ngoặc kép hoặc trong
 * khối [NGHE]…[/NGHE], và KHÔNG chứa một chữ có dấu tiếng Việt nào.
 */
const CO_DAU_VIET = /[àáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđÀÁẢÃẠĂẰẮẲẴẶÂẦẤẨẪẬÈÉẺẼẸÊỀẾỂỄỆÌÍỈĨỊÒÓỎÕỌÔỒỐỔỖỘƠỜỚỞỠỢÙÚỦŨỤƯỪỨỬỮỰỲÝỶỸỴĐ]/;

function boNgoaiNgu(s) {
  return s
    // Thay bằng MỘT ký tự, đúng chỗ, không chèn thêm dấu cách. Ký hiệu thay thế
    // dài mấy tiếng thì tự nó làm câu dài ra — đúng cái đang cần đo. Chèn thêm
    // dấu cách thì tạo ra lỗi
    // "thừa dấu cách" và "dấu cách trước dấu câu" mà bản gốc không hề có.
    .replace(/\[NGHE\][\s\S]*?\[\/NGHE\]/g, 'X')
    // Nếu đoạn bị bỏ vốn kết thúc bằng dấu câu thì ký hiệu thay thế phải mang
    // theo dấu đó, nếu không hai câu trong bản gốc sẽ bị đếm thành một câu dài.
    .replace(/"([^"]{2,})"/g, (m, trong) => (CO_DAU_VIET.test(trong) ? m : (/[.!?]\s*$/.test(trong) ? 'X.' : 'X')));
}

class LanguageScientist {
  constructor({ bank = null, voice = null, llm = null, telemetry = null, behavior = null, mastery = null, bus = null } = {}) {
    this.bank = bank;
    this.voice = voice;
    this.llm = llm;
    this.telemetry = telemetry;
    this.behavior = behavior;
    this.mastery = mastery;
    this.bus = bus;
    this.tuVung = new TuVung({ bank });
    this.stats = { soat: 0, khongDat: 0, baiHoc: 0, amTiet: 0 };
  }

  // ── Bốn cấp soát ────────────────────────────────────────────────────────

  /**
   * Soát một đoạn văn tiếng Việt.
   * @param {string} text
   * @param {object} o lop: lớp học sinh (bật cấp 3 và 4); loai: 'bai-giai' | 'tu-do'
   */
  soat(text, { lop = null, loai = 'tu-do', kieuDau = 'tudo' } = {}) {
    this.stats.soat++;
    const s = boNgoaiNgu(String(text || ''));

    const c1 = soatChinhTa(s, { kieuDau });
    const c2 = kiemVanPhong(s, { loai });
    const c3 = lop ? hopVoiLop(s, lop) : null;
    const c4 = lop ? this.tuVung.tuVuotLop(s, lop) : null;

    const loiC4 = c4 && c4.tong
      ? [{
        muc: 'CANH_BAO', ma: 'TU_VUOT_LOP',
        moTa: `${c4.tong} thuật ngữ chương trình dạy ở lớp trên: ${c4.items.slice(0, 4).map((x) => `"${x.tu}" (lớp ${x.lopDay})`).join(', ')}`,
        cach: 'Giải thích ngay trong bài, hoặc thay bằng cách nói của lứa tuổi.',
      }]
      : [];

    const soLoi = c1.soLoi + c2.soLoi + (c3 ? c3.loi.filter((l) => l.muc === 'LOI').length : 0);
    const soNhac = c1.soCanhBao + c2.soCanhBao
      + (c3 ? c3.loi.filter((l) => l.muc !== 'LOI').length : 0) + loiC4.length;
    const diem = Math.max(0, 100 - soLoi * 12 - soNhac * 4);

    return {
      ok: soLoi === 0,
      dat: soLoi === 0,
      diem,
      xep: diem >= 90 ? 'xuất sắc' : diem >= 75 ? 'đạt' : diem >= 50 ? 'cần sửa' : 'không dùng được',
      lop,
      cap1ChinhTa: c1,
      cap2VanPhong: c2,
      cap3DoDoc: c3,
      cap4TuVung: c4 ? { ...c4, loi: loiC4 } : null,
      canSua: [
        ...c1.loi.filter((l) => l.muc === 'LOI'),
        ...c2.loi.filter((l) => l.muc === 'LOI'),
        ...(c3 ? c3.loi.filter((l) => l.muc === 'LOI') : []),
      ],
      tomTat: [
        `Cấp 1 chính tả: ${c1.ok ? 'đạt' : `${c1.soLoi} lỗi`}`,
        `Cấp 2 văn phong: ${c2.ok ? 'đạt' : `${c2.soLoi} lỗi`}`,
        c3 ? `Cấp 3 độ đọc: ${c3.ok ? 'vừa sức' : 'quá sức'} lớp ${lop} (${c3.doDo.tiengMoiCau} tiếng/câu, trần ${c3.nguong.toiDa})` : 'Cấp 3 độ đọc: bỏ qua (chưa cho biết lớp)',
        c4 ? `Cấp 4 từ vựng: ${c4.tong ? `${c4.tong} từ vượt lớp` : 'không có từ vượt lớp'}` : 'Cấp 4 từ vựng: bỏ qua',
      ].join(' · '),
    };
  }

  /** Sửa những lỗi trình bày máy sửa được, không đụng vào nghĩa. */
  chuanHoa(text, o = {}) { return chuanHoaChinhTa(text, o); }

  // ── Phân tích âm tiết ───────────────────────────────────────────────────

  /**
   * Bảng âm tiết: mỗi tiếng tách thành âm đầu · âm đệm · âm chính · âm cuối ·
   * thanh điệu. Dùng để dạy đọc, để soi lỗi phát âm, và để kiểm chính bộ đọc
   * giọng nói của hệ thống.
   */
  amTiet(text) {
    this.stats.amTiet++;
    const tieng = cacTieng(String(text || '')).map((t) => t.tu);
    const bang = [];
    const theoThanh = {};
    let khongDoc = 0;
    for (const t of tieng) {
      const p = parseSyllable(t.toLowerCase());
      if (!p.ok) { khongDoc++; bang.push({ tieng: t, doc: false, vi: p.error }); continue; }
      theoThanh[p.tone] = (theoThanh[p.tone] || 0) + 1;
      bang.push({
        tieng: t, doc: true,
        amDau: p.initial || '∅',
        amDem: p.glide || '∅',
        amChinh: p.nucleus.text,
        amCuoi: p.coda || '∅',
        thanh: p.tone,
        vanKho: vanKho(t),
      });
    }
    const doc = bang.filter((b) => b.doc);
    return {
      ok: true,
      soTieng: tieng.length,
      docDuoc: doc.length,
      khongDoc,
      theoThanh,
      tiLeVanKho: doc.length ? round(doc.filter((b) => b.vanKho).length / doc.length, 3) : 0,
      bang,
      thanhDieu: Object.keys(TONES),
    };
  }

  // ── Phân tích câu ───────────────────────────────────────────────────────

  /**
   * Phân tích cấu trúc câu ở mức đo được: độ dài, loại câu, số mệnh đề.
   * KHÔNG hứa tách chủ ngữ — vị ngữ: muốn làm đúng việc đó cần bộ phân tích
   * cú pháp có huấn luyện, hệ thống này không có, và đoán bừa thì tệ hơn là
   * không làm.
   */
  phanTichCau(text) {
    const cau = cacCau(String(text || ''));
    const { TU_NOI } = require('./docde');
    const ra = cau.map((c, i) => {
      const tieng = cacTieng(c).map((t) => t.tu);
      const noi = tieng.filter((t) => TU_NOI.includes(t.toLowerCase()));
      return {
        so: i + 1,
        cau: c,
        soTieng: tieng.length,
        loai: loaiCau(c),
        soMenhDe: noi.length + 1,
        tuNoi: noi,
        daiQuaMuc: tieng.length > 30,
      };
    });
    return {
      ok: true,
      soCau: ra.length,
      cacCau: ra,
      theoLoai: ra.reduce((a, c) => { a[c.loai] = (a[c.loai] || 0) + 1; return a; }, {}),
      cauDaiNhat: ra.length ? ra.reduce((a, b) => (b.soTieng > a.soTieng ? b : a)) : null,
      ghiChu: 'Đo được độ dài, loại câu và số mệnh đề. Việc tách chủ ngữ — vị ngữ cần bộ phân tích cú pháp mà hệ thống này chưa có.',
    };
  }

  // ── Bài học bốn kỹ năng ─────────────────────────────────────────────────

  /**
   * Dựng bài học nghe — nói — đọc — viết từ một dạng bài có thật trong kho.
   * Mỗi kỹ năng lấy nguyên liệu từ học liệu đã thẩm định, không bịa.
   */
  baiHoc4KyNang(maDang, { soBai = 3 } = {}) {
    this.stats.baiHoc++;
    if (!this.bank) return { ok: false, error: 'CHƯA_GẮN_KHO_HỌC_LIỆU' };
    let form = FORM_INDEX.get(maDang);
    if (!form) {
      const { BaiGiangPipeline } = require('../nexus/bai-giang');
      const t = new BaiGiangPipeline({}).timDang(maDang);
      if (!t.khop) return { ok: false, error: 'KHÔNG_CÓ_DẠNG_BÀI_KHỚP', goiY: t.goiY };
      form = FORM_INDEX.get(t.khop.ma);
    }
    const lop = Number((form.code.match(/^M(\d+)/) || [])[1]) || null;
    const bai = this.bank.query({ formCode: form.code, limit: soBai });
    if (!bai.length) {
      return { ok: false, error: 'KHO_CHƯA_CÓ_BÀI_CHO_DẠNG_NÀY', maDang: form.code,
        goi: 'Gieo học liệu cho dạng này trước (POST /content/seed).' };
    }

    const tuVung = this.tuVung.choDang(form.code);

    // ĐỌC — đề bài thật, kèm câu hỏi đọc hiểu rút từ cấu trúc của đề.
    const doc = {
      mucTieu: [`Đọc hiểu đề bài dạng "${form.name}"`, 'Tách được dữ kiện và yêu cầu'],
      baiDoc: bai.map((b, i) => ({ so: i + 1, de: b.stem })),
      cauHoi: bai.map((b, i) => ({
        so: i + 1,
        hoi: 'Đề bài cho biết điều gì, và yêu cầu tìm điều gì?',
        deSo: i + 1,
        goiYTraLoi: (b.solutionSteps || [])[0] || 'Đọc lại câu đầu của đề.',
      })),
      doDo: doDoc(bai.map((b) => b.stem).join(' ')),
    };

    // NGHE — lời giảng thật, đã có sẵn để bộ giọng đọc.
    const loiNghe = bai.flatMap((b, i) => [
      `Bài ${i + 1}. ${b.stem}`,
      ...(b.solutionSteps || []).map((s, j) => `Bước ${j + 1}. ${s}`),
      b.answer ? `Đáp số: ${b.answer}.` : '',
    ].filter(Boolean));
    const nghe = {
      mucTieu: ['Nghe và ghi lại được các bước giải', 'Nghe hiểu thuật ngữ toán bằng tai'],
      kichBan: loiNghe,
      soCau: loiNghe.length,
      cauHoi: [
        { so: 1, hoi: 'Bước đầu tiên của lời giải là gì?', mucDo: 'chi tiết' },
        { so: 2, hoi: 'Đáp số cuối cùng là bao nhiêu?', mucDo: 'chi tiết' },
        { so: 3, hoi: 'Vì sao phải làm bước đó trước?', mucDo: 'suy luận' },
      ],
      ghiChu: 'Kịch bản này đưa thẳng vào bộ đọc giọng nói được — không cần thu âm.',
    };

    // NÓI — luyện đọc thành tiếng đúng những tiếng KHÓ THẬT trong bài này.
    const tatCaTieng = cacTieng(bai.map((b) => `${b.stem} ${(b.solutionSteps || []).join(' ')}`).join(' '))
      .map((t) => t.tu.toLowerCase());
    const khoThat = [...new Set(tatCaTieng)]
      .map((t) => ({ tieng: t, p: parseSyllable(t) }))
      .filter((x) => x.p.ok && vanKho(x.tieng))
      .slice(0, 12)
      .map((x) => ({
        tieng: x.tieng,
        amDau: x.p.initial || '∅',
        amChinh: x.p.nucleus.text,
        amCuoi: x.p.coda || '∅',
        thanh: x.p.tone,
      }));
    const noi = {
      mucTieu: ['Đọc to đề bài rõ ràng', 'Phát âm đúng thuật ngữ toán'],
      luyenTieng: khoThat,
      luyenThuatNgu: tuVung.ok ? tuVung.items.slice(0, 8).map((x) => x.tu) : [],
      baiTap: [
        { ten: 'Đọc to đề bài', moTa: 'Đọc to bài 1, chú ý ngắt ở dấu phẩy.', thoiGian: '3 phút' },
        { ten: 'Giảng lại', moTa: 'Nói lại cách giải cho bạn nghe, không nhìn vở.', thoiGian: '5 phút' },
      ],
      ghiChu: khoThat.length
        ? `${khoThat.length} tiếng có vần khó lấy từ chính bài này, không phải danh sách chung.`
        : 'Bài này không có tiếng nào vần khó.',
    };

    // VIẾT — khung trình bày lời giải, kèm bảng tự kiểm lấy từ chuẩn văn phong.
    const viet = {
      mucTieu: ['Trình bày lời giải đủ năm phần', 'Viết đúng mạch "Ta có — Suy ra — Vậy"'],
      khung: [
        'Đề bài: (chép lại đề)',
        'Điều kiện xác định: (nếu có)',
        'Lời giải: Ta có… Suy ra… Do đó…',
        'Kiểm tra lại: thay kết quả vào đề',
        'Kết luận: Vậy…',
      ],
      baiMau: bai[0] ? {
        de: bai[0].stem,
        loiGiai: (bai[0].solutionSteps || []).map((s, j) => `Bước ${j + 1}. ${s}`).join('\n'),
        ketLuan: bai[0].answer ? `Vậy đáp số là ${bai[0].answer}.` : null,
      } : null,
      baiTap: bai.slice(1).map((b, i) => ({ so: i + 1, de: b.stem, yeuCau: 'Trình bày đủ năm phần.' })),
      tuKiem: [
        'Có đủ Đề bài · Lời giải · Kết luận chưa?',
        'Mỗi bước có nêu lý do chưa?',
        'Có dùng "Ta có", "Suy ra", "Vậy" chưa?',
        'Ký hiệu viết đúng chuẩn chưa (x² chứ không phải x^2)?',
        'Có viết tắt hay dùng từ nói chuyện không?',
      ],
    };

    // Soát chính bài học này bằng bốn cấp của chính mình.
    const vanBan = [...doc.baiDoc.map((x) => x.de), ...loiNghe].join('\n');
    const tuSoat = this.soat(vanBan, { lop });

    return {
      ok: true,
      maDang: form.code,
      tenDang: form.name,
      lop,
      nguon: 'kho học liệu đã thẩm định',
      soBaiDung: bai.length,
      tuVung: tuVung.ok ? tuVung.items : [],
      nghe, noi, doc, viet,
      tuSoat: { dat: tuSoat.dat, diem: tuSoat.diem, tomTat: tuSoat.tomTat },
    };
  }

  /** Bài học ra dạng văn bản in được. */
  baiHocRaChu(b) {
    if (!b.ok) return '';
    const d = [`# Bài học bốn kỹ năng: ${b.tenDang}`, '',
      `Mã dạng ${b.maDang} · lớp ${b.lop ?? '—'} · nguồn: ${b.nguon}`, ''];
    d.push('## 1. NGHE', '', '**Mục tiêu:** ' + b.nghe.mucTieu.join(' · '), '', '**Kịch bản nghe:**', '');
    for (const c of b.nghe.kichBan) d.push(`- ${c}`);
    d.push('', '**Câu hỏi:**', '');
    for (const c of b.nghe.cauHoi) d.push(`${c.so}. (${c.mucDo}) ${c.hoi}`);
    d.push('', '## 2. NÓI', '', '**Luyện tiếng khó trong bài:**', '');
    for (const t of b.noi.luyenTieng) d.push(`- **${t.tieng}** — âm đầu ${t.amDau}, âm chính ${t.amChinh}, âm cuối ${t.amCuoi}, thanh ${t.thanh}`);
    if (b.noi.luyenThuatNgu.length) d.push('', '**Thuật ngữ cần nói đúng:** ' + b.noi.luyenThuatNgu.join(' · '));
    d.push('', '## 3. ĐỌC', '');
    for (const x of b.doc.baiDoc) d.push(`**Đề ${x.so}.** ${x.de}`, '');
    d.push(`*Độ đọc: ${b.doc.doDo.tiengMoiCau} tiếng/câu, câu dài nhất ${b.doc.doDo.cauDaiNhat} tiếng.*`, '');
    d.push('## 4. VIẾT', '', '**Khung trình bày:**', '');
    for (const k of b.viet.khung) d.push(`- ${k}`);
    if (b.viet.baiMau) {
      d.push('', '**Bài mẫu:**', '', b.viet.baiMau.de, '', b.viet.baiMau.loiGiai);
      if (b.viet.baiMau.ketLuan) d.push('', b.viet.baiMau.ketLuan);
    }
    d.push('', '**Tự kiểm trước khi nộp:**', '');
    for (const t of b.viet.tuKiem) d.push(`- [ ] ${t}`);
    return d.join('\n');
  }

  // ── Soi cả kho học liệu ─────────────────────────────────────────────────

  /**
   * Soát ngôn ngữ TOÀN BỘ kho học liệu, chấm theo đúng lớp của từng dạng bài.
   * Đây là việc không ai ngồi làm tay nổi: vài nghìn đề bài, mỗi đề phải đối
   * chiếu với ngưỡng đọc và từ vựng của đúng lớp nó thuộc về.
   */
  auditKho({ limitMoiDang = 50, chiLoi = true } = {}) {
    if (!this.bank) return { ok: false, error: 'CHƯA_GẮN_KHO_HỌC_LIỆU' };
    const t0 = Date.now();
    const hang = [];
    let soBai = 0;
    const demLoi = {};

    for (const f of FORM_INDEX.values()) {
      for (const b of this.bank.query({ formCode: f.code, limit: limitMoiDang })) {
        soBai++;
        const lop = lopCuaBai(f, b);
        // Đề bài soát đủ; các bước giải là MẢNH CÂU nối tiếp nhau nên không
        // đòi hỏi viết hoa đầu dòng — đòi ở đó là bắt lỗi oan.
        const rDe = this.soat(goNguonNgoaiNgu(b), { lop });
        // Soát CẢ thao tác lẫn căn cứ. Căn cứ cũng là câu chữ người học đọc,
        // nên nó phải chịu đúng chuẩn chính tả và văn phong như phần thao tác —
        // miễn trừ nó thì nửa lời giải không ai soát.
        const vanBuoc = cacBuoc(b).map(vanBanDayDu).filter(Boolean).join(' ');
        const rBuoc = vanBuoc ? this.soat(vanBuoc, { lop }) : null;
        const r = rDe;
        const loi = [
          ...r.cap1ChinhTa.loi,
          ...r.cap2VanPhong.loi.filter((l) => l.muc === 'LOI'),
          ...(r.cap3DoDoc ? r.cap3DoDoc.loi : []),
          ...(r.cap4TuVung ? r.cap4TuVung.loi : []),
          ...(rBuoc ? rBuoc.cap1ChinhTa.loi.filter((l) => l.ma !== 'KHONG_VIET_HOA' && l.ma !== 'THIEU_DAU_KET_CAU') : []),
        ];
        for (const l of loi) demLoi[l.ma] = (demLoi[l.ma] || 0) + 1;
        if (chiLoi && r.dat && !loi.length) continue;
        hang.push({
          id: b.id, maDang: f.code, lop,
          dat: r.dat, diem: r.diem,
          tiengMoiCau: r.cap3DoDoc ? r.cap3DoDoc.doDo.tiengMoiCau : null,
          loi: loi.map((l) => ({ ma: l.ma, moTa: l.moTa })),
          de: String(b.stem).slice(0, 80),
        });
      }
    }

    hang.sort((a, b) => a.diem - b.diem);
    const khongDat = hang.filter((h) => !h.dat).length;
    return {
      ok: true,
      soBai,
      soCanXem: hang.length,
      khongDat,
      tiLeDat: soBai ? round((soBai - khongDat) / soBai, 3) : 1,
      loiThuongGap: Object.entries(demLoi).sort((a, b) => b[1] - a[1]).map(([ma, n]) => ({ ma, soLan: n })),
      items: hang.slice(0, 100),
      ms: Date.now() - t0,
    };
  }

  // ── Chẩn đoán năng lực ngôn ngữ của học viên ────────────────────────────

  /**
   * Chẩn đoán dựa trên DỮ LIỆU HỌC THẬT.
   * Không có dữ liệu thì không chẩn đoán — một bản chẩn đoán dựng từ hồ sơ
   * khai báo chỉ là lời phỏng đoán mặc áo báo cáo.
   */
  chanDoan(learnerId) {
    if (!learnerId) return { ok: false, error: 'THIẾU_MÃ_HỌC_VIÊN' };
    if (!this.telemetry || !this.behavior) return { ok: false, error: 'CHƯA_GẮN_DỮ_LIỆU_HỌC' };
    const hv = this.behavior.analyze ? this.behavior.analyze(learnerId) : null;
    if (!hv || hv.ok === false) {
      return { ok: false, error: 'CHƯA_CÓ_DỮ_LIỆU_HỌC', learnerId,
        goi: 'Học viên cần làm ít nhất một phiên luyện để hệ thống có cái mà đo.' };
    }
    return {
      ok: true, learnerId,
      nguon: 'telemetry và phân tích hành vi thật',
      hanhVi: hv,
      ghiChu: 'Đây là chẩn đoán hành vi học. Năng lực ngôn ngữ (nghe-nói-đọc-viết) '
        + 'cần bài kiểm tra ngôn ngữ riêng — hệ thống hiện đo được độ đọc của HỌC LIỆU, '
        + 'chưa đo được kỹ năng ngôn ngữ của học viên.',
    };
  }

  status() {
    return {
      cap: ['chính tả', 'văn phong', 'độ đọc theo lớp', 'từ vựng theo lớp'],
      canKhoa: { soat: false, amTiet: false, phanTichCau: false, baiHoc4KyNang: false },
      tuVung: this.tuVung.status(),
      nguongLop: NGUONG_LOP,
      nguongLaQuyUoc: true,
      hieuChinh: this.bank ? thongKeTheoLop(this.bank) : null,
      stats: { ...this.stats },
    };
  }
}

module.exports = {
  goNguonNgoaiNgu, LanguageScientist, boNgoaiNgu, lopChuanCuaDang, lopCuaBai, TANG_SANG_LOP, loaiCau };
