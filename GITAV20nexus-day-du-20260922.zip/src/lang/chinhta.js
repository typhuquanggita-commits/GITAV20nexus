'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  CHUẨN CHÍNH TẢ TIẾNG VIỆT — soát bằng cấu trúc âm tiết, không bằng từ điển
 * ═══════════════════════════════════════════════════════════════════════════
 *  Một bộ soát chính tả dựa trên từ điển bao giờ cũng thiếu: tiếng Việt có
 *  hàng vạn từ ghép, tên riêng, thuật ngữ. Nhưng tiếng Việt có một thứ mà
 *  tiếng Anh không có — ÂM TIẾT CÓ LUẬT. Mỗi tiếng là (âm đầu) + (âm đệm) +
 *  âm chính + (âm cuối) + thanh điệu, và tập hợp các mảnh ấy là hữu hạn.
 *
 *  Vì vậy chỗ này soát bằng LUẬT CẤU TẠO: "ngiêm" sai vì "ngi" không phải âm
 *  đầu hợp lệ; "trứơc" sai vì dấu đặt lệch khỏi âm chính. Cách này bắt được
 *  lỗi gõ máy và lỗi đặt dấu — hai loại lỗi chiếm phần lớn trong văn bản soạn
 *  vội — mà không cần bất kỳ từ điển nào.
 *
 *  Chỗ nó KHÔNG làm được thì nói thẳng:
 *   · Không biết "bàn" hay "bàng" mới đúng trong câu, vì cả hai đều là âm
 *     tiết hợp lệ. Đó là việc của người, hoặc của mô hình có người duyệt.
 *   · Không bắt được lỗi gõ mà phần sai lại tách ra thành hai âm tiết hợp
 *     lệ: "ngiêm" tách được thành "ngi" + "êm", cả hai đều đúng luật. Đây là
 *     cái giá phải trả để KHÔNG báo oan những từ mượn viết liền như
 *     "lôgarit", "vectơ", "xentimét" — báo oan từ đúng làm người dùng mất
 *     tin vào cả bộ soát, còn bỏ sót một lỗi hiếm thì người đọc lại vẫn thấy.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { parseSyllable, TONES } = require('../voice/phonemizer');

/** Nguyên âm mang dấu, theo thứ tự để dựng lại chữ có dấu. */
const NGUYEN_AM = {
  a: ['a', 'á', 'à', 'ả', 'ã', 'ạ'],
  ă: ['ă', 'ắ', 'ằ', 'ẳ', 'ẵ', 'ặ'],
  â: ['â', 'ấ', 'ầ', 'ẩ', 'ẫ', 'ậ'],
  e: ['e', 'é', 'è', 'ẻ', 'ẽ', 'ẹ'],
  ê: ['ê', 'ế', 'ề', 'ể', 'ễ', 'ệ'],
  i: ['i', 'í', 'ì', 'ỉ', 'ĩ', 'ị'],
  o: ['o', 'ó', 'ò', 'ỏ', 'õ', 'ọ'],
  ô: ['ô', 'ố', 'ồ', 'ổ', 'ỗ', 'ộ'],
  ơ: ['ơ', 'ớ', 'ờ', 'ở', 'ỡ', 'ợ'],
  u: ['u', 'ú', 'ù', 'ủ', 'ũ', 'ụ'],
  ư: ['ư', 'ứ', 'ừ', 'ử', 'ữ', 'ự'],
  y: ['y', 'ý', 'ỳ', 'ỷ', 'ỹ', 'ỵ'],
};
/** Thứ tự thanh điệu khớp với chỉ số trong NGUYEN_AM. */
const THANH = ['ngang', 'sắc', 'huyền', 'hỏi', 'ngã', 'nặng'];
const CHI_SO_THANH = Object.fromEntries(THANH.map((t, i) => [t, i]));

/** Bảng ngược: chữ có dấu → { gốc, thanh }. */
const TRA_NGUOC = {};
for (const [goc, ds] of Object.entries(NGUYEN_AM)) {
  ds.forEach((ch, i) => { TRA_NGUOC[ch] = { goc, thanh: THANH[i] }; });
}

/**
 * Teencode và lối viết tắt của tin nhắn. Không phải "sai tiếng Việt" trong
 * đời sống, nhưng tuyệt đối không được xuất hiện trong học liệu.
 */
const TEENCODE = {
  // "kg" KHÔNG nằm ở đây: đó là ki-lô-gam, đơn vị khối lượng có trong mọi
  // đề toán tiểu học.
  ko: 'không', k: 'không', hok: 'không', khum: 'không',
  dc: 'được', đc: 'được', dk: 'được', ok: 'được',
  j: 'gì', z: 'gì', ji: 'gì', v: 'vậy',
  bik: 'biết', bit: 'biết', thik: 'thích', thick: 'thích',
  wa: 'quá', qua: null, roi: 'rồi', r: 'rồi',
  nhiu: 'nhiêu', nhju: 'nhiêu', mik: 'mình', mk: 'mình',
  bn: 'bạn', b: 'bạn', e: 'em', a: null,
  cx: 'cũng', cug: 'cũng', vs: 'với', vn: null,
  ntn: 'như thế nào', nhma: 'nhưng mà', tks: 'cảm ơn', thanks: 'cảm ơn',
  ny: 'người yêu', gato: 'ghen tị', ghê_ta: null,
};
/** Chỉ bắt khi đứng riêng một mình và viết thường — "a" trong "a = 1" là hệ số. */
const TEENCODE_BAT = new Set(['ko', 'hok', 'khum', 'dc', 'đc', 'dk', 'bik', 'bit',
  'thik', 'thick', 'wa', 'nhiu', 'nhju', 'mik', 'mk', 'bn', 'cx', 'cug', 'ntn', 'nhma',
  'tks', 'ny', 'gato', 'ji']);

/**
 * Cặp chữ mà sách giáo khoa hiện hành CHỌN MỘT.
 * Không đưa vào đây những cặp còn tranh luận (kỹ/kĩ, mỹ/mĩ, lý/lí đều được
 * chấp nhận) — bắt lỗi thứ đang được phép dùng là bắt oan.
 */
const CHINH_TA_SGK = [
  { sai: /\bqui (định|tắc|ước|trình|mô|luật|chuẩn|nạp)\b/gi, dung: 'quy $1' },
  { sai: /\bxử dụng\b/gi, dung: 'sử dụng' },
  { sai: /\bsáng lạn\b/gi, dung: 'xán lạn' },
  { sai: /\bchia sẻ\b/gi, dung: null },
  { sai: /\bxúc tích\b/gi, dung: 'súc tích' },
  { sai: /\byếu điểm\b(?=.{0,40}(kém|hạn chế|khắc phục))/gi, dung: 'điểm yếu (yếu điểm nghĩa là điểm quan trọng)' },
  { sai: /\bcọ sát\b/gi, dung: 'cọ xát' },
  { sai: /\bsuông sẻ\b/gi, dung: 'suôn sẻ' },
  { sai: /\btham quan\b/gi, dung: null },
  { sai: /\bthăm quan\b/gi, dung: 'tham quan' },
  { sai: /\bvô hình chung\b/gi, dung: 'vô hình trung' },
  { sai: /\bđường xá\b/gi, dung: 'đường sá' },
  { sai: /\bbàng quang\b(?=.{0,30}(thái độ|thờ ơ|với))/gi, dung: 'bàng quan' },
  { sai: /\bchẩn đoán\b(?=.{0,20}(văn|chính tả))/gi, dung: null },
  { sai: /\bdấu diếm\b/gi, dung: 'giấu giếm' },
  { sai: /\bgiả thiết\b(?=.{0,30}(khoa học|nghiên cứu))/gi, dung: 'giả thuyết' },
  { sai: /\bsáp nhập\b/gi, dung: 'sáp nhập hoặc sát nhập — sách giáo khoa dùng "sáp nhập"' },
].filter((r) => r.dung !== null);

// ── Đặt dấu thanh ──────────────────────────────────────────────────────────

/** Bỏ dấu thanh khỏi một chữ cái, trả về { gốc, thanh }. */
function boThanh(ch) {
  return TRA_NGUOC[ch] || { goc: ch, thanh: null };
}

/** Đặt dấu thanh lên một chữ cái nguyên âm. */
function datThanh(ch, thanh) {
  const g = boThanh(ch).goc;
  const ds = NGUYEN_AM[g];
  if (!ds) return ch;
  return ds[CHI_SO_THANH[thanh] ?? 0];
}

/**
 * Vị trí ĐÚNG của dấu thanh trong một âm tiết.
 *
 * Luật: dấu thanh đặt trên ÂM CHÍNH.
 *  · Âm chính một nguyên âm → đặt ngay trên nó.
 *  · Âm chính là nguyên âm đôi:
 *      - có âm cuối  → đặt trên nguyên âm THỨ HAI  (cuộc, nghiêng, tiếng)
 *      - không âm cuối → đặt trên nguyên âm THỨ NHẤT (của, mía, thuở)
 *
 * Đây là "kiểu mới", đúng với sách giáo khoa hiện hành: hoà, thuỷ, quỳ.
 * "Kiểu cũ" (hòa, thủy) đặt dấu ở giữa cho cân mắt; cả hai đều đọc được, nên
 * hệ thống KHÔNG coi kiểu cũ là sai — chỉ đòi hỏi một văn bản dùng nhất quán
 * một kiểu.
 */
function viTriDauThanh(amTiet) {
  const p = parseSyllable(amTiet);
  if (!p.ok) return null;
  const { glide, nucleus, coda } = p;
  const truoc = (p.initial || '') + (glide || '');
  const nuc = nucleus.text;
  // Âm chính một nguyên âm: kiểu mới đặt ngay trên nó; kiểu cũ lùi về âm đệm
  // nếu có ("hòa" thay vì "hoà").
  if (nuc.length === 1) {
    return { viTri: truoc.length, chu: nuc, kieuCu: glide ? (p.initial || '').length : truoc.length };
  }
  const moi = coda ? truoc.length + 1 : truoc.length;
  // Kiểu cũ đặt dấu cho cân mắt, tức là lùi về chữ âm đệm khi có âm đệm:
  // "hòa" thay vì "hoà", "thủy" thay vì "thuỷ". Không có âm đệm thì hai kiểu
  // trùng nhau.
  const cu = glide ? (p.initial || '').length : moi;
  return { viTri: moi, kieuCu: cu, chu: nuc[moi - truoc.length] };
}

/**
 * Viết lại một âm tiết với dấu thanh đặt đúng chỗ.
 * Trả về null nếu không phải âm tiết tiếng Việt.
 */
function datLaiDauThanh(amTiet, { kieu = 'moi' } = {}) {
  const raw = String(amTiet);
  const chu = [...raw.normalize('NFC')];
  let thanh = null;
  const tran = chu.map((c) => {
    const b = boThanh(c);
    if (b.thanh && b.thanh !== 'ngang') thanh = b.thanh;
    return b.goc;
  });
  const tranStr = tran.join('');
  if (!thanh) return tranStr === raw ? raw : tranStr;
  const vt = viTriDauThanh(tranStr);
  if (!vt) return null;
  const dat = kieu === 'cu' ? vt.kieuCu : vt.viTri;
  const ra = [...tranStr];
  if (dat >= ra.length) return null;
  ra[dat] = datThanh(ra[dat], thanh);
  return ra.join('');
}

// ── Soát một đoạn văn ──────────────────────────────────────────────────────

/**
 * Bảng chữ cái tiếng Việt, DỰNG BẰNG MÁY từ bảng nguyên âm phía trên.
 *
 * Không gõ tay danh sách chữ: gõ tay thì sót, và một chữ bị sót sẽ cắt đôi
 * mọi tiếng chứa nó — "Viết" từng bị tách thành "Vi" và "t" vì thiếu chữ "ế",
 * kéo theo phép đếm tiếng sai ở mọi nơi dùng đến nó.
 *
 * Cũng KHÔNG dùng dải [À-ỹ]: dải đó là U+00C0–U+1EF9, nuốt trọn cả bảng chữ
 * Hy Lạp — ký hiệu toán "Δ" sẽ bị đem đi soát chính tả tiếng Việt.
 */
const CHU_THUONG = `a-z${Object.values(NGUYEN_AM).flat().join('')}đ`;
const CHU_VIET = `A-Za-z${Object.values(NGUYEN_AM).flat().join('')}${Object.values(NGUYEN_AM).flat().join('').toLocaleUpperCase('vi')}đĐ`;
const RE_TIENG = new RegExp(`[${CHU_VIET}]+`, 'gu');
const RE_THUONG = new RegExp(`^[${CHU_THUONG}]`, 'u');

/** Tách văn bản thành các "tiếng" để soát, giữ vị trí để trích dẫn được. */
function cacTieng(text) {
  const ra = [];
  const re = new RegExp(RE_TIENG.source, 'gu');
  let m;
  while ((m = re.exec(text)) !== null) ra.push({ tu: m[0], viTri: m.index });
  return ra;
}

/** Cắt câu tiếng Việt. Không cắt ở dấu chấm của số thập phân hay viết tắt. */
function cacCau(text) {
  const s = String(text || '').replace(/\s+/g, ' ').trim();
  if (!s) return [];
  const ra = [];
  let dem = '';
  const chu = [...s];
  for (let i = 0; i < chu.length; i++) {
    const c = chu[i];
    dem += c;
    if (!'.!?…'.includes(c)) continue;
    const truoc = chu[i - 1] || '';
    const sau = chu[i + 1] || '';
    if (c === '.' && /\d/.test(truoc) && /\d/.test(sau)) continue;   // 3.14
    if (c === '.' && /[A-ZĐ]/.test(truoc) && dem.trim().length <= 3) continue; // T.P
    if (sau && sau !== ' ') continue;
    ra.push(dem.trim());
    dem = '';
  }
  if (dem.trim()) ra.push(dem.trim());
  return ra;
}

/**
 * Từ mượn viết liền nhiều âm tiết: "lôgarit", "vectơ", "xentimét".
 * Tách được thành các âm tiết hợp lệ thì đó là từ đúng, không phải lỗi gõ.
 */
function ghepDuocTuAmTiet(tu, mucToiDa = 3) {
  const t = String(tu).toLowerCase();
  const thu = (con, conLai) => {
    if (!con) return true;
    if (conLai === 0) return false;
    for (let n = Math.min(con.length, 5); n >= 1; n--) {
      if (parseSyllable(con.slice(0, n)).ok && thu(con.slice(n), conLai - 1)) return true;
    }
    return false;
  };
  return thu(t, mucToiDa);
}


/** Trích một đoạn quanh vị trí lỗi. */
function trich(s, i, ban = 20) {
  const a = Math.max(0, i - ban);
  return `${a > 0 ? '…' : ''}${s.slice(a, i + ban).replace(/\s+/g, ' ')}${i + ban < s.length ? '…' : ''}`;
}

/**
 * Soát chính tả và cách trình bày của một đoạn văn tiếng Việt.
 * @param {string} text
 * @param {object} o  boQua: mảng mã lỗi bỏ qua; kieuDau: 'moi' | 'cu' | 'tudo'
 */
function soatChinhTa(text, { boQua = [], kieuDau = 'tudo' } = {}) {
  // Công thức toán KHÔNG phải lời văn: "$\\text{ƯCLN}(36, 88)$" mà đem soát
  // chính tả thì "text", "ƯCLN" đều bị báo là âm tiết sai. Ký hiệu toán đã có
  // cửa soát riêng (src/math/kyhieu.js); ở đây thay bằng một chỗ trống trung
  // tính để cấu trúc câu vẫn nguyên.
  // Giữ lại dấu kết câu nằm cuối công thức ("Tính: $2 + 7 = ?$" vẫn là một
  // câu hỏi hoàn chỉnh), nếu không thì bộ soát báo thiếu dấu kết câu oan.
  const s = String(text || '')
    .replace(/\$([^$]*)\$/g, (_, than) => (/[?!.]\s*$/.test(than) ? `X${than.trim().slice(-1)}` : 'X'))
    .replace(/\\[a-zA-Z]+\s*(\{[^{}]*\})?/g, 'X');
  const loi = [];
  const them = (muc, ma, moTa, cach, viTri) => {
    if (boQua.includes(ma)) return;
    loi.push({ muc, ma, moTa, cach, viTri: viTri ?? null });
  };

  // ── 1. Âm tiết không hợp luật cấu tạo ──
  const khongDoc = [];
  const datSai = [];
  const kieuDaDung = new Set();
  for (const { tu, viTri } of cacTieng(s)) {
    const thuong = tu.toLowerCase();
    if (thuong.length > 7) continue;                     // chắc chắn không phải một tiếng
    // Một chữ cái đứng lẻ không phải âm tiết mà là ký hiệu hoặc đơn vị:
    // "đ" là đồng, "m" là mét, "x" là ẩn số. Báo nó sai chính tả là báo sai.
    if (thuong.length === 1) continue;
    // Viết hoa toàn bộ là chữ viết tắt hoặc ký hiệu: ƯCLN, BCNN, ABC.
    if (tu === tu.toUpperCase() && tu.length >= 2) continue;
    const p = parseSyllable(thuong);
    if (!p.ok) {
      // Chỉ báo khi chữ có dấu tiếng Việt — chuỗi thuần a-z rất có thể là
      // tiếng nước ngoài, tên biến hay ký hiệu. Và phải chắc chắn nó không
      // phải từ mượn viết liền như "lôgarit", "vectơ".
      if (/[à-ỹđ]/i.test(thuong) && !ghepDuocTuAmTiet(thuong)) khongDoc.push({ tu, viTri, vi: p.error });
      continue;
    }
    if (ghepDuocTuAmTiet(thuong, 1) === false) continue;   // từ mượn nhiều âm tiết: không xét đặt dấu
    const dung = datLaiDauThanh(thuong, { kieu: 'moi' });
    const cu = datLaiDauThanh(thuong, { kieu: 'cu' });
    if (dung && thuong === dung && cu !== dung) kieuDaDung.add('moi');
    if (cu && thuong === cu && cu !== dung) kieuDaDung.add('cu');
    if (dung && cu && thuong !== dung && thuong !== cu) datSai.push({ tu, viTri, dung });
  }
  for (const x of khongDoc.slice(0, 8)) {
    them('LOI', 'AM_TIET_SAI', `"${x.tu}" không đúng cấu tạo âm tiết tiếng Việt (${x.vi})`, 'Kiểm tra lại cách gõ.', x.viTri);
  }
  for (const x of datSai.slice(0, 8)) {
    them('LOI', 'DAU_THANH_SAI', `"${x.tu}" đặt dấu thanh sai chỗ`, `Viết "${x.dung}".`, x.viTri);
  }
  if (kieuDaDung.size === 2) {
    them('CANH_BAO', 'DAU_THANH_LAN_KIEU', 'Văn bản lẫn cả hai kiểu đặt dấu (hoà/hòa)',
      'Chọn một kiểu và dùng nhất quán; sách giáo khoa hiện hành dùng kiểu "hoà".');
  }
  if (kieuDau !== 'tudo' && kieuDaDung.size && !kieuDaDung.has(kieuDau)) {
    them('CANH_BAO', 'SAI_KIEU_DAU', `Văn bản dùng kiểu đặt dấu "${[...kieuDaDung][0]}" trong khi quy ước là "${kieuDau}"`, 'Chạy chuanHoaChinhTa() để đổi đồng loạt.');
  }

  // ── 2. Teencode ──
  const teen = [];
  for (const { tu, viTri } of cacTieng(s)) {
    const t = tu.toLowerCase();
    if (tu === t && TEENCODE_BAT.has(t)) teen.push({ tu, viTri, dung: TEENCODE[t] });
  }
  for (const x of teen.slice(0, 6)) {
    them('LOI', 'TEENCODE', `"${x.tu}" là lối viết tin nhắn`, `Viết đủ: "${x.dung}".`, x.viTri);
  }

  // ── 3. Cặp chữ sách giáo khoa chọn một ──
  for (const r of CHINH_TA_SGK) {
    const m = s.match(r.sai);
    if (m) them('LOI', 'CHINH_TA_SGK', `"${m[0]}" không đúng chuẩn`, `Viết "${m[0].replace(r.sai, r.dung)}".`, s.indexOf(m[0]));
  }

  // ── 4. Cách trình bày ──
  const trinhBay = [
    [/ {2,}/, 'THUA_DAU_CACH', 'Có chỗ gõ từ hai dấu cách liền nhau', 'Chỉ dùng một dấu cách.'],
    [/[ \t]+[,;.!?](?![.\d])/, 'DAU_CACH_TRUOC_DAU_CAU', 'Có dấu cách trước dấu câu', 'Dấu câu viết sát chữ đứng trước.'],
    [/[,;:](?=[^\s\d)"'”])/, 'THIEU_DAU_CACH_SAU_DAU_CAU', 'Thiếu dấu cách sau dấu phẩy hoặc chấm phẩy', 'Sau dấu câu phải có một dấu cách.'],
    [new RegExp(`[${CHU_THUONG}]\\.[A-ZÀ-Ỹ]`, 'u'), 'THIEU_DAU_CACH_SAU_CHAM', 'Thiếu dấu cách sau dấu chấm', 'Sau dấu chấm phải có một dấu cách.'],
    [new RegExp(`([${CHU_THUONG}])\\1{2,}`, 'iu'), 'LAP_CHU', 'Có chữ cái lặp ba lần trở lên (kiểu "haayyy")', 'Viết đúng chính tả.'],
    [/\.{4,}/, 'CHAM_LUNG_SAI', 'Dấu chấm lửng phải đúng ba chấm', 'Dùng "…" hoặc đúng ba dấu chấm.'],
  ];
  for (const [re, ma, moTa, cach] of trinhBay) {
    const m = s.match(re);
    if (m) them('CANH_BAO', ma, `${moTa}: "${trich(s, m.index)}"`, cach, m.index);
  }

  // ── 5. Câu không viết hoa chữ đầu ──
  const cau = cacCau(s);
  const khongHoa = cau.filter((c) => RE_THUONG.test(c.trim()));
  if (khongHoa.length) {
    them('CANH_BAO', 'KHONG_VIET_HOA', `${khongHoa.length} câu không viết hoa chữ đầu (ví dụ: "${khongHoa[0].slice(0, 30)}…")`, 'Viết hoa chữ cái đầu câu.');
  }

  // ── 6. Câu không có dấu chấm kết thúc ──
  // Mẩu chữ cuối ngắn dưới bốn tiếng thường là tiêu đề hay nhãn, không phải
  // câu — đòi dấu chấm ở đó là đòi sai.
  const cuoi = cau.length ? cau[cau.length - 1] : '';
  if (cau.length && cacTieng(cuoi).length >= 4 && !/[.!?…:)]$/.test(cuoi)) {
    them('CANH_BAO', 'THIEU_DAU_KET_CAU', 'Câu cuối chưa có dấu kết thúc', 'Thêm dấu chấm.');
  }

  // ── 7. Cả câu không dấu ──
  const cauKhongDau = cau.filter((c) => {
    const tieng = c.split(/\s+/).filter((t) => /^[A-Za-z]{2,}$/.test(t));
    return tieng.length >= 5 && !/[à-ỹđĐ]/i.test(c);
  });
  if (cauKhongDau.length) {
    them('LOI', 'VIET_KHONG_DAU', `${cauKhongDau.length} câu viết không dấu ("${cauKhongDau[0].slice(0, 35)}…")`, 'Học liệu phải viết đủ dấu.');
  }

  // ── 8. Văn bản có dấu nhưng lác đác chỗ gõ thiếu dấu ──
  // Không bắt được chắc chắn: "cho", "do", "ba" viết không dấu vẫn là tiếng
  // Việt hợp lệ. Nhưng một văn bản đang viết có dấu mà xen nhiều tiếng thuần
  // a-z thì gần như chắc là gõ vội, nên báo để người soạn tự nhìn lại.
  const tatCaTieng = cacTieng(s).map((t) => t.tu);
  if (tatCaTieng.length >= 12) {
    const coDau = tatCaTieng.filter((t) => /[à-ỹđ]/i.test(t)).length;
    // Bỏ qua chữ viết hoa toàn bộ: mã dạng bài "M9.PT2.GIAI" hay chữ viết
    // tắt "ƯCLN" không phải là chỗ gõ thiếu dấu.
    const thuanAscii = tatCaTieng.filter((t) => /^[a-z]{3,}$/.test(t)).length;
    const tiLeDau = coDau / tatCaTieng.length;
    const tiLeAscii = thuanAscii / tatCaTieng.length;
    if (tiLeDau >= 0.2 && tiLeAscii >= 0.25) {
      them('CANH_BAO', 'LAC_CHO_THIEU_DAU',
        `${Math.round(tiLeDau * 100)}% tiếng có dấu nhưng ${Math.round(tiLeAscii * 100)}% tiếng viết thuần a-z`,
        'Soát lại những chỗ gõ thiếu dấu.');
    }
  }

  const soLoi = loi.filter((l) => l.muc === 'LOI').length;
  const soCanhBao = loi.length - soLoi;
  return {
    ok: soLoi === 0,
    soLoi,
    soCanhBao,
    loi,
    soCau: cau.length,
    soTieng: cacTieng(s).length,
    diem: Math.max(0, 100 - soLoi * 12 - soCanhBao * 4),
  };
}

/**
 * Sửa những lỗi trình bày SỬA ĐƯỢC BẰNG MÁY mà không đổi nghĩa.
 * Cố ý KHÔNG tự sửa chính tả từ vựng: máy không biết người viết định nói
 * "bàn" hay "bàng", sửa bừa là làm hỏng nội dung.
 */
function chuanHoaChinhTa(text, { kieuDau = null } = {}) {
  if (typeof text !== 'string') return text;
  let s = text.normalize('NFC');
  s = s.replace(/\r\n?/g, '\n');
  s = s.replace(/[ \t]{2,}/g, ' ');
  s = s.replace(/[ \t]+([,;.!?…])/g, '$1');
  s = s.replace(/([,;:])(?=[^\s\d)"'”])/g, '$1 ');
  s = s.replace(/([a-zà-ỹđ])\.([A-ZÀ-ỸĐ])/g, '$1. $2');
  s = s.replace(/\.{3,}/g, '…');
  s = s.replace(/[ \t]+$/gm, '');

  if (kieuDau === 'moi' || kieuDau === 'cu') {
    s = s.replace(new RegExp(RE_TIENG.source, 'gu'), (tu) => {
      if (tu.length > 7 || !/[à-ỹ]/i.test(tu)) return tu;
      const hoa = tu[0] === tu[0].toUpperCase() && tu[0] !== tu[0].toLowerCase();
      const ra = datLaiDauThanh(tu.toLowerCase(), { kieu: kieuDau });
      if (!ra) return tu;
      return hoa ? ra[0].toUpperCase() + ra.slice(1) : ra;
    });
  }
  return s;
}

module.exports = {
  soatChinhTa, chuanHoaChinhTa, datLaiDauThanh, viTriDauThanh,
  cacCau, cacTieng, boThanh, datThanh, ghepDuocTuAmTiet, CHU_VIET, CHU_THUONG,
  TEENCODE, CHINH_TA_SGK, NGUYEN_AM, THANH,
};
