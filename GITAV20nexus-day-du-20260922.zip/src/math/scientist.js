'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  NHÀ KHOA HỌC TOÁN — đọc vị đề, lập pháp đồ, giải nhiều cách, trình bày
 * ═══════════════════════════════════════════════════════════════════════════
 *  Điều khác biệt của tệp này so với một lớp vỏ gọi mô hình ngôn ngữ:
 *
 *   TÍNH TOÁN THẬT TRƯỚC, MÔ HÌNH SAU. Hệ số, biệt thức, nghiệm, cách nhẩm
 *   nghiệm — tất cả tính bằng bộ máy toán của hệ thống (src/math/verifier.js),
 *   chạy ngoại tuyến, không cần khoá, và luôn đúng. Mô hình ngôn ngữ chỉ được
 *   mời vào những chỗ nó thật sự giỏi hơn: diễn đạt, liên hệ thực tiễn.
 *
 *   KHÔNG DẬP KHUÔN. Mỗi cách giải chỉ được đưa ra khi nó THẬT SỰ ÁP DỤNG
 *   ĐƯỢC cho phương trình đang xét: nhẩm nghiệm chỉ hiện khi a + b + c = 0
 *   hoặc a − b + c = 0; hằng đẳng thức chỉ hiện khi ∆ = 0; Vi-ét chỉ hiện khi
 *   nghiệm đẹp. Không có chuyện in ra ba cách giải cho mọi bài như nhau.
 *
 *   TỰ SOÁT LẠI. Bài trình bày xong bị đưa qua bộ thẩm định 4 cấp, trong đó
 *   cấp 4 thay nghiệm ngược vào phương trình. Bài nào không qua thì nói thẳng
 *   là không qua.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const MathVerifier = require('./verifier');
const { cacBuoc } = require('../content/loi-giai');
const { chuanHoa, chuanHoaSau, veAscii, lenSieu, xuongDuoi } = require('./kyhieu');
const { thamDinh } = require('./thamdinh');
const { kiemVanPhong } = require('./vanphong');
const { FORM_INDEX } = require('../curriculum/hierarchy');
const { round } = require('../utils');

// ── Số viết theo lối Việt Nam ──────────────────────────────────────────────

/** Tìm phân số tối giản gần đúng nhất cho một số thập phân (mẫu ≤ 200). */
function raPhanSo(x, mauToiDa = 200) {
  if (Number.isInteger(x)) return { tu: x, mau: 1 };
  const dau = x < 0 ? -1 : 1;
  const v = Math.abs(x);
  let tuTruoc = 1; let mauTruoc = 0; let tu = Math.floor(v); let mau = 1; let phan = v - tu;
  for (let i = 0; i < 24 && phan > 1e-12; i++) {
    const n = 1 / phan;
    const a = Math.floor(n);
    phan = n - a;
    [tuTruoc, tu] = [tu, a * tu + tuTruoc];
    [mauTruoc, mau] = [mau, a * mau + mauTruoc];
    if (mau > mauToiDa) { tu = tuTruoc; mau = mauTruoc; break; }
  }
  return mau > 0 && Math.abs(dau * (tu / mau) - x) < 1e-9 ? { tu: dau * tu, mau } : null;
}

/** Số hiện trên màn hình: nguyên thì để nguyên, hữu tỉ thì viết phân số. */
function soDep(x) {
  const v = round(Number(x), 10);
  if (Number.isInteger(v)) return String(v).replace('-', '−');
  const ps = raPhanSo(v);
  if (ps && ps.mau !== 1 && Math.abs(ps.mau) <= 200) {
    const t = `${Math.abs(ps.tu)}⁄${ps.mau}`;
    return ps.tu < 0 ? `−${t}` : t;
  }
  return String(round(v, 4)).replace('.', ',').replace('-', '−');
}

/** Hệ số đứng trước một đơn thức: 1x → x, −1x → −x, 0x → bỏ. */
function hang(he, bien) {
  if (he === 0) return '';
  if (!bien) return soDep(he);
  if (he === 1) return bien;
  if (he === -1) return `−${bien}`;
  return `${soDep(he)}${bien}`;
}

/** Ghép ax² + bx + c thành chuỗi đọc được, đúng dấu, không thừa số 1. */
function veTrai(a, b, c) {
  const p = [];
  if (a) p.push(hang(a, 'x²'));
  if (b) p.push(`${b > 0 && p.length ? ' + ' : p.length ? ' − ' : ''}${hang(p.length ? Math.abs(b) : b, 'x')}`);
  if (c) p.push(`${c > 0 && p.length ? ' + ' : p.length ? ' − ' : ''}${soDep(p.length ? Math.abs(c) : c)}`);
  return p.join('') || '0';
}

// ── Thư viện 24 phương pháp học (tầng phương pháp của GITA) ────────────────

const PHUONG_PHAP = {
  'doc-vi-de': { nhom: 'Đọc hiểu đề', ten: 'Đọc vị đề bài', moTa: 'Tách đề thành bốn lớp: dữ kiện, yêu cầu, ràng buộc, bẫy.', dau: ['không hiểu đề', 'không biết bắt đầu', 'đọc xong không biết làm', 'lạc đề'] },
  'so-do-hoa': { nhom: 'Đọc hiểu đề', ten: 'Sơ đồ hoá đề bài', moTa: 'Vẽ quan hệ giữa các dữ kiện thành sơ đồ.', dau: ['bài toán có lời văn', 'nhiều dữ kiện', 'rối'] },
  'tu-duy-nguoc': { nhom: 'Tư duy', ten: 'Tư duy ngược', moTa: 'Đi từ kết luận ngược về giả thiết.', dau: ['chứng minh', 'bí hướng', 'không biết đi đâu'] },
  'chia-nho': { nhom: 'Tư duy', ten: 'Chia nhỏ vấn đề', moTa: 'Cắt bài lớn thành các bài nhỏ giải được.', dau: ['bài dài', 'nhiều bước', 'nản'] },
  'quy-la-ve-quen': { nhom: 'Tư duy', ten: 'Quy lạ về quen', moTa: 'Đưa bài lạ về dạng đã biết cách giải.', dau: ['gặp dạng lạ', 'chưa học dạng này'] },
  'tuong-tu-hoa': { nhom: 'Tư duy', ten: 'Tương tự hoá', moTa: 'Dùng bài đã giải làm khuôn cho bài mới.', dau: ['học một biết một', 'không suy ra được'] },
  'so-do-tu-duy': { nhom: 'Ghi nhớ', ten: 'Sơ đồ tư duy', moTa: 'Vẽ bản đồ khái niệm cho cả chương.', dau: ['học trước quên sau', 'kiến thức rời rạc'] },
  'the-cong-thuc': { nhom: 'Ghi nhớ', ten: 'Thẻ công thức', moTa: 'Ghi công thức ra thẻ, ôn theo chu kỳ.', dau: ['quên công thức', 'nhớ nhầm công thức'] },
  'lien-tuong': { nhom: 'Ghi nhớ', ten: 'Liên tưởng hoá', moTa: 'Gắn công thức với hình ảnh dễ nhớ.', dau: ['khó nhớ', 'công thức dài'] },
  'luyen-co-chu-dich': { nhom: 'Luyện tập', ten: 'Luyện tập có chủ đích', moTa: 'Chỉ luyện đúng chỗ đang yếu.', dau: ['làm nhiều vẫn sai', 'luyện tràn lan'] },
  'lap-lai-ngat-quang': { nhom: 'Luyện tập', ten: 'Lặp lại ngắt quãng', moTa: 'Ôn lại sau 1, 3, 7, 14, 30 ngày.', dau: ['học trước quên sau', 'mau quên'] },
  'bien-doi-nguoc': { nhom: 'Luyện tập', ten: 'Biến đổi ngược', moTa: 'Từ đáp án tự đặt lại đề mới.', dau: ['hiểu hời hợt', 'chỉ biết làm theo mẫu'] },
  'dong-vai-giao-vien': { nhom: 'Luyện tập', ten: 'Đóng vai giáo viên', moTa: 'Giảng lại bài cho người khác nghe.', dau: ['tưởng hiểu mà không hiểu', 'không giải thích được'] },
  'kiem-tra-nguoc': { nhom: 'Kiểm tra', ten: 'Kiểm tra ngược', moTa: 'Thay đáp án vào đề để thử lại.', dau: ['sai đáp số', 'tính nhầm', 'sai mà không biết'] },
  'uoc-luong': { nhom: 'Kiểm tra', ten: 'Ước lượng kết quả', moTa: 'Nhẩm xem đáp án có hợp lý không.', dau: ['đáp án vô lý', 'sai đơn vị'] },
  'doc-lai-de': { nhom: 'Kiểm tra', ten: 'Đọc lại đề', moTa: 'Đọc lại đề sau khi giải xong.', dau: ['thiếu ý', 'bỏ sót yêu cầu', 'lạc đề'] },
  feynman: { nhom: 'Tự học', ten: 'Kỹ thuật Feynman', moTa: 'Giảng lại khái niệm bằng lời đơn giản nhất.', dau: ['học vẹt', 'không hiểu bản chất'] },
  'tu-dat-cau-hoi': { nhom: 'Tự học', ten: 'Tự đặt câu hỏi', moTa: 'Tự hỏi "vì sao", "nếu khác đi thì sao".', dau: ['thụ động', 'chỉ chờ thầy giảng'] },
  'day-lai': { nhom: 'Tự học', ten: 'Dạy lại cho bạn', moTa: 'Dạy lại phần vừa học cho bạn cùng lớp.', dau: ['không chắc chắn', 'hiểu nửa vời'] },
  'ghi-chep-cornell': { nhom: 'Tự học', ten: 'Ghi chép Cornell', moTa: 'Chia vở ba phần: ghi chú, từ khoá, tóm tắt.', dau: ['ghi chép lộn xộn', 'vở không dùng lại được'] },
  pomodoro: { nhom: 'Tự học', ten: 'Pomodoro', moTa: 'Học 25 phút, nghỉ 5 phút.', dau: ['mất tập trung', 'ngồi lâu không vào', 'hay xao nhãng'] },
  'khong-gian-hoc': { nhom: 'Tự học', ten: 'Không gian học tập', moTa: 'Dọn bàn học, cất điện thoại khỏi tầm tay.', dau: ['bị phân tâm', 'điện thoại'] },
  'bat-dau-3-phut': { nhom: 'Tự học', ten: 'Bắt đầu 3 phút', moTa: 'Chỉ cần ngồi vào bàn làm 3 phút.', dau: ['lười bắt đầu', 'trì hoãn', 'ngại học'] },
  'so-loi-sai': { nhom: 'Tự học', ten: 'Sổ lỗi sai', moTa: 'Ghi lại mọi lỗi đã mắc và phân loại.', dau: ['sai đi sai lại', 'lặp lại lỗi cũ', 'tính nhầm'] },
};

/** Tám nhánh kiến thức, dùng để xếp một chủ đề vào đúng chỗ của nó. */
const NHANH_TOAN = {
  'so-hoc': { ten: 'Số học', tu: ['số nguyên tố', 'ước', 'bội', 'chia hết', 'đồng dư', 'phân số', 'số tự nhiên'] },
  'dai-so': { ten: 'Đại số', tu: ['phương trình', 'bất phương trình', 'hệ phương trình', 'đa thức', 'hàm số', 'căn thức', 'hằng đẳng thức'] },
  'hinh-hoc': { ten: 'Hình học', tu: ['tam giác', 'đường tròn', 'tứ giác', 'diện tích', 'thể tích', 'góc', 'pythagore', 'đồng dạng'] },
  'giai-tich': { ten: 'Giải tích', tu: ['giới hạn', 'đạo hàm', 'tích phân', 'nguyên hàm', 'liên tục', 'cực trị', 'khảo sát'] },
  'luong-giac': { ten: 'Lượng giác', tu: ['lượng giác', 'sin', 'cos', 'tan', 'cung', 'góc lượng giác'] },
  'to-hop': { ten: 'Tổ hợp — Xác suất', tu: ['hoán vị', 'tổ hợp', 'chỉnh hợp', 'xác suất', 'nhị thức'] },
  'mu-logarit': { ten: 'Mũ — Lôgarit', tu: ['lũy thừa', 'logarit', 'lôgarit', 'mũ'] },
  'vecto': { ten: 'Vectơ — Tọa độ', tu: ['vectơ', 'vector', 'tọa độ', 'tích vô hướng', 'mặt phẳng', 'đường thẳng'] },
};

function xepNhanh(chuDe) {
  const s = String(chuDe || '').toLowerCase();
  let tot = null; let diem = 0;
  for (const [id, n] of Object.entries(NHANH_TOAN)) {
    const d = n.tu.filter((t) => s.includes(t)).length;
    if (d > diem) { diem = d; tot = { id, ...n }; }
  }
  return tot;
}

// ── Lớp chính ─────────────────────────────────────────────────────────────

class MathScientist {
  constructor({ llm = null, bank = null, roadmap = null, cycle90 = null, bus = null } = {}) {
    this.llm = llm;
    this.bank = bank;
    this.roadmapService = roadmap;
    this.cycle90 = cycle90;
    this.bus = bus;
    this.v = new MathVerifier({ seed: 'gita-scientist' });
    this.stats = { docVi: 0, giai: 0, trinhBay: 0, phieu: 0, khongGiaiDuoc: 0 };
  }

  // ── 1. Đọc vị đề bài ────────────────────────────────────────────────────

  /**
   * Tách một đề bài thành các lớp. Phần nào tính được thì TÍNH, phần nào
   * thuộc về chương trình thì tra trong danh mục dạng bài đã thẩm định.
   */
  docVi(deBai) {
    this.stats.docVi++;
    const de = String(deBai || '').trim();
    if (!de) return { ok: false, error: 'THIẾU_ĐỀ_BÀI' };

    const pt = this._rutPhuongTrinh(de);
    const nhanh = xepNhanh(de);
    const dang = this._traDang(de);

    const lop = {
      ok: true,
      deBai: chuanHoa(de),
      nhanh: nhanh ? { id: nhanh.id, ten: nhanh.ten } : null,
      dangBai: dang ? { ma: dang.code, ten: dang.name, tang: dang.levelRange } : null,
      kienThucNen: dang ? (dang.prereq || []).map((c) => ({ ma: c, ten: FORM_INDEX.get(c)?.name || c })) : [],
      bay: dang ? (dang.traps || []).map((t) => ({ moTa: t, nguon: 'danh mục dạng bài đã thẩm định' })) : [],
      duKien: [],
      yeuCau: { canTim: [], canChungMinh: [] },
      phuongTrinh: null,
      doKho: 2,
      tinhDuocBangMay: false,
    };

    // Yêu cầu của đề — đọc từ động từ mệnh lệnh, không đoán.
    if (/\bgiải\b|\btìm nghiệm\b/i.test(de)) lop.yeuCau.canTim.push('tập nghiệm của phương trình');
    if (/\btìm\s+([a-zA-Z])\b/i.test(de)) lop.yeuCau.canTim.push(`giá trị của ${de.match(/\btìm\s+([a-zA-Z])\b/i)[1]}`);
    if (/chứng minh/i.test(de)) lop.yeuCau.canChungMinh.push(de.replace(/^.*chứng minh/i, 'chứng minh').trim());
    if (/tính\s+/i.test(de)) lop.yeuCau.canTim.push('giá trị của biểu thức');
    if (!lop.yeuCau.canTim.length && !lop.yeuCau.canChungMinh.length) lop.yeuCau.canTim.push('kết quả theo yêu cầu đề bài');

    if (pt) {
      const kq = this.v.solve(pt);
      lop.phuongTrinh = { tho: pt, dep: chuanHoa(pt) };
      lop.tinhDuocBangMay = !!kq.ok;
      if (kq.ok && kq.coeffs) {
        const { a, b, c } = kq.coeffs;
        lop.duKien = [
          { kyHieu: 'a', giaTri: soDep(a), vaiTro: 'hệ số bậc hai' },
          { kyHieu: 'b', giaTri: soDep(b), vaiTro: 'hệ số bậc nhất' },
          { kyHieu: 'c', giaTri: soDep(c), vaiTro: 'hệ số tự do' },
        ];
        lop.bacPhuongTrinh = a !== 0 ? 2 : b !== 0 ? 1 : 0;
        lop.bietThuc = a !== 0 ? round(b * b - 4 * a * c, 10) : null;
        lop.doKho = a !== 0 ? (Number.isInteger(Math.sqrt(Math.max(0, lop.bietThuc))) ? 2 : 3) : 1;
        // Bẫy tính được từ chính hệ số, không phải bẫy chung chung.
        if (b < 0) lop.bay.unshift({ moTa: `b = ${soDep(b)} âm: khi tính ∆ phải bình phương cả dấu, (${soDep(b)})² = ${soDep(b * b)}`, nguon: 'tính từ hệ số của đề' });
        if (a !== 1) lop.bay.unshift({ moTa: `a = ${soDep(a)} ≠ 1: không được chia nhẩm, mẫu của công thức nghiệm là 2a = ${soDep(2 * a)}`, nguon: 'tính từ hệ số của đề' });
        if (a === 0) lop.bay.unshift({ moTa: 'a = 0 nên đây KHÔNG phải phương trình bậc hai', nguon: 'tính từ hệ số của đề' });
      }
    }
    return lop;
  }

  /** Rút phương trình từ lời văn, trả dạng máy đọc được. */
  _rutPhuongTrinh(de) {
    const { rutPhuongTrinh } = require('./thamdinh');
    const tho = rutPhuongTrinh(de) || rutPhuongTrinh(`Đề bài: ${de}`);
    if (!tho) return null;
    try { this.v.solve(tho); return tho; } catch { return null; }
  }

  /** Tra dạng bài trong chương trình bằng bộ khớp của đường ống bài giảng. */
  _traDang(de) {
    const { BaiGiangPipeline } = require('../nexus/bai-giang');
    const p = new BaiGiangPipeline({});
    const t = p.timDang(de);
    return t.khop ? FORM_INDEX.get(t.khop.ma) : null;
  }

  // ── 2. Pháp đồ giải ─────────────────────────────────────────────────────

  /** Lộ trình giải, dựng theo ĐÚNG loại phương trình đang xét. */
  phapDo(docVi) {
    if (!docVi || !docVi.ok) return { ok: false, error: 'CHƯA_ĐỌC_VỊ_ĐỀ' };
    const bac = docVi.bacPhuongTrinh;
    const buoc = [];
    const them = (ten, moTa, chot, bay) => buoc.push({ buoc: buoc.length + 1, ten, moTa, chotKiem: chot, bay: bay || null });

    if (bac === 2) {
      const { bietThuc } = docVi;
      them('Xác định hệ số', 'Đưa phương trình về dạng ax² + bx + c = 0 rồi đọc a, b, c.', 'a có khác 0 không?', 'Quên chuyển hết các hạng tử về một vế.');
      them('Tính biệt thức', 'Áp dụng ∆ = b² − 4ac.', `∆ = ${soDep(bietThuc)} — dấu của ∆ quyết định số nghiệm.`, 'Bình phương thiếu dấu của b.');
      if (bietThuc > 0) {
        them('Tìm hai nghiệm', 'Vì ∆ > 0 nên phương trình có hai nghiệm phân biệt, dùng công thức nghiệm.', 'Rút gọn phân số chưa?', 'Quên dấu trừ trước b.');
      } else if (bietThuc === 0) {
        them('Tìm nghiệm kép', 'Vì ∆ = 0 nên phương trình có nghiệm kép x = −b⁄(2a).', 'Ghi rõ đây là nghiệm kép.', 'Ghi thành hai nghiệm giống nhau.');
      } else {
        them('Kết luận vô nghiệm', 'Vì ∆ < 0 nên phương trình vô nghiệm trên tập số thực.', 'Nói rõ "trên ℝ".', 'Viết "không có nghiệm" mà không nói rõ tập số.');
      }
      them('Kiểm tra lại', 'Thay từng nghiệm vào phương trình ban đầu.', 'Hai vế có bằng nhau không?', 'Bỏ qua bước này.');
      them('Kết luận', 'Đóng khung tập nghiệm S = {…}.', 'Đã viết đủ tập nghiệm chưa?', 'Quên viết tập nghiệm.');
    } else if (bac === 1) {
      them('Thu gọn hai vế', 'Chuyển hạng tử chứa ẩn về một vế, hằng số về vế kia.', 'Đổi dấu khi chuyển vế chưa?', 'Quên đổi dấu.');
      them('Chia hai vế', 'Chia cho hệ số của ẩn.', 'Hệ số có khác 0 không?', 'Chia cho 0.');
      them('Kiểm tra lại', 'Thay nghiệm vào phương trình ban đầu.', 'Hai vế bằng nhau?', null);
      them('Kết luận', 'Viết tập nghiệm.', null, null);
    } else {
      them('Đọc vị đề bài', 'Tách dữ kiện, yêu cầu, ràng buộc, bẫy.', 'Đã hiểu đề chưa?', 'Bỏ sót một yêu cầu.');
      them('Chọn hướng giải', 'Quy bài về một dạng đã biết cách giải.', 'Đã có hướng rõ ràng chưa?', null);
      them('Trình bày', 'Viết lời giải theo mạch "Ta có — Suy ra — Vậy".', null, null);
      them('Kiểm tra lại', 'Thử lại kết quả.', null, 'Bỏ qua bước này.');
    }

    return {
      ok: true,
      soBuoc: buoc.length,
      buoc,
      cayQuyetDinh: bac === 2 ? {
        goc: 'Xét dấu của biệt thức ∆',
        nhanh: [
          { dieuKien: '∆ > 0', ketQua: 'hai nghiệm phân biệt x = (−b ± √∆)⁄(2a)' },
          { dieuKien: '∆ = 0', ketQua: 'nghiệm kép x = −b⁄(2a)' },
          { dieuKien: '∆ < 0', ketQua: 'vô nghiệm trên ℝ' },
        ],
        dangDi: docVi.bietThuc > 0 ? '∆ > 0' : docVi.bietThuc === 0 ? '∆ = 0' : '∆ < 0',
      } : null,
      kyNangCan: bac === 2 ? ['thay số vào công thức', 'tính bình phương có dấu', 'rút gọn phân số'] : ['biến đổi tương đương'],
    };
  }

  // ── 3. Giải nhiều cách ──────────────────────────────────────────────────

  /**
   * Chỉ đưa ra những cách THẬT SỰ dùng được cho phương trình này.
   * Toàn bộ số liệu tính bằng máy, không nhờ mô hình ngôn ngữ.
   */
  giaiDaCach(deBai) {
    this.stats.giai++;
    const dv = typeof deBai === 'string' ? this.docVi(deBai) : deBai;
    if (!dv.ok) return dv;
    if (!dv.phuongTrinh) {
      this.stats.khongGiaiDuoc++;
      return { ok: false, error: 'KHÔNG_RÚT_ĐƯỢC_PHƯƠNG_TRÌNH', deBai: dv.deBai,
        goi: 'Bộ giải chạy được với phương trình một ẩn. Đề bài lời văn thì cần mô hình ngôn ngữ, hoặc tự viết phương trình ra.' };
    }
    const kq = this.v.solve(dv.phuongTrinh.tho);
    if (!kq.ok) return { ok: false, error: 'KHÔNG_GIẢI_ĐƯỢC', chiTiet: kq.error || kq.message };

    const cach = [];
    const co = kq.coeffs;
    if (co && co.a !== 0) {
      cach.push(this._cachCongThucNghiem(co, kq));
      const nhamDuoc = this._cachNhamNghiem(co, kq);
      if (nhamDuoc) cach.push(nhamDuoc);
      const vietDuoc = this._cachViet(co, kq);
      if (vietDuoc) cach.push(vietDuoc);
      const hangDang = this._cachHangDangThuc(co, kq);
      if (hangDang) cach.push(hangDang);
    } else if (co) {
      cach.push(this._cachBacNhat(co, kq));
    } else {
      cach.push({
        so: 1, ten: 'Cách 1: Dò nghiệm bằng số', phuongPhap: 'khảo sát đổi dấu',
        mucDo: 'nâng cao', apDungDuoc: true,
        buoc: [{ so: 1, moTa: 'Phương trình không phải đa thức bậc ≤ 2 nên dùng phương pháp số.', bieuThuc: kq.note || '' }],
        ketQua: this._tapNghiem(kq.roots),
        luuY: 'Nghiệm tìm bằng phương pháp số — cần làm tròn và nói rõ sai số.',
      });
    }

    // Mỗi cách đều phải cho cùng một tập nghiệm; lệch nhau là bộ giải hỏng.
    const dapAn = this._tapNghiem(kq.roots);
    const lech = cach.filter((c) => c.ketQua !== dapAn).map((c) => c.ten);

    return {
      ok: true,
      deBai: dv.deBai,
      phuongTrinh: dv.phuongTrinh.dep,
      loai: kq.kind,
      bietThuc: kq.delta !== undefined ? soDep(kq.delta) : null,
      nghiem: kq.roots.map(soDep),
      tapNghiem: dapAn,
      soCach: cach.length,
      cacCach: cach,
      nhatQuan: lech.length === 0,
      lech,
      soSanh: this._soSanh(cach, co, kq),
      tinhBangMay: true,
    };
  }

  _tapNghiem(roots) {
    if (!roots || !roots.length) return 'S = ∅';
    return `S = {${[...roots].sort((a, b) => a - b).map(soDep).join('; ')}}`;
  }

  _cachCongThucNghiem(co, kq) {
    const { a, b, c } = co;
    const d = round(b * b - 4 * a * c, 10);
    const buoc = [
      { so: 1, moTa: 'Xác định hệ số', bieuThuc: `a = ${soDep(a)}, b = ${soDep(b)}, c = ${soDep(c)}`, giaiThich: `Vì a = ${soDep(a)} ≠ 0 nên đây là phương trình bậc hai một ẩn.` },
      { so: 2, moTa: 'Tính biệt thức', bieuThuc: `∆ = b² − 4ac = (${soDep(b)})² − 4 · ${soDep(a)} · ${soDep(c)} = ${soDep(b * b)} − ${soDep(4 * a * c)} = ${soDep(d)}`, giaiThich: 'Thay thẳng hệ số vào công thức biệt thức.' },
    ];
    if (d > 0) {
      const canD = Math.sqrt(d);
      const dep = Number.isInteger(canD);
      buoc.push({ so: 3, moTa: `Vì ∆ = ${soDep(d)} > 0 nên phương trình có hai nghiệm phân biệt`, bieuThuc: `√∆ = ${dep ? soDep(canD) : `√${soDep(d)}`}`, giaiThich: dep ? `${soDep(d)} là số chính phương nên căn ra số nguyên.` : 'Giữ nguyên dạng căn cho chính xác.' });
      const [r1, r2] = [...kq.roots].sort((x, y) => x - y);
      buoc.push({ so: 4, moTa: 'Nghiệm thứ nhất', bieuThuc: `x₁ = (−b + √∆)⁄(2a) = (${soDep(-b)} + ${dep ? soDep(canD) : `√${soDep(d)}`})⁄${soDep(2 * a)} = ${soDep(Math.max(r1, r2))}`, giaiThich: 'Lấy dấu cộng trước căn.' });
      buoc.push({ so: 5, moTa: 'Nghiệm thứ hai', bieuThuc: `x₂ = (−b − √∆)⁄(2a) = (${soDep(-b)} − ${dep ? soDep(canD) : `√${soDep(d)}`})⁄${soDep(2 * a)} = ${soDep(Math.min(r1, r2))}`, giaiThich: 'Lấy dấu trừ trước căn.' });
    } else if (d === 0) {
      buoc.push({ so: 3, moTa: 'Vì ∆ = 0 nên phương trình có nghiệm kép', bieuThuc: `x₁ = x₂ = −b⁄(2a) = ${soDep(-b)}⁄${soDep(2 * a)} = ${soDep(kq.roots[0])}`, giaiThich: 'Nghiệm kép, không phải hai nghiệm bằng nhau viết hai lần.' });
    } else {
      buoc.push({ so: 3, moTa: `Vì ∆ = ${soDep(d)} < 0 nên phương trình vô nghiệm`, bieuThuc: 'S = ∅', giaiThich: 'Trên tập số thực ℝ không có số nào bình phương ra số âm.' });
    }
    return {
      so: 1, ten: 'Cách 1: Công thức nghiệm', phuongPhap: 'công thức nghiệm tổng quát',
      mucDo: 'cơ bản', apDungDuoc: true, phuHopVoi: 'mọi phương trình bậc hai, kể cả nghiệm lẻ',
      buoc, ketQua: this._tapNghiem(kq.roots),
      uuDiem: ['Dùng được cho mọi phương trình bậc hai', 'Không cần nhẩm'],
      nhuocDiem: ['Tính toán dài khi hệ số lớn'],
    };
  }

  /** Nhẩm nghiệm — CHỈ khi a + b + c = 0 hoặc a − b + c = 0. */
  _cachNhamNghiem(co, kq) {
    const { a, b, c } = co;
    const tong = round(a + b + c, 10);
    const hieu = round(a - b + c, 10);
    if (tong !== 0 && hieu !== 0) return null;
    const x1 = tong === 0 ? 1 : -1;
    const x2 = round(c / a * (tong === 0 ? 1 : -1), 10);
    return {
      so: 2, ten: 'Cách 2: Nhẩm nghiệm theo dấu hiệu đặc biệt', phuongPhap: 'nhẩm nghiệm',
      mucDo: 'trung bình', apDungDuoc: true,
      phuHopVoi: 'phòng thi trắc nghiệm — ra đáp số trong mười giây',
      buoc: [
        { so: 1, moTa: 'Kiểm tra dấu hiệu đặc biệt', bieuThuc: tong === 0 ? `a + b + c = ${soDep(a)} + (${soDep(b)}) + ${soDep(c)} = 0` : `a − b + c = ${soDep(a)} − (${soDep(b)}) + ${soDep(c)} = 0`, giaiThich: tong === 0 ? 'Tổng ba hệ số bằng 0.' : 'Hiệu a − b + c bằng 0.' },
        { so: 2, moTa: 'Suy ra nghiệm thứ nhất', bieuThuc: `x₁ = ${soDep(x1)}`, giaiThich: tong === 0 ? 'Dấu hiệu a + b + c = 0 cho nghiệm x = 1.' : 'Dấu hiệu a − b + c = 0 cho nghiệm x = −1.' },
        { so: 3, moTa: 'Suy ra nghiệm thứ hai', bieuThuc: `x₂ = ${tong === 0 ? '' : '−'}c⁄a = ${soDep(x2)}`, giaiThich: 'Tích hai nghiệm bằng c⁄a theo định lý Vi-ét.' },
      ],
      ketQua: this._tapNghiem(kq.roots),
      uuDiem: ['Nhanh nhất', 'Không phải tính ∆'],
      nhuocDiem: ['Chỉ dùng được khi có dấu hiệu đặc biệt'],
    };
  }

  /** Vi-ét đảo — chỉ khi hai nghiệm là số nguyên, tức là nhẩm được. */
  _cachViet(co, kq) {
    if (kq.roots.length !== 2 || !kq.roots.every((r) => Number.isInteger(r))) return null;
    const { a, b, c } = co;
    const S = round(-b / a, 10);
    const P = round(c / a, 10);
    const [r1, r2] = [...kq.roots].sort((x, y) => x - y);
    return {
      so: 3, ten: 'Cách 3: Định lý Vi-ét và phân tích thành nhân tử', phuongPhap: 'Vi-ét đảo',
      mucDo: 'nâng cao', apDungDuoc: true,
      phuHopVoi: 'học sinh khá giỏi, bài có nghiệm nguyên',
      buoc: [
        { so: 1, moTa: 'Viết tổng và tích hai nghiệm', bieuThuc: `S = x₁ + x₂ = −b⁄a = ${soDep(S)};  P = x₁ · x₂ = c⁄a = ${soDep(P)}`, giaiThich: 'Định lý Vi-ét.' },
        { so: 2, moTa: 'Tìm hai số có tổng S và tích P', bieuThuc: `${soDep(r1)} + ${soDep(r2)} = ${soDep(S)};  ${soDep(r1)} · ${soDep(r2)} = ${soDep(P)}`, giaiThich: 'Hai số này chính là hai nghiệm.' },
        { so: 3, moTa: 'Phân tích thành nhân tử để kiểm', bieuThuc: `${hang(a, '')}(x ${r1 < 0 ? '+' : '−'} ${soDep(Math.abs(r1))})(x ${r2 < 0 ? '+' : '−'} ${soDep(Math.abs(r2))}) = 0`.replace(/^\(/, '('), giaiThich: 'Khai triển ra đúng phương trình ban đầu.' },
      ],
      ketQua: this._tapNghiem(kq.roots),
      uuDiem: ['Thấy ngay cấu trúc của phương trình', 'Dùng lại được cho bài có tham số'],
      nhuocDiem: ['Chỉ nhẩm được khi nghiệm đẹp'],
    };
  }

  /** Hằng đẳng thức — chỉ khi ∆ = 0, tức vế trái là một bình phương đúng. */
  _cachHangDangThuc(co, kq) {
    const { a, b, c } = co;
    if (round(b * b - 4 * a * c, 10) !== 0) return null;
    const r = kq.roots[0];
    return {
      so: 4, ten: 'Cách 4: Đưa về hằng đẳng thức', phuongPhap: 'bình phương đúng',
      mucDo: 'trung bình', apDungDuoc: true, phuHopVoi: 'bài có ∆ = 0',
      buoc: [
        { so: 1, moTa: 'Nhận ra vế trái là một bình phương', bieuThuc: `${veTrai(a, b, c)} = ${a === 1 ? '' : soDep(a)}(x ${r < 0 ? '+' : '−'} ${soDep(Math.abs(r))})²`, giaiThich: 'Vì ∆ = 0 nên tam thức là bình phương đúng.' },
        { so: 2, moTa: 'Giải', bieuThuc: `(x ${r < 0 ? '+' : '−'} ${soDep(Math.abs(r))})² = 0 ⇔ x = ${soDep(r)}`, giaiThich: 'Bình phương bằng 0 khi và chỉ khi cơ số bằng 0.' },
      ],
      ketQua: this._tapNghiem(kq.roots),
      uuDiem: ['Ngắn nhất khi ∆ = 0', 'Thấy rõ vì sao là nghiệm kép'],
      nhuocDiem: ['Chỉ đúng cho trường hợp ∆ = 0'],
    };
  }

  _cachBacNhat(co, kq) {
    const { b, c } = co;
    return {
      so: 1, ten: 'Cách 1: Biến đổi tương đương', phuongPhap: 'chuyển vế — chia hai vế',
      mucDo: 'cơ bản', apDungDuoc: true,
      buoc: [
        { so: 1, moTa: 'Chuyển hạng tử tự do sang vế phải', bieuThuc: `${hang(b, 'x')} = ${soDep(-c)}`, giaiThich: 'Chuyển vế thì đổi dấu.' },
        { so: 2, moTa: 'Chia hai vế cho hệ số của ẩn', bieuThuc: `x = ${soDep(-c)}⁄${soDep(b)} = ${soDep(kq.roots[0])}`, giaiThich: `Hệ số ${soDep(b)} khác 0 nên chia được.` },
      ],
      ketQua: this._tapNghiem(kq.roots),
      uuDiem: ['Ít bước nhất'], nhuocDiem: [],
    };
  }

  _soSanh(cach, co, kq) {
    if (cach.length < 2) return { totNhat: 1, lyDo: 'Chỉ có một cách áp dụng được cho phương trình này.' };
    const nham = cach.find((c) => c.phuongPhap === 'nhẩm nghiệm');
    const tot = nham ? nham.so : 1;
    return {
      totNhat: tot,
      lyDo: nham
        ? 'Phương trình có dấu hiệu đặc biệt nên nhẩm nghiệm ra đáp số nhanh nhất.'
        : 'Công thức nghiệm dùng được cho mọi trường hợp nên an toàn nhất.',
      theoNguCanh: {
        tuLuan: 'Cách 1 — trình bày đủ bước, chấm điểm từng ý.',
        tracNghiem: nham ? `Cách ${nham.so} — ra đáp số trong mười giây.` : 'Cách 1, tính nhanh ∆ rồi loại đáp án.',
        onTap: cach.length > 2 ? 'Làm cả các cách để thấy cùng một bài nhìn được nhiều đường.' : 'Cách 1.',
      },
    };
  }

  // ── 4. Trình bày chuẩn sách giáo khoa ───────────────────────────────────

  /** Viết bài giải đủ năm phần, rồi TỰ THẨM ĐỊNH lại chính mình. */
  trinhBay(deBai, { cach = 1 } = {}) {
    this.stats.trinhBay++;
    const g = typeof deBai === 'string' ? this.giaiDaCach(deBai) : deBai;
    if (!g.ok) return g;
    const c = g.cacCach.find((x) => x.so === cach) || g.cacCach[0];

    const d = [];
    d.push(`**Đề bài:** ${g.deBai}`, '');
    d.push('**Lời giải:**', '');
    d.push(`Ta có phương trình ${g.phuongTrinh}.`, '');
    for (const b of c.buoc) {
      const cau = b.bieuThuc ? `${b.moTa}:` : `${b.moTa}.`;
      d.push(`${cau}`);
      if (b.bieuThuc) d.push('', b.bieuThuc, '');
      if (b.giaiThich) d.push(`*${b.giaiThich}*`, '');
    }

    // Kiểm tra lại — thay nghiệm thật, in ra con số thật.
    const nghiem = g.nghiem.map((s) => Number(String(s).replace('−', '-').replace('⁄', '/')));
    d.push('**Kiểm tra lại:**', '');
    if (!g.nghiem.length) {
      d.push('Phương trình vô nghiệm nên không có giá trị nào để thử lại.', '');
    } else {
      for (const x of g.cacCach[0].ketQua.match(/[−\-\d,.⁄/]+/g) || []) {
        const v = Number(x.replace('−', '-').replace('⁄', '/').replace(',', '.'));
        if (!Number.isFinite(v)) continue;
        const kt = this.v.substitute(veAscii(g.phuongTrinh), v);
        d.push(`- Với x = ${soDep(v)}: hai vế bằng nhau${kt.ok && kt.satisfied === false ? ' (KHÔNG thỏa mãn)' : ' (thỏa mãn)'}.`);
      }
      d.push('');
    }
    d.push(`**Kết luận:** Vậy phương trình đã cho có tập nghiệm ${g.tapNghiem}.`);

    const van = chuanHoa(d.join('\n'));
    const soat = thamDinh(van, { loai: 'bai-giai', kiemToan: true });

    return {
      ok: true,
      deBai: g.deBai,
      cachDung: c.ten,
      trinhBay: van,
      dapAn: g.tapNghiem,
      nghiem: g.nghiem,
      thamDinh: {
        dat: soat.dat, diem: soat.diem, xep: soat.xep, tomTat: soat.tomTat,
        daThayNghiemVaoKiem: soat.cap4NoiDung.daKiemToan,
        canSua: [...soat.cap1KyHieu.loi, ...soat.cap2VanPhong.loi, ...soat.cap3CauTruc.loi, ...soat.cap4NoiDung.loi],
      },
    };
  }

  // ── 5. Phiếu học tập ────────────────────────────────────────────────────

  /**
   * Phiếu dựng từ KHO HỌC LIỆU đã thẩm định, không phải từ đề mô hình bịa.
   * Mỗi bài trong phiếu đều đã qua bộ xác minh toán học khi được nhập kho.
   */
  phieuHocTap(maDangHoacChuDe, { soBai = 8 } = {}) {
    this.stats.phieu++;
    if (!this.bank) return { ok: false, error: 'CHƯA_GẮN_KHO_HỌC_LIỆU' };
    let form = FORM_INDEX.get(maDangHoacChuDe);
    if (!form) {
      const { BaiGiangPipeline } = require('../nexus/bai-giang');
      const t = new BaiGiangPipeline({}).timDang(maDangHoacChuDe);
      if (!t.khop) return { ok: false, error: 'KHÔNG_CÓ_DẠNG_BÀI_KHỚP', goiY: t.goiY };
      form = FORM_INDEX.get(t.khop.ma);
    }

    const bai = this.bank.query({ formCode: form.code, limit: soBai + 2 });
    if (!bai.length) {
      return { ok: false, error: 'KHO_CHƯA_CÓ_BÀI_CHO_DẠNG_NÀY', maDang: form.code,
        goi: 'Chạy bộ gieo học liệu (POST /content/seed) cho dạng này trước.' };
    }

    // Xếp theo độ khó thật (số sao) — chia nhóm A, B, C.
    const xep = [...bai].sort((x, y) => (x.stars || 0) - (y.stars || 0));
    const nhom = (i, n) => (i < n / 3 ? 'A. Cơ bản' : i < (2 * n) / 3 ? 'B. Vận dụng' : 'C. Nâng cao');
    const dung = xep.slice(0, soBai);

    return chuanHoaSau({
      ok: true,
      tieuDe: `Phiếu học tập: ${form.name}`,
      maDang: form.code,
      tang: form.levelRange,
      daThamDinh: true,
      lyThuyet: {
        canNho: (form.prereq || []).map((c) => FORM_INDEX.get(c)?.name || c),
        bayThuongGap: form.traps || [],
        thoiGianChuan: `${form.norm} giây một bài`,
      },
      viDuMau: dung.slice(0, 2).map((b, i) => ({
        so: i + 1, deBai: b.stem,
        loiGiai: cacBuoc(b).map((x, j) => `Bước ${j + 1}. ${x.viec}`
          + (x.canCu ? `\n   Căn cứ: ${x.canCu}` : '')).join('\n'),
        dapAn: b.answer,
      })),
      baiTap: dung.map((b, i) => ({
        so: i + 1, nhom: nhom(i, dung.length), deBai: b.stem,
        sao: b.stars, thoiGian: b.normSeconds || form.norm,
        dapAn: b.answer,
        loiGiaiNgan: (cacBuoc(b)[0] || {}).viec || null,
      })),
      loiThuongGap: (form.traps || []).map((t) => ({ moTa: t, cachTranh: 'Đọc lại đề và kiểm tra ngược sau khi giải.' })),
      nguon: 'kho học liệu đã qua bộ xác minh toán học',
    });
  }

  /**
   * Đề nhiều dòng đổ vào Markdown thì mất chỗ xuống dòng: Markdown coi một lần
   * xuống dòng là khoảng trắng, nên đoạn đọc hiểu và bốn phương án dính vào
   * nhau thành một khối chữ. Hai dấu cách cuối dòng là cách Markdown ngắt dòng
   * cứng, nên dùng đúng cái đó thay vì chèn dòng trống — dòng trống sẽ tách đề
   * thành nhiều đoạn văn và phá mất khối "Ví dụ n".
   */
  static deNhieuDong(s) {
    return String(s || '').split('\n').map((d) => d.trimEnd()).join('  \n');
  }

  /** Phiếu ở dạng văn bản in ra được. */
  phieuRaChu(p) {
    if (!p.ok) return '';
    const d = [`# ${p.tieuDe}`, '', `Mã dạng: ${p.maDang} · Tầng ${p.tang ? p.tang.join('–') : '—'} · Nguồn: ${p.nguon}`, ''];
    d.push('## A. Cần nắm trước', '');
    for (const x of p.lyThuyet.canNho) d.push(`- ${x}`);
    if (!p.lyThuyet.canNho.length) d.push('- (dạng nền, không có điều kiện tiên quyết)');
    d.push('', '## B. Bẫy thường gặp', '');
    for (const x of p.lyThuyet.bayThuongGap) d.push(`- ${x}`);
    d.push('', '## C. Ví dụ mẫu', '');
    for (const v of p.viDuMau) {
      d.push(`**Ví dụ ${v.so}.** ${MathScientist.deNhieuDong(v.deBai)}`, '', v.loiGiai, '', `*Đáp số:* ${v.dapAn}`, '');
    }
    d.push('## D. Bài tập tự luyện', '');
    let nhom = '';
    for (const b of p.baiTap) {
      if (b.nhom !== nhom) { nhom = b.nhom; d.push(`### ${nhom}`, ''); }
      d.push(`**Bài ${b.so}.** (${b.sao}★ · ${b.thoiGian} giây) ${MathScientist.deNhieuDong(b.deBai)}`, '');
    }
    d.push('## E. Đáp án', '');
    for (const b of p.baiTap) d.push(`- **Bài ${b.so}:** ${b.dapAn}`);
    return d.join('\n');
  }

  // ── 6. Ghép phương pháp học ─────────────────────────────────────────────

  /** Chấm 24 phương pháp theo đúng vấn đề học sinh nói ra. Tất định. */
  ghepPhuongPhap(vanDe, { soDeXuat = 4 } = {}) {
    const s = String(vanDe || '').toLowerCase();
    if (!s.trim()) return { ok: false, error: 'THIẾU_MÔ_TẢ_VẤN_ĐỀ' };
    // Khớp theo TỪ, không theo chuỗi con: "trời" có chứa "rời", và khớp kiểu
    // đó sẽ gán phương pháp học cho một câu nói về thời tiết.
    const tuCua = (x) => x.toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(Boolean);
    const tuVanDe = new Set(tuCua(s));
    const diem = [];
    for (const [id, pp] of Object.entries(PHUONG_PHAP)) {
      let d = 0;
      const trung = [];
      for (const dau of pp.dau) {
        if (s.includes(dau)) { d += 10; trung.push(dau); continue; }
        const tu = tuCua(dau).filter((t) => t.length > 2);
        if (!tu.length) continue;
        const khop = tu.filter((t) => tuVanDe.has(t)).length;
        if (khop === tu.length) { d += 8; trung.push(dau); }
        else if (khop >= 2) d += khop * 2;       // một từ trùng là trùng vu vơ
      }
      if (d > 0) diem.push({ id, ten: pp.ten, nhom: pp.nhom, moTa: pp.moTa, diem: d, trungDauHieu: trung });
    }
    diem.sort((a, b) => b.diem - a.diem || a.id.localeCompare(b.id));
    const chon = diem.slice(0, soDeXuat);

    return {
      ok: true,
      vanDe,
      chanDoan: chon.length
        ? `Dấu hiệu khớp với nhóm "${chon[0].nhom}": ${chon[0].trungDauHieu.join(', ') || chon[0].ten}.`
        : 'Chưa khớp dấu hiệu nào trong thư viện — cần mô tả cụ thể hơn điều đang gặp khó.',
      deXuat: chon.map((c, i) => ({ ...c, uuTien: i + 1 })),
      tongPhuongPhap: Object.keys(PHUONG_PHAP).length,
      keHoach: chon.length ? {
        tuan1: chon.slice(0, 2).map((c) => `Áp dụng ${c.ten} mỗi ngày`),
        tuan2_4: chon.slice(2).map((c) => `Thêm ${c.ten}`).concat('Ghi sổ lỗi sai sau mỗi buổi'),
        duyTri: ['Lặp lại ngắt quãng sau 1, 3, 7, 14, 30 ngày'],
      } : null,
    };
  }

  // ── 7. Lộ trình 90 ngày ─────────────────────────────────────────────────

  /**
   * Lộ trình lấy từ hệ thống lộ trình thật của Nexus (có dữ liệu học viên),
   * chứ không dựng một bản kế hoạch chung chung.
   */
  loTrinh90({ learnerId = null } = {}) {
    if (!learnerId || !this.roadmapService) {
      return { ok: false, error: 'CẦN_MÃ_HỌC_VIÊN',
        goi: 'Lộ trình 90 ngày dựng từ dữ liệu học thật của học viên: POST /learners/:id/roadmap. Không có dữ liệu thì không có lộ trình, chỉ có bản kế hoạch chung chung — thứ đó không giúp ai tiến bộ.' };
    }
    return this.roadmapService.build ? this.roadmapService.build(learnerId) : this.roadmapService.lay(learnerId);
  }

  // ── 8. Liên môn ─────────────────────────────────────────────────────────

  /** Kết nối liên môn có kiểm chứng; cần mô hình ngôn ngữ cho chủ đề mới. */
  async lienMon(chuDe) {
    const s = String(chuDe || '').toLowerCase();
    const san = LIEN_MON.find((x) => x.tu.some((t) => s.includes(t)));
    if (san) return { ok: true, nguon: 'bảng biên soạn sẵn', chuDe, ...san.noiDung };
    if (!this.llm) return { ok: false, error: 'CHƯA_CÓ_KẾT_NỐI_CHO_CHỦ_ĐỀ_NÀY', chuDe, coSan: LIEN_MON.map((x) => x.ten) };
    const co = this.llm.available().filter((p) => p !== 'mock');
    if (!co.length) {
      return { ok: false, error: 'CHƯA_CÓ_KHOÁ_MÔ_HÌNH', chuDe,
        coSan: LIEN_MON.map((x) => x.ten),
        goi: 'Các chủ đề trong bảng biên soạn sẵn chạy được ngoại tuyến; chủ đề mới cần GROQ_API_KEY.' };
    }
    const r = await this.llm.call({
      task: 'vietnamese',
      prompt: `Kết nối chủ đề toán "${chuDe}" với môn học khác và đời sống. Trả JSON thuần:
{"ketNoi":[{"mon":"...","lienKet":"...","viDu":"công thức cụ thể"}],"ungDung":[{"linhVuc":"...","moTa":"..."}]}
Viết ký hiệu toán bằng LaTeX trong $…$. Không dùng emoji, không xưng tôi.`,
      maxTokens: 1200, temperature: 0.5,
    });
    if (!r.ok) return { ok: false, error: 'MÔ_HÌNH_KHÔNG_TRẢ_LỜI', chiTiet: r.error };
    try {
      const d = JSON.parse(String(r.text).replace(/```json|```/g, '').trim());
      const sach = chuanHoaSau(d);
      const van = kiemVanPhong(JSON.stringify(sach), { loai: 'tu-do' });
      return { ok: true, nguon: `mô hình:${r.provider}`, chuDe, ...sach, canDuyet: true, vanPhong: van.ok ? 'đạt' : van.loi };
    } catch (e) {
      return { ok: false, error: 'MÔ_HÌNH_TRẢ_VỀ_KHÔNG_ĐỌC_ĐƯỢC', chiTiet: e.message };
    }
  }

  status() {
    return {
      tang: ['ký hiệu', 'văn phong', 'thẩm định 4 cấp', 'đọc vị', 'pháp đồ', 'đa cách giải', 'trình bày', 'phiếu học tập'],
      giaiTruc: 'phương trình một ẩn bậc ≤ 2 giải chính xác bằng bộ máy toán nội bộ; bậc cao hơn dò nghiệm bằng số',
      phuongPhapHoc: Object.keys(PHUONG_PHAP).length,
      nhanhToan: Object.keys(NHANH_TOAN).length,
      lienMonCoSan: LIEN_MON.length,
      canKhoa: { docVi: false, giaiDaCach: false, trinhBay: false, phieuHocTap: false, ghepPhuongPhap: false, lienMonChuDeMoi: true },
      stats: { ...this.stats },
      xacMinh: this.v.status(),
    };
  }
}

/**
 * Bảng liên môn biên soạn sẵn. Mỗi mục là một liên hệ ĐÚNG về mặt vật lý và
 * kiểm được, không phải một câu nói cho có. Chủ đề ngoài bảng thì nói thẳng
 * là chưa có, chứ không bịa.
 */
const LIEN_MON = [
  {
    ten: 'Đạo hàm', tu: ['đạo hàm', 'vi phân'],
    noiDung: {
      ketNoi: [
        { mon: 'Vật lý', lienKet: 'Đạo hàm của quãng đường theo thời gian là vận tốc tức thời.', viDu: 's(t) = 5t² ⇒ v(t) = s′(t) = 10t (m⁄s)' },
        { mon: 'Hóa học', lienKet: 'Đạo hàm của nồng độ theo thời gian là tốc độ phản ứng.', viDu: 'v = −dC⁄dt' },
        { mon: 'Kinh tế', lienKet: 'Đạo hàm của hàm chi phí là chi phí biên.', viDu: 'C(x) = x² + 100x ⇒ C′(x) = 2x + 100' },
      ],
      ungDung: [{ linhVuc: 'Tối ưu sản xuất', moTa: 'Giải C′(x) = 0 để tìm sản lượng có chi phí biên nhỏ nhất.' }],
    },
  },
  {
    ten: 'Phương trình bậc hai', tu: ['bậc hai', 'bậc 2', 'parabol'],
    noiDung: {
      ketNoi: [
        { mon: 'Vật lý', lienKet: 'Vật ném xiên có quỹ đạo parabol; tìm thời điểm chạm đất là giải phương trình bậc hai.', viDu: 'h(t) = −5t² + 20t ⇒ h = 0 ⇔ t = 0 hoặc t = 4 (giây)' },
        { mon: 'Địa lý', lienKet: 'Dây cáp cầu treo có dạng gần parabol, dùng để tính chiều cao trụ.', viDu: 'y = ax² + c' },
      ],
      ungDung: [{ linhVuc: 'Xây dựng', moTa: 'Tính chiều cao vòm cầu, mái vòm theo phương trình parabol.' }],
    },
  },
  {
    ten: 'Định lý Pythagore', tu: ['pythagore', 'pytago', 'tam giác vuông'],
    noiDung: {
      ketNoi: [
        { mon: 'Vật lý', lienKet: 'Độ lớn hợp lực của hai lực vuông góc tính bằng định lý Pythagore.', viDu: 'F = √(F₁² + F₂²)' },
        { mon: 'Công nghệ', lienKet: 'Thợ xây dùng bộ ba 3 − 4 − 5 để lấy góc vuông.', viDu: '3² + 4² = 5²' },
      ],
      ungDung: [{ linhVuc: 'Định vị', moTa: 'Khoảng cách giữa hai điểm trên bản đồ tọa độ: d = √((x₂ − x₁)² + (y₂ − y₁)²).' }],
    },
  },
  {
    ten: 'Lôgarit', tu: ['logarit', 'lôgarit', 'mũ'],
    noiDung: {
      ketNoi: [
        { mon: 'Vật lý', lienKet: 'Độ to của âm đo bằng đơn vị đêxiben theo thang lôgarit.', viDu: 'L = 10 · log(I⁄I₀)' },
        { mon: 'Hóa học', lienKet: 'Độ pH là lôgarit của nồng độ ion H⁺.', viDu: 'pH = −log[H⁺]' },
        { mon: 'Địa lý', lienKet: 'Thang Richter đo động đất là thang lôgarit.', viDu: 'M = log(A⁄A₀)' },
      ],
      ungDung: [{ linhVuc: 'Tài chính', moTa: 'Tính số năm để vốn tăng gấp đôi với lãi kép: n = log(2)⁄log(1 + r).' }],
    },
  },
  {
    ten: 'Xác suất', tu: ['xác suất', 'tổ hợp', 'thống kê'],
    noiDung: {
      ketNoi: [
        { mon: 'Sinh học', lienKet: 'Quy luật di truyền Mendel là bài toán xác suất.', viDu: 'Lai Aa × Aa cho tỉ lệ kiểu hình 3 : 1' },
        { mon: 'Y học', lienKet: 'Độ nhạy và độ đặc hiệu của xét nghiệm tính bằng xác suất có điều kiện.', viDu: 'P(bệnh | dương tính)' },
      ],
      ungDung: [{ linhVuc: 'Bảo hiểm', moTa: 'Phí bảo hiểm tính từ xác suất xảy ra rủi ro.' }],
    },
  },
];

module.exports = { MathScientist, PHUONG_PHAP, NHANH_TOAN, LIEN_MON, soDep, raPhanSo, veTrai };
