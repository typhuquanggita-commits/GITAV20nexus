'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  VĂN PHONG TOÁN TIẾNG VIỆT — bộ soát lời văn trong bài giải
 * ═══════════════════════════════════════════════════════════════════════════
 *  Một bài giải đúng đáp số vẫn có thể hỏng, nếu nó viết theo giọng máy:
 *  "Tôi sẽ giải bài này", "Tuyệt vời!", "pt có 2 nghiệm ✅". Học sinh chép
 *  theo lối đó vào bài thi là mất điểm trình bày, và tệ hơn, quen tay viết
 *  sai suốt đời.
 *
 *  Tệp này cưỡng chế lối viết của sách giáo khoa Toán Việt Nam:
 *   · Không ngôi thứ nhất, không cảm thán, không khen thưởng.
 *   · Không viết tắt trong lời giải.
 *   · Không biểu tượng cảm xúc.
 *   · Có đủ các mốc "Ta có", "Suy ra", "Vậy…" để bài đọc lên thành một
 *     mạch lập luận, chứ không phải một dãy phép tính rời.
 *
 *  Mỗi lỗi trả về kèm chỗ sai và cách sửa, để người soạn sửa được ngay chứ
 *  không phải đoán.
 * ═══════════════════════════════════════════════════════════════════════════
 */

/** Lời của máy trợ lý, không phải lời của nhà toán học. */
const LOI_MAY = [
  'Tôi sẽ', 'Tôi có thể', 'Tôi nghĩ', 'Hãy để tôi', 'Chúng ta hãy', 'Chúng ta cùng',
  'Bạn có thể', 'Bạn hãy', 'Hy vọng', 'Chúc mừng', 'Rất tốt', 'Tuyệt vời',
  'Cảm ơn bạn', 'Xin chào', 'Bây giờ chúng ta', 'Đầu tiên, hãy', 'Như bạn thấy',
  'Dưới đây là', 'Hãy cùng nhau',
];

/**
 * Viết tắt bị cấm trong lời giải.
 * Chỉ bắt dạng viết thường đứng riêng: "PT2" trong mã dạng M9.PT2.GIAI và
 * "TM" trong tên riêng không phải lỗi.
 */
const VIET_TAT = [
  { re: /(?<![.\w])pt(?![\w.])/g, dung: 'phương trình' },
  { re: /(?<![.\w])bpt(?![\w.])/g, dung: 'bất phương trình' },
  { re: /(?<![.\w])hpt(?![\w.])/g, dung: 'hệ phương trình' },
  { re: /(?<![.\w])bt(?![\w.])/g, dung: 'biểu thức' },
  { re: /(?<![.\w])đk(?![\w.])/g, dung: 'điều kiện' },
  { re: /(?<![.\w])đkxđ(?![\w.])/gi, dung: 'điều kiện xác định (viết đủ ít nhất một lần)' },
  { re: /(?<![.\w])đc(?![\w.])/g, dung: 'được' },
  { re: /(?<![.\w])vs(?![\w.])/g, dung: 'với' },
  { re: /(?<![.\w])vd(?![\w.])/g, dung: 'ví dụ' },
  { re: /(?<![.\w])kl(?![\w.])/g, dung: 'kết luận' },
  { re: /(?<![.\w])tm(?![\w.])/g, dung: 'thỏa mãn' },
  { re: /(?<![.\w])ntn(?![\w.])/g, dung: 'như thế nào' },
  { re: /(?<![.\w])nx(?![\w.])/g, dung: 'nhận xét' },
];

/** Biểu tượng cảm xúc — bắt theo dải Unicode, không bắt theo danh sách. */
const EMOJI = /[←-⇿⌀-⏿①-⓿■-➿⬀-⯿️\u{1F000}-\u{1FAFF}]/gu;
/** Ký hiệu toán nằm trong các dải trên — không phải emoji, không được báo lỗi. */
// Ký hiệu toán học KHÔNG phải biểu tượng cảm xúc, dù nằm cùng dải Unicode.
// Nhóm cuối là các DẤU ĐẶT TRÊN ĐẦU ký hiệu: cung ⌒ của góc, vectơ, gạch
// ngang của số đối — bộ dựng công thức sinh ra chúng khi vẽ \widehat, \vec,
// \overline, nên báo chúng là biểu tượng cảm xúc là bắt lỗi oan.
const KHONG_PHAI_EMOJI = new Set([...'←↑→↓↔⇒⇔∀∂∃∅∆∇∈∉∋∏∑−∓∕∗∘√∛∜∝∞∠∡∢∥∦∧∨∩∪∫∬∮∴∵∼≃≅≈≠≡≤≥≪≫⊂⊃⊆⊇⊕⊗⊥⋅⌈⌉⌊⌋△▲□■◆○●◊★☆✓✗⌒‾◯◇∦≅≃∡']);

/**
 * Mốc lập luận bắt buộc của một bài giải.
 * Không dùng \b được: trong JavaScript \w chỉ là [A-Za-z0-9_], nên "Ta có"
 * kết thúc bằng "ó" là ký tự KHÔNG phải \w — đặt \b sau đó thì không bao giờ
 * khớp. Phải tự viết ranh giới từ theo bảng chữ cái Unicode.
 */
const TRUOC = '(?<![\\p{L}\\p{N}])';
const SAU = '(?![\\p{L}\\p{N}])';
const tuKhoa = (...tu) => new RegExp(`${TRUOC}(?:${tu.join('|')})${SAU}`, 'u');

const MOC_LAP_LUAN = [
  { ten: 'mở đầu', re: tuKhoa('Ta có', 'Xét', 'Theo đề bài', 'Theo giả thiết', 'Cho') },
  { ten: 'biến đổi', re: tuKhoa('Do đó', 'Suy ra', 'Khi đó', 'Mặt khác', 'Từ đó', 'Vì vậy', 'Nên') },
  { ten: 'kết luận', re: tuKhoa('Vậy', 'Kết luận', 'đpcm', 'điều phải chứng minh') },
];

/** Phần bắt buộc của một bài giải trình bày đầy đủ. */
const PHAN_BAI_GIAI = [
  { ten: 'Đề bài', re: /(^|\n)\s*\**\s*(Đề bài|ĐỀ BÀI|Bài toán)\b/i },
  { ten: 'Lời giải', re: /(^|\n)\s*\**\s*(Lời giải|LỜI GIẢI|Giải)\b/i },
  { ten: 'Kết luận', re: tuKhoa('Kết luận', 'KẾT LUẬN', 'Vậy') },
];

/** Trích một đoạn quanh vị trí lỗi để người sửa thấy ngay chỗ sai. */
function trich(s, i, ban = 22) {
  const a = Math.max(0, i - ban);
  return `${a > 0 ? '…' : ''}${s.slice(a, i + ban).replace(/\s+/g, ' ').trim()}${i + ban < s.length ? '…' : ''}`;
}

/**
 * Soát văn phong.
 * @param {string} text
 * @param {object} o  loai: 'bai-giai' soát đủ cấu trúc; 'tu-do' chỉ soát điều cấm.
 */
function kiemVanPhong(text, { loai = 'tu-do' } = {}) {
  const s = String(text || '');
  const loi = [];
  const them = (muc, ma, moTa, cach) => loi.push({ muc, ma, moTa, cach });

  // 1. Giọng máy
  for (const t of LOI_MAY) {
    const i = s.indexOf(t);
    if (i >= 0) them('LOI', 'GIONG_MAY', `Lời của máy trợ lý: "${trich(s, i)}"`, 'Viết theo lối sách giáo khoa: "Ta có", "Xét", "Suy ra".');
  }
  // Ngôi thứ nhất số ít đứng đầu câu.
  const ngoi = s.match(/(^|[.!?]\s+|\n)\s*(Tôi|Mình|Em xin)(?![\p{L}\p{N}])/u);
  if (ngoi) them('LOI', 'NGOI_THU_NHAT', `Dùng ngôi thứ nhất: "${ngoi[2]}"`, 'Bài giải toán viết khách quan, không xưng tôi.');

  // 2. Viết tắt
  for (const v of VIET_TAT) {
    const co = s.match(v.re);
    if (co) them('LOI', 'VIET_TAT', `Viết tắt "${co[0]}" (${co.length} chỗ)`, `Viết đủ: "${v.dung}".`);
  }

  // 3. Biểu tượng cảm xúc
  const emo = [...new Set([...s.matchAll(EMOJI)].map((m) => m[0]))].filter((c) => !KHONG_PHAI_EMOJI.has(c));
  if (emo.length) them('LOI', 'EMOJI', `Có biểu tượng cảm xúc: ${emo.slice(0, 5).join(' ')}`, 'Bỏ khỏi nội dung toán.');

  // 4. Cảm thán và chữ in hoa để nhấn mạnh
  if (/[!]{1,}/.test(s.replace(/[≠≢]/g, ''))) {
    const i = s.search(/!/);
    if (!/\d!/.test(s)) them('CANH_BAO', 'CAM_THAN', `Dấu chấm than: "${trich(s, i)}"`, 'Bài toán không cảm thán (trừ khi là giai thừa n!).');
  }

  // 5. Mốc lập luận — chỉ đòi hỏi ở một BÀI GIẢI. Khung hình bài giảng là
  //    những mảnh chữ rời (tiêu đề, gạch đầu dòng), đòi "Ta có… Suy ra…" ở
  //    đó là bắt lỗi oan.
  if (loai === 'bai-giai') {
    for (const m of MOC_LAP_LUAN) {
      if (!m.re.test(s)) them('CANH_BAO', 'THIEU_MOC', `Thiếu mốc lập luận: ${m.ten}`, 'Thêm "Ta có" / "Suy ra" / "Vậy" để bài thành một mạch lập luận.');
    }
  }

  // 6. Cấu trúc — chỉ đòi hỏi khi đây là một bài giải trình bày đầy đủ
  if (loai === 'bai-giai') {
    const thieu = PHAN_BAI_GIAI.filter((p) => !p.re.test(s)).map((p) => p.ten);
    if (thieu.length) them('LOI', 'THIEU_PHAN', `Thiếu phần: ${thieu.join(', ')}`, 'Bài giải đủ gồm: Đề bài · Điều kiện xác định (nếu có) · Lời giải · Kiểm tra lại · Kết luận.');
    if (!/S\s*=\s*[{(\[]|tập nghiệm|đpcm|vô nghiệm/i.test(s)) {
      them('CANH_BAO', 'THIEU_DAP_SO', 'Không thấy tập nghiệm đóng khung ở cuối', 'Kết bằng "Vậy phương trình có tập nghiệm S = {…}".');
    }
  }

  const soLoi = loi.filter((x) => x.muc === 'LOI').length;
  const soCanhBao = loi.length - soLoi;
  return {
    ok: soLoi === 0,
    soLoi, soCanhBao, loi,
    diem: Math.max(0, 100 - soLoi * 10 - soCanhBao * 3),
  };
}

module.exports = { kiemVanPhong, LOI_MAY, VIET_TAT, MOC_LAP_LUAN, PHAN_BAI_GIAI };
