'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  THẨM ĐỊNH 4 CẤP — cửa cuối trước khi một bài giải được đem dạy
 * ═══════════════════════════════════════════════════════════════════════════
 *  Cấp 1 — KÝ HIỆU : viết đúng ký hiệu toán quốc tế chưa.
 *  Cấp 2 — VĂN PHONG: viết đúng giọng sách giáo khoa chưa.
 *  Cấp 3 — CẤU TRÚC : có đủ đề bài, lời giải, kiểm tra, kết luận chưa.
 *  Cấp 4 — NỘI DUNG : ĐÁP SỐ CÓ ĐÚNG KHÔNG.
 *
 *  Cấp 4 là cấp duy nhất không thể làm bằng cách dò chuỗi. Ở đây nó được làm
 *  thật: rút phương trình và tập nghiệm ra khỏi bài, đổi về dạng máy đọc
 *  được, rồi thay nghiệm vào phương trình bằng bộ xác minh toán học của hệ
 *  thống. Nghiệm sai thì bài trượt, bất kể trình bày đẹp đến đâu — đó là
 *  điểm khác nhau giữa "kiểm tra thật" và "trông có vẻ đã kiểm tra".
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { kiemKyHieu, veAscii } = require('./kyhieu');
const { kiemVanPhong, PHAN_BAI_GIAI } = require('./vanphong');
const MathVerifier = require('./verifier');

const _verifier = new MathVerifier({ seed: 'gita-tham-dinh' });

/** Hàm toán học được phép viết bằng chữ trong một biểu thức. */
const HAM = new Set(['sqrt', 'sin', 'cos', 'tan', 'cot', 'log', 'ln', 'exp', 'abs', 'Delta', 'pi']);

/**
 * Một "từ" có phải mảnh của biểu thức toán không.
 * Cách phân biệt: chữ tiếng Việt có dấu thì chắc chắn là lời văn; một cụm
 * chữ cái thuần từ ba ký tự trở lên mà không phải tên hàm cũng là lời văn
 * ("cho", "nên"). Còn lại — "x²", "4ac", "=", "0." — là toán.
 */
function laToan(tu) {
  if (!tu) return false;
  // Có cả lối viết thô của máy (^, _, *, /) vì hàm này còn dùng để rút
  // phương trình từ đề bài người dùng gõ vào, chưa qua chuẩn hoá.
  if (!/^[0-9A-Za-z⁰-⁹¹²³ⁿ₀-₉√∛∆·⁄()+\-−.,;:=<>≤≥≠|{}^_*/!]+$/u.test(tu)) return false;
  for (const cum of tu.match(/[A-Za-z]+/g) || []) {
    if (cum.length >= 3 && !HAM.has(cum)) return false;
  }
  return true;
}

/**
 * Rút phương trình ra khỏi lời văn.
 * Không dùng một biểu thức chính quy dài: nó sẽ ngoạm luôn mấy chữ cuối của
 * từ đứng trước ("…trình x² = 0" → "nh x² = 0"). Ở đây cắt theo TỪ, rồi tìm
 * dải từ toán dài nhất có chứa dấu bằng.
 */
function rutPhuongTrinh(text) {
  const s = String(text || '');
  const dongDe = s.match(/(?:Đề bài|ĐỀ BÀI|Bài toán)\s*:?\s*\**\s*(.+)/);
  for (const nguon of [dongDe ? dongDe[1] : null, s].filter(Boolean)) {
    const tu = nguon.split(/\s+/);
    let tot = null;
    let dai = 0;
    let i = 0;
    while (i < tu.length) {
      if (!laToan(tu[i])) { i++; continue; }
      let j = i;
      while (j < tu.length && laToan(tu[j])) j++;
      const dai2 = j - i;
      const cum = tu.slice(i, j).join(' ');
      if (cum.includes('=') && dai2 > dai) { tot = cum; dai = dai2; }
      i = j;
    }
    if (!tot) continue;
    const tho = veAscii(tot).trim().replace(/^[.,;:]+|[.,;:]+$/g, '');
    const [trai] = tho.split('=');
    // "S = {2; 3}" là tập nghiệm, không phải phương trình cần kiểm.
    if (!/[a-z]/.test(tho) || trai.trim() === 'S' || !tho.includes('=')) continue;
    return tho;
  }
  return null;
}

/**
 * Đọc một số viết theo lối toán: "−5", "1⁄2", "3/4", "2,5".
 * Nghiệm hữu tỉ hay được viết thành phân số; bỏ qua nó thì bộ thẩm định sẽ
 * báo "thiếu nghiệm" trên một bài hoàn toàn đúng.
 */
function doSo(t) {
  const s = veAscii(String(t)).trim().replace(/−/g, '-');
  const ps = s.match(/^(-?\d+(?:[.,]\d+)?)\s*\/\s*(-?\d+(?:[.,]\d+)?)$/);
  if (ps) {
    const a = Number(ps[1].replace(',', '.'));
    const b = Number(ps[2].replace(',', '.'));
    return b !== 0 ? a / b : NaN;
  }
  return Number(s.replace(',', '.'));
}

/** Rút tập nghiệm "S = {2; 3}" hoặc "x = 2" ra khỏi bài. */
function rutTapNghiem(text) {
  const s = String(text || '');
  const boNgoac = s.match(/S\s*=\s*\{([^}]*)\}/);
  if (boNgoac) {
    const so = boNgoac[1].split(/[;]/).map(doSo).filter((n) => Number.isFinite(n));
    return so.length ? so : null;
  }
  if (/S\s*=\s*(∅|\{\s*\}|rỗng)/i.test(s) || /vô nghiệm/i.test(s)) return [];
  const rieng = [...s.matchAll(/x[₀-₉0-9]?\s*=\s*(−?-?\d+(?:[.,]\d+)?(?:\s*[⁄/]\s*\d+)?)/g)]
    .map((m) => doSo(m[1]))
    .filter((n) => Number.isFinite(n));
  return rieng.length ? [...new Set(rieng)] : null;
}

/**
 * Thẩm định một bài giải.
 * @param {string} text
 * @param {object} o  loai: 'bai-giai' soát đủ bốn cấp · 'tu-do' chỉ soát ký
 *   hiệu và văn phong. Cấp 4 chỉ chạy trên MỘT bài giải trọn vẹn: thay nghiệm
 *   vào một mớ mảnh chữ rời rạc thì chỉ ra kết quả vô nghĩa, và một kết quả
 *   vô nghĩa còn tệ hơn không kiểm.
 */
function thamDinh(text, { loai = 'bai-giai', kiemToan = loai === 'bai-giai' } = {}) {
  const s = String(text || '');

  // ── Cấp 1: ký hiệu ──
  const c1 = kiemKyHieu(s);

  // ── Cấp 2: văn phong ──
  const c2 = kiemVanPhong(s, { loai: 'tu-do' });

  // ── Cấp 3: cấu trúc ──
  const thieu = loai === 'bai-giai' ? PHAN_BAI_GIAI.filter((p) => !p.re.test(s)).map((p) => p.ten) : [];
  const coKiemTra = /Kiểm tra lại|Thử lại|thay .{0,12}vào/i.test(s);
  const c3 = {
    ok: thieu.length === 0,
    thieu,
    coKiemTraLai: coKiemTra,
    loi: [
      ...thieu.map((t) => ({ ma: 'THIEU_PHAN', moTa: `Thiếu phần "${t}"`, cach: 'Bài giải đủ: Đề bài · ĐKXĐ · Lời giải · Kiểm tra lại · Kết luận.' })),
      ...(loai === 'bai-giai' && !coKiemTra
        ? [{ ma: 'THIEU_KIEM_TRA', moTa: 'Không có bước kiểm tra lại nghiệm', cach: 'Thay nghiệm vào phương trình và ghi kết quả.' }]
        : []),
    ],
  };

  // ── Cấp 4: nội dung toán ──
  const c4 = { ok: true, loi: [], daKiemToan: false, chiTiet: null };
  if (!/[=+−·√∆²³₁₂∑∫≤≥≠]/.test(s)) {
    c4.ok = false;
    c4.loi.push({ ma: 'KHONG_CO_TOAN', moTa: 'Không có ký hiệu toán học nào trong bài', cach: 'Bài giảng toán phải có công thức.' });
  }
  if (s.trim().length < 80) {
    c4.ok = false;
    c4.loi.push({ ma: 'QUA_NGAN', moTa: `Nội dung chỉ ${s.trim().length} ký tự`, cach: 'Viết đủ lập luận, không chỉ ghi đáp số.' });
  }

  if (kiemToan) {
    const pt = rutPhuongTrinh(s);
    const nghiem = rutTapNghiem(s);
    if (pt && nghiem) {
      const r = _verifier.checkRoots(pt, nghiem);
      c4.daKiemToan = true;
      c4.chiTiet = { phuongTrinh: pt, nghiemCongBo: nghiem, ketQua: r };
      if (r.ok === false || r.correct === false) {
        c4.ok = false;
        c4.loi.push({
          ma: 'DAP_SO_SAI',
          moTa: `Nghiệm công bố không thỏa phương trình: ${pt} với ${JSON.stringify(nghiem)}${r.reason ? ` — ${r.reason}` : ''}`,
          cach: 'Giải lại và kiểm tra bằng cách thay nghiệm vào phương trình.',
        });
      }
    }
  }

  // ── Điểm tổng ──
  // Ký hiệu và đáp số là hai thứ không được phép sai: trượt một trong hai là
  // trượt toàn bài, dù các cấp còn lại có đẹp đến đâu.
  let diem = 100;
  diem -= c1.soLoi * 12;
  diem -= c2.soLoi * 10 + c2.soCanhBao * 3;
  diem -= c3.loi.length * 6;
  diem -= c4.loi.length * 20;
  diem = Math.max(0, Math.round(diem));

  const dat = c1.ok && c2.ok && c4.ok;
  return {
    ok: dat,
    dat,
    diem,
    xep: diem >= 90 ? 'xuất sắc' : diem >= 75 ? 'đạt' : diem >= 50 ? 'cần sửa' : 'không dùng được',
    cap1KyHieu: c1,
    cap2VanPhong: c2,
    cap3CauTruc: c3,
    cap4NoiDung: c4,
    tomTat: [
      `Cấp 1 ký hiệu: ${c1.ok ? 'đạt' : `${c1.soLoi} lỗi`}`,
      `Cấp 2 văn phong: ${c2.ok ? 'đạt' : `${c2.soLoi} lỗi`}${c2.soCanhBao ? ` (${c2.soCanhBao} nhắc)` : ''}`,
      `Cấp 3 cấu trúc: ${c3.ok ? 'đủ phần' : `thiếu ${c3.thieu.join(', ')}`}`,
      `Cấp 4 nội dung: ${c4.ok ? (c4.daKiemToan ? 'đáp số đã thay vào kiểm' : 'đạt (không rút được phương trình để kiểm)') : c4.loi.map((l) => l.ma).join(', ')}`,
    ].join(' · '),
  };
}

module.exports = { thamDinh, rutPhuongTrinh, rutTapNghiem };
