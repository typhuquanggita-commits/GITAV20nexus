'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  PNG — đọc và ghi, viết thẳng bằng JavaScript
 * ═══════════════════════════════════════════════════════════════════════════
 *  Bản thiết kế GITA Photo Studio giao mọi khâu xử lý ảnh cho ffmpeg: phóng
 *  to, chỉnh màu, tăng chi tiết, đo chất lượng, xuất tệp. Máy chủ này không
 *  có ffmpeg, và cả dự án có luật không phụ thuộc chạy thật. Không đọc nổi
 *  một tệp ảnh thì không có tầng xử lý nào chạy được.
 *
 *  PNG thì đọc được bằng chính thư viện chuẩn của Node: cấu trúc là chuỗi
 *  khối (IHDR, IDAT, IEND), dữ liệu ảnh là zlib — mà `node:zlib` có sẵn.
 *  Phần còn lại là bỏ bộ lọc từng dòng quét (5 kiểu, trong đó Paeth là kiểu
 *  hay bị làm sai nhất) và ghép lại thành mảng điểm ảnh.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const zlib = require('node:zlib');

const CHU_KY = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

/** Bảng CRC32 — PNG bắt buộc mọi khối phải có, sai một bit là tệp hỏng. */
const CRC_BANG = (() => {
  const b = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    b[n] = c;
  }
  return b;
})();

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_BANG[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function khoi(kieu, duLieu) {
  const ten = Buffer.from(kieu, 'ascii');
  const than = Buffer.concat([ten, duLieu]);
  const ra = Buffer.alloc(8 + duLieu.length + 4);
  ra.writeUInt32BE(duLieu.length, 0);
  than.copy(ra, 4);
  ra.writeUInt32BE(crc32(than), 8 + duLieu.length);
  return ra;
}

/** Dự đoán Paeth — chỗ dễ sai nhất khi tự viết bộ giải PNG. */
function paeth(a, b, c) {
  const p = a + b - c;
  const pa = Math.abs(p - a);
  const pb = Math.abs(p - b);
  const pc = Math.abs(p - c);
  if (pa <= pb && pa <= pc) return a;
  if (pb <= pc) return b;
  return c;
}

/**
 * Ảnh trong hệ thống: {width, height, data} với data là RGBA 8-bit,
 * 4 byte một điểm ảnh — một dạng duy nhất cho mọi tầng xử lý.
 */
function taoAnh(width, height, fill = [0, 0, 0, 255]) {
  const data = Buffer.alloc(width * height * 4);
  for (let i = 0; i < data.length; i += 4) {
    data[i] = fill[0]; data[i + 1] = fill[1]; data[i + 2] = fill[2]; data[i + 3] = fill[3];
  }
  return { width, height, data };
}

/** Ghi ảnh RGBA thành tệp PNG. */
function ghiPNG(anh, { nen = 6, boLoc = 'paeth' } = {}) {
  const { width, height, data } = anh;
  const soByte = 4;                       // RGBA
  const thoDong = width * soByte;
  // Mỗi dòng quét có một byte đầu ghi kiểu bộ lọc.
  const tho = Buffer.alloc((thoDong + 1) * height);

  for (let y = 0; y < height; y++) {
    const vaoDong = y * thoDong;
    const raDong = y * (thoDong + 1);
    if (boLoc === 'none') {
      tho[raDong] = 0;
      data.copy(tho, raDong + 1, vaoDong, vaoDong + thoDong);
      continue;
    }
    tho[raDong] = 4;                      // Paeth — nén tốt nhất cho ảnh chụp
    for (let x = 0; x < thoDong; x++) {
      const gt = data[vaoDong + x];
      const a = x >= soByte ? data[vaoDong + x - soByte] : 0;
      const b = y > 0 ? data[vaoDong - thoDong + x] : 0;
      const c = (x >= soByte && y > 0) ? data[vaoDong - thoDong + x - soByte] : 0;
      tho[raDong + 1 + x] = (gt - paeth(a, b, c)) & 0xff;
    }
  }

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;        // 8 bit mỗi kênh
  ihdr[9] = 6;        // màu kiểu 6 = RGBA
  ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;

  return Buffer.concat([
    CHU_KY,
    khoi('IHDR', ihdr),
    khoi('IDAT', zlib.deflateSync(tho, { level: nen })),
    khoi('IEND', Buffer.alloc(0)),
  ]);
}

/** Đọc tệp PNG thành ảnh RGBA. */
function docPNG(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 8 || !buf.subarray(0, 8).equals(CHU_KY)) {
    return { ok: false, error: 'KHÔNG_PHẢI_TỆP_PNG' };
  }
  let p = 8;
  let width = 0; let height = 0; let sauBit = 0; let kieuMau = 0; let xenKe = 0;
  const idat = [];
  let bangMau = null;
  let trongSuot = null;

  while (p + 8 <= buf.length) {
    const len = buf.readUInt32BE(p);
    const kieu = buf.toString('ascii', p + 4, p + 8);
    const than = buf.subarray(p + 8, p + 8 + len);
    if (kieu === 'IHDR') {
      width = than.readUInt32BE(0);
      height = than.readUInt32BE(4);
      sauBit = than[8]; kieuMau = than[9]; xenKe = than[12];
    } else if (kieu === 'PLTE') bangMau = Buffer.from(than);
    else if (kieu === 'tRNS') trongSuot = Buffer.from(than);
    else if (kieu === 'IDAT') idat.push(Buffer.from(than));
    else if (kieu === 'IEND') break;
    p += 8 + len + 4;
  }

  if (!width || !height) return { ok: false, error: 'PNG_THIẾU_IHDR' };
  if (sauBit !== 8) return { ok: false, error: `CHƯA_HỖ_TRỢ_ĐỘ_SÂU_${sauBit}_BIT` };
  if (xenKe) return { ok: false, error: 'CHƯA_HỖ_TRỢ_PNG_XEN_KẼ' };
  if (!idat.length) return { ok: false, error: 'PNG_KHÔNG_CÓ_DỮ_LIỆU_ẢNH' };

  const kenh = { 0: 1, 2: 3, 3: 1, 4: 2, 6: 4 }[kieuMau];
  if (!kenh) return { ok: false, error: `KIỂU_MÀU_LẠ_${kieuMau}` };

  let tho;
  try { tho = zlib.inflateSync(Buffer.concat(idat)); } catch (e) { return { ok: false, error: `GIẢI_NÉN_HỎNG: ${e.message}` }; }

  const thoDong = width * kenh;
  const canThiet = (thoDong + 1) * height;
  if (tho.length < canThiet) return { ok: false, error: 'DỮ_LIỆU_ẢNH_BỊ_CẮT' };

  // Bỏ bộ lọc từng dòng
  const px = Buffer.alloc(thoDong * height);
  for (let y = 0; y < height; y++) {
    const kieuLoc = tho[y * (thoDong + 1)];
    const vao = y * (thoDong + 1) + 1;
    const ra = y * thoDong;
    for (let x = 0; x < thoDong; x++) {
      const gt = tho[vao + x];
      const a = x >= kenh ? px[ra + x - kenh] : 0;
      const b = y > 0 ? px[ra - thoDong + x] : 0;
      const c = (x >= kenh && y > 0) ? px[ra - thoDong + x - kenh] : 0;
      let v;
      switch (kieuLoc) {
        case 0: v = gt; break;
        case 1: v = gt + a; break;
        case 2: v = gt + b; break;
        case 3: v = gt + ((a + b) >> 1); break;
        case 4: v = gt + paeth(a, b, c); break;
        default: return { ok: false, error: `KIỂU_LỌC_LẠ_${kieuLoc}_Ở_DÒNG_${y}` };
      }
      px[ra + x] = v & 0xff;
    }
  }

  // Quy về RGBA
  const data = Buffer.alloc(width * height * 4);
  for (let i = 0, j = 0; i < width * height; i++) {
    const s = i * kenh;
    let r; let g; let b; let a = 255;
    if (kieuMau === 0) { r = g = b = px[s]; }
    else if (kieuMau === 2) { r = px[s]; g = px[s + 1]; b = px[s + 2]; }
    else if (kieuMau === 3) {
      if (!bangMau) return { ok: false, error: 'PNG_BẢNG_MÀU_THIẾU_PLTE' };
      const k = px[s] * 3;
      r = bangMau[k]; g = bangMau[k + 1]; b = bangMau[k + 2];
      if (trongSuot && px[s] < trongSuot.length) a = trongSuot[px[s]];
    } else if (kieuMau === 4) { r = g = b = px[s]; a = px[s + 1]; }
    else { r = px[s]; g = px[s + 1]; b = px[s + 2]; a = px[s + 3]; }
    data[j++] = r; data[j++] = g; data[j++] = b; data[j++] = a;
  }

  return { ok: true, width, height, data, kieuMau, kenh };
}

/** Nhận dạng định dạng tệp ảnh từ vài byte đầu. */
function nhanDang(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 4) return 'không rõ';
  if (buf.subarray(0, 8).equals(CHU_KY)) return 'png';
  if (buf[0] === 0xff && buf[1] === 0xd8) return 'jpeg';
  if (buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') return 'webp';
  if (buf.toString('ascii', 0, 3) === 'GIF') return 'gif';
  if (buf.toString('utf8', 0, 200).trimStart().startsWith('<svg')) return 'svg';
  return 'không rõ';
}

module.exports = { ghiPNG, docPNG, taoAnh, nhanDang, crc32, paeth, CHU_KY };
