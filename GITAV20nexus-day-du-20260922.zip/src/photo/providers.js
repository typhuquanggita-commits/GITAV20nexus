'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  CỔNG TẠO ẢNH — và cái luôn chạy được khi chưa có cổng nào
 * ═══════════════════════════════════════════════════════════════════════════
 *  Không ai vẽ được ảnh chụp bằng vài trăm dòng JavaScript, nên ở tầng SINH
 *  ảnh hệ thống phụ thuộc dịch vụ ngoài — và nói thẳng như vậy.
 *
 *  Nhưng "chưa có mạng" không có nghĩa là không làm được gì. Hai thứ vẫn
 *  chạy đầy đủ, không cần khoá và không cần mạng:
 *    · KHUNG DỰNG — bản vẽ bố cục theo đúng toạ độ chủ thể, góc nhìn ống
 *      kính, hướng đèn. Đủ để chốt bố cục trước buổi chụp.
 *    · HẬU KỲ — toàn bộ tám tầng xử lý chạy trên ảnh có sẵn của người dùng.
 *
 *  Pollinations được giữ làm cổng mặc định vì miễn phí và không cần khoá,
 *  nhưng ghi rõ: đây là dịch vụ cộng đồng, không có cam kết phục vụ.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const cfg = require('../config');
const L = require('../logger');
const { round, sleep } = require('../utils');

const esc = (s) => String(s ?? '')
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

/** ── Khung dựng: luôn chạy được, không phải ảnh chụp ───────────────────── */
class CongKhungDung {
  constructor() {
    this.id = 'khung-dung';
    this.ten = 'Khung dựng bố cục (nội bộ)';
    this.tinhTien = false;
    this.canMang = false;
  }

  sanSang() { return { ok: true }; }

  /** Vẽ bố cục: lưới một phần ba, vị trí chủ thể, góc ống kính, hướng đèn. */
  ve(ke, { rong = 960, cao = 640 } = {}) {
    const cx = ke.chuThe.x * rong;
    const cy = ke.chuThe.y * cao;
    // Góc nhìn ngang theo tiêu cự trên khung 36mm
    const tieuCu = Number(String(ke.ongKinh).replace(/[^\d.]/g, '')) || 50;
    const goc = 2 * Math.atan(36 / (2 * tieuCu)) * 180 / Math.PI;
    const huongDen = {
      rembrandt: -45, 'ba-diem': -30, buom: -90, chia: -90,
      'gio-vang': 160, 'gio-xanh': 200, 'cua-so': -160, 'troi-may': -90,
    }[ke.anhSang] ?? -45;
    const rad = huongDen * Math.PI / 180;
    const dx = Math.cos(rad) * 140;
    const dy = Math.sin(rad) * 140;
    const duoi = cao - 92;

    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${rong} ${cao}" width="${rong}" height="${cao}" role="img" aria-label="Khung dựng bố cục ${esc(ke.boCucTen)}">
  <rect width="${rong}" height="${cao}" fill="#0e1016"/>
  <rect x="0" y="0" width="${rong}" height="${duoi}" fill="#1a1f2b"/>
  <g stroke="#ffffff" stroke-width="1" opacity=".18" fill="none">
    <line x1="${rong / 3}" y1="0" x2="${rong / 3}" y2="${duoi}"/>
    <line x1="${rong * 2 / 3}" y1="0" x2="${rong * 2 / 3}" y2="${duoi}"/>
    <line x1="0" y1="${duoi / 3}" x2="${rong}" y2="${duoi / 3}"/>
    <line x1="0" y1="${duoi * 2 / 3}" x2="${rong}" y2="${duoi * 2 / 3}"/>
  </g>
  <g opacity=".45" stroke="#7fd1ff" stroke-width="1.4" fill="none">
    <path d="M ${cx} ${duoi} L ${cx - Math.tan(goc * Math.PI / 360) * duoi * 0.55} 0"/>
    <path d="M ${cx} ${duoi} L ${cx + Math.tan(goc * Math.PI / 360) * duoi * 0.55} 0"/>
  </g>
  <g>
    <line x1="${cx + dx}" y1="${Math.max(24, cy + dy)}" x2="${cx}" y2="${cy}" stroke="#ffcf6b" stroke-width="2.4" opacity=".85"/>
    <circle cx="${cx + dx}" cy="${Math.max(24, cy + dy)}" r="13" fill="#ffcf6b" opacity=".9"/>
    <text x="${cx + dx}" y="${Math.max(24, cy + dy) + 4}" text-anchor="middle" font-size="11" fill="#2b1d00" font-family="system-ui,sans-serif" font-weight="700">đèn</text>
  </g>
  <circle cx="${cx}" cy="${cy}" r="30" fill="none" stroke="#6ee7a8" stroke-width="2.5"/>
  <circle cx="${cx}" cy="${cy}" r="5" fill="#6ee7a8"/>
  <text x="${cx}" y="${cy + 50}" text-anchor="middle" font-size="12.5" fill="#6ee7a8" font-family="system-ui,sans-serif">chủ thể (${ke.chuThe.x} · ${ke.chuThe.y})</text>
  <rect x="0" y="${duoi}" width="${rong}" height="${cao - duoi}" fill="#0e1016"/>
  <text x="16" y="${duoi + 26}" font-size="14" fill="#e8ebf2" font-family="system-ui,sans-serif" font-weight="600">${esc(ke.boCucTen)} · ${esc(ke.ongKinhTen)} · ${esc(ke.anhSangTen)}</text>
  <text x="16" y="${duoi + 48}" font-size="12" fill="#96a0b4" font-family="system-ui,sans-serif">${esc(ke.mayAnhTen)}${ke.phimTen && ke.phim !== 'Khong' ? ` · ${esc(ke.phimTen)}` : ''} · góc nhìn ngang ${round(goc, 1)}° · khẩu f/${ke.khauDo}</text>
  <text x="16" y="${duoi + 70}" font-size="11.5" fill="#6f7a90" font-family="system-ui,sans-serif">Đây là khung dựng bố cục, không phải ảnh chụp.</text>
</svg>`;
  }
}

/** ── Pollinations: miễn phí, không cần khoá ─────────────────────────────── */
class CongPollinations {
  constructor() {
    this.id = 'pollinations';
    this.ten = 'Pollinations (miễn phí, không cần khoá)';
    this.tinhTien = false;
    this.canMang = true;
    this.note = 'Dịch vụ cộng đồng, không có cam kết phục vụ. Có thể chậm hoặc từ chối lúc đông.';
    this.stats = { goi: 0, xong: 0, hong: 0 };
  }

  sanSang() { return { ok: true, luuY: 'Cần mạng ra ngoài. Không có cam kết phục vụ.' }; }

  async tao(ke, { rong = 1024, cao = 1024, moHinh = 'flux', timeoutMs = 120_000 } = {}) {
    this.stats.goi++;
    const t0 = Date.now();
    const goc = (cfg.PHOTO.pollinationsUrl || 'https://image.pollinations.ai').replace(/\/+$/, '');
    const q = new URLSearchParams({
      width: String(rong), height: String(cao), model: moHinh,
      seed: String(ke.hatGiong % 1_000_000), nologo: 'true',
    });
    const url = `${goc}/prompt/${encodeURIComponent(ke.prompt)}?${q}`;
    try {
      const r = await fetch(url, { headers: { 'user-agent': 'GITA-Photo-Studio/20' }, signal: AbortSignal.timeout(timeoutMs) });
      if (!r.ok) throw new Error(`HTTP_${r.status}`);
      const buf = Buffer.from(await r.arrayBuffer());
      if (buf.length < 5000) throw new Error(`TỆP_QUÁ_NHỎ_${buf.length}_BYTE`);
      this.stats.xong++;
      return { ok: true, cong: this.id, anh: buf, moHinh, hatGiong: ke.hatGiong, ms: Date.now() - t0, usd: 0 };
    } catch (e) {
      this.stats.hong++;
      return { ok: false, cong: this.id, loi: String(e.message).slice(0, 160), ms: Date.now() - t0 };
    }
  }
}

/** ── ComfyUI chạy tại máy: 0 đồng, cần GPU ──────────────────────────────── */
class CongComfyUI {
  constructor() {
    this.id = 'comfyui';
    this.ten = 'ComfyUI tại máy (0 đồng, cần GPU)';
    this.tinhTien = false;
    this.canMang = false;
    this.note = 'Cần ComfyUI đang chạy và có mô hình FLUX trong models/checkpoints.';
    this.stats = { goi: 0, xong: 0, hong: 0 };
  }

  sanSang() {
    if (!cfg.PHOTO.comfyUrl) return { ok: false, ly: 'CHƯA_CẤU_HÌNH', sua: 'Đặt COMFYUI_URL=http://127.0.0.1:8188' };
    return { ok: true, luuY: 'Chỉ chạy khi ComfyUI đang bật.' };
  }

  _quyTrinh(ke, rong, cao) {
    return {
      3: {
        class_type: 'KSampler',
        inputs: {
          seed: ke.hatGiong % 1_000_000, steps: 4, cfg: 1.0,
          sampler_name: 'euler', scheduler: 'simple', denoise: 1,
          model: ['4', 0], positive: ['6', 0], negative: ['7', 0], latent_image: ['5', 0],
        },
      },
      4: { class_type: 'CheckpointLoaderSimple', inputs: { ckpt_name: cfg.PHOTO.comfyModel } },
      5: { class_type: 'EmptyLatentImage', inputs: { width: rong, height: cao, batch_size: 1 } },
      6: { class_type: 'CLIPTextEncode', inputs: { text: ke.prompt, clip: ['4', 1] } },
      7: { class_type: 'CLIPTextEncode', inputs: { text: ke.promptCam || '', clip: ['4', 1] } },
      8: { class_type: 'VAEDecode', inputs: { samples: ['3', 0], vae: ['4', 2] } },
      9: { class_type: 'SaveImage', inputs: { filename_prefix: 'gita', images: ['8', 0] } },
    };
  }

  async tao(ke, { rong = 1024, cao = 1024, timeoutMs = 300_000 } = {}) {
    const av = this.sanSang();
    if (!av.ok) return { ok: false, cong: this.id, loi: av.ly };
    this.stats.goi++;
    const t0 = Date.now();
    const goc = cfg.PHOTO.comfyUrl.replace(/\/+$/, '');
    try {
      const gui = await fetch(`${goc}/prompt`, {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ prompt: this._quyTrinh(ke, rong, cao) }),
        signal: AbortSignal.timeout(30_000),
      });
      if (!gui.ok) throw new Error(`HTTP_${gui.status}: ${(await gui.text()).slice(0, 120)}`);
      const { prompt_id: pid } = await gui.json();
      if (!pid) throw new Error('KHÔNG_CÓ_MÃ_YÊU_CẦU');

      const han = Date.now() + timeoutMs;
      while (Date.now() < han) {
        await sleep(2000);
        const ls = await fetch(`${goc}/history/${pid}`, { signal: AbortSignal.timeout(20_000) }).then((r) => r.json());
        const ra = ls?.[pid]?.outputs;
        if (!ra) continue;
        for (const nut of Object.keys(ra)) {
          const img = ra[nut].images?.[0];
          if (!img) continue;
          const u = `${goc}/view?filename=${encodeURIComponent(img.filename)}&subfolder=${encodeURIComponent(img.subfolder || '')}&type=${encodeURIComponent(img.type || 'output')}`;
          const buf = Buffer.from(await (await fetch(u, { signal: AbortSignal.timeout(60_000) })).arrayBuffer());
          this.stats.xong++;
          return { ok: true, cong: this.id, anh: buf, tenTep: img.filename, ms: Date.now() - t0, usd: 0 };
        }
      }
      throw new Error(`HẾT_THỜI_GIAN_CHỜ_${Math.round(timeoutMs / 1000)}S`);
    } catch (e) {
      this.stats.hong++;
      return { ok: false, cong: this.id, loi: String(e.message).slice(0, 160), ms: Date.now() - t0 };
    }
  }
}

/** ── Hugging Face: cần khoá, có gói miễn phí ────────────────────────────── */
class CongHuggingFace {
  constructor() {
    this.id = 'huggingface';
    this.ten = 'Hugging Face Inference';
    this.tinhTien = false;
    this.canMang = true;
    this.note = 'Gói miễn phí có hạn mức và hay phải chờ mô hình khởi động.';
    this.stats = { goi: 0, xong: 0, hong: 0 };
  }

  sanSang() {
    if (!cfg.PHOTO.hfKey) return { ok: false, ly: 'THIẾU_KHOÁ', sua: 'Đặt HF_TOKEN (huggingface.co/settings/tokens)' };
    return { ok: true };
  }

  async tao(ke, { rong = 1024, cao = 1024, timeoutMs = 180_000 } = {}) {
    const av = this.sanSang();
    if (!av.ok) return { ok: false, cong: this.id, loi: av.ly };
    this.stats.goi++;
    const t0 = Date.now();
    try {
      const r = await fetch(`https://api-inference.huggingface.co/models/${cfg.PHOTO.hfModel}`, {
        method: 'POST',
        headers: { authorization: `Bearer ${cfg.PHOTO.hfKey}`, 'content-type': 'application/json' },
        body: JSON.stringify({
          inputs: ke.prompt,
          parameters: { negative_prompt: ke.promptCam, width: rong, height: cao },
        }),
        signal: AbortSignal.timeout(timeoutMs),
      });
      if (!r.ok) throw new Error(`HTTP_${r.status}`);
      const buf = Buffer.from(await r.arrayBuffer());
      if (buf.length < 5000) throw new Error('TỆP_QUÁ_NHỎ');
      this.stats.xong++;
      return { ok: true, cong: this.id, anh: buf, moHinh: cfg.PHOTO.hfModel, ms: Date.now() - t0, usd: 0 };
    } catch (e) {
      this.stats.hong++;
      return { ok: false, cong: this.id, loi: String(e.message).slice(0, 160), ms: Date.now() - t0 };
    }
  }
}

/** Bốn chế độ chạy, mỗi chế độ một thứ tự cổng. */
const CHE_DO = {
  'mien-phi': { ten: 'Miễn phí', thuTu: ['pollinations'], note: 'Không cần khoá, không cần GPU.' },
  'tai-may': { ten: 'Chạy tại máy', thuTu: ['comfyui'], note: 'Dữ liệu không ra khỏi máy. Cần GPU.' },
  'hon-hop': { ten: 'Hỗn hợp', thuTu: ['comfyui', 'pollinations'], note: 'Ưu tiên tại máy, hỏng thì ra dịch vụ miễn phí.' },
  'co-khoa': { ten: 'Có khoá', thuTu: ['huggingface', 'pollinations'], note: 'Dùng hạn mức Hugging Face trước.' },
};

class CongTaoAnh {
  constructor() {
    this.khungDung = new CongKhungDung();
    this.cong = new Map([
      ['pollinations', new CongPollinations()],
      ['comfyui', new CongComfyUI()],
      ['huggingface', new CongHuggingFace()],
    ]);
  }

  /** Thứ tự cổng sẽ thật sự được thử, kèm lý do bỏ qua cổng nào. */
  duongDi(cheDo = cfg.PHOTO.cheDo, uuTien = null) {
    const cd = CHE_DO[cheDo] || CHE_DO['mien-phi'];
    const ds = uuTien ? [uuTien, ...cd.thuTu.filter((x) => x !== uuTien)] : cd.thuTu;
    const chuoi = ds.map((id) => {
      const c = this.cong.get(id);
      if (!c) return { id, ok: false, ly: 'KHÔNG_CÓ_CỔNG_NÀY' };
      const av = c.sanSang();
      return { id, ten: c.ten, ok: av.ok, ly: av.ly || null, sua: av.sua || null, luuY: av.luuY || null, note: c.note || null };
    });
    return { cheDo, cheDoTen: cd.ten, note: cd.note, chuoi, chon: chuoi.find((x) => x.ok)?.id || null };
  }

  async tao(ke, { cheDo = cfg.PHOTO.cheDo, uuTien = null, rong, cao } = {}) {
    const dd = this.duongDi(cheDo, uuTien);
    const daThu = [];
    for (const b of dd.chuoi) {
      if (!b.ok) { daThu.push({ cong: b.id, loi: b.ly }); continue; }
      const r = await this.cong.get(b.id).tao(ke, { rong, cao });
      if (r.ok) return { ...r, daThu };
      daThu.push({ cong: b.id, loi: r.loi });
      L.warn(`Tạo ảnh qua ${b.id} hỏng: ${r.loi}`);
    }
    return {
      // Trả cả `error` để lớp HTTP ánh xạ được sang 503 — mã lỗi nghiệp vụ
      // mà không có tên chuẩn thì tầng trên phải đoán, và đoán là sai.
      ok: false, error: 'KHÔNG_CỔNG_NÀO_TẠO_ĐƯỢC_ẢNH', loi: 'KHÔNG_CỔNG_NÀO_TẠO_ĐƯỢC_ẢNH', daThu, duongDi: dd,
      goi: 'Vẫn dùng được: khung dựng bố cục, và hậu kỳ tám tầng trên ảnh có sẵn.',
    };
  }

  trangThai() {
    const dd = this.duongDi();
    return {
      cheDo: cfg.PHOTO.cheDo,
      cheDoCo: Object.entries(CHE_DO).map(([id, c]) => ({ id, ten: c.ten, note: c.note, thuTu: c.thuTu })),
      duongDi: dd,
      khungDung: { id: this.khungDung.id, ten: this.khungDung.ten, sanSang: true, canMang: false },
      cong: [...this.cong.values()].map((c) => {
        const av = c.sanSang();
        return { id: c.id, ten: c.ten, sanSang: av.ok, ly: av.ly || null, sua: av.sua || null, canMang: c.canMang, tinhTien: c.tinhTien, note: c.note || null, stats: { ...c.stats } };
      }),
    };
  }
}

module.exports = { CongTaoAnh, CongKhungDung, CongPollinations, CongComfyUI, CongHuggingFace, CHE_DO };
