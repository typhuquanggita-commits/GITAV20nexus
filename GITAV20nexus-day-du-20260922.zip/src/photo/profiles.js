'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  HỒ SƠ MÁY ẢNH VÀ GIẢ LẬP PHIM — bằng THAM SỐ, không bằng chuỗi lệnh ffmpeg
 * ═══════════════════════════════════════════════════════════════════════════
 *  Bản thiết kế mô tả chất màu bằng chuỗi `eq=contrast=1.12:saturation=1.25`.
 *  Chuỗi đó chỉ có nghĩa với ffmpeg: hệ thống không đọc được, không kiểm tra
 *  được, không so sánh được hai hồ sơ khác nhau ở đâu, và sai một dấu hai
 *  chấm là im lặng bỏ qua.
 *
 *  Ở đây mỗi hồ sơ là một bộ SỐ mà chính hệ thống hiểu và áp được: tương
 *  phản, bão hoà, gamma, nhiệt độ màu, cân bằng từng kênh, tối góc, hạt.
 *  Nhờ vậy bảng "hồ sơ này khác hồ sơ kia ở đâu" là một phép trừ, và kiểm
 *  thử đo được chất màu thật sự đổi đúng hướng.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { duongTuDiem } = require('./image');

/** Tám hồ sơ máy ảnh. `prompt` là phần mô tả gửi cho mô hình tạo ảnh. */
const MAY_ANH = {
  Fujifilm: {
    ten: 'Fujifilm GFX 100 II',
    note: 'Trung hình 102MP, màu Fujifilm, da trong và chuyển tông mượt',
    prompt: 'shot on Fujifilm GFX 100 II medium format, GF 110mm f/2 lens, Fujifilm color science, 102 megapixel, exceptional dynamic range, film-like rendering',
    mau: { tuongPhan: 1.12, baoHoa: 1.18, gamma: 1.04, kelvin: 6100, canBang: { r: 0.012, g: 0.004, b: -0.008 } },
    hat: 0.012, toiGoc: 0.14,
    exif: { Make: 'FUJIFILM', Model: 'GFX100 II', LensModel: 'GF110mmF2 R LM WR', FNumber: 2.0, ISO: 100, ExposureTime: '1/125', FocalLength: 110 },
  },
  Canon: {
    ten: 'Canon EOS R5',
    note: 'Toàn khung 45MP, tông da ấm, chuẩn thương mại',
    prompt: 'shot on Canon EOS R5 full-frame, RF 85mm f/1.2L lens, Canon Standard Picture Style, natural warm skin tones, 45 megapixel',
    mau: { tuongPhan: 1.08, baoHoa: 1.12, gamma: 1.02, kelvin: 5600, canBang: { r: 0.018, g: 0.006, b: -0.012 } },
    hat: 0.008, toiGoc: 0.10,
    exif: { Make: 'Canon', Model: 'EOS R5', LensModel: 'RF85mm F1.2 L USM', FNumber: 1.2, ISO: 200, ExposureTime: '1/160', FocalLength: 85 },
  },
  Sony: {
    ten: 'Sony α7R V',
    note: 'Toàn khung 61MP, trong trẻo, trung tính',
    prompt: 'shot on Sony A7R V, FE 85mm f/1.4 GM lens, Sony Creative Look ST, 61 megapixel, high clarity',
    mau: { tuongPhan: 1.10, baoHoa: 1.08, gamma: 1.00, kelvin: 6500, canBang: { r: 0.004, g: 0.008, b: 0.004 } },
    hat: 0.006, toiGoc: 0.08,
    exif: { Make: 'SONY', Model: 'ILCE-7RM5', LensModel: 'FE 85mm F1.4 GM', FNumber: 1.4, ISO: 160, ExposureTime: '1/200', FocalLength: 85 },
  },
  Leica: {
    ten: 'Leica M11',
    note: 'Vi tương phản cao, màu kiềm chế, chất Đức',
    prompt: 'shot on Leica M11, Summilux-M 50mm f/1.4 ASPH, Leica M look, rich microcontrast, 60 megapixel',
    mau: { tuongPhan: 1.16, baoHoa: 1.02, gamma: 1.05, kelvin: 6300, canBang: { r: 0.006, g: 0.002, b: 0.000 } },
    hat: 0.014, toiGoc: 0.20,
    exif: { Make: 'Leica Camera AG', Model: 'LEICA M11', LensModel: 'Summilux-M 1:1.4/50 ASPH.', FNumber: 1.4, ISO: 200, ExposureTime: '1/250', FocalLength: 50 },
  },
  Hasselblad: {
    ten: 'Hasselblad H6D-100c',
    note: 'Trung hình 100MP, màu tự nhiên Bắc Âu, nhẹ tay nhất',
    prompt: 'shot on Hasselblad H6D-100c, HC 100mm f/2.2 lens, Hasselblad Natural Colour Solution, 100 megapixel medium format',
    mau: { tuongPhan: 1.05, baoHoa: 1.06, gamma: 1.02, kelvin: 6500, canBang: { r: 0.006, g: 0.006, b: 0.002 } },
    hat: 0.005, toiGoc: 0.07,
    exif: { Make: 'Hasselblad', Model: 'H6D-100c', LensModel: 'HC 100', FNumber: 2.2, ISO: 100, ExposureTime: '1/250', FocalLength: 100 },
  },
  ARRI: {
    ten: 'ARRI Alexa 65',
    note: 'Chất điện ảnh: tương phản cao, bão hoà thấp, ngả lạnh',
    prompt: 'shot on ARRI Alexa 65, Panavision Sphero 65 lens, cinematic film look, Hollywood color science, 6.5K',
    mau: { tuongPhan: 1.22, baoHoa: 0.92, gamma: 1.08, doSang: -0.015, kelvin: 7000, canBang: { r: 0.010, g: 0.000, b: -0.018 } },
    hat: 0.022, toiGoc: 0.24,
    exif: { Make: 'ARRI', Model: 'ALEXA 65', LensModel: 'Panavision Sphero 65', FNumber: 2.8, ISO: 800, ExposureTime: '1/48', FocalLength: 40 },
  },
  RED: {
    ten: 'RED V-Raptor 8K VV',
    note: 'Điện ảnh nhưng màu thẳng hơn ARRI',
    prompt: 'shot on RED V-Raptor 8K VV, cinematic color science, high dynamic range',
    mau: { tuongPhan: 1.18, baoHoa: 1.00, gamma: 1.05, doSang: -0.008, kelvin: 6800, canBang: { r: 0.006, g: 0.000, b: -0.010 } },
    hat: 0.018, toiGoc: 0.20,
    exif: { Make: 'RED Digital Cinema', Model: 'V-RAPTOR 8K VV', LensModel: 'RED Prime', FNumber: 2.0, ISO: 800, ExposureTime: '1/48', FocalLength: 35 },
  },
  iPhone: {
    ten: 'iPhone 16 Pro Max',
    note: 'Nhiếp ảnh tính toán: sạch, sáng đều, hơi tăng tương phản cục bộ',
    prompt: 'shot on iPhone 16 Pro Max, Apple ProRAW, computational photography, natural HDR',
    mau: { tuongPhan: 1.10, baoHoa: 1.06, gamma: 1.03, doSang: 0.012, kelvin: 6400, canBang: { r: 0.002, g: 0.002, b: 0.002 } },
    hat: 0.004, toiGoc: 0.05,
    exif: { Make: 'Apple', Model: 'iPhone 16 Pro Max', LensModel: 'iPhone 16 Pro Max back triple camera', FNumber: 1.78, ISO: 50, ExposureTime: '1/2000', FocalLength: 24 },
  },
  KhongApDung: {
    ten: 'Không áp dụng',
    note: 'Giữ nguyên ảnh gốc — dùng để so sánh',
    prompt: '',
    mau: {}, hat: 0, toiGoc: 0,
    exif: { Make: 'GITA Photo Studio', Model: 'nguyên bản' },
  },
};

/**
 * Giả lập phim bằng ĐƯỜNG TÔNG thật cho từng kênh.
 * Đây mới là chỗ tạo ra "chất phim": vai tối nâng lên, vùng sáng nén lại,
 * và ba kênh cong khác nhau. Nhân hệ số bão hoà không bao giờ ra chất đó.
 */
const PHIM = {
  Khong: { ten: 'Không giả lập', diem: null },
  KodakPortra400: {
    ten: 'Kodak Portra 400',
    note: 'Da ấm, vai tối nâng nhẹ, vùng sáng hồng — chuẩn chụp người',
    diem: {
      r: [[0, 0.04], [0.25, 0.30], [0.5, 0.55], [0.75, 0.79], [1, 0.98]],
      g: [[0, 0.03], [0.25, 0.27], [0.5, 0.52], [0.75, 0.77], [1, 0.97]],
      b: [[0, 0.05], [0.25, 0.25], [0.5, 0.49], [0.75, 0.74], [1, 0.95]],
    },
    baoHoaThem: 0.96, hatThem: 0.010,
  },
  KodakEktar100: {
    ten: 'Kodak Ektar 100',
    note: 'Bão hoà cao, đỏ mạnh, hạt rất mịn — chuẩn phong cảnh',
    diem: {
      r: [[0, 0.02], [0.25, 0.26], [0.5, 0.54], [0.75, 0.82], [1, 1.00]],
      g: [[0, 0.02], [0.25, 0.24], [0.5, 0.51], [0.75, 0.79], [1, 0.99]],
      b: [[0, 0.03], [0.25, 0.23], [0.5, 0.48], [0.75, 0.76], [1, 0.98]],
    },
    baoHoaThem: 1.16, hatThem: 0.004,
  },
  FujiVelvia50: {
    ten: 'Fujifilm Velvia 50',
    note: 'Rực rỡ, tương phản mạnh, lục và lam nổi',
    diem: {
      r: [[0, 0.01], [0.25, 0.22], [0.5, 0.52], [0.75, 0.84], [1, 1.00]],
      g: [[0, 0.01], [0.25, 0.23], [0.5, 0.54], [0.75, 0.85], [1, 1.00]],
      b: [[0, 0.02], [0.25, 0.24], [0.5, 0.53], [0.75, 0.83], [1, 1.00]],
    },
    baoHoaThem: 1.24, hatThem: 0.006,
  },
  FujiProvia100F: {
    ten: 'Fujifilm Provia 100F',
    note: 'Cân bằng, trung thực, ít can thiệp',
    diem: {
      r: [[0, 0.02], [0.25, 0.25], [0.5, 0.51], [0.75, 0.78], [1, 0.99]],
      g: [[0, 0.02], [0.25, 0.25], [0.5, 0.51], [0.75, 0.78], [1, 0.99]],
      b: [[0, 0.02], [0.25, 0.25], [0.5, 0.51], [0.75, 0.78], [1, 0.99]],
    },
    baoHoaThem: 1.06, hatThem: 0.006,
  },
  IlfordHP5: {
    ten: 'Ilford HP5 Plus (đen trắng)',
    note: 'Đen trắng, hạt rõ, vai tối mềm',
    denTrang: true,
    diem: {
      r: [[0, 0.06], [0.25, 0.28], [0.5, 0.52], [0.75, 0.77], [1, 0.96]],
      g: [[0, 0.06], [0.25, 0.28], [0.5, 0.52], [0.75, 0.77], [1, 0.96]],
      b: [[0, 0.06], [0.25, 0.28], [0.5, 0.52], [0.75, 0.77], [1, 0.96]],
    },
    baoHoaThem: 0, hatThem: 0.030,
  },
  Cinestill800T: {
    ten: 'Cinestill 800T',
    note: 'Phim đèn dây tóc: ngả lam, quầng đỏ quanh đèn, chụp đêm',
    diem: {
      r: [[0, 0.07], [0.25, 0.28], [0.5, 0.52], [0.75, 0.76], [1, 0.95]],
      g: [[0, 0.06], [0.25, 0.27], [0.5, 0.51], [0.75, 0.76], [1, 0.96]],
      b: [[0, 0.10], [0.25, 0.33], [0.5, 0.57], [0.75, 0.81], [1, 1.00]],
    },
    baoHoaThem: 1.05, hatThem: 0.026,
  },
};

/** Dựng bảng 256 mức cho một loại phim. Tính một lần rồi nhớ lại. */
const _nhoDuong = new Map();
function duongPhim(tenPhim) {
  const p = PHIM[tenPhim];
  if (!p || !p.diem) return null;
  if (_nhoDuong.has(tenPhim)) return _nhoDuong.get(tenPhim);
  const d = { r: duongTuDiem(p.diem.r), g: duongTuDiem(p.diem.g), b: duongTuDiem(p.diem.b) };
  _nhoDuong.set(tenPhim, d);
  return d;
}

function layMayAnh(ten) { return MAY_ANH[ten] || MAY_ANH.KhongApDung; }
function layPhim(ten) { return PHIM[ten] || PHIM.Khong; }
function lietKeMayAnh() {
  return Object.entries(MAY_ANH).map(([id, m]) => ({ id, ten: m.ten, note: m.note, mau: m.mau }));
}
function lietKePhim() {
  return Object.entries(PHIM).map(([id, p]) => ({ id, ten: p.ten, note: p.note || '', denTrang: !!p.denTrang }));
}

/** Hai hồ sơ khác nhau ở đâu — một phép trừ, vì chất màu là số. */
function soSanh(a, b) {
  const x = layMayAnh(a).mau; const y = layMayAnh(b).mau;
  const khoa = new Set([...Object.keys(x), ...Object.keys(y)]);
  const ra = {};
  for (const k of khoa) {
    if (k === 'canBang') continue;
    const va = x[k] ?? (k === 'doSang' ? 0 : 1);
    const vb = y[k] ?? (k === 'doSang' ? 0 : 1);
    if (va !== vb) ra[k] = { [a]: va, [b]: vb, lech: Math.round((vb - va) * 1000) / 1000 };
  }
  return ra;
}

module.exports = { MAY_ANH, PHIM, layMayAnh, layPhim, duongPhim, lietKeMayAnh, lietKePhim, soSanh };
