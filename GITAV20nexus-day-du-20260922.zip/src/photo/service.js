'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  XƯỞNG ẢNH — tám tầng, và cái nào chạy được không cần mạng
 * ═══════════════════════════════════════════════════════════════════════════
 *  Ba cửa vào, xếp theo thứ tự "làm được ngay" giảm dần:
 *
 *   1. chuanBi()  dựng prompt + chọn bố cục + vẽ khung dựng.  Không cần mạng.
 *   2. hauKy()    tám tầng hậu kỳ trên ảnh CÓ SẴN của người dùng. Không cần
 *                 mạng, không cần khoá, không cần ffmpeg. Đây là phần làm
 *                 việc thật sự của xưởng.
 *   3. tao()      gọi dịch vụ sinh ảnh rồi chạy tiếp tầng 4–8. Cần mạng.
 *
 *  Tám tầng: đọc ảnh → chuẩn khung → phóng to nhiều lần → chất màu máy ảnh →
 *  đường tông phim → làm sắc → hạt và tối góc → soát và xuất.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const cfg = require('../config');
const L = require('../logger');
const { id: newId, round, sha256 } = require('../utils');
const PNG = require('./png');
const JPG = require('./jpeg');
const I = require('./image');
const { dungPrompt } = require('./prompt');
const { boCucCho, KIEU_ANH } = require('./composition');
const { layMayAnh, layPhim, duongPhim, lietKeMayAnh, lietKePhim, soSanh: soSanhHoSo } = require('./profiles');
const QC = require('./qc');
const { CongTaoAnh, CHE_DO } = require('./providers');

/** Mức chất lượng: cạnh dài mục tiêu và số lần phóng. */
const MUC = {
  hd: { ten: 'HD', canh: 1280, mp: 1.6, lanPhong: 1 },
  '2k': { ten: '2K', canh: 2048, mp: 4.2, lanPhong: 1 },
  '4k': { ten: '4K', canh: 3072, mp: 9.4, lanPhong: 2 },
  '8k': { ten: '8K', canh: 4608, mp: 21.2, lanPhong: 2 },
};

class PhotoService {
  constructor({ db = null, bus = null } = {}) {
    this.cong = new CongTaoAnh();
    this.bus = bus;
    this.repo = db ? db.collection('photo_jobs', { indexes: ['trangThai'] }) : null;
    this.viec = new Map();
    if (this.repo) for (const d of this.repo.all()) this.viec.set(d.id, d);
    this.stats = { chuanBi: 0, hauKy: 0, tao: 0, hong: 0, msXuLy: 0, diemTong: 0, soCham: 0 };
  }

  /** ── TẦNG 1–2: prompt, bố cục, khung dựng ─────────────────────────────── */
  chuanBi(moTa, t = {}) {
    if (!moTa || !String(moTa).trim()) return { ok: false, error: 'THIẾU_MÔ_TẢ' };
    this.stats.chuanBi++;
    const ke = dungPrompt(moTa, {
      kieuAnh: t.kieuAnh || 'chan-dung',
      mayAnh: t.mayAnh || cfg.PHOTO.mayAnh,
      phim: t.phim || cfg.PHOTO.phim,
      ongKinh: t.ongKinh || null, anhSang: t.anhSang || null,
      camXuc: t.camXuc || 'dien-anh', boCuc: t.boCuc || null, bien: t.bien || 0,
    });
    const chatLuong = MUC[t.chatLuong || cfg.PHOTO.chatLuong] ? (t.chatLuong || cfg.PHOTO.chatLuong) : '4k';
    return {
      ok: true,
      ...ke,
      chatLuong, muc: MUC[chatLuong],
      khungDung: this.cong.khungDung.ve(ke),
      duongDi: this.cong.duongDi(t.cheDo || cfg.PHOTO.cheDo, t.uuTien || null),
      boCucKhac: boCucCho(ke.kieuAnh),
    };
  }

  /** Đọc một tệp ảnh bất kỳ thành ảnh RGBA. */
  doc(buf) {
    if (!Buffer.isBuffer(buf) || !buf.length) return { ok: false, error: 'THIẾU_TỆP_ẢNH' };
    if (buf.length > cfg.PHOTO.tranByteVao) {
      return { ok: false, error: 'TỆP_QUÁ_LỚN', byte: buf.length, tran: cfg.PHOTO.tranByteVao };
    }
    const dang = PNG.nhanDang(buf);
    if (dang === 'png') return { ...PNG.docPNG(buf), dang };
    if (dang === 'jpeg') return { ...JPG.docJPEG(buf), dang };
    return { ok: false, error: 'CHƯA_HỖ_TRỢ_ĐỊNH_DẠNG', dang,
      goi: 'Hệ thống đọc được PNG và JPEG baseline. Hãy xuất lại ảnh sang một trong hai.' };
  }

  /**
   * ── TẦNG 3–8: HẬU KỲ ─────────────────────────────────────────────────────
   * Chạy trên ảnh có sẵn. Không cần mạng, không cần khoá, không cần ffmpeg.
   */
  hauKy(anhVao, t = {}) {
    const t0 = Date.now();
    const doc = Buffer.isBuffer(anhVao) ? this.doc(anhVao) : { ok: true, ...anhVao, dang: 'rgba' };
    if (!doc.ok) return doc;

    const mayAnh = t.mayAnh || cfg.PHOTO.mayAnh;
    const phim = t.phim || cfg.PHOTO.phim;
    const chatLuong = MUC[t.chatLuong] ? t.chatLuong : cfg.PHOTO.chatLuong;
    const muc = MUC[chatLuong] || MUC['4k'];
    const ma = layMayAnh(mayAnh);
    const ph = layPhim(phim);

    let anh = { width: doc.width, height: doc.height, data: doc.data };
    const truoc = { width: anh.width, height: anh.height, data: Buffer.from(anh.data) };
    const buoc = [];
    const ghi = (ten, chiTiet) => buoc.push({ buoc: ten, chiTiet, rong: anh.width, cao: anh.height });

    ghi('đọc ảnh', `${doc.dang.toUpperCase()} ${anh.width}×${anh.height} (${round(anh.width * anh.height / 1e6, 2)}MP)`);

    // ── Tầng 3: phóng to nhiều lần, làm sắc nhẹ giữa các lần ──
    const canhDai = Math.max(anh.width, anh.height);
    const dichCanh = t.giuKichThuoc ? canhDai : muc.canh;
    if (dichCanh !== canhDai) {
      const tongTiLe = dichCanh / canhDai;
      const lan = tongTiLe > 1 ? Math.min(muc.lanPhong, Math.max(1, Math.ceil(Math.log2(tongTiLe)))) : 1;
      const dichRong = Math.max(8, Math.round(doc.width * tongTiLe));
      const dichCao = Math.max(8, Math.round(doc.height * tongTiLe));
      for (let i = 1; i <= lan; i++) {
        // Lần cuối nhảy thẳng tới kích thước đích. Nhân dần từng bước rồi làm
        // tròn mỗi bước sẽ trôi vài điểm ảnh — 4:3 mà ra 3072×2305 thì tỉ lệ
        // khung hình đã sai, in ra là lệch mép.
        const w = i === lan ? dichRong : Math.max(8, Math.round(anh.width * Math.pow(tongTiLe, 1 / lan)));
        const h = i === lan ? dichCao : Math.max(8, Math.round(anh.height * Math.pow(tongTiLe, 1 / lan)));
        const mp = (w * h) / 1e6;
        if (mp > cfg.PHOTO.tranMegapixel) {
          ghi('phóng to', `dừng ở ${anh.width}×${anh.height} — bước sau sẽ vượt trần ${cfg.PHOTO.tranMegapixel}MP`);
          break;
        }
        anh = I.doiKichThuoc(anh, w, h);
        // Mỗi lần phóng làm ảnh mềm đi một chút; làm sắc nhẹ ngay sau đó
        // hiệu quả hơn hẳn việc để dồn tới cuối rồi làm sắc một lần thật mạnh.
        if (tongTiLe > 1 && i < lan) anh = I.lamSac(anh, { banKinh: 1.0, cuongDo: 0.45, nguong: 2 }).anh;
        ghi('phóng to', `lần ${i}/${lan} → ${anh.width}×${anh.height} (Lanczos-3)`);
      }
    }

    // ── Tầng 4: chất màu máy ảnh ──
    if (Object.keys(ma.mau).length) {
      anh = I.chinhMau(anh, { ...ma.mau, ...(t.mauThem || {}) });
      ghi('chất màu máy ảnh', `${ma.ten}: tương phản ${ma.mau.tuongPhan ?? 1} · bão hoà ${ma.mau.baoHoa ?? 1} · ${ma.mau.kelvin ?? '—'}K`);
    } else if (t.mauThem) {
      anh = I.chinhMau(anh, t.mauThem);
      ghi('chất màu', 'chỉ áp tham số người dùng truyền vào');
    }

    // ── Tầng 5: đường tông giả lập phim ──
    if (ph.diem) {
      anh = I.apDuongTong(anh, duongPhim(phim));
      if (ph.baoHoaThem !== undefined && ph.baoHoaThem !== 1) {
        anh = I.chinhMau(anh, { baoHoa: ph.baoHoaThem });
      }
      ghi('giả lập phim', `${ph.ten}${ph.denTrang ? ' (đen trắng)' : ''} · bão hoà ×${ph.baoHoaThem}`);
    }

    // ── Tầng 6: làm sắc ──
    const sac = t.lamSac === false ? null : {
      banKinh: t.lamSac?.banKinh ?? 1.2,
      cuongDo: t.lamSac?.cuongDo ?? 0.95,
      nguong: t.lamSac?.nguong ?? 3,
    };
    if (sac) {
      const r = I.lamSac(anh, sac);
      anh = r.anh;
      ghi('làm sắc', `bán kính ${sac.banKinh} · cường độ ${sac.cuongDo} · ngưỡng ${sac.nguong} → sửa ${r.diemDaSua.toLocaleString('vi-VN')} điểm`);
    }

    // ── Tầng 7: hạt phim và tối góc ──
    const hat = t.hat ?? (ma.hat + (ph.hatThem || 0));
    if (hat > 0) {
      anh = I.themHat(anh, { cuongDo: hat, seed: t.hatGiong || sha256(`${mayAnh}|${phim}`).slice(0, 12) });
      ghi('hạt phim', `cường độ ${round(hat, 3)} (tất định theo hạt giống)`);
    }
    const vig = t.toiGoc ?? ma.toiGoc;
    if (vig > 0) {
      anh = I.toiGoc(anh, { cuongDo: vig });
      ghi('tối góc', `cường độ ${vig}`);
    }

    // ── Tầng 8: soát và xuất ──
    const ctxCham = { mayAnh, phim, canhMucTieu: t.giuKichThuoc ? null : muc.canh };
    const soSanh = QC.soSanh(truoc, anh, ctxCham);
    const cham = QC.soat(anh, ctxCham);
    const ms = Date.now() - t0;
    this.stats.hauKy++;
    this.stats.msXuLy += ms;
    this.stats.diemTong += cham.diem;
    this.stats.soCham++;

    return {
      ok: true,
      anh,
      rong: anh.width, cao: anh.height,
      megapixel: round(anh.width * anh.height / 1e6, 2),
      mayAnh, mayAnhTen: ma.ten, phim, phimTen: ph.ten, chatLuong,
      buoc, soSanh, cham,
      ms,
      exif: { ...ma.exif, SoftwareUsed: 'GITAmath Nexus V20 — xưởng ảnh', ProcessedAt: new Date().toISOString() },
    };
  }

  /** Xuất ra tệp: PNG gốc + JPEG giao hàng + siêu dữ liệu. */
  xuat(anh, { mayAnh = cfg.PHOTO.mayAnh, chatLuongJpeg = cfg.PHOTO.chatLuongJpeg, exif = null } = {}) {
    const png = PNG.ghiPNG(anh, { nen: 9 });
    const jpg = JPG.ghiJPEG(anh, { chatLuong: chatLuongJpeg });
    return {
      ok: true,
      png, jpeg: jpg,
      bytePng: png.length, byteJpeg: jpg.length,
      tiLeNen: round(jpg.length / png.length, 3),
      sieuDuLieu: { ...(exif || layMayAnh(mayAnh).exif), ChatLuongJpeg: chatLuongJpeg, Rong: anh.width, Cao: anh.height },
    };
  }

  /** ── CỬA 3: sinh ảnh rồi hậu kỳ ──────────────────────────────────────── */
  async tao(moTa, t = {}) {
    const ke = this.chuanBi(moTa, t);
    if (!ke.ok) return ke;
    this.stats.tao++;

    const muc = ke.muc;
    // Sinh ở cạnh 1024 rồi phóng to bằng Lanczos — hầu hết mô hình cho chất
    // lượng tốt nhất quanh kích thước huấn luyện, xin thẳng 4K thường ra ảnh
    // méo bố cục.
    const r = await this.cong.tao(ke, { cheDo: t.cheDo || cfg.PHOTO.cheDo, uuTien: t.uuTien || null, rong: 1024, cao: 1024 });
    if (!r.ok) { this.stats.hong++; return { ...r, ke }; }

    const hk = this.hauKy(r.anh, { ...t, chatLuong: ke.chatLuong });
    if (!hk.ok) { this.stats.hong++; return hk; }

    const viec = {
      id: newId('ANH'), taoLuc: Date.now(), trangThai: 'XONG',
      moTa, cong: r.cong, ms: (r.ms || 0) + hk.ms,
      ke: { prompt: ke.prompt, boCuc: ke.boCuc, ongKinh: ke.ongKinh, anhSang: ke.anhSang, mayAnh: ke.mayAnh, phim: ke.phim },
      ketQua: { rong: hk.rong, cao: hk.cao, megapixel: hk.megapixel, diem: hk.cham.diem, xep: hk.cham.xep },
    };
    this._luu(viec);
    this.bus?.safeEmit?.('photo:created', { id: viec.id, cong: r.cong, diem: hk.cham.diem });
    return { ok: true, viec: viec.id, cong: r.cong, daThu: r.daThu || [], ke, ...hk, msSinh: r.ms };
  }

  _luu(v) { this.viec.set(v.id, v); if (this.repo) this.repo.put(v); }

  danhSach({ limit = 30 } = {}) {
    const ds = [...this.viec.values()].sort((a, b) => b.taoLuc - a.taoLuc).slice(0, limit);
    return { ok: true, tong: this.viec.size, items: ds };
  }

  status() {
    return {
      cong: this.cong.trangThai(),
      mayAnh: lietKeMayAnh(),
      phim: lietKePhim(),
      kieuAnh: Object.entries(KIEU_ANH).map(([id, ten]) => ({ id, ten })),
      mucChatLuong: Object.entries(MUC).map(([id, m]) => ({ id, ...m })),
      dinhDangDocDuoc: ['png', 'jpeg (baseline)'],
      gioiHan: { tranMegapixel: cfg.PHOTO.tranMegapixel, tranByteVao: cfg.PHOTO.tranByteVao },
      viec: this.viec.size,
      stats: {
        ...this.stats,
        diemTrungBinh: this.stats.soCham ? round(this.stats.diemTong / this.stats.soCham, 1) : 0,
        msTrungBinh: this.stats.hauKy ? Math.round(this.stats.msXuLy / this.stats.hauKy) : 0,
      },
    };
  }
}

module.exports = { PhotoService, MUC };
