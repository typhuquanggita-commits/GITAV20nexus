'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BỐ CỤC — chọn TẤT ĐỊNH, không bốc thăm
 * ═══════════════════════════════════════════════════════════════════════════
 *  Bản thiết kế chọn bố cục bằng `Math.random()`. Hai hệ quả, cái nào cũng
 *  hỏng: cùng một yêu cầu chạy hai lần ra hai bố cục khác nhau nên không
 *  dựng lại được bộ ảnh đã duyệt; và chụp một bộ mười tấm thì bố cục nhảy
 *  loạn, không ra bộ.
 *
 *  Ở đây bố cục được chọn theo BĂM của chính nội dung yêu cầu: cùng một mô
 *  tả luôn ra cùng một bố cục, mà mười mô tả khác nhau vẫn trải đều. Muốn
 *  đổi thì đổi số hiệu tấm (`bien`), không phải cầu may.
 *
 *  Mỗi bố cục còn kèm TOẠ ĐỘ đặt chủ thể trong khung, để lớp dựng khung mẫu
 *  vẽ ra được — bố cục nói bằng lời thì không kiểm được, nói bằng toạ độ thì
 *  kiểm được.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { fnv1a } = require('../utils');

const BO_CUC = {
  'mot-phan-ba': {
    ten: 'Quy tắc một phần ba',
    prompt: 'rule of thirds composition, subject placed on intersection point, balanced professional framing',
    chuThe: { x: 0.333, y: 0.382 }, trong: 8,
    hop: ['chan-dung', 'phong-canh', 'duong-pho', 'tai-lieu', 'san-pham'],
  },
  'ty-le-vang': {
    ten: 'Tỷ lệ vàng',
    prompt: 'golden ratio composition, 1.618 proportion, Fibonacci spiral arrangement, natural harmony',
    chuThe: { x: 0.382, y: 0.382 }, trong: 9,
    hop: ['chan-dung', 'thoi-trang', 'phong-canh', 'my-thuat'],
  },
  'duong-dan': {
    ten: 'Đường dẫn mắt',
    prompt: 'leading lines guiding the eye to the subject, strong perspective, dynamic composition',
    chuThe: { x: 0.62, y: 0.5 }, trong: 8,
    hop: ['phong-canh', 'kien-truc', 'duong-pho'],
  },
  'doi-xung': {
    ten: 'Đối xứng',
    prompt: 'perfect symmetry, centered composition, mirrored elements, architectural balance',
    chuThe: { x: 0.5, y: 0.5 }, trong: 7,
    hop: ['kien-truc', 'san-pham', 'my-thuat'],
  },
  'khoang-trong': {
    ten: 'Khoảng trống',
    prompt: 'generous negative space, minimalist composition, subject offset, breathing room',
    chuThe: { x: 0.28, y: 0.55 }, trong: 7,
    hop: ['san-pham', 'thoi-trang', 'my-thuat', 'chan-dung'],
  },
  'lop-chieu-sau': {
    ten: 'Lớp chiều sâu',
    prompt: 'foreground midground background layers, deep depth of field separation, environmental context',
    chuThe: { x: 0.44, y: 0.52 }, trong: 8,
    hop: ['chan-dung', 'phong-canh', 'tai-lieu', 'thoi-trang'],
  },
  'cheo-dong': {
    ten: 'Chéo động',
    prompt: 'diagonal composition, dynamic tilted angle, energetic framing, sense of movement',
    chuThe: { x: 0.6, y: 0.38 }, trong: 7,
    hop: ['duong-pho', 'thoi-trang', 'kien-truc'],
  },
  'khung-trong-khung': {
    ten: 'Khung trong khung',
    prompt: 'frame within a frame, natural framing element in foreground, contextual depth',
    chuThe: { x: 0.5, y: 0.46 }, trong: 8,
    hop: ['duong-pho', 'tai-lieu', 'kien-truc', 'chan-dung'],
  },
};

const KIEU_ANH = {
  'chan-dung': 'Chân dung',
  'phong-canh': 'Phong cảnh',
  'san-pham': 'Sản phẩm',
  'duong-pho': 'Đường phố',
  'kien-truc': 'Kiến trúc',
  'thoi-trang': 'Thời trang',
  'tai-lieu': 'Tài liệu',
  'my-thuat': 'Mỹ thuật',
};

/**
 * Chọn bố cục tất định.
 * @param {string} kieuAnh
 * @param {string} hatGiong thường là chính mô tả ảnh
 * @param {number} bien số hiệu tấm trong bộ — đổi số này để ra bố cục khác
 */
function chonBoCuc(kieuAnh, hatGiong = '', bien = 0) {
  const ungVien = Object.entries(BO_CUC)
    .filter(([, b]) => b.hop.includes(kieuAnh))
    .map(([id, b]) => ({ id, ...b }));
  const ds = ungVien.length ? ungVien : Object.entries(BO_CUC).map(([id, b]) => ({ id, ...b }));

  // Bánh xe có trọng số, quay bằng băm chứ không bằng may rủi.
  const tong = ds.reduce((s, b) => s + b.trong, 0);
  const h = fnv1a(`${kieuAnh}|${hatGiong}|${bien}`);
  let moc = h % tong;
  for (const b of ds) {
    moc -= b.trong;
    if (moc < 0) return b;
  }
  return ds[ds.length - 1];
}

/** Mọi bố cục hợp với kiểu ảnh này — để người dùng chọn tay. */
function boCucCho(kieuAnh) {
  return Object.entries(BO_CUC)
    .filter(([, b]) => b.hop.includes(kieuAnh))
    .map(([id, b]) => ({ id, ten: b.ten, chuThe: b.chuThe }));
}

module.exports = { BO_CUC, KIEU_ANH, chonBoCuc, boCucCho };
