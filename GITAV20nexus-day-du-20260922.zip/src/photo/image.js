'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  XỬ LÝ ẢNH — toàn bộ tầng hậu kỳ, viết thẳng bằng JavaScript
 * ═══════════════════════════════════════════════════════════════════════════
 *  Bản thiết kế gọi ffmpeg cho mọi khâu: `scale=...:flags=lanczos`,
 *  `unsharp=5:5:0.8`, `eq=contrast=1.12:saturation=1.25`, `signalstats`.
 *  Máy chủ không có ffmpeg, nên toàn bộ chuỗi đó được viết lại bằng thuật
 *  toán thật:
 *
 *    · Lanczos-3 — nội suy có cửa sổ sinc, sắc hơn song tuyến tính rõ rệt
 *    · Mặt nạ làm sắc — làm mờ Gauss rồi trừ, có ngưỡng để không khuếch đại
 *      nhiễu ở vùng da mịn
 *    · Chỉnh màu — tương phản quanh điểm giữa, bão hoà theo độ sáng cảm
 *      nhận (không kéo lệch sắc), gamma, cân bằng trắng theo Kelvin
 *    · Đường tông giả lập phim — bảng 256 mức cho từng kênh, nội suy đơn điệu
 *    · Đo chất lượng — trung bình, độ lệch chuẩn, phương sai Laplace (độ
 *      nét), tỉ lệ cháy sáng và bẹp tối, lệch cân bằng trắng
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { seededRandom, round, clamp } = require('../utils');

const kep = (v) => (v < 0 ? 0 : v > 255 ? 255 : v);
const luma = (r, g, b) => 0.2126 * r + 0.7152 * g + 0.0722 * b;

function saoChep(anh) {
  return { width: anh.width, height: anh.height, data: Buffer.from(anh.data) };
}

/** ── NỘI SUY LANCZOS-3 ───────────────────────────────────────────────────── */
function sinc(x) { return x === 0 ? 1 : Math.sin(Math.PI * x) / (Math.PI * x); }
function lanczos(x, a = 3) {
  const ax = Math.abs(x);
  if (ax >= a) return 0;
  return sinc(x) * sinc(x / a);
}

/** Bảng trọng số cho một trục — tính một lần rồi dùng cho mọi dòng/cột. */
function bangTrongSo(nguon, dich, a = 3) {
  const tiLe = dich / nguon;
  const banKinh = tiLe < 1 ? a / tiLe : a;      // thu nhỏ thì phải lấy cửa sổ rộng hơn
  const bang = [];
  for (let i = 0; i < dich; i++) {
    const tam = (i + 0.5) / tiLe - 0.5;
    const tu = Math.ceil(tam - banKinh);
    const den = Math.floor(tam + banKinh);
    const ds = [];
    let tong = 0;
    for (let j = tu; j <= den; j++) {
      const w = lanczos(tiLe < 1 ? (j - tam) * tiLe : j - tam, a);
      if (w === 0) continue;
      const k = j < 0 ? 0 : j >= nguon ? nguon - 1 : j;      // kẹp mép
      ds.push({ k, w });
      tong += w;
    }
    for (const d of ds) d.w /= tong || 1;
    bang.push(ds);
  }
  return bang;
}

/** Phóng to / thu nhỏ bằng Lanczos-3, tách hai trục cho nhanh. */
function doiKichThuoc(anh, rongMoi, caoMoi) {
  const { width: W, height: H, data } = anh;
  if (rongMoi === W && caoMoi === H) return saoChep(anh);

  const bx = bangTrongSo(W, rongMoi);
  const by = bangTrongSo(H, caoMoi);

  // Bước 1: theo trục ngang
  const tam = new Float32Array(rongMoi * H * 4);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < rongMoi; x++) {
      let r = 0; let g = 0; let b = 0; let a = 0;
      for (const { k, w } of bx[x]) {
        const i = (y * W + k) * 4;
        r += data[i] * w; g += data[i + 1] * w; b += data[i + 2] * w; a += data[i + 3] * w;
      }
      const o = (y * rongMoi + x) * 4;
      tam[o] = r; tam[o + 1] = g; tam[o + 2] = b; tam[o + 3] = a;
    }
  }

  // Bước 2: theo trục dọc
  const ra = Buffer.alloc(rongMoi * caoMoi * 4);
  for (let y = 0; y < caoMoi; y++) {
    for (let x = 0; x < rongMoi; x++) {
      let r = 0; let g = 0; let b = 0; let a = 0;
      for (const { k, w } of by[y]) {
        const i = (k * rongMoi + x) * 4;
        r += tam[i] * w; g += tam[i + 1] * w; b += tam[i + 2] * w; a += tam[i + 3] * w;
      }
      const o = (y * rongMoi + x) * 4;
      ra[o] = kep(Math.round(r)); ra[o + 1] = kep(Math.round(g));
      ra[o + 2] = kep(Math.round(b)); ra[o + 3] = kep(Math.round(a));
    }
  }
  return { width: rongMoi, height: caoMoi, data: ra };
}

/** ── LÀM MỜ GAUSS (tách trục) ────────────────────────────────────────────── */
function nhanGauss(banKinh) {
  const sigma = Math.max(0.5, banKinh / 2);
  const n = Math.max(1, Math.ceil(banKinh));
  const k = new Float32Array(n * 2 + 1);
  let tong = 0;
  for (let i = -n; i <= n; i++) {
    const v = Math.exp(-(i * i) / (2 * sigma * sigma));
    k[i + n] = v; tong += v;
  }
  for (let i = 0; i < k.length; i++) k[i] /= tong;
  return { k, n };
}

function lamMo(anh, banKinh) {
  const { width: W, height: H, data } = anh;
  const { k, n } = nhanGauss(banKinh);
  const tam = new Float32Array(W * H * 3);
  const ra = Buffer.from(data);

  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      let r = 0; let g = 0; let b = 0;
      for (let i = -n; i <= n; i++) {
        const sx = clamp(x + i, 0, W - 1);
        const s = (y * W + sx) * 4;
        const w = k[i + n];
        r += data[s] * w; g += data[s + 1] * w; b += data[s + 2] * w;
      }
      const o = (y * W + x) * 3;
      tam[o] = r; tam[o + 1] = g; tam[o + 2] = b;
    }
  }
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      let r = 0; let g = 0; let b = 0;
      for (let i = -n; i <= n; i++) {
        const sy = clamp(y + i, 0, H - 1);
        const s = (sy * W + x) * 3;
        const w = k[i + n];
        r += tam[s] * w; g += tam[s + 1] * w; b += tam[s + 2] * w;
      }
      const o = (y * W + x) * 4;
      ra[o] = kep(Math.round(r)); ra[o + 1] = kep(Math.round(g)); ra[o + 2] = kep(Math.round(b));
    }
  }
  return { width: W, height: H, data: ra };
}

/**
 * Mặt nạ làm sắc. Ngưỡng là chỗ quan trọng: không có ngưỡng thì nhiễu trên
 * vùng da mịn bị khuếch đại thành lấm tấm, ảnh trông "số hoá" chứ không nét.
 */
function lamSac(anh, { banKinh = 2, cuongDo = 0.8, nguong = 3 } = {}) {
  const mo = lamMo(anh, banKinh);
  const ra = Buffer.from(anh.data);
  let chamTay = 0;
  for (let i = 0; i < ra.length; i += 4) {
    for (let c = 0; c < 3; c++) {
      const goc = anh.data[i + c];
      const hieu = goc - mo.data[i + c];
      if (Math.abs(hieu) < nguong) continue;
      ra[i + c] = kep(Math.round(goc + hieu * cuongDo));
      chamTay++;
    }
  }
  return { anh: { width: anh.width, height: anh.height, data: ra }, diemDaSua: Math.round(chamTay / 3) };
}

/** ── CHỈNH MÀU ───────────────────────────────────────────────────────────── */

/** Nhiệt độ màu → hệ số nhân từng kênh (xấp xỉ Tanner Helland). */
function heSoKelvin(kelvin) {
  const t = clamp(kelvin, 1000, 40000) / 100;
  let r; let g; let b;
  if (t <= 66) { r = 255; g = 99.4708025861 * Math.log(t) - 161.1195681661; } else {
    r = 329.698727446 * Math.pow(t - 60, -0.1332047592);
    g = 288.1221695283 * Math.pow(t - 60, -0.0755148492);
  }
  if (t >= 66) b = 255;
  else if (t <= 19) b = 0;
  else b = 138.5177312231 * Math.log(t - 10) - 305.0447927307;
  return [clamp(r, 0, 255) / 255, clamp(g, 0, 255) / 255, clamp(b, 0, 255) / 255];
}

/**
 * @param {object} t {tuongPhan, baoHoa, doSang, gamma, kelvin, sacThai, canBang{r,g,b}}
 */
function chinhMau(anh, t = {}) {
  const {
    tuongPhan = 1, baoHoa = 1, doSang = 0, gamma = 1,
    kelvin = null, sacThai = 0, canBang = null,
  } = t;
  const ra = Buffer.from(anh.data);

  // Bảng tra gamma — tính một lần, tránh pow cho từng điểm ảnh
  const bangGamma = new Uint8Array(256);
  for (let i = 0; i < 256; i++) bangGamma[i] = kep(Math.round(255 * Math.pow(i / 255, 1 / gamma)));

  const [kr, kg, kb] = kelvin ? heSoKelvin(kelvin) : [1, 1, 1];
  const chuan = kelvin ? heSoKelvin(6500) : [1, 1, 1];
  const wr = kelvin ? kr / chuan[0] : 1;
  const wg = kelvin ? kg / chuan[1] : 1;
  const wb = kelvin ? kb / chuan[2] : 1;

  for (let i = 0; i < ra.length; i += 4) {
    let r = anh.data[i]; let g = anh.data[i + 1]; let b = anh.data[i + 2];

    // 1) Cân bằng trắng theo nhiệt độ + sắc thái (lục ↔ đỏ tía)
    if (kelvin) { r *= wr; g *= wg; b *= wb; }
    if (sacThai) { g *= 1 - sacThai * 0.15; r *= 1 + sacThai * 0.07; b *= 1 + sacThai * 0.07; }

    // 2) Cân bằng từng kênh (lift theo phong cách máy ảnh)
    if (canBang) { r += canBang.r * 255; g += canBang.g * 255; b += canBang.b * 255; }

    // 3) Độ sáng
    if (doSang) { r += doSang * 255; g += doSang * 255; b += doSang * 255; }

    // 4) Tương phản quanh điểm giữa — không phải nhân thẳng, nhân thẳng là
    //    vừa tăng tương phản vừa làm sáng cả ảnh.
    if (tuongPhan !== 1) {
      r = (r - 128) * tuongPhan + 128;
      g = (g - 128) * tuongPhan + 128;
      b = (b - 128) * tuongPhan + 128;
    }

    // 5) Bão hoà quanh ĐỘ SÁNG CẢM NHẬN, giữ nguyên sắc
    if (baoHoa !== 1) {
      const l = luma(r, g, b);
      r = l + (r - l) * baoHoa;
      g = l + (g - l) * baoHoa;
      b = l + (b - l) * baoHoa;
    }

    ra[i] = bangGamma[kep(Math.round(r))];
    ra[i + 1] = bangGamma[kep(Math.round(g))];
    ra[i + 2] = bangGamma[kep(Math.round(b))];
  }
  return { width: anh.width, height: anh.height, data: ra };
}

/** Áp một đường tông (bảng 256 mức cho từng kênh) — dùng cho giả lập phim. */
function apDuongTong(anh, duong) {
  const ra = Buffer.from(anh.data);
  for (let i = 0; i < ra.length; i += 4) {
    ra[i] = duong.r[anh.data[i]];
    ra[i + 1] = duong.g[anh.data[i + 1]];
    ra[i + 2] = duong.b[anh.data[i + 2]];
  }
  return { width: anh.width, height: anh.height, data: ra };
}

/** Dựng bảng 256 mức từ vài điểm neo, nội suy trơn. */
function duongTuDiem(diem) {
  const b = new Uint8Array(256);
  const ds = [...diem].sort((a, x) => a[0] - x[0]);
  for (let i = 0; i < 256; i++) {
    const x = i / 255;
    let j = 0;
    while (j < ds.length - 2 && ds[j + 1][0] < x) j++;
    const [x0, y0] = ds[j];
    const [x1, y1] = ds[j + 1] || ds[j];
    const t = x1 === x0 ? 0 : (x - x0) / (x1 - x0);
    const s = t * t * (3 - 2 * t);                     // vào êm ra êm
    b[i] = kep(Math.round(255 * (y0 + (y1 - y0) * s)));
  }
  return b;
}

/** Hạt phim — tất định theo hạt giống, mạnh hơn ở vùng trung gian như phim thật. */
function themHat(anh, { cuongDo = 0.02, seed = 'gita-grain' } = {}) {
  if (cuongDo <= 0) return saoChep(anh);
  const rnd = seededRandom(seed);
  const ra = Buffer.from(anh.data);
  for (let i = 0; i < ra.length; i += 4) {
    const l = luma(anh.data[i], anh.data[i + 1], anh.data[i + 2]) / 255;
    const manh = 4 * l * (1 - l);                      // đỉnh ở vùng trung gian
    const n = (rnd() - 0.5) * 2 * cuongDo * 255 * manh;
    ra[i] = kep(Math.round(anh.data[i] + n));
    ra[i + 1] = kep(Math.round(anh.data[i + 1] + n));
    ra[i + 2] = kep(Math.round(anh.data[i + 2] + n));
  }
  return { width: anh.width, height: anh.height, data: ra };
}

/** Tối góc — ống kính thật nào cũng có, thiếu nó ảnh trông "sạch quá". */
function toiGoc(anh, { cuongDo = 0.18, banKinh = 0.75 } = {}) {
  if (cuongDo <= 0) return saoChep(anh);
  const { width: W, height: H } = anh;
  const ra = Buffer.from(anh.data);
  const cx = W / 2; const cy = H / 2;
  const max = Math.sqrt(cx * cx + cy * cy);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const d = Math.sqrt((x - cx) ** 2 + (y - cy) ** 2) / max;
      const k = d < banKinh ? 1 : 1 - cuongDo * ((d - banKinh) / (1 - banKinh)) ** 2;
      const i = (y * W + x) * 4;
      ra[i] = kep(Math.round(anh.data[i] * k));
      ra[i + 1] = kep(Math.round(anh.data[i + 1] * k));
      ra[i + 2] = kep(Math.round(anh.data[i + 2] * k));
    }
  }
  return { width: W, height: H, data: ra };
}

/** ── ĐO ─────────────────────────────────────────────────────────────────── */

function bieuDoMuc(anh) {
  const h = new Uint32Array(256);
  for (let i = 0; i < anh.data.length; i += 4) {
    h[Math.round(luma(anh.data[i], anh.data[i + 1], anh.data[i + 2]))]++;
  }
  return h;
}

/**
 * Độ nét đo bằng phương sai của toán tử Laplace — chuẩn thực dụng trong thị
 * giác máy tính: ảnh mờ có ít biến thiên bậc hai nên phương sai thấp.
 *
 * MỘT CẠM BẪY phải xử lý: phương sai Laplace phụ thuộc kích thước. Phóng to
 * một ảnh lên gấp đôi làm con số này tụt khoảng bốn lần dù mắt nhìn thấy
 * đúng bằng đó chi tiết. Nếu không chuẩn hoá thì mọi ảnh sau khi phóng to
 * đều bị chấm là "mờ", và cả tầng phóng to hoá ra tự bắn vào chân mình.
 * Nên phép đo luôn thực hiện trên bản quy về cạnh dài 1024 — một thước đo
 * chung cho mọi độ phân giải.
 */
const CANH_CHUAN = 1024;

function doNet(anh) {
  const canhDai = Math.max(anh.width, anh.height);
  // Quy về cạnh dài chuẩn theo CẢ HAI chiều. Chỉ thu nhỏ ảnh lớn là chưa đủ:
  // so một tấm 320px với chính nó sau khi phóng lên 640px vẫn lệch mười lần,
  // và tầng phóng to sẽ luôn bị chấm là làm ảnh mờ đi.
  const a = Math.abs(canhDai - CANH_CHUAN) / CANH_CHUAN < 0.02
    ? anh
    : doiKichThuoc(anh, Math.max(3, Math.round(anh.width * CANH_CHUAN / canhDai)),
      Math.max(3, Math.round(anh.height * CANH_CHUAN / canhDai)));
  return doNetTho(a);
}

/** Phương sai Laplace thô, đúng trên kích thước đang có. */
function doNetTho(anh) {
  const { width: W, height: H, data } = anh;
  if (W < 3 || H < 3) return 0;
  let tong = 0; let tongBinh = 0; let n = 0;
  for (let y = 1; y < H - 1; y++) {
    for (let x = 1; x < W - 1; x++) {
      const i = (y * W + x) * 4;
      const l = (j) => luma(data[j], data[j + 1], data[j + 2]);
      const v = -4 * l(i) + l(i - 4) + l(i + 4) + l(i - W * 4) + l(i + W * 4);
      tong += v; tongBinh += v * v; n++;
    }
  }
  const tb = tong / n;
  return round(tongBinh / n - tb * tb, 2);
}

function doAnh(anh) {
  const { data } = anh;
  const soDiem = data.length / 4;
  let tongL = 0; let tongL2 = 0;
  let tongR = 0; let tongG = 0; let tongB = 0;
  let tongBaoHoa = 0;
  let chay = 0; let bep = 0;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i]; const g = data[i + 1]; const b = data[i + 2];
    const l = luma(r, g, b);
    tongL += l; tongL2 += l * l;
    tongR += r; tongG += g; tongB += b;
    const max = Math.max(r, g, b); const min = Math.min(r, g, b);
    tongBaoHoa += max === 0 ? 0 : (max - min) / max;
    if (max >= 254) chay++;
    if (max <= 1) bep++;
  }

  const tbL = tongL / soDiem;
  const lech = Math.sqrt(Math.max(0, tongL2 / soDiem - tbL * tbL));
  const h = bieuDoMuc(anh);
  let tich = 0; let p1 = 0; let p99 = 255;
  for (let i = 0; i < 256; i++) {
    tich += h[i];
    if (p1 === 0 && tich >= soDiem * 0.01) p1 = i;
    if (tich >= soDiem * 0.99) { p99 = i; break; }
  }
  const tbR = tongR / soDiem; const tbG = tongG / soDiem; const tbB = tongB / soDiem;

  return {
    rong: anh.width, cao: anh.height,
    megapixel: round((anh.width * anh.height) / 1e6, 2),
    doSang: round(tbL, 1),
    doLechChuan: round(lech, 1),
    dai: p99 - p1,
    p1, p99,
    doBaoHoa: round((tongBaoHoa / soDiem) * 100, 1),
    doNet: doNet(anh),
    chaySang: round((chay / soDiem) * 100, 3),
    bepToi: round((bep / soDiem) * 100, 3),
    canBangTrang: { r: round(tbR, 1), g: round(tbG, 1), b: round(tbB, 1), lechRB: round(tbR - tbB, 1) },
  };
}

module.exports = {
  saoChep, doiKichThuoc, lamMo, lamSac, chinhMau, apDuongTong, duongTuDiem,
  themHat, toiGoc, doAnh, doNet, doNetTho, bieuDoMuc, heSoKelvin, lanczos, luma, CANH_CHUAN,
};
