'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  DỰNG PROMPT — ghép bằng luật, và nói rõ đã thêm gì
 * ═══════════════════════════════════════════════════════════════════════════
 *  Người dùng gõ một câu tiếng Việt. Mô hình tạo ảnh cần một câu tiếng Anh
 *  đầy đủ thông số máy ảnh, ống kính, ánh sáng, bố cục. Khoảng cách đó được
 *  lấp bằng LUẬT, và mọi thứ hệ thống tự thêm đều được liệt kê ra — người
 *  dùng phải biết ảnh mình nhận được đã bị thêm những gì.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { chonBoCuc, BO_CUC } = require('./composition');
const { layMayAnh, layPhim } = require('./profiles');
const { fnv1a } = require('../utils');

const ONG_KINH = {
  '24mm': { ten: '24mm góc siêu rộng', prompt: 'shot on 24mm f/1.4 lens, ultra-wide perspective, dramatic depth', khau: 1.4 },
  '35mm': { ten: '35mm góc rộng', prompt: 'shot on 35mm f/1.4 lens, environmental portrait framing', khau: 1.4 },
  '50mm': { ten: '50mm tiêu chuẩn', prompt: 'shot on 50mm f/1.2 lens, natural human perspective', khau: 1.2 },
  '85mm': { ten: '85mm chân dung', prompt: 'shot on 85mm f/1.2 lens, portrait compression, creamy bokeh, subject isolation', khau: 1.2 },
  '105mm': { ten: '105mm macro', prompt: 'shot on 105mm f/2.8 macro lens, extreme detail, edge-to-edge sharpness', khau: 2.8 },
  '135mm': { ten: '135mm tele', prompt: 'shot on 135mm f/2 lens, telephoto compression, editorial separation', khau: 2.0 },
};

const ANH_SANG = {
  'ba-diem': { ten: 'Ba điểm phòng thu', prompt: 'three-point studio lighting, key fill and rim light, professional setup' },
  rembrandt: { ten: 'Rembrandt', prompt: 'Rembrandt lighting, key light at 45 degrees, triangle of light on the cheek' },
  buom: { ten: 'Cánh bướm', prompt: 'butterfly lighting, key light above and centered, glamour beauty look' },
  chia: { ten: 'Chia đôi', prompt: 'split lighting, half the face lit half in shadow, dramatic contrast' },
  'gio-vang': { ten: 'Giờ vàng', prompt: 'golden hour sunlight, warm backlit rim, long soft shadows' },
  'gio-xanh': { ten: 'Giờ xanh', prompt: 'blue hour twilight, cool ambient light, cinematic mood' },
  'cua-so': { ten: 'Ánh sáng cửa sổ', prompt: 'soft north-facing window light, natural diffusion, painterly falloff' },
  'troi-may': { ten: 'Trời nhiều mây', prompt: 'overcast daylight, soft even light, no harsh shadows' },
};

const CAM_XUC = {
  'dien-anh': 'cinematic mood, filmic tones, wide dynamic range',
  'tap-chi': 'editorial magazine quality, high fashion aesthetic',
  'tai-lieu': 'documentary realism, candid unposed moment, authentic emotion',
  'my-thuat': 'fine art photography, gallery print quality',
  'thuong-mai': 'commercial advertising quality, polished and brand-ready',
  'lang-man': 'romantic atmosphere, soft warm tones, intimate and dreamy',
  tram: 'moody dramatic atmosphere, deep shadows, high contrast',
  sang: 'bright airy high-key atmosphere, cheerful and open',
};

const KY_THUAT = [
  'photorealistic', 'ultra high detail', 'razor sharp focus',
  'professional photography', 'perfect exposure', 'high dynamic range',
];

const CHI_TIET_NGUOI = [
  'natural skin texture with visible pores', 'fine individual hair strands',
  'catchlight in the eyes', 'subsurface scattering on skin',
];

/** Những thứ phải CHẶN — chỗ hay lộ ra "ảnh do máy vẽ" nhất. */
const CAM = [
  'cartoon', 'anime', 'illustration', 'painting', 'drawing', 'sketch',
  '3d render', 'cgi', 'digital art', 'video game render',
  'low quality', 'blurry', 'out of focus', 'pixelated', 'jpeg artifacts',
  'overexposed', 'underexposed', 'oversaturated', 'washed out',
  'deformed', 'bad anatomy', 'extra fingers', 'missing fingers', 'fused limbs',
  'watermark', 'text', 'signature', 'logo', 'frame border',
  'plastic skin', 'waxy skin', 'airbrushed skin', 'doll-like', 'uncanny valley',
  'asymmetric eyes', 'crossed eyes', 'lazy eye',
];

const ONG_KINH_THEO_KIEU = {
  'chan-dung': '85mm', 'thoi-trang': '135mm', 'san-pham': '105mm',
  'phong-canh': '24mm', 'duong-pho': '35mm', 'tai-lieu': '35mm',
  'kien-truc': '24mm', 'my-thuat': '50mm',
};
const ANH_SANG_THEO_KIEU = {
  'chan-dung': 'rembrandt', 'thoi-trang': 'ba-diem', 'san-pham': 'ba-diem',
  'phong-canh': 'gio-vang', 'duong-pho': 'troi-may', 'tai-lieu': 'cua-so',
  'kien-truc': 'gio-xanh', 'my-thuat': 'cua-so',
};

/**
 * @param {string} moTa mô tả của người dùng (tiếng Việt cũng được)
 * @param {object} t {kieuAnh, mayAnh, phim, ongKinh, anhSang, camXuc, boCuc, bien}
 */
function dungPrompt(moTa, t = {}) {
  const {
    kieuAnh = 'chan-dung', mayAnh = 'Fujifilm', phim = 'Khong',
    ongKinh = null, anhSang = null, camXuc = 'dien-anh', boCuc = null, bien = 0,
  } = t;

  const bc = boCuc && BO_CUC[boCuc] ? { id: boCuc, ...BO_CUC[boCuc] } : chonBoCuc(kieuAnh, moTa, bien);
  const okId = ongKinh || ONG_KINH_THEO_KIEU[kieuAnh] || '50mm';
  const asId = anhSang || ANH_SANG_THEO_KIEU[kieuAnh] || 'ba-diem';
  const ok = ONG_KINH[okId] || ONG_KINH['50mm'];
  const as = ANH_SANG[asId] || ANH_SANG['ba-diem'];
  const cx = CAM_XUC[camXuc] || CAM_XUC['dien-anh'];
  const ma = layMayAnh(mayAnh);
  const ph = layPhim(phim);
  const laNguoi = ['chan-dung', 'thoi-trang', 'tai-lieu'].includes(kieuAnh);

  const daThem = [
    { phan: 'bố cục', gia: bc.ten },
    { phan: 'ống kính', gia: ok.ten },
    { phan: 'ánh sáng', gia: as.ten },
    { phan: 'cảm xúc', gia: camXuc },
    { phan: 'máy ảnh', gia: ma.ten },
  ];
  if (ph.diem) daThem.push({ phan: 'giả lập phim', gia: ph.ten });

  const phan = [
    String(moTa).trim(),
    bc.prompt, ok.prompt, as.prompt, cx,
    ma.prompt || null,
    ph.diem ? `${ph.ten} film emulation` : null,
    ...KY_THUAT,
    ...(laNguoi ? CHI_TIET_NGUOI : []),
  ].filter(Boolean);

  const prompt = phan.join(', ');
  return {
    prompt,
    promptCam: CAM.join(', '),
    kieuAnh,
    boCuc: bc.id, boCucTen: bc.ten, chuThe: bc.chuThe,
    ongKinh: okId, ongKinhTen: ok.ten, khauDo: ok.khau,
    anhSang: asId, anhSangTen: as.ten,
    camXuc, mayAnh, mayAnhTen: ma.ten, phim, phimTen: ph.ten,
    daThem,
    soTu: prompt.split(/\s+/).length,
    hatGiong: fnv1a(`${moTa}|${bien}`) >>> 0,
  };
}

module.exports = { dungPrompt, ONG_KINH, ANH_SANG, CAM_XUC, CAM };
