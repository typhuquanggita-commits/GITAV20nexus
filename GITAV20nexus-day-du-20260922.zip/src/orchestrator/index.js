'use strict';
/**
 * ORCHESTRATOR — tách API khỏi thực thi (V20 §2.1).
 * API nhận request → trả runId ngay (<50ms) → worker chạy nền, có checkpoint từng bước.
 * Trạng thái run lưu trong Store nên không mất khi tiến trình khởi động lại (với Redis).
 */

const cfg = require('../config');
const L = require('../logger');
const bus = require('../kernel/eventbus');
const { id: newId, round, ema } = require('../utils');

const RUN_STATES = { PENDING: 'pending', RUNNING: 'running', COMPLETED: 'completed', FAILED: 'failed' };

class Orchestrator {
  constructor({ store, queue, cache, adaptiveRouter, guardrails, constitution, heart, safePrompt, moe, llm, scheduler, eventStore, otel }) {
    this.store = store;
    this.queue = queue;
    this.cache = cache;
    this.router = adaptiveRouter;
    this.guardrails = guardrails;
    this.constitution = constitution;
    this.heart = heart;
    this.safePrompt = safePrompt;
    this.moe = moe;
    this.llm = llm;
    this.scheduler = scheduler;
    this.eventStore = eventStore;
    this.otel = otel;
    this.stats = { created: 0, completed: 0, failed: 0, steps: 0, avgRunMs: 0 };
  }

  async createRun(request) {
    const runId = newId('RUN');
    const run = {
      id: runId,
      input: request.input,
      mode: request.mode || 'sync',
      taskType: request.taskType || 'vietnamese',
      tenantId: request.tenantId || null,
      state: RUN_STATES.PENDING,
      createdAt: Date.now(),
      steps: [],
      result: null,
      error: null,
    };
    await this._persist(run);
    this.stats.created++;
    this.queue.enqueue('orchestrator:run', { runId }, { priority: request.priority || 'normal' });
    return { ok: true, runId, state: run.state };
  }

  async getRun(runId) {
    const run = await this._load(runId);
    if (!run) return { ok: false, error: 'RUN_NOT_FOUND' };
    return {
      ok: true,
      id: run.id,
      state: run.state,
      mode: run.mode,
      steps: run.steps.map((s) => ({ type: s.type, ok: s.ok, ms: s.ms })),
      result: run.result,
      error: run.error,
      createdAt: run.createdAt,
      durationMs: run.completedAt ? run.completedAt - run.createdAt : null,
    };
  }

  async executeRun(runId) {
    const t0 = Date.now();
    const run = await this._load(runId);
    if (!run) return { ok: false, error: 'RUN_NOT_FOUND' };
    if (run.state !== RUN_STATES.PENDING) return { ok: false, error: 'RUN_ALREADY_STARTED' };

    run.state = RUN_STATES.RUNNING;
    run.startedAt = Date.now();
    await this._persist(run);

    try {
      const out = await this._steps(run);
      run.state = out.ok ? RUN_STATES.COMPLETED : RUN_STATES.FAILED;
      run.result = out.output ?? null;
      run.error = out.error ?? null;
      run.completedAt = Date.now();
      await this._persist(run);

      if (out.ok) { this.stats.completed++; this.stats.avgRunMs = round(ema(this.stats.avgRunMs, Date.now() - t0), 1); }
      else this.stats.failed++;

      await this.eventStore.append('orchestrator', run.state, {
        runId, mode: run.mode, ms: Date.now() - t0, ok: out.ok,
      }).catch(() => {});
      bus.safeEmit('orchestrator:run_done', { runId, ok: out.ok, ms: Date.now() - t0 });
      return { ok: out.ok, runId, output: out.output, error: out.error };
    } catch (e) {
      run.state = RUN_STATES.FAILED;
      run.error = e.message;
      run.completedAt = Date.now();
      await this._persist(run);
      this.stats.failed++;
      return { ok: false, runId, error: e.message };
    }
  }

  async _steps(run) {
    await this._step(run, 'guardrail', async () => {
      const c = this.guardrails.checkInput(run.input);
      if (!c.ok) throw new Error(`GUARDRAIL_BLOCK:${c.reason}`);
      return { ok: true };
    });

    await this._step(run, 'constitution', async () => {
      const c = this.constitution.validate('llm_call', { injectionDetected: false });
      if (!c.ok) throw new Error(`CONSTITUTION_BLOCK:${c.violations[0]?.article}`);
      return { ok: true };
    });

    await this._step(run, 'heart_input', async () => {
      const c = this.heart.validateInput(run.input);
      if (!c.ok) throw new Error(`HEART_BLOCK:${c.axiom}`);
      return { ok: true };
    });

    const cached = await this._step(run, 'cache_lookup', async () => {
      const hit = await this.cache.get(run.input);
      return { ok: true, hit: !!hit, value: hit?.value ?? null, category: hit?.category };
    });
    if (cached.hit) return { ok: true, output: cached.value, cached: true };

    // Chế độ thực thi — TƯỜNG MINH
    if (run.mode === 'entropy-moe') {
      const r = await this._step(run, 'moe_route', async () => {
        const res = await this.moe.route(run.input);
        if (!res.ok) throw new Error(res.error || 'MOE_FAILED');
        return { ok: true, output: res.output, k: res.k, entropy: res.entropy };
      });
      await this.cache.set(run.input, r.output).catch(() => {});
      return { ok: true, output: r.output };
    }

    if (run.mode === 'team') {
      const r = await this._step(run, 'team_run', async () => {
        const res = await this.scheduler.team({ type: run.taskType, input: run.input });
        if (!res.ok) throw new Error(res.error || 'TEAM_FAILED');
        return { ok: true, output: res.output, review: res.review };
      });
      return { ok: true, output: r.output };
    }

    // Mặc định: giao cho một agent qua scheduler (đúng khối, đúng cấp bậc)
    const r = await this._step(run, 'agent_dispatch', async () => {
      const res = await this.scheduler.dispatch({
        type: run.taskType, input: run.input, requester: run.tenantId,
        dedupeKey: `${run.taskType}:${run.id}`,
      });
      if (!res.ok) throw new Error(res.error || 'DISPATCH_FAILED');
      return { ok: true, output: res.output, agentId: res.agentId, provider: res.provider };
    });

    return { ok: true, output: r.output };
  }

  async _step(run, type, fn) {
    const t0 = Date.now();
    try {
      const r = await fn();
      run.steps.push({ type, ok: true, ms: Date.now() - t0, at: Date.now() });
      this.stats.steps++;
      await this._persist(run);
      return r;
    } catch (e) {
      run.steps.push({ type, ok: false, ms: Date.now() - t0, error: e.message, at: Date.now() });
      await this._persist(run);
      throw e;
    }
  }

  async _persist(run) {
    await this.store.set(`orch:run:${run.id}`, JSON.stringify(run), cfg.RUN_TTL_SEC);
  }

  async _load(runId) {
    const raw = await this.store.get(`orch:run:${runId}`);
    if (!raw) return null;
    try { return JSON.parse(raw); } catch { return null; }
  }

  startWorker(concurrency = 20) {
    this.queue.registerWorker('orchestrator:run', (job) => this.executeRun(job.data.runId), { concurrency });
    L.ok(`Orchestrator: worker sẵn sàng (concurrency=${concurrency})`);
    return this;
  }

  status() {
    return { ...this.stats, avgRunMs: Math.round(this.stats.avgRunMs) };
  }
}

module.exports = Orchestrator;
module.exports.RUN_STATES = RUN_STATES;
