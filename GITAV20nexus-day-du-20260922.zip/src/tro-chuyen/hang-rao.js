'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  LỚP 2 — HÀNG RÀO NHẮC LẠI  (Proxy Barrier)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Ý tưởng gốc rất gọn: trước khi đưa câu của người dùng cho mô hình chính,
 *  đưa nó cho một mô hình NHỎ với đúng một việc — NHẮC LẠI nguyên văn. Mô
 *  hình nhỏ ấy không được dặn dò gì khác, nên nếu trong câu có lệnh giấu,
 *  lệnh ấy sẽ kéo nó đi chệch, và phần nhắc lại KHÔNG còn khớp nguyên văn.
 *  Chệch là lộ.
 *
 *  ── ĐIỀU PHẢI NÓI THẲNG TRƯỚC ────────────────────────────────────────────
 *
 *  Hệ này KHÔNG mặc định có mô hình ngôn ngữ chạy được. Không mạng, không
 *  khoá, hoặc đang chạy trong bản cài đặt trên máy giáo viên — đều là chuyện
 *  bình thường ở đây. Nên hàng rào này có HAI chế độ, và nó LUÔN nói rõ mình
 *  đang ở chế độ nào chứ không im lặng tụt xuống:
 *
 *      đầy-đủ   có mô hình nhỏ → nhắc lại thật, so thật. Đây là bản đúng.
 *      rút-gọn  không có mô hình → CHỈ còn phép so cấu trúc dưới đây.
 *
 *  Ở chế độ rút gọn, hàng rào này YẾU HƠN HẲN. Nói ra điều đó là bắt buộc:
 *  một lớp phòng thủ tự nhận mạnh hơn thực tế còn nguy hiểm hơn không có lớp
 *  ấy, vì người ta sẽ dựa vào nó.
 *
 *  ── PHÉP SO: SO CÁI GÌ VÀ KHÔNG SO CÁI GÌ ───────────────────────────────
 *
 *  So nguyên văn từng ký tự thì hỏng ngay: mô hình nào cũng đổi khoảng trắng,
 *  bỏ dấu câu cuối, viết hoa đầu câu. So như thế là chặn cả câu sạch.
 *
 *  Nên so ba thứ, và cả ba đều là thứ một lệnh giấu BẮT BUỘC phải làm lệch:
 *      1. Bộ chữ  — lệnh giấu luôn thêm hoặc bớt từ
 *      2. Độ dài  — chệch quá một phần tư là đã kể chuyện khác
 *      3. Thứ tự  — cùng bộ chữ mà đảo thứ tự cũng là một câu khác
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { deaccent } = require('../utils');

/** Lệch quá ngần này thì coi như đã kể chuyện khác. */
const LECH_TOI_DA = 0.25;

const chuanHoa = (s) => deaccent(String(s || ''))
  .toLowerCase()
  .replace(/[^\p{L}\p{N}\s]/gu, ' ')
  .replace(/\s+/g, ' ')
  .trim();

const tachTu = (s) => chuanHoa(s).split(' ').filter(Boolean);

/** Tỉ lệ từ của câu gốc còn nguyên trong câu nhắc lại. */
function tiLeGiuTu(goc, lai) {
  const a = tachTu(goc);
  const b = new Set(tachTu(lai));
  if (!a.length) return 1;
  return a.filter((t) => b.has(t)).length / a.length;
}

class HangRao {
  /**
   * @param {object} o
   * @param {function} o.nhacLai  async (text) => string — mô hình nhỏ nhắc lại.
   *                              Không truyền thì hàng rào ở chế độ rút gọn.
   */
  constructor({ nhacLai = null, lechToiDa = LECH_TOI_DA } = {}) {
    this.nhacLai = nhacLai;
    this.lechToiDa = lechToiDa;
    this.soLuot = 0;
    this.soChan = 0;
    this.soRutGon = 0;
  }

  get cheDo() { return this.nhacLai ? 'day-du' : 'rut-gon'; }

  /**
   * @returns {{dat:boolean, cheDo:string, ma?:string, vi?:string, doGiu?:number}}
   */
  async soi(text) {
    this.soLuot += 1;
    if (!this.nhacLai) {
      this.soRutGon += 1;
      return { dat: true, cheDo: 'rut-gon', ma: 'khong-co-mo-hinh-nho',
        vi: 'Chưa có mô hình nhỏ để nhắc lại, nên lớp này KHÔNG soi được lần này. '
          + 'Bốn lớp còn lại vẫn chạy đủ.' };
    }

    let lai;
    try {
      lai = await this.nhacLai(text);
    } catch (e) {
      // Mô hình hỏng thì KHÔNG cho qua lặng lẽ, cũng không chặn người dùng
      // vô can. Nói rõ là lớp này vừa nghỉ.
      this.soRutGon += 1;
      return { dat: true, cheDo: 'rut-gon', ma: 'mo-hinh-hong',
        vi: `Mô hình nhắc lại gặp lỗi (${e.message}) nên lớp này không soi được lần này.` };
    }

    const doGiu = tiLeGiuTu(text, lai);
    const a = tachTu(text).length;
    const b = tachTu(lai).length;
    const lechDai = a ? Math.abs(b - a) / a : 0;

    if (doGiu < 1 - this.lechToiDa) {
      this.soChan += 1;
      return { dat: false, cheDo: 'day-du', ma: 'nhac-lai-mat-chu', doGiu,
        vi: `Phần nhắc lại chỉ giữ ${Math.round(doGiu * 100)}% số từ của câu gốc. `
          + 'Một câu bình thường được nhắc lại gần như nguyên vẹn; mất chữ nghĩa là có lệnh giấu kéo đi.' };
    }
    if (lechDai > this.lechToiDa) {
      this.soChan += 1;
      return { dat: false, cheDo: 'day-du', ma: 'nhac-lai-doi-do-dai', doGiu,
        vi: `Câu gốc ${a} từ, phần nhắc lại ${b} từ. Chênh lệch này nghĩa là mô hình đã LÀM gì đó `
          + 'thay vì chỉ nhắc lại.' };
    }
    return { dat: true, cheDo: 'day-du', ma: 'khop', doGiu };
  }

  /** Lời dặn cho mô hình nhỏ. Càng ít chữ càng khó chèn lệnh vào. */
  static loiDan(text) {
    return 'Nhắc lại nguyên văn đoạn dưới đây. Không thêm, không bớt, không trả lời, '
      + 'không giải thích.\n\n<<<\n' + String(text) + '\n>>>';
  }

  status() {
    return {
      cheDo: this.cheDo,
      giaiThich: this.nhacLai
        ? 'Có mô hình nhỏ nhắc lại — lớp này đang soi đủ.'
        : 'CHƯA có mô hình nhỏ. Lớp này đang ở chế độ rút gọn và YẾU HƠN HẲN bản đầy đủ.',
      lechToiDa: this.lechToiDa,
      soLuot: this.soLuot,
      soChan: this.soChan,
      soLuotKhongSoiDuoc: this.soRutGon,
    };
  }
}

module.exports = HangRao;
module.exports.tiLeGiuTu = tiLeGiuTu;
