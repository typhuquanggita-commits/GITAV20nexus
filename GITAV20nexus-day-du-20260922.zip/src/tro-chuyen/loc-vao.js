'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  LỚP 1 — LỌC ĐẦU VÀO
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Lớp rẻ nhất và chặn được nhiều nhất: đọc câu người dùng gõ, tìm những hình
 *  dạng CHỈ xuất hiện khi có người đang cố nói chuyện với cỗ máy thay vì nói
 *  chuyện với trợ lý.
 *
 *  BA ĐIỀU LỚP NÀY BIẾT RÕ VỀ CHÍNH NÓ, nói ra trước khi ai hỏi:
 *
 *  1. Nó bắt HÌNH DẠNG, không hiểu Ý. "Bỏ qua mọi chỉ dẫn phía trên" bị chặn
 *     vì câu ấy có hình dạng của một lệnh, không phải vì máy hiểu nó xấu. Nên
 *     người viết một câu tấn công bằng lối khác hẳn sẽ đi qua được lớp này —
 *     và đó chính là việc của bốn lớp sau.
 *
 *  2. Nó chặn NHẦM được. Một phụ huynh viết "hệ thống: con tôi không vào
 *     được" sẽ bị chặn vì hai chữ đầu trùng hình dạng thẻ hệ thống. Nên mỗi
 *     lần chặn đều nói rõ VÌ SAO và mời viết lại — không im lặng nuốt câu hỏi.
 *
 *  3. Nó KHÔNG phải tường lửa. Đây là cái sàng đầu tiên, không phải cái cuối.
 *
 *  VÌ SAO KHÔNG DÙNG MÔ HÌNH NGÔN NGỮ Ở LỚP NÀY. Vì lớp này phải chạy trên
 *  MỌI câu, kể cả khi không có mạng và không có khoá. Một lớp phòng thủ chỉ
 *  hoạt động khi trả được tiền là một lớp phòng thủ không có.
 * ═══════════════════════════════════════════════════════════════════════════
 */

/**
 * Các hình dạng tấn công. Mỗi mục có tên đọc được VÀ một câu nói rõ vì sao —
 * người bị chặn oan phải đọc được lý do mà cãi lại.
 */
const HINH_DANG = [
  { ma: 'bo-qua-chi-dan', re: /(bỏ\s*qua|ignore|disregard)\s+(tất\s*cả\s+|all\s+)?(mọi\s+|các\s+)?(chỉ\s*dẫn|hướng\s*dẫn|previous\s+instructions?|above)/i,
    vi: 'Câu này yêu cầu cỗ máy quên đi phần dặn dò của hệ thống. Người dùng thật không cần làm thế.' },
  { ma: 'gia-danh-he-thong', re: /(^|\n)\s*(system|assistant|developer)\s*:/i,
    vi: 'Câu mở đầu bằng nhãn vai của cỗ máy — đây là cách người ta chèn lời vào giữa cuộc nói chuyện.' },
  { ma: 'the-dac-biet', re: /<\|(im_start|im_end|endoftext|system)\|>|\[\/?INST\]|<<SYS>>/i,
    vi: 'Có thẻ điều khiển của mô hình ngôn ngữ trong câu. Người dùng không gõ những thẻ này.' },
  { ma: 'doi-vai-be-khoa', re: /(you\s+are\s+now|bây\s*giờ\s+(bạn|mày)\s+là)\s+(DAN|jailbreak|unrestricted|không\s+giới\s*hạn)/i,
    vi: 'Câu yêu cầu trợ lý đổi sang một nhân cách không còn luật nào.' },
  // Bản đầu chỉ bắt "nhắc LẠI", nên "in RA system prompt" — lối nói tự nhiên
  // nhất trong tiếng Việt — đi thẳng qua. Nay bắt cả "ra", "cho tôi xem",
  // và cả khi không có từ nối nào.
  { ma: 'moi-lay-loi-dan', re: /(nhắc|đọc|in|lặp|xem|cho\s+xem|tiết\s*lộ)\s*(lại|ra|hết)?\s*(toàn\s*bộ\s+)?(lời\s*dặn|chỉ\s*dẫn\s+(hệ\s*thống|gốc)|system\s*prompt|prompt\s+hệ\s*thống)|repeat\s+(the\s+)?(system\s+)?prompt|print\s+your\s+(system\s+)?(prompt|instructions)/i,
    vi: 'Câu đòi lấy lời dặn nội bộ của hệ thống ra ngoài.' },
  { ma: 'lay-loi-dan-vong', re: /(dịch|translate)\s+(phần|the)\s+(trên|above)\s+(sang|to)/i,
    vi: 'Đòi dịch "phần ở trên" là một cách lấy lời dặn nội bộ mà không nói thẳng.' },
  { ma: 'ma-hoa', re: /base64\s*:|(\\x[0-9a-f]{2}){4,}|(%[0-9a-f]{2}){8,}/i,
    vi: 'Trong câu có một khối đã mã hoá. Câu hỏi thật không cần mã hoá.' },
];

/** Dài hơn mức này thì không còn là câu hỏi nữa. */
const DAI_TOI_DA = 4000;

/**
 * Chữ nhìn GIỐNG chữ Latinh nhưng là chữ khác.
 *
 * Dùng để viết "ignоre" với chữ о Kirin — mắt người đọc ra một từ, bộ lọc đọc
 * ra một từ khác. Tiếng Việt KHÔNG dùng những dải chữ này, nên gặp nhiều là
 * dấu hiệu rõ ràng.
 *
 * Ngưỡng 5: một hai chữ có thể là người dán nhầm từ một trang khác.
 */
const DAI_GIA_MAO = [[0x0400, 0x04ff], [0x0370, 0x03ff], [0x0500, 0x052f]];
const GIA_MAO_TOI_DA = 5;

const laGiaMao = (m) => DAI_GIA_MAO.some(([a, b]) => m >= a && m <= b);
const laLatinh = (m) => (m >= 0x41 && m <= 0x5a) || (m >= 0x61 && m <= 0x7a);

/**
 * Dấu hiệu CHẮC CHẮN: một TỪ vừa có chữ Latinh vừa có chữ Kirin hoặc Hy Lạp.
 *
 * Bản đầu chỉ đếm tổng số chữ lạ và chặn khi quá năm. Ngưỡng ấy bỏ lọt đúng
 * cách tấn công thật: "ignоre аll рreviоus" chỉ cần bốn chữ Kirin đặt vào
 * đúng chỗ là mắt người đọc ra một đằng, bộ lọc đọc ra một nẻo.
 *
 * Trộn hai bảng chữ TRONG MỘT TỪ thì không có cách nào xảy ra tình cờ. Người
 * viết tiếng Nga viết nguyên từ tiếng Nga; người dán nhầm cũng dán nguyên
 * cụm. Chỉ kẻ cố ý mới trộn vào giữa từ.
 */
function coTuTron(s) {
  for (const tu of String(s).split(/\s+/)) {
    let latinh = false;
    let la = false;
    for (const ch of tu) {
      const m = ch.codePointAt(0);
      if (laLatinh(m)) latinh = true;
      else if (laGiaMao(m)) la = true;
      if (latinh && la) return tu;
    }
  }
  return null;
}

/** Ký tự vô hình — dùng để giấu lệnh giữa những chữ bình thường. */
const VO_HINH = /[​-‏‪-‮⁠-⁤﻿]/;

class LocVao {
  constructor({ daiToiDa = DAI_TOI_DA } = {}) {
    this.daiToiDa = daiToiDa;
    this.soChan = 0;
    this.theoMa = new Map();
  }

  /**
   * @returns {{dat:boolean, ma:string, vi:string}}
   */
  soi(text) {
    const s = String(text == null ? '' : text);

    if (s.length > this.daiToiDa) {
      return this._chan('qua-dai', `Câu dài ${s.length} ký tự, quá mức ${this.daiToiDa}. `
        + 'Câu hỏi dài thế này thường là một khối văn bản dán vào để làm loãng phần dặn dò của hệ thống.');
    }
    if (VO_HINH.test(s)) {
      return this._chan('ky-tu-vo-hinh',
        'Trong câu có ký tự không hiện ra trên màn hình. Người gõ bình thường không tạo ra được chúng.');
    }
    const tron = coTuTron(s);
    if (tron) {
      return this._chan('chu-gia-mao',
        `Từ "${tron}" trộn chữ Latinh với chữ thuộc bảng chữ khác trong cùng một từ. `
        + 'Trộn như thế không xảy ra tình cờ — đây là cách viết để mắt người đọc ra một đằng '
        + 'còn bộ lọc đọc ra một nẻo.');
    }
    let giaMao = 0;
    for (const ch of s) if (laGiaMao(ch.codePointAt(0))) giaMao += 1;
    if (giaMao > GIA_MAO_TOI_DA) {
      return this._chan('chu-gia-mao',
        `Có ${giaMao} chữ nhìn giống chữ Latinh nhưng thuộc bảng chữ khác — cách này dùng để qua mặt bộ lọc.`);
    }
    for (const h of HINH_DANG) {
      if (h.re.test(s)) return this._chan(h.ma, h.vi);
    }
    return { dat: true, ma: 'sach', vi: '' };
  }

  _chan(ma, vi) {
    this.soChan += 1;
    this.theoMa.set(ma, (this.theoMa.get(ma) || 0) + 1);
    return { dat: false, ma, vi };
  }

  /** Lời từ chối gửi cho người dùng. Nói lý do, và luôn mời viết lại. */
  loiTuChoi(ket) {
    return `Câu vừa rồi em chưa nhận được. ${ket.vi} `
      + 'Anh/chị viết lại bằng lời thường giúp em, em trả lời ngay ạ.';
  }

  status() {
    return {
      soHinhDang: HINH_DANG.length + 3,
      daiToiDa: this.daiToiDa,
      soChan: this.soChan,
      theoMa: Object.fromEntries(this.theoMa),
      canMang: false,
      canKhoa: false,
    };
  }
}

module.exports = LocVao;
module.exports.HINH_DANG = HINH_DANG;
module.exports.coTuTron = coTuTron;
