'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  LẬP KẾ HOẠCH TRƯỚC, LÀM SAU
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Một trợ lý vừa nghĩ vừa làm thì không ai canh được nó: mỗi bước mới sinh
 *  ra từ kết quả bước trước, nên không có gì để đối chiếu. Lật lại thứ tự thì
 *  canh được: KHAI kế hoạch ra trước, rồi mới chạy, rồi so đường đi thật với
 *  kế hoạch ấy.
 *
 *  Đây là điều kiện để lính gác ở lớp 5 làm việc được. Không có kế hoạch ghi
 *  trước thì lính gác không có gì để so, và lớp 5 chỉ còn là một cái tên.
 *
 *  ── ĐỌC Ý BẰNG BẢNG TỪ, KHÔNG BẰNG MÔ HÌNH ──────────────────────────────
 *
 *  Cùng lý do với khiên việc: tất định, đọc được, và chạy được khi không có
 *  mạng. Bảng từ dưới đây SAI ĐƯỢC — người hỏi một câu lạ sẽ rơi vào "hỏi
 *  chung". Và đó là chỗ rơi ĐÚNG: việc hẹp nhất, công cụ ít nhất, không chạm
 *  dữ liệu riêng của ai.
 *
 *  Đọc sai mà rơi vào chỗ chặt là đọc sai an toàn. Đọc sai mà rơi vào chỗ
 *  rộng mới là lỗ thủng.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { deaccent } = require('../utils');
const { BANG_VIEC } = require('./khien-viec');

/**
 * Từ khoá của từng việc. Viết không dấu vì câu người dùng gõ thường thiếu dấu.
 * Mỗi mục có TRỌNG SỐ: từ càng riêng của việc ấy thì càng nặng.
 */
const TU_KHOA = {
  'hoi-tien-do-con': [['con toi', 3], ['con em', 3], ['be nha', 3], ['chau nha', 3], ['con minh', 3],
    ['tien do cua con', 4], ['con hoc', 2]],
  'hoi-tien-do-minh': [['tien do', 2], ['em hoc den dau', 3], ['minh hoc', 2], ['da lam bao nhieu', 3],
    ['diem cua em', 3], ['bai em lam', 3]],
  'hoi-lop': [['lop toi', 3], ['lop minh day', 4], ['hoc sinh lop', 3], ['si so', 3], ['ca lop', 2]],
  'hoi-chuong-trinh': [['chuong trinh', 3], ['dang bai', 3], ['hoc gi', 2], ['kien thuc', 2],
    ['so do tu duy', 3], ['lo trinh hoc', 3], ['can biet gi truoc', 4]],
  'xin-goi-y-hoc': [['nen hoc gi', 4], ['hoc gi tiep', 4], ['goi y', 2], ['tiep theo hoc', 3]],
  'bao-truc-trac': [['khong vao duoc', 4], ['loi', 2], ['bi loi', 3], ['khong chay', 3],
    ['hong', 2], ['truc trac', 3], ['khong mo duoc', 3]],
  'hoi-hoc-phi': [['hoc phi', 4], ['bao nhieu tien', 4], ['gia', 2], ['goi cuoc', 3], ['dong tien', 3]],
};

/** Việc rơi vào khi không từ nào khớp. Hẹp nhất, không chạm dữ liệu riêng. */
const VIEC_MAC_DINH = 'hoi-chung';

/**
 * Đọc ý người dùng.
 *
 * @returns {{viec:string, diem:number, tuTrung:string[], chacChan:boolean}}
 */
function docY(cauHoi) {
  const s = ` ${deaccent(String(cauHoi || '')).toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, ' ').replace(/\s+/g, ' ')} `;
  let tot = { viec: VIEC_MAC_DINH, diem: 0, tuTrung: [] };
  for (const [viec, tu] of Object.entries(TU_KHOA)) {
    let diem = 0;
    const trung = [];
    for (const [t, w] of tu) {
      if (s.includes(` ${t} `) || s.includes(`${t} `) || s.includes(` ${t}`)) { diem += w; trung.push(t); }
    }
    if (diem > tot.diem) tot = { viec, diem, tuTrung: trung };
  }
  // Điểm thấp thì KHÔNG đoán bừa. Ba là ngưỡng của đúng một từ riêng.
  if (tot.diem < 3) return { viec: VIEC_MAC_DINH, diem: tot.diem, tuTrung: tot.tuTrung, chacChan: false };
  return { ...tot, chacChan: true };
}

/**
 * Dựng kế hoạch. Kế hoạch KHAI ĐỦ công cụ sẽ gọi, trước khi gọi cái nào.
 *
 * @returns {{ok:boolean, viec:string, congCu:string[], chamAi:string, buoc:Array, canNguoiDuyet:boolean}}
 */
function dungKeHoach(cauHoi, { vai = 'GUEST' } = {}) {
  const y = docY(cauHoi);
  const v = BANG_VIEC[y.viec];
  if (!v) {
    return { ok: false, loi: 'VIEC_CHUA_KHAI', viec: y.viec };
  }

  // Thứ tự bước: đọc trước, ghi sau. Việc ghi luôn nằm cuối và luôn là chỗ
  // dừng lại hỏi người — một trợ lý không tự ghi vào sổ nhà rồi báo sau.
  const doc = v.congCu.filter((c) => !c.startsWith('ghi-'));
  const ghi = v.congCu.filter((c) => c.startsWith('ghi-'));
  const congCu = [...doc, ...ghi];

  const buoc = congCu.map((c, i) => ({
    id: `b${i + 1}`,
    congCu: c,
    canTruoc: i === 0 ? [] : [`b${i}`],
    dungLaiHoiNguoi: c.startsWith('ghi-'),
  }));

  return {
    ok: true,
    viec: y.viec,
    tenViec: v.ten,
    doDocY: y.diem,
    docYChacChan: y.chacChan,
    tuTrung: y.tuTrung,
    congCu,
    chamAi: v.chamAi,
    vaiToiThieu: v.vaiToiThieu,
    buoc,
    canNguoiDuyet: ghi.length > 0,
    // Thứ tự chạy, tính bằng phép sắp theo phụ thuộc. Ở đây chuỗi thẳng nên
    // kết quả trùng thứ tự khai, nhưng phép sắp vẫn chạy thật để khi có bước
    // rẽ nhánh thì không phải viết lại.
    thuTuChay: sapTheoPhuThuoc(buoc),
    chamDung: buoc.filter((b) => b.dungLaiHoiNguoi).map((b) => b.id),
  };
}

/** Sắp các bước theo phụ thuộc. Gặp vòng thì nói ra chứ không chạy vòng quanh. */
function sapTheoPhuThuoc(buoc) {
  const chiMuc = new Map(buoc.map((b) => [b.id, b]));
  const xong = new Set();
  const dangDi = new Set();
  const ra = [];
  const vong = [];

  const di = (id) => {
    if (xong.has(id)) return;
    if (dangDi.has(id)) { vong.push(id); return; }
    dangDi.add(id);
    const b = chiMuc.get(id);
    if (b) for (const t of b.canTruoc) di(t);
    dangDi.delete(id);
    xong.add(id);
    ra.push(id);
  };
  for (const b of buoc) di(b.id);
  return vong.length ? { ok: false, vong } : ra;
}

module.exports = { docY, dungKeHoach, sapTheoPhuThuoc, TU_KHOA, VIEC_MAC_DINH };
