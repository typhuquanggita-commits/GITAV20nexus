# Tiến Trình Thực Hiện — GITAmath Web App

> 12 sprint × 2 tuần = 24 tuần. Mỗi sprint có **cổng kiểm** (gate): không qua thì không sang sprint sau.

---

## Nguyên tắc chi phối

1. **Lát cắt dọc, không lát cắt ngang.** Mỗi sprint phải cho ra một luồng người dùng chạy được end-to-end, không phải "xong tầng database".
2. **Không có tính năng nào được merge nếu chưa chạy thật trên staging.** Đây là bài học trực tiếp từ 24 giờ vừa rồi: 232 file, 0 lần chạy.
3. **Đóng băng kiến trúc 6 tháng.** Ý tưởng mới → `docs/BACKLOG.md`, không vào code.
4. **Nội dung đi song song code, không đi sau.** Giáo viên soạn item từ tuần 1.

---

## GIAI ĐOẠN 0 — 48 giờ tới (trước Sprint 1)

Không viết code. Chỉ ra quyết định.

| # | Việc | Ai | Đầu ra |
|---|---|---|---|
| 1 | Đọc và duyệt [`01-HE-THONG-GITAMATH.md`](./01-HE-THONG-GITAMATH.md) | Chủ dự án | Xác nhận bản đọc đúng ý đồ |
| 2 | **Chốt kiến trúc**: chọn Next.js + Postgres, bỏ 4 kiến trúc cũ | Chủ dự án | Quyết định bằng văn bản, không đảo lại |
| 3 | Chốt **người dùng số 1**: hệ nào (SAT? HSA? Toán lớp 9?), lớp mấy, thi tháng nào | Chủ dự án | 1 đoạn mô tả |
| 4 | Chốt **ai soạn nội dung** và ngân sách cho việc đó | Chủ dự án | Tên người + số tiền/tháng |
| 5 | Mở tài khoản: Vercel, Neon (hoặc Supabase), Google AI Studio, Groq | Kỹ thuật | Biến môi trường trong `.env.local` |
| 6 | Dọn repo: template Veo 3 Gallery hiện tại không liên quan GITAmath | Kỹ thuật | Quyết định giữ/xoá |

**Cổng G0:** trả lời được 3 câu hỏi cuối §7 của tài liệu 01. Chưa trả lời được thì chưa bắt đầu.

---

## GIAI ĐOẠN 1 — Nền móng (Sprint 1–2, tuần 1–4)

### Sprint 1 — Khung chạy được
- Khởi tạo Next.js 15 + TS strict + Tailwind + shadcn
- Drizzle + Neon, migration đầu tiên: `users`, `sessions`, `audit_log`
- Auth.js: đăng ký / đăng nhập / quên mật khẩu (Argon2id)
- `kernel/rbac.ts` (14 vai trò), `kernel/constitution.ts` (50 điều), `kernel/math-notation.ts` (port từ bản A + test)
- CI: typecheck → lint → vitest → migrate → deploy preview
- Deploy staging

**Cổng G1:** người thật đăng ký được trên URL staging, vai trò được lưu, hành động ghi vào `audit_log`. Có ảnh chụp màn hình + link.

### Sprint 2 — Lát cắt dọc đầu tiên
- Bảng `subjects`, `skills`, `items`, `mastery`, `responses`
- Seed 12 lớp Toán từ `CONFIG.TOPICS` + **50 item thật soạn tay** cho 1 kỹ năng
- Trang `/hoc`: lấy bài → hiển thị KaTeX → trả lời → chấm → xem lời giải từng bước
- Cập nhật `mastery` bằng BKT
- PWA shell + mobile layout

**Cổng G2:** một học sinh thật làm 20 bài liên tiếp trên điện thoại, `p_known` thay đổi đúng hướng. **Đây là lần đầu tiên GITAmath thực sự tồn tại.**

---

## GIAI ĐOẠN 2 — Kho nội dung (Sprint 3–4, tuần 5–8)

Đây là giai đoạn quyết định sống còn của sản phẩm.

### Sprint 3 — Công cụ soạn & duyệt
- Admin `/admin/noi-dung`: soạn item (editor LaTeX xem trước bằng KaTeX), gán skill/tier/difficulty
- Import CSV/JSON hàng loạt, tự tính `content_hash` chống trùng
- Quy trình duyệt: `draft → review → published` + bảng `item_reviews`
- Kiểm tự động khi lưu: `MathNotation.validate()` + kiểm cấu trúc đáp án

### Sprint 4 — Pipeline sinh & kiểm định
- `kernel/llm.ts`: gateway đa provider + `safeMetaPrompt` + category cache + theo dõi chi phí
- Job `generate_variants`: từ item gốc sinh 5–10 biến thể (đổi số/ngữ cảnh, giữ kỹ năng)
- Job `verify_item`: model **khác** giải lại, đối chiếu đáp án; lệch → đẩy sang `review`
- Bảng điều khiển: số item theo trạng thái, độ phủ theo skill

**Cổng G4:** **1.000 item `published`**, phủ ≥ 80% kỹ năng của track đầu tiên, ≥ 95% qua kiểm định tự động, 100% có lời giải LaTeX. Kèm báo cáo độ phủ.

> Nếu không qua được G4, mọi thứ phía sau là vô nghĩa. Dừng lại và giải quyết nội dung.

---

## GIAI ĐOẠN 3 — Học tập (Sprint 5–6, tuần 9–12)

### Sprint 5 — Adaptive + lộ trình
- `tracks/*.ts`: nạp `LEVELS` của IELTS/SAT/HSA/TSA/SPT **nguyên vẹn** từ tài liệu cũ
- Ghi danh (`enrollments`), lộ trình theo `STUDY_PLANS`, lên cấp theo `exitTest` đa kỹ năng
- Bộ chọn bài: vùng phát triển gần (0.3 ≤ p_known ≤ 0.85) + SM-2 tới hạn
- Trang `/lo-trinh`: 10 cấp, mốc, % hoàn thành

### Sprint 6 — Duy trì thói quen
- Streak, XP, huy hiệu (rút gọn từ Wow/Fan Nation — lấy 20% cho 80% giá trị)
- Bảng xếp hạng (1 loại, không phải 9)
- Thông báo trong app + email nhắc học
- Trang hồ sơ: radar kỹ năng, lưới streak 30 ngày, vòng cấp độ

**Cổng G6:** 20 người dùng thử thật, đo **D7 retention ≥ 30%**. Không đạt thì sửa trải nghiệm học, chưa làm tiếp.

---

## GIAI ĐOẠN 4 — Thi cử (Sprint 7–8, tuần 13–16)

### Sprint 7 — Máy thi
- `exams` + blueprint theo `*_FORMAT` (HSA 150 câu/195′, TSA 80/130′, SAT 98/134′ adaptive M1→M2…)
- Giao diện làm bài: đồng hồ + cảnh báo 5′/1′ + tự nộp, lưới điều hướng câu, cắm cờ ôn lại, phím tắt
- Nháp trong IndexedDB, nộp lại khi có mạng
- Chấm + `score-converter` (port nguyên bảng quy đổi cũ)

### Sprint 8 — Chống gian lận + phân tích sau thi
- `proctor_events`: chuyển tab, mất focus, dán, bất thường thời gian (chọn ~6/14 loại, cái thực sự đo được trên web)
- Điểm rủi ro 0–100, cảnh báo, gắn cờ để người xem lại (**không** tự khoá tài khoản)
- Báo cáo sau thi: điểm theo phần, theo kỹ năng, so với mục tiêu, đề xuất ôn
- Hiệu chỉnh item: tính `p_value` / `discrimination` từ dữ liệu thật

**Cổng G8:** 10 người làm trọn 1 đề mock đầy đủ độ dài trên điện thoại, không mất bài, điểm quy đổi khớp thang chuẩn.

---

## GIAI ĐOẠN 5 — Gia sư AI (Sprint 9–10, tuần 17–20)

### Sprint 9 — Tutor thật
- 5 persona (Socratic / Thân thiện / Nghiêm khắc / Chuyên gia / Coach) — giữ nguyên system prompt đã viết
- Gọi API **thật** (Gemini Flash → Groq → Claude Haiku), streaming
- Ngữ cảnh: điểm yếu từ `mastery`, item đang làm
- Gợi ý nhiều cấp (không đưa đáp án ngay)
- Kiểm HEART/NES ở output, hạn mức chi phí theo gói

### Sprint 10 — Chấm Writing & Speaking
- Rubric IELTS 4 tiêu chí / SAT essay 3 tiêu chí — chấm bằng Claude
- Chấm 2 lần, lệch > 1 band → xếp hàng cho người chấm
- Ghi âm Speaking (MediaRecorder) → chuyển văn bản → chấm
- Lưu phản hồi có cấu trúc, hiện tiến bộ theo thời gian

**Cổng G10:** 30 bài Writing chấm bằng AI đối chiếu với 1 giám khảo người — sai lệch trung bình ≤ 0.5 band. Không đạt thì không bán tính năng này.

---

## GIAI ĐOẠN 6 — Thương mại hoá (Sprint 11–12, tuần 21–24)

### Sprint 11 — Bán hàng
- `packages` 11 tầng (seed nguyên bảng giá cũ), `orders`, `payments`, `entitlements`
- Cổng thanh toán VN: VNPay hoặc MoMo (chuyển khoản thủ công cho tier cao)
- Áp hạn mức theo gói (bài/ngày, phút tutor/tháng, số mock)
- Hoá đơn + `trace_id` theo điều A37

### Sprint 12 — Vận hành & ra mắt
- Admin: KPI theo phòng ban, doanh thu, phễu, danh sách rủi ro rời bỏ
- Sentry + trang health + báo cáo audit
- Landing SEO (SSR, schema.org, sitemap), trang giá
- Tài liệu pháp lý: điều khoản, quyền riêng tư, hồ sơ Luật AI 134/2025
- Kiểm thử tải: 500 người dùng đồng thời (k6)

**Cổng G12 — Ra mắt:** 100 người dùng thật, ≥ 10 đơn hàng có thu tiền, uptime ≥ 99.5% trong 2 tuần, 0 sự cố dữ liệu.

---

## Bảng theo dõi tổng

| Sprint | Tuần | Trọng tâm | Cổng kiểm |
|---|---|---|---|
| 0 | — | Ra quyết định | G0: trả lời 3 câu hỏi nền |
| 1 | 1–2 | Khung + Auth + Kernel | G1: đăng ký được trên staging |
| 2 | 3–4 | Lát cắt dọc luyện tập | G2: 20 bài liên tiếp trên điện thoại |
| 3 | 5–6 | Công cụ soạn nội dung | — |
| 4 | 7–8 | Pipeline sinh + kiểm định | **G4: 1.000 item published** |
| 5 | 9–10 | Adaptive + lộ trình 9 hệ | — |
| 6 | 11–12 | Streak/XP/thông báo | **G6: D7 retention ≥ 30%** |
| 7 | 13–14 | Máy thi | — |
| 8 | 15–16 | Chống gian lận + phân tích | G8: mock đủ độ dài, không mất bài |
| 9 | 17–18 | AI Tutor thật | — |
| 10 | 19–20 | Chấm Writing/Speaking | **G10: lệch ≤ 0.5 band** |
| 11 | 21–22 | Thanh toán + gói | — |
| 12 | 23–24 | Vận hành + ra mắt | **G12: 100 user, 10 đơn có thu** |

---

## Nhân sự theo giai đoạn

| Giai đoạn | Kỹ thuật | Nội dung | Khác |
|---|---|---|---|
| S0–S2 | 1 full-stack | 1 giáo viên (bán thời gian) | — |
| S3–S6 | 1 full-stack | **2 giáo viên (toàn thời gian)** | — |
| S7–S10 | 2 full-stack | 2 giáo viên + 1 giám khảo IELTS | 1 tư vấn luật (theo việc) |
| S11–S12 | 2 full-stack | 2 giáo viên | 1 marketing, 1 CSKH |

Đối chiếu với `Cấu Trúc GITAmath` (đề xuất 9–12 người ngay từ đầu): con số đó đúng cho giai đoạn 10K user, quá sớm cho 24 tuần đầu. Bắt đầu 2–3 người, tuyển theo cổng kiểm đã vượt qua.

---

## Ngân sách 24 tuần

| Khoản | Tháng | 6 tháng |
|---|---|---|
| Hạ tầng (Vercel Pro + Neon + Blob) | $45 | $270 |
| LLM API (chủ yếu free tier + Claude cho chấm) | $30–120 | $450 |
| Tên miền + email | $10 | $60 |
| Sentry (bậc dev) | $0 | $0 |
| **Tổng kỹ thuật** | **$85–175** | **~$780** |
| Nội dung (2 giáo viên) | — | *khoản lớn nhất — do bạn quyết* |

Không có dòng nào cho K8s, Kafka, ClickHouse, MinIO. Chưa cần.

---

## Bảo vệ khỏi vòng lặp viết lại

Điều nguy hiểm nhất với dự án này không phải là kỹ thuật — mà là viết lại lần thứ năm. Ba hàng rào:

1. **`docs/BACKLOG.md`** — mọi ý tưởng mới ghi vào đây kèm ngày. Xem lại mỗi cuối sprint. Không sửa kiến trúc giữa sprint.
2. **Định nghĩa "xong"** — một tính năng chỉ xong khi: có test, chạy trên staging, có người thật dùng, có số liệu. Không phải khi "code đã viết".
3. **Cổng kiểm là bắt buộc** — G2, G4, G6, G10 là điểm dừng thật. Không qua được thì sửa, không đi tiếp.

---

## Việc đầu tiên, ngay bây giờ

```bash
git checkout claude/gitamath-system-research-8uuyab

# 1. Đọc docs/01 → xác nhận bản đọc đúng ý đồ
# 2. Đọc docs/02 → duyệt hoặc phản biện kiến trúc
# 3. Trả lời 3 câu hỏi cuối docs/01 §7
# 4. Nói "bắt đầu Sprint 1" — tôi dựng khung Next.js + auth + kernel ngay trên nhánh này
```
