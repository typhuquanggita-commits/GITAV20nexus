# GITAmath — Bản Hệ Thống Đọc Được

> Kết quả nghiên cứu toàn bộ folder Drive `1-_qBobUV4RSPMXsDZzbP_1DKepp44edR`
> Ngày đọc: 2026-09-19 · 18/18 file · 2 spreadsheet + 16 Google Docs

---

## 0. Phạm vi đã đọc

| # | File | Kích thước | Loại | Mức đọc |
|---|------|-----------|------|---------|
| 1 | Cấu Trúc GITAmath | 18 KB | Kiến trúc tổng hợp | 100% |
| 2 | Nexus V20 | 35 KB | Kiến trúc phân tán | 100% |
| 3 | hướng dẫn script | 15 KB | Hướng dẫn triển khai | 100% |
| 4 | web luyện thi | 44 KB | Code Apps Script đầy đủ | 100% |
| 5 | Nexus GITAmath | 49 KB | Nexus X10 | 100% |
| 6 | Ui GITAmath 7 | 42 KB | Nexus v1 | Cấu trúc + tổng kết + mẫu code |
| 7 | GITAmath365 full | 124 KB | EMPIRE v100 | Cấu trúc + hiến pháp + security + DB + tổng kết |
| 8 | GITAmathIRON | 238 KB | IRON v100.1 | Báo cáo 47 lỗi + architect + cấu trúc + tổng kết |
| 9 | UI GITAmath | 238 KB | UI Dashboard 1–3 + Premium | Cấu trúc + tổng kết + mẫu code |
| 10 | UI GITAmath 4 | 122 KB | Ultra 10 hệ thống | Cấu trúc + ai-tutor + tổng kết |
| 11 | UI GITAmath 5 | 67 KB | KG · BI · Collab · Trại | Cấu trúc + tổng kết |
| 12 | Ui GITAmath 6 | 51 KB | RTX · Peer · OKR · Churn · Edge | Cấu trúc + tổng kết |
| 13 | Ielts 9.0 | 53 KB | Hệ IELTS | Curriculum + tổng kết |
| 14 | SAT 1600 | 45 KB | Hệ SAT | Curriculum + vocab + converter + docs |
| 15 | HSA 1300 | 39 KB | Hệ HSA | Curriculum + format + tổng kết |
| 16 | TSA 100 | 42 KB | Hệ TSA + 4 hệ bổ sung | Curriculum + converter + strategy + tổng kết |
| 17 | GITAmath_Main365 | 1 KB | Google Sheet | **Rỗng hoàn toàn** |
| 18 | GITAmath_Shard | 1 KB | Google Sheet | **Rỗng hoàn toàn** |

**Minh bạch về mức đọc:** tôi đã đọc 100% phần đặc tả, kiến trúc, bảng dữ liệu, cấu hình, curriculum, tổng kết và hướng dẫn của cả 18 file. Với 6 file code cực lớn (tổng ~63.000 dòng, phần lớn là code JavaScript lặp mẫu giữa các phiên bản), tôi đọc đầy đủ phần khai báo dữ liệu/cấu hình/API và đọc mẫu sâu phần thân hàm — không nạp từng dòng boilerplate trùng lặp. Mọi kết luận dưới đây đều được kiểm chứng bằng grep trực tiếp trên toàn văn, không suy đoán.

---

## 1. Kết luận quan trọng nhất

> **GITAmath không phải một hệ thống. Đó là 4 hệ thống khác nhau, viết lại từ đầu 4 lần trong 24 giờ, không tương thích với nhau, và chưa có dòng nào từng được chạy.**

Mốc thời gian tạo file cho thấy rõ:

```
18/09 01:35  web luyện thi ........... KIẾN TRÚC A — Apps Script + Google Sheets
18/09 01:47  hướng dẫn script ........ (hướng dẫn deploy cho A)
18/09 02:14  GITAmath_Main365 ........ Sheet rỗng — BƯỚC 7 chưa từng chạy
18/09 02:17  GITAmath_Shard .......... Sheet rỗng
18/09 12:08  GITAmath365 full ........ KIẾN TRÚC B — Node + Electron + SQLite (v100)
18/09 12:28  GITAmathIRON ............ KIẾN TRÚC B' — vá 47 lỗi của B (v100.1)
18/09 14:08  Ielts 9.0 ............... module hệ B
18/09 14:12  SAT 1600 ................ module hệ B
18/09 14:17  HSA 1300 ................ module hệ B
18/09 14:21  TSA 100 ................. module hệ B
18/09 14:27  UI GITAmath ............. UI cho hệ B
18/09 15:16  UI GITAmath 4 ........... +10 hệ Ultra
18/09 16:35  UI GITAmath 5 ........... +KG, BI, Trại
18/09 17:53  Ui GITAmath 6 ........... +RTX, Peer, OKR, Churn, Edge
18/09 17:58  Ui GITAmath 7 ........... KIẾN TRÚC C — Nexus phủ lên B
18/09 18:00  Nexus GITAmath .......... KIẾN TRÚC C' — Nexus X10
19/09 01:21  Nexus V20 ............... KIẾN TRÚC D — phân tán K8s, viết lại lần 4
19/09 01:45  Cấu Trúc GITAmath ....... tự kiểm toán, thừa nhận phần lớn là bản vẽ
```

Chính tài liệu cuối cùng (`Cấu Trúc GITAmath`) đã tự thừa nhận điều này và tự kết luận:

> *"Đừng viết thêm code. Bước tiếp theo là: `npm ci && npm run verify && npm start`. Paste 2 file log đó cho tôi. Đây là con đường duy nhất từ thiết kế → sản phẩm thật."*

Đó là kết luận đúng. Tài liệu này xác nhận và cụ thể hoá nó.

---

## 2. Bốn kiến trúc — so sánh

| | **A. Apps Script** | **B. Empire/IRON** | **C. Nexus X10** | **D. Nexus V20** |
|---|---|---|---|---|
| File nguồn | web luyện thi | GITAmath365 full, IRON | Ui GITAmath 7, Nexus GITAmath | Nexus V20 |
| Runtime | Google Apps Script V8 | Node 20 + Electron | Node 20 (trong process B) | Node 20 + K8s |
| Dữ liệu | Google Sheets (2 file) | SQLite WAL (better-sqlite3) | SQLite (kế thừa B) | Redis + Qdrant + NATS + ClickHouse + MinIO |
| Giao diện | HtmlService 3 file | Electron + renderer/ | Dashboard War Room | CDN + React (chưa viết) |
| Quy mô khai báo | ~49 file .gs (gộp 5) | ~232 file | 22 file nexus/ + 200 module catalog | 60+ module + 10 nhóm endpoint |
| Triển khai | Web App URL, $0 | Cài máy tính | Cài máy tính | Docker Compose → K8s 3–20 pod |
| AI | 100 agent "ảo" (sheet) | 100 agent + 10 thanh tra | +autopilot 5 chế độ | 500 agent, MoE, bandit |
| Chi phí/tháng | $0 | $0 | $0 | $50 → $13.000 |
| Đã chạy? | **Chưa** (sheet rỗng) | **Chưa** | **Chưa** | **Chưa** |

**Chúng không cộng dồn được.** `Users.register()` của A ghi vào Sheet; `db.register()` của B ghi vào SQLite bằng bcrypt; D lại đi qua `Orchestrator.createRun()` → BullMQ → Redis. Ba cách lưu user khác nhau, ba mô hình phiên khác nhau, không có lớp chuyển đổi nào giữa chúng.

---

## 3. Mô hình nghiệp vụ (phần ỔN ĐỊNH qua cả 4 kiến trúc)

Đây là tài sản thật của dự án — nó không đổi dù code bị viết lại 4 lần.

### 3.1 Chín hệ đào tạo

| # | Hệ | Số cấp | Thang điểm | Format thi | Nguồn |
|---|----|--------|-----------|-----------|-------|
| 1 | **IELTS** | 10 | 0 → 9.0 | 4 kỹ năng | Ielts 9.0 |
| 2 | **SAT** | 10 | 400 → 1600 | 98 câu / 134 phút, adaptive M1→M2 | SAT 1600 |
| 3 | **HSA** (ĐHQG HN) | 10 | 150 → 1300 | 150 câu / 195 phút, 3 phần + 1 tự chọn | HSA 1300 |
| 4 | **TSA** (ĐHBK HN) | 10 | 0 → 100 | 80 câu / 130 phút, 4 phần | TSA 100 |
| 5 | **SPT** (ĐHQG HCM) | 10 | 0 → 1200 | 160 câu / 250 phút, 4 phần | TSA 100 |
| 6 | **English Comm** | 6 (CEFR) | A1 → C2 | ~1300 giờ | TSA 100 |
| 7 | **Olympiad** | 6 tier | Trường → IMO | Huy chương | TSA 100 |
| 8 | **Toán phổ thông** | 12 lớp × 8 tier | — | HSG → Quốc tế | web luyện thi |
| 9 | **Tiếng Anh 1–12** | 12 lớp | — | 4 dạng câu hỏi | web luyện thi |

Mỗi hệ có cùng khuôn: `curriculum.js` (10 cấp, mỗi cấp có `focus`, `milestones`, `skills`, `exitTest`) → `placement.js` → các module kỹ năng → `mock-test.js` → `score-converter.js` → `strategy-*.js` → `index.js`.

**Cơ chế lên cấp** (nhất quán): học viên chỉ lên cấp khi **tất cả** kỹ năng đạt ngưỡng `exitTest` của cấp hiện tại. Ví dụ IELTS: `['listening','reading','writing','speaking'].every(s => skillScores[s] >= level.exitTest[s])`.

**Gói học** (`STUDY_PLANS`): `intensive` (5–6h/ngày) · `standard` (3h/ngày) · `relaxed` (1.5h/ngày) — quyết định số tuần mỗi cấp.

### 3.2 Kho nội dung mục tiêu

| Loại | Mục tiêu | Thực tế trong tài liệu |
|------|----------|----------------------|
| Bài Toán | 500.000 | Hàm `statementOf()` sinh từ 8 template + số ngẫu nhiên |
| Bài Tiếng Anh | 500.000 | Hàm `questionOf()` — **3 câu hỏi cố định** theo 3 dải lớp |
| Chuyên đề Toán | 30.000 | 768 tổ hợp thật, còn lại nhân bản `#idx` |
| Chuyên đề CLC/Chuyên/ĐH | 30.000 | `Chuyên đề ${target} #${i}` — chỉ có tên |
| HSA/TSA/SPT | 1.000 | `Chuyên đề ${ex} · ${sb} #${i}` — chỉ có tên |
| Từ vựng SAT "3000+" | 3.000 | **~450 chuỗi từ**, `definition: "Định nghĩa của \"${w}\""` |
| Tài liệu KB | 1.000.000 | 0 |

### 3.3 Phân quyền (RBAC)

14 vai trò: `SUPER_ADMIN`, `CEO`, `CTO`, `ACADEMIC_DIR`, `HEAD_TEACHER`, `TEACHER`, `COACH`, `INSPECTOR`, `ACCOUNTANT`, `SALES`, `MARKETER`, `SUPPORT`, `CONTENT_EDITOR`, `STUDENT` (+ `GUEST`, `AI_AGENT`).

Cơ chế: wildcard match — `'finance.*'` khớp `finance.summary`; `'*'` = toàn quyền.

### 3.4 Gói học phí — 11 tầng

| Tier | Tên | Giá (VNĐ) | Tháng | Điểm nhấn |
|---|---|---|---|---|
| 0 | Free | 0 | 0 | 10 bài/ngày |
| 1 | Starter | 2.000.000 | 3 | 500 bài/tháng |
| 2 | Basic | 5.000.000 | 6 | 3.000 bài, chấm tự động |
| 3 | Advanced | 10.000.000 | 12 | 10.000 bài, coaching nhóm |
| 4 | Pro | 25.000.000 | 12 | 50.000 bài, IELTS cơ bản |
| 5 | Elite | 40.000.000 | 18 | Coaching 1-1/tháng |
| 6 | Premium | 60.000.000 | 18 | Coaching 1-1/tuần |
| 7 | Platinum | 90.000.000 | 24 | IELTS 7.0 / SAT 1400 |
| 8 | Diamond | 120.000.000 | 24 | Coaching 1-1/3 ngày |
| 9 | Executive | 160.000.000 | 24 | Mentor riêng |
| 10 | Ultimate | 200.000.000 | 24 | Bảo hành điểm |

### 3.5 Hiến pháp

- Bản A (web luyện thi): **10 điều + 7 điều cấm**
- Bản B (EMPIRE v100): **50 điều / 5 chương** — I Nguyên tắc gốc · II AI & Bộ não · III Thanh tra · IV Bảo mật & Tài chính · V Vận hành & Phục hồi. Có `validate(action, ctx)` chạy thật, trả `{ok, violations, maxSeverity}`.
- Bản D (Nexus V20): **7 axiom HEART** + `NES_BOUNDARIES` (chặn AI tự nhận có ý thức/cảm xúc/ký ức).

Điều xuyên suốt và quan trọng nhất về sản phẩm: **A02 — chuẩn LaTeX**, cấm `/`, `^`, `sqrt()` trong nội dung hiển thị. Module `MathNotation.normalize()` tự chuyển `3/4` → `\dfrac{3}{4}`, `x^2` → `x^{2}`, `sqrt(x)` → `\sqrt{x}`.

### 3.6 Bảo mật

Bản B: **22 lớp** = 10 phòng vệ ngoài (DDoS, bot, zero-day, APT, ransomware, MITM, phishing, insider, supply-chain, social) + 12 tầng trong (geoIP, blacklist, rate-limit, payload-size, signature, SQLi, XSS, token, permissions, encryption, constitution, behavioral).

Bản D: 4 lớp chống prompt-injection (provenance tagging, channel isolation, dual-LLM, capability minimization) + `SafeMetaPrompt` với 15 regex phát hiện jailbreak.

### 3.7 Các hệ vệ tinh

- **Wow + Fan Nation** (22 module): Loyalty 6 bậc · Ambassador 5 bậc · VIP 4 bậc · Nation 6 chapter · Mission 1M · Delight · Recognition · Referral
- **Strategy**: 1.000 chiến lược (bản B) → 100.000 (bản D: 20 domain × 5.000, 3 tầng Commander → Strategist → Tactician, có Monte Carlo `twin/simulate` tính VaR95/CVaR95)
- **Trại huấn luyện** (3 chương trình): Leader Boom 7N6Đ · Trainer the Trainer 14 ngày/140 giờ · Gel Alpha 10 ngày, kèm 55+ tài liệu pháp lý VN, 10 giấy phép, 8 tiêu chí Bộ GD&ĐT, 5 loại bảo hiểm
- **Ultra 10**: PWA · AI Tutor (4 provider, 5 persona) · Adaptive Learning (BKT + SM-2) · Multi-tenant · Classroom+Zoom · Telegram · Facebook · Psychometric (DISC/MBTI/Big Five/Holland/VARK) · Biometric · Anti-cheat (14 loại vi phạm, risk score 0–100)
- **Part 5/6**: Knowledge Graph · BI 40+ metric · Collab CRDT · Real-time Exam · Peer Learning · OKR · ML Churn (logistic regression thuần JS, 16 feature) · Edge CDN 8 region

### 3.8 KPI & tổ chức

- Bản A: 10 phòng ban (ACADEMIC, ENGLISH, VIDEO, EXAM, COACHING, MARKETING, FINANCE, SUPPORT, AI_OPS, INSPECTOR)
- Bản D: 500 agent chia 6 chuyên môn (Math 80 · Code 80 · Tutor 100 · Research 80 · Business 60 · Vietnamese 100), vòng đời CREATE → BOOT → WORK → KPI TRACK → COACH → APPLY → ROLLBACK
- Nhân sự người cần tuyển (theo `Cấu Trúc GITAmath`): 9–12 người, vốn $10K–30K/tháng, 12–24 tháng để đạt 100K user

---

## 4. Đánh giá trung thực: cái gì thật, cái gì chưa

### 4.1 Thật và dùng được ngay

- **Mô hình nghiệp vụ giáo dục** — 9 hệ đào tạo với format thi chuẩn, đúng thực tế (HSA 150 câu/195 phút, TSA 80 câu/130 phút, Digital SAT 98 câu/134 phút adaptive). Đây là phần giá trị nhất.
- **Chuẩn LaTeX + `MathNotation`** — thuật toán normalize/validate chạy được, giải đúng vấn đề thật.
- **Cơ chế lên cấp theo `exitTest` đa kỹ năng** — đúng sư phạm.
- **Bảng giá 11 tầng, 14 vai trò, hiến pháp 50 điều** — quyết định kinh doanh đã chốt, không cần thiết kế lại.
- **Schema SQLite** (12 bảng, có index) — dùng gần như nguyên vẹn được.
- **Thuật toán có thật**: Thompson Sampling (beta/gamma sampling viết tay), entropy MoE adaptive-K, BKT, SM-2, logistic regression, haversine + MCMC.

### 4.2 Bản vẽ — chưa test

- Không có file log nào. Không có `verify.log`, không có `start.log`.
- Hai spreadsheet **rỗng** → `setup()` trong hướng dẫn 15 bước chưa từng được chạy dù chỉ một lần.
- Không có repo Git nào chứa 232 file đó. Repo hiện tại (`Quang-GITA`) chứa **template Veo 3 Gallery của AI Studio**, không liên quan GITAmath.

### 4.3 Chưa đúng như mô tả (đã kiểm chứng bằng grep toàn văn)

| Tuyên bố | Thực tế trong code |
|---|---|
| AI Tutor 4 provider (Claude/GPT/Gemini/Local) | `_callAI()` ghi rõ `// Production: call actual API` / `// For now: return simulated response`. Token và độ trễ đều `Math.random()`. |
| Zoom API integration | `this.accessToken = 'simulated_token_' + Date.now()` |
| Telegram bot | `// Production: POST https://api.telegram.org/...` — chưa gọi |
| Facebook insights | `// Simulate reach` |
| Biometric face recognition | `// Simulate based on hash prefix match` |
| "500.000 bài toán" | 8 template × số ngẫu nhiên; cron sinh 2.000 bài/giờ → 11 ngày ra 500.000 bài **trùng dạng** |
| "500.000 bài tiếng Anh" | `questionOf()` trả về **đúng 3 câu hỏi** tuỳ dải lớp |
| "3000+ từ vựng SAT" | ~450 từ, định nghĩa là `"Định nghĩa của \"abate\""` |
| "2000+ event routes" | `generateAllRoutes()` ghép 30 group × 30 action rồi gán module **ngẫu nhiên**: `[...ALL_MODULES].sort(() => Math.random() - 0.5)` |
| Mock test TSA/SPT/HSA | Sinh `Câu ${i+1} — ${p.name}`, `options: ['A','B','C','D']`, `correct: 0` — mọi đáp án đúng đều là A |
| ZK proof (`operator-zk`) | Chỉ là SHA-256 hash commitment, không phải zkSNARK |
| "Hiệu quả 1000x" | Chính tài liệu ghi: *"không có cơ sở khoa học cho 1000x"* |

### 4.4 Rủi ro pháp lý đã được nhận diện

Tài liệu `Cấu Trúc GITAmath` nêu Luật AI VN 134/2025/QH15 có hiệu lực 01/3/2026, và hệ thống giáo dục thuộc nhóm **rủi ro cao** → phải đăng ký với Bộ KH&CN, đánh giá phù hợp, giám sát liên tục. Đây là ràng buộc thật, cần xử lý trước khi mở cho người dùng thật.

---

## 5. Danh mục module đã khai báo (để tra cứu)

`MODULE_CATALOG` của Nexus X10 khai báo 12 danh mục:

| Danh mục | Số module | Ví dụ |
|---|---|---|
| CORE | 10 | eventbus, state, logger, database, constitution, brain, teamwork, agents, inspectors, architect |
| SECURITY | 5 | security, antivirus, reset, biometric, antiCheat |
| AI | 7 | aiTutor, adaptive, analyticsAI, mlChurn, psychometric, kg, aiGenerator |
| BUSINESS | 7 | finance, sales, marketing, library, kpi, legal, bi |
| EDUCATION | 19 | personal, trainer, 3×QC, behavior, attention, consultant, coach, rtx, peer, okr, ielts/sat/hsa/tsa/spt System, englishComm, olympiad |
| ECOSYSTEM | 8 | wowSystem, fanSystem, retention10, strategySystem, creative, collab, gamification, notification |
| CAMP | 6 | campPrograms, campDocs, campSafety, campConsultation, campManager, campAI |
| INTEGRATION | 9 | videoCall, voice, payment, i18n, telegram, facebook, zoom, classroom, tenant |
| INFRA | 2 | edge, superadmin |
| AUTOPILOT | 6 | autopilot, autoScaler, autoOptimizer, autoHealer, predictive, chaos |
| OBSERV | 6 | healthMonitor, trafficCtrl, circuitMgr, resourceMgr, eventScheduler, warRoom |

**Tổng: ~85 module định danh** (không phải 232 — con số 232 là số *file* bao gồm cả HTML/CSS/locales/docs).

---

## 6. API surface đã thiết kế

### Bản A — Apps Script (1 endpoint, action-based)
`api(action, payload)` với ~60 action: `auth.*`, `roles.*`, `constitution.*`, `kpi.*`, `ai.*`, `brain.*`, `bank.*`, `topics.*`, `examprep.*`, `hsa.*`, `eng.*`, `ielts.*`, `sat.*`, `curriculum.*`, `exam.*`, `progress.*`, `pkg.*`, `fin.*`, `mkt.*`, `media.*`, `admin.*`

### Bản B/C — Node (`POST /api/action`)
Cùng mô hình action-based, SuperAdmin có 40+ → 300+ action sau các patch.

### Bản D — Nexus V20 (REST, 10 nhóm)
CORE · ORCHESTRATOR · GOVERNANCE · MEDIA · INTELLIGENCE · STRATEGY · PLATFORM · ECONOMY · SECURITY · OPS

**Điểm chung đáng giữ:** mô hình `{action, args}` một endpoint, trả `{ok, ...}` — đơn giản, dễ kiểm soát RBAC tập trung, dễ audit. Nên giữ tinh thần này.

---

## 7. Ba câu hỏi phải trả lời trước khi viết dòng code tiếp theo

1. **Người dùng đầu tiên là ai, học gì, trên thiết bị nào?** Toàn bộ 4 kiến trúc đều ngầm định "100K user" nhưng không kiến trúc nào định nghĩa 100 user đầu tiên. Bản B/C là **Electron — app cài trên máy tính**, trong khi học sinh Việt Nam luyện thi chủ yếu trên điện thoại.

2. **Ai viết nội dung thật?** Không một dòng code nào giải được việc này. 500.000 bài toán có lời giải chuẩn LaTeX cần biên tập viên thật, hoặc pipeline LLM + kiểm duyệt người thật. Đây là hạng mục đắt nhất và chưa có kế hoạch.

3. **Chọn kiến trúc nào?** Không thể giữ cả 4. Phương án ở [`02-PHUONG-AN-WEB-APP.md`](./02-PHUONG-AN-WEB-APP.md).
