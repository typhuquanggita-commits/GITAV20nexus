# Phương Án Lập Trình Tối Ưu — GITAmath Web App

> Đi kèm [`01-HE-THONG-GITAMATH.md`](./01-HE-THONG-GITAMATH.md)
> Nguyên tắc: **một codebase, web-first, chạy được trước — mở rộng sau.**

---

## 1. Quyết định kiến trúc

### 1.1 Chọn gì

**Next.js 15 (App Router) + TypeScript + PostgreSQL** — một ứng dụng web duy nhất, deploy trên Vercel hoặc Cloudflare, chạy tốt trên điện thoại.

```
┌──────────────────────────────────────────────────────────┐
│  Trình duyệt (mobile-first, PWA)                         │
│  React 19 · Tailwind · shadcn/ui · KaTeX                 │
└────────────────────────┬─────────────────────────────────┘
                         │ Server Actions + REST /api/v1
┌────────────────────────▼─────────────────────────────────┐
│  Next.js App (modular monolith)                          │
│  ┌────────┬────────┬────────┬────────┬────────┬───────┐ │
│  │identity│catalog │learning│assess  │tutor   │commerce││
│  ├────────┴────────┴────────┴────────┴────────┴───────┤ │
│  │  engagement  ·  ops (audit/KPI/analytics)           │ │
│  ├──────────────────────────────────────────────────── │ │
│  │  kernel: auth · rbac · constitution · llm · events  │ │
│  └──────────────────────────────────────────────────── ┘ │
└────────┬──────────────────────┬──────────────────────────┘
         │                      │
┌────────▼─────────┐  ┌─────────▼──────────┐  ┌────────────┐
│ PostgreSQL       │  │ Job queue          │  │ LLM Gateway│
│ + pgvector       │  │ (pg-boss, cùng DB) │  │ Gemini/Groq│
│ Drizzle ORM      │  │                    │  │ + Claude   │
└──────────────────┘  └────────────────────┘  └────────────┘
```

### 1.2 Vì sao loại 4 kiến trúc cũ

| Kiến trúc | Lý do loại |
|---|---|
| **A. Apps Script + Sheets** | Giới hạn cứng: 6 phút/lần chạy, 30s UrlFetch, Sheet tối đa 10 triệu ô → 500K bài × 10 cột = 5 triệu ô, chỉ riêng kho Toán đã chiếm nửa quota. `sh.getDataRange().getValues()` nạp toàn bộ sheet vào RAM cho **mỗi** request — sập ở vài nghìn dòng. `ProblemBank.next()` quét tuyến tính cả bảng. Không có transaction, không có index, không chịu được đồng thời. Sẽ vỡ trước 1.000 user. |
| **B. Electron + SQLite** | Sai kênh phân phối. Học sinh luyện thi dùng điện thoại; bắt cài app desktop là mất 90% thị trường. SQLite một file cũng không phục vụ đa người dùng qua mạng. |
| **C. Nexus X10** | Lớp điều phối in-process chồng lên B — thừa hoàn toàn với một monolith. `generateAllRoutes()` gán module ngẫu nhiên là anti-pattern nguy hiểm: hệ thống sẽ hành xử khác nhau sau mỗi lần khởi động. |
| **D. Nexus V20 (K8s)** | Redis + NATS + Qdrant + ClickHouse + MinIO + K8s 3–20 pod cho **0 người dùng**. $500+/tháng, cần 9–12 kỹ sư vận hành. Đúng cho năm thứ 3, sai cho hôm nay. |

**Nhưng giữ lại từ D:** mô hình khái niệm rất tốt — adaptive router, category-aware cache, safe meta-prompt, HEART constitution. Ta cài chúng dưới dạng **hàm trong monolith**, không phải microservice.

### 1.3 Stack cụ thể

| Lớp | Chọn | Lý do |
|---|---|---|
| Framework | **Next.js 15, App Router, TS strict** | SSR cho SEO, RSC giảm JS phía client, Server Actions bỏ được nửa số API route |
| UI | **Tailwind + shadcn/ui + KaTeX** | shadcn = sở hữu code, không khoá vendor. KaTeX là lựa chọn đúng đã có sẵn trong bản A |
| DB | **PostgreSQL (Neon hoặc Supabase)** + **pgvector** | Có transaction, index, full-text search tiếng Việt, JSONB. pgvector thay Qdrant ở giai đoạn đầu |
| ORM | **Drizzle** | SQL-first, type-safe, migration bằng file — dễ review hơn Prisma cho schema hay đổi |
| Auth | **Auth.js v5** (email + Google) | Argon2id cho mật khẩu (thay SHA-256+salt của bản A — SHA-256 quá nhanh, không chống brute-force) |
| Queue | **pg-boss** (dùng chính Postgres) | Không thêm hạ tầng. Đổi sang Upstash QStash khi cần |
| Cache | **Next.js cache + Upstash Redis** khi cần | Chưa cần ở 10K user |
| LLM | **một module gateway** | Gemini Flash / Groq (free tier) cho tutor & sinh nội dung; Claude cho chấm Writing/Speaking và kiểm duyệt |
| File | **Vercel Blob / S3-compatible** | Thay MinIO |
| Realtime | **SSE** cho dashboard, **Postgres LISTEN/NOTIFY** cho thi trực tiếp | Không cần WebSocket hub riêng |
| Observability | **Sentry + Vercel Analytics + bảng `audit`** | Thay ClickHouse + Prometheus + Grafana giai đoạn đầu |
| Test | **Vitest** (unit) + **Playwright** (e2e) | Đã cài sẵn Chromium trong môi trường |
| CI | **GitHub Actions**: typecheck → lint → test → migrate → deploy | |

**Chi phí thực tế:** $0–25/tháng cho tới ~5.000 người dùng hoạt động.

---

## 2. Tám bounded context (thay cho 232 file)

Mỗi context là một thư mục `src/modules/<tên>/` gồm `schema.ts` · `service.ts` · `actions.ts` · `types.ts`. **Context chỉ gọi nhau qua service function đã export, không truy cập bảng của nhau.**

| # | Context | Trách nhiệm | Gom từ các module cũ |
|---|---|---|---|
| 1 | **identity** | User, session, RBAC 14 vai trò, tenant, audit | Users, Security, Roles, tenant, multi-tenant, biometric |
| 2 | **catalog** | Môn, kỹ năng, knowledge graph, **item bank**, phiên bản & kiểm duyệt nội dung | ProblemBank, EnglishBank, Topics, ExamPrep, HSA_TSA_SPT, knowledge-graph, library, Inspectors |
| 3 | **learning** | Ghi danh, lộ trình 9 hệ, adaptive (BKT + SM-2), mastery, streak | curriculum×9, adaptive-learning, Curriculum, personal, okr, peer-learning |
| 4 | **assessment** | Đề thi, lượt làm bài, chấm, score converter, chống gian lận | Exam, mock-test×9, score-converter×9, real-time-exam, anti-cheat, Proctoring |
| 5 | **tutor** | AI tutor 5 persona, gợi ý nhiều cấp, chấm Writing/Speaking, LLM gateway | ai-tutor, Brain, Agents, coach, consultant, voice |
| 6 | **commerce** | Gói 11 tầng, đơn hàng, thanh toán, hoá đơn, doanh thu | Packages, Orders, Payment, Finance, Invoice |
| 7 | **engagement** | XP, huy hiệu, bảng xếp hạng, thông báo, giới thiệu, dự báo rời bỏ | Wow×12, Fan Nation×10, gamification, notification, ml-churn, retention10 |
| 8 | **ops** | Dashboard admin, KPI, analytics, cờ tính năng, health | superadmin, kpi, bi-dashboard, analytics-ai, healthMonitor, nexus/* |

**Kernel dùng chung** (`src/kernel/`): `auth.ts` · `rbac.ts` · `constitution.ts` · `llm.ts` · `events.ts` · `math-notation.ts` · `errors.ts` · `logger.ts`

### 2.1 Cái gì DỪNG, cái gì HOÃN

| Bỏ hẳn | Lý do |
|---|---|
| Electron, `app/main.js`, `preload.js` | Web thay thế hoàn toàn |
| Nexus (cả 3 bản), autopilot, chaos, war-room, service-registry, event-mesh | Không có microservice thì không có gì để điều phối |
| antivirus.js, hybrid-pqc, operator-zk, sgfusion | Không giải vấn đề nào của sản phẩm |
| "500 agent AI" | Không có công việc thật cho 500 tiến trình |
| Camp (3 trại), Telegram, Facebook, Zoom | Là sản phẩm khác — tách ra sau |

| Hoãn tới sau MVP | Khi nào |
|---|---|
| Multi-tenant (trường học) | Có khách hàng B2B đầu tiên |
| Psychometric (DISC/MBTI) | Sau khi giữ chân được người dùng |
| Video call, avatar 3D, voice cloning | Khi có doanh thu bù chi phí |
| Federated learning, edge CDN | >50K người dùng |
| Strategy 100K, digital twin | Không phải tính năng cho người học |

Kết quả: **~85 module → 8 context + kernel**. Ít hơn 10 lần thứ phải bảo trì, mà không mất tính năng nào người dùng thật sự dùng.

---

## 3. Mô hình dữ liệu cốt lõi

20 bảng thay cho "hàng chục sheet". Kế thừa schema SQLite của bản B, sửa các lỗi thiết kế.

```sql
-- IDENTITY
users(id uuid pk, email citext unique, password_hash text,       -- argon2id
      full_name, phone, role role_enum default 'STUDENT',
      status, tenant_id, locale default 'vi',
      created_at, last_login_at)
sessions(id, user_id fk, token_hash, expires_at, ip, ua, revoked_at)
audit_log(id bigserial, at, actor_id, action, entity, entity_id, detail jsonb)
  -- PARTITION BY RANGE (at); giữ 365 ngày theo điều A34

-- CATALOG  ← trái tim sản phẩm
subjects(id, code, name)                               -- math, english, ielts, sat, hsa, tsa, spt
skills(id, subject_id, code, name, grade, parent_id)   -- knowledge graph (cây + cạnh prereq)
skill_edges(from_skill, to_skill, kind)                -- prerequisite | related
items(id uuid pk, subject_id, skill_id, tier, difficulty numeric,
      kind item_kind,                                  -- mcq | numeric | free_text | essay | speaking
      stem_latex text, options jsonb, answer jsonb,
      solution_steps jsonb,                            -- LaTeX từng bước
      source text, author_id, license,
      status item_status default 'draft',              -- draft|review|published|retired
      content_hash text unique,                        -- SHA-256 chống trùng
      p_value numeric, discrimination numeric,         -- thống kê từ lượt làm thật
      created_at, published_at)
item_reviews(id, item_id, reviewer_id, verdict, notes, at)

-- LEARNING
enrollments(id, user_id, track track_enum, target_score numeric,
            plan plan_enum, current_level int, started_at)
mastery(user_id, skill_id, p_known numeric,            -- BKT
        last_seen_at, next_due_at, ease numeric, interval_days int,  -- SM-2
        PRIMARY KEY (user_id, skill_id))
study_sessions(id, user_id, started_at, ended_at, minutes, items_done, accuracy)
streaks(user_id pk, current int, longest int, last_day date)

-- ASSESSMENT
exams(id, kind, track, title, blueprint jsonb, duration_min, created_by)
attempts(id uuid, exam_id, user_id, started_at, submitted_at,
         raw_score, scaled_score, section_scores jsonb, status)
responses(id bigserial, attempt_id, item_id, answer jsonb,
          is_correct bool, ms int, flagged bool)
proctor_events(id, attempt_id, type, data jsonb, at)   -- 14 loại vi phạm

-- TUTOR
conversations(id, user_id, persona, subject, level, provider, created_at)
messages(id bigserial, conversation_id, role, content, tokens_in, tokens_out, cost_usd, at)

-- COMMERCE
packages(code pk, tier int, name, price_vnd bigint, months int, features jsonb, active)
orders(id, user_id, package_code, price_vnd, months, status, trace_id, created_at)
payments(id, order_id, amount_vnd, method, status, provider_ref, at)
entitlements(user_id, package_code, starts_at, ends_at, limits jsonb)

-- ENGAGEMENT
xp_events(id bigserial, user_id, kind, amount int, ref, at)
notifications(id, user_id, kind, title, body, read_at, at)
```

**Chỉ mục bắt buộc:**
```sql
CREATE INDEX ON items (subject_id, skill_id, tier, difficulty) WHERE status='published';
CREATE INDEX ON items USING gin (to_tsvector('simple', stem_latex));
CREATE INDEX ON responses (attempt_id);
CREATE INDEX ON mastery (user_id, next_due_at);   -- lấy bài ôn tới hạn
CREATE INDEX ON audit_log (actor_id, at DESC);
```

**Ba sửa lỗi so với bản cũ:**
1. `content_hash UNIQUE` ở tầng DB — chống trùng thật, không phải quét `Set` trong RAM.
2. `p_value` / `discrimination` — đo độ khó **thật** từ dữ liệu người học, thay `difficulty` gán tay.
3. `status` + `item_reviews` — quy trình kiểm duyệt 2 lớp (điều A06) được mã hoá vào dữ liệu, không chỉ là lời hứa.

---

## 4. Bảy quyết định kỹ thuật then chốt

### 4.1 Item bank là sản phẩm, không phải máy sinh câu hỏi

Đây là thay đổi quan trọng nhất. Bản cũ dùng `statementOf(level, topic, seed)` ghép template → 500.000 bài **cùng 8 dạng**, người học phát hiện trong 10 phút.

Thay bằng **pipeline 4 bước**:

```
1. NGUỒN      →  import đề thi công khai + giáo viên soạn (CSV/JSON/Word)
2. SINH       →  LLM sinh biến thể từ item gốc (đổi số, đổi ngữ cảnh, giữ kỹ năng)
3. KIỂM ĐỊNH  →  tự động: MathNotation.validate + giải lại bằng CAS/LLM khác, đối chiếu
                 người: 1 giáo viên duyệt trước khi status='published'
4. HIỆU CHỈNH →  sau ≥100 lượt làm, tính p_value/discrimination, loại item xấu
```

Mục tiêu thực tế: **3.000 item chất lượng cao** phủ hết kỹ năng thi, hơn hẳn 500.000 item template. Đủ cho mọi bài luyện tập adaptive vì hệ thống chọn theo kỹ năng + độ khó, không cần kho khổng lồ.

### 4.2 Một cổng LLM, có ngân sách và hàng rào

```ts
// src/kernel/llm.ts
type Task = 'tutor_chat' | 'hint' | 'grade_writing' | 'grade_speaking'
          | 'generate_item' | 'verify_item' | 'moderate'

const ROUTE: Record<Task, Model[]> = {
  tutor_chat:    ['gemini-flash', 'groq-llama', 'claude-haiku'],  // rẻ → đắt
  grade_writing: ['claude-sonnet'],                                // chất lượng là bắt buộc
  verify_item:   ['claude-sonnet'],                                // khác model với lúc sinh
  moderate:      ['gemini-flash'],
}

export async function callLLM(task: Task, input: LLMInput): Promise<LLMResult>
// bên trong: safeMetaPrompt → chọn model → fallback → circuit breaker
//            → cache theo category → ghi cost → kiểm HEART ở output
```

Giữ nguyên các ý hay từ Nexus V20, cài dưới dạng hàm:
- **`safeMetaPrompt()`** — 15 regex chống injection + tách kênh system/user (điều OWASP LLM01)
- **Category cache** — code/math ngưỡng 0.85–0.90 TTL dài; chat 0.95 TTL ngắn; PII/tài chính **tắt cache**
- **HEART/NES check ở output** — chặn AI tự nhận có cảm xúc/ý thức
- **Adaptive routing** — bắt đầu bằng luật tĩnh + đo; chỉ bật Thompson Sampling khi đã có ≥10.000 mẫu reward thật

Hạn mức cứng: chi phí LLM/người dùng/ngày, vượt thì hạ cấp model rồi từ chối lịch sự.

### 4.3 Adaptive engine — BKT + SM-2, viết một lần dùng cho 9 hệ

```ts
// Chọn bài tiếp theo:
// 1. Lấy mastery của user cho các skill trong track
// 2. Lọc skill ở "vùng phát triển gần": 0.3 ≤ p_known ≤ 0.85
// 3. Ưu tiên skill có next_due_at đã tới hạn (SM-2)
// 4. Lấy item published có difficulty ≈ p_known của user
// 5. Cập nhật p_known sau mỗi phản hồi (BKT: P(L|correct), P(L|incorrect))
```
Toàn bộ `curriculum.js` × 9 chỉ là **dữ liệu cấu hình** (`tracks/ielts.ts`, `tracks/sat.ts`...), không phải 9 class riêng.

### 4.4 Hiến pháp là middleware, không phải tài liệu

```ts
// Mọi server action đi qua:
withGuards(action, {
  auth: 'required',
  permission: 'bank.next',
  constitution: ['A02_latex', 'A06_audited', 'A37_trace'],
})
```
Vi phạm severity 3 → chặn + ghi audit. Điều này biến 50 điều hiến pháp từ văn bản thành code chạy thật.

### 4.5 Bảo mật đủ dùng, không diễn

Bỏ "22 lớp". Giữ 8 thứ thật sự chặn được tấn công:

1. Argon2id cho mật khẩu (**không** SHA-256 như bản A)
2. Session token có hash trong DB + xoay vòng + `httpOnly`/`SameSite=Lax`
3. Rate limit **sliding window** theo IP + theo user (bản cũ dùng fixed window, bị bypass ở ranh giới cửa sổ)
4. Zod validate mọi input ở biên
5. Drizzle parameterized query (không nối chuỗi SQL)
6. CSP + security headers
7. RBAC kiểm tra ở tầng service, **không** chỉ ở UI
8. `audit_log` append-only cho mọi hành động thay đổi trạng thái

Cloudflare lo DDoS/WAF — không tự viết `d1_ddos()`.

### 4.6 Không dùng số ngẫu nhiên trong cấu hình hệ thống

`generateAllRoutes()` của Nexus dùng `Math.random()` để quyết định module nào nhận event nào. Hệ quả: hai lần khởi động, hệ thống hành xử khác nhau, không thể debug, không thể test. **Mọi định tuyến phải tường minh trong code.** Đây là lỗi kiến trúc nghiêm trọng nhất trong toàn bộ tài liệu — phải loại bỏ.

### 4.7 Mobile-first + PWA từ ngày đầu

Người học luyện thi trên điện thoại, trong giờ nghỉ, mạng kém.
- Ngưỡng breakpoint: 360 / 768 / 1024
- Vùng chạm ≥ 44px
- Service worker: cache vỏ ứng dụng + bài đang làm; nộp bài khi có mạng trở lại
- Bài thi lưu nháp vào IndexedDB — mất mạng không mất bài

---

## 5. Cấu trúc thư mục

```
src/
├── app/
│   ├── (marketing)/          # landing, pricing, SEO
│   ├── (app)/
│   │   ├── hoc/              # luyện tập adaptive
│   │   ├── thi/              # làm bài thi
│   │   ├── lo-trinh/         # roadmap 9 hệ
│   │   ├── gia-su/           # AI tutor
│   │   └── ho-so/            # tiến độ, streak, huy hiệu
│   ├── (admin)/
│   │   ├── noi-dung/         # soạn & duyệt item
│   │   ├── nguoi-dung/
│   │   ├── kinh-doanh/
│   │   └── van-hanh/         # KPI, health, audit
│   └── api/v1/               # REST cho mobile/tích hợp sau này
├── modules/
│   ├── identity/  catalog/  learning/  assessment/
│   ├── tutor/     commerce/ engagement/ ops/
├── kernel/
│   ├── auth.ts  rbac.ts  constitution.ts  llm.ts
│   ├── events.ts  math-notation.ts  errors.ts  logger.ts
├── db/
│   ├── schema/*.ts  migrations/  seed/
└── ui/                       # shadcn + component riêng (MathRender, ItemCard…)

content/                      # item bank dạng file, review qua PR
├── math/  english/  ielts/  sat/  hsa/  tsa/
tests/
├── unit/  e2e/
```

---

## 6. Hợp đồng API

Giữ tinh thần `{action, args}` của bản cũ nhưng type-safe:

```ts
// Server Action — dùng trong UI Next.js
'use server'
export const nextItem = action
  .schema(z.object({ track: TrackEnum, skillId: z.string().uuid().optional() }))
  .use(requireAuth, requirePermission('bank.next'), checkEntitlement('items_per_day'))
  .handler(async ({ input, ctx }) => catalog.nextItemFor(ctx.user, input))

// REST — cho mobile app / tích hợp sau này
POST /api/v1/actions
{ "action": "learning.nextItem", "args": { "track": "sat" } }
→ { "ok": true, "data": {...}, "meta": { "ms": 42, "traceId": "..." } }
```

Một registry action duy nhất ⇒ RBAC, hiến pháp, audit, rate-limit, entitlement đều kiểm ở một chỗ.

---

## 7. Ngân sách hiệu năng (SLO)

| Chỉ số | Mục tiêu | Cách đạt |
|---|---|---|
| LCP trang học | < 2.0s trên 4G | RSC, ảnh tối ưu, KaTeX lazy |
| `nextItem` p95 | < 150ms | Index đúng, không N+1 |
| Nộp bài thi p95 | < 400ms | Ghi theo lô, tính điểm nền |
| Tutor phản hồi đầu tiên | < 1.2s | Streaming, model nhanh trước |
| Uptime | 99.5% | Vercel + Neon, health check |
| Chi phí LLM / user hoạt động / tháng | < $0.15 | Cache + định tuyến theo bậc |

---

## 8. Bảng chuyển đổi — cũ sang mới

| Tài sản cũ | Xử lý |
|---|---|
| `CONFIG.TOPICS`, `CONFIG.ENG_TOPICS` (12 lớp) | → seed bảng `skills` |
| `MathNotation` | → `kernel/math-notation.ts` + test đầy đủ **(giữ gần nguyên)** |
| `Packages.TIERS` 11 tầng | → seed bảng `packages` **(giữ nguyên)** |
| `Roles.PERMS` | → `kernel/rbac.ts` **(giữ nguyên logic wildcard)** |
| `CONSTITUTION.articles` 50 điều | → `kernel/constitution.ts` **(giữ nguyên)** |
| `LEVELS` của IELTS/SAT/HSA/TSA/SPT | → `modules/learning/tracks/*.ts` **(giữ nguyên dữ liệu)** |
| `*_FORMAT` (số câu, thời gian, trọng số) | → cấu hình blueprint đề thi **(giữ nguyên)** |
| `score-converter.js` × 5 | → `modules/assessment/scoring/*.ts` **(giữ nguyên bảng quy đổi)** |
| `strategy-*.js` | → nội dung tĩnh, hiển thị trong lộ trình |
| Schema SQLite 12 bảng | → Postgres DDL ở §3 **(mở rộng)** |
| `ProblemBank.generate()` | **Thay bằng** pipeline item bank §4.1 |
| `AITutor._callAI()` | **Thay bằng** `kernel/llm.ts` gọi API thật |
| `Security` 22 lớp | **Thay bằng** 8 biện pháp §4.5 |
| Nexus (3 bản) | **Bỏ** |
| Electron | **Bỏ** |

---

## 9. Rủi ro và cách xử

| Rủi ro | Mức | Xử lý |
|---|---|---|
| Không có nội dung thật → sản phẩm rỗng | **Cao** | Item bank là Sprint 3–4, trước mọi tính năng phụ. Thuê 1–2 giáo viên soạn ngay. |
| Lại rơi vào vòng viết lại lần thứ 5 | **Cao** | Đóng băng kiến trúc 6 tháng. Mọi đề xuất mới vào backlog, không vào code. |
| Luật AI VN 134/2025 (giáo dục = rủi ro cao) | **Cao** | Tư vấn luật ở Sprint 1. Chuẩn bị hồ sơ đăng ký Bộ KH&CN **trước** khi mở công khai. |
| Chi phí LLM vượt kiểm soát | Trung bình | Hạn mức cứng/người/ngày + cache + bậc model |
| LLM chấm sai Writing/Speaking | Trung bình | Chấm 2 model, lệch > 1 band → đưa người chấm |
| Phạm vi phình to trở lại | **Cao** | Danh sách "Bỏ hẳn"/"Hoãn" §2.1 là cam kết, không phải gợi ý |
| Kho item bị chép lậu | Thấp–TB | Watermark theo user, giới hạn tốc độ, không trả toàn bộ đáp án ở client |

---

## 10. Một trang tóm tắt

| Câu hỏi | Trả lời |
|---|---|
| Viết bằng gì? | Next.js 15 + TypeScript + PostgreSQL + Drizzle, deploy Vercel |
| Bao nhiêu module? | 8 context + 1 kernel (không phải 232 file) |
| Bao nhiêu bảng? | ~20 |
| Chạy ở đâu? | Trình duyệt điện thoại (PWA), không phải Electron |
| Tốn bao nhiêu? | $0–25/tháng tới 5.000 user |
| Cần mấy người? | 1 full-stack + 1 giáo viên soạn nội dung để ra MVP |
| Bao lâu ra MVP? | 8 tuần cho lát cắt dọc chạy thật; 24 tuần cho bản thương mại |
| Việc quan trọng nhất? | **Kho câu hỏi thật.** Phần còn lại là kỹ thuật thông thường. |

Tiến trình thực hiện: [`03-TIEN-TRINH.md`](./03-TIEN-TRINH.md)
