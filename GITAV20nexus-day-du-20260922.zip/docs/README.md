# GITAmath — Hồ sơ nghiên cứu & phương án

Kết quả đọc toàn bộ folder Drive GITAmath (18 file) và phương án lập trình Web App.

| Tài liệu | Nội dung |
|---|---|
| [`01-HE-THONG-GITAMATH.md`](./01-HE-THONG-GITAMATH.md) | Bản hệ thống đọc được: 18 file, 4 kiến trúc, mô hình nghiệp vụ, đánh giá thật/bản vẽ |
| [`02-PHUONG-AN-WEB-APP.md`](./02-PHUONG-AN-WEB-APP.md) | Kiến trúc tối ưu, stack, 8 bounded context, mô hình dữ liệu, 7 quyết định kỹ thuật |
| [`03-TIEN-TRINH.md`](./03-TIEN-TRINH.md) | 12 sprint × 2 tuần, cổng kiểm, nhân sự, ngân sách |

## Tóm tắt ba dòng

1. Drive chứa **4 kiến trúc khác nhau** cho cùng một sản phẩm, viết lại 4 lần trong 24 giờ, **chưa lần nào được chạy** — hai spreadsheet vẫn rỗng.
2. Tài sản thật là **mô hình nghiệp vụ giáo dục**: 9 hệ đào tạo với format thi chuẩn, chuẩn LaTeX, 11 tầng giá, 14 vai trò, hiến pháp 50 điều. Phần code là bản vẽ.
3. Đề xuất: **một** ứng dụng Next.js + PostgreSQL, 8 module, mobile-first, $0–25/tháng — và coi **kho câu hỏi thật** là sản phẩm, không phải máy sinh template.

> Lưu ý: mã nguồn ở thư mục gốc repo hiện là template "Veo 3 Gallery" của AI Studio, không liên quan GITAmath. Cần quyết định giữ hay dọn trước Sprint 1.
