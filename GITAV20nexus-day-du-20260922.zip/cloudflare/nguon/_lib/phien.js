'use strict';
/**
 * Phiên đăng nhập.
 *
 * Kho chỉ giữ BĂM của thẻ phiên, không giữ thẻ. Ai đọc trộm được bảng
 * user_sessions cũng không dựng lại được thẻ để giả danh — đây là lý do
 * duy nhất khiến cột id của bảng ấy là một chuỗi băm chứ không phải mã
 * ngẫu nhiên đọc thẳng.
 */

const { maMoi, chuoiNgauNhien, sha256, bamMatKhau, kiemMatKhau } = require('./ma.js');
const { VAI } = require('./quyen.js');

const TEN_BANH = 'gita_phien';
const HAN_MAC_DINH_MS = 8 * 3600 * 1000;
const HAN_HOC_VIEN_MS = 4 * 3600 * 1000;   // máy hay dùng chung, rút ngắn lại

function hanTheoVai(vai) {
  return vai === 'LEARNER' ? HAN_HOC_VIEN_MS : HAN_MAC_DINH_MS;
}

/** Đọc thẻ phiên: ưu tiên Authorization, sau đó mới đến bánh quy. */
function docThe(req) {
  const h = req.headers.get('authorization');
  if (h && /^Bearer\s+/i.test(h)) return h.replace(/^Bearer\s+/i, '').trim();
  const banh = req.headers.get('cookie');
  if (!banh) return null;
  for (const phan of banh.split(';')) {
    const i = phan.indexOf('=');
    if (i < 0) continue;
    if (phan.slice(0, i).trim() === TEN_BANH) return phan.slice(i + 1).trim();
  }
  return null;
}

function banhQuy(the, hanMs) {
  return TEN_BANH + '=' + the +
    '; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=' + Math.floor(hanMs / 1000);
}
function banhQuyXoa() {
  return TEN_BANH + '=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0';
}

async function moPhien(kho, nguoi, userAgent, bayGio) {
  const now = bayGio || Date.now();
  const the = chuoiNgauNhien(32);
  const han = hanTheoVai(nguoi.role);
  await kho.chen('user_sessions', {
    id: await sha256(the),
    user_id: nguoi.id,
    created_at: now,
    expires_at: now + han,
    user_agent: (userAgent || '').slice(0, 200) || null,
  });
  await kho.chay('UPDATE users SET last_login_at = ?, updated_at = ? WHERE id = ?',
    [now, now, nguoi.id]);
  return { the, hanMs: han, hetLuc: now + han };
}

/** Trả về người dùng nếu thẻ còn hiệu lực, ngược lại null. Không ném lỗi. */
async function doiThe(kho, the, bayGio) {
  if (!the || typeof the !== 'string' || the.length < 32) return null;
  const now = bayGio || Date.now();
  const r = await kho.mot(
    'SELECT s.id AS phien, s.expires_at, s.revoked_at, u.* FROM user_sessions s ' +
    'JOIN users u ON u.id = s.user_id WHERE s.id = ?', [await sha256(the)]);
  if (!r) return null;
  if (r.revoked_at) return null;
  if (Number(r.expires_at) <= now) return null;
  if (r.status !== 'ACTIVE') return null;
  return {
    phien: r.phien,
    id: r.id, email: r.email, ten: r.full_name, vai: r.role,
    hetLuc: Number(r.expires_at),
  };
}

async function dongPhien(kho, maPhien, bayGio) {
  const r = await kho.chay('UPDATE user_sessions SET revoked_at = ? WHERE id = ? AND revoked_at IS NULL',
    [bayGio || Date.now(), maPhien]);
  return (r && r.meta && r.meta.changes) || (r && r.changes) || 0;
}

async function dongHetPhienCua(kho, userId, bayGio) {
  const r = await kho.chay(
    'UPDATE user_sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL',
    [bayGio || Date.now(), userId]);
  return (r && r.meta && r.meta.changes) || (r && r.changes) || 0;
}

/** Dọn phiên đã hết hạn — gọi từ lịch Cron, không làm trong đường chính. */
async function quetPhienHetHan(kho, bayGio) {
  const r = await kho.chay('DELETE FROM user_sessions WHERE expires_at < ?',
    [(bayGio || Date.now()) - 7 * 24 * 3600 * 1000]);
  return (r && r.meta && r.meta.changes) || (r && r.changes) || 0;
}

/**
 * Luật mật khẩu — vai càng cao càng ngặt, giống hệ Node V20.
 * Trả về mảng lời chê; rỗng nghĩa là đạt.
 */
function soiMatKhau(matKhau, vai) {
  const p = String(matKhau || '');
  const v = VAI[vai] || VAI.LEARNER;
  const che = [];
  if (p.length < v.doDaiMatKhauToiThieu) {
    che.push('phải từ ' + v.doDaiMatKhauToiThieu + ' ký tự trở lên');
  }
  const nhom = [/[a-z]/, /[A-Z]/, /[0-9]/, /[^A-Za-z0-9]/].filter((re) => re.test(p)).length;
  const canNhom = v.bac >= 60 ? 3 : 2;
  if (nhom < canNhom) {
    che.push('phải có ít nhất ' + canNhom + ' nhóm ký tự (thường, hoa, số, ký hiệu)');
  }
  if (p && /^(.)\1+$/.test(p)) che.push('không được là một ký tự lặp lại');
  const thuong = p.toLowerCase();
  for (const xau of ['gita', 'matkhau', 'password', '123456', 'qwerty', 'admin', 'hocsinh', 'giaovien']) {
    if (thuong.includes(xau)) { che.push('không được chứa "' + xau + '"'); break; }
  }
  return che;
}

module.exports = {
  TEN_BANH, docThe, banhQuy, banhQuyXoa, moPhien, doiThe, dongPhien, dongHetPhienCua,
  quetPhienHetHan, soiMatKhau, hanTheoVai, bamMatKhau, kiemMatKhau, maMoi,
};
