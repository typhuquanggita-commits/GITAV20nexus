'use strict';
/**
 * Bảng phân quyền — một bảng khai báo, không rải if rác khắp nơi.
 *
 * Lấy đúng ma trận đang chạy ở hệ Node V20 rồi thêm SUPER_ADMIN ở trên
 * cùng. Ba hậu tố có ý nghĩa riêng:
 *   :own    — chỉ trên dữ liệu của chính mình
 *   :scope  — chỉ trong lớp/trường được gán
 *   (không) — trên toàn hệ thống
 *
 * SUPER_ADMIN vẫn KHÔNG được vài việc, cố tình. Xem CAM_TUYET_DOI.
 */

const VAI = {
  SUPER_ADMIN: { ten: 'Quản trị tối cao', bac: 100, doDaiMatKhauToiThieu: 16 },
  ADMIN:       { ten: 'Quản trị viên',    bac: 80,  doDaiMatKhauToiThieu: 12 },
  TEACHER:     { ten: 'Giáo viên',        bac: 60,  doDaiMatKhauToiThieu: 10 },
  PARENT:      { ten: 'Phụ huynh',        bac: 40,  doDaiMatKhauToiThieu: 8 },
  LEARNER:     { ten: 'Học viên',         bac: 20,  doDaiMatKhauToiThieu: 8 },
  GUEST:       { ten: 'Khách',            bac: 0,   doDaiMatKhauToiThieu: 8 },
};

const QUYEN = {
  SUPER_ADMIN: [
    '*',
  ],
  ADMIN: [
    'user.create', 'user.read', 'user.update', 'user.disable', 'user.reset_password',
    'school.*', 'class.*', 'learner.*', 'item.*', 'exam.*', 'practice.read',
    'report.*', 'agents.read', 'mission.run', 'curriculum.read', 'import.*', 'export.*',
    'course.*', 'cohort.*', 'event.*', 'org.*', 'audit.read', 'analytics.read',
    'content.moderate', 'cert.issue', 'ai.use',
    // Miền GITAV20nexus
    'curriculum.write', 'bank.*', 'exam.build', 'exam.grade', 'camp.manage',
    'brain.read', 'brain.assign', 'crm.*', 'survey.*', 'roadmap.manage',
    'video.manage', 'ketoan.read', 'ketoan.post', 'cay-tien.admin',
  ],
  TEACHER: [
    'class.read:scope', 'class.update:scope',
    'learner.read:scope', 'learner.create:scope', 'learner.update:scope',
    'item.read', 'item.create', 'item.review',
    'exam.assign:scope', 'exam.read:scope',
    'practice.read:scope', 'report.read:scope', 'report.export:scope',
    'curriculum.read', 'import.learners:scope', 'export.class:scope',
    'course.create', 'course.update:own', 'cohort.manage:scope',
    'content.moderate:scope', 'analytics.read:scope', 'ai.use',
    // Miền GITAV20nexus — giáo viên làm nội dung, không đụng tiền
    'bank.read', 'bank.create', 'bank.review', 'exam.build', 'exam.grade:scope',
    'camp.manage:scope', 'survey.read:scope', 'survey.run:scope',
    'roadmap.manage:scope', 'video.manage', 'brain.read',
  ],
  PARENT: [
    'learner.read:scope', 'practice.read:scope', 'report.read:scope',
    'exam.read:scope', 'curriculum.read', 'ai.use',
    'survey.run:scope', 'crm.read:scope',
  ],
  LEARNER: [
    'learner.read:own', 'practice.start:own', 'practice.answer:own', 'practice.read:own',
    'exam.take:own', 'exam.read:own', 'report.read:own', 'item.read:assigned',
    'curriculum.read', 'course.enroll:own', 'ai.use',
    'bank.read:assigned', 'survey.run:own', 'roadmap.read:own', 'camp.join:own',
  ],
  GUEST: ['curriculum.read'],
};

/**
 * Việc không ai được làm qua đường HTTP, kể cả SUPER_ADMIN.
 *
 * Đây không phải trang trí. Mỗi dòng dưới đây là một việc mà nếu mở ra
 * thì một thẻ phiên bị lấy cắp là đủ để mất trắng, nên nó phải đi qua
 * đường khác (wrangler, bảng điều khiển Cloudflare, quy trình hai người).
 */
const CAM_TUYET_DOI = {
  'db.drop':        'Xoá bảng phải làm bằng wrangler, có người thứ hai xác nhận.',
  'user.read_password': 'Mật khẩu chỉ tồn tại ở dạng băm; không có đường nào đọc ra được.',
  'audit.delete':   'Nhật ký kiểm toán nối chuỗi băm; xoá một dòng là tự khai đã sửa.',
  'secret.read':    'Khoá API nằm ở biến môi trường của Cloudflare, không đi qua HTTP.',
  'cay-tien.read':  'Cây tiền chỉ hiện trong hệ quản trị GITAV20nexus, không ra đường công khai.',
};

function coQuyen(vai, can) {
  const ds = QUYEN[vai];
  if (!ds) return false;
  if (CAM_TUYET_DOI[can]) return false;       // cấm trước, xét sau
  for (const q of ds) {
    if (q === '*') return true;
    if (q === can) return true;
    // 'report.*' phủ 'report.read' và 'report.read:scope'
    if (q.endsWith('.*')) {
      const goc = q.slice(0, -2);
      if (can === goc || can.startsWith(goc + '.')) return true;
    }
    // 'learner.read:scope' phủ yêu cầu 'learner.read' trong phạm vi
    const [qGoc] = q.split(':');
    const [cGoc] = can.split(':');
    if (qGoc === cGoc && q.includes(':') && !can.includes(':')) return true;
  }
  return false;
}

/** Phạm vi rộng nhất mà vai này có với một việc: 'he-thong' | 'pham-vi' | 'minh' | null */
function phamVi(vai, viecGoc) {
  const ds = QUYEN[vai] || [];
  if (CAM_TUYET_DOI[viecGoc]) return null;
  if (ds.includes('*')) return 'he-thong';
  let rong = null;
  for (const q of ds) {
    const [g, hau] = q.split(':');
    const khop = g === viecGoc ||
      (g.endsWith('.*') && viecGoc.startsWith(g.slice(0, -2) + '.')) ||
      (g.endsWith('.*') && viecGoc === g.slice(0, -2));
    if (!khop) continue;
    const m = !hau ? 'he-thong' : hau === 'scope' ? 'pham-vi' : 'minh';
    if (m === 'he-thong') return 'he-thong';
    if (m === 'pham-vi') rong = 'pham-vi';
    else if (!rong) rong = 'minh';
  }
  return rong;
}

function caoHon(vaiA, vaiB) {
  return (VAI[vaiA] ? VAI[vaiA].bac : -1) > (VAI[vaiB] ? VAI[vaiB].bac : -1);
}

/** Bảng phân quyền dạng dữ liệu, để trang /phan-quyen.html vẽ ra được. */
function banPhanQuyen() {
  const viec = [...new Set(Object.values(QUYEN).flat().filter((q) => q !== '*')
    .map((q) => q.split(':')[0]))].sort();
  return {
    vai: Object.keys(VAI).map((m) => Object.assign({ ma: m }, VAI[m])),
    viec: viec,
    luoi: viec.map((v) => ({
      viec: v,
      theoVai: Object.fromEntries(Object.keys(VAI).map((m) => [m, phamVi(m, v)])),
    })),
    camTuyetDoi: Object.entries(CAM_TUYET_DOI).map(([ma, vi]) => ({ ma, lyDo: vi })),
  };
}

module.exports = { VAI, QUYEN, CAM_TUYET_DOI, coQuyen, phamVi, caoHon, banPhanQuyen };
