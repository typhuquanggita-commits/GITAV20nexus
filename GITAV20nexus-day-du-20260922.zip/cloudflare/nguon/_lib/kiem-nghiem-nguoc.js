'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  KIỂM NGHIỆM NGƯỢC — thử lại một ngưỡng trên dữ liệu đã có
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Hệ thống đang đặt ngưỡng vượt cấp là 90% trên 60 bài. Câu hỏi không
 *  ai hỏi: con số ấy ĐÚNG không? Nó dự báo được gì không, hay chỉ là
 *  một con số tròn trịa nghe hợp lý?
 *
 *  Tệp này trả lời bằng cách duy nhất trả lời được: dựng lại đúng cảnh
 *  ngày hôm đó, quyết định bằng ngưỡng ấy, rồi nhìn xem cái gì thật sự
 *  đã xảy ra sau đó.
 *
 *  BỐN LUẬT KHÔNG PHÁ:
 *
 *  1. CẮT ĐÚNG MỐC. Tính ngưỡng chỉ bằng dữ liệu có TRƯỚC mốc; đo kết
 *     quả chỉ bằng dữ liệu SAU mốc. Lẫn một chút là phép đo thành vô
 *     nghĩa mà vẫn ra những con số rất đẹp — đây là kiểu sai nguy hiểm
 *     nhất vì nó không trông giống sai.
 *
 *  2. CHIA THEO THỜI GIAN, KHÔNG CHIA NGẪU NHIÊN. Học trước, kiểm sau.
 *     Trộn ngẫu nhiên là để tương lai rò ngược vào quá khứ.
 *
 *  3. NÓI CẢ HAI PHÍA. Một ngưỡng chặt thì ít người qua mà qua rồi hay
 *     đạt; một ngưỡng lỏng thì ngược lại. Báo cáo phải có cả tỉ lệ bỏ
 *     sót lẫn tỉ lệ báo nhầm, không chỉ chọn con số đẹp.
 *
 *  4. KHÔNG TỰ ĐỔI NGƯỠNG. Chỉ đề xuất, kèm số. Người quyết vẫn là người.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const tk = require('./thong-ke.js');
const dtt = require('./do-tin-hieu.js');

const NGAY = 86400000;
const MAU_TOI_THIEU = 30;

/**
 * Lấy mẫu các cặp (người học, mốc thời gian) từ dữ liệu thật.
 *
 * Mốc lấy đều theo tuần, không lấy ngẫu nhiên — để chạy lại cho ra đúng
 * một kết quả, và để mẫu không dồn vào một quãng.
 */
async function layMau(kho, tuMs, denMs, buocNgay) {
  const buoc = (buocNgay || 7) * NGAY;
  const nguoi = await kho.nhieu(
    'SELECT DISTINCT l.user_id FROM luot_thi l WHERE l.bat_dau BETWEEN ? AND ? LIMIT 5000',
    [tuMs, denMs]);
  const ra = [];
  for (const n of nguoi) {
    const nhom = await dtt.nhomCua(kho, n.user_id);
    for (let m = tuMs + buoc; m < denMs; m += buoc) {
      ra.push({ userId: n.user_id, moc: m, nhom });
    }
  }
  return ra;
}

/**
 * Thử một ngưỡng: ai qua ngưỡng ở mốc, và sau đó họ ra sao.
 *
 * @param nguong  { tiLe, soBaiToiThieu }
 * @param dich    { tiLeSau }  coi là "đạt" nếu tỉ lệ đúng sau mốc ≥ mức này
 */
async function thuNguong(kho, mau, nguong, dich, soNgaySau) {
  const nSau = soNgaySau || 30;
  const mucDat = dich && dich.tiLeSau !== undefined ? dich.tiLeSau : 0.85;

  let quaVaDat = 0, quaMaKhong = 0, khongQuaMaDat = 0, khongQuaVaKhong = 0;
  let boQua = 0;
  const diemDat = [], diemKhongDat = [];

  for (const m of mau) {
    const truoc = await kho.mot(
      'SELECT COUNT(*) AS n, COALESCE(SUM(t.dung),0) AS d ' +
      'FROM luot_thi_tra_loi t JOIN luot_thi l ON l.id = t.luot_id ' +
      'WHERE l.user_id = ? AND t.at < ? AND t.dung IS NOT NULL', [m.userId, m.moc]);
    const nTruoc = Number(truoc.n);
    const sau = await dtt.ketQuaSau(kho, m.userId, m.moc, nSau);
    if (!sau) { boQua += 1; continue; }

    const tiLeTruoc = nTruoc ? Number(truoc.d) / nTruoc : 0;
    const qua = nTruoc >= nguong.soBaiToiThieu && tiLeTruoc >= nguong.tiLe;
    const dat = sau.giaTri >= mucDat;

    if (qua && dat) quaVaDat += 1;
    else if (qua && !dat) quaMaKhong += 1;
    else if (!qua && dat) khongQuaMaDat += 1;
    else khongQuaVaKhong += 1;

    (dat ? diemDat : diemKhongDat).push(tiLeTruoc);
  }

  const tong = quaVaDat + quaMaKhong + khongQuaMaDat + khongQuaVaKhong;
  if (tong < MAU_TOI_THIEU) {
    return {
      duMau: false, coMau: tong, boQua,
      noiThang: 'Chỉ dựng lại được ' + tong + ' trường hợp, cần ít nhất ' + MAU_TOI_THIEU
        + '. Chưa kiểm nghiệm được ngưỡng này — và nói thế còn hơn đưa ra một tỉ lệ '
        + 'phần trăm tính trên vài trường hợp.',
    };
  }

  const soQua = quaVaDat + quaMaKhong;
  const soDat = quaVaDat + khongQuaMaDat;
  const chinhXacKhiQua = soQua ? quaVaDat / soQua : null;       // qua ngưỡng thì có đạt thật không
  const batDuoc = soDat ? quaVaDat / soDat : null;              // người đạt thật thì ngưỡng có bắt được không
  const baoNham = soQua ? quaMaKhong / soQua : null;
  const boSot = soDat ? khongQuaMaDat / soDat : null;

  return {
    duMau: true, coMau: tong, boQua,
    nguong, mucDat, soNgaySau: nSau,
    bang: { quaVaDat, quaMaKhong, khongQuaMaDat, khongQuaVaKhong },
    chinhXacKhiQua: r4(chinhXacKhiQua),
    batDuoc: r4(batDuoc),
    baoNham: r4(baoNham),
    boSot: r4(boSot),
    // Tỉ lệ nền: nếu cho tất cả qua thì bao nhiêu phần trăm vẫn đạt.
    // Ngưỡng nào không vượt được con số này là ngưỡng vô dụng.
    tiLeNen: r4(tong ? soDat / tong : null),
    honMucNen: chinhXacKhiQua !== null && tong
      ? r4(chinhXacKhiQua - soDat / tong) : null,
    noiThang: noiVeNguong(chinhXacKhiQua, soDat / tong, boSot, tong),
  };
}

const r4 = (x) => (x === null || x === undefined ? null : Number(x.toFixed(4)));

function noiVeNguong(chinhXac, nen, boSot, tong) {
  if (chinhXac === null) {
    return 'Không ai qua ngưỡng trên mẫu này — ngưỡng đang chặt tới mức không dùng được.';
  }
  const hon = chinhXac - nen;
  if (hon <= 0.02) {
    return 'Ngưỡng này gần như KHÔNG nói thêm được gì: người qua ngưỡng đạt '
      + (chinhXac * 100).toFixed(1) + '%, trong khi cho tất cả qua thì vẫn đạt '
      + (nen * 100).toFixed(1) + '%. Chênh ' + (hon * 100).toFixed(1)
      + ' điểm phần trăm trên ' + tong + ' trường hợp.';
  }
  const phanBoSot = boSot === null ? '' :
    ' Nhưng nó bỏ sót ' + (boSot * 100).toFixed(1)
    + '% số người lẽ ra đã đạt — họ bị giữ lại mà không cần thiết.';
  return 'Ngưỡng có tác dụng: người qua ngưỡng đạt ' + (chinhXac * 100).toFixed(1)
    + '%, cao hơn mức nền ' + (nen * 100).toFixed(1) + '% là '
    + (hon * 100).toFixed(1) + ' điểm.' + phanBoSot;
}

/**
 * Quét một dải ngưỡng để xem đâu là chỗ đổi nhiều nhất.
 * KHÔNG chọn hộ, chỉ bày ra cả dải cùng số đo.
 */
async function quetDaiNguong(kho, mau, dsTiLe, soBaiToiThieu, dich, soNgaySau) {
  const ra = [];
  for (const t of dsTiLe) {
    const r = await thuNguong(kho, mau, { tiLe: t, soBaiToiThieu }, dich, soNgaySau);
    ra.push(Object.assign({ tiLe: t }, r));
  }
  const dung = ra.filter((x) => x.duMau && x.honMucNen !== null);
  const tot = dung.length
    ? dung.reduce((a, b) => (b.honMucNen > a.honMucNen ? b : a))
    : null;
  return {
    dai: ra,
    deXuat: tot ? { tiLe: tot.tiLe, honMucNen: tot.honMucNen,
      chinhXacKhiQua: tot.chinhXacKhiQua, boSot: tot.boSot } : null,
    noiThang: tot
      ? 'Trên dải đã thử, ngưỡng ' + (tot.tiLe * 100).toFixed(0) + '% cho chênh lệch so với '
        + 'mức nền lớn nhất. Đây là ĐỀ XUẤT kèm số đo, không phải một thay đổi đã áp dụng — '
        + 'đổi ngưỡng vượt cấp là việc của người.'
      : 'Chưa dải nào đủ mẫu để đề xuất. Không đề xuất gì còn hơn đề xuất trên mẫu mỏng.',
  };
}

/**
 * Chia theo thời gian: học trên nửa đầu, kiểm trên nửa sau.
 *
 * Một ngưỡng chọn ra từ chính dữ liệu rồi đem khoe trên chính dữ liệu ấy
 * thì bao giờ cũng đẹp. Phép chia này là cách duy nhất biết nó có còn
 * đẹp trên quãng chưa từng nhìn hay không.
 */
async function hocTruocKiemSau(kho, tuMs, denMs, dsTiLe, soBaiToiThieu, dich, soNgaySau) {
  const giua = tuMs + Math.floor((denMs - tuMs) / 2);
  const mauHoc = await layMau(kho, tuMs, giua, 7);
  const mauKiem = await layMau(kho, giua, denMs, 7);

  const hoc = await quetDaiNguong(kho, mauHoc, dsTiLe, soBaiToiThieu, dich, soNgaySau);
  if (!hoc.deXuat) {
    return { duMau: false, noiThang: 'Nửa đầu không đủ mẫu để chọn ngưỡng. ' + hoc.noiThang };
  }
  const kiem = await thuNguong(kho, mauKiem,
    { tiLe: hoc.deXuat.tiLe, soBaiToiThieu }, dich, soNgaySau);

  const giuDuoc = kiem.duMau && kiem.honMucNen !== null
    && kiem.honMucNen > 0.02;
  return {
    duMau: kiem.duMau,
    mocChia: giua,
    nuaDau: { soMau: mauHoc.length, deXuat: hoc.deXuat },
    nuaSau: kiem,
    giuDuocTrenQuangMoi: giuDuoc,
    noiThang: !kiem.duMau
      ? 'Nửa sau không đủ mẫu để kiểm. Ngưỡng chọn ở nửa đầu KHÔNG được coi là đã kiểm.'
      : (giuDuoc
        ? 'Ngưỡng chọn ở nửa đầu vẫn có tác dụng trên nửa sau — đây là điều đáng tin hơn '
          + 'nhiều so với một con số chỉ đẹp trên chính dữ liệu đã dùng để chọn nó.'
        : 'Ngưỡng chọn ở nửa đầu KHÔNG giữ được tác dụng trên nửa sau. Nghĩa là con số '
          + 'đẹp ở nửa đầu chỉ là khớp với nhiễu. Đừng dùng.'),
  };
}

/**
 * Tình huống giả định: cắt bớt một phần số bài rồi xem ngưỡng còn đứng không.
 * Không sinh dữ liệu mới — chỉ BỚT dữ liệu thật đi, nên không bịa gì cả.
 */
async function thuTinhHuong(kho, mau, nguong, dich, soNgaySau, giuLai) {
  const ty = giuLai === undefined ? 0.5 : giuLai;
  // Giữ lại một phần mẫu theo cách tất định: băm mã người học.
  const loc = mau.filter((m) => {
    let h = 0;
    for (let i = 0; i < m.userId.length; i++) h = (h * 31 + m.userId.charCodeAt(i)) % 1000;
    return h < ty * 1000;
  });
  const r = await thuNguong(kho, loc, nguong, dich, soNgaySau);
  return Object.assign({ giuLai: ty, soMauConLai: loc.length }, r);
}

module.exports = {
  layMau, thuNguong, quetDaiNguong, hocTruocKiemSau, thuTinhHuong,
  noiVeNguong, MAU_TOI_THIEU,
};
