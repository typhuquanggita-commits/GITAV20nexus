'use strict';
/**
 * Kho đệm ba tầng — L1 KV (nóng), L2 D1 (ấm), L3 vectơ (gần giống).
 *
 * Ý đồ: 60–80% câu hỏi trùng nhau, nên đừng đốt hạn mức AI cho cùng một
 * câu hai lần.
 *
 * Một giới hạn phải nói thẳng: tầng L3 so khớp bằng cosin trên vectơ
 * nhúng. Nếu chưa gắn Vectorize thì tầng này tự tắt chứ không giả vờ
 * chạy — cachTimGanGiong() trả về null và mọi thứ vẫn đúng, chỉ là
 * tiết kiệm ít hơn.
 */

const { maMoi, sha256 } = require('./ma.js');

const NGUONG_GAN_GIONG = 0.93;    // dưới mức này coi là câu khác
const HAN_MAC_DINH_MS = 7 * 24 * 3600 * 1000;
const L3_TOI_DA_SO_SANH = 200;    // chỉ so với 200 câu gần nhất cùng loại

/** Khoá đệm = băm của (lời nhắc + mẫu máy + tham số) — đúng như đặc tả. */
async function khoaCua(loaiDem, loiNhac, mauMay, thamSo) {
  const than = [loaiDem, loiNhac || '', mauMay || '', JSON.stringify(thamSo || {})].join('\u0000');
  return sha256(than);
}

function tichVoHuong(a, b) {
  let t = 0;
  for (let i = 0; i < a.length; i++) t += a[i] * b[i];
  return t;
}
function doDai(a) {
  return Math.sqrt(tichVoHuong(a, a));
}
/** Cosin hai vectơ; trả 0 nếu một trong hai là vectơ không. */
function cosin(a, b) {
  if (!a || !b || a.length !== b.length || a.length === 0) return 0;
  const m = doDai(a) * doDai(b);
  return m === 0 ? 0 : tichVoHuong(a, b) / m;
}

function KhoNghia(kho, kv, dongHo) {
  const bayGio = dongHo || (() => Date.now());

  async function lay(loaiDem, khoa) {
    // L1 — KV, nhanh nhất, nhưng bậc miễn phí chỉ cho 1.000 lượt GHI/ngày
    // nên chỉ đọc ở đây, ghi thì dè dặt (xem ghiL1DuocKhong).
    if (kv) {
      try {
        const v = await kv.get('dem:' + loaiDem + ':' + khoa, 'json');
        if (v && Number(v.hetLuc) > bayGio()) {
          return { tang: 'L1', gtri: v.gtri, theTietKiem: Number(v.theTietKiem) || 0 };
        }
      } catch (e) { /* KV hỏng thì rơi xuống L2, không làm đổ cả yêu cầu */ }
    }

    // L2 — D1
    const r = await kho.mot('SELECT * FROM semantic_cache_warm WHERE content_hash = ?', [khoa]);
    if (r && Number(r.expires_at) > bayGio()) {
      await kho.chay(
        'UPDATE semantic_cache_warm SET hit_count = hit_count + 1, last_hit_at = ? ' +
        'WHERE content_hash = ?', [bayGio(), khoa]);
      return { tang: 'L2', gtri: JSON.parse(r.response_json),
        theTietKiem: Number(r.tokens_saved) || 0 };
    }
    return null;
  }

  /**
   * L3 — tìm câu đã hỏi gần giống. Cần vectơ nhúng của câu hỏi mới.
   * Không có vectơ thì trả null, không đoán.
   */
  async function layGanGiong(loaiDem, vecto, nguong) {
    if (!vecto || !vecto.length) return null;
    const muc = nguong || NGUONG_GAN_GIONG;
    const ds = await kho.nhieu(
      'SELECT cache_key, prompt_text, embedding_json FROM semantic_cache_index ' +
      'WHERE cache_type = ? ORDER BY created_at DESC LIMIT ?', [loaiDem, L3_TOI_DA_SO_SANH]);
    let tot = null;
    for (const d of ds) {
      let v;
      try { v = JSON.parse(d.embedding_json); } catch (e) { continue; }
      const diem = cosin(vecto, v);
      if (!tot || diem > tot.diem) tot = { diem, khoa: d.cache_key, cau: d.prompt_text };
    }
    if (!tot || tot.diem < muc) return null;
    const r = await kho.mot('SELECT * FROM semantic_cache_warm WHERE content_hash = ?', [tot.khoa]);
    if (!r || Number(r.expires_at) <= bayGio()) return null;
    await kho.chay(
      'UPDATE semantic_cache_warm SET hit_count = hit_count + 1, last_hit_at = ? ' +
      'WHERE content_hash = ?', [bayGio(), tot.khoa]);
    return { tang: 'L3', gtri: JSON.parse(r.response_json), giong: Number(tot.diem.toFixed(4)),
      cauCu: tot.cau, theTietKiem: Number(r.tokens_saved) || 0 };
  }

  async function dat(loaiDem, khoa, gtri, theTietKiem, hanMs, loiNhac, vecto) {
    const now = bayGio();
    const hetLuc = now + (hanMs || HAN_MAC_DINH_MS);
    const than = JSON.stringify(gtri);
    await kho.chay(
      'INSERT INTO semantic_cache_warm ' +
      '(content_hash, cache_type, response_json, tokens_saved, hit_count, last_hit_at, created_at, expires_at) ' +
      'VALUES (?, ?, ?, ?, 0, ?, ?, ?) ' +
      'ON CONFLICT(content_hash) DO UPDATE SET ' +
      '  response_json = excluded.response_json, tokens_saved = excluded.tokens_saved, ' +
      '  last_hit_at = excluded.last_hit_at, expires_at = excluded.expires_at',
      [khoa, loaiDem, than, theTietKiem || 0, now, now, hetLuc]);

    if (vecto && vecto.length && loiNhac) {
      await kho.chen('semantic_cache_index', {
        id: maMoi(), cache_key: khoa, prompt_text: String(loiNhac).slice(0, 4000),
        cache_type: loaiDem, embedding_json: JSON.stringify(vecto), created_at: now,
      });
    }

    if (kv) {
      try {
        await kv.put('dem:' + loaiDem + ':' + khoa,
          JSON.stringify({ gtri, hetLuc, theTietKiem: theTietKiem || 0 }),
          { expirationTtl: Math.max(60, Math.floor((hetLuc - now) / 1000)) });
      } catch (e) { /* hết hạn mức ghi KV thì L2 vẫn gánh được */ }
    }
  }

  async function donHetHan() {
    const r = await kho.chay('DELETE FROM semantic_cache_warm WHERE expires_at < ?', [bayGio()]);
    const n = (r && r.meta && r.meta.changes) || (r && r.changes) || 0;
    await kho.chay(
      'DELETE FROM semantic_cache_index WHERE cache_key NOT IN ' +
      '(SELECT content_hash FROM semantic_cache_warm)');
    return n;
  }

  async function tinhHinh() {
    const w = await kho.mot(
      'SELECT COUNT(*) AS so, COALESCE(SUM(hit_count),0) AS trung, ' +
      '       COALESCE(SUM(hit_count * tokens_saved),0) AS the ' +
      'FROM semantic_cache_warm WHERE expires_at > ?', [bayGio()]);
    const i = await kho.dem('SELECT COUNT(*) FROM semantic_cache_index');
    return {
      soMuc: Number(w.so) || 0,
      luotTrung: Number(w.trung) || 0,
      theDaTietKiem: Number(w.the) || 0,
      soVecto: i,
      coL1: !!kv,
      nguongGanGiong: NGUONG_GAN_GIONG,
    };
  }

  return { khoaCua, lay, layGanGiong, dat, donHetHan, tinhHinh, cosin };
}

module.exports = { KhoNghia, cosin, khoaCua, NGUONG_GAN_GIONG };
