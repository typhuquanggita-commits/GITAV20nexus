'use strict';
/**
 * GIEO DỮ LIỆU NỀN.
 *
 * Chạy lại bao nhiêu lần cũng ra đúng một kết quả: mỗi câu đều là
 * INSERT … ON CONFLICT DO UPDATE trên khoá tự nhiên, không phải INSERT
 * mù. Gieo hai lần không nhân đôi gì cả — đây là điều kiện để gieo
 * được từ lịch Cron mà không sợ.
 *
 * Gieo KHÔNG tạo ra bài tập, chuyên đề hay học viên. Nó chỉ dựng khung:
 * môn, cấp độ, ô chương trình, kỳ thi, trại, bộ máy, hệ thống tài khoản,
 * hiến pháp. Nội dung học là việc của con người và của quy trình soạn —
 * máy không tự đẻ ra 800.000 bài được, và hệ thống không giả vờ là có.
 */

const bg = require('./bang-goc.js');
const tc = require('./to-chuc.js');
const hp = require('./hien-phap.js');
const { BO, CANH_BAO_CHUNG } = require('./bo-phieu.js');
const { maMoi } = require('./ma.js');

async function gieo(kho, bayGio) {
  const now = bayGio || Date.now();
  const dem = {};

  // ── Môn học ──
  for (const m of bg.MON_HOC) {
    await kho.chay(
      'INSERT INTO mon_hoc (id, ten, ten_en, thu_tu, mo_ta) VALUES (?, ?, ?, ?, ?) ' +
      'ON CONFLICT(id) DO UPDATE SET ten = excluded.ten, ten_en = excluded.ten_en, ' +
      '  thu_tu = excluded.thu_tu, mo_ta = excluded.mo_ta',
      [m.id, m.ten, m.ten_en, m.thu_tu, m.mo_ta]);
  }
  dem.monHoc = bg.MON_HOC.length;

  // ── Cấp độ ──
  for (const c of bg.CAP_DO) {
    await kho.chay(
      'INSERT INTO cap_do (id, ten, thu_tu, dich_den, dieu_kien_vao) VALUES (?, ?, ?, ?, ?) ' +
      'ON CONFLICT(id) DO UPDATE SET ten = excluded.ten, thu_tu = excluded.thu_tu, ' +
      '  dich_den = excluded.dich_den, dieu_kien_vao = excluded.dieu_kien_vao',
      [c.id, c.ten, c.thu_tu, c.dich_den, c.dieu_kien_vao]);
  }
  dem.capDo = bg.CAP_DO.length;

  // ── Ô chương trình: môn × lớp × cấp độ ──
  // Cấp Đại học chỉ mở từ lớp 10, và cấp Quốc tế từ lớp 6 — mở sớm hơn
  // là bày ra một ô rỗng mà không ai vào được.
  let soO = 0;
  for (const m of bg.MON_HOC) {
    for (let lop = 1; lop <= 12; lop++) {
      for (const c of bg.CAP_DO) {
        if (c.id === 'dai-hoc' && lop < 10) continue;
        if (c.id === 'quoc-te' && lop < 6) continue;
        if (c.id === 'chuyen' && lop < 5) continue;
        const id = m.id + '-l' + lop + '-' + c.id;
        await kho.chay(
          'INSERT INTO o_chuong_trinh (id, mon_id, lop, cap_do_id, mo_ta) VALUES (?, ?, ?, ?, ?) ' +
          'ON CONFLICT(mon_id, lop, cap_do_id) DO UPDATE SET mo_ta = excluded.mo_ta',
          [id, m.id, lop, c.id, m.ten + ' lớp ' + lop + ' — cấp ' + c.ten + '. ' + c.dich_den]);
        // Mỗi ô có sẵn một dòng phủ sóng để đếm lại, khởi đầu bằng không.
        await kho.chay(
          'INSERT INTO phu_song (id, o_id, dem_luc) VALUES (?, ?, ?) ' +
          'ON CONFLICT(o_id) DO NOTHING', [id, id, now]);
        soO++;
      }
    }
  }
  dem.oChuongTrinh = soO;

  // ── Kỳ thi ──
  for (const k of bg.KY_THI) {
    await kho.chay(
      'INSERT INTO ky_thi (id, ten, ngan, diem_toi_da, don_vi_diem, co_quan, ghi_chu) ' +
      'VALUES (?, ?, ?, ?, ?, ?, ?) ' +
      'ON CONFLICT(id) DO UPDATE SET ten = excluded.ten, ngan = excluded.ngan, ' +
      '  diem_toi_da = excluded.diem_toi_da, co_quan = excluded.co_quan, ghi_chu = excluded.ghi_chu',
      [k.id, k.ten, k.ngan, k.diem_toi_da, k.don_vi_diem, k.co_quan, k.ghi_chu]);
  }
  dem.kyThi = bg.KY_THI.length;

  // ── Trại ──
  for (const t of bg.TRAI) {
    await kho.chay(
      'INSERT INTO trai (id, ten, muc_tieu, lop_tu, lop_den, so_ngay, so_gio, ' +
      '  nguong_vao_json, nguong_ra_json, mo_ta) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ' +
      'ON CONFLICT(id) DO UPDATE SET ten = excluded.ten, muc_tieu = excluded.muc_tieu, ' +
      '  nguong_vao_json = excluded.nguong_vao_json, nguong_ra_json = excluded.nguong_ra_json',
      [t.id, t.ten, t.muc_tieu, t.lop_tu, t.lop_den, t.so_ngay, t.so_gio,
        JSON.stringify(t.nguong_vao), JSON.stringify(t.nguong_ra), t.muc_tieu]);
  }
  dem.trai = bg.TRAI.length;

  // ── Ban chuyên môn và 600 trợ lý ──
  for (const b of tc.BAN) {
    await kho.chay(
      'INSERT INTO ban_chuyen_mon (id, ten, nhiem_vu, so_tro_ly) VALUES (?, ?, ?, ?) ' +
      'ON CONFLICT(id) DO UPDATE SET ten = excluded.ten, nhiem_vu = excluded.nhiem_vu, ' +
      '  so_tro_ly = excluded.so_tro_ly',
      [b.id, b.ten, b.nhiem_vu, b.so]);
  }
  const dsTl = tc.danhSachTroLy();
  for (const t of dsTl) {
    await kho.chay(
      'INSERT INTO tro_ly (id, ban_id, ten, vai, chuyen_mon, pham_vi, suc_chua_ngay, created_at) ' +
      'VALUES (?, ?, ?, ?, ?, ?, ?, ?) ' +
      'ON CONFLICT(id) DO UPDATE SET ban_id = excluded.ban_id, ten = excluded.ten, ' +
      '  vai = excluded.vai, pham_vi = excluded.pham_vi, suc_chua_ngay = excluded.suc_chua_ngay',
      [t.id, t.ban_id, t.ten, t.vai, t.chuyen_mon, t.pham_vi, t.suc_chua_ngay, now]);
  }
  for (const b of tc.BAN) {
    const tb = dsTl.find((x) => x.ban_id === b.id && x.vai === 'truong-ban');
    if (tb) {
      await kho.chay('UPDATE ban_chuyen_mon SET truong_ban_id = ? WHERE id = ?', [tb.id, b.id]);
    }
  }
  dem.troLy = dsTl.length;
  dem.ban = tc.BAN.length;

  // ── Bảng nhiệm vụ ──
  for (const n of tc.NHIEM_VU) {
    await kho.chay(
      'INSERT INTO bang_nhiem_vu (id, ma, ten, ban_id, vai_lam, dau_vao_json, dau_ra_json, ' +
      '  tieu_chuan_dat, phut_du_kien, can_nguoi_duyet, cam_json) ' +
      'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ' +
      'ON CONFLICT(ma) DO UPDATE SET ten = excluded.ten, ban_id = excluded.ban_id, ' +
      '  tieu_chuan_dat = excluded.tieu_chuan_dat, phut_du_kien = excluded.phut_du_kien, ' +
      '  can_nguoi_duyet = excluded.can_nguoi_duyet, cam_json = excluded.cam_json',
      [maMoi(), n.ma, n.ten, n.ban, n.vai, JSON.stringify(n.dau_vao), JSON.stringify(n.dau_ra),
        n.tieu_chuan, n.phut, n.can_nguoi_duyet, JSON.stringify(n.cam)]);
  }
  dem.nhiemVu = tc.NHIEM_VU.length;

  // ── Quy trình ──
  for (const q of tc.QUY_TRINH) {
    await kho.chay(
      'INSERT INTO quy_trinh (id, ma, ten, muc_dich, buoc_json, dau_ra, hieu_luc_tu) ' +
      'VALUES (?, ?, ?, ?, ?, ?, ?) ' +
      'ON CONFLICT(ma) DO UPDATE SET ten = excluded.ten, muc_dich = excluded.muc_dich, ' +
      '  buoc_json = excluded.buoc_json, dau_ra = excluded.dau_ra',
      [maMoi(), q.ma, q.ten, q.muc_dich, JSON.stringify(q.buoc), q.dau_ra, now]);
  }
  dem.quyTrinh = tc.QUY_TRINH.length;

  // ── 50 trợ lý quan hệ gia đình ──
  for (const c of tc.danhSachCrm()) {
    await kho.chay(
      'INSERT INTO crm_tro_ly (id, ten, to_id, vai, suc_chua_ngay, muc_tu_chu, created_at) ' +
      'VALUES (?, ?, ?, ?, ?, ?, ?) ' +
      'ON CONFLICT(id) DO UPDATE SET ten = excluded.ten, to_id = excluded.to_id, ' +
      '  vai = excluded.vai, muc_tu_chu = excluded.muc_tu_chu',
      [c.id, c.ten, c.to_id, c.vai, c.suc_chua_ngay, c.muc_tu_chu, now]);
  }
  dem.crmTroLy = 50;

  // ── Hệ thống tài khoản kế toán ──
  for (const t of bg.TAI_KHOAN) {
    await kho.chay(
      'INSERT INTO tai_khoan_ke_toan (so, ten, cap, cha_so, loai, du_thuong, thong_tu, hoat_dong) ' +
      'VALUES (?, ?, ?, ?, ?, ?, ?, 1) ' +
      'ON CONFLICT(so) DO UPDATE SET ten = excluded.ten, loai = excluded.loai, ' +
      '  du_thuong = excluded.du_thuong, thong_tu = excluded.thong_tu',
      [t.so, t.ten, t.cap, t.cha_so, t.loai, t.du_thuong, t.thong_tu]);
  }
  dem.taiKhoanKeToan = bg.TAI_KHOAN.length;

  // ── Bốn bộ phiếu ──
  // Câu hỏi sống trong mã nguồn; bảng này chỉ ghi lại để khoá ngoại của
  // luot_khao_sat có chỗ bám và để đếm được số câu thật.
  for (const [ma, b] of Object.entries(BO)) {
    const de = b.mo.deBai();
    await kho.chay(
      'INSERT INTO bo_phieu (id, ten, nhom, so_cau, cach_cham, canh_bao, nguon, phien_ban, hoat_dong) ' +
      "VALUES (?, ?, ?, ?, ?, ?, ?, '1', 1) " +
      'ON CONFLICT(id) DO UPDATE SET ten = excluded.ten, nhom = excluded.nhom, ' +
      '  so_cau = excluded.so_cau, cach_cham = excluded.cach_cham, ' +
      '  canh_bao = excluded.canh_bao, nguon = excluded.nguon',
      [ma, b.ten, b.nhom, de.length,
        'Nhận một mảng ' + b.dangTraLoi + '; chấm bằng chính mô-đun của hệ Node.',
        (b.mo.KHONG_LAM ? b.mo.KHONG_LAM + ' ' : '') + CANH_BAO_CHUNG, b.nguon]);
  }
  dem.boPhieu = Object.keys(BO).length;

  // ── Hiến pháp ──
  for (const d of hp.DIEU) {
    await kho.chay(
      'INSERT INTO hien_phap (id, dieu, ten, noi_dung, can_cu_json, bat_buoc, vi_pham_thi, hieu_luc_tu) ' +
      'VALUES (?, ?, ?, ?, ?, 1, ?, ?) ' +
      'ON CONFLICT(dieu) DO UPDATE SET ten = excluded.ten, noi_dung = excluded.noi_dung, ' +
      '  can_cu_json = excluded.can_cu_json, vi_pham_thi = excluded.vi_pham_thi',
      [maMoi(), d.dieu, d.ten, d.noi_dung, JSON.stringify(d.can_cu), d.vi_pham_thi, now]);
  }
  dem.hienPhap = hp.DIEU.length;

  return dem;
}

/** Đếm lại phủ sóng từ kho thật. Không ai khai tay được con số này. */
async function demLaiPhuSong(kho, bayGio) {
  const now = bayGio || Date.now();
  const ds = await kho.nhieu('SELECT id FROM o_chuong_trinh');
  for (const o of ds) {
    const cd = await kho.dem('SELECT COUNT(*) FROM chuyen_de WHERE o_id = ?', [o.id]);
    const b = await kho.mot(
      'SELECT COUNT(*) AS tong, ' +
      "  SUM(CASE WHEN trang_thai = 'da-soat'     THEN 1 ELSE 0 END) AS soat, " +
      "  SUM(CASE WHEN trang_thai = 'da-xuat-ban' THEN 1 ELSE 0 END) AS xuat " +
      'FROM bai_tap WHERE o_id = ?', [o.id]);
    const ch = await kho.dem('SELECT COUNT(*) FROM chuan_kien_thuc WHERE o_id = ?', [o.id]);
    const chCoBai = await kho.dem(
      'SELECT COUNT(DISTINCT c.id) FROM chuan_kien_thuc c ' +
      'JOIN bai_tap b ON b.o_id = c.o_id AND b.chuan_ids_json LIKE \'%\' || c.id || \'%\' ' +
      'WHERE c.o_id = ?', [o.id]);
    await kho.chay(
      'INSERT INTO phu_song (id, o_id, so_chuyen_de, so_bai_nhap, so_bai_soat, so_bai_xuat, ' +
      '  so_chuan, so_chuan_co_bai, dem_luc) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ' +
      'ON CONFLICT(o_id) DO UPDATE SET so_chuyen_de = excluded.so_chuyen_de, ' +
      '  so_bai_nhap = excluded.so_bai_nhap, so_bai_soat = excluded.so_bai_soat, ' +
      '  so_bai_xuat = excluded.so_bai_xuat, so_chuan = excluded.so_chuan, ' +
      '  so_chuan_co_bai = excluded.so_chuan_co_bai, dem_luc = excluded.dem_luc',
      [o.id, o.id, cd, Number(b.tong) || 0, Number(b.soat) || 0, Number(b.xuat) || 0,
        ch, chCoBai, now]);
    await kho.chay('UPDATE o_chuong_trinh SET so_chuyen_de = ?, so_bai = ? WHERE id = ?',
      [cd, Number(b.tong) || 0, o.id]);
  }
  return ds.length;
}

module.exports = { gieo, demLaiPhuSong };
