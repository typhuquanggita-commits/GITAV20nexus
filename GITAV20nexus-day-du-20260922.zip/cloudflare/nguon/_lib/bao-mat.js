'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  HAI MƯƠI HAI LỚP CANH
 *  Mười lớp phòng vệ ngoài + mười hai tầng trong.
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  BA ĐIỀU NÓI THẲNG TRƯỚC, vì một bộ canh nói quá về chính mình còn
 *  nguy hiểm hơn không có bộ canh nào:
 *
 *  1. Workers chạy mỗi lượt trong một bản cô lập riêng, KHÔNG có trạng
 *     thái sống chung giữa các lượt. Nên lớp nào cần thấy toàn cảnh
 *     trong một giây — chặn lũ yêu cầu chẳng hạn — không làm đủ được ở
 *     đây. Phần ấy do chính hạ tầng Cloudflare đứng trước gánh, và mã
 *     này chỉ làm phần đếm được qua kho. Mỗi lớp tự khai `dayDu` là
 *     true hay false, và trang tình trạng in ra đúng lời khai ấy.
 *
 *  2. Lớp canh KHÔNG thay cho việc viết mã đúng. Lớp chống tiêm SQL ở
 *     đây là lưới thứ hai; lưới thứ nhất là mọi câu truy vấn đều dùng
 *     tham số ràng buộc, không nối chuỗi. Bỏ lưới thứ nhất rồi trông
 *     vào lưới thứ hai là làm ngược.
 *
 *  3. Chặn nhầm một người dùng thật là một thiệt hại có thật. Nên lớp
 *     hành vi chỉ ĐÁNH DẤU để xem lại, không tự chặn — một hôm làm việc
 *     khác thường không phải là một cuộc tấn công.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { maMoi, sha256 } = require('./ma.js');

const THAN_TOI_DA = 256 * 1024;
const NUOC_CHAN_MAC_DINH = [];        // để trống: không chặn nước nào theo mặc định

// ── Khuôn nhận dạng, khai một chỗ ──────────────────────────────────────

const KHUON_MA_DOC = [
  { ma: 'thoat-hex', re: /\\x[0-9a-f]{2}/i, vi: 'Chuỗi thoát dạng \\xNN — cách giấu mã trong dữ liệu.' },
  { ma: 'thoat-kep', re: /%[0-9a-f]{2}%[0-9a-f]{2}/i, vi: 'Mã hoá URL hai lớp để qua mặt bộ lọc.' },
  { ma: 'goi-eval', re: /\beval\s*\(|new\s+Function\s*\(/i, vi: 'Gọi trình biên dịch động.' },
  { ma: 'leo-thu-muc', re: /\.\.[/\\]/, vi: 'Trèo ngược thư mục.' },
  { ma: 'nguyen-mau', re: /__proto__|constructor\s*\[|prototype\s*\[/, vi: 'Đụng vào nguyên mẫu đối tượng.' },
];

const KHUON_TIEM_SQL = [
  { ma: 'hoac-luon-dung', re: /(\bor\b|\bและ\b)\s+['"]?\d+['"]?\s*=\s*['"]?\d+/i,
    vi: 'Mệnh đề luôn đúng, khuôn kinh điển của tiêm SQL.' },
  { ma: 'noi-cau', re: /;\s*(drop|delete|update|insert|alter|truncate)\s+/i,
    vi: 'Nối thêm một câu lệnh sau dấu chấm phẩy.' },
  { ma: 'gop-truy-van', re: /\bunion\b[\s\S]{0,40}\bselect\b/i, vi: 'Gộp thêm một truy vấn.' },
  { ma: 'chu-thich-sql', re: /(--|#|\/\*)[^\n]*(\bor\b|\band\b|=)/i,
    vi: 'Chú thích SQL dùng để cắt phần còn lại của câu.' },
];

const KHUON_XSS = [
  { ma: 'the-script', re: /<\s*script\b/i, vi: 'Thẻ script trong dữ liệu.' },
  { ma: 'javascript-uri', re: /javascript\s*:/i, vi: 'Địa chỉ dạng javascript:.' },
  { ma: 'su-kien-noi-tuyen', re: /\bon(error|load|click|mouse\w+|focus)\s*=/i,
    vi: 'Thuộc tính bắt sự kiện nội tuyến.' },
  { ma: 'khung-nhung', re: /<\s*(iframe|object|embed)\b/i, vi: 'Thẻ nhúng nội dung ngoài.' },
];

const KHUON_LUA = [
  { ma: 'chuyen-huong-ngoai', re: /^(https?:)?\/\//i, vi: 'Đường chuyển tiếp ra ngoài miền.' },
];

const KHUON_DU_DO = [
  { ma: 'xin-bo-qua-kiem', re: /(bỏ\s*qua|skip|bypass)[\s\S]{0,24}(kiểm|duyệt|xác\s*minh|verify)/i,
    vi: 'Xin bỏ qua bước kiểm hoặc bước duyệt.' },
  { ma: 'gia-danh-quan-tri', re: /(tôi|em|mình)\s+(là|chính là)\s+(quản\s*trị|admin|super\s*admin|chủ\s*hệ)/i,
    vi: 'Tự xưng là quản trị trong nội dung yêu cầu.' },
  { ma: 'gap-nen-bo-buoc', re: /(gấp|khẩn|ngay\s*lập\s*tức)[\s\S]{0,30}(bỏ|khỏi\s*cần|không\s*cần)\s*(duyệt|kiểm)/i,
    vi: 'Lấy cớ gấp để xin bỏ bước.' },
];

const VIEC_PHA_HOAI = ['xoa-du-lieu', 'xoa-hang-loat', 'xuat-toan-bo', 'ha-quyen-hang-loat'];

// ── Một lớp canh ───────────────────────────────────────────────────────

function lop(ma, ten, giaiDoan, dayDu, vi, chay) {
  return { ma, ten, giaiDoan, dayDu, vi, chay };
}

function bat(o, maLoi, vi, dauHieu) {
  return { dat: false, ma: maLoi, vi, dauHieu: dauHieu || null };
}
const qua = { dat: true };

/** Gom mọi chuỗi trong thân yêu cầu thành một chuỗi để quét khuôn. */
function gomChu(gt, sau) {
  const d = sau || 0;
  if (d > 6) return '';
  if (typeof gt === 'string') return gt + '\u0000';
  if (typeof gt === 'number' || typeof gt === 'boolean') return String(gt) + '\u0000';
  if (Array.isArray(gt)) return gt.map((x) => gomChu(x, d + 1)).join('');
  if (gt && typeof gt === 'object') {
    return Object.keys(gt).map((k) => k + '\u0000' + gomChu(gt[k], d + 1)).join('');
  }
  return '';
}

function doKhuon(chu, bang) {
  for (const k of bang) if (k.re.test(chu)) return k;
  return null;
}

// ═══════════════════════════════════════════════════════════════════════════
//  MƯỜI LỚP PHÒNG VỆ NGOÀI
// ═══════════════════════════════════════════════════════════════════════════

const PHONG_VE = [
  lop('D1', 'Chặn lũ yêu cầu', 'phong-ve', false,
    'Workers không có trạng thái chung giữa các bản cô lập nên KHÔNG đếm được '
    + 'toàn cảnh trong một giây. Phần ấy do hạ tầng Cloudflare đứng trước gánh. '
    + 'Ở đây chỉ đếm theo tài khoản và theo ngày, qua kho.',
    async (c) => {
      if (!c.ip) return qua;
      const r = await c.kho.mot(
        'SELECT count FROM rate_counters WHERE id = ?',
        ['doc:' + c.ip + ':' + new Date(c.bayGio).toISOString().slice(0, 10)]);
      const n = r ? Number(r.count) : 0;
      if (n > 20000) {
        return bat(c, 'lu-yeu-cau',
          'Địa chỉ này đã gọi ' + n + ' lượt trong ngày — vượt xa mức một người dùng thật.',
          { soLuot: n });
      }
      return qua;
    }),

  lop('D2', 'Nhận dạng máy quét', 'phong-ve', true,
    'Chỉ chặn những máy quét TỰ KHAI là máy quét. Thiếu dòng tự giới thiệu, '
    + 'hoặc khai là curl, chỉ được ĐÁNH DẤU — vì đó là một dòng tiêu đề ai '
    + 'cũng sửa được trong một giây, nên dựng cổng trên nó là diễn trò chứ '
    + 'không phải canh. Ứng dụng di động và lệnh gọi máy-sang-máy hoàn toàn '
    + 'hợp lệ cũng không gửi dòng ấy.',
    (c) => {
      const ua = c.ua || '';
      if (!ua) {
        c.danhDau.push({ lop: 'D2', dauHieu: ['Không khai trình duyệt.'] });
        return qua;
      }
      if (/googlebot|bingbot|duckduckbot/i.test(ua)) return qua;
      if (/\b(bot|crawler|spider|scraper)\b/i.test(ua)) {
        return bat(c, 'may-quet-tu-khai',
          'Dòng tự giới thiệu khai đây là máy quét: ' + ua.slice(0, 60));
      }
      if (/\b(curl|wget|python-requests|libwww|httpie)\b/i.test(ua)) {
        c.danhDau.push({ lop: 'D2', dauHieu: ['Gọi bằng công cụ dòng lệnh: ' + ua.slice(0, 40)] });
      }
      return qua;
    }),

  lop('D3', 'Khuôn mã độc', 'phong-ve', true,
    'Quét thân yêu cầu tìm năm khuôn giấu mã đã biết.',
    (c) => {
      const k = doKhuon(c.chuThan, KHUON_MA_DOC);
      return k ? bat(c, 'ma-doc:' + k.ma, k.vi) : qua;
    }),

  lop('D4', 'Tấn công dai dẳng', 'phong-ve', true,
    'Một tài khoản gọi đều tăm tắp suốt nhiều giờ là máy, không phải người.',
    async (c) => {
      if (!c.userId) return qua;
      const gio = Math.floor(c.bayGio / 3600000);
      const r = await c.kho.mot(
        'SELECT COUNT(*) AS so FROM lenh_bo_nao WHERE user_id = ? AND at > ?',
        [c.userId, c.bayGio - 3600000]);
      const so = Number(r.so);
      if (so > 3000) {
        return bat(c, 'goi-day-dac',
          'Tài khoản này gọi ' + so + ' lượt trong một giờ. Người dùng thật không làm được thế.',
          { soLuot: so, gio });
      }
      return qua;
    }),

  lop('D5', 'Phá hoại hàng loạt', 'phong-ve', true,
    'Việc xoá hoặc xuất toàn bộ dữ liệu luôn phải có người duyệt, không có ngoại lệ.',
    (c) => {
      if (!VIEC_PHA_HOAI.includes(c.viec)) return qua;
      if (c.daCoNguoiDuyet) return qua;
      return bat(c, 'pha-hoai-hang-loat',
        'Việc "' + c.viec + '" không chạy được nếu chưa có một con người bấm duyệt.');
    }),

  lop('D6', 'Nghe lén giữa đường', 'phong-ve', true,
    'Buộc đi qua HTTPS, và buộc tên miền trong địa chỉ khớp tên miền trong tiêu đề '
    + 'Host. Hai thứ lệch nhau là dấu hiệu có ai đó đứng giữa và viết lại yêu cầu.',
    (c) => {
      if (c.giaoThuc !== 'https:' && !c.laThu) {
        return bat(c, 'khong-phai-https', 'Yêu cầu không đi qua HTTPS.');
      }
      if (c.tenMien && c.tieuDeHost && c.tenMien !== c.tieuDeHost) {
        return bat(c, 'ten-mien-lech',
          'Tên miền trong địa chỉ và trong tiêu đề Host không khớp nhau.');
      }
      return qua;
    }),

  lop('D7', 'Dẫn dụ ra ngoài', 'phong-ve', true,
    'Không nhận tham số chuyển tiếp trỏ ra miền khác.',
    (c) => {
      for (const ten of ['quayVe', 'chuyenToi', 'next', 'redirect', 'return_to', 'url']) {
        const v = c.thamSoUrl.get(ten);
        if (v && doKhuon(v, KHUON_LUA)) {
          return bat(c, 'chuyen-huong-ngoai',
            'Tham số ' + ten + ' trỏ ra ngoài miền: ' + String(v).slice(0, 60));
        }
      }
      return qua;
    }),

  lop('D8', 'Người trong nhà', 'phong-ve', true,
    'Hai việc. Một: tài khoản đã khoá mà vẫn gọi được thì chặn — đường phiên đã '
    + 'bắt việc này rồi, đây là lưới thứ hai cho đường khoá ký máy-gọi-máy. Hai: '
    + 'một tài khoản quản trị làm dồn dập quá nhiều việc nhạy cảm trong một giờ. '
    + 'Đây là dấu hiệu duy nhất trong hai mươi hai lớp nhắm vào người CÓ quyền, '
    + 'chứ không nhắm vào người ngoài.',
    async (c) => {
      if (!c.userId) return qua;
      const u = await c.kho.mot('SELECT status, role FROM users WHERE id = ?', [c.userId]);
      if (u && u.status !== 'ACTIVE') {
        return bat(c, 'tai-khoan-da-khoa',
          'Tài khoản đang ở trạng thái ' + u.status + ' mà vẫn gọi được.');
      }
      if (!u || (u.role !== 'ADMIN' && u.role !== 'SUPER_ADMIN')) return qua;
      const r = await c.kho.mot(
        'SELECT COUNT(*) AS so FROM audit_log WHERE actor_id = ? AND at > ? ' +
        "AND (action LIKE 'tai-khoan.%' OR action LIKE 'bao-mat.%' " +
        "     OR action LIKE 'lo-trinh.mo-cap-bang-tay' OR action LIKE 'ke-toan.%')",
        [c.userId, c.bayGio - 3600000]);
      const so = Number(r.so);
      if (so > 200) {
        return bat(c, 'don-dap-viec-nhay-cam',
          'Tài khoản quản trị này đã làm ' + so + ' việc nhạy cảm trong một giờ. '
          + 'Dừng lại để người khác xem — đây là mức mà thao tác tay không đạt tới.',
          { soViec: so });
      }
      if (so > 80) {
        c.danhDau.push({ lop: 'D8',
          dauHieu: [so + ' việc nhạy cảm trong một giờ từ một tài khoản quản trị.'] });
      }
      return qua;
    }),

  lop('D9', 'Chuỗi cung ứng', 'phong-ve', true,
    'Bản ghép không mang gói ngoài nào — bộ ghép chặn từ lúc dựng. Lớp này '
    + 'canh chiều còn lại: dữ liệu vào không được mang đường dẫn tải mã.',
    (c) => {
      if (/https?:\/\/[^\s"']+\.(js|mjs|wasm)\b/i.test(c.chuThan)) {
        return bat(c, 'duong-tai-ma',
          'Thân yêu cầu mang một đường dẫn tới tệp mã chạy được.');
      }
      return qua;
    }),

  lop('D10', 'Dụ người', 'phong-ve', true,
    'Bắt ba khuôn dụ dỗ thường gặp: xin bỏ bước kiểm, tự xưng quản trị, lấy cớ gấp.',
    (c) => {
      const k = doKhuon(c.chuThan, KHUON_DU_DO);
      return k ? bat(c, 'du-do:' + k.ma, k.vi) : qua;
    }),
];

// ═══════════════════════════════════════════════════════════════════════════
//  MƯỜI HAI TẦNG TRONG
// ═══════════════════════════════════════════════════════════════════════════

const TANG_TRONG = [
  lop('L1', 'Nước gọi đến', 'tang-trong', true,
    'Cloudflare cho biết nước của mỗi yêu cầu. Mặc định không chặn nước nào; '
    + 'danh sách chặn do quản trị đặt.',
    (c) => {
      const chan = c.nuocChan && c.nuocChan.length ? c.nuocChan : NUOC_CHAN_MAC_DINH;
      if (c.nuoc && chan.includes(c.nuoc)) {
        return bat(c, 'nuoc-bi-chan', 'Yêu cầu đến từ ' + c.nuoc + ', nằm trong danh sách chặn.');
      }
      return qua;
    }),

  lop('L2', 'Danh sách chặn', 'tang-trong', true,
    'Địa chỉ hoặc tài khoản đã bị chặn thì dừng ngay, không xét tiếp.',
    async (c) => {
      const tim = [];
      if (c.ip) tim.push(['ip', c.ip]);
      if (c.userId) tim.push(['tai-khoan', c.userId]);
      for (const [l, v] of tim) {
        const r = await c.kho.mot(
          'SELECT ly_do, chan_den FROM danh_sach_chan WHERE loai = ? AND gia_tri = ?', [l, v]);
        if (r && (!r.chan_den || Number(r.chan_den) > c.bayGio)) {
          return bat(c, 'nam-trong-danh-sach-chan', r.ly_do, { loai: l });
        }
      }
      return qua;
    }),

  lop('L3', 'Hạn mức', 'tang-trong', true,
    'Đếm theo ngày trong kho D1 — không dùng KV vì bậc miễn phí chỉ cho 1.000 '
    + 'lượt ghi KV mỗi ngày, mà đếm hạn mức thì ghi mỗi lượt gọi.',
    () => qua),   // hạn mức thật do bối cảnh gọi canHanMuc, lớp này chỉ khai

  lop('L4', 'Cỡ thân yêu cầu', 'tang-trong', true,
    'Thân quá lớn là cách làm nghẽn máy chủ rẻ nhất.',
    (c) => (c.coThan > THAN_TOI_DA
      ? bat(c, 'than-qua-lon', 'Thân yêu cầu ' + c.coThan + ' byte, vượt mức ' + THAN_TOI_DA + '.')
      : qua)),

  lop('L5', 'Chữ ký lệnh máy', 'tang-trong', true,
    'Lệnh máy-gọi-máy phải mang chữ ký. Kho chỉ giữ BĂM của khoá ký, '
    + 'nên đọc trộm bảng khoá cũng không ký giả được.',
    async (c) => {
      if (!c.khoaKy) return qua;              // không khai khoá thì đi đường người dùng
      const r = await c.kho.mot(
        'SELECT id, het_han, thu_hoi_luc, pham_vi_json FROM khoa_ky WHERE bam_khoa = ?',
        [await sha256(c.khoaKy)]);
      if (!r) return bat(c, 'khoa-ky-khong-biet', 'Khoá ký không có trong kho.');
      if (r.thu_hoi_luc) return bat(c, 'khoa-ky-da-thu-hoi', 'Khoá ký này đã bị thu hồi.');
      if (r.het_han && Number(r.het_han) < c.bayGio) {
        return bat(c, 'khoa-ky-het-han', 'Khoá ký đã hết hạn.');
      }
      c.phamViKhoa = JSON.parse(r.pham_vi_json);
      await c.kho.chay('UPDATE khoa_ky SET dung_lan_cuoi = ? WHERE id = ?', [c.bayGio, r.id]);
      return qua;
    }),

  lop('L6', 'Tiêm SQL', 'tang-trong', true,
    'Lưới thứ HAI. Lưới thứ nhất là mọi truy vấn đều dùng tham số ràng buộc, '
    + 'không nối chuỗi — và lưới ấy mới là thứ thật sự giữ.',
    (c) => {
      const k = doKhuon(c.chuThan, KHUON_TIEM_SQL);
      return k ? bat(c, 'tiem-sql:' + k.ma, k.vi) : qua;
    }),

  lop('L7', 'Chèn mã vào trang', 'tang-trong', true,
    'Cũng là lưới thứ hai: mọi chữ ra trang đều đã đi qua bộ thoát ký tự.',
    (c) => {
      const k = doKhuon(c.chuThan, KHUON_XSS);
      return k ? bat(c, 'chen-ma:' + k.ma, k.vi) : qua;
    }),

  lop('L8', 'Thẻ phiên', 'tang-trong', true,
    'Kho chỉ giữ băm của thẻ. Thẻ hết hạn, bị thu hồi, hoặc thuộc tài khoản '
    + 'đã khoá đều không dùng được.',
    (c) => (c.canDangNhap && !c.userId
      ? bat(c, 'chua-dang-nhap', 'Đường này đòi đăng nhập.')
      : qua)),

  lop('L9', 'Phân quyền', 'tang-trong', true,
    'Bảng phân quyền khai báo, cộng năm việc cấm tuyệt đối mà kể cả quản trị '
    + 'tối cao cũng không làm qua đường HTTP được.',
    () => qua),   // quyền thật do từng tuyến gọi canQuyen; lớp này chỉ khai

  lop('L10', 'Mã hoá', 'tang-trong', false,
    'Đường truyền: HTTPS bắt buộc, có kiểm ở lớp D6. Mật khẩu: PBKDF2-SHA256 '
    + '210.000 vòng. Thẻ phiên: chỉ lưu băm. NHƯNG dữ liệu trong D1 KHÔNG mã '
    + 'hoá ở mức ứng dụng — ai đọc được kho là đọc được nội dung. Nói ra vì '
    + 'im lặng ở chỗ này là để người dùng tin vào một thứ không có.',
    () => qua),

  lop('L11', 'Hiến pháp', 'tang-trong', true,
    'Mười lăm điều, mỗi điều dẫn văn bản pháp lý thật.',
    () => qua),   // bộ não gọi riêng ở bước sau

  lop('L12', 'Hành vi khác thường', 'tang-trong', true,
    'So hôm nay với nếp thường ngày của CHÍNH tài khoản ấy. Chỉ ĐÁNH DẤU để '
    + 'xem lại, KHÔNG chặn — một hôm làm việc khác thường không phải một cuộc '
    + 'tấn công, và chặn nhầm người dùng thật là thiệt hại có thật.',
    async (c) => {
      if (!c.userId) return qua;
      const n = await c.kho.mot('SELECT * FROM nep_tai_khoan WHERE user_id = ?', [c.userId]);
      if (!n || Number(n.so_luot) < 50) return qua;     // chưa đủ nếp thì chưa so
      const dauHieu = [];
      const gio = new Date(c.bayGio).getUTCHours();
      let theoGio = {};
      try { theoGio = JSON.parse(n.gio_hay_dung || '{}'); } catch (e) { theoGio = {}; }
      const tong = Object.values(theoGio).reduce((a, b) => a + b, 0) || 1;
      if ((theoGio[gio] || 0) / tong < 0.01) {
        dauHieu.push('Giờ ' + gio + ' giờ quốc tế gần như chưa bao giờ tài khoản này hoạt động.');
      }
      if (n.nuoc_hay_vao && c.nuoc && n.nuoc_hay_vao !== c.nuoc) {
        dauHieu.push('Vào từ ' + c.nuoc + ', trong khi nếp thường là ' + n.nuoc_hay_vao + '.');
      }
      if (dauHieu.length) c.danhDau.push({ lop: 'L12', dauHieu });
      return qua;
    }),
];

const MOI_LOP = PHONG_VE.concat(TANG_TRONG);

// ═══════════════════════════════════════════════════════════════════════════
//  CHẠY CẢ HAI MƯƠI HAI LỚP
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @returns {{dat:boolean, lop?:string, giaiDoan?:string, ma?:string, vi?:string,
 *            daChay:number, danhDau:Array}}
 */
async function soi(boiCanh) {
  const c = Object.assign({ danhDau: [], thamSoUrl: new URLSearchParams() }, boiCanh);
  let daChay = 0;
  for (const l of MOI_LOP) {
    daChay += 1;
    let r;
    try {
      r = await l.chay(c);
    } catch (e) {
      // Một lớp canh tự vỡ thì coi như KHÔNG qua. Mở cửa vì bộ canh hỏng là
      // cách hỏng tệ nhất mà một hệ bảo mật có thể hỏng.
      r = bat(c, 'lop-canh-loi', 'Lớp ' + l.ma + ' tự vỡ: ' + (e && e.message));
    }
    if (r && r.dat === false) {
      return { dat: false, lop: l.ma + '_' + l.ten, giaiDoan: l.giaiDoan,
        ma: r.ma, vi: r.vi, dauHieu: r.dauHieu, daChay, danhDau: c.danhDau };
    }
  }
  return { dat: true, daChay, danhDau: c.danhDau, phamViKhoa: c.phamViKhoa || null };
}

/** Dựng bối cảnh từ một Request thật. */
async function boiCanhTu(req, kho, than, bayGio, them) {
  const url = new URL(req.url);
  const cf = req.cf || {};
  const chuThan = gomChu(than === undefined ? null : than) + ' ' + url.search;
  return Object.assign({
    kho,
    bayGio: bayGio || Date.now(),
    ip: req.headers.get('cf-connecting-ip') || null,
    ua: req.headers.get('user-agent') || '',
    nuoc: cf.country || null,
    giaoThuc: url.protocol,
    tenMien: url.hostname,
    tieuDeHost: (req.headers.get('host') || '').split(':')[0] || null,
    laThu: url.hostname.endsWith('.local') || url.hostname === 'localhost',
    thamSoUrl: url.searchParams,
    duongDan: url.pathname,
    cachGoi: req.method,
    khoaKy: req.headers.get('x-khoa-ky') || null,
    chuThan,
    coThan: chuThan.length,
    danhDau: [],
  }, them || {});
}

/** Ghi một lượt chặn. Không ghi lượt qua — ghi hết thì kho đầy vì rác. */
async function ghiChan(kho, r, c, bayGio) {
  await kho.chen('nhat_ky_chan', {
    id: maMoi(), lop: r.lop, giai_doan: r.giaiDoan, ly_do: r.vi,
    duong_dan: c.duongDan || null, cach_goi: c.cachGoi || null,
    ip: c.ip || null, user_id: c.userId || null,
    dau_hieu_json: r.dauHieu ? JSON.stringify(r.dauHieu) : null,
    at: bayGio,
  });
}

/** Cập nhật nếp thường ngày. Gọi sau mỗi lượt ĐÃ QUA, không gọi khi bị chặn. */
async function capNhatNep(kho, c, bayGio) {
  if (!c.userId) return;
  const gio = new Date(bayGio).getUTCHours();
  const n = await kho.mot('SELECT * FROM nep_tai_khoan WHERE user_id = ?', [c.userId]);
  let theoGio = {};
  try { theoGio = n ? JSON.parse(n.gio_hay_dung || '{}') : {}; } catch (e) { theoGio = {}; }
  theoGio[gio] = (theoGio[gio] || 0) + 1;
  await kho.chay(
    'INSERT INTO nep_tai_khoan (user_id, so_luot, gio_hay_dung, nuoc_hay_vao, cap_nhat) ' +
    'VALUES (?, 1, ?, ?, ?) ' +
    'ON CONFLICT(user_id) DO UPDATE SET so_luot = so_luot + 1, ' +
    '  gio_hay_dung = excluded.gio_hay_dung, ' +
    '  nuoc_hay_vao = COALESCE(nep_tai_khoan.nuoc_hay_vao, excluded.nuoc_hay_vao), ' +
    '  cap_nhat = excluded.cap_nhat',
    [c.userId, JSON.stringify(theoGio), c.nuoc || null, bayGio]);
}

/** Bảng để trang quản trị vẽ ra — kèm lời khai lớp nào làm đủ, lớp nào không. */
function banLop() {
  return {
    soLop: MOI_LOP.length,
    phongVe: PHONG_VE.map((l) => ({ ma: l.ma, ten: l.ten, dayDu: l.dayDu, giaiThich: l.vi })),
    tangTrong: TANG_TRONG.map((l) => ({ ma: l.ma, ten: l.ten, dayDu: l.dayDu, giaiThich: l.vi })),
    soLopChuaDayDu: MOI_LOP.filter((l) => !l.dayDu).length,
    noiThang: 'Hai lớp tự khai là CHƯA ĐỦ: D1 vì Workers không có trạng thái chung '
      + 'giữa các bản cô lập, và L10 vì dữ liệu trong kho không mã hoá ở mức ứng dụng. '
      + 'Ghi ra đây thay vì để một con số 22/22 trông đẹp mà sai.',
  };
}

module.exports = {
  soi, boiCanhTu, ghiChan, capNhatNep, banLop, gomChu, doKhuon,
  PHONG_VE, TANG_TRONG, MOI_LOP,
  KHUON_MA_DOC, KHUON_TIEM_SQL, KHUON_XSS, KHUON_DU_DO, VIEC_PHA_HOAI, THAN_TOI_DA,
};
