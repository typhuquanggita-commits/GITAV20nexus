'use strict';
/**
 * Cổng AI — sáu nhà cung cấp, tự chuyển khi một nhà hỏng.
 *
 * Ý đồ của đặc tả V13: mỗi nhà cho một hạn mức miễn phí; gộp sáu nhà
 * lại thì hạn mức cộng dồn, nên hệ thống chạy ở mức $0. Cái giá phải
 * trả là mỗi lượt gọi phải biết nhà nào còn hạn và nhà nào đang hỏng —
 * đó là toàn bộ việc của tệp này.
 *
 * Một điều nói thẳng: ở đây KHÔNG có mô hình nào chạy cục bộ. Không
 * cắm khoá thì không có câu trả lời, và hàm sẽ nói đúng như vậy chứ
 * không bịa ra một câu cho có.
 */

const { maMoi } = require('./ma.js');

const THU_TU_MAC_DINH = 'cf-workers-ai,gemini,groq,openrouter,together,hf';
const TRAN_NGAY_MAC_DINH = 500;

/** Ước số thẻ khi nhà cung cấp không trả về con số thật. ~3,5 ký tự/thẻ. */
const uocThe = (chu) => Math.ceil(String(chu || '').length / 3.5);

function tinNhan(tuyChon) {
  if (tuyChon.tinNhan && tuyChon.tinNhan.length) return tuyChon.tinNhan;
  const ra = [];
  if (tuyChon.loiHeThong) ra.push({ role: 'system', content: tuyChon.loiHeThong });
  ra.push({ role: 'user', content: tuyChon.loiNhac || '' });
  return ra;
}

const NHA = {
  'cf-workers-ai': {
    ma: 'cf-workers-ai', ten: 'Cloudflare Workers AI',
    async goi(moi, tuyChon) {
      if (!moi.AI) throw new Error('chua-gan-Workers-AI');
      const mauMay = tuyChon.viec === 'nhung'
        ? (moi.EMBEDDING_MODEL || '@cf/baai/bge-base-en-v1.5')
        : (moi.GENERATION_MODEL || '@cf/meta/llama-3.1-8b-instruct');
      const tn = tinNhan(tuyChon);
      const r = await moi.AI.run(mauMay, {
        messages: tn,
        temperature: tuyChon.nhietDo === undefined ? 0.3 : tuyChon.nhietDo,
        max_tokens: tuyChon.theToiDa || 4096,
      });
      const chu = r.response || r.result || JSON.stringify(r);
      return { chu, mauMay, theVao: uocThe(JSON.stringify(tn)), theRa: uocThe(chu) };
    },
  },

  gemini: {
    ma: 'gemini', ten: 'Google Gemini',
    async goi(moi, tuyChon) {
      const khoa = moi.GEMINI_API_KEY;
      if (!khoa) throw new Error('thieu-GEMINI_API_KEY');
      const mauMay = 'gemini-1.5-flash-latest';
      const noi = tinNhan(tuyChon).map((m) => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }],
      }));
      const r = await fetch(
        'https://generativelanguage.googleapis.com/v1beta/models/' + mauMay +
        ':generateContent?key=' + encodeURIComponent(khoa),
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: noi,
            generationConfig: {
              temperature: tuyChon.nhietDo === undefined ? 0.3 : tuyChon.nhietDo,
              maxOutputTokens: tuyChon.theToiDa || 4096,
              responseMimeType: tuyChon.kieuJson ? 'application/json' : 'text/plain',
            },
          }),
        });
      if (!r.ok) throw new Error('gemini-' + r.status);
      const d = await r.json();
      const chu = (((d.candidates || [])[0] || {}).content || {}).parts
        ? d.candidates[0].content.parts[0].text : '';
      return {
        chu: chu || '', mauMay,
        theVao: (d.usageMetadata || {}).promptTokenCount || 0,
        theRa: (d.usageMetadata || {}).candidatesTokenCount || 0,
      };
    },
  },

  groq:       nhaKieuOpenAI('groq', 'Groq', 'GROQ_API_KEY',
                'https://api.groq.com/openai/v1/chat/completions', 'llama-3.3-70b-versatile'),
  openrouter: nhaKieuOpenAI('openrouter', 'OpenRouter', 'OPENROUTER_API_KEY',
                'https://openrouter.ai/api/v1/chat/completions',
                'meta-llama/llama-3.1-8b-instruct:free',
                { 'HTTP-Referer': 'https://gitamathv20nexus.pages.dev' }),
  together:   nhaKieuOpenAI('together', 'Together AI', 'TOGETHER_API_KEY',
                'https://api.together.xyz/v1/chat/completions',
                'meta-llama/Llama-3.3-70B-Instruct-Turbo-Free'),
  hf:         nhaKieuOpenAI('hf', 'Hugging Face', 'HF_API_KEY',
                'https://router.huggingface.co/v1/chat/completions',
                'meta-llama/Llama-3.1-8B-Instruct'),
};

/** Bốn nhà cuối nói cùng một thứ tiếng (OpenAI chat completions). */
function nhaKieuOpenAI(ma, ten, tenKhoa, dia, mauMay, themTieuDe) {
  return {
    ma, ten,
    async goi(moi, tuyChon) {
      const khoa = moi[tenKhoa];
      if (!khoa) throw new Error('thieu-' + tenKhoa);
      const tn = tinNhan(tuyChon);
      const than = {
        model: mauMay,
        messages: tn,
        temperature: tuyChon.nhietDo === undefined ? 0.3 : tuyChon.nhietDo,
        max_tokens: tuyChon.theToiDa || 4096,
      };
      if (tuyChon.kieuJson) than.response_format = { type: 'json_object' };
      const r = await fetch(dia, {
        method: 'POST',
        headers: Object.assign({
          Authorization: 'Bearer ' + khoa,
          'Content-Type': 'application/json',
        }, themTieuDe || {}),
        body: JSON.stringify(than),
      });
      if (!r.ok) throw new Error(ma + '-' + r.status);
      const d = await r.json();
      const chu = (((d.choices || [])[0] || {}).message || {}).content || '';
      return {
        chu, mauMay,
        theVao: (d.usage || {}).prompt_tokens || 0,
        theRa: (d.usage || {}).completion_tokens || 0,
      };
    },
  };
}

function ngayCua(bayGio) {
  return new Date(bayGio || Date.now()).toISOString().slice(0, 10);
}

async function ghiLuotDung(kho, ma, ngay, theVao, theRa, treMs, thanhCong, bayGio) {
  const now = bayGio || Date.now();
  await kho.chay(
    'INSERT INTO ai_provider_usage ' +
    '(id, provider_code, day, requests_count, tokens_input, tokens_output, ' +
    ' failures_count, avg_latency_ms, created_at, updated_at) ' +
    'VALUES (?, ?, ?, 1, ?, ?, ?, ?, ?, ?) ' +
    'ON CONFLICT(provider_code, day) DO UPDATE SET ' +
    '  requests_count = requests_count + 1, ' +
    '  tokens_input   = tokens_input  + excluded.tokens_input, ' +
    '  tokens_output  = tokens_output + excluded.tokens_output, ' +
    '  failures_count = failures_count + excluded.failures_count, ' +
    '  avg_latency_ms = (COALESCE(avg_latency_ms,0) * (requests_count - 1) ' +
    '                    + excluded.avg_latency_ms) / requests_count, ' +
    '  updated_at     = excluded.updated_at',
    [maMoi(), ma, ngay, theVao, theRa, thanhCong ? 0 : 1, treMs, now, now]);
}

async function ghiSucKhoe(kho, ma, tinhTrang, treMs, loi, bayGio) {
  await kho.chen('ai_provider_health', {
    id: maMoi(), provider_code: ma, status: tinhTrang,
    latency_ms: treMs, error_msg: loi ? String(loi).slice(0, 500) : null,
    checked_at: bayGio || Date.now(),
  });
}

/**
 * Gọi AI. Thử lần lượt theo thứ tự cho đến khi có nhà trả lời.
 * Ném lỗi kèm đường đã đi nếu cả sáu nhà đều không trả lời được —
 * không trả về câu giả để lấp chỗ trống.
 */
async function sinh(kho, moi, tuyChon, dongHo) {
  const bayGio = dongHo || (() => Date.now());
  const thuTu = String(moi.AI_PROVIDER_ORDER || THU_TU_MAC_DINH).split(',')
    .map((x) => x.trim()).filter(Boolean);
  const dsNha = tuyChon.nhaUuTien
    ? [tuyChon.nhaUuTien].concat(thuTu.filter((x) => x !== tuyChon.nhaUuTien))
    : thuTu;
  const tran = parseInt(moi.AI_PROVIDER_DAILY_CAP || String(TRAN_NGAY_MAC_DINH), 10);
  const ngay = ngayCua(bayGio());
  const duongDaDi = [];

  for (const ma of dsNha) {
    const nha = NHA[ma];
    if (!nha) { duongDaDi.push(ma + ':khong-biet-nha'); continue; }

    const dung = await kho.mot(
      'SELECT requests_count FROM ai_provider_usage WHERE provider_code = ? AND day = ?',
      [ma, ngay]);
    if (dung && Number(dung.requests_count) >= tran) {
      duongDaDi.push(ma + ':het-han-muc'); continue;
    }

    const suc = await kho.mot(
      'SELECT status FROM ai_provider_health WHERE provider_code = ? ' +
      'ORDER BY checked_at DESC LIMIT 1', [ma]);
    if (suc && suc.status === 'down') { duongDaDi.push(ma + ':dang-hong'); continue; }

    const batDau = bayGio();
    try {
      const r = await nha.goi(moi, tuyChon);
      const tre = bayGio() - batDau;
      await ghiLuotDung(kho, ma, ngay, r.theVao, r.theRa, tre, true, bayGio());
      await ghiSucKhoe(kho, ma, 'healthy', tre, null, bayGio());
      duongDaDi.push(ma + ':dat');
      return {
        chu: r.chu, nha: ma, tenNha: nha.ten, mauMay: r.mauMay,
        treMs: tre, theVao: r.theVao, theRa: r.theRa, duongDaDi,
      };
    } catch (e) {
      const tre = bayGio() - batDau;
      duongDaDi.push(ma + ':loi:' + String(e.message || e).slice(0, 40));
      await ghiLuotDung(kho, ma, ngay, 0, 0, tre, false, bayGio());
      await ghiSucKhoe(kho, ma, 'degraded', tre, e.message || String(e), bayGio());
    }
  }

  const loi = new Error('Không nhà cung cấp AI nào trả lời được: ' + duongDaDi.join(' → '));
  loi.ma = 'ai-khong-goi-duoc';
  loi.duongDaDi = duongDaDi;
  throw loi;
}

async function tinhHinh(kho, moi, bayGio) {
  const ngay = ngayCua(bayGio);
  const tran = parseInt(moi.AI_PROVIDER_DAILY_CAP || String(TRAN_NGAY_MAC_DINH), 10);
  const thuTu = String(moi.AI_PROVIDER_ORDER || THU_TU_MAC_DINH).split(',').map((x) => x.trim());
  const ra = [];
  for (const ma of thuTu) {
    const nha = NHA[ma];
    if (!nha) continue;
    const d = await kho.mot(
      'SELECT * FROM ai_provider_usage WHERE provider_code = ? AND day = ?', [ma, ngay]);
    const s = await kho.mot(
      'SELECT status, checked_at FROM ai_provider_health WHERE provider_code = ? ' +
      'ORDER BY checked_at DESC LIMIT 1', [ma]);
    ra.push({
      ma, ten: nha.ten,
      coKhoa: ma === 'cf-workers-ai' ? !!moi.AI : !!moi[tenKhoaCua(ma)],
      daGoi: d ? Number(d.requests_count) : 0,
      tran,
      conLai: Math.max(0, tran - (d ? Number(d.requests_count) : 0)),
      hongLuot: d ? Number(d.failures_count) : 0,
      treTrungBinhMs: d ? Number(d.avg_latency_ms || 0) : 0,
      tinhTrang: s ? s.status : 'chua-do',
    });
  }
  return { ngay, nha: ra, tongConLai: ra.reduce((t, x) => t + (x.coKhoa ? x.conLai : 0), 0) };
}

function tenKhoaCua(ma) {
  return { gemini: 'GEMINI_API_KEY', groq: 'GROQ_API_KEY', openrouter: 'OPENROUTER_API_KEY',
    together: 'TOGETHER_API_KEY', hf: 'HF_API_KEY' }[ma];
}

module.exports = { NHA, sinh, tinhHinh, THU_TU_MAC_DINH, TRAN_NGAY_MAC_DINH, ngayCua, uocThe };
