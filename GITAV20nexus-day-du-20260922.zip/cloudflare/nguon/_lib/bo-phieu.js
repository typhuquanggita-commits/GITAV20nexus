'use strict';
/**
 * Bốn bộ phiếu, khai một chỗ.
 *
 * Câu hỏi và cách chấm nằm ở src/khao-sat/* của hệ Node và được dùng
 * lại nguyên vẹn. Tệp này chỉ thêm phần mô tả: bộ nào thuộc nhóm nào,
 * nguồn ở đâu, và câu cảnh báo bắt buộc đi kèm mọi kết quả.
 *
 * Cả bốn bộ đều nhận một MẢNG {so, …}. Ghi rõ ở đây vì đó là chỗ dễ
 * gọi sai nhất, và gọi sai thì kết quả vẫn ra — chỉ là ra sai.
 */

const BO = {
  disc: {
    ten: 'DISC — bốn nhóm hành vi', nhom: 'tinh-cach',
    mo: require('../../../src/khao-sat/disc.js'),
    nguon: 'Mô hình DISC của William Moulton Marston, bản rút gọn 20 câu.',
    dangTraLoi: '{ so, dungNhat, itDungNhat }',
  },
  mbti: {
    ten: 'MBTI — bốn cặp xu hướng', nhom: 'tinh-cach',
    mo: require('../../../src/khao-sat/mbti.js'),
    nguon: 'Bốn cặp lưỡng phân theo Myers–Briggs, bản rút gọn 32 câu.',
    dangTraLoi: '{ so, chon }',
  },
  'tam-ly-hoc-duong': {
    ten: 'Sàng lọc tâm lý học đường', nhom: 'tam-ly',
    mo: require('../../../src/khao-sat/tam-ly-hoc-duong.js'),
    nguon: 'Bộ sàng lọc nội bộ, dựng theo các miền quan sát được ở trường học.',
    dangTraLoi: '{ so, diem }',
  },
  'phuong-phap-hoc': {
    ten: 'Phương pháp học', nhom: 'ky-nang',
    mo: require('../../../src/khao-sat/phuong-phap-hoc.js'),
    nguon: 'Bộ đo thói quen học, dựng theo các miền có dấu vết đo được.',
    dangTraLoi: '{ so, diem }',
  },
};

const CANH_BAO_CHUNG =
  'Kết quả này là một lát cắt tại thời điểm làm phiếu, không phải chẩn đoán và không ' +
  'phải một nhãn dán lên con người. Đừng dùng nó để quyết định thay cho quan sát trực tiếp.';

module.exports = { BO, CANH_BAO_CHUNG };
