'use strict';
/**
 * Nhật ký kiểm toán nối chuỗi băm.
 *
 * Mỗi dòng mang băm của dòng ngay trước. Sửa hay bỏ một dòng ở giữa là
 * chuỗi đứt, và soiChuoi() chỉ ra đúng chỗ đứt. Việc này KHÔNG chứng
 * minh nội dung ghi là thật — nó chỉ chứng minh rằng sau khi ghi thì
 * chưa ai sửa. Nói rõ ở đây để không ai nhầm hai điều đó.
 */

const { maMoi, sha256 } = require('./ma.js');

const GOC = '0'.repeat(64);

function chuoiOnDinh(gt) {
  if (gt === null || typeof gt !== 'object') return JSON.stringify(gt);
  if (Array.isArray(gt)) return '[' + gt.map(chuoiOnDinh).join(',') + ']';
  const k = Object.keys(gt).sort();
  return '{' + k.map((x) => JSON.stringify(x) + ':' + chuoiOnDinh(gt[x])).join(',') + '}';
}

async function ghi(kho, viec, bayGio) {
  const now = bayGio || Date.now();
  const cuoi = await kho.mot('SELECT seq, hash FROM audit_log ORDER BY seq DESC LIMIT 1');
  const seq = cuoi ? Number(cuoi.seq) + 1 : 1;
  const truoc = cuoi ? cuoi.hash : GOC;
  const chiTiet = viec.chiTiet === undefined ? null : chuoiOnDinh(viec.chiTiet);
  const than = chuoiOnDinh({
    seq, at: now, actor: viec.nguoi || null, action: viec.viec,
    target: viec.doiTuong || null, detail: chiTiet, prev: truoc,
  });
  const bam = await sha256(than);
  await kho.chen('audit_log', {
    id: maMoi(), seq, at: now,
    actor_id: viec.nguoi || null,
    action: viec.viec,
    target: viec.doiTuong || null,
    detail_json: chiTiet,
    prev_hash: truoc,
    hash: bam,
  });
  return { seq, hash: bam };
}

/** Duyệt lại cả cuốn. Bắt cả sửa nội dung lẫn xoá dòng giữa chừng. */
async function soiChuoi(kho) {
  const ds = await kho.nhieu('SELECT * FROM audit_log ORDER BY seq ASC');
  let truoc = GOC;
  for (let i = 0; i < ds.length; i++) {
    const d = ds[i];
    if (Number(d.seq) !== i + 1) {
      return { lanh: false, ma: 'thieu-dong', tai: i + 1,
        loi: 'Thiếu dòng số ' + (i + 1) + ' — có dòng bị xoá khỏi giữa cuốn.' };
    }
    if (d.prev_hash !== truoc) {
      return { lanh: false, ma: 'dut-chuoi', tai: Number(d.seq),
        loi: 'Dòng ' + d.seq + ' không nối đúng vào dòng trước.' };
    }
    const bam = await sha256(chuoiOnDinh({
      seq: Number(d.seq), at: Number(d.at), actor: d.actor_id, action: d.action,
      target: d.target, detail: d.detail_json, prev: d.prev_hash,
    }));
    if (bam !== d.hash) {
      return { lanh: false, ma: 'sua-noi-dung', tai: Number(d.seq),
        loi: 'Nội dung dòng ' + d.seq + ' đã bị sửa sau khi ghi.' };
    }
    truoc = d.hash;
  }
  return {
    lanh: true, soDong: ds.length, bamCuoi: truoc,
    khongChungMinh: 'Chuỗi băm chỉ chứng minh chưa ai sửa sau khi ghi. ' +
      'Nó không chứng minh nội dung được ghi là đúng sự thật.',
  };
}

module.exports = { ghi, soiChuoi, chuoiOnDinh, GOC };
