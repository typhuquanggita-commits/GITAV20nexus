'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  THƯ VIỆN CHỈ BÁO HỌC TẬP — VÀ PHÉP ĐO SỨC TIÊN ĐOÁN CỦA CHÚNG
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Cách nghĩ ở đây mượn từ ngành định lượng tài chính, và nó là cách
 *  nghĩ nghiêm nhất mà tôi biết cho câu hỏi "chỉ báo này có nói được
 *  điều gì về tương lai không":
 *
 *    · IC (hệ số tiên đoán) — tương quan HẠNG giữa chỉ báo ĐO HÔM NAY
 *      và kết quả XẢY RA SAU ĐÓ. Dùng hạng vì quan hệ hiếm khi thẳng,
 *      nhưng thứ tự thì có nghĩa.
 *    · IR (độ bền) — trung bình IC chia độ lệch IC qua nhiều lát thời
 *      gian. Một chỉ báo đúng một lần rồi sai mãi có IC đẹp mà IR tệ.
 *    · Suy giảm — IC ở 7, 14, 30, 60 ngày. Chỉ báo nào chỉ đúng trong
 *      ba ngày thì đừng dùng nó để xếp lộ trình ba tháng.
 *    · Khử nhóm — trừ đi trung bình của chính lớp và môn ấy, để chỉ báo
 *      không chỉ đang đo "em học lớp mấy".
 *    · Cắt đúng mốc — chỉ dùng dữ liệu CÓ TRƯỚC mốc để tính chỉ báo, và
 *      chỉ dùng dữ liệu SAU mốc để tính kết quả. Lẫn một chút là cả
 *      phép đo thành vô nghĩa mà vẫn trông rất đẹp.
 *
 *  BA ĐIỀU TỆP NÀY TỪ CHỐI LÀM:
 *
 *  1. Không kết luận dưới cỡ mẫu tối thiểu. Trả về "chưa đủ mẫu" chứ
 *     không trả về một con số.
 *  2. Không báo một hệ số mà khoảng tin cậy của nó còn chứa số không.
 *     Nó được ghi ra, nhưng đánh dấu là CHƯA KHÁC KHÔNG.
 *  3. Không tự đổi ngưỡng vượt cấp. Nó chỉ ĐỀ XUẤT, kèm số đo; người
 *     quyết định vẫn là người.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const tk = require('./thong-ke.js');

const MAU_TOI_THIEU = 40;          // dưới mức này không kết luận gì
const MAU_DE_TIN = 200;            // trên mức này mới gọi là đủ vững
const CHAN_TROI = [7, 14, 30, 60]; // số ngày nhìn về phía trước
const NGAY = 86400000;

/**
 * Mười hai chỉ báo. Mỗi chỉ báo khai:
 *   ma, ten, y      — nó đo cái gì, bằng lời
 *   chieu           — +1 nghĩa là cao thì tốt, -1 nghĩa là cao thì xấu
 *   tinh(kho, userId, mocMs) — CHỈ đọc dữ liệu có trước mocMs
 */
const CHI_BAO = [
  {
    ma: 'ti-le-dung-7n', ten: 'Tỉ lệ đúng bảy ngày gần nhất', chieu: 1,
    y: 'Phần bài làm đúng trong bảy ngày trước mốc. Chỉ báo thẳng nhất, và cũng là chỉ báo dễ bị lẫn với độ khó bài nhất.',
    async tinh(kho, u, moc) {
      const r = await kho.mot(
        'SELECT COUNT(*) AS n, COALESCE(SUM(t.dung),0) AS d ' +
        'FROM luot_thi_tra_loi t JOIN luot_thi l ON l.id = t.luot_id ' +
        'WHERE l.user_id = ? AND t.at < ? AND t.at >= ? AND t.dung IS NOT NULL',
        [u, moc, moc - 7 * NGAY]);
      const n = Number(r.n);
      return n >= 5 ? Number(r.d) / n : null;
    },
  },
  {
    ma: 'so-bai-7n', ten: 'Số bài đã làm bảy ngày gần nhất', chieu: 1,
    y: 'Khối lượng thật. Làm nhiều không chắc học tốt, nhưng làm quá ít thì mọi chỉ báo khác đều không đủ mẫu.',
    async tinh(kho, u, moc) {
      const n = await kho.dem(
        'SELECT COUNT(*) FROM luot_thi_tra_loi t JOIN luot_thi l ON l.id = t.luot_id ' +
        'WHERE l.user_id = ? AND t.at < ? AND t.at >= ?', [u, moc, moc - 7 * NGAY]);
      return n;
    },
  },
  {
    ma: 'giay-moi-cau', ten: 'Số giây trung bình mỗi câu', chieu: 1,
    y: 'Quá nhanh là đoán bừa, quá chậm là đang vật lộn. Chiều +1 vì ở dải bình thường, chậm hơn một chút thường đi với làm kỹ hơn.',
    async tinh(kho, u, moc) {
      const r = await kho.mot(
        'SELECT AVG(t.giay_lam) AS g, COUNT(t.giay_lam) AS n ' +
        'FROM luot_thi_tra_loi t JOIN luot_thi l ON l.id = t.luot_id ' +
        'WHERE l.user_id = ? AND t.at < ? AND t.giay_lam IS NOT NULL', [u, moc]);
      return Number(r.n) >= 5 ? Number(r.g) : null;
    },
  },
  {
    ma: 'doi-dap-an', ten: 'Số lần đổi đáp án trung bình', chieu: -1,
    y: 'Đổi đi đổi lại nhiều là dấu hiệu chưa chắc. Đây là thứ chỉ đo được khi máy ghi lại từng lần đổi, và hệ này có ghi.',
    async tinh(kho, u, moc) {
      const r = await kho.mot(
        'SELECT AVG(t.doi_dap_an) AS d, COUNT(*) AS n ' +
        'FROM luot_thi_tra_loi t JOIN luot_thi l ON l.id = t.luot_id ' +
        'WHERE l.user_id = ? AND t.at < ?', [u, moc]);
      return Number(r.n) >= 5 ? Number(r.d) : null;
    },
  },
  {
    ma: 'chuoi-ngay', ten: 'Số ngày học liên tục', chieu: 1,
    y: 'Đếm chuỗi ngày có buổi học không đứt tính tới mốc. Đều đặn thường quan trọng hơn cường độ.',
    async tinh(kho, u, moc) {
      const ds = await kho.nhieu(
        'SELECT DISTINCT date(bat_dau/1000, \'unixepoch\') AS ng FROM buoi_hoc ' +
        'WHERE user_id = ? AND bat_dau < ? ORDER BY ng DESC LIMIT 120', [u, moc]);
      if (!ds.length) return null;
      let chuoi = 0;
      let truoc = new Date(moc).toISOString().slice(0, 10);
      for (const d of ds) {
        if (d.ng === truoc || d.ng === lui(truoc, 1)) {
          chuoi += 1; truoc = d.ng;
        } else break;
      }
      return chuoi;
    },
  },
  {
    ma: 'deu-gio', ten: 'Học đều giờ', chieu: 1,
    y: 'Đo bằng mức tập trung của các buổi vào một vài khung giờ. Học đúng giờ mỗi ngày dễ giữ hơn học tuỳ hứng.',
    async tinh(kho, u, moc) {
      const ds = await kho.nhieu(
        'SELECT bat_dau FROM buoi_hoc WHERE user_id = ? AND bat_dau < ? LIMIT 400', [u, moc]);
      if (ds.length < 5) return null;
      const dem = new Array(24).fill(0);
      for (const d of ds) dem[new Date(Number(d.bat_dau)).getUTCHours()] += 1;
      const tong = ds.length;
      let h = 0;
      for (const c of dem) if (c > 0) { const p = c / tong; h -= p * Math.log2(p); }
      return 1 - h / Math.log2(24);        // 1 là rất đều, 0 là rải khắp
    },
  },
  {
    ma: 'ngat-quang', ten: 'Số lần ngắt quãng mỗi buổi', chieu: -1,
    y: 'Buổi học bị cắt vụn nhiều lần thì thời lượng có đó mà không thành gì.',
    async tinh(kho, u, moc) {
      const r = await kho.mot(
        'SELECT AVG(ngat_quang) AS x, COUNT(*) AS n FROM buoi_hoc ' +
        'WHERE user_id = ? AND bat_dau < ?', [u, moc]);
      return Number(r.n) >= 3 ? Number(r.x) : null;
    },
  },
  {
    ma: 'tua-video', ten: 'Số lần tua lại video mỗi tập', chieu: -1,
    y: 'Tua lại nhiều ở một chỗ nghĩa là chỗ ấy khó hiểu. Đây là chỉ báo về BÀI GIẢNG nhiều hơn về người học.',
    async tinh(kho, u, moc) {
      const r = await kho.mot(
        'SELECT AVG(tua_lai) AS x, COUNT(*) AS n FROM video_luot_xem ' +
        'WHERE user_id = ? AND at < ?', [u, moc]);
      return Number(r.n) >= 3 ? Number(r.x) : null;
    },
  },
  {
    ma: 'xem-het-video', ten: 'Tỉ lệ xem hết video', chieu: 1,
    y: 'Bỏ dở giữa chừng đều đặn là dấu hiệu bài giảng dài quá hoặc lệch trình độ.',
    async tinh(kho, u, moc) {
      const r = await kho.mot(
        'SELECT AVG(xem_het) AS x, COUNT(*) AS n FROM video_luot_xem ' +
        'WHERE user_id = ? AND at < ?', [u, moc]);
      return Number(r.n) >= 3 ? Number(r.x) : null;
    },
  },
  {
    ma: 'boi-roi', ten: 'Số tín hiệu bối rối', chieu: -1,
    y: 'Đếm từ chính lời người học nói với gia sư, không phải suy đoán.',
    async tinh(kho, u, moc) {
      return kho.dem(
        "SELECT COUNT(*) FROM tutor_signals WHERE user_id = ? AND created_at < ? " +
        "AND signal_type = 'confusion'", [u, moc]);
    },
  },
  {
    ma: 'nam-duoc', ten: 'Số tín hiệu nắm được bài', chieu: 1,
    y: 'Cũng đếm từ lời người học. Đặt cạnh chỉ báo bối rối thì thành một cặp đọc được.',
    async tinh(kho, u, moc) {
      return kho.dem(
        "SELECT COUNT(*) FROM tutor_signals WHERE user_id = ? AND created_at < ? " +
        "AND signal_type = 'mastery'", [u, moc]);
    },
  },
  {
    ma: 'diem-cham-gia-su', ten: 'Điểm người học chấm cho gia sư', chieu: 1,
    y: 'Người học thấy câu trả lời có giúp được mình không. Đo trải nghiệm, không đo kiến thức.',
    async tinh(kho, u, moc) {
      const r = await kho.mot(
        'SELECT AVG(helpful_rating) AS x, COUNT(helpful_rating) AS n FROM tutor_messages ' +
        'WHERE user_id = ? AND created_at < ? AND helpful_rating IS NOT NULL', [u, moc]);
      return Number(r.n) >= 3 ? Number(r.x) : null;
    },
  },
];

function lui(ngayIso, n) {
  const d = new Date(ngayIso + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() - n);
  return d.toISOString().slice(0, 10);
}

/**
 * Kết quả về sau: tỉ lệ làm đúng trong khoảng (moc, moc + chanTroi ngày].
 * Đây là thứ mọi chỉ báo đang cố tiên đoán.
 */
async function ketQuaSau(kho, userId, moc, soNgay) {
  const r = await kho.mot(
    'SELECT COUNT(*) AS n, COALESCE(SUM(t.dung),0) AS d ' +
    'FROM luot_thi_tra_loi t JOIN luot_thi l ON l.id = t.luot_id ' +
    'WHERE l.user_id = ? AND t.at > ? AND t.at <= ? AND t.dung IS NOT NULL',
    [userId, moc, moc + soNgay * NGAY]);
  const n = Number(r.n);
  return n >= 5 ? { giaTri: Number(r.d) / n, soBai: n } : null;
}

/** Lớp và môn của một người học — dùng để khử nhóm. */
async function nhomCua(kho, userId) {
  const h = await kho.mot('SELECT lop FROM ho_so_hoc_vien WHERE user_id = ?', [userId]);
  return h && h.lop !== null ? 'lop-' + h.lop : 'chua-khai';
}

/**
 * Đo sức tiên đoán của MỘT chỉ báo, ở MỘT chân trời.
 *
 * @param mau  [{userId, moc}] — các cặp người-và-mốc đã chọn sẵn
 */
async function doMotChiBao(kho, chiBao, mau, soNgay) {
  const x = [], y = [], nhom = [];
  for (const m of mau) {
    const v = await chiBao.tinh(kho, m.userId, m.moc);
    if (v === null || !Number.isFinite(v)) continue;
    const kq = await ketQuaSau(kho, m.userId, m.moc, soNgay);
    if (!kq) continue;
    x.push(v); y.push(kq.giaTri); nhom.push(m.nhom || 'chung');
  }
  const n = x.length;
  if (n < MAU_TOI_THIEU) {
    return { ma: chiBao.ma, ten: chiBao.ten, soNgay, coMau: n,
      duMau: false, ic: null,
      noiThang: 'Chỉ có ' + n + ' cặp đo được, cần ít nhất ' + MAU_TOI_THIEU
        + '. Không kết luận gì về chỉ báo này.' };
  }
  const xKhu = tk.khuNhom(x, nhom);
  const icTho = tk.spearman(x, y);
  const icKhu = tk.spearman(xKhu, y);
  const kt = tk.khoangTinCay(icKhu, n);
  return {
    ma: chiBao.ma, ten: chiBao.ten, y: chiBao.y, chieu: chiBao.chieu,
    soNgay, coMau: n, duMau: true,
    icTho: icTho === null ? null : Number(icTho.toFixed(4)),
    ic: icKhu === null ? null : Number(icKhu.toFixed(4)),
    khoangTinCay: kt,
    khacKhong: tk.khacKhong(kt),
    duVung: n >= MAU_DE_TIN,
    noiThang: icKhu === null
      ? 'Chỉ báo không đổi trên mẫu này nên không có tương quan để nói.'
      : (!tk.khacKhong(kt)
        ? 'Hệ số ' + icKhu.toFixed(3) + ' nhưng khoảng tin cậy còn chứa số không — '
          + 'chưa nói được là chỉ báo này tiên đoán được gì.'
        : (n < MAU_DE_TIN
          ? 'Có dấu hiệu tiên đoán, nhưng mẫu ' + n + ' còn mỏng; cần khoảng '
            + MAU_DE_TIN + ' mới gọi là vững.'
          : 'Tiên đoán được, trên mẫu ' + n + '.')),
  };
}

/** Đo cả mười hai chỉ báo, ở cả bốn chân trời. */
async function doTatCa(kho, mau, chanTroi) {
  const ct = chanTroi && chanTroi.length ? chanTroi : CHAN_TROI;
  const ra = [];
  for (const cb of CHI_BAO) {
    const theoChanTroi = [];
    for (const n of ct) theoChanTroi.push(await doMotChiBao(kho, cb, mau, n));
    const coIc = theoChanTroi.filter((t) => t.duMau && t.ic !== null);
    const icTb = coIc.length ? tk.trungBinh(coIc.map((t) => t.ic)) : null;
    const icLech = coIc.length > 1 ? tk.doLech(coIc.map((t) => t.ic)) : null;
    ra.push({
      ma: cb.ma, ten: cb.ten, y: cb.y, chieu: cb.chieu,
      theoChanTroi,
      icTrungBinh: icTb === null ? null : Number(icTb.toFixed(4)),
      // IR: trung bình chia độ lệch. Chỉ báo đúng một lần rồi sai mãi có
      // IC đẹp mà IR tệ, và IR mới là thứ quyết định có dùng được không.
      ir: (icTb !== null && icLech !== null && icLech > 1e-9)
        ? Number((icTb / icLech).toFixed(3)) : null,
      suyGiam: moTaSuyGiam(theoChanTroi),
      dungDuoc: coIc.some((t) => t.khacKhong && t.duVung),
    });
  }
  return ra;
}

function moTaSuyGiam(ds) {
  const co = ds.filter((t) => t.duMau && t.ic !== null && t.khacKhong);
  if (co.length < 2) return 'Chưa đủ chân trời đo được để nói về suy giảm.';
  const dau = co[0], cuoi = co[co.length - 1];
  const giam = Math.abs(dau.ic) - Math.abs(cuoi.ic);
  if (giam > 0.05) {
    return 'Mạnh ở ' + dau.soNgay + ' ngày rồi nhạt dần tới ' + cuoi.soNgay
      + ' ngày. Đừng dùng chỉ báo này để xếp lộ trình dài.';
  }
  if (giam < -0.05) {
    return 'Càng nhìn xa càng rõ — hợp để xếp lộ trình dài hơn là để nhắc hằng ngày.';
  }
  return 'Giữ đều qua các chân trời.';
}

/**
 * Gộp các chỉ báo thành một điểm duy nhất, trọng số theo IR ĐO ĐƯỢC.
 *
 * Chỉ nhận chỉ báo đã chứng minh được là khác không và đủ vững. Chỉ báo
 * chưa chứng minh thì trọng số bằng không — không phải một trọng số nhỏ.
 * Cho một chỉ báo chưa chứng minh một trọng số nhỏ là cách êm ái để đưa
 * phỏng đoán vào kết quả.
 */
function gopDiem(daDo, giaTri) {
  const dung = daDo.filter((d) => d.dungDuoc && d.ir !== null);
  if (!dung.length) {
    return { diem: null, dungMayChiBao: 0,
      noiThang: 'Không chỉ báo nào đã chứng minh được sức tiên đoán, nên không gộp '
        + 'điểm nào cả. Gộp bừa thì ra một con số trông khoa học mà rỗng.' };
  }
  const tongTs = dung.reduce((s, d) => s + Math.abs(d.ir), 0);
  let diem = 0;
  const gop = [];
  for (const d of dung) {
    const v = giaTri[d.ma];
    if (v === undefined || v === null) continue;
    const ts = Math.abs(d.ir) / tongTs;
    diem += ts * d.chieu * v;
    gop.push({ ma: d.ma, trongSo: Number(ts.toFixed(4)), giaTri: v });
  }
  return {
    diem: Number(diem.toFixed(4)),
    dungMayChiBao: gop.length,
    thanhPhan: gop,
    noiThang: 'Trọng số lấy từ IR đo được, không lấy từ ý kiến. '
      + (daDo.length - dung.length) + ' chỉ báo bị để trọng số không vì chưa chứng minh được gì.',
  };
}

module.exports = {
  CHI_BAO, CHAN_TROI, MAU_TOI_THIEU, MAU_DE_TIN,
  doMotChiBao, doTatCa, gopDiem, ketQuaSau, nhomCua, moTaSuyGiam, lui,
};
