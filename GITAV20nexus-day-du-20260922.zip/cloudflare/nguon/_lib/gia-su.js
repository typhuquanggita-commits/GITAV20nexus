'use strict';
/**
 * Gia sư AI một kèm một.
 *
 * Hai lớp canh của hệ Node được dùng lại NGUYÊN VẸN ở đây, không chép
 * sang bản thứ hai: lọc đường vào (bảy hình dạng tấn công, chữ giả mạo,
 * ký tự vô hình) và canh đường ra (che số riêng tư, chặn lời hứa kết
 * quả, chặn chẩn đoán, chặn lộ cách phân loại nội bộ). Hai bộ luật chỉ
 * tồn tại ở một chỗ nên không bao giờ lệch nhau.
 *
 * Lời dặn hệ thống được dựng theo hồ sơ người học: phong cách, nhịp độ,
 * độ sâu, cách trình bày, và tâm trạng lúc hỏi. Đây là phần khiến gia sư
 * này khác một ô trò chuyện thường.
 */

const { maMoi } = require('./ma.js');
const congAi = require('./cong-ai.js');
const LocVao = require('../../../src/tro-chuyen/loc-vao.js');
const CanhRa = require('../../../src/tro-chuyen/canh-ra.js');

const DAI_TIN_TOI_DA = 4000;
const LICH_SU_DUA_VAO = 12;      // 6 lượt hỏi–đáp gần nhất
const TIN_MOI_GIO = 60;

const PHONG_CACH = {
  warm: 'Ấm áp, khích lệ. Xưng "mình" và gọi người học là "bạn".',
  direct: 'Ngắn gọn, đi thẳng vấn đề. Không lan man.',
  socratic: 'Đặt câu hỏi gợi mở, dẫn dắt để người học tự tìm ra.',
  humorous: 'Có chút hài hước, ví von vui nhưng vẫn chính xác.',
};
const NHIP_DO = {
  slow: 'Giải thích chi tiết, chia nhỏ từng bước, hỏi lại sau mỗi hai ba đoạn.',
  normal: 'Giải thích vừa phải, có ví dụ, hỏi lại sau mỗi bốn năm đoạn.',
  fast: 'Đi thẳng vào ý chính, ít ví dụ, giả định người học đã nắm phần cơ bản.',
};
const DO_SAU = {
  overview: 'Chỉ đưa bức tranh tổng thể, không đi sâu chi tiết.',
  balanced: 'Cân bằng giữa tổng quan và chi tiết, có ví dụ cụ thể.',
  deep: 'Đi sâu vào cơ chế, nguyên lý, và các trường hợp biên.',
};
const CACH_HOC = {
  visual: 'Khi có thể thì mô tả bằng sơ đồ, bảng, hình.',
  auditory: 'Dùng nhịp câu, ví von âm thanh, gợi ý đọc to lên.',
  kinesthetic: 'Đưa một bài tập làm ngay sau mỗi khái niệm.',
  reading: 'Đưa ví dụ dạng bài đọc và trích dẫn nguồn.',
  balanced: 'Kết hợp nhiều cách trình bày.',
};
const TAM_TRANG = {
  focused: 'Người học đang tập trung — đi sâu vào nội dung.',
  tired: 'Người học có vẻ mệt — rút ngắn, ví dụ nhẹ, gợi ý nghỉ một lát.',
  frustrated: 'Người học đang bế tắc — khích lệ, chia nhỏ vấn đề, đừng thêm áp lực.',
  curious: 'Người học đang tò mò — mở rộng chủ đề, gợi ý hướng khám phá.',
  bored: 'Người học có vẻ chán — thêm ví dụ thú vị, một câu đố ngắn, tình huống thật.',
};

const HO_SO_MAC_DINH = {
  learning_style: 'balanced', pace: 'normal', depth_pref: 'balanced',
  preferred_lang: 'vi', interests_json: '[]', goals_json: '[]',
  timezone: 'Asia/Ho_Chi_Minh', response_style: 'warm',
};

function docMang(chu) {
  try { const v = JSON.parse(chu || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; }
}

async function hoSo(kho, userId, bayGio) {
  const r = await kho.mot('SELECT * FROM tutor_profiles WHERE user_id = ?', [userId]);
  if (r) return r;
  const now = bayGio;
  await kho.chen('tutor_profiles',
    Object.assign({ user_id: userId, created_at: now, updated_at: now }, HO_SO_MAC_DINH));
  return Object.assign({ user_id: userId, created_at: now, updated_at: now }, HO_SO_MAC_DINH);
}

function dungLoiDan(hs, boiCanh) {
  const so = [];
  so.push('# VAI');
  so.push('Bạn là gia sư riêng của GITAV20nexus, dạy người Việt.');
  so.push('');
  so.push('# PHONG CÁCH');
  so.push(PHONG_CACH[hs.response_style] || PHONG_CACH.warm);
  so.push('');
  so.push('# NHỊP ĐỘ');
  so.push(NHIP_DO[hs.pace] || NHIP_DO.normal);
  so.push('');
  so.push('# ĐỘ SÂU');
  so.push(DO_SAU[hs.depth_pref] || DO_SAU.balanced);
  so.push('');
  so.push('# CÁCH TRÌNH BÀY');
  so.push(CACH_HOC[hs.learning_style] || CACH_HOC.balanced);
  so.push('');
  so.push('# TÂM TRẠNG NGƯỜI HỌC LÚC NÀY');
  so.push(TAM_TRANG[boiCanh.tamTrang] || TAM_TRANG.focused);

  const thich = docMang(hs.interests_json);
  const dich = docMang(hs.goals_json);
  so.push('');
  so.push('# HỒ SƠ');
  so.push('- Quan tâm: ' + (thich.length ? thich.join(', ') : 'chưa rõ'));
  so.push('- Mục tiêu: ' + (dich.length ? dich.join(', ') : 'chưa rõ'));

  if (boiCanh.tenBai) {
    so.push('');
    so.push('# ĐANG HỌC');
    so.push('Bài: "' + boiCanh.tenBai + '"');
    if (boiCanh.noiDungBai) {
      so.push('Nội dung bài (dùng làm nguồn, không bịa thêm ngoài phần này):');
      so.push(String(boiCanh.noiDungBai).slice(0, 6000));
    }
  }

  so.push('');
  so.push('# LUẬT KHÔNG ĐƯỢC PHÁ');
  so.push('1. Có phần "ĐANG HỌC" thì chỉ dựa vào đó. Không bịa thêm dữ kiện.');
  so.push('2. Không chẩn đoán y tế, tâm lý hay pháp lý cho bất kỳ ai.');
  so.push('3. Không hứa trước kết quả học tập của một con người.');
  so.push('4. Không đủ căn cứ thì nói thẳng là chưa đủ, đừng đoán.');
  so.push('5. Ký hiệu toán viết theo chuẩn quốc tế.');
  so.push('6. Kết mỗi lượt bằng một câu hỏi mở hoặc một việc cụ thể để làm.');
  so.push('');
  so.push('# DẠNG TRẢ LỜI');
  so.push('Trả về đúng một đối tượng JSON, không kèm lời dẫn:');
  so.push('{"traLoi":"...", "goiY":["...","..."], "viecLam":[{"loai":"quiz","nhan":"..."}]}');
  return so.join('\n');
}

/**
 * Nhận ra tín hiệu học tập từ câu người học vừa gõ.
 *
 * Đặc tả gốc coi "tại sao" và "làm sao" là dấu hiệu bối rối — nhưng đó
 * là cách mở đầu của gần như mọi câu hỏi, nên nó kêu suốt và thành vô
 * nghĩa. Ở đây chỉ tính là bối rối khi người học nói thẳng rằng chưa
 * hiểu, hoặc hỏi lại đúng thứ vừa được giải thích.
 */
const KHUON_BOI_ROI = [
  /không\s+hiểu|chưa\s+hiểu|khó\s+hiểu|rối\s+quá|loạn\s+hết/i,
  /nghĩa\s+là\s+(gì|sao)|hiểu\s+sao\s+(đây|giờ)/i,
  /giải\s+thích\s+lại|nói\s+lại\s+(giúp|hộ)/i,
];
const KHUON_NAM_DUOC = [
  /^(hiểu\s+rồi|ok|rõ\s+rồi|à\s+ra\s+thế|em\s+hiểu\s+rồi)/i,
  /giờ\s+(tôi|em|mình)\s+(có\s+thể|làm\s+được)|đã\s+làm\s+được/i,
];

function nhanTinHieu(cauHoi, soLuotTruoc, daHoiLai) {
  const ra = [];
  if (KHUON_BOI_ROI.some((k) => k.test(cauHoi))) {
    ra.push({ loai: 'confusion', manh: 0.7, cho: { cau: cauHoi.slice(0, 100) } });
  } else if (daHoiLai) {
    ra.push({ loai: 'repetition', manh: 0.6, cho: { lyDo: 'hỏi lại gần như nguyên câu cũ' } });
  }
  if (KHUON_NAM_DUOC.some((k) => k.test(cauHoi))) {
    ra.push({ loai: 'mastery', manh: 0.8, cho: { cau: cauHoi.slice(0, 100) } });
  }
  if (cauHoi.trim().length < 5 && soLuotTruoc > 5) {
    ra.push({ loai: 'dropoff', manh: 0.5, cho: { dai: cauHoi.trim().length } });
  }
  return ra;
}

/** So thô hai câu — đủ để biết người học đang hỏi lại chính câu vừa hỏi. */
function ganGiongNhau(a, b) {
  const chuan = (s) => String(s).toLowerCase().replace(/\s+/g, ' ').trim();
  const x = chuan(a), y = chuan(b);
  if (!x || !y) return false;
  if (x === y) return true;
  const tx = new Set(x.split(' ')), ty = new Set(y.split(' '));
  let chung = 0;
  for (const t of tx) if (ty.has(t)) chung++;
  return chung / Math.max(tx.size, ty.size) >= 0.8;
}

function docTraLoi(chu) {
  const s = String(chu || '').replace(/^```(?:json)?\s*|\s*```$/g, '').trim();
  try {
    const v = JSON.parse(s);
    if (v && typeof v === 'object' && typeof v.traLoi === 'string') {
      return {
        traLoi: v.traLoi,
        goiY: Array.isArray(v.goiY) ? v.goiY.slice(0, 5).map(String) : [],
        viecLam: Array.isArray(v.viecLam) ? v.viecLam.slice(0, 5) : [],
        dungDang: true,
      };
    }
  } catch (e) { /* rơi xuống dưới */ }
  // Nhà cung cấp trả về văn xuôi thay vì JSON: vẫn dùng được, chỉ là
  // không có gợi ý. Bỏ cả lượt vì sai khuôn là phí một lượt hạn mức.
  return { traLoi: s, goiY: [], viecLam: [], dungDang: false };
}

/**
 * Một lượt trò chuyện. Trả về { dat, ... } hoặc { dat:false, ma, loi }.
 */
async function troChuyen(kho, moi, tham, bayGio) {
  const loc = new LocVao({ daiToiDa: DAI_TIN_TOI_DA });
  const canh = new CanhRa({ tuongRoRi: tham.tuongRoRi });

  const cauHoi = String(tham.cauHoi || '');
  const vao = loc.soi(cauHoi);
  if (!vao.dat) {
    return { dat: false, ma: 'cau-hoi-bi-chan', loi: loc.loiTuChoi(vao), lyDo: vao.ma };
  }

  const hs = await hoSo(kho, tham.userId, bayGio);
  const lichSu = await kho.nhieu(
    'SELECT role, content FROM tutor_messages WHERE thread_id = ? ORDER BY created_at DESC LIMIT ?',
    [tham.maLuong, LICH_SU_DUA_VAO]);
  lichSu.reverse();

  const cauNguoiTruoc = [...lichSu].reverse().find((m) => m.role === 'user');
  const daHoiLai = !!(cauNguoiTruoc && ganGiongNhau(cauNguoiTruoc.content, cauHoi));

  const loiDan = dungLoiDan(hs, {
    tamTrang: tham.tamTrang, tenBai: tham.tenBai, noiDungBai: tham.noiDungBai,
  });
  const tinNhan = [{ role: 'system', content: loiDan }]
    .concat(lichSu.map((m) => ({ role: m.role === 'assistant' ? 'assistant' : 'user',
      content: m.content })))
    .concat([{ role: 'user', content: cauHoi }]);

  const now = bayGio;
  const maCauHoi = maMoi();
  await kho.chen('tutor_messages', {
    id: maCauHoi, thread_id: tham.maLuong, user_id: tham.userId, role: 'user',
    content: cauHoi, mood: tham.tamTrang || null,
    user_state_json: tham.trangThai ? JSON.stringify(tham.trangThai) : null,
    created_at: now,
  });

  let r;
  try {
    r = await congAi.sinh(kho, moi,
      { tinNhan, kieuJson: true, nhietDo: 0.4, theToiDa: 2048 }, () => bayGio);
  } catch (e) {
    return { dat: false, ma: 'ai-khong-goi-duoc', loi: e.message, duongDaDi: e.duongDaDi };
  }

  const banRa = docTraLoi(r.chu);
  const ra = canh.soi(banRa.traLoi, { vai: tham.vai });
  if (!ra.dat) {
    // Câu máy sinh ra vi phạm — KHÔNG lưu nó, và nói thẳng với người học.
    await kho.chen('tutor_signals', {
      id: maMoi(), user_id: tham.userId, signal_type: 'confusion', content_id: maCauHoi,
      strength: 0.3, evidence_json: JSON.stringify({ chanODuongRa: ra.ma }), created_at: now,
    });
    return { dat: false, ma: 'cau-tra-loi-bi-chan', loi: canh.loiThay(ra), lyDo: ra.ma };
  }

  const maTraLoi = maMoi();
  await kho.chen('tutor_messages', {
    id: maTraLoi, thread_id: tham.maLuong, user_id: tham.userId, role: 'assistant',
    content: ra.chu,
    content_json: JSON.stringify({ goiY: banRa.goiY, viecLam: banRa.viecLam }),
    model: r.mauMay, provider: r.nha, tokens_in: r.theVao, tokens_out: r.theRa,
    latency_ms: r.treMs, created_at: now,
  });

  await kho.chay(
    'UPDATE tutor_threads SET message_count = message_count + 2, ' +
    '  tokens_used = tokens_used + ?, updated_at = ? WHERE id = ?',
    [Number(r.theVao) + Number(r.theRa), now, tham.maLuong]);

  for (const t of nhanTinHieu(cauHoi, lichSu.length, daHoiLai)) {
    await kho.chen('tutor_signals', {
      id: maMoi(), user_id: tham.userId, signal_type: t.loai, content_id: maCauHoi,
      strength: t.manh, evidence_json: JSON.stringify(t.cho), created_at: now,
    });
  }

  return {
    dat: true, maTinNhan: maTraLoi, traLoi: ra.chu,
    goiY: banRa.goiY, viecLam: banRa.viecLam,
    daCheSoRieng: ra.daChe.length,
    nha: r.nha, mauMay: r.mauMay, treMs: r.treMs,
    theoDungDang: banRa.dungDang,
  };
}

module.exports = {
  troChuyen, hoSo, dungLoiDan, nhanTinHieu, docTraLoi, ganGiongNhau,
  PHONG_CACH, NHIP_DO, DO_SAU, CACH_HOC, TAM_TRANG, HO_SO_MAC_DINH,
  DAI_TIN_TOI_DA, TIN_MOI_GIO, docMang,
};
