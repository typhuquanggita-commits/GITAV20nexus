'use strict';
/**
 * Hạn mức theo ngày, đếm trong D1.
 *
 * Cố ý KHÔNG dùng KV: KV chỉ cho 1.000 lượt ghi mỗi ngày ở bậc miễn phí,
 * mà đếm hạn mức thì ghi mỗi lượt gọi. D1 cho 100.000 lượt ghi/ngày nên
 * chỗ này phải nằm ở D1. Đây là ràng buộc thật của bậc miễn phí, không
 * phải sở thích.
 */

const MUC = {
  'ai':        { ngay: 200,  ten: 'gọi trợ lý AI' },
  'dang-nhap': { ngay: 50,   ten: 'thử đăng nhập' },
  'ghi':       { ngay: 1000, ten: 'ghi dữ liệu' },
  'doc':       { ngay: 5000, ten: 'đọc dữ liệu' },
};

function ngayCua(bayGio) {
  return new Date(bayGio || Date.now()).toISOString().slice(0, 10);
}

/**
 * Tăng một và trả về tình trạng. Nếu đã vượt thì KHÔNG tăng nữa, để một
 * kẻ gõ liên tục không đẩy con số lên vô hạn.
 */
async function xin(kho, xo, khoa, bayGio) {
  const muc = MUC[xo];
  if (!muc) throw new Error('xo-khong-biet: ' + xo);
  const now = bayGio || Date.now();
  const ngay = ngayCua(now);
  const id = xo + ':' + khoa + ':' + ngay;
  const hien = await kho.mot('SELECT count FROM rate_counters WHERE id = ?', [id]);
  const da = hien ? Number(hien.count) : 0;
  if (da >= muc.ngay) {
    return { cho: false, da, tran: muc.ngay, conLai: 0, ten: muc.ten };
  }
  if (hien) {
    await kho.chay('UPDATE rate_counters SET count = count + 1, updated_at = ? WHERE id = ?',
      [now, id]);
  } else {
    await kho.chen('rate_counters',
      { id, bucket: xo, day: ngay, count: 1, updated_at: now });
  }
  return { cho: true, da: da + 1, tran: muc.ngay, conLai: muc.ngay - da - 1, ten: muc.ten };
}

async function xem(kho, xo, khoa, bayGio) {
  const muc = MUC[xo] || { ngay: 0, ten: xo };
  const r = await kho.mot('SELECT count FROM rate_counters WHERE id = ?',
    [xo + ':' + khoa + ':' + ngayCua(bayGio)]);
  const da = r ? Number(r.count) : 0;
  return { da, tran: muc.ngay, conLai: Math.max(0, muc.ngay - da), ten: muc.ten };
}

/** Dọn số đếm cũ — gọi từ lịch Cron. */
async function quet(kho, bayGio) {
  const cu = new Date((bayGio || Date.now()) - 3 * 86400000).toISOString().slice(0, 10);
  const r = await kho.chay('DELETE FROM rate_counters WHERE day < ?', [cu]);
  return (r && r.meta && r.meta.changes) || (r && r.changes) || 0;
}

module.exports = { MUC, xin, xem, quet, ngayCua };
