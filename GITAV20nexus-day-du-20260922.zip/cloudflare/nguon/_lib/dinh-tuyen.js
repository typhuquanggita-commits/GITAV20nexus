'use strict';
/**
 * Bộ định tuyến nhỏ, đủ cho 251 đường của đặc tả V13.
 *
 * Hai điều đáng nói:
 *  1. Đường có mẫu (/sessions/:id/answer) được biên dịch một lần lúc nạp,
 *     không phải mỗi lần có yêu cầu.
 *  2. Đường tĩnh tra bằng bảng băm; chỉ đường có tham số mới phải duyệt.
 *     Với 251 đường thì đây là khác biệt thật, không phải tối ưu hão.
 */

function tachMau(mau) {
  const doan = mau.split('/').filter(Boolean);
  const ten = [];
  for (const d of doan) if (d.startsWith(':')) ten.push(d.slice(1));
  return { doan: doan, ten: ten, coThamSo: ten.length > 0 };
}

function BoDinhTuyen() {
  const tinh = new Map();      // "GET /api/v13/providers" -> xu_ly
  const dong = [];             // { cach, doan, ten, xuLy }
  const duong = [];            // để liệt kê ra ngoài

  function them(cach, mau, xuLy, ghiChu) {
    const c = cach.toUpperCase();
    duong.push({ cach: c, mau: mau, ghiChu: ghiChu || '' });
    const m = tachMau(mau);
    if (!m.coThamSo) {
      const khoa = c + ' ' + mau;
      if (tinh.has(khoa)) throw new Error('Trùng đường: ' + khoa);
      tinh.set(khoa, xuLy);
      return;
    }
    dong.push({ cach: c, doan: m.doan, ten: m.ten, xuLy: xuLy, mau: mau });
  }

  function tim(cach, duongDan) {
    const c = cach.toUpperCase();
    const thang = tinh.get(c + ' ' + duongDan);
    if (thang) return { xuLy: thang, thamSo: {} };

    const doan = duongDan.split('/').filter(Boolean);
    for (const r of dong) {
      if (r.cach !== c || r.doan.length !== doan.length) continue;
      const thamSo = {};
      let khop = true;
      for (let i = 0; i < r.doan.length; i++) {
        const mau = r.doan[i];
        if (mau.charCodeAt(0) === 58 /* ':' */) {
          const gt = decodeURIComponent(doan[i]);
          if (gt === '') { khop = false; break; }
          thamSo[mau.slice(1)] = gt;
        } else if (mau !== doan[i]) { khop = false; break; }
      }
      if (khop) return { xuLy: r.xuLy, thamSo: thamSo };
    }
    return null;
  }

  /** Có đường này ở cách khác không — để trả 405 thay vì 404 cho đúng. */
  function coDuongKhacCach(duongDan) {
    const doan = duongDan.split('/').filter(Boolean);
    const ra = [];
    for (const k of tinh.keys()) {
      const [c, d] = k.split(' ');
      if (d === duongDan) ra.push(c);
    }
    for (const r of dong) {
      if (r.doan.length !== doan.length) continue;
      let khop = true;
      for (let i = 0; i < r.doan.length; i++) {
        if (r.doan[i].charCodeAt(0) !== 58 && r.doan[i] !== doan[i]) { khop = false; break; }
      }
      if (khop) ra.push(r.cach);
    }
    return [...new Set(ra)];
  }

  return {
    them: them,
    tim: tim,
    coDuongKhacCach: coDuongKhacCach,
    duong: duong,
    get soDuong() { return duong.length; },
    /** Gắn cả một nhóm tuyến vào tiền tố, đúng kiểu .route() của đặc tả. */
    gan: function (tienTo, khai) {
      khai(function (cach, mau, xuLy, ghiChu) {
        them(cach, tienTo + (mau === '/' ? '' : mau), xuLy, ghiChu);
      });
    },
  };
}

module.exports = { BoDinhTuyen, tachMau };
