'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BỘ NÃO TRUNG TÂM — cửa vào duy nhất của mọi lệnh
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Mọi yêu cầu đi qua đúng năm bước, theo đúng thứ tự này, không có
 *  đường tắt nào:
 *
 *      1. BẢO MẬT     — hai mươi hai lớp canh
 *      2. HIẾN PHÁP   — mười lăm điều, mỗi điều có căn cứ pháp lý
 *      3. ĐỌC LỆNH    — lệnh này thuộc loại gì, ban nào lo, nặng hay nhẹ
 *      4. GIAO VIỆC   — chọn ban và trợ lý còn sức chứa
 *      5. THANH TRA   — soi lại kết quả trước khi trả ra
 *
 *  VÌ SAO PHẢI CÓ MỘT CỬA DUY NHẤT. Sáu trăm trợ lý mà mỗi người tự
 *  quyết thì không ai trả lời được câu "hệ thống đã làm gì hôm qua".
 *  Ở đây mỗi lệnh để lại đúng một dòng, và dòng ấy nói lệnh đã đi qua
 *  những cửa nào, bị chặn ở cửa nào, ai làm, mất bao lâu.
 *
 *  BỘ NÃO KHÔNG GỌI MÔ HÌNH NGÔN NGỮ. Việc đọc lệnh và chọn ban là
 *  bảng tra, không phải một câu nhắc. Một bộ điều phối mà mỗi lần nghĩ
 *  lại ra một kết quả khác thì không điều phối được gì.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { maMoi } = require('./ma.js');
const baoMat = require('./bao-mat.js');
const hienPhap = require('./hien-phap.js');

const UU_TIEN = ['thap', 'thuong', 'cao', 'khan'];

/**
 * Bảng đọc lệnh: tiền tố đường dẫn → ban lo việc và mức nặng.
 * Tra bảng, không đoán. Đường không có trong bảng vẫn chạy, chỉ là
 * không giao xuống ban nào — và điều đó được ghi lại.
 */
const BANG_DOC = [
  { tienTo: '/api/chuong-trinh', ban: 'lo-trinh', loai: 'chuong-trinh', uuTien: 'thuong' },
  { tienTo: '/api/kho-bai', ban: 'toan', loai: 'kho-bai', uuTien: 'thuong' },
  { tienTo: '/api/luyen-thi', ban: 'khao-thi', loai: 'luyen-thi', uuTien: 'cao' },
  { tienTo: '/api/khao-sat', ban: 'tam-ly', loai: 'khao-sat', uuTien: 'cao' },
  { tienTo: '/api/lo-trinh', ban: 'lo-trinh', loai: 'lo-trinh', uuTien: 'cao' },
  { tienTo: '/api/trai', ban: 'trai', loai: 'trai', uuTien: 'thuong' },
  { tienTo: '/api/bo-nao', ban: 'chat-luong', loai: 'quan-tri', uuTien: 'cao' },
  { tienTo: '/api/crm', ban: null, loai: 'quan-he-gia-dinh', uuTien: 'cao' },
  { tienTo: '/api/ke-toan', ban: null, loai: 'tai-chinh', uuTien: 'khan' },
  { tienTo: '/api/chuoi-video', ban: 'noi-dung', loai: 'video', uuTien: 'thap' },
  { tienTo: '/api/v16/tutor', ban: 'toan', loai: 'gia-su', uuTien: 'cao' },
  { tienTo: '/api/v13/translations', ban: 'tieng-anh', loai: 'dich', uuTien: 'thuong' },
  { tienTo: '/api/v13/providers', ban: 'ky-thuat', loai: 'ha-tang', uuTien: 'thuong' },
  { tienTo: '/api/v13/sync', ban: 'ky-thuat', loai: 'dong-bo', uuTien: 'thap' },
  { tienTo: '/api/tai-khoan', ban: null, loai: 'tai-khoan', uuTien: 'khan' },
  { tienTo: '/api/health', ban: null, loai: 'tinh-trang', uuTien: 'thap' },
];

/** Việc nào luôn phải có một con người bấm duyệt — Điều 14. */
const CAN_NGUOI_DUYET = [
  { cach: 'POST', khuon: /^\/api\/ke-toan\/chung-tu\/[^/]+\/ghi-so$/ },
  { cach: 'POST', khuon: /^\/api\/ke-toan\/ky\/[^/]+\/khoa$/ },
  { cach: 'POST', khuon: /^\/api\/tai-khoan\/[^/]+\/vai$/ },
  { cach: 'POST', khuon: /^\/api\/tai-khoan\/[^/]+\/khoa$/ },
  { cach: 'POST', khuon: /^\/api\/lo-trinh\/mo-cap-bang-tay\// },
  { cach: 'POST', khuon: /^\/api\/trai\/khoa\/[^/]+\/xet-ra\// },
];

/** Việc phá hoại — bộ canh D5 hỏi tới danh sách này. */
function viecCua(cach, duongDan) {
  if (cach === 'DELETE') return 'xoa-du-lieu';
  if (/\/xuat-toan-bo|\/export\/all/.test(duongDan)) return 'xuat-toan-bo';
  return null;
}

function docLenh(cach, duongDan) {
  const m = BANG_DOC.find((x) => duongDan.startsWith(x.tienTo));
  const canDuyet = CAN_NGUOI_DUYET.some(
    (x) => x.cach === cach && x.khuon.test(duongDan));
  return {
    loai: m ? m.loai : 'chua-phan-loai',
    ban: m ? m.ban : null,
    uuTien: canDuyet ? 'khan' : (m ? m.uuTien : 'thuong'),
    canNguoiDuyet: canDuyet,
    doi: cach !== 'GET' && cach !== 'HEAD',
  };
}

/**
 * Chọn một trợ lý trong ban, theo sức chứa còn lại của hôm nay.
 * Không có ai rảnh thì trả về null — và bộ não ghi lại điều đó thay vì
 * giao ép.
 */
async function chonTroLy(kho, banId, vai, ngay) {
  if (!banId) return null;
  const ds = await kho.nhieu(
    'SELECT t.id, t.suc_chua_ngay, COALESCE(k.viec_nhan, 0) AS da_nhan ' +
    'FROM tro_ly t LEFT JOIN kpi_tro_ly k ON k.tro_ly_id = t.id AND k.ngay = ? ' +
    "WHERE t.ban_id = ? AND t.vai = ? AND t.trang_thai IN ('ranh','dang-lam') " +
    'ORDER BY da_nhan ASC, t.id ASC LIMIT 20', [ngay, banId, vai || 'thuc-thi']);
  const chon = ds.find((x) => Number(x.da_nhan) < Number(x.suc_chua_ngay));
  return chon ? chon.id : null;
}

/**
 * Thanh tra: soi lại câu trả lời trước khi nó rời hệ thống.
 *
 * Ba điều kiểm, và cả ba đều là điều đã từng hỏng thật ở một hệ nào đó:
 *  1. Mã trạng thái phải hợp lý với nội dung — 200 kèm {dat:false} là
 *     nói dối máy gọi.
 *  2. Câu trả lời không được mang vết ngăn xếp hay tên bảng ra ngoài.
 *  3. Câu trả lời không được mang phân loại nội bộ về gia đình.
 */
const VET_LO = [
  { ma: 'vet-ngan-xep', re: /\bat\s+\w+\s+\([^)]*\.js:\d+:\d+\)/, vi: 'Vết ngăn xếp lọt ra ngoài.' },
  { ma: 'duong-dan-may', re: /\/home\/[a-z0-9_-]+\/|[A-Z]:\\Users\\/i, vi: 'Đường dẫn trên máy chủ lọt ra ngoài.' },
  { ma: 'cau-sql', re: /\bSELECT\b[\s\S]{0,60}\bFROM\b\s+[a-z_]+/i, vi: 'Câu SQL lọt ra ngoài.' },
  { ma: 'cay-tien', re: /cay_tien_nhom|cay-tien-nhom/i, vi: 'Phân loại nội bộ về gia đình lọt ra ngoài.' },
];

function thanhTra(maTrangThai, chuTraLoi) {
  const loi = [];
  let than = null;
  try { than = JSON.parse(chuTraLoi); } catch (e) { than = null; }
  if (than && typeof than === 'object' && than.dat === false && maTrangThai < 400) {
    loi.push({ ma: 'ma-trang-thai-lech',
      vi: 'Thân nói không đạt mà mã trạng thái là ' + maTrangThai + '.' });
  }
  if (than && typeof than === 'object' && than.dat === true && maTrangThai >= 400) {
    loi.push({ ma: 'ma-trang-thai-lech',
      vi: 'Thân nói đạt mà mã trạng thái là ' + maTrangThai + '.' });
  }
  for (const v of VET_LO) if (v.re.test(chuTraLoi)) loi.push({ ma: v.ma, vi: v.vi });
  return { dat: loi.length === 0, loi };
}

/**
 * Chạy một lệnh qua bộ não.
 *
 * @param {Function} lam  hàm làm việc thật, nhận bối cảnh và trả về Response
 */
async function chay(tham) {
  const { req, moi, kho, bayGio, nguoi, dap } = tham;
  const t0 = bayGio();
  const url = new URL(req.url);
  const duongDan = url.pathname;
  const cach = req.method;
  const doc = docLenh(cach, duongDan);
  const maLenh = maMoi();
  const ngay = new Date(t0).toISOString().slice(0, 10);

  // ── 1. BẢO MẬT — hai mươi hai lớp ──
  const bc = await baoMat.boiCanhTu(req, kho, tham.than, t0, {
    userId: nguoi ? nguoi.id : null,
    vai: nguoi ? nguoi.vai : null,
    viec: viecCua(cach, duongDan),
    daCoNguoiDuyet: !!tham.daCoNguoiDuyet,
    canDangNhap: false,
    nuocChan: (moi.NUOC_CHAN || '').split(',').map((x) => x.trim()).filter(Boolean),
  });
  const sec = await baoMat.soi(bc);
  if (!sec.dat) {
    await baoMat.ghiChan(kho, sec, bc, t0);
    await ghiLenh(kho, {
      id: maLenh, loai: doc.loai, uuTien: doc.uuTien, nguoi, ip: bc.ip,
      duongDan, trangThai: 'chan-bao-mat', chanTai: sec.lop, doi: doc.doi,
      ms: bayGio() - t0, at: t0,
    }, moi);
    return {
      chan: true,
      tra: dap.hong(403, 'bi-chan-o-lop-canh',
        'Yêu cầu bị dừng ở lớp canh ' + sec.lop + '. ' + sec.vi,
        { lop: sec.lop, giaiDoan: sec.giaiDoan, maLenh }),
    };
  }

  // ── 2. HIẾN PHÁP ──
  const hp = soiHienPhap(doc, nguoi, duongDan);
  if (!hp.dat) {
    await kho.chen('vi_pham_hien_phap', {
      id: maMoi(), dieu: hp.dieu, user_id: nguoi ? nguoi.id : null,
      bang_chung_json: JSON.stringify({ duongDan, cach, lyDo: hp.vi }),
      xu_ly: hp.xuLy, at: t0,
    });
    await ghiLenh(kho, {
      id: maLenh, loai: doc.loai, uuTien: doc.uuTien, nguoi, ip: bc.ip,
      duongDan, trangThai: 'chan-hien-phap', chanTai: 'Điều ' + hp.dieu, doi: doc.doi,
      ms: bayGio() - t0, at: t0,
    }, moi);
    return {
      chan: true,
      tra: dap.hong(403, 'pham-hien-phap',
        'Điều ' + hp.dieu + ' của hiến pháp vận hành không cho việc này. ' + hp.vi,
        { dieu: hp.dieu, xuLy: hp.xuLy, maLenh }),
    };
  }

  // ── 3 và 4. ĐỌC LỆNH rồi GIAO VIỆC ──
  const troLy = doc.doi ? await chonTroLy(kho, doc.ban, 'thuc-thi', ngay) : null;
  if (troLy) {
    await kho.chay(
      'INSERT INTO kpi_tro_ly (id, tro_ly_id, ngay, viec_nhan) VALUES (?, ?, ?, 1) ' +
      'ON CONFLICT(tro_ly_id, ngay) DO UPDATE SET viec_nhan = viec_nhan + 1',
      [maMoi(), troLy, ngay]);
  }

  return {
    chan: false,
    maLenh,
    doc,
    troLy,
    danhDau: sec.danhDau,
    /** Gọi sau khi tuyến đã trả lời, để thanh tra và ghi sổ. */
    async ketThuc(tra) {
      const chu = await tra.clone().text();
      const soi = thanhTra(tra.status, chu);
      const ms = bayGio() - t0;
      await ghiLenh(kho, {
        id: maLenh, loai: doc.loai, uuTien: doc.uuTien, nguoi, ip: bc.ip,
        duongDan, trangThai: soi.dat ? 'xong' : 'hong', doi: doc.doi,
        uuTien: doc.uuTien,
        banGiao: { ban: doc.ban, troLy, canNguoiDuyet: doc.canNguoiDuyet },
        soi: soi.dat ? null : soi.loi,
        ms, at: t0,
      }, moi);
      if (troLy && soi.dat) {
        await kho.chay(
          'INSERT INTO kpi_tro_ly (id, tro_ly_id, ngay, viec_xong) VALUES (?, ?, ?, 1) ' +
          'ON CONFLICT(tro_ly_id, ngay) DO UPDATE SET viec_xong = viec_xong + 1',
          [maMoi(), troLy, ngay]);
      }
      try { await baoMat.capNhatNep(kho, bc, t0); } catch (e) { /* nếp hỏng không chặn lệnh */ }

      if (!soi.dat) {
        // Thanh tra bắt được thì KHÔNG trả câu ấy ra ngoài. Trả ra một câu
        // trung thực về việc đã dừng, còn chi tiết nằm trong sổ.
        return dap.hong(500, 'thanh-tra-chan',
          'Câu trả lời bị thanh tra giữ lại trước khi rời hệ thống: '
          + soi.loi.map((l) => l.vi).join(' '),
          { maLenh });
      }
      return tra;
    },
  };
}

function soiHienPhap(doc, nguoi, duongDan) {
  // Điều 8 — phân loại nội bộ không ra đường công khai.
  if (/\/cay-tien/.test(duongDan) && (!nguoi || nguoi.vai === 'LEARNER' || nguoi.vai === 'PARENT')) {
    const d = hienPhap.DIEU.find((x) => x.dieu === 8);
    return { dat: false, dieu: 8, vi: d.noi_dung.split('.')[0] + '.', xuLy: d.vi_pham_thi };
  }
  // Điều 14 — việc có hậu quả phải có người duyệt, và người duyệt phải là người.
  if (doc.canNguoiDuyet && nguoi && nguoi.vai === 'GUEST') {
    const d = hienPhap.DIEU.find((x) => x.dieu === 14);
    return { dat: false, dieu: 14, vi: 'Việc này cần một con người có quyền bấm duyệt.',
      xuLy: d.vi_pham_thi };
  }
  return { dat: true };
}

/**
 * Có ghi dòng nhật ký cho lệnh này không.
 *
 * D1 ở bậc miễn phí cho 100.000 lượt ghi mỗi ngày. Ghi mọi lượt đọc thì
 * riêng nhật ký đã ăn hết hạn mức trước khi hệ thống làm được việc gì.
 * Nên: lệnh làm ĐỔI dữ liệu và lệnh BỊ CHẶN ghi đủ, lệnh chỉ đọc thì lấy
 * mẫu. Lấy mẫu chứ không bỏ hẳn, vì một dòng trong hai mươi vẫn đủ để
 * thấy hình dạng của lưu lượng.
 */
function coGhi(l, moi) {
  if (l.trangThai !== 'xong') return true;          // chặn và hỏng: ghi đủ
  if (l.uuTien === 'khan' || l.uuTien === 'cao') return true;
  if (String(moi && moi.BO_NAO_GHI_MOI_LUOT) === 'true') return true;
  if (l.doi) return true;                            // lệnh đổi dữ liệu: ghi đủ
  // Lấy mẫu tất định theo mã lệnh, không dùng Math.random.
  let h = 0;
  for (let i = 0; i < l.id.length; i++) h = (h * 31 + l.id.charCodeAt(i)) % 20;
  return h === 0;
}

async function ghiLenh(kho, l, moi) {
  if (!coGhi(l, moi)) return;
  await kho.chay(
    'INSERT INTO lenh_bo_nao (id, loai, uu_tien, user_id, vai, ip, duong_dan, ' +
    '  trang_thai, chan_tai, ban_giao_json, soi_json, ms, at) ' +
    'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ' +
    'ON CONFLICT(id) DO UPDATE SET trang_thai = excluded.trang_thai, ' +
    '  ban_giao_json = excluded.ban_giao_json, soi_json = excluded.soi_json, ' +
    '  ms = excluded.ms',
    [l.id, l.loai, l.uuTien, l.nguoi ? l.nguoi.id : null, l.nguoi ? l.nguoi.vai : null,
      l.ip || null, l.duongDan, l.trangThai, l.chanTai || null,
      l.banGiao ? JSON.stringify(l.banGiao) : null,
      l.soi ? JSON.stringify(l.soi) : null, l.ms, l.at]);
}

/** Tình hình bộ não — để bảng quản trị tổng vẽ ra. */
async function tinhHinh(kho, bayGio, soGio) {
  const gio = soGio || 24;
  const tu = bayGio - gio * 3600000;
  const t = await kho.mot(
    'SELECT COUNT(*) AS tong, ' +
    "  SUM(CASE WHEN trang_thai='xong' THEN 1 ELSE 0 END) AS xong, " +
    "  SUM(CASE WHEN trang_thai='chan-bao-mat' THEN 1 ELSE 0 END) AS chanBm, " +
    "  SUM(CASE WHEN trang_thai='chan-hien-phap' THEN 1 ELSE 0 END) AS chanHp, " +
    "  SUM(CASE WHEN trang_thai='hong' THEN 1 ELSE 0 END) AS hong, " +
    '  AVG(ms) AS msTb, MAX(ms) AS msMax FROM lenh_bo_nao WHERE at > ?', [tu]);
  const theoLoai = await kho.nhieu(
    'SELECT loai, COUNT(*) AS so FROM lenh_bo_nao WHERE at > ? GROUP BY loai ORDER BY so DESC',
    [tu]);
  const chanTheoLop = await kho.nhieu(
    'SELECT lop, COUNT(*) AS so FROM nhat_ky_chan WHERE at > ? GROUP BY lop ORDER BY so DESC',
    [tu]);
  const tong = Number(t.tong);
  return {
    soGio: gio,
    tongLenh: tong,
    xong: Number(t.xong || 0),
    chanBoiBaoMat: Number(t.chanBm || 0),
    chanBoiHienPhap: Number(t.chanHp || 0),
    thanhTraGiuLai: Number(t.hong || 0),
    msTrungBinh: t.msTb === null ? null : Math.round(Number(t.msTb)),
    msLauNhat: t.msMax === null ? null : Number(t.msMax),
    theoLoai: theoLoai.map((x) => ({ loai: x.loai, so: Number(x.so) })),
    chanTheoLop: chanTheoLop.map((x) => ({ lop: x.lop, so: Number(x.so) })),
    coDuLieu: tong > 0,
    ghiChu: tong === 0
      ? 'Chưa có lệnh nào đi qua trong ' + gio + ' giờ vừa rồi.' : '',
  };
}

module.exports = {
  chay, docLenh, coGhi, thanhTra, chonTroLy, tinhHinh, soiHienPhap, viecCua,
  BANG_DOC, CAN_NGUOI_DUYET, VET_LO, UU_TIEN,
};
