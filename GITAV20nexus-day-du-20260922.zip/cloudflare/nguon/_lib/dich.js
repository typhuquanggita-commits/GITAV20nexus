'use strict';
/**
 * Dịch nội dung, có thuật ngữ cố định.
 *
 * Điều quan trọng nhất ở đây không phải là gọi máy dịch — mà là bảng
 * thuật ngữ. Giáo trình mà mỗi bài dịch "đạo hàm" một kiểu thì học
 * viên mất phương hướng. Nên thuật ngữ được ép vào lời nhắc TRƯỚC khi
 * dịch, rồi soát lại SAU khi dịch; chỗ nào máy không theo thì báo ra
 * chứ không lặng lẽ bỏ qua.
 *
 * Bản dịch còn mang băm của bản gốc. Gốc đổi thì băm lệch, bản dịch tự
 * chuyển sang trạng thái "stale" — không ai phải nhớ đi cập nhật tay.
 */

const { maMoi, sha256 } = require('./ma.js');
const congAi = require('./cong-ai.js');
const { KhoNghia } = require('./kho-nghia.js');

const TIENG = {
  vi: 'tiếng Việt', en: 'tiếng Anh', zh: 'tiếng Trung',
  ja: 'tiếng Nhật', ko: 'tiếng Hàn', fr: 'tiếng Pháp',
};

function tiengHopLe(m) {
  return Object.prototype.hasOwnProperty.call(TIENG, String(m || ''));
}

/** Băm của bản gốc — để biết khi nào bản dịch đã lạc hậu. */
async function bamGoc(truong) {
  const k = Object.keys(truong).sort();
  return sha256(k.map((x) => x + '\u0000' + String(truong[x])).join('\u0001'));
}

async function layThuatNgu(kho, tuTieng, sangTieng) {
  return kho.nhieu(
    'SELECT source_term, target_term, context FROM translation_glossary ' +
    'WHERE source_lang = ? AND target_lang = ?', [tuTieng, sangTieng]);
}

/** Chỉ đưa vào lời nhắc những thuật ngữ thật sự xuất hiện trong bản gốc. */
function thuatNguDungDuoc(dsThuatNgu, chuGoc) {
  const thuong = chuGoc.toLowerCase();
  return dsThuatNgu.filter((t) => thuong.includes(String(t.source_term).toLowerCase()));
}

function dungLoiNhac(truong, tuTieng, sangTieng, thuatNgu) {
  const phan = [
    'Dịch các trường sau từ ' + (TIENG[tuTieng] || tuTieng) +
    ' sang ' + (TIENG[sangTieng] || sangTieng) + '.',
    'Giữ nguyên khoá JSON. Chỉ dịch giá trị.',
    'Giữ nguyên mọi công thức toán, mã, số và tên riêng.',
  ];
  if (thuatNgu.length) {
    phan.push('Bắt buộc dùng đúng các thuật ngữ sau, không được dịch khác:');
    for (const t of thuatNgu) {
      phan.push('  · "' + t.source_term + '" → "' + t.target_term + '"' +
        (t.context ? '  (' + t.context + ')' : ''));
    }
  }
  phan.push('Trả về đúng một đối tượng JSON, không kèm lời dẫn.');
  phan.push('');
  phan.push(JSON.stringify(truong, null, 2));
  return phan.join('\n');
}

/** Soát lại: thuật ngữ nào đã hứa mà bản dịch không dùng. */
function soiThuatNgu(banDich, thuatNgu) {
  const chu = JSON.stringify(banDich).toLowerCase();
  return thuatNgu
    .filter((t) => !chu.includes(String(t.target_term).toLowerCase()))
    .map((t) => ({ goc: t.source_term, phaiLa: t.target_term }));
}

/**
 * Dịch một nội dung. Trả về { dat, ban, tuDem, thuatNguLech } hoặc
 * { dat:false, ma, loi } — không bao giờ trả bản dịch giả.
 */
async function dichNoiDung(kho, moi, tham, bayGio) {
  const { loaiNoiDung, maNoiDung, truong, tuTieng, sangTieng } = tham;
  if (!tiengHopLe(tuTieng) || !tiengHopLe(sangTieng)) {
    return { dat: false, ma: 'tieng-khong-ho-tro',
      loi: 'Chỉ hỗ trợ: ' + Object.keys(TIENG).join(', ') + '.' };
  }
  if (tuTieng === sangTieng) {
    return { dat: false, ma: 'cung-mot-tieng', loi: 'Tiếng nguồn và tiếng đích trùng nhau.' };
  }
  if (!truong || typeof truong !== 'object' || Object.keys(truong).length === 0) {
    return { dat: false, ma: 'khong-co-gi-de-dich', loi: 'Không có trường nào để dịch.' };
  }

  const bam = await bamGoc(truong);
  const da = await kho.mot(
    'SELECT * FROM content_translations WHERE content_type = ? AND content_id = ? AND target_lang = ?',
    [loaiNoiDung, maNoiDung, sangTieng]);
  if (da && da.source_hash === bam && da.status !== 'stale') {
    return { dat: true, daCo: true, ban: JSON.parse(da.translated_json),
      trangThai: da.status, id: da.id };
  }

  const tnTatCa = await layThuatNgu(kho, tuTieng, sangTieng);
  const tn = thuatNguDungDuoc(tnTatCa, JSON.stringify(truong));
  const loiNhac = dungLoiNhac(truong, tuTieng, sangTieng, tn);

  const dem = KhoNghia(kho, moi.KV, () => bayGio);
  const khoa = await dem.khoaCua('translate', loiNhac, 'dich', { tuTieng, sangTieng });
  const daDem = await dem.lay('translate', khoa);
  let ban, tuDem = null, mauMay = 'dem';
  if (daDem) {
    ban = daDem.gtri; tuDem = daDem.tang;
  } else {
    let r;
    try {
      r = await congAi.sinh(kho, moi, {
        viec: 'dich', loiNhac, kieuJson: true, nhietDo: 0.1, theToiDa: 4096,
      }, () => bayGio);
    } catch (e) {
      return { dat: false, ma: 'ai-khong-goi-duoc', loi: e.message, duongDaDi: e.duongDaDi };
    }
    try {
      ban = JSON.parse(String(r.chu).replace(/^```(?:json)?\s*|\s*```$/g, '').trim());
    } catch (e) {
      return { dat: false, ma: 'ban-dich-khong-phai-json',
        loi: 'Nhà cung cấp ' + r.nha + ' trả về thứ không phải JSON. Không lưu bản hỏng.' };
    }
    mauMay = r.nha + ':' + r.mauMay;
    await dem.dat('translate', khoa, ban, r.theRa, 30 * 86400000, loiNhac, null);
  }

  const lech = soiThuatNgu(ban, tn);
  const now = bayGio;
  const id = da ? da.id : maMoi();
  const diem = tn.length ? Number(((tn.length - lech.length) / tn.length).toFixed(3)) : null;

  await kho.chay(
    'INSERT INTO content_translations ' +
    '(id, content_type, content_id, source_lang, target_lang, translated_json, source_hash, ' +
    ' status, model, quality_score, created_at, updated_at) ' +
    "VALUES (?, ?, ?, ?, ?, ?, ?, 'machine', ?, ?, ?, ?) " +
    'ON CONFLICT(content_type, content_id, target_lang) DO UPDATE SET ' +
    '  translated_json = excluded.translated_json, source_hash = excluded.source_hash, ' +
    "  status = 'machine', model = excluded.model, quality_score = excluded.quality_score, " +
    '  updated_at = excluded.updated_at',
    [id, loaiNoiDung, maNoiDung, tuTieng, sangTieng, JSON.stringify(ban), bam,
      mauMay, diem, now, now]);

  return {
    dat: true, id, ban, tuDem, mauMay,
    soThuatNguApDung: tn.length,
    thuatNguLech: lech,
    diemChatLuong: diem,
    canNguoiSoat: lech.length > 0,
  };
}

/** Đánh dấu mọi bản dịch của một nội dung là đã lạc hậu khi gốc đổi. */
async function danhDauLacHau(kho, loaiNoiDung, maNoiDung, bamMoi, bayGio) {
  const r = await kho.chay(
    "UPDATE content_translations SET status = 'stale', updated_at = ? " +
    'WHERE content_type = ? AND content_id = ? AND source_hash != ?',
    [bayGio, loaiNoiDung, maNoiDung, bamMoi]);
  return (r && r.meta && r.meta.changes) || 0;
}

module.exports = { TIENG, tiengHopLe, bamGoc, dichNoiDung, danhDauLacHau,
  layThuatNgu, thuatNguDungDuoc, soiThuatNgu, dungLoiNhac };
