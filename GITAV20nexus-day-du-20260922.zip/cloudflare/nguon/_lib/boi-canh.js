'use strict';
/**
 * Bối cảnh của một yêu cầu — mọi tuyến nhận đúng một đối tượng này.
 *
 * Lý do gom vào một chỗ: có 251 đường. Nếu mỗi đường tự đọc thân yêu
 * cầu, tự kiểm phiên, tự chặn hạn mức thì chỉ cần một đường quên là
 * thủng. Ở đây quên thì không chạy được, vì không có đường nào khác để
 * lấy người dùng ra.
 */

const { Kho } = require('./kho.js');
const dap = require('./dap.js');
const phien = require('./phien.js');
const quyen = require('./quyen.js');
const hanMuc = require('./han-muc.js');
const nhatKy = require('./nhat-ky.js');

const THAN_TOI_DA = 256 * 1024;   // 256 KB; đủ cho mọi tuyến, chặn thân khổng lồ

async function docThan(req) {
  const kieu = req.headers.get('content-type') || '';
  if (!kieu.includes('application/json')) return {};
  const chu = await req.text();
  if (chu.length === 0) return {};
  if (chu.length > THAN_TOI_DA) { const e = new Error('than-qua-lon'); e.ma = 'than-qua-lon'; throw e; }
  try { return JSON.parse(chu); } catch (e) {
    const x = new Error('than-khong-phai-json'); x.ma = 'than-khong-phai-json'; throw x;
  }
}

async function dungBoiCanh(req, moi, thamSo, dongHo) {
  const url = new URL(req.url);
  const kho = Kho(moi.DB);
  const the = phien.docThe(req);
  const nguoi = the ? await phien.doiThe(kho, the, dongHo ? dongHo() : undefined) : null;

  const bc = {
    req, moi, url, kho, thamSo: thamSo || {},
    nguoi,                                  // null nếu chưa đăng nhập
    bayGio: dongHo || (() => Date.now()),
    than: null,                             // nạp lười qua layThan()

    async layThan() {
      if (bc.than === null) bc.than = await docThan(req);
      return bc.than;
    },

    /** Bắt buộc đăng nhập. Trả về null nếu đạt, hoặc Response lỗi nếu không. */
    canDangNhap() {
      return bc.nguoi ? null : dap.chuaDangNhap();
    },

    /** Bắt buộc có quyền. Trả về null nếu đạt, hoặc Response lỗi. */
    canQuyen(viec) {
      if (!bc.nguoi) return dap.chuaDangNhap();
      if (quyen.CAM_TUYET_DOI[viec]) {
        return dap.hong(403, 'cam-tuyet-doi', quyen.CAM_TUYET_DOI[viec]);
      }
      if (!quyen.coQuyen(bc.nguoi.vai, viec)) return dap.khongDuQuyen(viec);
      return null;
    },

    /** Của chính mình, hoặc có quyền trên toàn hệ thống. */
    canLaChinhMinh(userId, viecThayThe) {
      if (!bc.nguoi) return dap.chuaDangNhap();
      if (bc.nguoi.id === userId) return null;
      if (viecThayThe && quyen.coQuyen(bc.nguoi.vai, viecThayThe)) return null;
      return dap.hong(403, 'khong-phai-cua-minh',
        'Chỉ xem hoặc sửa được dữ liệu của chính tài khoản đang đăng nhập.');
    },

    /** Xin một lượt trong hạn mức ngày. Trả về Response lỗi nếu hết. */
    async canHanMuc(xo) {
      const khoa = bc.nguoi ? bc.nguoi.id : (req.headers.get('cf-connecting-ip') || 'khach');
      const r = await hanMuc.xin(kho, xo, khoa, bc.bayGio());
      if (!r.cho) {
        return dap.hong(429, 'qua-han-muc',
          'Hết hạn mức ' + r.ten + ' trong ngày (' + r.tran + ' lượt). Ngày mai mở lại.',
          { tran: r.tran, daDung: r.da });
      }
      return null;
    },

    ghiNhatKy(viec, doiTuong, chiTiet) {
      return nhatKy.ghi(kho, {
        nguoi: bc.nguoi ? bc.nguoi.id : null, viec, doiTuong, chiTiet,
      }, bc.bayGio());
    },

    /** Số nguyên trong khoảng, hoặc mặc định. Không bao giờ ném. */
    soTu(ten, macDinh, nhoNhat, lonNhat) {
      const v = parseInt(bc.url.searchParams.get(ten), 10);
      if (!Number.isInteger(v)) return macDinh;
      if (nhoNhat !== undefined && v < nhoNhat) return nhoNhat;
      if (lonNhat !== undefined && v > lonNhat) return lonNhat;
      return v;
    },
  };
  return bc;
}

module.exports = { dungBoiCanh, docThan, THAN_TOI_DA };
