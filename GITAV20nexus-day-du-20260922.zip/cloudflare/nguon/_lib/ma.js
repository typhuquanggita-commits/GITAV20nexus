'use strict';
/**
 * Việc mã hoá — chạy được cả trên workerd lẫn Node, vì chỉ dùng WebCrypto.
 *
 * Mật khẩu băm bằng PBKDF2-SHA256. Không dùng bcrypt/argon2 vì Workers
 * không có, và vì kho mã nguồn này giữ luật không phụ thuộc gói ngoài.
 * Số vòng lặp ghi thẳng vào chuỗi băm để sau này nâng lên được mà không
 * làm hỏng mật khẩu cũ.
 */

const LAP_MAC_DINH = 210000;   // khuyến nghị OWASP 2023 cho PBKDF2-SHA256
const DAI_MUOI = 16;
const DAI_BAM = 32;

const bam_ra_chu = (bd) =>
  Array.from(new Uint8Array(bd)).map((b) => b.toString(16).padStart(2, '0')).join('');

function chu_ra_bam(chu) {
  const n = chu.length / 2;
  const ra = new Uint8Array(n);
  for (let i = 0; i < n; i++) ra[i] = parseInt(chu.substr(i * 2, 2), 16);
  return ra;
}

function maMoi() {
  return crypto.randomUUID();
}

/** Chuỗi ngẫu nhiên an toàn, dùng cho thẻ phiên và mã mời. */
function chuoiNgauNhien(soByte) {
  const b = new Uint8Array(soByte || 32);
  crypto.getRandomValues(b);
  return bam_ra_chu(b.buffer);
}

async function sha256(chu) {
  const bd = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(chu));
  return bam_ra_chu(bd);
}

async function pbkdf2(matKhau, muoi, lap) {
  const khoa = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(matKhau), 'PBKDF2', false, ['deriveBits']);
  const bit = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt: muoi, iterations: lap, hash: 'SHA-256' }, khoa, DAI_BAM * 8);
  return new Uint8Array(bit);
}

/** Trả về chuỗi dạng: lặp$muối$băm — tự mang theo tham số của chính nó. */
async function bamMatKhau(matKhau, lap) {
  const soLap = lap || LAP_MAC_DINH;
  const muoi = new Uint8Array(DAI_MUOI);
  crypto.getRandomValues(muoi);
  const bam = await pbkdf2(matKhau, muoi, soLap);
  return soLap + '$' + bam_ra_chu(muoi.buffer) + '$' + bam_ra_chu(bam.buffer);
}

/** So sánh theo thời gian hằng — không để lộ độ dài khớp qua thời gian chạy. */
function bangNhau(a, b) {
  if (a.length !== b.length) return false;
  let khac = 0;
  for (let i = 0; i < a.length; i++) khac |= a[i] ^ b[i];
  return khac === 0;
}

async function kiemMatKhau(matKhau, luuTru) {
  if (typeof luuTru !== 'string') return false;
  const phan = luuTru.split('$');
  if (phan.length !== 3) return false;
  const lap = parseInt(phan[0], 10);
  if (!Number.isInteger(lap) || lap < 1000 || lap > 5000000) return false;
  let muoi, mong;
  try { muoi = chu_ra_bam(phan[1]); mong = chu_ra_bam(phan[2]); } catch (e) { return false; }
  if (mong.length !== DAI_BAM) return false;
  const thu = await pbkdf2(matKhau, muoi, lap);
  return bangNhau(thu, mong);
}

module.exports = {
  maMoi, chuoiNgauNhien, sha256, bamMatKhau, kiemMatKhau, bangNhau,
  bam_ra_chu, chu_ra_bam, LAP_MAC_DINH,
};
