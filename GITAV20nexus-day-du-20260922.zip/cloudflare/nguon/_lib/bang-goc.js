'use strict';
/**
 * BẢNG GỐC — dữ liệu nền của hệ thống, khai một lần ở đây.
 *
 * Đây là những thứ KHÔNG do người dùng nhập và KHÔNG do máy nghĩ ra:
 * môn học, cấp độ, kỳ thi, trại, hệ thống tài khoản kế toán, hiến pháp.
 * Chúng nằm trong mã nguồn chứ không nằm trong kho dữ liệu, vì chúng
 * phải giống hệt nhau ở mọi bản triển khai và phải soát được bằng mắt.
 *
 * Mỗi con số ở đây đều có nguồn. Chỗ nào tôi không chắc thì ghi rõ là
 * chưa chắc, chứ không điền một con số cho đẹp bảng.
 */

const MON_HOC = [
  { id: 'toan', ten: 'Toán', ten_en: 'Mathematics', thu_tu: 1,
    mo_ta: 'Số học, đại số, hình học, giải tích, xác suất thống kê — theo Chương trình giáo dục phổ thông 2018.' },
  { id: 'tieng-anh', ten: 'Tiếng Anh', ten_en: 'English', thu_tu: 2,
    mo_ta: 'Nghe, nói, đọc, viết theo Khung năng lực ngoại ngữ 6 bậc dùng cho Việt Nam, đối chiếu CEFR.' },
  { id: 'ngu-van', ten: 'Ngữ văn', ten_en: 'Vietnamese Language and Literature', thu_tu: 3,
    mo_ta: 'Đọc hiểu, viết, nói và nghe — theo Chương trình giáo dục phổ thông 2018.' },
];

/**
 * Bảy cấp độ. Điều kiện vào là điều kiện KHẮT KHE và đo được — không
 * có cấp nào vào được chỉ bằng cách đăng ký.
 */
const CAP_DO = [
  { id: 'co-ban', ten: 'Cơ bản', thu_tu: 1,
    dich_den: 'Làm chủ chương trình chính khoá, bài kiểm tra trên lớp đạt 9–10.',
    dieu_kien_vao: 'Không có. Đây là cấp vào của mọi người học.' },
  { id: 'nang-cao', ten: 'Nâng cao', thu_tu: 2,
    dich_den: 'Giải được dạng vượt trên yêu cầu sách giáo khoa của cùng lớp.',
    dieu_kien_vao: 'Đạt từ 90% bài cấp Cơ bản cùng lớp, trên ít nhất 60 bài đã làm.' },
  { id: 'clc', ten: 'Chất lượng cao', thu_tu: 3,
    dich_den: 'Đủ sức thi vào lớp chất lượng cao của trường.',
    dieu_kien_vao: 'Đạt từ 85% bài cấp Nâng cao, và một bài kiểm tra chốt cấp từ 8,0.' },
  { id: 'hsg', ten: 'Học sinh giỏi', thu_tu: 4,
    dich_den: 'Dự thi học sinh giỏi cấp trường, huyện, tỉnh.',
    dieu_kien_vao: 'Đạt từ 85% bài cấp Chất lượng cao, và giữ mức ấy liên tục 4 tuần.' },
  { id: 'chuyen', ten: 'Chuyên', thu_tu: 5,
    dich_den: 'Đủ sức thi vào trường trung học phổ thông chuyên.',
    dieu_kien_vao: 'Đạt từ 80% bài cấp Học sinh giỏi, và hai đề thi thử chuyên từ 7,5.' },
  { id: 'dai-hoc', ten: 'Đại học', thu_tu: 6,
    dich_den: 'Thi tốt nghiệp và xét tuyển đại học, gồm cả các kỳ đánh giá năng lực.',
    dieu_kien_vao: 'Học lớp 10 trở lên, và đạt từ 80% bài cấp Chuyên hoặc Học sinh giỏi cùng môn.' },
  { id: 'quoc-te', ten: 'Quốc tế', thu_tu: 7,
    dich_den: 'Dự thi các kỳ thi và giải quốc tế.',
    dieu_kien_vao: 'Có giải cấp tỉnh trở lên, hoặc đạt từ 90% bài cấp Chuyên trên ít nhất 200 bài.' },
];

/**
 * Sáu hệ chuẩn. Điểm tối đa và cơ quan tổ chức là dữ kiện có thật;
 * CẤU TRÚC chi tiết (số câu, số phút, trọng số) nằm ở src/matran/chuan.js
 * và chỉ có một bản duy nhất ở đó.
 */
const KY_THI = [
  { id: 'hsa', ten: 'Đánh giá năng lực Đại học Quốc gia Hà Nội', ngan: 'HSA 1300',
    diem_toi_da: 1300, don_vi_diem: 'điểm', co_quan: 'Đại học Quốc gia Hà Nội',
    ghi_chu: 'Phần tự chọn làm tổng số câu và số phút thay đổi theo thí sinh.' },
  { id: 'tsa', ten: 'Đánh giá tư duy Đại học Bách khoa Hà Nội', ngan: 'TSA 100',
    diem_toi_da: 100, don_vi_diem: 'điểm', co_quan: 'Đại học Bách khoa Hà Nội', ghi_chu: null },
  { id: 'spt', ten: 'Đánh giá năng lực chuyên biệt Đại học Sư phạm', ngan: 'SPT 1200',
    diem_toi_da: 1200, don_vi_diem: 'điểm', co_quan: 'Trường Đại học Sư phạm', ghi_chu: null },
  { id: 'ielts', ten: 'IELTS Academic', ngan: 'IELTS 9.0',
    diem_toi_da: 9, don_vi_diem: 'band', co_quan: 'British Council · IDP · Cambridge',
    ghi_chu: 'Điểm theo nửa band, bốn kỹ năng rồi lấy trung bình làm tròn theo quy tắc riêng.' },
  { id: 'sat', ten: 'Digital SAT', ngan: 'SAT 1600',
    diem_toi_da: 1600, don_vi_diem: 'điểm', co_quan: 'College Board',
    ghi_chu: 'Bản số hoá, thích ứng theo mô-đun.' },
  { id: 'toeic', ten: 'TOEIC Listening and Reading', ngan: 'TOEIC 990',
    diem_toi_da: 990, don_vi_diem: 'điểm', co_quan: 'ETS',
    ghi_chu: 'Nghe và Đọc, mỗi phần 5–495. Bản Nói và Viết tính thang riêng, chưa đưa vào đây.' },
];

/** Ba trại. Ngưỡng vào và ngưỡng ra đều đo được. */
const TRAI = [
  {
    id: 'gel-alpha', ten: 'Trại Gel Alpha',
    muc_tieu: 'Dựng nền nếp học và sức bền tinh thần: ngồi vào bàn đúng giờ, ' +
      'làm hết việc đã nhận, và chịu được một bài khó mà không bỏ giữa chừng.',
    lop_tu: 4, lop_den: 12, so_ngay: 21, so_gio: 63,
    nguong_vao: [
      { ma: 'co-ho-so', mo_ta: 'Đã có hồ sơ học viên và đã làm test đầu vào ít nhất một môn.' },
      { ma: 'cam-ket-gio', mo_ta: 'Gia đình xác nhận thu xếp được 3 giờ mỗi tuần trong 3 tuần.' },
    ],
    nguong_ra: [
      { ma: 'du-buoi', mo_ta: 'Có mặt từ 18 trên 21 buổi.', do_bang: 'so-buoi', nguong: 18 },
      { ma: 'chuoi-lien-tuc', mo_ta: 'Giữ chuỗi học liên tục ít nhất 14 ngày.', do_bang: 'thoi-gian-giu', nguong: 14 },
      { ma: 'bai-kho', mo_ta: 'Hoàn thành 10 bài mức khó 7 trở lên mà không bỏ dở.', do_bang: 'so-bai', nguong: 10 },
    ],
  },
  {
    id: 'leader-boom', ten: 'Trại Leader Boom',
    muc_tieu: 'Dẫn dắt nhóm, nói trước đám đông, và chịu trách nhiệm về kết quả ' +
      'của một việc có người khác cùng làm.',
    lop_tu: 6, lop_den: 12, so_ngay: 14, so_gio: 56,
    nguong_vao: [
      { ma: 'da-qua-gel', mo_ta: 'Đã hoàn thành trại Gel Alpha, hoặc có chuỗi học liên tục 30 ngày.' },
      { ma: 'lop-6', mo_ta: 'Từ lớp 6 trở lên.' },
    ],
    nguong_ra: [
      { ma: 'du-buoi', mo_ta: 'Có mặt từ 12 trên 14 buổi.', do_bang: 'so-buoi', nguong: 12 },
      { ma: 'dan-nhom', mo_ta: 'Dẫn ít nhất 2 buổi làm việc nhóm, được nhóm chấm từ 7/10.', do_bang: 'diem-kiem-tra', nguong: 7 },
      { ma: 'trinh-bay', mo_ta: 'Một bài trình bày 10 phút trước trại, ban giám khảo chấm từ 7/10.', do_bang: 'diem-kiem-tra', nguong: 7 },
    ],
  },
  {
    id: 'hoc-gioi', ten: 'Kỹ năng học giỏi',
    muc_tieu: 'Phương pháp học: ghi chép, ôn ngắt quãng, tự kiểm tra, đọc hiểu nhanh, ' +
      'và cách sửa lỗi sai lặp lại. Nội dung chia theo cấp lớp.',
    lop_tu: 1, lop_den: 12, so_ngay: 10, so_gio: 20,
    nguong_vao: [
      { ma: 'khong', mo_ta: 'Không có. Mọi học viên đều vào được.' },
    ],
    nguong_ra: [
      { ma: 'du-buoi', mo_ta: 'Có mặt từ 8 trên 10 buổi.', do_bang: 'so-buoi', nguong: 8 },
      { ma: 'so-loi-sai', mo_ta: 'Lập và dùng sổ lỗi sai ít nhất 20 lần.', do_bang: 'so-bai', nguong: 20 },
      { ma: 'tu-kiem', mo_ta: 'Tự kiểm tra đúng nhịp ôn ngắt quãng trong 4 tuần.', do_bang: 'thoi-gian-giu', nguong: 28 },
    ],
  },
];

/**
 * Hệ thống tài khoản kế toán Việt Nam.
 *
 * Số hiệu và tên lấy theo Thông tư 200/2014/TT-BTC; những tài khoản còn
 * dùng nguyên ở Thông tư 133/2016/TT-BTC thì đánh 'ca-hai'. Đây là danh
 * mục CẤP MỘT; tài khoản cấp hai do người dùng mở thêm khi cần.
 */
const TAI_KHOAN = [
  ['111', 'Tiền mặt', 'tai-san', 'no', 'ca-hai'],
  ['112', 'Tiền gửi ngân hàng', 'tai-san', 'no', 'ca-hai'],
  ['113', 'Tiền đang chuyển', 'tai-san', 'no', 'tt200'],
  ['121', 'Chứng khoán kinh doanh', 'tai-san', 'no', 'tt200'],
  ['128', 'Đầu tư nắm giữ đến ngày đáo hạn', 'tai-san', 'no', 'tt200'],
  ['131', 'Phải thu của khách hàng', 'tai-san', 'no', 'ca-hai'],
  ['133', 'Thuế giá trị gia tăng được khấu trừ', 'tai-san', 'no', 'ca-hai'],
  ['138', 'Phải thu khác', 'tai-san', 'no', 'ca-hai'],
  ['141', 'Tạm ứng', 'tai-san', 'no', 'ca-hai'],
  ['152', 'Nguyên liệu, vật liệu', 'tai-san', 'no', 'ca-hai'],
  ['153', 'Công cụ, dụng cụ', 'tai-san', 'no', 'ca-hai'],
  ['154', 'Chi phí sản xuất, kinh doanh dở dang', 'tai-san', 'no', 'ca-hai'],
  ['156', 'Hàng hoá', 'tai-san', 'no', 'ca-hai'],
  ['211', 'Tài sản cố định hữu hình', 'tai-san', 'no', 'ca-hai'],
  ['213', 'Tài sản cố định vô hình', 'tai-san', 'no', 'tt200'],
  ['214', 'Hao mòn tài sản cố định', 'tai-san', 'co', 'ca-hai'],
  ['242', 'Chi phí trả trước', 'tai-san', 'no', 'ca-hai'],
  ['331', 'Phải trả cho người bán', 'no-phai-tra', 'co', 'ca-hai'],
  ['333', 'Thuế và các khoản phải nộp Nhà nước', 'no-phai-tra', 'co', 'ca-hai'],
  ['334', 'Phải trả người lao động', 'no-phai-tra', 'co', 'ca-hai'],
  ['338', 'Phải trả, phải nộp khác', 'no-phai-tra', 'co', 'ca-hai'],
  ['341', 'Vay và nợ thuê tài chính', 'no-phai-tra', 'co', 'ca-hai'],
  ['352', 'Dự phòng phải trả', 'no-phai-tra', 'co', 'tt200'],
  ['353', 'Quỹ khen thưởng, phúc lợi', 'no-phai-tra', 'co', 'tt200'],
  ['411', 'Vốn đầu tư của chủ sở hữu', 'von-chu-so-huu', 'co', 'ca-hai'],
  ['418', 'Các quỹ thuộc vốn chủ sở hữu', 'von-chu-so-huu', 'co', 'tt200'],
  ['421', 'Lợi nhuận sau thuế chưa phân phối', 'von-chu-so-huu', 'co', 'ca-hai'],
  ['511', 'Doanh thu bán hàng và cung cấp dịch vụ', 'doanh-thu', 'co', 'ca-hai'],
  ['515', 'Doanh thu hoạt động tài chính', 'doanh-thu', 'co', 'ca-hai'],
  ['521', 'Các khoản giảm trừ doanh thu', 'doanh-thu', 'no', 'tt200'],
  ['632', 'Giá vốn hàng bán', 'chi-phi', 'no', 'ca-hai'],
  ['635', 'Chi phí tài chính', 'chi-phi', 'no', 'ca-hai'],
  ['641', 'Chi phí bán hàng', 'chi-phi', 'no', 'tt200'],
  ['642', 'Chi phí quản lý kinh doanh', 'chi-phi', 'no', 'ca-hai'],
  ['711', 'Thu nhập khác', 'doanh-thu', 'co', 'ca-hai'],
  ['811', 'Chi phí khác', 'chi-phi', 'no', 'ca-hai'],
  ['821', 'Chi phí thuế thu nhập doanh nghiệp', 'chi-phi', 'no', 'ca-hai'],
  ['911', 'Xác định kết quả kinh doanh', 'khac', 'khong', 'ca-hai'],
].map(([so, ten, loai, du, tt]) => ({
  so, ten, cap: 1, cha_so: null, loai, du_thuong: du, thong_tu: tt, hoat_dong: 1,
}));

module.exports = { MON_HOC, CAP_DO, KY_THI, TRAI, TAI_KHOAN };
