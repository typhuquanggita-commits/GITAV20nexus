'use strict';
/**
 * Thống kê dùng chung — viết tay, không gói ngoài, và tất định.
 *
 * Mỗi hàm ở đây đều trả về cả CỠ MẪU bên cạnh con số. Một hệ số tương
 * quan 0,9 trên bốn điểm dữ liệu không nói lên điều gì, mà nhìn vào
 * con số thì không phân biệt được với 0,9 trên bốn nghìn điểm. Nên cỡ
 * mẫu đi kèm, luôn luôn.
 */

/** Hạng của từng phần tử, chia đều hạng cho các giá trị bằng nhau. */
function hang(ds) {
  const n = ds.length;
  const chiSo = ds.map((v, i) => [v, i]).sort((a, b) => a[0] - b[0]);
  const h = new Array(n);
  let i = 0;
  while (i < n) {
    let j = i;
    while (j + 1 < n && chiSo[j + 1][0] === chiSo[i][0]) j++;
    const tb = (i + j) / 2 + 1;
    for (let k = i; k <= j; k++) h[chiSo[k][1]] = tb;
    i = j + 1;
  }
  return h;
}

function trungBinh(ds) {
  return ds.length ? ds.reduce((a, b) => a + b, 0) / ds.length : 0;
}

function doLech(ds) {
  const n = ds.length;
  if (n < 2) return 0;
  const tb = trungBinh(ds);
  return Math.sqrt(ds.reduce((s, x) => s + (x - tb) * (x - tb), 0) / (n - 1));
}

/** Tương quan Pearson. Trả về null khi một bên không đổi — không phải 0. */
function pearson(x, y) {
  const n = Math.min(x.length, y.length);
  if (n < 3) return null;
  const tbx = trungBinh(x.slice(0, n));
  const tby = trungBinh(y.slice(0, n));
  let tu = 0, mx = 0, my = 0;
  for (let i = 0; i < n; i++) {
    const a = x[i] - tbx, b = y[i] - tby;
    tu += a * b; mx += a * a; my += b * b;
  }
  if (mx === 0 || my === 0) return null;   // một bên phẳng: không có tương quan để nói
  return tu / Math.sqrt(mx * my);
}

/**
 * Tương quan hạng Spearman.
 *
 * Dùng hạng thay vì giá trị thô vì quan hệ giữa một chỉ báo học tập và
 * kết quả sau đó hiếm khi là đường thẳng — nhưng thứ tự thì có nghĩa.
 */
function spearman(x, y) {
  const n = Math.min(x.length, y.length);
  if (n < 3) return null;
  return pearson(hang(x.slice(0, n)), hang(y.slice(0, n)));
}

/**
 * Khoảng tin cậy 95% của hệ số tương quan, qua phép biến đổi Fisher.
 *
 * Có khoảng này thì mới nói được "0,31 nhưng khoảng từ -0,05 đến 0,60"
 * — nghĩa là chưa chắc khác không. Thiếu nó thì mọi con số đều trông
 * như đã chắc chắn.
 */
function khoangTinCay(r, n) {
  if (r === null || n < 4 || Math.abs(r) >= 1) return null;
  const z = 0.5 * Math.log((1 + r) / (1 - r));
  const se = 1 / Math.sqrt(n - 3);
  const lo = z - 1.96 * se, hi = z + 1.96 * se;
  const doi = (t) => (Math.exp(2 * t) - 1) / (Math.exp(2 * t) + 1);
  return { tu: Number(doi(lo).toFixed(4)), den: Number(doi(hi).toFixed(4)) };
}

/** Khoảng có chứa số 0 không — nếu có thì chưa nói được gì. */
function khacKhong(kt) {
  return kt ? (kt.tu > 0 || kt.den < 0) : false;
}

/**
 * Khử ảnh hưởng của nhóm: trong mỗi nhóm, trừ đi trung bình rồi chia
 * độ lệch của chính nhóm ấy.
 *
 * Vì sao cần: nếu không khử, một chỉ báo có thể chỉ đang đo "em học
 * lớp mấy" chứ không đo điều ta tưởng. Học sinh lớp 12 làm đúng nhiều
 * hơn lớp 3 là chuyện đương nhiên, và một chỉ báo bắt được chuyện đương
 * nhiên ấy trông rất mạnh mà vô dụng.
 */
function khuNhom(giaTri, nhom) {
  const theo = new Map();
  for (let i = 0; i < giaTri.length; i++) {
    const k = String(nhom[i]);
    if (!theo.has(k)) theo.set(k, []);
    theo.get(k).push(giaTri[i]);
  }
  const tb = new Map(), lech = new Map();
  for (const [k, ds] of theo) { tb.set(k, trungBinh(ds)); lech.set(k, doLech(ds)); }
  return giaTri.map((v, i) => {
    const k = String(nhom[i]);
    const s = lech.get(k);
    return s > 1e-9 ? (v - tb.get(k)) / s : 0;
  });
}

/** Phân vị theo kiểu nội suy tuyến tính. */
function phanVi(ds, p) {
  if (!ds.length) return null;
  const s = [...ds].sort((a, b) => a - b);
  const i = (s.length - 1) * p;
  const lo = Math.floor(i), hi = Math.ceil(i);
  return lo === hi ? s[lo] : s[lo] + (s[hi] - s[lo]) * (i - lo);
}

module.exports = {
  hang, trungBinh, doLech, pearson, spearman, khoangTinCay, khacKhong, khuNhom, phanVi,
};
