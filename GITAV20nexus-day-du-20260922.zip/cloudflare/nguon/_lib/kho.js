'use strict';
/**
 * Lớp mỏng trên D1.
 *
 * D1 và node:sqlite có cùng hình dạng prepare/bind, nên bộ thử chạy
 * được y hệt bản thật mà không cần giả lập lỏng lẻo. Lớp này chỉ thêm
 * ba thứ D1 không cho sẵn: câu lỗi tiếng Việt khi chưa gắn kho, phân
 * trang có chặn trên, và chèn theo đối tượng.
 */

const { hong } = require('./dap.js');

const TRANG_MAC_DINH = 20;
const TRANG_TOI_DA = 100;

function Kho(d1) {
  if (!d1) throw new Error('chua-gan-kho');

  async function mot(sql, tham) {
    return d1.prepare(sql).bind(...(tham || [])).first();
  }
  async function nhieu(sql, tham) {
    const r = await d1.prepare(sql).bind(...(tham || [])).all();
    return r.results || [];
  }
  async function chay(sql, tham) {
    return d1.prepare(sql).bind(...(tham || [])).run();
  }
  async function dem(sql, tham) {
    const r = await mot(sql, tham);
    if (!r) return 0;
    const k = Object.keys(r)[0];
    return Number(r[k]) || 0;
  }

  /** Chèn một hàng từ đối tượng; bỏ qua khoá có giá trị undefined. */
  async function chen(bang, hang) {
    const cot = Object.keys(hang).filter((k) => hang[k] !== undefined);
    if (cot.length === 0) throw new Error('chen-rong');
    const sql = 'INSERT INTO ' + bang + ' (' + cot.join(', ') + ') VALUES (' +
      cot.map(() => '?').join(', ') + ')';
    return chay(sql, cot.map((k) => hang[k]));
  }

  /** Cập nhật theo khoá chính id; trả về số hàng đổi. */
  async function sua(bang, id, hang) {
    const cot = Object.keys(hang).filter((k) => hang[k] !== undefined);
    if (cot.length === 0) return 0;
    const sql = 'UPDATE ' + bang + ' SET ' + cot.map((k) => k + ' = ?').join(', ') +
      ' WHERE id = ?';
    const r = await chay(sql, cot.map((k) => hang[k]).concat([id]));
    return (r && r.meta && r.meta.changes) || (r && r.changes) || 0;
  }

  async function xoa(bang, id) {
    const r = await chay('DELETE FROM ' + bang + ' WHERE id = ?', [id]);
    return (r && r.meta && r.meta.changes) || (r && r.changes) || 0;
  }

  return { d1, mot, nhieu, chay, dem, chen, sua, xoa };
}

/** Đọc tham số phân trang, luôn kẹp trong khoảng an toàn. */
function phanTrang(url) {
  const t = parseInt(url.searchParams.get('soDong') || url.searchParams.get('limit'), 10);
  const b = parseInt(url.searchParams.get('boQua') || url.searchParams.get('offset'), 10);
  const soDong = Number.isInteger(t) && t > 0 ? Math.min(t, TRANG_TOI_DA) : TRANG_MAC_DINH;
  const boQua = Number.isInteger(b) && b >= 0 ? b : 0;
  return { soDong, boQua };
}

/** Câu trả lời khi Pages chưa được gắn kho D1 — nói thẳng cách sửa. */
function chuaGanKho() {
  return hong(503, 'chua-gan-kho',
    'Dự án Pages chưa được gắn kho dữ liệu D1. Vào Cloudflare → Pages → dự án → ' +
    'Settings → Functions → D1 database bindings, thêm một gắn kết tên DB rồi triển khai lại.');
}

module.exports = { Kho, phanTrang, chuaGanKho, TRANG_MAC_DINH, TRANG_TOI_DA };
