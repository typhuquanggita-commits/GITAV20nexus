'use strict';
/**
 * Khuôn trả lời chung cho mọi tuyến.
 *
 * Một chỗ duy nhất quyết định hình dạng câu trả lời, nên không có tuyến
 * nào tự bịa ra kiểu riêng. Lỗi luôn mang mã máy đọc được ở `ma` và câu
 * tiếng Việt ở `loi` — người đọc hiểu, máy cũng phân nhánh được.
 */

const TIEU_DE_CHUNG = {
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store',
  'X-Content-Type-Options': 'nosniff',
};

function json(du_lieu, ma_trang_thai, them) {
  return new Response(JSON.stringify(du_lieu, null, 2), {
    status: ma_trang_thai || 200,
    headers: Object.assign({}, TIEU_DE_CHUNG, them || {}),
  });
}

function dat(du_lieu) {
  return json(Object.assign({ dat: true }, du_lieu));
}

/** Lỗi có chủ đích: mã ngắn để máy phân nhánh, câu tiếng Việt để người đọc. */
function hong(ma_trang_thai, ma, loi, them) {
  return json(Object.assign({ dat: false, ma: ma, loi: loi }, them || {}), ma_trang_thai);
}

const thieu = (truong) => hong(400, 'thieu-truong', 'Thiếu trường bắt buộc: ' + truong);
const saiKieu = (truong, mong) => hong(400, 'sai-kieu', 'Trường ' + truong + ' phải là ' + mong);
const chuaDangNhap = () => hong(401, 'chua-dang-nhap', 'Cần đăng nhập mới dùng được đường này.');
const khongDuQuyen = (can) =>
  hong(403, 'khong-du-quyen', 'Tài khoản không có quyền ' + can + '.');
const khongThay = (gi) => hong(404, 'khong-thay', 'Không tìm thấy ' + gi + '.');
const trung = (gi) => hong(409, 'trung', gi + ' đã tồn tại.');
const quaHanMuc = (con) =>
  hong(429, 'qua-han-muc', 'Vượt hạn mức gọi trong ngày.', { conLai: con });

module.exports = {
  json, dat, hong, thieu, saiKieu, chuaDangNhap, khongDuQuyen, khongThay, trung, quaHanMuc,
  TIEU_DE_CHUNG,
};
