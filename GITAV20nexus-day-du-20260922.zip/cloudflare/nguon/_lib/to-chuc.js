'use strict';
/**
 * BỘ MÁY — 600 trợ lý chuyên môn và 50 trợ lý quan hệ gia đình.
 *
 * Danh sách sinh TẤT ĐỊNH từ bảng phân công dưới đây: cùng một bảng
 * luôn cho ra cùng một danh sách, cùng mã, cùng thứ tự. Không có
 * Math.random() ở đây — một bộ máy mà mỗi lần khởi động lại đổi người
 * thì không ai giao việc cho nó được.
 *
 * Bảy vai, và mỗi vai có lý do tồn tại riêng:
 *   truong-ban  — chia việc trong ban, chịu trách nhiệm đầu ra của ban
 *   hoach-dinh  — cắt việc lớn thành việc nhỏ có thể giao
 *   thuc-thi    — làm phần lớn khối lượng
 *   tham-dinh   — soát lại việc của người khác, KHÔNG soát việc mình
 *   huan-luyen  — sửa lời dặn cho trợ lý có KPI kém
 *   tra-cuu     — tìm nguồn, đối chiếu chuẩn
 *   canh-gac    — chặn việc vượt quyền, việc phạm hiến pháp
 */

const BAN = [
  { id: 'toan', ten: 'Ban Toán', so: 120,
    nhiem_vu: 'Soạn chuyên đề, bài tập và lời giải môn Toán lớp 1–12, cả bảy cấp độ.' },
  { id: 'tieng-anh', ten: 'Ban Tiếng Anh', so: 100,
    nhiem_vu: 'Soạn nội dung bốn kỹ năng, và phần tiếng Anh của IELTS, SAT, TOEIC, HSA.' },
  { id: 'ngu-van', ten: 'Ban Ngữ văn', so: 80,
    nhiem_vu: 'Soạn đọc hiểu, viết, nói và nghe; phần ngôn ngữ và văn học của HSA.' },
  { id: 'khao-thi', ten: 'Ban Khảo thí', so: 70,
    nhiem_vu: 'Dựng đề theo cấu trúc sáu hệ chuẩn, chấm, quy đổi điểm, phân tích độ khó thật.' },
  { id: 'lo-trinh', ten: 'Ban Lộ trình và Giám sát', so: 60,
    nhiem_vu: 'Xếp lộ trình cá nhân, xét điều kiện vượt cấp, phát cảnh báo học tập.' },
  { id: 'noi-dung', ten: 'Ban Nội dung và Video', so: 60,
    nhiem_vu: 'Viết kịch bản chuỗi bài giải, dựng thứ tự sư phạm, soát ký hiệu toán.' },
  { id: 'tam-ly', ten: 'Ban Khảo sát và Tâm lý', so: 40,
    nhiem_vu: 'Vận hành phiếu DISC, MBTI, kỹ năng, tâm lý học đường; đọc kết quả đúng giới hạn của phiếu.' },
  { id: 'trai', ten: 'Ban Trại huấn luyện', so: 30,
    nhiem_vu: 'Vận hành Gel Alpha, Leader Boom, Kỹ năng học giỏi; xét ngưỡng vào và ngưỡng ra.' },
  { id: 'chat-luong', ten: 'Ban Chất lượng và Thanh tra', so: 25,
    nhiem_vu: 'Soát ngẫu nhiên đầu ra của mọi ban, đo KPI, soi vi phạm hiến pháp.' },
  { id: 'ky-thuat', ten: 'Ban Kỹ thuật và Dữ liệu', so: 15,
    nhiem_vu: 'Di trú kho dữ liệu, dọn dẹp theo lịch, theo dõi hạn mức sáu nhà cung cấp AI.' },
];

/** Tỷ lệ vai trong một ban. Cộng lại phải đúng số người của ban. */
const TI_LE_VAI = [
  { vai: 'truong-ban', phan: 1, coDinh: true },     // luôn đúng một người
  { vai: 'hoach-dinh', phan: 0.08 },
  { vai: 'tham-dinh', phan: 0.15 },
  { vai: 'tra-cuu', phan: 0.10 },
  { vai: 'huan-luyen', phan: 0.05 },
  { vai: 'canh-gac', phan: 0.04 },
  { vai: 'thuc-thi', phan: null },                  // phần còn lại
];

function chiaVai(soNguoi) {
  const ra = [];
  let daChia = 0;
  for (const t of TI_LE_VAI) {
    if (t.coDinh) { ra.push({ vai: t.vai, so: 1 }); daChia += 1; continue; }
    if (t.phan === null) continue;
    const so = Math.max(1, Math.round((soNguoi - 1) * t.phan));
    ra.push({ vai: t.vai, so });
    daChia += so;
  }
  const conLai = soNguoi - daChia;
  if (conLai < 1) {
    throw new Error('Ban ' + soNguoi + ' người: chia vai xong không còn ai thực thi.');
  }
  ra.push({ vai: 'thuc-thi', so: conLai });
  return ra;
}

const TEN_VAI = {
  'truong-ban': 'Trưởng ban', 'hoach-dinh': 'Hoạch định', 'thuc-thi': 'Thực thi',
  'tham-dinh': 'Thẩm định', 'huan-luyen': 'Huấn luyện', 'tra-cuu': 'Tra cứu',
  'canh-gac': 'Canh gác',
};

/** Phạm vi dữ liệu theo vai — hẹp là mặc định, rộng phải có lý do. */
const PHAM_VI_VAI = {
  'truong-ban': 'pham-vi', 'hoach-dinh': 'pham-vi', 'thuc-thi': 'minh',
  'tham-dinh': 'pham-vi', 'huan-luyen': 'pham-vi', 'tra-cuu': 'chung',
  'canh-gac': 'chung',
};

function danhSachTroLy() {
  const ra = [];
  let so = 0;
  for (const b of BAN) {
    for (const nhom of chiaVai(b.so)) {
      for (let i = 0; i < nhom.so; i++) {
        so += 1;
        ra.push({
          id: 'tl-' + String(so).padStart(4, '0'),
          ban_id: b.id,
          ten: TEN_VAI[nhom.vai] + ' ' + b.ten.replace(/^Ban /, '') + ' ' + (i + 1),
          vai: nhom.vai,
          chuyen_mon: b.id,
          pham_vi: PHAM_VI_VAI[nhom.vai],
          suc_chua_ngay: nhom.vai === 'thuc-thi' ? 24 : nhom.vai === 'tham-dinh' ? 16 : 12,
        });
      }
    }
  }
  return ra;
}

/** Năm mươi trợ lý quan hệ gia đình, chia năm tổ. */
const TO_CRM = [
  { id: 'tiep-nhan', ten: 'Tổ Tiếp nhận', so: 10, vai: 'tiep-nhan',
    viec: 'Nhận đầu mối mới, xác minh thông tin, xếp lịch tư vấn.' },
  { id: 'tu-van', ten: 'Tổ Tư vấn', so: 12, vai: 'tu-van',
    viec: 'Đọc kết quả test đầu vào, giải thích lộ trình, trả lời gia đình.' },
  { id: 'cham-soc', ten: 'Tổ Chăm sóc', so: 15, vai: 'cham-soc',
    viec: 'Theo sát người học đang học, báo tiến bộ, xử lý phàn nàn.' },
  { id: 'thu-hoi', ten: 'Tổ Công nợ', so: 6, vai: 'thu-hoi',
    viec: 'Nhắc học phí đến hạn, lập đề nghị miễn giảm để người duyệt.' },
  { id: 'phan-tich', ten: 'Tổ Phân tích', so: 7, vai: 'phan-tich',
    viec: 'Đo hiệu quả từng kênh, tìm chỗ gia đình rời đi, đề xuất sửa.' },
];

function danhSachCrm() {
  const ra = [];
  let so = 0;
  for (const t of TO_CRM) {
    for (let i = 0; i < t.so; i++) {
      so += 1;
      const laToTruong = i === 0;
      ra.push({
        id: 'crm-' + String(so).padStart(2, '0'),
        to_id: t.id,
        ten: (laToTruong ? 'Tổ trưởng ' : '') + t.ten.replace(/^Tổ /, '') + ' ' + (i + 1),
        vai: laToTruong ? 'to-truong' : t.vai,
        // Mức tự chủ: 0 không tự quyết gì, 3 tự quyết trong hạn mức.
        // Tổ Công nợ cố ý để mức 0 — nhắc tiền là việc dễ làm tổn thương nhất.
        muc_tu_chu: t.id === 'thu-hoi' ? 0 : (laToTruong ? 3 : 2),
        suc_chua_ngay: t.id === 'cham-soc' ? 40 : 30,
      });
    }
  }
  return ra;
}

/** Bảng nhiệm vụ: việc nào thuộc ban nào, đầu vào đầu ra là gì. */
const NHIEM_VU = [
  { ma: 'soan-chuyen-de', ten: 'Soạn một chuyên đề', ban: 'toan', vai: 'thuc-thi',
    dau_vao: ['o_id', 'ma_chuyen_de', 'chuan_ids'],
    dau_ra: ['chuyen_de', 'bai_giang'],
    tieu_chuan: 'Phủ hết chuẩn kiến thức đã nhận, có ít nhất 3 bài giảng, ký hiệu toán đạt bộ soi.',
    phut: 90, can_nguoi_duyet: 1, cam: ['xuat-ban-khong-qua-tham-dinh'] },
  { ma: 'soan-bai-tap', ten: 'Soạn một bài tập kèm lời giải', ban: 'toan', vai: 'thuc-thi',
    dau_vao: ['chuyen_de_id', 'do_kho', 'dang'],
    dau_ra: ['bai_tap'],
    tieu_chuan: 'Có nguồn, có lời giải từng bước, băm nội dung không trùng bài đã có.',
    phut: 20, can_nguoi_duyet: 0, cam: ['bia-nguon'] },
  { ma: 'tham-dinh-bai', ten: 'Thẩm định một bài tập', ban: 'chat-luong', vai: 'tham-dinh',
    dau_vao: ['bai_id'],
    dau_ra: ['ket_luan', 'diem_chat_luong'],
    tieu_chuan: 'Kiểm đáp án, kiểm ký hiệu, kiểm nguồn, kiểm độ khó khai có khớp thực tế.',
    phut: 15, can_nguoi_duyet: 0, cam: ['tham-dinh-bai-cua-chinh-minh'] },
  { ma: 'dung-de', ten: 'Dựng một đề thi', ban: 'khao-thi', vai: 'thuc-thi',
    dau_vao: ['ky_thi_id', 'loai'],
    dau_ra: ['de_thi'],
    tieu_chuan: 'Khớp đúng cấu trúc hệ chuẩn, không lặp bài trong cùng đề, phủ đủ các phần.',
    phut: 60, can_nguoi_duyet: 1, cam: ['sua-cau-truc-he-chuan'] },
  { ma: 'xet-vuot-cap', ten: 'Xét một lần vượt cấp', ban: 'lo-trinh', vai: 'tham-dinh',
    dau_vao: ['user_id', 'o_id'],
    dau_ra: ['xet_vuot_cap'],
    tieu_chuan: 'Đủ mẫu mới kết luận; thiếu mẫu thì trả về thiếu-mẫu chứ không đoán.',
    phut: 5, can_nguoi_duyet: 0, cam: ['mo-cap-khi-chua-du-bang-chung'] },
  { ma: 'viet-kich-ban-video', ten: 'Viết kịch bản một tập video', ban: 'noi-dung', vai: 'thuc-thi',
    dau_vao: ['bai_id'],
    dau_ra: ['video_tap'],
    tieu_chuan: 'Mỗi cảnh nói gì hiện gì rõ ràng, tổng thời lượng đúng khoảng đã giao.',
    phut: 45, can_nguoi_duyet: 1, cam: [] },
  { ma: 'doc-ket-qua-phieu', ten: 'Đọc kết quả một phiếu khảo sát', ban: 'tam-ly', vai: 'thuc-thi',
    dau_vao: ['luot_id'],
    dau_ra: ['nhan_xet'],
    tieu_chuan: 'Nói đúng giới hạn của phiếu, luôn kèm câu cảnh báo, không kết luận y tế.',
    phut: 10, can_nguoi_duyet: 1, cam: ['chan-doan', 'ket-luan-y-te'] },
  { ma: 'xet-nguong-trai', ten: 'Xét ngưỡng vào hoặc ra của trại', ban: 'trai', vai: 'tham-dinh',
    dau_vao: ['khoa_id', 'user_id', 'chieu'],
    dau_ra: ['ket_qua_xet'],
    tieu_chuan: 'Đối chiếu từng điều kiện với số thật; không đạt thì nói rõ thiếu điều nào.',
    phut: 8, can_nguoi_duyet: 0, cam: ['cap-chung-nhan-khi-chua-dat'] },
  { ma: 'soi-vi-pham', ten: 'Soi một vi phạm hiến pháp', ban: 'chat-luong', vai: 'canh-gac',
    dau_vao: ['bang_chung'],
    dau_ra: ['vi_pham_hien_phap'],
    tieu_chuan: 'Dẫn đúng điều bị phạm và trích bằng chứng nguyên văn.',
    phut: 12, can_nguoi_duyet: 1, cam: [] },
  { ma: 'theo-han-muc-ai', ten: 'Theo dõi hạn mức sáu nhà cung cấp', ban: 'ky-thuat', vai: 'thuc-thi',
    dau_vao: [],
    dau_ra: ['bao_cao_han_muc'],
    tieu_chuan: 'Báo trước khi còn dưới 20% hạn mức ngày của nhà cuối cùng còn sống.',
    phut: 3, can_nguoi_duyet: 0, cam: [] },
];

/** Quy trình: trình tự bước và ai duyệt ở bước nào. */
const QUY_TRINH = [
  { ma: 'xuat-ban-noi-dung', ten: 'Đưa một chuyên đề ra xuất bản',
    muc_dich: 'Không nội dung nào tới người học mà chưa qua mắt thứ hai.',
    buoc: [
      { thu_tu: 1, viec: 'soan-chuyen-de', ban: 'toan', duyet_boi: null },
      { thu_tu: 2, viec: 'soan-bai-tap', ban: 'toan', duyet_boi: null },
      { thu_tu: 3, viec: 'tham-dinh-bai', ban: 'chat-luong', duyet_boi: 'tham-dinh' },
      { thu_tu: 4, viec: 'soi-ky-hieu', ban: 'noi-dung', duyet_boi: 'tham-dinh' },
      { thu_tu: 5, viec: 'duyet-xuat-ban', ban: 'chat-luong', duyet_boi: 'nguoi' },
    ],
    dau_ra: 'Chuyên đề ở trạng thái da-xuat-ban, kèm bài tập đã thẩm định.' },
  { ma: 'tiep-nhan-hoc-vien', ten: 'Từ đầu mối mới tới buổi học đầu tiên',
    muc_dich: 'Không ai được xếp lớp mà chưa đo nền kiến thức.',
    buoc: [
      { thu_tu: 1, viec: 'tiep-nhan-dau-moi', ban: 'crm', duyet_boi: null },
      { thu_tu: 2, viec: 'tao-ho-so', ban: 'crm', duyet_boi: null },
      { thu_tu: 3, viec: 'test-dau-vao', ban: 'khao-thi', duyet_boi: null },
      { thu_tu: 4, viec: 'doc-ket-qua-phieu', ban: 'tam-ly', duyet_boi: 'nguoi' },
      { thu_tu: 5, viec: 'xep-lo-trinh', ban: 'lo-trinh', duyet_boi: 'nguoi' },
      { thu_tu: 6, viec: 'bao-gia-dinh', ban: 'crm', duyet_boi: 'nguoi' },
    ],
    dau_ra: 'Học viên có hồ sơ, có kết quả đầu vào, có lộ trình và gia đình đã được báo.' },
  { ma: 'xet-vuot-cap', ten: 'Xét mở cấp tiếp theo',
    muc_dich: 'Giữ luật không nhảy cấp, và nói được vì sao chưa mở.',
    buoc: [
      { thu_tu: 1, viec: 'gom-bang-chung', ban: 'lo-trinh', duyet_boi: null },
      { thu_tu: 2, viec: 'xet-vuot-cap', ban: 'lo-trinh', duyet_boi: 'tham-dinh' },
      { thu_tu: 3, viec: 'bao-ket-qua', ban: 'crm', duyet_boi: null },
    ],
    dau_ra: 'Một dòng xet_vuot_cap có chi tiết từng điều kiện và số thật.' },
];

module.exports = {
  BAN, TO_CRM, TI_LE_VAI, TEN_VAI, PHAM_VI_VAI, NHIEM_VU, QUY_TRINH,
  chiaVai, danhSachTroLy, danhSachCrm,
};
