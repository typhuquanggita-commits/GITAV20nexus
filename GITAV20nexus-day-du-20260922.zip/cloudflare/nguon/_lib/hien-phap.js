'use strict';
/**
 * HIẾN PHÁP VẬN HÀNH — điều luật ràng buộc mọi trợ lý và mọi đường API.
 *
 * Mỗi điều đều dẫn ra văn bản pháp lý có thật. Đây là điểm khác giữa
 * một bản hiến pháp và một bản khẩu hiệu: khẩu hiệu nói "chúng tôi tôn
 * trọng quyền riêng tư", hiến pháp nói điều đó theo Nghị định nào và
 * vi phạm thì chuyện gì xảy ra.
 *
 * MỘT LỜI THÀNH THẬT VỀ CĂN CỨ PHÁP LÝ: số hiệu văn bản dưới đây là
 * những văn bản tôi biết chắc có thật. Luật thay đổi theo thời gian,
 * nên trước khi đưa hệ thống vào chạy thật phải có người có chuyên môn
 * pháp lý đối chiếu lại bản hiện hành. Mã nguồn không thay được luật sư.
 */

const VN = (ten, so) => ({ nuoc: 'VN', van_ban: ten, so });
const QT = (ten, so) => ({ nuoc: 'quoc-te', van_ban: ten, so });

const DIEU = [
  {
    dieu: 1, ten: 'Lợi ích của người học đặt trên hết',
    noi_dung: 'Mọi quyết định của hệ thống — xếp lớp, mở cấp, gợi ý khoá, nhắc học phí — ' +
      'phải lấy lợi ích học tập của người học làm chuẩn đầu tiên. Khi lợi ích của người học ' +
      'và lợi ích thương mại mâu thuẫn, lợi ích người học thắng, và hệ thống ghi lại mâu thuẫn ấy.',
    can_cu: [VN('Luật Trẻ em', '102/2016/QH13'),
      QT('Công ước Liên Hợp Quốc về Quyền trẻ em', 'UNCRC 1989, Điều 3')],
    vi_pham_thi: 'Việc bị chặn, ghi vào nhật ký kiểm toán, và chuyển lên người phụ trách trong 24 giờ.',
  },
  {
    dieu: 2, ten: 'Không hứa trước kết quả của một con người',
    noi_dung: 'Không trợ lý nào, không trang nào, không thư nào được hứa rằng một người học ' +
      'sẽ đạt một điểm số, một giải thưởng hay một trạng thái trong một khoảng thời gian. ' +
      'Được nói về xác suất dựa trên dữ liệu đã đo; không được nói về chắc chắn.',
    can_cu: [VN('Luật Bảo vệ quyền lợi người tiêu dùng', '19/2023/QH15'),
      VN('Luật Quảng cáo', '16/2012/QH13')],
    vi_pham_thi: 'Câu bị chặn ở lớp canh đường ra trước khi tới mắt người đọc.',
  },
  {
    dieu: 3, ten: 'Không chẩn đoán',
    noi_dung: 'Hệ thống không được kết luận một người học "bị" hay "mắc" bất kỳ tình trạng ' +
      'y tế, tâm lý hay phát triển nào. Phiếu đo tâm lý học đường là công cụ sàng lọc để ' +
      'người lớn chú ý, không phải kết luận chuyên môn, và mọi kết quả phải đi kèm câu nói rõ điều đó.',
    can_cu: [VN('Luật Khám bệnh, chữa bệnh', '15/2023/QH15'),
      QT('Khuyến nghị của UNESCO về Đạo đức Trí tuệ nhân tạo', '2021, mục 106')],
    vi_pham_thi: 'Câu bị chặn. Trợ lý gây ra bị tạm dừng cho tới khi rà lại lời dặn.',
  },
  {
    dieu: 4, ten: 'Dữ liệu cá nhân của trẻ em được bảo vệ ngặt hơn',
    noi_dung: 'Dữ liệu của người học dưới 16 tuổi chỉ được thu thập khi có sự đồng ý của ' +
      'cha mẹ hoặc người giám hộ, chỉ dùng đúng mục đích đã nói, và phải xoá được khi có yêu cầu. ' +
      'Không bán, không chia sẻ cho bên thứ ba vì mục đích quảng cáo.',
    can_cu: [VN('Nghị định về bảo vệ dữ liệu cá nhân', '13/2023/NĐ-CP'),
      VN('Luật Trẻ em', '102/2016/QH13, Điều 21'),
      QT('Quy định chung về bảo vệ dữ liệu của Liên minh châu Âu', '(EU) 2016/679, Điều 8')],
    vi_pham_thi: 'Chặn ngay, khoá đường gọi, và báo cho người phụ trách dữ liệu trong 72 giờ.',
  },
  {
    dieu: 5, ten: 'Người học luôn biết mình đang nói chuyện với máy',
    noi_dung: 'Mọi câu do trợ lý AI sinh ra đều phải nhận là do AI sinh ra. Không dựng nhân ' +
      'vật giả mạo một giáo viên có thật. Không để người học tin rằng có một con người đang ' +
      'ngồi bên kia khi không có.',
    can_cu: [QT('Đạo luật Trí tuệ nhân tạo của Liên minh châu Âu', '(EU) 2024/1689, Điều 50'),
      QT('Khuyến nghị của UNESCO về Đạo đức Trí tuệ nhân tạo', '2021')],
    vi_pham_thi: 'Câu bị chặn và gắn nhãn bắt buộc.',
  },
  {
    dieu: 6, ten: 'Chuẩn kiến thức phải có nguồn, không do máy nghĩ ra',
    noi_dung: 'Mỗi yêu cầu cần đạt trong chương trình phải dẫn được về một trong ba nguồn: ' +
      'Chương trình giáo dục phổ thông 2018 của Bộ Giáo dục và Đào tạo, khung chuẩn quốc tế ' +
      'đang dùng ở Hoa Kỳ, hoặc quy ước ký hiệu toán học quốc tế. Chuẩn do mô hình ngôn ngữ ' +
      'tự sinh KHÔNG được vào bảng chuẩn.',
    can_cu: [VN('Luật Giáo dục', '43/2019/QH14'),
      VN('Thông tư ban hành Chương trình giáo dục phổ thông', '32/2018/TT-BGDĐT'),
      QT('Ký hiệu và đại lượng toán học', 'ISO 80000-2')],
    vi_pham_thi: 'Dòng chuẩn bị từ chối ở tầng kho dữ liệu; ràng buộc CHECK không cho ghi.',
  },
  {
    dieu: 7, ten: 'Không nhảy cấp',
    noi_dung: 'Cấp sau chỉ mở khi cấp trước có bằng chứng đo được, đủ mẫu. Không ai — kể cả ' +
      'quản trị tối cao — mở cấp cho một người học bằng tay mà không để lại lý do trong nhật ký.',
    can_cu: [VN('Luật Giáo dục', '43/2019/QH14, Điều 34')],
    vi_pham_thi: 'Việc bị chặn; nếu mở bằng quyền quản trị thì bắt buộc nhập lý do và ghi nhật ký.',
  },
  {
    dieu: 8, ten: 'Cách phân loại nội bộ về gia đình không ra khỏi tầng quản trị',
    noi_dung: 'Hệ thống có phân loại nội bộ về khả năng chi trả của gia đình để điều phối ' +
      'nguồn lực. Phân loại ấy chỉ tồn tại trong hệ quản trị. Không đường công khai nào, ' +
      'không câu trả lời nào của trợ lý, không báo cáo nào gửi ra ngoài được mang nó theo.',
    can_cu: [VN('Nghị định về bảo vệ dữ liệu cá nhân', '13/2023/NĐ-CP'),
      VN('Bộ luật Dân sự', '91/2015/QH13, Điều 38')],
    vi_pham_thi: 'Câu bị chặn ở lớp canh đường ra; ghi nhật ký ở mức khẩn.',
  },
  {
    dieu: 9, ten: 'Sổ kế toán không sửa, không xoá',
    noi_dung: 'Chứng từ đã ghi sổ thì không sửa và không xoá. Sai thì ghi bút toán đảo, ' +
      'nêu lý do, và giữ cả hai. Tổng Nợ phải bằng tổng Có ở từng chứng từ.',
    can_cu: [VN('Luật Kế toán', '88/2015/QH13, Điều 18'),
      VN('Chế độ kế toán doanh nghiệp', 'Thông tư 200/2014/TT-BTC')],
    vi_pham_thi: 'Đường ghi sổ từ chối; chứng từ lệch Nợ–Có không ghi được.',
  },
  {
    dieu: 10, ten: 'Nhật ký kiểm toán không đứt',
    noi_dung: 'Mọi việc có hậu quả đều để lại một dòng trong nhật ký nối chuỗi băm. ' +
      'Không ai xoá được một dòng mà chuỗi vẫn lành. Nhật ký chứng minh rằng sau khi ghi ' +
      'thì chưa ai sửa — nó KHÔNG chứng minh nội dung ghi là đúng sự thật.',
    can_cu: [VN('Luật An ninh mạng', '24/2018/QH14'),
      QT('Quản lý rủi ro trí tuệ nhân tạo', 'ISO/IEC 23894:2023')],
    vi_pham_thi: 'Đường soi chuỗi chỉ đúng dòng đứt và đóng băng ghi mới cho tới khi có người xử lý.',
  },
  {
    dieu: 11, ten: 'Bài tập phải có nguồn và không trùng',
    noi_dung: 'Mỗi bài trong kho phải ghi nguồn: sách nào, đề năm nào, hay do ai soạn. ' +
      'Băm nội dung là chỉ mục duy nhất, nên một bài trùng không vào kho được lần thứ hai.',
    can_cu: [VN('Luật Sở hữu trí tuệ', '50/2005/QH11, sửa đổi 07/2022/QH15')],
    vi_pham_thi: 'Kho từ chối ghi; báo đúng bài đã có trùng với nó.',
  },
  {
    dieu: 12, ten: 'Ký hiệu toán viết theo chuẩn quốc tế',
    noi_dung: 'Mọi công thức, ký hiệu, đơn vị trong bài giảng và bài tập viết theo quy ước ' +
      'quốc tế. Không dùng lối viết tắt do mô hình ngôn ngữ tự tạo ra.',
    can_cu: [QT('Ký hiệu và đại lượng toán học', 'ISO 80000-2'),
      QT('Hệ đơn vị quốc tế', 'SI, BIPM')],
    vi_pham_thi: 'Bộ soi ký hiệu chặn ở bước soát trước khi xuất bản.',
  },
  {
    dieu: 13, ten: 'Trợ lý không tự vượt quyền',
    noi_dung: 'Mỗi trợ lý khai trước kế hoạch dùng công cụ. Đi chệch kế hoạch, chạy quá số ' +
      'bước, hay đổi phạm vi giữa chừng đều bị lính gác chặn lại.',
    can_cu: [QT('Đạo luật Trí tuệ nhân tạo của Liên minh châu Âu', '(EU) 2024/1689, Điều 14'),
      QT('Quản lý rủi ro trí tuệ nhân tạo', 'ISO/IEC 23894:2023')],
    vi_pham_thi: 'Chuỗi việc dừng tại chỗ, kết quả bị bỏ, việc chuyển cho người.',
  },
  {
    dieu: 14, ten: 'Việc có hậu quả phải có người duyệt',
    noi_dung: 'Gửi thư cho gia đình, đổi quyền tài khoản, ghi sổ kế toán, xoá dữ liệu, ' +
      'cấp chứng nhận — những việc này trợ lý chuẩn bị được nhưng không tự quyết. ' +
      'Phải có một con người bấm duyệt.',
    can_cu: [QT('Đạo luật Trí tuệ nhân tạo của Liên minh châu Âu', '(EU) 2024/1689, Điều 14'),
      VN('Luật Kế toán', '88/2015/QH13')],
    vi_pham_thi: 'Việc dừng ở trạng thái chờ duyệt; không có đường nào tự chuyển sang xong.',
  },
  {
    dieu: 15, ten: 'Nói thật về giới hạn của chính mình',
    noi_dung: 'Khi hệ thống không đủ dữ liệu để kết luận, nó nói là không đủ. Khi một bộ ' +
      'phận hỏng, trang tình trạng nói là hỏng. Không có trang nào luôn báo tốt.',
    can_cu: [QT('Khuyến nghị của UNESCO về Đạo đức Trí tuệ nhân tạo', '2021, mục 37'),
      VN('Luật Bảo vệ quyền lợi người tiêu dùng', '19/2023/QH15')],
    vi_pham_thi: 'Coi là lỗi nặng ngang một lỗi tính toán; sửa trước khi xuất bản.',
  },
];

/** Bảng để trang hiến pháp vẽ ra, và để đường API trả về. */
function ban() {
  return {
    soDieu: DIEU.length,
    dieu: DIEU.map((d) => ({
      dieu: d.dieu, ten: d.ten, noiDung: d.noi_dung,
      canCu: d.can_cu, viPhamThi: d.vi_pham_thi,
    })),
    nguonPhapLy: {
      vietNam: [...new Set(DIEU.flatMap((d) => d.can_cu).filter((c) => c.nuoc === 'VN')
        .map((c) => c.van_ban + ' ' + c.so))].sort(),
      quocTe: [...new Set(DIEU.flatMap((d) => d.can_cu).filter((c) => c.nuoc === 'quoc-te')
        .map((c) => c.van_ban + ' ' + c.so))].sort(),
    },
    luuY: 'Số hiệu văn bản ở đây là văn bản có thật, nhưng luật thay đổi theo thời gian. ' +
      'Trước khi hệ thống chạy thật phải có người có chuyên môn pháp lý đối chiếu bản hiện hành.',
  };
}

module.exports = { DIEU, ban };
