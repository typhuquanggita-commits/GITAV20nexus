'use strict';
/**
 * Điểm uy tín cộng đồng.
 *
 * Đặc tả để ngỏ một lỗ: ai cũng gọi được /record với targetUserId bất
 * kỳ, nghĩa là tự cộng điểm cho mình hoặc cho bạn mình vô hạn. Ở đây
 * bịt lại bằng hai luật:
 *   - Tự ghi cho mình thì chỉ được các loại "tôi đã làm" (edit, review,
 *     suggest, flag), không được loại "đã được duyệt" (approve/reject).
 *   - Ghi cho người khác thì phải có quyền kiểm duyệt.
 * Cộng thêm trần mỗi ngày, vì điểm không giới hạn thì bảng xếp hạng
 * chỉ đo được ai rảnh nhất.
 */

const { maMoi } = require('./ma.js');

const DIEM = { review: 2, edit: 5, approve: 10, reject: 3, flag: 1, suggest: 3 };
const TU_GHI_DUOC = ['review', 'edit', 'suggest', 'flag'];
const BAC = [
  { ten: 'master', tu: 5000 },
  { ten: 'expert', tu: 2000 },
  { ten: 'reviewer', tu: 500 },
  { ten: 'contributor', tu: 100 },
  { ten: 'newcomer', tu: 0 },
];
const TRAN_NGAY = 200;      // điểm tối đa một người kiếm được mỗi ngày

function bacCua(diem) {
  for (const b of BAC) if (diem >= b.tu) return b.ten;
  return 'newcomer';
}

async function diemHomNay(kho, userId, bayGio) {
  const dau = new Date(bayGio).setUTCHours(0, 0, 0, 0);
  return kho.dem(
    'SELECT COALESCE(SUM(points_delta),0) FROM contribution_events ' +
    'WHERE user_id = ? AND created_at >= ?', [userId, dau]);
}

/**
 * Ghi một việc đóng góp. Trả về { dat, ma?, diemCong, tong, bac }.
 * Không ném lỗi — người gọi tự quyết định trả mã HTTP nào.
 */
async function ghiDongGop(kho, tham, bayGio) {
  const loai = String(tham.loai || '');
  if (!Object.prototype.hasOwnProperty.call(DIEM, loai)) {
    return { dat: false, ma: 'loai-khong-biet',
      loi: 'Loại đóng góp phải là một trong: ' + Object.keys(DIEM).join(', ') + '.' };
  }
  const choAi = tham.choAi || tham.nguoiGhi;
  const tuGhi = choAi === tham.nguoiGhi;
  if (tuGhi && !TU_GHI_DUOC.includes(loai)) {
    return { dat: false, ma: 'tu-cong-diem',
      loi: 'Loại "' + loai + '" phải do người khác xác nhận, không tự ghi cho mình được.' };
  }
  if (!tuGhi && !tham.duocKiemDuyet) {
    return { dat: false, ma: 'khong-du-quyen-ghi-ho',
      loi: 'Ghi đóng góp cho người khác cần quyền kiểm duyệt nội dung.' };
  }

  const now = bayGio;
  const daCo = await diemHomNay(kho, choAi, now);
  if (daCo >= TRAN_NGAY) {
    return { dat: false, ma: 'qua-tran-ngay',
      loi: 'Tài khoản này đã đạt trần ' + TRAN_NGAY + ' điểm đóng góp trong ngày.' };
  }
  const diem = Math.min(DIEM[loai], TRAN_NGAY - daCo);

  await kho.chen('contribution_events', {
    id: maMoi(), user_id: choAi, event_type: loai,
    content_type: String(tham.loaiNoiDung || ''), content_id: String(tham.maNoiDung || ''),
    points_delta: diem, reason: tham.lyDo ? String(tham.lyDo).slice(0, 500) : null,
    verified_by: tham.nguoiGhi, created_at: now,
  });

  const d = (t) => (loai === t ? 1 : 0);
  await kho.chay(
    'INSERT INTO reputation_scores ' +
    '(user_id, total_points, level, reviews_count, edits_count, approvals_count, ' +
    ' rejections_count, reputation_score, last_active_at, updated_at) ' +
    "VALUES (?, ?, 'newcomer', ?, ?, ?, ?, 0, ?, ?) " +
    'ON CONFLICT(user_id) DO UPDATE SET ' +
    '  total_points     = total_points + excluded.total_points, ' +
    '  reviews_count    = reviews_count + excluded.reviews_count, ' +
    '  edits_count      = edits_count + excluded.edits_count, ' +
    '  approvals_count  = approvals_count + excluded.approvals_count, ' +
    '  rejections_count = rejections_count + excluded.rejections_count, ' +
    '  last_active_at   = excluded.last_active_at, ' +
    '  updated_at       = excluded.updated_at',
    [choAi, diem, d('review'), d('edit'), d('approve'), d('reject'), now, now]);

  const s = await kho.mot('SELECT total_points FROM reputation_scores WHERE user_id = ?', [choAi]);
  const tong = Number(s.total_points);
  const bac = bacCua(tong);
  await kho.chay('UPDATE reputation_scores SET level = ?, ' +
    'reputation_score = CASE WHEN (reviews_count + edits_count) = 0 THEN 0 ' +
    '  ELSE CAST(approvals_count AS REAL) / (reviews_count + edits_count) END ' +
    'WHERE user_id = ?', [bac, choAi]);

  await kho.chen('reward_ledger', {
    id: maMoi(), user_id: choAi, points: diem, source: loai,
    reference_id: String(tham.maNoiDung || ''), created_at: now,
  });

  const huy = await xetHuyHieu(kho, choAi, tong, now);
  return { dat: true, diemCong: diem, tong, bac, huyHieuMoi: huy,
    conLaiHomNay: Math.max(0, TRAN_NGAY - daCo - diem) };
}

const HUY_HIEU = [
  { ma: 'buoc-dau', dieu: (s) => s.total_points >= 10, ten: 'Bước đầu' },
  { ma: 'nguoi-soat', dieu: (s) => s.reviews_count >= 25, ten: 'Người soát' },
  { ma: 'nguoi-sua', dieu: (s) => s.edits_count >= 25, ten: 'Người sửa' },
  { ma: 'tram-diem', dieu: (s) => s.total_points >= 100, ten: 'Trăm điểm' },
  { ma: 'nghin-diem', dieu: (s) => s.total_points >= 1000, ten: 'Nghìn điểm' },
];

async function xetHuyHieu(kho, userId, tong, bayGio) {
  const s = await kho.mot('SELECT * FROM reputation_scores WHERE user_id = ?', [userId]);
  if (!s) return [];
  const moi = [];
  for (const h of HUY_HIEU) {
    if (!h.dieu(s)) continue;
    const da = await kho.mot(
      'SELECT id FROM user_badges WHERE user_id = ? AND badge_code = ?', [userId, h.ma]);
    if (da) continue;
    await kho.chen('user_badges', {
      id: maMoi(), user_id: userId, badge_code: h.ma,
      metadata_json: JSON.stringify({ ten: h.ten, tai: tong }), earned_at: bayGio,
    });
    moi.push({ ma: h.ma, ten: h.ten });
  }
  return moi;
}

module.exports = { DIEM, BAC, TRAN_NGAY, TU_GHI_DUOC, HUY_HIEU, bacCua, ghiDongGop, diemHomNay };
