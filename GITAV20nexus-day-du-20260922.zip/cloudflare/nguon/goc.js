'use strict';
/**
 * Cửa vào của toàn bộ tầng Cloudflare.
 *
 * Một yêu cầu đi qua đây theo đúng thứ tự này và không có đường tắt:
 *   1. Đường không bắt đầu bằng /api → giao cho tệp tĩnh (ASSETS).
 *   2. Chưa gắn kho D1 → nói thẳng cách gắn, không giả vờ chạy được.
 *   3. Tìm tuyến. Không có → 404. Có nhưng sai cách gọi → 405 kèm cách đúng.
 *   4. Dựng bối cảnh (phiên, quyền, hạn mức) rồi mới gọi tuyến.
 *   5. Mọi lỗi chưa bắt được đều thành 500 có mã, không lộ vết ngăn xếp.
 */

const { BoDinhTuyen } = require('./_lib/dinh-tuyen.js');
const { dungBoiCanh } = require('./_lib/boi-canh.js');
const dap = require('./_lib/dap.js');
const { chuaGanKho } = require('./_lib/kho.js');
const { NHOM } = require('./danh-muc.js');
const { nhomTuyen } = require('./nap.js');
const boNao = require('./_lib/bo-nao-trung-tam.js');

let BO = null;

function dungBo() {
  if (BO) return BO;
  const bo = BoDinhTuyen();
  for (const n of NHOM) {
    const m = nhomTuyen[n.tep];
    if (!m) continue;               // nhóm khai trong danh mục mà chưa có tệp
    bo.gan(n.tienTo, (them) => m.dangKy(them));
  }
  BO = bo;
  return bo;
}

function tieuDeCors(moi) {
  // Chỉ mở cho chính miền của trang. Không có dấu sao ở đây.
  const gocChoPhep = moi.CORS_ORIGIN || '';
  if (!gocChoPhep) return {};
  return {
    'Access-Control-Allow-Origin': gocChoPhep,
    'Access-Control-Allow-Credentials': 'true',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
  };
}

async function xuLy(req, moi, ctx, dongHo) {
  const url = new URL(req.url);
  // Dấu gạch chéo cuối không tạo ra đường khác. Người gõ tay hay thêm nó,
  // và trả 404 vì một dấu gạch là thứ khó chịu không có lý do gì.
  const duongDan = url.pathname.length > 1 && url.pathname.endsWith('/')
    ? url.pathname.replace(/\/+$/, '') : url.pathname;

  // 1 — mọi thứ không phải API là tệp tĩnh
  if (!duongDan.startsWith('/api')) {
    if (moi.ASSETS) return moi.ASSETS.fetch(req);
    return new Response('Chưa gắn kho tệp tĩnh.', { status: 500 });
  }

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: tieuDeCors(moi) });
  }

  // 2 — chưa gắn D1 thì nói thẳng, đừng để tuyến tự vỡ
  if (!moi.DB) return chuaGanKho();

  const bo = dungBo();
  const khop = bo.tim(req.method, duongDan);

  if (!khop) {
    const cachKhac = bo.coDuongKhacCach(duongDan);
    if (cachKhac.length) {
      return dap.hong(405, 'sai-cach-goi',
        'Đường này có thật nhưng phải gọi bằng ' + cachKhac.join(' hoặc ') + '.',
        { cachDung: cachKhac });
    }
    return dap.hong(404, 'khong-co-duong',
      'Không có đường ' + req.method + ' ' + duongDan + '. Xem GET /api/duong để biết đủ.');
  }

  try {
    const bc = await dungBoiCanh(req, moi, khop.thamSo, dongHo);
    bc.ctx = ctx;

    // ── Bộ não trung tâm: cửa vào duy nhất ──
    //
    // Mọi lệnh đi qua đây trước khi chạm vào tuyến, và đi qua đây lần nữa
    // trên đường ra. Không có đường vòng: tuyến không tự gọi được, vì nó
    // chỉ nhận bối cảnh đã qua bộ não.
    const nao = await boNao.chay({
      req, moi, kho: bc.kho, bayGio: bc.bayGio, nguoi: bc.nguoi, dap,
      than: req.method === 'GET' || req.method === 'HEAD' ? null : await bc.layThan(),
    });
    if (nao.chan) return nao.tra;
    bc.maLenh = nao.maLenh;
    bc.troLyNhan = nao.troLy;
    bc.danhDauHanhVi = nao.danhDau;
    bc.soDuong = bo.soDuong;
    bc.dsDuong = bo.duong;
    bc.nhomTuyen = NHOM.filter((n) => nhomTuyen[n.tep])
      .map((n) => ({ ten: n.ten, tienTo: n.tienTo || '(nền)' }));
    const raTho = await khop.xuLy(bc);
    if (!(raTho instanceof Response)) {
      return dap.hong(500, 'tuyen-khong-tra-response',
        'Tuyến ' + req.method + ' ' + duongDan + ' không trả về Response.');
    }
    // Đường ra cũng đi qua bộ não: thanh tra soi lại rồi mới cho rời hệ thống.
    const ra = await nao.ketThuc(raTho);
    const them = tieuDeCors(moi);
    if (Object.keys(them).length === 0) return ra;
    const h = new Headers(ra.headers);
    for (const k of Object.keys(them)) h.set(k, them[k]);
    return new Response(ra.body, { status: ra.status, headers: h });
  } catch (e) {
    if (e && e.ma === 'than-khong-phai-json') {
      return dap.hong(400, 'than-khong-phai-json', 'Thân yêu cầu không phải JSON hợp lệ.');
    }
    if (e && e.ma === 'than-qua-lon') {
      return dap.hong(413, 'than-qua-lon', 'Thân yêu cầu vượt 256 KB.');
    }
    if (e && e.ma === 'ai-khong-goi-duoc') {
      return dap.hong(502, 'ai-khong-goi-duoc', e.message, { duongDaDi: e.duongDaDi });
    }
    if (e && e.message === 'chua-gan-kho') return chuaGanKho();
    // Không đưa vết ngăn xếp ra ngoài: nó lộ đường dẫn và tên bảng.
    console.error('loi-khong-bat-duoc', duongDan, e && e.stack ? e.stack : e);
    return dap.hong(500, 'loi-may-chu',
      'Máy chủ gặp lỗi khi xử lý ' + req.method + ' ' + duongDan + '.');
  }
}

const worker = {
  fetch(req, moi, ctx) {
    return xuLy(req, moi, ctx);
  },
  /** Lịch Cron: dọn dẹp, không làm việc nặng trong đường chính. */
  async scheduled(su, moi, ctx) {
    if (!moi.DB) return;
    const { Kho } = require('./_lib/kho.js');
    const phien = require('./_lib/phien.js');
    const hanMuc = require('./_lib/han-muc.js');
    const { KhoNghia } = require('./_lib/kho-nghia.js');
    const kho = Kho(moi.DB);
    const p = await phien.quetPhienHetHan(kho);
    const h = await hanMuc.quet(kho);
    const d = await KhoNghia(kho, moi.KV).donHetHan();
    console.log('don-dep', JSON.stringify({ phienXoa: p, demXoa: d, hanMucXoa: h }));
  },
};

module.exports = { worker, xuLy, dungBo };
