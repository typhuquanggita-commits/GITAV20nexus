'use strict';
/**
 * Sinh nap.js — bảng require tĩnh của các nhóm tuyến.
 *
 * Phải là require tĩnh vì bộ ghép đọc chúng để xếp thứ tự; require
 * động sẽ chạy được ở Node nhưng chết trên workerd. Tệp này sinh ra
 * bảng ấy từ danh mục, nên không bao giờ lệch nhau.
 */
const fs = require('node:fs');
const path = require('node:path');
const { NHOM } = require('./danh-muc.js');

const thuMuc = path.join(__dirname, 'tuyen');
const co = [], thieu = [];
for (const n of NHOM) {
  (fs.existsSync(path.join(thuMuc, n.tep + '.js')) ? co : thieu).push(n.tep);
}

const ra = [
  "'use strict';",
  '/**',
  ' * Bảng nhóm tuyến — SINH TỰ ĐỘNG bởi tao-nap.js, đừng sửa tay.',
  ' * Chạy lại:  node cloudflare/nguon/tao-nap.js',
  ' */',
  '',
  'const nhomTuyen = {',
  ...co.map((t) => "  '" + t + "': require('./tuyen/" + t + ".js'),"),
  '};',
  '',
  'module.exports = { nhomTuyen };',
  '',
].join('\n');

fs.writeFileSync(path.join(__dirname, 'nap.js'), ra);
console.log('nap.js: ' + co.length + ' nhóm có tệp' +
  (thieu.length ? ', ' + thieu.length + ' nhóm còn thiếu: ' + thieu.join(', ') : ''));
