'use strict';
/**
 * Danh mục các nhóm tuyến.
 *
 * Một chỗ duy nhất khai báo nhóm nào gắn ở tiền tố nào. Thêm nhóm mà
 * quên khai ở đây thì nó không tồn tại — cố ý, để không có tuyến nào
 * lọt vào hệ thống mà không ai biết.
 *
 * Tiền tố giữ nguyên đánh số phiên bản của đặc tả (v13…v23) vì các
 * ứng dụng khách đã gọi theo đường ấy; đổi bây giờ là làm hỏng chúng.
 */

const NHOM = [
  // Nền — không mang số phiên bản, vì luôn có
  { tienTo: '',                        tep: 'he-thong',        ten: 'Hệ thống' },
  { tienTo: '',                        tep: 'tai-khoan',       ten: 'Tài khoản' },

  // V13 — nền $0
  { tienTo: '/api/v13/providers',      tep: 'nha-cung-cap',    ten: 'Sáu nhà cung cấp AI' },
  { tienTo: '/api/v13/sync',           tep: 'dong-bo',         ten: 'Đồng bộ ngoại tuyến CRDT' },
  { tienTo: '/api/v13/contributions',  tep: 'dong-gop',        ten: 'Đóng góp cộng đồng' },
  { tienTo: '/api/v13/translations',   tep: 'dich',            ten: 'Dịch nội dung' },

  // V16 — học và nội dung
  { tienTo: '/api/v16/tutor',          tep: 'gia-su',          ten: 'Gia sư AI' },
  { tienTo: '/api/v16/video',          tep: 'video',           ten: 'Dựng video bài giảng' },
  { tienTo: '/api/v16/podcast',        tep: 'podcast',         ten: 'Podcast bài giảng' },
  { tienTo: '/api/v16/cert',           tep: 'chung-chi',       ten: 'Chứng chỉ' },
  { tienTo: '/api/v16/marketplace',    tep: 'cho-khoa-hoc',    ten: 'Chợ khoá học' },

  // V17 — trường lớp và doanh nghiệp
  { tienTo: '/api/v17/generate',       tep: 'sinh-khoa-hoc',   ten: 'Sinh khoá học tự động' },
  { tienTo: '/api/v17/cohorts',        tep: 'khoa-dong-hanh',  ten: 'Khoá đồng hành' },
  { tienTo: '/api/v17/skills',         tep: 'do-thi-ky-nang',  ten: 'Đồ thị kỹ năng' },
  { tienTo: '/api/v17/interview',      tep: 'luyen-phong-van', ten: 'Luyện phỏng vấn' },
  { tienTo: '/api/v17/enterprise',     tep: 'to-chuc',         ten: 'Tổ chức và đăng nhập một lần' },

  // V18 — nghiên cứu, sự kiện, tín chỉ
  { tienTo: '/api/v18/research',       tep: 'nghien-cuu',      ten: 'Trợ lý nghiên cứu' },
  { tienTo: '/api/v18/events',         tep: 'su-kien',         ten: 'Sự kiện trực tiếp' },
  { tienTo: '/api/v18/credits',        tep: 'tin-chi',         ten: 'Tín chỉ kỹ năng' },
  { tienTo: '/api/v18/podcast-dialogue', tep: 'doi-thoai',     ten: 'Podcast dạng đối thoại' },
  { tienTo: '/api/v18/coach',          tep: 'huan-luyen',      ten: 'Huấn luyện nghề nghiệp' },

  // V19 — cộng đồng và giọng nói
  { tienTo: '/api/v19/buddies',        tep: 'ban-hoc',         ten: 'Ghép bạn học' },
  { tienTo: '/api/v19/voice',          tep: 'giong-noi',       ten: 'Học bằng giọng nói' },
  { tienTo: '/api/v19/packs',          tep: 'goi-ngoai-tuyen', ten: 'Gói học ngoại tuyến' },
  { tienTo: '/api/v19/qa',             tep: 'hoi-dap',         ten: 'Hỏi đáp ẩn danh' },
  { tienTo: '/api/v19/debate',         tep: 'tranh-luan',      ten: 'Bạn tranh luận' },

  // V20 — đo lường và biến đổi nội dung
  { tienTo: '/api/v20/remix',          tep: 'bien-soan-lai',   ten: 'Biến bài học sang dạng khác' },
  { tienTo: '/api/v20/analytics',      tep: 'do-luong',        ten: 'Bảng đo lường học tập' },
  { tienTo: '/api/v20/translate-pro',  tep: 'dich-chuyen-sau', ten: 'Dịch có thuật ngữ' },
  { tienTo: '/api/v20/twin',           tep: 'ban-sao-so',      ten: 'Bản sao số của người học' },
  { tienTo: '/api/v20/peer-grading',   tep: 'cham-cheo',       ten: 'Chấm chéo' },

  // V21 — trợ giảng, cộng đồng, kiểm toán
  { tienTo: '/api/v21/ta',             tep: 'tro-giang',       ten: 'Trợ giảng AI' },
  { tienTo: '/api/v21/micro',          tep: 'hoc-vun',         ten: 'Học vụn' },
  { tienTo: '/api/v21/audit',          tep: 'soi-chuong-trinh', ten: 'Soi chương trình học' },
  { tienTo: '/api/v21/onchain',        tep: 'chung-chi-chuoi', ten: 'Chứng chỉ nối chuỗi' },
  { tienTo: '/api/v21/community',      tep: 'cong-dong',       ten: 'Quản lý cộng đồng' },

  // V22 — lớp ảo, cố vấn, pháp lý, dự báo
  { tienTo: '/api/v22/classroom',      tep: 'lop-ao',          ten: 'Lớp học ảo' },
  { tienTo: '/api/v22/mentor',         tep: 'co-van',          ten: 'Cố vấn AI' },
  { tienTo: '/api/v22/legal',          tep: 'phap-ly',         ten: 'Tuân thủ pháp lý' },
  { tienTo: '/api/v22/predictive',     tep: 'du-bao',          ten: 'Dự báo kết quả' },

  // V23 — thi chứng chỉ
  { tienTo: '/api/v23/exam',           tep: 'thi-chung-chi',   ten: 'Kỳ thi chứng chỉ' },
  // ── Miền GITAV20nexus ──
  { tienTo: '/api/chuong-trinh',       tep: 'chuong-trinh',    ten: 'Chương trình Toán · Tiếng Anh · Ngữ văn lớp 1–12' },
  { tienTo: '/api/kho-bai',            tep: 'kho-bai',         ten: 'Kho bài tập và chuyên đề' },
  { tienTo: '/api/luyen-thi',          tep: 'luyen-thi',       ten: 'Luyện thi và tổ chức thi sáu hệ chuẩn' },
  { tienTo: '/api/khao-sat',           tep: 'khao-sat',        ten: 'Khảo sát, test đầu vào, hồ sơ học viên' },
  { tienTo: '/api/lo-trinh',           tep: 'lo-trinh',        ten: 'Lộ trình cá nhân hoá và giám sát' },
  { tienTo: '/api/trai',               tep: 'trai',            ten: 'Trại Gel Alpha · Leader Boom · Kỹ năng học giỏi' },
  { tienTo: '/api/bo-nao',             tep: 'bo-nao',          ten: 'Bộ não 600 trợ lý, bảng nhiệm vụ, hiến pháp' },
  { tienTo: '/api/crm',                tep: 'crm',             ten: 'Quan hệ gia đình — 50 trợ lý' },
  { tienTo: '/api/ke-toan',            tep: 'ke-toan',         ten: 'Tài chính kế toán ghi sổ kép' },
  { tienTo: '/api/chuoi-video',        tep: 'chuoi-video',     ten: 'Chuỗi video bài giải' },
  { tienTo: '/api/bao-mat',            tep: 'bao-mat',         ten: 'Bảo mật 22 lớp và sổ lệnh bộ não' },
  { tienTo: '/api/tong',               tep: 'tong',            ten: 'Bảng quản trị tổng' },
  { tienTo: '/api/tin-hieu',           tep: 'tin-hieu',        ten: 'Đo sức tiên đoán và kiểm nghiệm ngưỡng' },
];

module.exports = { NHOM };
