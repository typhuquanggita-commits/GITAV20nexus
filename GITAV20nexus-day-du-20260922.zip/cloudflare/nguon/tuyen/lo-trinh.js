'use strict';
/**
 * Lộ trình cá nhân hoá, giám sát và xét vượt cấp.
 *
 * Luật không nhảy cấp (Điều 7) sống ở đây, và nó có một mặt ít ai nghĩ
 * tới: KHÔNG KẾT LUẬN KHI CHƯA ĐỦ MẪU. Một học viên làm đúng 3/3 bài
 * không phải là người đạt 100% — đó là người mới làm ba bài. Cột
 * tren_mau của điều kiện giữ đúng chỗ ấy, và hàm xét trả về
 * "thiếu-mẫu" chứ không trả về "đạt".
 */

const dap = require('../_lib/dap.js');
const { maMoi } = require('../_lib/ma.js');
const bg = require('../_lib/bang-goc.js');

const DO_BANG = ['ti-le-dung', 'so-bai', 'diem-kiem-tra', 'so-buoi', 'chuan-phu', 'thoi-gian-giu'];

/** Điều kiện mặc định cho một ô, suy từ điều kiện vào của cấp kế tiếp. */
function dieuKienMacDinh(capDoId) {
  const c = bg.CAP_DO.find((x) => x.id === capDoId);
  if (!c) return [];
  const sau = bg.CAP_DO.find((x) => x.thu_tu === c.thu_tu + 1);
  if (!sau) {
    return [{ ma: 'giu-muc', mo_ta: 'Giữ tỉ lệ đúng từ 90% trên ít nhất 200 bài.',
      do_bang: 'ti-le-dung', nguong: 0.9, tren_mau: 200, bat_buoc: 1 }];
  }
  // Ngưỡng lấy đúng theo câu điều kiện vào đã khai ở bảng gốc.
  const tuNguong = { 'nang-cao': [0.9, 60], clc: [0.85, 60], hsg: [0.85, 60],
    chuyen: [0.8, 80], 'dai-hoc': [0.8, 80], 'quoc-te': [0.9, 200] }[sau.id] || [0.85, 60];
  return [
    { ma: 'ti-le-dung', mo_ta: 'Đạt từ ' + Math.round(tuNguong[0] * 100) + '% số bài đã làm.',
      do_bang: 'ti-le-dung', nguong: tuNguong[0], tren_mau: tuNguong[1], bat_buoc: 1 },
    { ma: 'so-bai', mo_ta: 'Đã làm ít nhất ' + tuNguong[1] + ' bài ở ô này.',
      do_bang: 'so-bai', nguong: tuNguong[1], tren_mau: null, bat_buoc: 1 },
  ];
}

/** Đo một điều kiện bằng số thật. Trả về { dat, so, duMau }. */
async function doDieuKien(kho, userId, oId, dk, bayGio) {
  if (dk.do_bang === 'ti-le-dung' || dk.do_bang === 'so-bai') {
    const r = await kho.mot(
      'SELECT COUNT(*) AS tong, COALESCE(SUM(t.dung), 0) AS dung ' +
      'FROM luot_thi_tra_loi t JOIN luot_thi l ON l.id = t.luot_id ' +
      'JOIN bai_tap b ON b.id = t.bai_id ' +
      'WHERE l.user_id = ? AND b.o_id = ? AND t.dung IS NOT NULL', [userId, oId]);
    const tong = Number(r.tong), dung = Number(r.dung);
    if (dk.do_bang === 'so-bai') {
      return { dat: tong >= dk.nguong, so: tong, duMau: true };
    }
    const canMau = dk.tren_mau || 1;
    if (tong < canMau) {
      return { dat: false, so: tong ? Number((dung / tong).toFixed(4)) : 0,
        duMau: false, canMau, daCo: tong };
    }
    const tiLe = dung / tong;
    return { dat: tiLe >= dk.nguong, so: Number(tiLe.toFixed(4)), duMau: true, daCo: tong };
  }
  if (dk.do_bang === 'diem-kiem-tra') {
    const r = await kho.mot(
      'SELECT MAX(l.diem_quy_doi) AS cao, COUNT(*) AS so FROM luot_thi l ' +
      "WHERE l.user_id = ? AND l.trang_thai = 'da-nop'", [userId]);
    const so = Number(r.so);
    const canMau = dk.tren_mau || 1;
    if (so < canMau) return { dat: false, so: Number(r.cao || 0), duMau: false, canMau, daCo: so };
    return { dat: Number(r.cao || 0) >= dk.nguong, so: Number(r.cao || 0), duMau: true, daCo: so };
  }
  if (dk.do_bang === 'so-buoi') {
    const so = await kho.dem('SELECT COUNT(*) FROM buoi_hoc WHERE user_id = ?', [userId]);
    return { dat: so >= dk.nguong, so, duMau: true };
  }
  if (dk.do_bang === 'chuan-phu') {
    const r = await kho.mot(
      'SELECT so_chuan, so_chuan_co_bai FROM phu_song WHERE o_id = ?', [oId]);
    const tong = r ? Number(r.so_chuan) : 0;
    const co = r ? Number(r.so_chuan_co_bai) : 0;
    if (tong === 0) return { dat: false, so: 0, duMau: false, canMau: 1, daCo: 0 };
    const ti = co / tong;
    return { dat: ti >= dk.nguong, so: Number(ti.toFixed(4)), duMau: true };
  }
  if (dk.do_bang === 'thoi-gian-giu') {
    const r = await kho.mot(
      'SELECT MIN(bat_dau) AS dau, MAX(bat_dau) AS cuoi, COUNT(*) AS so ' +
      'FROM buoi_hoc WHERE user_id = ?', [userId]);
    const so = Number(r.so);
    if (so < 2) return { dat: false, so: 0, duMau: false, canMau: 2, daCo: so };
    const ngay = Math.floor((Number(r.cuoi) - Number(r.dau)) / 86400000);
    return { dat: ngay >= dk.nguong, so: ngay, duMau: true };
  }
  return { dat: false, so: null, duMau: false, canMau: 1, daCo: 0 };
}

function dangKy(them) {
  them('POST', '/dieu-kien', async (bc) => {
    const chan = bc.canQuyen('roadmap.manage');
    if (chan) return chan;
    const t = await bc.layThan();
    const oId = String(t.oId || '');
    const o = await bc.kho.mot('SELECT id, cap_do_id FROM o_chuong_trinh WHERE id = ?', [oId]);
    if (!o) return dap.khongThay('ô chương trình');
    const ds = Array.isArray(t.dieuKien) ? t.dieuKien : dieuKienMacDinh(o.cap_do_id);
    if (ds.length === 0) {
      return dap.hong(400, 'khong-co-dieu-kien',
        'Một ô không có điều kiện vượt nào nghĩa là cấp sau mở tự do. Điều 7 không cho.');
    }
    for (const d of ds) {
      if (!DO_BANG.includes(d.do_bang)) {
        return dap.hong(400, 'do-bang-khong-biet',
          'do_bang phải là một trong: ' + DO_BANG.join(', ') + '.');
      }
      await bc.kho.chay(
        'INSERT INTO dieu_kien_vuot (id, o_id, ma, mo_ta, do_bang, nguong, tren_mau, bat_buoc) ' +
        'VALUES (?, ?, ?, ?, ?, ?, ?, ?) ' +
        'ON CONFLICT(o_id, ma) DO UPDATE SET mo_ta = excluded.mo_ta, ' +
        '  do_bang = excluded.do_bang, nguong = excluded.nguong, ' +
        '  tren_mau = excluded.tren_mau, bat_buoc = excluded.bat_buoc',
        [maMoi(), oId, d.ma, d.mo_ta, d.do_bang, Number(d.nguong),
          d.tren_mau === undefined || d.tren_mau === null ? null : Number(d.tren_mau),
          d.bat_buoc === 0 ? 0 : 1]);
    }
    await bc.ghiNhatKy('lo-trinh.dieu-kien', oId, { so: ds.length });
    return dap.json({ dat: true, oId, soDieuKien: ds.length, dieuKien: ds }, 201);
  }, 'Đặt điều kiện vượt cho một ô');

  them('POST', '/xet-vuot/:userId/:oId', async (bc) => {
    const chan = bc.canQuyen('roadmap.manage');
    if (chan) return chan;
    const o = await bc.kho.mot('SELECT id FROM o_chuong_trinh WHERE id = ?', [bc.thamSo.oId]);
    if (!o) return dap.khongThay('ô chương trình');
    const ds = await bc.kho.nhieu('SELECT * FROM dieu_kien_vuot WHERE o_id = ?', [bc.thamSo.oId]);
    if (ds.length === 0) {
      return dap.hong(409, 'chua-dat-dieu-kien',
        'Ô này chưa có điều kiện vượt nào. Đặt điều kiện trước khi xét, ' +
        'vì xét mà không có chuẩn thì kết luận gì cũng được.');
    }

    const chiTiet = [];
    let thieuMau = false, chuaDat = false;
    for (const d of ds) {
      const k = await doDieuKien(bc.kho, bc.thamSo.userId, bc.thamSo.oId, d, bc.bayGio());
      chiTiet.push({ ma: d.ma, moTa: d.mo_ta, doBang: d.do_bang, nguong: d.nguong,
        soThat: k.so, dat: k.dat, duMau: k.duMau,
        canMau: k.canMau, daCo: k.daCo, batBuoc: !!d.bat_buoc });
      if (!k.duMau && d.bat_buoc) thieuMau = true;
      if (k.duMau && !k.dat && d.bat_buoc) chuaDat = true;
    }
    const ketQua = thieuMau ? 'thieu-mau' : (chuaDat ? 'chua-dat' : 'dat');

    const id = maMoi();
    await bc.kho.chen('xet_vuot_cap', {
      id, user_id: bc.thamSo.userId, o_id: bc.thamSo.oId,
      xet_luc: bc.bayGio(), ket_qua: ketQua,
      chi_tiet_json: JSON.stringify(chiTiet), nguoi_duyet: bc.nguoi.id,
    });
    await bc.ghiNhatKy('lo-trinh.xet-vuot', id, { oId: bc.thamSo.oId, ketQua });

    return dap.json({
      dat: true, id, ketQua, chiTiet,
      noiThang: ketQua === 'thieu-mau'
        ? 'Chưa đủ mẫu để kết luận. Làm đúng ba bài không phải là đạt 100% — ' +
          'đó là mới làm ba bài.'
        : (ketQua === 'chua-dat'
          ? 'Chưa đạt. Xem chi tiết để biết điều kiện nào còn thiếu và thiếu bao nhiêu.'
          : 'Đạt đủ mọi điều kiện bắt buộc.'),
    });
  }, 'Xét một lần vượt cấp, dựa trên số thật');

  them('POST', '/mo-cap-bang-tay/:userId/:oId', async (bc) => {
    const chan = bc.canQuyen('roadmap.manage');
    if (chan) return chan;
    const t = await bc.layThan();
    const lyDo = String(t.lyDo || '').trim();
    if (lyDo.length < 20) {
      return dap.hong(400, 'thieu-ly-do',
        'Mở cấp bằng tay phải nêu lý do từ 20 ký tự trở lên. ' +
        'Điều 7 cho phép làm việc này, nhưng không cho phép làm lặng lẽ.');
    }
    const id = maMoi();
    await bc.kho.chen('xet_vuot_cap', {
      id, user_id: bc.thamSo.userId, o_id: bc.thamSo.oId, xet_luc: bc.bayGio(),
      ket_qua: 'dat',
      chi_tiet_json: JSON.stringify([{ ma: 'mo-bang-tay', moTa: lyDo,
        boiAi: bc.nguoi.id, khongQuaDieuKien: true }]),
      nguoi_duyet: bc.nguoi.id,
    });
    await bc.ghiNhatKy('lo-trinh.mo-cap-bang-tay', id,
      { userId: bc.thamSo.userId, oId: bc.thamSo.oId, lyDo });
    return dap.json({ dat: true, id,
      ghiChu: 'Đã ghi vào nhật ký kiểm toán kèm lý do và tên người mở.' }, 201);
  }, 'Mở cấp bằng tay, bắt buộc nêu lý do');

  them('GET', '/xet-vuot/:userId', async (bc) => {
    const chan = bc.canLaChinhMinh(bc.thamSo.userId, 'roadmap.manage');
    if (chan) return chan;
    const ds = await bc.kho.nhieu(
      'SELECT * FROM xet_vuot_cap WHERE user_id = ? ORDER BY xet_luc DESC LIMIT ?',
      [bc.thamSo.userId, bc.soTu('soDong', 30, 1, 100)]);
    return dap.json({ dat: true, so: ds.length, lan: ds.map((d) => ({
      id: d.id, o: d.o_id, ketQua: d.ket_qua, luc: Number(d.xet_luc),
      chiTiet: JSON.parse(d.chi_tiet_json), nguoiDuyet: d.nguoi_duyet })) });
  }, 'Lịch sử xét vượt cấp của một người học');

  them('POST', '/buoi-hoc', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const t = await bc.layThan();
    const id = maMoi();
    const now = bc.bayGio();
    await bc.kho.chen('buoi_hoc', {
      id, user_id: bc.nguoi.id,
      chuyen_de_id: t.chuyenDeId ? String(t.chuyenDeId) : null,
      bat_dau: t.batDau ? Number(t.batDau) : now,
      ket_thuc: t.ketThuc ? Number(t.ketThuc) : null,
      so_bai_lam: Number(t.soBaiLam || 0), so_bai_dung: Number(t.soBaiDung || 0),
      giay_tap_trung: t.giayTapTrung === undefined ? null : Number(t.giayTapTrung),
      ngat_quang: Number(t.ngatQuang || 0),
      ghi_chu: t.ghiChu ? String(t.ghiChu).slice(0, 500) : null,
    });
    return dap.json({ dat: true, id }, 201);
  }, 'Ghi lại một buổi học');

  them('GET', '/giam-sat/:userId', async (bc) => {
    const chan = bc.canLaChinhMinh(bc.thamSo.userId, 'roadmap.manage');
    if (chan) return chan;
    const soNgay = bc.soTu('soNgay', 30, 1, 365);
    const tu = bc.bayGio() - soNgay * 86400000;
    const b = await bc.kho.mot(
      'SELECT COUNT(*) AS soBuoi, COALESCE(SUM(so_bai_lam),0) AS lam, ' +
      'COALESCE(SUM(so_bai_dung),0) AS dung, COALESCE(SUM(ngat_quang),0) AS ngat ' +
      'FROM buoi_hoc WHERE user_id = ? AND bat_dau >= ?', [bc.thamSo.userId, tu]);
    const cb = await bc.kho.nhieu(
      'SELECT loai, muc, bang_chung_json, da_xu_ly, created_at FROM canh_bao_hoc_tap ' +
      'WHERE user_id = ? ORDER BY created_at DESC LIMIT 20', [bc.thamSo.userId]);
    const lam = Number(b.lam);
    return dap.json({
      dat: true, soNgay,
      soBuoi: Number(b.soBuoi), baiDaLam: lam, baiDung: Number(b.dung),
      tiLeDung: lam ? Number((Number(b.dung) / lam).toFixed(4)) : null,
      soLanNgatQuang: Number(b.ngat),
      canhBao: cb.map((c) => ({ loai: c.loai, muc: c.muc,
        bangChung: JSON.parse(c.bang_chung_json), daXuLy: !!c.da_xu_ly,
        luc: Number(c.created_at) })),
      duLieu: Number(b.soBuoi) > 0,
      ghiChu: Number(b.soBuoi) === 0
        ? 'Chưa có buổi học nào trong khoảng này nên chưa nói được gì về tiến bộ.' : '',
    });
  }, 'Giám sát: số thật của một người học trong khoảng ngày');

  them('POST', '/canh-bao/:userId', async (bc) => {
    const chan = bc.canQuyen('roadmap.manage');
    if (chan) return chan;
    const t = await bc.layThan();
    const loai = String(t.loai || '');
    const LOAI = ['tut-doc', 'nghi-lau', 'doan-bua', 'qua-tai', 'sai-lap-lai', 'dat-dich-som'];
    if (!LOAI.includes(loai)) {
      return dap.hong(400, 'loai-canh-bao-khong-biet',
        'Loại cảnh báo phải là một trong: ' + LOAI.join(', ') + '.');
    }
    const muc = String(t.muc || 'nhac');
    if (!['nhac', 'luu-y', 'khan'].includes(muc)) {
      return dap.hong(400, 'muc-khong-biet', 'Mức phải là nhac, luu-y hoặc khan.');
    }
    if (!t.bangChung) {
      return dap.thieu('bangChung (cảnh báo không có bằng chứng là tin đồn)');
    }
    const id = maMoi();
    await bc.kho.chen('canh_bao_hoc_tap', {
      id, user_id: bc.thamSo.userId, loai, muc,
      bang_chung_json: JSON.stringify(t.bangChung), created_at: bc.bayGio(),
    });
    return dap.json({ dat: true, id, loai, muc }, 201);
  }, 'Phát một cảnh báo học tập, bắt buộc kèm bằng chứng');
}

module.exports = { dangKy, doDieuKien, dieuKienMacDinh, DO_BANG };
