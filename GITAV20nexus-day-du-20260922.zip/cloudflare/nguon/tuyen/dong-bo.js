'use strict';
/**
 * Đồng bộ ngoại tuyến kiểu CRDT.
 *
 * Máy khách làm việc khi mất mạng, khi có mạng thì đẩy các gói thay
 * đổi lên. Máy chủ KHÔNG hợp nhất — nó chỉ giữ nhật ký nối tiếp và
 * đồng hồ vectơ; việc hợp nhất do máy khách làm, vì chỉ máy khách mới
 * hiểu cấu trúc tài liệu. Đây là điểm khiến kiến trúc này chạy được
 * trên Workers, nơi không có trạng thái sống lâu.
 *
 * Đồng hồ vectơ ở đây dùng để LỌC — máy khách nào đã có gói của chính
 * mình thì không cần nhận lại, tiết kiệm băng thông cho máy dùng 3G.
 */

const dap = require('../_lib/dap.js');
const { maMoi } = require('../_lib/ma.js');

const GOI_TOI_DA_MOI_LAN = 50;
const DAI_GOI_TOI_DA = 500000;
const DAI_ANH_CHUP_TOI_DA = 2000000;
const BAN_TOI_DA = 10;
const BAN_CON_SONG_MS = 5 * 60 * 1000;

function docDongHoVecto(x) {
  if (!x || typeof x !== 'object' || Array.isArray(x)) return null;
  const ra = {};
  for (const k of Object.keys(x)) {
    const v = x[k];
    if (!Number.isFinite(v) || v < 0) return null;
    ra[k] = Math.floor(v);
  }
  return ra;
}

function dangKy(them) {
  them('POST', '/push', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const t = await bc.layThan();
    const maTaiLieu = String(t.docId || t.maTaiLieu || '');
    if (!maTaiLieu || maTaiLieu.length > 200) return dap.thieu('maTaiLieu (1–200 ký tự)');
    const ds = Array.isArray(t.updates || t.goi) ? (t.updates || t.goi) : null;
    if (!ds) return dap.saiKieu('goi', 'một mảng');
    if (ds.length === 0) return dap.hong(400, 'goi-rong', 'Không có gói nào để đẩy.');
    if (ds.length > GOI_TOI_DA_MOI_LAN) {
      return dap.hong(400, 'qua-nhieu-goi',
        'Mỗi lần đẩy tối đa ' + GOI_TOI_DA_MOI_LAN + ' gói; chia nhỏ ra.');
    }

    const now = bc.bayGio();
    const ra = [];
    for (const g of ds) {
      const than = String(g.updateBlob || g.than || '');
      if (than.length < 4 || than.length > DAI_GOI_TOI_DA) {
        return dap.hong(400, 'goi-sai-co',
          'Mỗi gói phải dài 4–' + DAI_GOI_TOI_DA + ' ký tự.');
      }
      const dhv = docDongHoVecto(g.vectorClock || g.dongHoVecto);
      if (!dhv) return dap.saiKieu('dongHoVecto', 'một đối tượng {maMay: số nguyên ≥ 0}');
      const id = maMoi();
      await bc.kho.chen('crdt_updates', {
        id, doc_id: maTaiLieu, user_id: bc.nguoi.id,
        update_blob: than, vector_clock: JSON.stringify(dhv),
        client_ts: Number.isFinite(g.clientTs) ? Math.floor(g.clientTs) : now,
        server_ts: now, applied: 1,
      });
      ra.push({ id, serverTs: now });
    }
    return dap.json({ dat: true, daNhan: ra.length, goi: ra });
  }, 'Đẩy gói thay đổi lên');

  them('POST', '/pull', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const t = await bc.layThan();
    const maTaiLieu = String(t.docId || t.maTaiLieu || '');
    if (!maTaiLieu) return dap.thieu('maTaiLieu');
    const tuLuc = Number.isFinite(t.sinceServerTs) ? Math.floor(t.sinceServerTs) : 0;
    const dhvKhach = docDongHoVecto(t.clientVectorClock || t.dongHoVecto || {}) || {};

    const anh = await bc.kho.mot(
      'SELECT snapshot_blob, up_to_seq, created_at FROM crdt_snapshots ' +
      'WHERE doc_id = ? ORDER BY up_to_seq DESC LIMIT 1', [maTaiLieu]);

    const ds = await bc.kho.nhieu(
      'SELECT id, user_id, update_blob, vector_clock, client_ts, server_ts ' +
      'FROM crdt_updates WHERE doc_id = ? AND server_ts > ? ORDER BY server_ts ASC LIMIT 500',
      [maTaiLieu, tuLuc]);

    // Bỏ gói mà máy khách đã có: đồng hồ vectơ của nó không vượt đồng hồ khách.
    const can = ds.filter((d) => {
      let v;
      try { v = JSON.parse(d.vector_clock); } catch (e) { return true; }
      for (const k of Object.keys(v)) {
        if ((dhvKhach[k] || 0) < v[k]) return true;    // có phần khách chưa thấy
      }
      return false;
    });

    return dap.json({
      dat: true,
      maTaiLieu,
      anhChup: anh ? { than: anh.snapshot_blob, denSo: Number(anh.up_to_seq),
        luc: Number(anh.created_at) } : null,
      soGoi: can.length,
      goi: can.map((d) => ({
        id: d.id, cuaAi: d.user_id, than: d.update_blob,
        dongHoVecto: JSON.parse(d.vector_clock),
        clientTs: Number(d.client_ts), serverTs: Number(d.server_ts),
      })),
      daBoQua: ds.length - can.length,
      moc: can.length ? Number(can[can.length - 1].server_ts) : tuLuc,
    });
  }, 'Kéo gói mới về, đã lọc thứ máy khách có rồi');

  them('POST', '/snapshot', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const t = await bc.layThan();
    const maTaiLieu = String(t.docId || t.maTaiLieu || '');
    const than = String(t.snapshotBlob || t.anhChup || '');
    if (!maTaiLieu) return dap.thieu('maTaiLieu');
    if (than.length < 4 || than.length > DAI_ANH_CHUP_TOI_DA) {
      return dap.hong(400, 'anh-chup-sai-co',
        'Ảnh chụp phải dài 4–' + DAI_ANH_CHUP_TOI_DA + ' ký tự.');
    }
    // up_to_seq phải tăng đều suốt đời tài liệu. Đếm số gói CÒN LẠI thì
    // sai, vì lần chụp trước đã dọn bớt — mốc sẽ tụt về 0 và lần chụp
    // sau ghi đè lên chính nó.
    const truoc = await bc.kho.mot(
      'SELECT up_to_seq FROM crdt_snapshots WHERE doc_id = ? ORDER BY up_to_seq DESC LIMIT 1',
      [maTaiLieu]);
    const daChup = truoc ? Number(truoc.up_to_seq) : 0;
    const moc = await bc.kho.mot(
      'SELECT COUNT(*) AS so, COALESCE(MAX(server_ts), 0) AS den FROM crdt_updates WHERE doc_id = ?',
      [maTaiLieu]);
    const chuaChup = Number(moc.so);
    const denSo = daChup + chuaChup;
    if (chuaChup === 0) {
      return dap.json({ dat: true, daCo: true, denSo,
        ghiChu: 'Không có gói mới nào từ lần chụp trước, không chụp lại.' });
    }
    await bc.kho.chen('crdt_snapshots', {
      id: maMoi(), doc_id: maTaiLieu, snapshot_blob: than,
      up_to_seq: denSo, created_at: bc.bayGio(),
    });
    // Chỉ dọn đúng những gói ảnh chụp này đã gộp — gói đến sau vẫn giữ.
    const xoa = await bc.kho.chay(
      'DELETE FROM crdt_updates WHERE doc_id = ? AND server_ts <= ?',
      [maTaiLieu, Number(moc.den)]);
    return dap.json({ dat: true, denSo, goiDaGop: chuaChup,
      goiDaDon: (xoa && xoa.meta && xoa.meta.changes) || 0 });
  }, 'Chụp lại trạng thái và dọn gói cũ');

  them('POST', '/peer/register', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const t = await bc.layThan();
    const maMay = String(t.deviceId || t.maMay || '');
    if (!maMay || maMay.length > 120) return dap.thieu('maMay');
    const ds = Array.isArray(t.docIds || t.maTaiLieu) ? (t.docIds || t.maTaiLieu) : [];
    if (ds.length > BAN_TOI_DA) {
      return dap.hong(400, 'qua-nhieu-tai-lieu',
        'Một máy mở tối đa ' + BAN_TOI_DA + ' tài liệu cùng lúc.');
    }
    const now = bc.bayGio();
    await bc.kho.chay(
      'INSERT INTO sync_peers (id, user_id, device_id, doc_ids_json, last_seen_at, connection_meta, created_at) ' +
      'VALUES (?, ?, ?, ?, ?, ?, ?) ' +
      'ON CONFLICT(user_id, device_id) DO UPDATE SET ' +
      '  doc_ids_json = excluded.doc_ids_json, last_seen_at = excluded.last_seen_at, ' +
      '  connection_meta = excluded.connection_meta',
      [maMoi(), bc.nguoi.id, maMay, JSON.stringify(ds.map(String)), now,
        t.ketNoi ? String(t.ketNoi).slice(0, 4000) : null, now]);
    return dap.json({ dat: true, maMay, soTaiLieu: ds.length });
  }, 'Ghi danh một máy đang mở tài liệu');

  them('GET', '/peer/find', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const maTaiLieu = bc.url.searchParams.get('docId') || bc.url.searchParams.get('maTaiLieu');
    if (!maTaiLieu) return dap.thieu('maTaiLieu');
    const con = bc.bayGio() - BAN_CON_SONG_MS;
    const ds = await bc.kho.nhieu(
      'SELECT user_id, device_id, doc_ids_json, last_seen_at, connection_meta ' +
      'FROM sync_peers WHERE last_seen_at > ? AND user_id != ? LIMIT 100',
      [con, bc.nguoi.id]);
    const hop = ds.filter((d) => {
      try { return JSON.parse(d.doc_ids_json).includes(maTaiLieu); } catch (e) { return false; }
    });
    return dap.json({
      dat: true, maTaiLieu, soBan: hop.length,
      ban: hop.map((d) => ({ cuaAi: d.user_id, maMay: d.device_id,
        thayLuc: Number(d.last_seen_at), ketNoi: d.connection_meta })),
      ghiChu: 'Chỉ liệt kê máy còn hoạt động trong ' +
        (BAN_CON_SONG_MS / 60000) + ' phút gần nhất.',
    });
  }, 'Tìm máy khác đang mở cùng tài liệu');
}

module.exports = { dangKy };
