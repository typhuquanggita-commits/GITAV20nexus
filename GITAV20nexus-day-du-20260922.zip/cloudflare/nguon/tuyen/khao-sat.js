'use strict';
/**
 * Khảo sát, test đầu vào, hồ sơ học viên.
 *
 * Bốn bộ phiếu dùng lại nguyên vẹn của hệ Node: DISC, MBTI, tâm lý học
 * đường, phương pháp học. Không chép sang bản thứ hai — câu hỏi và cách
 * chấm chỉ có một chỗ duy nhất.
 *
 * ĐIỀU QUAN TRỌNG NHẤT Ở TỆP NÀY: mọi kết quả tâm lý đều trả kèm câu
 * nói rõ đây không phải chẩn đoán, và bộ sàng lọc tự khai điều nó KHÔNG
 * hỏi. Một bảng hỏi tự động mà trình bày như một kết luận y tế là thứ
 * gây hại thật cho một đứa trẻ — Điều 3 của hiến pháp vận hành.
 */

const dap = require('../_lib/dap.js');
const { maMoi } = require('../_lib/ma.js');
// Bảng bộ phiếu và câu cảnh báo khai ở _lib/bo-phieu.js — đúng một chỗ,
// cũng là chỗ bộ gieo dữ liệu đọc, nên hai nơi không bao giờ lệch nhau.
const { BO, CANH_BAO_CHUNG } = require('../_lib/bo-phieu.js');

/**
 * Đo độ tin: làm quá nhanh thì không đọc kịp câu hỏi.
 * Ba giây một câu là ngưỡng thấp nhất còn hợp lý cho người đọc tiếng Việt.
 */
const GIAY_MOI_CAU_TOI_THIEU = 3;

function doTinCay(soCau, giayLam, traLoi) {
  const lyDo = [];
  let diem = 1;
  if (giayLam !== null && giayLam < soCau * GIAY_MOI_CAU_TOI_THIEU) {
    diem -= 0.5;
    lyDo.push('Làm hết ' + soCau + ' câu trong ' + giayLam + ' giây — nhanh hơn mức đọc kịp.');
  }
  // Bốn bộ phiếu đều nhận mảng {so, …}; mỗi bộ đặt lựa chọn ở một khoá
  // khác nhau, nên lấy mọi khoá trừ "so" làm giá trị để đo lặp.
  const gt = Array.isArray(traLoi)
    ? traLoi.map((x) => (x && typeof x === 'object'
      ? JSON.stringify(Object.keys(x).filter((k) => k !== 'so').sort()
        .map((k) => x[k]))
      : String(x)))
    : Object.values(traLoi || {});
  if (gt.length >= 8) {
    const dem = {};
    for (const v of gt) dem[String(v)] = (dem[String(v)] || 0) + 1;
    const nhieuNhat = Math.max(...Object.values(dem));
    if (nhieuNhat / gt.length >= 0.9) {
      diem -= 0.4;
      lyDo.push('Chọn cùng một mức ở ' + nhieuNhat + '/' + gt.length + ' câu.');
    }
  }
  const thieu = soCau - gt.length;
  if (thieu > 0) {
    diem -= Math.min(0.5, thieu / soCau);
    lyDo.push('Bỏ trống ' + thieu + ' câu.');
  }
  return { diem: Number(Math.max(0, diem).toFixed(2)), lyDo };
}

function dangKy(them) {
  them('GET', '/bo-phieu', async () => dap.json({
    dat: true,
    so: Object.keys(BO).length,
    bo: Object.entries(BO).map(([ma, b]) => ({
      ma, ten: b.ten, nhom: b.nhom, soCau: b.mo.deBai().length, nguon: b.nguon,
      khongLam: b.mo.KHONG_LAM || null,
    })),
    canhBaoChung: CANH_BAO_CHUNG,
  }), 'Các bộ phiếu có thật và số câu của từng bộ');

  them('GET', '/bo-phieu/:ma', async (bc) => {
    const b = BO[bc.thamSo.ma];
    if (!b) return dap.khongThay('bộ phiếu ' + bc.thamSo.ma);
    return dap.json({
      dat: true, ma: bc.thamSo.ma, ten: b.ten, nhom: b.nhom, nguon: b.nguon,
      cau: b.mo.deBai(),
      khongLam: b.mo.KHONG_LAM || null,
      canhBao: CANH_BAO_CHUNG,
    });
  }, 'Đề một bộ phiếu');

  them('POST', '/lam/:ma', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const b = BO[bc.thamSo.ma];
    if (!b) return dap.khongThay('bộ phiếu ' + bc.thamSo.ma);
    const t = await bc.layThan();
    const traLoi = t.traLoi;
    // Cả bốn bộ phiếu của hệ Node đều nhận một MẢNG {so, …}. Nhận đối
    // tượng rồi tự đoán thứ tự là chỗ dễ chấm sai nhất, nên ở đây từ chối
    // thẳng thay vì đoán.
    if (!Array.isArray(traLoi)) {
      return dap.saiKieu('traLoi', 'một mảng, mỗi phần tử có trường "so" là số thứ tự câu');
    }
    const de = b.mo.deBai();
    if (traLoi.length > de.length) {
      return dap.hong(400, 'thua-cau',
        'Bộ này có ' + de.length + ' câu, nhận được ' + traLoi.length + ' câu trả lời.');
    }
    const soHopLe = new Set(de.map((c) => c.so));
    for (const x of traLoi) {
      if (!x || typeof x !== 'object' || !soHopLe.has(x.so)) {
        return dap.hong(400, 'so-cau-khong-co',
          'Mỗi phần tử phải có trường "so" trùng một câu trong đề.');
      }
    }
    let ketQua;
    try {
      ketQua = b.mo.cham(traLoi);
    } catch (e) {
      return dap.hong(400, 'khong-cham-duoc',
        'Bộ chấm từ chối bản trả lời này: ' + e.message);
    }
    const giay = t.giayLam === undefined ? null : Number(t.giayLam);
    const tin = doTinCay(de.length, giay, traLoi);

    const id = maMoi();
    const now = bc.bayGio();
    await bc.kho.chen('luot_khao_sat', {
      id, bo_id: bc.thamSo.ma, user_id: bc.nguoi.id,
      cho_ai: t.choAi ? String(t.choAi).slice(0, 120) : null,
      bat_dau: t.batDau ? Number(t.batDau) : now, nop_luc: now,
      tra_loi_json: JSON.stringify(traLoi),
      ket_qua_json: JSON.stringify(ketQua),
      do_tin_cay: tin.diem,
      co_the_tin: tin.diem >= 0.6 ? 1 : 0,
      vi_sao_khong_tin: tin.lyDo.length ? tin.lyDo.join(' ') : null,
      created_at: now,
    });

    // Ghi kết quả gọn vào hồ sơ để các tuyến khác dùng lại.
    if (bc.thamSo.ma === 'disc' || bc.thamSo.ma === 'mbti') {
      const gon = ketQua.ma || ketQua.kieu || ketQua.nhom || null;
      if (gon) {
        await bc.kho.chay(
          'UPDATE ho_so_hoc_vien SET ' + (bc.thamSo.ma === 'disc' ? 'disc' : 'mbti') +
          ' = ?, updated_at = ? WHERE user_id = ?', [String(gon), now, bc.nguoi.id]);
      }
    }

    return dap.json({
      dat: true, id, bo: bc.thamSo.ma, ketQua,
      doTinCay: tin.diem, coTheTin: tin.diem >= 0.6,
      viSaoKhongTin: tin.lyDo,
      canhBao: CANH_BAO_CHUNG,
      khongLam: b.mo.KHONG_LAM || null,
    }, 201);
  }, 'Làm một bộ phiếu và nhận kết quả kèm độ tin');

  them('GET', '/luot/cua-toi', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const ds = await bc.kho.nhieu(
      'SELECT id, bo_id, cho_ai, nop_luc, ket_qua_json, do_tin_cay, co_the_tin ' +
      'FROM luot_khao_sat WHERE user_id = ? ORDER BY created_at DESC LIMIT ?',
      [bc.nguoi.id, bc.soTu('soDong', 30, 1, 100)]);
    return dap.json({ dat: true, so: ds.length, luot: ds.map((d) => ({
      id: d.id, bo: d.bo_id, choAi: d.cho_ai, nopLuc: Number(d.nop_luc),
      ketQua: JSON.parse(d.ket_qua_json), doTinCay: d.do_tin_cay,
      coTheTin: !!d.co_the_tin })), canhBaoChung: CANH_BAO_CHUNG });
  }, 'Các lượt khảo sát của mình');

  them('POST', '/ho-so', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const t = await bc.layThan();
    const ten = String(t.hoTen || bc.nguoi.ten || '').trim();
    if (!ten) return dap.thieu('hoTen');
    const lop = t.lop === undefined ? null : Number(t.lop);
    if (lop !== null && (!Number.isInteger(lop) || lop < 1 || lop > 12)) {
      return dap.hong(400, 'lop-ngoai-khoang', 'Lớp là số nguyên từ 1 đến 12.');
    }
    const now = bc.bayGio();
    await bc.kho.chay(
      'INSERT INTO ho_so_hoc_vien (user_id, ho_ten, ngay_sinh, lop, truong, tinh_thanh, ' +
      '  muc_tieu_json, mon_quan_tam_json, ky_thi_dich_json, created_at, updated_at) ' +
      'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ' +
      'ON CONFLICT(user_id) DO UPDATE SET ho_ten = excluded.ho_ten, ' +
      '  ngay_sinh = excluded.ngay_sinh, lop = excluded.lop, truong = excluded.truong, ' +
      '  tinh_thanh = excluded.tinh_thanh, muc_tieu_json = excluded.muc_tieu_json, ' +
      '  mon_quan_tam_json = excluded.mon_quan_tam_json, ' +
      '  ky_thi_dich_json = excluded.ky_thi_dich_json, updated_at = excluded.updated_at',
      [bc.nguoi.id, ten, t.ngaySinh ? String(t.ngaySinh).slice(0, 10) : null, lop,
        t.truong ? String(t.truong).slice(0, 200) : null,
        t.tinhThanh ? String(t.tinhThanh).slice(0, 100) : null,
        JSON.stringify(Array.isArray(t.mucTieu) ? t.mucTieu.map(String).slice(0, 10) : []),
        JSON.stringify(Array.isArray(t.monQuanTam) ? t.monQuanTam.map(String).slice(0, 5) : []),
        JSON.stringify(Array.isArray(t.kyThiDich) ? t.kyThiDich.map(String).slice(0, 6) : []),
        now, now]);
    await bc.ghiNhatKy('khao-sat.ho-so', bc.nguoi.id, { lop });
    return dap.json({ dat: true, userId: bc.nguoi.id });
  }, 'Tạo hoặc cập nhật hồ sơ học viên');

  them('GET', '/ho-so/cua-toi', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const h = await bc.kho.mot('SELECT * FROM ho_so_hoc_vien WHERE user_id = ?', [bc.nguoi.id]);
    if (!h) {
      return dap.json({ dat: true, coHoSo: false,
        ghiChu: 'Chưa có hồ sơ. Gửi POST /api/khao-sat/ho-so để tạo.' });
    }
    return dap.json({ dat: true, coHoSo: true, hoSo: {
      hoTen: h.ho_ten, ngaySinh: h.ngay_sinh, lop: h.lop, truong: h.truong,
      tinhThanh: h.tinh_thanh, mucTieu: JSON.parse(h.muc_tieu_json),
      monQuanTam: JSON.parse(h.mon_quan_tam_json), kyThiDich: JSON.parse(h.ky_thi_dich_json),
      disc: h.disc, mbti: h.mbti, phongCachHoc: h.phong_cach_hoc } });
  }, 'Hồ sơ của mình');

  them('POST', '/test-dau-vao', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const t = await bc.layThan();
    const mon = String(t.mon || '');
    const lop = Number(t.lop);
    const m = await bc.kho.mot('SELECT id FROM mon_hoc WHERE id = ?', [mon]);
    if (!m) return dap.khongThay('môn ' + mon);
    if (!Number.isInteger(lop) || lop < 1 || lop > 12) {
      return dap.hong(400, 'lop-ngoai-khoang', 'Lớp là số nguyên từ 1 đến 12.');
    }
    const id = maMoi();
    const now = bc.bayGio();
    await bc.kho.chen('test_dau_vao', {
      id, user_id: bc.nguoi.id, mon_id: mon, lop,
      de_id: t.deId ? String(t.deId) : null,
      bat_dau: now, trang_thai: 'dang-lam', created_at: now,
    });
    return dap.json({ dat: true, id }, 201);
  }, 'Mở một bài test đầu vào');

  them('POST', '/test-dau-vao/:id/nop', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const t = await bc.layThan();
    const d = await bc.kho.mot('SELECT * FROM test_dau_vao WHERE id = ?', [bc.thamSo.id]);
    if (!d) return dap.khongThay('bài test đầu vào');
    const cuaMinh = bc.canLaChinhMinh(d.user_id, 'exam.grade');
    if (cuaMinh) return cuaMinh;
    if (d.trang_thai !== 'dang-lam') {
      return dap.hong(409, 'da-nop', 'Bài này đã ' + d.trang_thai + '.');
    }
    const diem = Number(t.diem);
    if (!(diem >= 0 && diem <= 10)) {
      return dap.hong(400, 'diem-ngoai-thang', 'Điểm từ 0 đến 10.');
    }

    // Xếp cấp theo điểm — ngưỡng khớp với điều kiện vào của từng cấp.
    // Không ai nhảy thẳng lên cấp cao chỉ vì một bài test: cao nhất mà
    // một bài đầu vào mở được là Nâng cao.
    const cap = diem >= 9 ? 'nang-cao' : 'co-ban';
    const oId = d.mon_id + '-l' + d.lop + '-' + cap;
    const co = await bc.kho.mot('SELECT id FROM o_chuong_trinh WHERE id = ?', [oId]);
    const now = bc.bayGio();

    await bc.kho.chay(
      "UPDATE test_dau_vao SET trang_thai = 'da-nop', nop_luc = ?, diem = ?, " +
      '  cap_do_de_xuat = ?, o_id_de_xuat = ?, lo_hong_json = ?, diem_manh_json = ? WHERE id = ?',
      [now, diem, cap, co ? oId : null,
        JSON.stringify(Array.isArray(t.loHong) ? t.loHong.map(String) : []),
        JSON.stringify(Array.isArray(t.diemManh) ? t.diemManh.map(String) : []), d.id]);

    return dap.json({
      dat: true, id: d.id, diem,
      capDoDeXuat: cap, oDeXuat: co ? oId : null,
      ghiChu: 'Một bài test đầu vào cao nhất chỉ mở tới cấp Nâng cao. ' +
        'Các cấp trên phải đi qua điều kiện vượt cấp — Điều 7 của hiến pháp vận hành.',
    });
  }, 'Nộp bài test đầu vào và nhận cấp độ đề xuất');
}

module.exports = { dangKy, BO, doTinCay, CANH_BAO_CHUNG };
