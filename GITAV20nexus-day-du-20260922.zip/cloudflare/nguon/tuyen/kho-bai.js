'use strict';
/**
 * Kho bài tập và chuyên đề.
 *
 * Ba luật cứng ở đây, và cả ba đều do kho dữ liệu giữ chứ không do mã
 * giữ — nên không có đường nào lách được:
 *   1. Bài trùng không vào kho: băm nội dung là chỉ mục duy nhất.
 *   2. Bài phải khai nguồn.
 *   3. Bài chưa thẩm định không xuất bản được, và không ai thẩm định
 *      bài do chính mình soạn.
 */

const dap = require('../_lib/dap.js');
const { maMoi, sha256 } = require('../_lib/ma.js');
const gieo = require('../_lib/gieo.js');

const DANG = ['trac-nghiem', 'dung-sai', 'dien-so', 'tu-luan', 'ghep-doi', 'sap-xep', 'noi-nghe', 'noi-viet'];

/** Chuẩn hoá đề trước khi băm: khoảng trắng và hoa thường không tạo ra bài mới. */
function chuanHoaDe(de) {
  return String(de).toLowerCase().replace(/\s+/g, ' ').trim();
}

function dangKy(them) {
  them('GET', '/tinh-hinh', async (bc) => {
    const chan = bc.canQuyen('bank.read');
    if (chan) return chan;
    const t = await bc.kho.mot(
      'SELECT COUNT(*) AS tong, ' +
      "  SUM(CASE WHEN trang_thai='nhap' THEN 1 ELSE 0 END) AS nhap, " +
      "  SUM(CASE WHEN trang_thai='da-soat' THEN 1 ELSE 0 END) AS soat, " +
      "  SUM(CASE WHEN trang_thai='da-xuat-ban' THEN 1 ELSE 0 END) AS xuat " +
      'FROM bai_tap');
    const cd = await bc.kho.dem('SELECT COUNT(*) FROM chuyen_de');
    const theoDang = await bc.kho.nhieu(
      'SELECT dang, COUNT(*) AS so FROM bai_tap GROUP BY dang ORDER BY so DESC');
    const theoKho = await bc.kho.nhieu(
      'SELECT do_kho, COUNT(*) AS so FROM bai_tap GROUP BY do_kho ORDER BY do_kho');
    const tong = Number(t.tong);
    return dap.json({
      dat: true,
      bai: { tong, nhap: Number(t.nhap || 0), daSoat: Number(t.soat || 0),
        daXuatBan: Number(t.xuat || 0) },
      chuyenDe: cd,
      dich: { bai: 800000, chuyenDe: 8000 },
      conThieu: { bai: Math.max(0, 800000 - tong), chuyenDe: Math.max(0, 8000 - cd) },
      theoDang: theoDang.map((x) => ({ dang: x.dang, so: Number(x.so) })),
      theoDoKho: theoKho.map((x) => ({ doKho: Number(x.do_kho), so: Number(x.so) })),
      noiThang: tong === 0
        ? 'Kho đang trống. Số 800.000 là đích của hệ thống, không phải số đang có. ' +
          'Bài vào kho bằng quy trình soạn và thẩm định, không phải bằng một lệnh sinh hàng loạt.'
        : '',
    });
  }, 'Kho có bao nhiêu bài thật, và còn thiếu bao nhiêu so với đích');

  them('POST', '/chuyen-de', async (bc) => {
    const chan = bc.canQuyen('bank.create');
    if (chan) return chan;
    const t = await bc.layThan();
    const oId = String(t.oId || '');
    const ma = String(t.ma || '').trim();
    const ten = String(t.ten || '').trim();
    if (!oId) return dap.thieu('oId');
    if (!ma) return dap.thieu('ma');
    if (!ten) return dap.thieu('ten');
    const o = await bc.kho.mot('SELECT id FROM o_chuong_trinh WHERE id = ?', [oId]);
    if (!o) return dap.khongThay('ô chương trình');
    const da = await bc.kho.mot('SELECT id FROM chuyen_de WHERE o_id = ? AND ma = ?', [oId, ma]);
    if (da) return dap.trung('Chuyên đề mã ' + ma + ' trong ô này');

    const thuTu = t.thuTu === undefined
      ? (await bc.kho.dem('SELECT COALESCE(MAX(thu_tu),0) FROM chuyen_de WHERE o_id = ?', [oId])) + 1
      : Number(t.thuTu);
    const id = maMoi();
    const now = bc.bayGio();
    await bc.kho.chen('chuyen_de', {
      id, o_id: oId, ma, ten, thu_tu: thuTu,
      tom_tat: t.tomTat ? String(t.tomTat).slice(0, 1000) : null,
      tien_quyet_json: JSON.stringify(Array.isArray(t.tienQuyet) ? t.tienQuyet.map(String) : []),
      chuan_ids_json: JSON.stringify(Array.isArray(t.chuanIds) ? t.chuanIds.map(String) : []),
      gio_du_kien: t.gioDuKien ? Number(t.gioDuKien) : null,
      trang_thai: 'nhap', nguoi_tao: bc.nguoi.id, created_at: now, updated_at: now,
    });
    await gieo.demLaiPhuSong(bc.kho, now);
    await bc.ghiNhatKy('kho-bai.chuyen-de.tao', id, { oId, ma });
    return dap.json({ dat: true, id, ma, thuTu }, 201);
  }, 'Tạo một chuyên đề');

  them('POST', '/bai', async (bc) => {
    const chan = bc.canQuyen('bank.create');
    if (chan) return chan;
    const chanHm = await bc.canHanMuc('ghi');
    if (chanHm) return chanHm;
    const t = await bc.layThan();
    const cdId = String(t.chuyenDeId || '');
    const de = String(t.deBai || '').trim();
    const nguon = String(t.nguon || '').trim();
    const dang = String(t.dang || '');
    const doKho = Number(t.doKho);

    if (!cdId) return dap.thieu('chuyenDeId');
    if (!de) return dap.thieu('deBai');
    if (!nguon) {
      return dap.hong(400, 'thieu-nguon',
        'Bài phải khai nguồn: sách nào, đề năm nào, hay do ai soạn. ' +
        'Đây là Điều 11 của hiến pháp vận hành.');
    }
    if (!DANG.includes(dang)) {
      return dap.hong(400, 'dang-khong-biet', 'Dạng phải là một trong: ' + DANG.join(', ') + '.');
    }
    if (!Number.isInteger(doKho) || doKho < 1 || doKho > 10) {
      return dap.hong(400, 'do-kho-ngoai-thang', 'Độ khó là số nguyên từ 1 đến 10.');
    }
    if (t.dapAn === undefined) return dap.thieu('dapAn');
    if (dang === 'trac-nghiem' && (!Array.isArray(t.luaChon) || t.luaChon.length < 2)) {
      return dap.hong(400, 'thieu-lua-chon', 'Bài trắc nghiệm phải có ít nhất hai lựa chọn.');
    }

    const cd = await bc.kho.mot('SELECT id, o_id FROM chuyen_de WHERE id = ?', [cdId]);
    if (!cd) return dap.khongThay('chuyên đề');

    const bam = await sha256(chuanHoaDe(de));
    const trung = await bc.kho.mot(
      'SELECT id, ma FROM bai_tap WHERE bam_noi_dung = ?', [bam]);
    if (trung) {
      return dap.hong(409, 'bai-trung',
        'Đề bài này đã có trong kho với mã ' + trung.ma + '. Kho không nhận bài trùng.',
        { baiDaCo: trung.id });
    }

    const id = maMoi();
    const ma = 'bt-' + bam.slice(0, 10);
    const now = bc.bayGio();
    await bc.kho.chen('bai_tap', {
      id, chuyen_de_id: cdId, o_id: cd.o_id, ma, dang, do_kho: doKho,
      de_bai: de,
      lua_chon_json: t.luaChon ? JSON.stringify(t.luaChon) : null,
      dap_an_json: JSON.stringify(t.dapAn),
      loi_giai: t.loiGiai ? String(t.loiGiai) : null,
      chuan_ids_json: JSON.stringify(Array.isArray(t.chuanIds) ? t.chuanIds.map(String) : []),
      nguon, bam_noi_dung: bam, trang_thai: 'nhap',
      nguoi_tao: bc.nguoi.id, created_at: now, updated_at: now,
    });
    await bc.kho.chen('bai_tap_lich_su', {
      id: maMoi(), bai_id: id, viec: 'tao', nguoi: bc.nguoi.id,
      sau_json: JSON.stringify({ dang, doKho, nguon }), at: now,
    });
    await bc.kho.chay('UPDATE chuyen_de SET so_bai = so_bai + 1, updated_at = ? WHERE id = ?',
      [now, cdId]);
    await gieo.demLaiPhuSong(bc.kho, now);
    return dap.json({ dat: true, id, ma,
      canThamDinh: 'Bài đang ở trạng thái nhap. Phải có người khác thẩm định mới xuất bản được.' },
      201);
  }, 'Thêm một bài tập, chặn trùng bằng băm nội dung');

  them('GET', '/bai', async (bc) => {
    const chan = bc.canQuyen('bank.read');
    if (chan) return chan;
    const dk = [], tham = [];
    for (const [q, cot] of [['oId', 'o_id'], ['chuyenDeId', 'chuyen_de_id'],
      ['dang', 'dang'], ['trangThai', 'trang_thai']]) {
      const v = bc.url.searchParams.get(q);
      if (v) { dk.push(cot + ' = ?'); tham.push(v); }
    }
    const kho = bc.soTu('doKho', 0, 0, 10);
    if (kho) { dk.push('do_kho = ?'); tham.push(kho); }
    const where = dk.length ? ' WHERE ' + dk.join(' AND ') : '';
    const ds = await bc.kho.nhieu(
      'SELECT id, ma, chuyen_de_id, o_id, dang, do_kho, de_bai, nguon, trang_thai, ' +
      '       diem_chat_luong, so_lan_dung, ti_le_dung FROM bai_tap' + where +
      ' ORDER BY created_at DESC LIMIT ? OFFSET ?',
      tham.concat([bc.soTu('soDong', 20, 1, 100), bc.soTu('boQua', 0, 0)]));
    const tong = await bc.kho.dem('SELECT COUNT(*) FROM bai_tap' + where, tham);
    return dap.json({ dat: true, tong, so: ds.length, bai: ds.map((d) => ({
      id: d.id, ma: d.ma, chuyenDeId: d.chuyen_de_id, o: d.o_id, dang: d.dang,
      doKho: Number(d.do_kho), deBai: d.de_bai, nguon: d.nguon, trangThai: d.trang_thai,
      diemChatLuong: d.diem_chat_luong, soLanDung: Number(d.so_lan_dung),
      tiLeDung: d.ti_le_dung })) });
  }, 'Tìm bài trong kho');

  them('GET', '/bai/:id', async (bc) => {
    const chan = bc.canQuyen('bank.read');
    if (chan) return chan;
    const b = await bc.kho.mot('SELECT * FROM bai_tap WHERE id = ?', [bc.thamSo.id]);
    if (!b) return dap.khongThay('bài tập');
    const hienDapAn = bc.canQuyen('bank.review') === null;
    return dap.json({
      dat: true,
      bai: {
        id: b.id, ma: b.ma, dang: b.dang, doKho: Number(b.do_kho), deBai: b.de_bai,
        luaChon: b.lua_chon_json ? JSON.parse(b.lua_chon_json) : null,
        nguon: b.nguon, trangThai: b.trang_thai, kyHieuChuan: b.ky_hieu_chuan,
        chuanIds: JSON.parse(b.chuan_ids_json),
        // Đáp án và lời giải chỉ hiện với người có quyền soát — học viên
        // đọc được đáp án thì mọi số liệu về tỉ lệ đúng thành vô nghĩa.
        dapAn: hienDapAn ? JSON.parse(b.dap_an_json) : undefined,
        loiGiai: hienDapAn ? b.loi_giai : undefined,
      },
      anDapAn: !hienDapAn,
    });
  }, 'Xem một bài; đáp án chỉ hiện với người có quyền soát');

  them('POST', '/bai/:id/tham-dinh', async (bc) => {
    const chan = bc.canQuyen('bank.review');
    if (chan) return chan;
    const t = await bc.layThan();
    const b = await bc.kho.mot('SELECT * FROM bai_tap WHERE id = ?', [bc.thamSo.id]);
    if (!b) return dap.khongThay('bài tập');
    if (b.nguoi_tao === bc.nguoi.id) {
      return dap.hong(403, 'tu-tham-dinh',
        'Không ai thẩm định bài do chính mình soạn. Chuyển cho người khác trong ban.');
    }
    const quyet = String(t.quyet || '');
    if (!['dat', 'tra-lai'].includes(quyet)) {
      return dap.hong(400, 'quyet-khong-biet', 'Quyết định phải là dat hoặc tra-lai.');
    }
    const diem = t.diem === undefined ? null : Number(t.diem);
    if (diem !== null && (!(diem >= 0) || diem > 10)) {
      return dap.hong(400, 'diem-ngoai-thang', 'Điểm chất lượng từ 0 đến 10.');
    }
    if (quyet === 'tra-lai' && !String(t.lyDo || '').trim()) {
      return dap.thieu('lyDo (trả lại bài phải nói vì sao)');
    }
    const now = bc.bayGio();
    const moi = quyet === 'dat' ? 'da-soat' : 'nhap';
    await bc.kho.chay(
      'UPDATE bai_tap SET trang_thai = ?, diem_chat_luong = ?, nguoi_soat = ?, updated_at = ? ' +
      'WHERE id = ?', [moi, diem, bc.nguoi.id, now, b.id]);
    await bc.kho.chen('bai_tap_lich_su', {
      id: maMoi(), bai_id: b.id, viec: 'soat', nguoi: bc.nguoi.id,
      truoc_json: JSON.stringify({ trangThai: b.trang_thai }),
      sau_json: JSON.stringify({ trangThai: moi, diem }),
      ly_do: t.lyDo ? String(t.lyDo).slice(0, 1000) : null, at: now,
    });
    await bc.ghiNhatKy('kho-bai.tham-dinh', b.id, { quyet, diem });
    return dap.json({ dat: true, id: b.id, trangThai: moi });
  }, 'Thẩm định một bài; cấm tự thẩm định bài mình soạn');

  them('POST', '/bai/:id/xuat-ban', async (bc) => {
    const chan = bc.canQuyen('bank.publish');
    if (chan) return chan;
    const b = await bc.kho.mot('SELECT * FROM bai_tap WHERE id = ?', [bc.thamSo.id]);
    if (!b) return dap.khongThay('bài tập');
    if (b.trang_thai !== 'da-soat') {
      return dap.hong(409, 'chua-tham-dinh',
        'Bài đang ở trạng thái ' + b.trang_thai + '. Chỉ bài đã thẩm định mới xuất bản được.');
    }
    const now = bc.bayGio();
    await bc.kho.chay("UPDATE bai_tap SET trang_thai = 'da-xuat-ban', updated_at = ? WHERE id = ?",
      [now, b.id]);
    await bc.kho.chen('bai_tap_lich_su', {
      id: maMoi(), bai_id: b.id, viec: 'xuat-ban', nguoi: bc.nguoi.id, at: now });
    await gieo.demLaiPhuSong(bc.kho, now);
    await bc.ghiNhatKy('kho-bai.xuat-ban', b.id, null);
    return dap.json({ dat: true, id: b.id, trangThai: 'da-xuat-ban' });
  }, 'Xuất bản một bài đã thẩm định');

  them('GET', '/bai/:id/lich-su', async (bc) => {
    const chan = bc.canQuyen('bank.read');
    if (chan) return chan;
    const ds = await bc.kho.nhieu(
      // Hai việc trong cùng một mili giây vẫn phải ra đúng thứ tự đã xảy
      // ra, nên xếp thêm theo rowid — thứ tự ghi vào bảng.
      'SELECT viec, nguoi, ly_do, at FROM bai_tap_lich_su WHERE bai_id = ? ' +
      'ORDER BY at ASC, rowid ASC',
      [bc.thamSo.id]);
    return dap.json({ dat: true, so: ds.length, lichSu: ds.map((d) => ({
      viec: d.viec, nguoi: d.nguoi, lyDo: d.ly_do, luc: Number(d.at) })) });
  }, 'Lịch sử một bài: ai làm gì, lúc nào');
}

module.exports = { dangKy };
