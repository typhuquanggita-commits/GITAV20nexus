'use strict';
/**
 * BẢNG QUẢN TRỊ TỔNG — một cửa nhìn toàn hệ.
 *
 * Đường /api/tong gom mọi mặt của hệ thống vào một câu trả lời, để
 * giao diện tổng chỉ gọi MỘT lượt thay vì mười lăm lượt. Với D1 ở bậc
 * miễn phí thì khác biệt ấy là thật, không phải làm đẹp.
 *
 * LUẬT CỦA TRANG NÀY: mỗi ô đều nói rõ dữ liệu có hay không. Ô rỗng
 * hiện chữ "chưa có", không hiện số không — vì số không trông giống
 * một phép đo, còn "chưa có" thì không.
 */

const dap = require('../_lib/dap.js');
const baoMat = require('../_lib/bao-mat.js');
const boNao = require('../_lib/bo-nao-trung-tam.js');
const congAi = require('../_lib/cong-ai.js');
const hienPhap = require('../_lib/hien-phap.js');
const tc = require('../_lib/to-chuc.js');
const nhatKy = require('../_lib/nhat-ky.js');
const { KhoNghia } = require('../_lib/kho-nghia.js');

const DICH_BAI = 800000;
const DICH_CHUYEN_DE = 8000;

/** Một ô của bảng. Không có dữ liệu thì nói là chưa có. */
function o(nhan, so, y, coDuLieu) {
  return { nhan, so: coDuLieu === false ? null : so, y,
    coDuLieu: coDuLieu !== false };
}

function dangKy(them) {
  them('GET', '/', async (bc) => {
    const chan = bc.canQuyen('audit.read');
    if (chan) return chan;
    const now = bc.bayGio();
    const gio = bc.soTu('soGio', 24, 1, 720);

    // ── Học thuật ──
    const ct = await bc.kho.mot(
      'SELECT COUNT(*) AS soO, COALESCE(SUM(so_chuyen_de),0) AS cd, ' +
      'COALESCE(SUM(so_bai),0) AS bai FROM o_chuong_trinh');
    const baiXuat = await bc.kho.dem('SELECT COALESCE(SUM(so_bai_xuat),0) FROM phu_song');
    const soHocVien = await bc.kho.dem("SELECT COUNT(*) FROM users WHERE role = 'LEARNER'");
    const soLuotThi = await bc.kho.dem('SELECT COUNT(*) FROM luot_thi');

    // ── Bộ máy ──
    const soTroLy = await bc.kho.dem('SELECT COUNT(*) FROM tro_ly');
    const soCrm = await bc.kho.dem('SELECT COUNT(*) FROM crm_tro_ly');
    const kpi = await bc.kho.mot(
      'SELECT COALESCE(SUM(viec_nhan),0) AS nhan, COALESCE(SUM(viec_xong),0) AS xong ' +
      'FROM kpi_tro_ly WHERE ngay >= ?',
      [new Date(now - 7 * 86400000).toISOString().slice(0, 10)]);

    // ── Bộ não và bảo mật ──
    const nao = await boNao.tinhHinh(bc.kho, now, gio);
    const dangChan = await bc.kho.dem(
      'SELECT COUNT(*) FROM danh_sach_chan WHERE chan_den IS NULL OR chan_den > ?', [now]);

    // ── Quan hệ gia đình ──
    const gd = await bc.kho.mot(
      'SELECT COUNT(*) AS tong, ' +
      "SUM(CASE WHEN chang = 'dang-hoc' THEN 1 ELSE 0 END) AS dangHoc FROM gia_dinh");
    const viecCho = await bc.kho.dem(
      "SELECT COUNT(*) FROM crm_viec WHERE trang_thai IN ('cho','cho-nguoi-duyet')");

    // ── Tài chính ──
    const ctTc = await bc.kho.mot(
      'SELECT COUNT(*) AS tong, ' +
      "SUM(CASE WHEN trang_thai = 'nhap' THEN 1 ELSE 0 END) AS nhap, " +
      "SUM(CASE WHEN trang_thai = 'da-ghi-so' THEN 1 ELSE 0 END) AS ghiSo FROM chung_tu");
    const conThu = await bc.kho.dem(
      'SELECT COALESCE(SUM(so_tien - da_thu),0) FROM hoc_phi ' +
      "WHERE trang_thai IN ('cho-thu','thu-mot-phan')");

    // ── Ba thứ luôn phải soi ──
    const chuoi = await nhatKy.soiChuoi(bc.kho);
    const ai = await congAi.tinhHinh(bc.kho, bc.moi, now);
    const dem = await KhoNghia(bc.kho, bc.moi.KV, bc.bayGio).tinhHinh();
    const viPham = await bc.kho.dem(
      'SELECT COUNT(*) FROM vi_pham_hien_phap WHERE at > ?', [now - gio * 3600000]);

    const canChuY = [];
    if (!chuoi.lanh) {
      canChuY.push({ muc: 'khan', viec: 'Nhật ký kiểm toán đứt chuỗi ở dòng ' + chuoi.tai
        + ': ' + chuoi.loi });
    }
    if (ai.tongConLai === 0) {
      canChuY.push({ muc: 'khan',
        viec: 'Không nhà cung cấp AI nào còn gọi được. Mọi tuyến cần AI đang trả lỗi.' });
    } else if (ai.nha.filter((n) => n.coKhoa && n.conLai > 0).length === 1) {
      canChuY.push({ muc: 'luu-y',
        viec: 'Chỉ còn một nhà cung cấp AI. Nhà ấy hỏng là mất hẳn phần AI.' });
    }
    if (Number(ctTc.nhap) > 0) {
      canChuY.push({ muc: 'luu-y',
        viec: Number(ctTc.nhap) + ' chứng từ kế toán chưa ghi sổ.' });
    }
    if (viecCho > 0) {
      canChuY.push({ muc: 'nhac', viec: viecCho + ' việc quan hệ gia đình đang chờ.' });
    }
    if (nao.thanhTraGiuLai > 0) {
      canChuY.push({ muc: 'khan',
        viec: nao.thanhTraGiuLai + ' câu trả lời bị thanh tra giữ lại trong ' + gio + ' giờ qua.' });
    }
    if (viPham > 0) {
      canChuY.push({ muc: 'khan', viec: viPham + ' vi phạm hiến pháp trong ' + gio + ' giờ qua.' });
    }

    const tongBai = Number(ct.bai);
    return dap.json({
      dat: true,
      luc: now,
      soGio: gio,

      hocThuat: {
        o: [
          o('Ô chương trình', Number(ct.soO), 'Ba môn × mười hai lớp × bảy cấp độ'),
          o('Chuyên đề', Number(ct.cd), 'Đích ' + DICH_CHUYEN_DE.toLocaleString('vi-VN'),
            Number(ct.cd) > 0),
          o('Bài trong kho', tongBai, 'Đích ' + DICH_BAI.toLocaleString('vi-VN'), tongBai > 0),
          o('Bài đã xuất bản', baiXuat, 'Đã qua thẩm định', baiXuat > 0),
          o('Học viên', soHocVien, 'Tài khoản vai học viên', soHocVien > 0),
          o('Lượt thi', soLuotThi, 'Đã mở, đã nộp hoặc quá hạn', soLuotThi > 0),
        ],
        noiThang: tongBai === 0
          ? 'Kho bài đang trống. Hai con số đích ở trên là ĐÍCH của hệ thống, '
            + 'không phải số đang có.'
          : 'Mới đạt ' + (tongBai / DICH_BAI * 100).toFixed(3) + '% của đích về số bài.',
      },

      boMay: {
        o: [
          o('Trợ lý chuyên môn', soTroLy, tc.BAN.length + ' ban, bảy vai'),
          o('Trợ lý quan hệ gia đình', soCrm, 'Năm tổ, tách hẳn khỏi bộ máy chuyên môn'),
          o('Việc nhận bảy ngày', Number(kpi.nhan), '', Number(kpi.nhan) > 0),
          o('Việc xong bảy ngày', Number(kpi.xong), '', Number(kpi.xong) > 0),
        ],
        tiLeXong: Number(kpi.nhan)
          ? Number((Number(kpi.xong) / Number(kpi.nhan)).toFixed(4)) : null,
      },

      boNao: {
        o: [
          o('Lệnh đi qua', nao.tongLenh, 'Trong ' + gio + ' giờ', nao.coDuLieu),
          o('Chặn bởi lớp canh', nao.chanBoiBaoMat, '', nao.coDuLieu),
          o('Chặn bởi hiến pháp', nao.chanBoiHienPhap, '', nao.coDuLieu),
          o('Thanh tra giữ lại', nao.thanhTraGiuLai, 'Câu trả lời không cho rời hệ thống',
            nao.coDuLieu),
          o('Mili giây trung bình', nao.msTrungBinh, '', nao.msTrungBinh !== null),
        ],
        theoLoai: nao.theoLoai,
        chanTheoLop: nao.chanTheoLop,
        ghiChu: nao.ghiChu,
      },

      baoMat: {
        lop: baoMat.banLop(),
        dangChan: dangChan,
        viPhamHienPhap: viPham,
      },

      quanHeGiaDinh: {
        o: [
          o('Gia đình', Number(gd.tong), '', Number(gd.tong) > 0),
          o('Đang học', Number(gd.dangHoc || 0), '', Number(gd.tong) > 0),
          o('Việc đang chờ', viecCho, 'Gồm cả việc chờ người duyệt', true),
        ],
        cayTien: 'Không hiện ở bảng này. Xem riêng ở /api/crm/cay-tien, cần quyền riêng, '
          + 'và mỗi lượt xem đều bị ghi lại — Điều 8.',
      },

      taiChinh: {
        o: [
          o('Chứng từ', Number(ctTc.tong), '', Number(ctTc.tong) > 0),
          o('Chưa ghi sổ', Number(ctTc.nhap || 0), 'Cần người khác ghi sổ', Number(ctTc.tong) > 0),
          o('Đã ghi sổ', Number(ctTc.ghiSo || 0), '', Number(ctTc.tong) > 0),
          o('Còn phải thu', conThu, 'Đơn vị: đồng', conThu > 0),
        ],
      },

      nenTang: {
        nhatKyKiemToan: { lanh: chuoi.lanh, soDong: chuoi.soDong || 0,
          loi: chuoi.lanh ? null : chuoi.loi,
          khongChungMinh: chuoi.khongChungMinh || null },
        congAi: { soNhaCoKhoa: ai.nha.filter((n) => n.coKhoa).length,
          tongLuotConLai: ai.tongConLai, theoNha: ai.nha },
        khoDem: dem,
        hienPhap: { soDieu: hienPhap.DIEU.length },
      },

      canChuY,
      tinhTrangChung: canChuY.some((x) => x.muc === 'khan') ? 'can-xu-ly-ngay'
        : (canChuY.length ? 'co-viec-cho' : 'binh-thuong'),
    });
  }, 'Bảng quản trị tổng — một cửa nhìn toàn hệ');

  them('GET', '/crm', async (bc) => {
    const chan = bc.canQuyen('crm.read');
    if (chan) return chan;
    const now = bc.bayGio();
    const pheu = await bc.kho.nhieu(
      'SELECT chang, COUNT(*) AS so FROM gia_dinh GROUP BY chang');
    const theoTo = await bc.kho.nhieu(
      'SELECT c.to_id, COUNT(DISTINCT c.id) AS nguoi, ' +
      "  COUNT(CASE WHEN v.trang_thai IN ('cho','dang-lam') THEN 1 END) AS viecDangLam " +
      'FROM crm_tro_ly c LEFT JOIN crm_viec v ON v.tro_ly_id = c.id GROUP BY c.to_id');
    const choNguoi = await bc.kho.nhieu(
      "SELECT loai, COUNT(*) AS so FROM crm_viec WHERE trang_thai = 'cho-nguoi-duyet' " +
      'GROUP BY loai');
    const tuongTac7n = await bc.kho.dem(
      'SELECT COUNT(*) FROM crm_tuong_tac WHERE at > ?', [now - 7 * 86400000]);
    return dap.json({
      dat: true,
      pheu: pheu.map((p) => ({ chang: p.chang, so: Number(p.so) })),
      theoTo: theoTo.map((t) => ({ to: t.to_id, soNguoi: Number(t.nguoi),
        viecDangLam: Number(t.viecDangLam) })),
      choNguoiDuyet: choNguoi.map((c) => ({ loai: c.loai, so: Number(c.so) })),
      tuongTacBayNgay: tuongTac7n,
      luuY: 'Việc nhắc học phí và xử lý phàn nàn không bao giờ tự gửi đi — '
        + 'chúng dừng ở chờ người duyệt.',
    });
  }, 'Bảng quản trị nhỏ của quan hệ gia đình');

  them('GET', '/tai-chinh', async (bc) => {
    const chan = bc.canQuyen('ketoan.read');
    if (chan) return chan;
    const ky = bc.url.searchParams.get('ky')
      || new Date(bc.bayGio()).toISOString().slice(0, 7);
    const cd = await bc.kho.mot(
      'SELECT COALESCE(SUM(CASE WHEN b.tk_no IS NOT NULL THEN b.so_tien ELSE 0 END),0) AS no, ' +
      '       COALESCE(SUM(CASE WHEN b.tk_co IS NOT NULL THEN b.so_tien ELSE 0 END),0) AS co ' +
      'FROM but_toan b JOIN chung_tu c ON c.id = b.chung_tu_id ' +
      "WHERE c.ky_id = ? AND c.trang_thai = 'da-ghi-so'", [ky]);
    const theoLoai = await bc.kho.nhieu(
      'SELECT loai, COUNT(*) AS so, COALESCE(SUM(tong_tien),0) AS tien FROM chung_tu ' +
      "WHERE ky_id = ? AND trang_thai = 'da-ghi-so' GROUP BY loai", [ky]);
    const k = await bc.kho.mot('SELECT trang_thai FROM ky_ke_toan WHERE id = ?', [ky]);
    const chuaGhi = await bc.kho.dem(
      "SELECT COUNT(*) FROM chung_tu WHERE ky_id = ? AND trang_thai IN ('nhap','cho-duyet')",
      [ky]);
    const no = Number(cd.no), co = Number(cd.co);
    return dap.json({
      dat: true, ky,
      trangThaiKy: k ? k.trang_thai : 'chua-mo',
      tongPhatSinhNo: no, tongPhatSinhCo: co,
      canDoi: no === co,
      lech: no - co,
      chungTuChuaGhiSo: chuaGhi,
      theoLoai: theoLoai.map((t) => ({ loai: t.loai, so: Number(t.so), tien: Number(t.tien) })),
      khoaDuocKhong: no === co && chuaGhi === 0,
      viSaoChuaKhoaDuoc: no !== co
        ? 'Kỳ đang lệch ' + Math.abs(no - co) + ' đồng.'
        : (chuaGhi > 0 ? 'Còn ' + chuaGhi + ' chứng từ chưa ghi sổ.' : null),
    });
  }, 'Bảng quản trị nhỏ của tài chính kế toán');
}

module.exports = { dangKy };
