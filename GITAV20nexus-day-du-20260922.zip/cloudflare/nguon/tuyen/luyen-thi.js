'use strict';
/**
 * Luyện thi và tổ chức thi: HSA · TSA · SPT · IELTS · SAT · TOEIC.
 *
 * Cấu trúc sáu hệ chuẩn dùng lại NGUYÊN VẸN bảng ở src/matran/chuan.js —
 * bảng ấy chép từ tài liệu gốc và có kiểm thử giữ. Ở đây không có bản
 * sao thứ hai của số câu hay số phút, nên không thể có hai con số cùng
 * tự nhận là cấu trúc của HSA.
 *
 * Đề dựng xong mang một mã băm của chính danh sách câu. Sửa lén một câu
 * trong đề đã mở là băm lệch, và bài nộp không chấm được — đúng như thế
 * là an toàn, vì chấm một đề đã bị sửa còn tệ hơn không chấm.
 */

const dap = require('../_lib/dap.js');
const { maMoi, sha256 } = require('../_lib/ma.js');
const chuan = require('../../../src/matran/chuan.js');

const PHUT_MAC_DINH = 60;

function heChuan(id) {
  return chuan.CHUAN_INDEX.get(id) || null;
}

/** Nấc 1–10 của một hệ chuẩn theo điểm quy đổi. */
function nacTheoDiem(heId, diem) {
  const h = heChuan(heId);
  if (!h) return null;
  for (let i = 0; i < h.nac.length; i++) {
    const [a, b] = h.nac[i];
    if (diem >= a && diem <= b) return i + 1;
  }
  return diem < h.nac[0][0] ? 1 : h.nac.length;
}

function dangKy(them) {
  them('GET', '/he-chuan', async () => dap.json({
    dat: true,
    so: chuan.CHUAN.length,
    he: chuan.CHUAN.map((c) => {
      const t = chuan.tongCua(c.id);
      return {
        ma: c.id, ten: c.ten, ngan: c.ngan, thang: c.thang,
        monChinh: c.monChinh,
        tongCauKhai: c.tongCau, tongPhutKhai: c.tongPhut,
        tongCauThat: t.cau, tongPhutThat: t.phut,
        khopCau: t.khopCau, khopPhut: t.khopPhut,
        phan: c.phan,
        nac: c.nac,
      };
    }),
    tenNac: chuan.TEN_NAC,
    ghiChu: 'khopCau và khopPhut so tổng đã khai với tổng cộng lại từ các phần. ' +
      'Lệch nghĩa là dữ liệu đặc tả có mâu thuẫn — phải sửa nguồn, không phải sửa phép quy đổi.',
  }), 'Cấu trúc thật của sáu hệ chuẩn');

  them('GET', '/he-chuan/:id', async (bc) => {
    const h = heChuan(bc.thamSo.id);
    if (!h) return dap.khongThay('hệ chuẩn ' + bc.thamSo.id);
    const k = await bc.kho.mot('SELECT * FROM ky_thi WHERE id = ?', [h.id]);
    const soDe = await bc.kho.dem('SELECT COUNT(*) FROM de_thi WHERE ky_thi_id = ?', [h.id]);
    return dap.json({
      dat: true,
      ma: h.id, ten: h.ten, ngan: h.ngan, thang: h.thang, phan: h.phan,
      nac: h.nac.map((n, i) => ({ nac: i + 1, ten: chuan.TEN_NAC[i], tu: n[0], den: n[1] })),
      coQuan: k ? k.co_quan : null, ghiChu: k ? k.ghi_chu : null,
      soDeDaDung: soDe,
    });
  }, 'Chi tiết một hệ chuẩn và mười nấc của nó');

  them('POST', '/de', async (bc) => {
    const chan = bc.canQuyen('exam.build');
    if (chan) return chan;
    const t = await bc.layThan();
    const heId = String(t.kyThi || '');
    const h = heChuan(heId);
    if (!h) return dap.khongThay('hệ chuẩn ' + heId);
    const loai = String(t.loai || 'thu');
    if (!['thu', 'chinh-thuc', 'chan-doan', 'theo-phan'].includes(loai)) {
      return dap.hong(400, 'loai-de-khong-biet', 'Loại đề phải là thu, chinh-thuc, chan-doan hoặc theo-phan.');
    }
    const cau = Array.isArray(t.cauIds) ? t.cauIds.map(String) : null;
    if (!cau || cau.length === 0) return dap.thieu('cauIds');
    if (new Set(cau).size !== cau.length) {
      return dap.hong(400, 'cau-lap-trong-de', 'Một đề không được chứa cùng một câu hai lần.');
    }

    // Câu phải có thật và phải đã xuất bản — đề thi không dùng bài nháp.
    const co = await bc.kho.nhieu(
      'SELECT id, trang_thai FROM bai_tap WHERE id IN (' + cau.map(() => '?').join(',') + ')', cau);
    if (co.length !== cau.length) {
      const coSet = new Set(co.map((x) => x.id));
      return dap.hong(400, 'cau-khong-ton-tai',
        'Có câu không có trong kho: ' + cau.filter((x) => !coSet.has(x)).slice(0, 5).join(', ') + '.');
    }
    const chuaXuat = co.filter((x) => x.trang_thai !== 'da-xuat-ban');
    if (chuaXuat.length && loai === 'chinh-thuc') {
      return dap.hong(409, 'cau-chua-xuat-ban',
        'Đề chính thức chỉ dùng câu đã xuất bản. Còn ' + chuaXuat.length + ' câu chưa xuất bản.');
    }

    const soPhut = t.soPhut === undefined
      ? (Array.isArray(h.tongPhut) ? h.tongPhut[0] : h.tongPhut || PHUT_MAC_DINH)
      : Number(t.soPhut);
    const id = maMoi();
    const now = bc.bayGio();
    const bam = await sha256(cau.join('|'));
    await bc.kho.chen('de_thi', {
      id, ky_thi_id: heId, ten: String(t.ten || (h.ngan + ' — đề ' + loai)),
      loai, cau_ids_json: JSON.stringify(cau), so_cau: cau.length, so_phut: soPhut,
      cau_truc_json: JSON.stringify({ phan: h.phan, thang: h.thang, chupLuc: now }),
      bam_de: bam, trang_thai: 'nhap', nguoi_tao: bc.nguoi.id,
      created_at: now, updated_at: now,
    });
    await bc.ghiNhatKy('luyen-thi.dung-de', id, { heId, loai, soCau: cau.length });
    return dap.json({ dat: true, id, soCau: cau.length, soPhut, bamDe: bam }, 201);
  }, 'Dựng một đề từ câu trong kho');

  them('POST', '/de/:id/mo', async (bc) => {
    const chan = bc.canQuyen('exam.build');
    if (chan) return chan;
    const d = await bc.kho.mot('SELECT * FROM de_thi WHERE id = ?', [bc.thamSo.id]);
    if (!d) return dap.khongThay('đề thi');
    const cau = JSON.parse(d.cau_ids_json);
    const bamLai = await sha256(cau.join('|'));
    if (bamLai !== d.bam_de) {
      return dap.hong(409, 'de-da-bi-sua',
        'Danh sách câu của đề này không khớp mã băm lúc dựng. Đề đã bị sửa; không mở được.');
    }
    const now = bc.bayGio();
    await bc.kho.chay("UPDATE de_thi SET trang_thai = 'mo', mo_luc = ?, updated_at = ? WHERE id = ?",
      [now, now, d.id]);
    await bc.ghiNhatKy('luyen-thi.mo-de', d.id, null);
    return dap.json({ dat: true, id: d.id, trangThai: 'mo' });
  }, 'Mở một đề cho thí sinh vào làm');

  them('POST', '/thi/bat-dau', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const t = await bc.layThan();
    const d = await bc.kho.mot('SELECT * FROM de_thi WHERE id = ?', [String(t.deId || '')]);
    if (!d) return dap.khongThay('đề thi');
    if (d.trang_thai !== 'mo') {
      return dap.hong(409, 'de-chua-mo', 'Đề đang ở trạng thái ' + d.trang_thai + '.');
    }
    const dangLam = await bc.kho.mot(
      "SELECT id FROM luot_thi WHERE de_id = ? AND user_id = ? AND trang_thai = 'dang-lam'",
      [d.id, bc.nguoi.id]);
    if (dangLam) {
      return dap.hong(409, 'dang-lam-do',
        'Bạn đang có một lượt chưa nộp trên đề này.', { luotId: dangLam.id });
    }
    const id = maMoi();
    const now = bc.bayGio();
    await bc.kho.chen('luot_thi', {
      id, de_id: d.id, user_id: bc.nguoi.id, bat_dau: now,
      han_nop: now + Number(d.so_phut) * 60000, trang_thai: 'dang-lam', created_at: now,
    });
    return dap.json({ dat: true, luotId: id, soCau: Number(d.so_cau),
      soPhut: Number(d.so_phut), hanNop: now + Number(d.so_phut) * 60000,
      cauIds: JSON.parse(d.cau_ids_json) }, 201);
  }, 'Bắt đầu một lượt thi');

  them('POST', '/thi/:id/tra-loi', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const t = await bc.layThan();
    const l = await bc.kho.mot('SELECT * FROM luot_thi WHERE id = ?', [bc.thamSo.id]);
    if (!l) return dap.khongThay('lượt thi');
    const cuaMinh = bc.canLaChinhMinh(l.user_id);
    if (cuaMinh) return cuaMinh;
    if (l.trang_thai !== 'dang-lam') {
      return dap.hong(409, 'luot-da-dong', 'Lượt này đã ' + l.trang_thai + '.');
    }
    const now = bc.bayGio();
    if (now > Number(l.han_nop)) {
      await bc.kho.chay("UPDATE luot_thi SET trang_thai = 'qua-han' WHERE id = ?", [l.id]);
      return dap.hong(409, 'qua-han', 'Đã quá hạn nộp. Lượt này không nhận thêm câu trả lời.');
    }
    const thuTu = Number(t.thuTu);
    if (!Number.isInteger(thuTu) || thuTu < 1) return dap.saiKieu('thuTu', 'số nguyên từ 1');
    const d = await bc.kho.mot('SELECT cau_ids_json FROM de_thi WHERE id = ?', [l.de_id]);
    const cau = JSON.parse(d.cau_ids_json);
    if (thuTu > cau.length) {
      return dap.hong(400, 'thu-tu-ngoai-de', 'Đề chỉ có ' + cau.length + ' câu.');
    }
    const da = await bc.kho.mot(
      'SELECT id, doi_dap_an FROM luot_thi_tra_loi WHERE luot_id = ? AND thu_tu = ?',
      [l.id, thuTu]);
    if (da) {
      await bc.kho.chay(
        'UPDATE luot_thi_tra_loi SET tra_loi_json = ?, doi_dap_an = doi_dap_an + 1, at = ? ' +
        'WHERE id = ?', [JSON.stringify(t.traLoi), now, da.id]);
      return dap.json({ dat: true, thuTu, daDoi: Number(da.doi_dap_an) + 1 });
    }
    await bc.kho.chen('luot_thi_tra_loi', {
      id: maMoi(), luot_id: l.id, bai_id: cau[thuTu - 1], thu_tu: thuTu,
      tra_loi_json: JSON.stringify(t.traLoi),
      giay_lam: t.giayLam === undefined ? null : Number(t.giayLam), at: now,
    });
    return dap.json({ dat: true, thuTu, daDoi: 0 });
  }, 'Ghi câu trả lời cho một câu');

  them('POST', '/thi/:id/nop', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const l = await bc.kho.mot('SELECT * FROM luot_thi WHERE id = ?', [bc.thamSo.id]);
    if (!l) return dap.khongThay('lượt thi');
    const cuaMinh = bc.canLaChinhMinh(l.user_id, 'exam.grade');
    if (cuaMinh) return cuaMinh;
    if (l.trang_thai === 'da-nop') {
      return dap.hong(409, 'da-nop', 'Lượt này đã nộp rồi.', { diem: l.diem_quy_doi });
    }
    const d = await bc.kho.mot('SELECT * FROM de_thi WHERE id = ?', [l.de_id]);
    const cau = JSON.parse(d.cau_ids_json);
    const bamLai = await sha256(cau.join('|'));
    if (bamLai !== d.bam_de) {
      return dap.hong(409, 'de-da-bi-sua',
        'Đề đã bị sửa sau khi mở. Không chấm lượt này — chấm một đề đã bị sửa còn tệ hơn không chấm.');
    }

    const traLoi = await bc.kho.nhieu(
      'SELECT * FROM luot_thi_tra_loi WHERE luot_id = ? ORDER BY thu_tu', [l.id]);
    const bai = cau.length
      ? await bc.kho.nhieu(
        'SELECT id, dap_an_json, dang FROM bai_tap WHERE id IN (' +
        cau.map(() => '?').join(',') + ')', cau)
      : [];
    const bang = new Map(bai.map((b) => [b.id, b]));

    let dung = 0, chamDuoc = 0, canNguoiCham = 0;
    for (const tl of traLoi) {
      const b = bang.get(tl.bai_id);
      if (!b) continue;
      if (b.dang === 'tu-luan' || b.dang === 'noi-viet') { canNguoiCham++; continue; }
      let dapAn;
      try { dapAn = JSON.parse(b.dap_an_json); } catch (e) { continue; }
      let cua;
      try { cua = JSON.parse(tl.tra_loi_json); } catch (e) { cua = null; }
      const ok = JSON.stringify(dapAn) === JSON.stringify(cua);
      chamDuoc++;
      if (ok) dung++;
      await bc.kho.chay('UPDATE luot_thi_tra_loi SET dung = ?, diem = ? WHERE id = ?',
        [ok ? 1 : 0, ok ? 1 : 0, tl.id]);
    }

    const h = heChuan(l.de_id ? d.ky_thi_id : null);
    const tiLe = chamDuoc ? dung / chamDuoc : 0;
    const thang = h ? h.thang : [0, 10];
    const quyDoi = Number((thang[0] + (thang[1] - thang[0]) * tiLe).toFixed(2));
    const nac = h ? nacTheoDiem(h.id, quyDoi) : null;
    const now = bc.bayGio();

    await bc.kho.chay(
      "UPDATE luot_thi SET trang_thai = 'da-nop', nop_luc = ?, diem_tho = ?, " +
      '  diem_quy_doi = ?, nac = ?, chi_tiet_json = ? WHERE id = ?',
      [now, dung, quyDoi, nac,
        JSON.stringify({ soCau: cau.length, daTraLoi: traLoi.length, chamMay: chamDuoc,
          dung, canNguoiCham }), l.id]);
    for (const b of bai) {
      await bc.kho.chay(
        'UPDATE bai_tap SET so_lan_dung = so_lan_dung + 1 WHERE id = ?', [b.id]);
    }

    return dap.json({
      dat: true, luotId: l.id,
      soCau: cau.length, daTraLoi: traLoi.length,
      mayChamDuoc: chamDuoc, dung, tiLeDung: Number(tiLe.toFixed(4)),
      diemQuyDoi: quyDoi, thang, nac,
      tenNac: nac ? chuan.TEN_NAC[nac - 1] : null,
      canNguoiCham,
      ghiChu: canNguoiCham > 0
        ? 'Còn ' + canNguoiCham + ' câu tự luận phải người chấm. Điểm trên chỉ tính phần máy chấm được.'
        : '',
    });
  }, 'Nộp bài và chấm phần máy chấm được');

  them('GET', '/thi/:id', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const l = await bc.kho.mot('SELECT * FROM luot_thi WHERE id = ?', [bc.thamSo.id]);
    if (!l) return dap.khongThay('lượt thi');
    const cuaMinh = bc.canLaChinhMinh(l.user_id, 'exam.grade');
    if (cuaMinh) return cuaMinh;
    return dap.json({ dat: true, luot: {
      id: l.id, deId: l.de_id, batDau: Number(l.bat_dau), hanNop: Number(l.han_nop),
      nopLuc: l.nop_luc ? Number(l.nop_luc) : null, trangThai: l.trang_thai,
      diemQuyDoi: l.diem_quy_doi, nac: l.nac,
      chiTiet: l.chi_tiet_json ? JSON.parse(l.chi_tiet_json) : null } });
  }, 'Xem một lượt thi');

  them('POST', '/lo-trinh', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const t = await bc.layThan();
    const heId = String(t.kyThi || '');
    const h = heChuan(heId);
    if (!h) return dap.khongThay('hệ chuẩn ' + heId);
    const dich = Number(t.diemDich);
    if (!(dich > h.thang[0] && dich <= h.thang[1])) {
      return dap.hong(400, 'diem-dich-ngoai-thang',
        'Điểm đích phải nằm trong thang ' + h.thang[0] + '–' + h.thang[1] + '.');
    }
    const dau = t.diemDau === undefined ? null : Number(t.diemDau);
    const nacDau = dau === null ? 0 : nacTheoDiem(heId, dau);
    const nacDich = nacTheoDiem(heId, dich);
    if (nacDich <= nacDau) {
      return dap.hong(400, 'dich-khong-cao-hon',
        'Điểm đích đang ở cùng nấc với điểm hiện tại. Đặt đích cao hơn ít nhất một nấc.');
    }

    const now = bc.bayGio();
    const id = maMoi();
    await bc.kho.chay(
      'INSERT INTO lo_trinh_thi (id, user_id, ky_thi_id, diem_dau, diem_dich, han_dich, ' +
      "  nac_hien_tai, trang_thai, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'dang-chay', ?, ?) " +
      'ON CONFLICT(user_id, ky_thi_id) DO UPDATE SET diem_dau = excluded.diem_dau, ' +
      '  diem_dich = excluded.diem_dich, han_dich = excluded.han_dich, updated_at = excluded.updated_at',
      [id, bc.nguoi.id, heId, dau, dich, t.hanDich ? Number(t.hanDich) : null,
        Math.max(1, nacDau), now, now]);
    const lt = await bc.kho.mot(
      'SELECT id FROM lo_trinh_thi WHERE user_id = ? AND ky_thi_id = ?', [bc.nguoi.id, heId]);

    // Mỗi nấc một chặng, từ nấc hiện tại tới nấc đích. Không bỏ nấc nào.
    const chang = [];
    for (let n = Math.max(1, nacDau) + (nacDau ? 1 : 0); n <= nacDich; n++) {
      const [a, b] = h.nac[n - 1];
      const cid = maMoi();
      await bc.kho.chay(
        'INSERT INTO lo_trinh_chang (id, lo_trinh_id, nac, ten, muc_tieu, dieu_kien_json, trang_thai) ' +
        'VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT(lo_trinh_id, nac) DO NOTHING',
        [cid, lt.id, n, 'Nấc ' + n + ' — ' + chuan.TEN_NAC[n - 1],
          'Đạt từ ' + a + ' điểm trong một lượt thi thử đầy đủ.',
          JSON.stringify([{ do_bang: 'diem-kiem-tra', nguong: a, tren_mau: 1 }]),
          n === Math.max(1, nacDau) + (nacDau ? 1 : 0) ? 'dang-hoc' : 'chua-mo']);
      chang.push({ nac: n, ten: chuan.TEN_NAC[n - 1], tu: a, den: b });
    }
    return dap.json({ dat: true, loTrinhId: lt.id, nacDau: Math.max(1, nacDau),
      nacDich, soChang: chang.length, chang }, 201);
  }, 'Lập lộ trình luyện thi từ nấc hiện tại tới nấc đích');

  them('GET', '/lo-trinh/cua-toi', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const ds = await bc.kho.nhieu(
      'SELECT * FROM lo_trinh_thi WHERE user_id = ? ORDER BY updated_at DESC', [bc.nguoi.id]);
    const ra = [];
    for (const l of ds) {
      const c = await bc.kho.nhieu(
        'SELECT nac, ten, muc_tieu, trang_thai, so_lan_kiem FROM lo_trinh_chang ' +
        'WHERE lo_trinh_id = ? ORDER BY nac', [l.id]);
      ra.push({
        id: l.id, kyThi: l.ky_thi_id, diemDau: l.diem_dau, diemDich: l.diem_dich,
        nacHienTai: Number(l.nac_hien_tai), trangThai: l.trang_thai,
        chang: c.map((x) => ({ nac: Number(x.nac), ten: x.ten, mucTieu: x.muc_tieu,
          trangThai: x.trang_thai, soLanKiem: Number(x.so_lan_kiem) })),
      });
    }
    return dap.json({ dat: true, so: ra.length, loTrinh: ra });
  }, 'Lộ trình luyện thi của mình');
}

module.exports = { dangKy, nacTheoDiem };
