'use strict';
/**
 * Chương trình học: ba môn, mười hai lớp, bảy cấp độ.
 *
 * Mọi con số về "kho có bao nhiêu" trên các đường này đều đọc từ bảng
 * phu_song, tức là đếm lại từ kho thật. Không đường nào trả về một con
 * số do người khai.
 */

const dap = require('../_lib/dap.js');
const bg = require('../_lib/bang-goc.js');
const gieo = require('../_lib/gieo.js');
const { maMoi } = require('../_lib/ma.js');

const DICH_CHUYEN_DE = 8000;
const DICH_BAI = 800000;

function dangKy(them) {
  them('GET', '/', async (bc) => {
    const o = await bc.kho.mot(
      'SELECT COUNT(*) AS so, COALESCE(SUM(so_chuyen_de),0) AS cd, ' +
      'COALESCE(SUM(so_bai),0) AS bai FROM o_chuong_trinh');
    const xuat = await bc.kho.dem(
      "SELECT COALESCE(SUM(so_bai_xuat),0) FROM phu_song");
    const cd = Number(o.cd), bai = Number(o.bai);
    return dap.json({
      dat: true,
      mon: bg.MON_HOC.map((m) => ({ ma: m.id, ten: m.ten, tenEn: m.ten_en, moTa: m.mo_ta })),
      capDo: bg.CAP_DO.map((c) => ({ ma: c.id, ten: c.ten, thuTu: c.thu_tu,
        dichDen: c.dich_den, dieuKienVao: c.dieu_kien_vao })),
      lop: Array.from({ length: 12 }, (_, i) => i + 1),
      soO: Number(o.so),
      kho: {
        chuyenDeDaCo: cd, chuyenDeDich: DICH_CHUYEN_DE,
        baiDaCo: bai, baiDaXuatBan: xuat, baiDich: DICH_BAI,
        phanTramChuyenDe: Number((cd / DICH_CHUYEN_DE * 100).toFixed(2)),
        phanTramBai: Number((bai / DICH_BAI * 100).toFixed(2)),
      },
      noiThang: bai === 0
        ? 'Khung chương trình đã dựng đủ, nhưng kho bài còn trống. Con số 800.000 là ĐÍCH, ' +
          'không phải số hiện có — và trang này đếm lại từ kho nên không nói khác được.'
        : 'Các con số trên đếm trực tiếp từ kho, không lấy từ chỗ khai tay.',
    });
  }, 'Tổng quan chương trình và mức phủ thật của kho');

  them('GET', '/o', async (bc) => {
    const mon = bc.url.searchParams.get('mon');
    const lop = bc.soTu('lop', 0, 0, 12);
    const cap = bc.url.searchParams.get('capDo');
    const dk = [], tham = [];
    if (mon) { dk.push('o.mon_id = ?'); tham.push(mon); }
    if (lop) { dk.push('o.lop = ?'); tham.push(lop); }
    if (cap) { dk.push('o.cap_do_id = ?'); tham.push(cap); }
    const where = dk.length ? ' WHERE ' + dk.join(' AND ') : '';
    const ds = await bc.kho.nhieu(
      'SELECT o.*, p.so_bai_nhap, p.so_bai_soat, p.so_bai_xuat, p.so_chuan, p.so_chuan_co_bai ' +
      'FROM o_chuong_trinh o LEFT JOIN phu_song p ON p.o_id = o.id' + where +
      ' ORDER BY o.mon_id, o.lop, o.cap_do_id LIMIT ?',
      tham.concat([bc.soTu('soDong', 100, 1, 300)]));
    return dap.json({ dat: true, so: ds.length, o: ds.map((d) => ({
      ma: d.id, mon: d.mon_id, lop: d.lop, capDo: d.cap_do_id, moTa: d.mo_ta,
      soChuyenDe: Number(d.so_chuyen_de),
      bai: { nhap: Number(d.so_bai_nhap || 0), daSoat: Number(d.so_bai_soat || 0),
        daXuatBan: Number(d.so_bai_xuat || 0) },
      chuan: { tong: Number(d.so_chuan || 0), coBai: Number(d.so_chuan_co_bai || 0) },
    })) });
  }, 'Danh sách ô chương trình, lọc theo môn, lớp, cấp độ');

  them('GET', '/o/:id', async (bc) => {
    const o = await bc.kho.mot('SELECT * FROM o_chuong_trinh WHERE id = ?', [bc.thamSo.id]);
    if (!o) return dap.khongThay('ô chương trình');
    const cd = await bc.kho.nhieu(
      'SELECT id, ma, ten, thu_tu, tom_tat, so_bai, trang_thai FROM chuyen_de ' +
      'WHERE o_id = ? ORDER BY thu_tu', [o.id]);
    const ch = await bc.kho.nhieu(
      'SELECT id, ma, yeu_cau, nguon_chuan, trich_dan, bac_nhan_thuc FROM chuan_kien_thuc ' +
      'WHERE o_id = ? ORDER BY ma', [o.id]);
    const dk = await bc.kho.nhieu(
      'SELECT ma, mo_ta, do_bang, nguong, tren_mau, bat_buoc FROM dieu_kien_vuot WHERE o_id = ?',
      [o.id]);
    const capDo = bg.CAP_DO.find((c) => c.id === o.cap_do_id);
    return dap.json({
      dat: true,
      o: { ma: o.id, mon: o.mon_id, lop: o.lop, capDo: o.cap_do_id, moTa: o.mo_ta },
      dichDen: capDo ? capDo.dich_den : null,
      dieuKienVaoCap: capDo ? capDo.dieu_kien_vao : null,
      chuyenDe: cd.map((x) => ({ ma: x.ma, ten: x.ten, thuTu: x.thu_tu,
        tomTat: x.tom_tat, soBai: Number(x.so_bai), trangThai: x.trang_thai })),
      chuanKienThuc: ch.map((x) => ({ ma: x.ma, yeuCau: x.yeu_cau,
        nguon: x.nguon_chuan, trichDan: x.trich_dan, bac: x.bac_nhan_thuc })),
      dieuKienVuot: dk.map((x) => ({ ma: x.ma, moTa: x.mo_ta, doBang: x.do_bang,
        nguong: x.nguong, trenMau: x.tren_mau, batBuoc: !!x.bat_buoc })),
      trong: cd.length === 0 && ch.length === 0,
    });
  }, 'Chi tiết một ô: chuyên đề, chuẩn kiến thức, điều kiện vượt');

  them('POST', '/chuan', async (bc) => {
    const chan = bc.canQuyen('curriculum.write');
    if (chan) return chan;
    const t = await bc.layThan();
    const oId = String(t.oId || '');
    const nguon = String(t.nguon || '');
    if (!['moet', 'us', 'toan'].includes(nguon)) {
      return dap.hong(400, 'nguon-chuan-khong-hop-le',
        'Nguồn chuẩn phải là moet, us hoặc toan. Chuẩn do mô hình ngôn ngữ tự sinh ' +
        'không được vào bảng này — đây là Điều 6 của hiến pháp vận hành.');
    }
    if (!String(t.trichDan || '').trim()) {
      return dap.thieu('trichDan (tên văn bản và mục cụ thể)');
    }
    const o = await bc.kho.mot('SELECT id FROM o_chuong_trinh WHERE id = ?', [oId]);
    if (!o) return dap.khongThay('ô chương trình');
    const bac = String(t.bac || 'hieu');
    if (!['nho', 'hieu', 'van-dung', 'phan-tich', 'danh-gia', 'sang-tao'].includes(bac)) {
      return dap.hong(400, 'bac-khong-biet', 'Bậc nhận thức không nằm trong thang đã khai.');
    }
    const ma = String(t.ma || '').trim();
    if (!ma) return dap.thieu('ma');
    const da = await bc.kho.mot('SELECT id FROM chuan_kien_thuc WHERE o_id = ? AND ma = ?', [oId, ma]);
    if (da) return dap.trung('Mã chuẩn ' + ma + ' trong ô này');
    const id = maMoi();
    await bc.kho.chen('chuan_kien_thuc', {
      id, o_id: oId, ma, yeu_cau: String(t.yeuCau || '').slice(0, 2000),
      nguon_chuan: nguon, trich_dan: String(t.trichDan).slice(0, 500),
      bac_nhan_thuc: bac, created_at: bc.bayGio(),
    });
    await gieo.demLaiPhuSong(bc.kho, bc.bayGio());
    await bc.ghiNhatKy('chuong-trinh.them-chuan', id, { oId, ma, nguon });
    return dap.json({ dat: true, id, ma }, 201);
  }, 'Thêm một chuẩn kiến thức, bắt buộc có nguồn');

  them('POST', '/gieo', async (bc) => {
    const chan = bc.canQuyen('curriculum.write');
    if (chan) return chan;
    const d = await gieo.gieo(bc.kho, bc.bayGio());
    await bc.ghiNhatKy('chuong-trinh.gieo', null, d);
    return dap.json({ dat: true, daGieo: d,
      ghiChu: 'Gieo chỉ dựng khung. Nó không tạo ra bài tập, chuyên đề hay học viên nào.' });
  }, 'Gieo lại dữ liệu nền, chạy bao nhiêu lần cũng ra một kết quả');

  them('POST', '/dem-lai', async (bc) => {
    const chan = bc.canQuyen('curriculum.read');
    if (chan) return chan;
    const so = await gieo.demLaiPhuSong(bc.kho, bc.bayGio());
    return dap.json({ dat: true, soODaDem: so });
  }, 'Đếm lại phủ sóng từ kho thật');
}

module.exports = { dangKy };
