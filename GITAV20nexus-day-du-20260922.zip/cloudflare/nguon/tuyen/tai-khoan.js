'use strict';
/**
 * Đăng ký, đăng nhập, đăng xuất, đổi mật khẩu, quản lý tài khoản.
 *
 * Hai chỗ cố ý làm chậm và cố ý mơ hồ:
 *  - Đăng nhập sai: luôn trả cùng một câu, dù sai thư điện tử hay sai
 *    mật khẩu. Nói rõ cái nào sai là tặng cho người dò một nửa đáp án.
 *  - Vẫn băm mật khẩu cả khi không tìm thấy tài khoản, để thời gian
 *    trả lời hai trường hợp không lệch nhau.
 */

const dap = require('../_lib/dap.js');
const phien = require('../_lib/phien.js');
const quyen = require('../_lib/quyen.js');
const { maMoi } = require('../_lib/ma.js');

const BAM_GIA = '210000$00000000000000000000000000000000$' + '0'.repeat(64);

function chuanEmail(x) {
  return String(x || '').trim().toLowerCase();
}
function emailHopLe(x) {
  return /^[^@\s]+@[^@\s.]+(\.[^@\s.]+)+$/.test(x) && x.length <= 254;
}

function dangKy(them) {
  them('POST', '/api/tai-khoan/dang-ky', async (bc) => {
    const chanHm = await bc.canHanMuc('ghi');
    if (chanHm) return chanHm;
    const t = await bc.layThan();
    const email = chuanEmail(t.email);
    const ten = String(t.ten || t.hoTen || '').trim();
    const matKhau = String(t.matKhau || '');
    if (!email) return dap.thieu('email');
    if (!emailHopLe(email)) return dap.hong(400, 'email-sai', 'Thư điện tử không đúng dạng.');
    if (!ten) return dap.thieu('ten');
    if (ten.length > 120) return dap.hong(400, 'ten-qua-dai', 'Tên không quá 120 ký tự.');

    // Người tự đăng ký luôn là học viên. Vai cao hơn do quản trị cấp.
    const vai = 'LEARNER';
    const che = phien.soiMatKhau(matKhau, vai);
    if (che.length) {
      return dap.hong(400, 'mat-khau-yeu', 'Mật khẩu ' + che.join('; ') + '.', { che });
    }

    const da = await bc.kho.mot('SELECT id FROM users WHERE email = ?', [email]);
    if (da) return dap.trung('Thư điện tử này');

    const now = bc.bayGio();
    const id = maMoi();
    await bc.kho.chen('users', {
      id, email, password_hash: await phien.bamMatKhau(matKhau),
      full_name: ten, role: vai, phone: t.dienThoai ? String(t.dienThoai).slice(0, 30) : null,
      status: 'ACTIVE', locale: 'vi', created_at: now, updated_at: now,
    });
    await bc.ghiNhatKy('tai-khoan.dang-ky', id, { email, vai });
    return dap.json({ dat: true, id, email, ten, vai }, 201);
  }, 'Tự đăng ký tài khoản học viên');

  them('POST', '/api/tai-khoan/dang-nhap', async (bc) => {
    const chanHm = await bc.canHanMuc('dang-nhap');
    if (chanHm) return chanHm;
    const t = await bc.layThan();
    const email = chuanEmail(t.email);
    const matKhau = String(t.matKhau || '');
    if (!email || !matKhau) return dap.thieu('email và matKhau');

    const u = await bc.kho.mot('SELECT * FROM users WHERE email = ?', [email]);
    // Băm cả khi không có tài khoản: giữ thời gian trả lời đều nhau.
    const dung = await phien.kiemMatKhau(matKhau, u ? u.password_hash : BAM_GIA);
    if (!u || !dung) {
      await bc.ghiNhatKy('tai-khoan.dang-nhap-hong', email, null);
      return dap.hong(401, 'sai-thong-tin', 'Thư điện tử hoặc mật khẩu không đúng.');
    }
    if (u.status !== 'ACTIVE') {
      return dap.hong(403, 'tai-khoan-khoa', 'Tài khoản đang bị khoá.');
    }

    const p = await phien.moPhien(bc.kho, u, bc.req.headers.get('user-agent'), bc.bayGio());
    await bc.ghiNhatKy('tai-khoan.dang-nhap', u.id, { vai: u.role });
    return dap.json(
      { dat: true, the: p.the, hetLuc: p.hetLuc,
        toi: { id: u.id, email: u.email, ten: u.full_name, vai: u.role } },
      200, { 'Set-Cookie': phien.banhQuy(p.the, p.hanMs) });
  }, 'Đăng nhập, nhận thẻ phiên');

  them('POST', '/api/tai-khoan/dang-xuat', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    await phien.dongPhien(bc.kho, bc.nguoi.phien, bc.bayGio());
    await bc.ghiNhatKy('tai-khoan.dang-xuat', bc.nguoi.id, null);
    return dap.json({ dat: true }, 200, { 'Set-Cookie': phien.banhQuyXoa() });
  }, 'Đóng phiên hiện tại');

  them('GET', '/api/tai-khoan/toi', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const u = await bc.kho.mot(
      'SELECT id, email, full_name, role, phone, status, locale, created_at, last_login_at ' +
      'FROM users WHERE id = ?', [bc.nguoi.id]);
    return dap.json({
      dat: true,
      toi: { id: u.id, email: u.email, ten: u.full_name, vai: u.role, dienThoai: u.phone,
        tinhTrang: u.status, tao: u.created_at, dangNhapCuoi: u.last_login_at },
      quyen: quyen.QUYEN[u.role] || [],
      hetLuc: bc.nguoi.hetLuc,
    });
  }, 'Hồ sơ tài khoản đang đăng nhập');

  them('POST', '/api/tai-khoan/doi-mat-khau', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const t = await bc.layThan();
    const cu = String(t.matKhauCu || '');
    const moi = String(t.matKhauMoi || '');
    if (!cu || !moi) return dap.thieu('matKhauCu và matKhauMoi');
    const u = await bc.kho.mot('SELECT password_hash, role FROM users WHERE id = ?', [bc.nguoi.id]);
    if (!await phien.kiemMatKhau(cu, u.password_hash)) {
      return dap.hong(401, 'sai-mat-khau-cu', 'Mật khẩu hiện tại không đúng.');
    }
    if (cu === moi) {
      return dap.hong(400, 'trung-mat-khau-cu', 'Mật khẩu mới phải khác mật khẩu cũ.');
    }
    const che = phien.soiMatKhau(moi, u.role);
    if (che.length) return dap.hong(400, 'mat-khau-yeu', 'Mật khẩu ' + che.join('; ') + '.', { che });

    await bc.kho.chay('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?',
      [await phien.bamMatKhau(moi), bc.bayGio(), bc.nguoi.id]);
    // Đổi mật khẩu thì mọi phiên khác phải chết, kể cả phiên kẻ trộm đang mở.
    await phien.dongHetPhienCua(bc.kho, bc.nguoi.id, bc.bayGio());
    await bc.ghiNhatKy('tai-khoan.doi-mat-khau', bc.nguoi.id, null);
    return dap.json({ dat: true, ghiChu: 'Mọi phiên đã đăng xuất, kể cả phiên này. Đăng nhập lại.' },
      200, { 'Set-Cookie': phien.banhQuyXoa() });
  }, 'Đổi mật khẩu và đóng mọi phiên');

  them('GET', '/api/tai-khoan', async (bc) => {
    const chan = bc.canQuyen('user.read');
    if (chan) return chan;
    const soDong = bc.soTu('soDong', 20, 1, 100);
    const boQua = bc.soTu('boQua', 0, 0);
    const ds = await bc.kho.nhieu(
      'SELECT id, email, full_name, role, status, created_at, last_login_at FROM users ' +
      'ORDER BY created_at DESC LIMIT ? OFFSET ?', [soDong, boQua]);
    const tong = await bc.kho.dem('SELECT COUNT(*) FROM users');
    return dap.json({ dat: true, tong, soDong, boQua, danhSach: ds });
  }, 'Danh sách tài khoản');

  them('POST', '/api/tai-khoan/:id/vai', async (bc) => {
    const chan = bc.canQuyen('user.update');
    if (chan) return chan;
    const t = await bc.layThan();
    const vaiMoi = String(t.vai || '');
    if (!quyen.VAI[vaiMoi]) {
      return dap.hong(400, 'vai-khong-biet',
        'Vai phải là một trong: ' + Object.keys(quyen.VAI).join(', ') + '.');
    }
    const u = await bc.kho.mot('SELECT id, role FROM users WHERE id = ?', [bc.thamSo.id]);
    if (!u) return dap.khongThay('tài khoản');
    if (u.id === bc.nguoi.id) {
      return dap.hong(400, 'tu-doi-vai-minh', 'Không tự đổi vai của chính mình được.');
    }
    // Không ai nâng người khác lên cao hơn hoặc ngang chính mình.
    if (!quyen.caoHon(bc.nguoi.vai, vaiMoi)) {
      return dap.hong(403, 'vuot-bac',
        'Chỉ cấp được vai thấp hơn vai của mình (' + bc.nguoi.vai + ').');
    }
    if (!quyen.caoHon(bc.nguoi.vai, u.role)) {
      return dap.hong(403, 'vuot-bac', 'Không đổi được vai của người ngang hoặc cao hơn mình.');
    }
    await bc.kho.chay('UPDATE users SET role = ?, updated_at = ? WHERE id = ?',
      [vaiMoi, bc.bayGio(), u.id]);
    await phien.dongHetPhienCua(bc.kho, u.id, bc.bayGio());
    await bc.ghiNhatKy('tai-khoan.doi-vai', u.id, { tu: u.role, sang: vaiMoi });
    return dap.json({ dat: true, id: u.id, vai: vaiMoi,
      ghiChu: 'Đã đóng mọi phiên của tài khoản ấy để quyền mới có hiệu lực ngay.' });
  }, 'Đổi vai của một tài khoản');

  them('POST', '/api/tai-khoan/:id/khoa', async (bc) => {
    const chan = bc.canQuyen('user.disable');
    if (chan) return chan;
    const u = await bc.kho.mot('SELECT id, role, status FROM users WHERE id = ?', [bc.thamSo.id]);
    if (!u) return dap.khongThay('tài khoản');
    if (u.id === bc.nguoi.id) {
      return dap.hong(400, 'tu-khoa-minh', 'Không tự khoá tài khoản của mình được.');
    }
    if (!quyen.caoHon(bc.nguoi.vai, u.role)) {
      return dap.hong(403, 'vuot-bac', 'Không khoá được người ngang hoặc cao hơn mình.');
    }
    const t = await bc.layThan();
    const moi = t.mo ? 'ACTIVE' : 'DISABLED';
    await bc.kho.chay('UPDATE users SET status = ?, updated_at = ? WHERE id = ?',
      [moi, bc.bayGio(), u.id]);
    if (moi === 'DISABLED') await phien.dongHetPhienCua(bc.kho, u.id, bc.bayGio());
    await bc.ghiNhatKy('tai-khoan.' + (moi === 'ACTIVE' ? 'mo-khoa' : 'khoa'), u.id, null);
    return dap.json({ dat: true, id: u.id, tinhTrang: moi });
  }, 'Khoá hoặc mở khoá tài khoản');
}

module.exports = { dangKy };
