'use strict';
/**
 * Quan hệ gia đình — 50 trợ lý chuyên trách.
 *
 * CÂY TIỀN. Hệ thống có phân loại nội bộ về khả năng chi trả để điều
 * phối nguồn lực. Cột cay_tien_nhom nằm ở bảng gia_dinh, và ở tệp này
 * nó CHỈ đi ra qua một đường duy nhất — /cay-tien — mà đường ấy đòi
 * quyền 'cay-tien.admin'. Mọi đường còn lại đều bỏ cột ấy ra khỏi câu
 * trả lời, kể cả đường xem chi tiết một gia đình.
 *
 * Đây là Điều 8 của hiến pháp vận hành, và nó được giữ ở ba chỗ độc
 * lập: bảng phân quyền, từng đường ở đây, và lớp canh đường ra.
 */

const dap = require('../_lib/dap.js');
const { maMoi } = require('../_lib/ma.js');
const tc = require('../_lib/to-chuc.js');

const CHANG = ['moi', 'da-lien-he', 'da-tu-van', 'da-test', 'dang-hoc', 'tam-dung', 'roi-di'];
const LOAI_VIEC = ['goi-dien', 'nhan-tin', 'tu-van', 'xep-lich-test', 'bao-ket-qua',
  'nhac-hoc-phi', 'cham-soc', 'xu-ly-phan-nan'];

/** Việc nhắc tiền luôn phải qua người — mức tự chủ 0 của tổ Công nợ. */
const VIEC_CAN_NGUOI = ['nhac-hoc-phi', 'xu-ly-phan-nan'];

function gonGiaDinh(d) {
  // Cố ý KHÔNG trả cay_tien_nhom. Bỏ sót ở đây là lộ ra ngoài.
  return {
    id: d.id, tenLienHe: d.ten_lien_he, dienThoai: d.dien_thoai, email: d.email,
    tinhThanh: d.tinh_thanh, nguonDen: d.nguon_den, chang: d.chang,
    troLy: d.tro_ly_id, ghiChu: d.ghi_chu,
    capNhat: Number(d.updated_at),
  };
}

function dangKy(them) {
  them('GET', '/', async (bc) => {
    const chan = bc.canQuyen('crm.read');
    if (chan) return chan;
    const theoChang = await bc.kho.nhieu(
      'SELECT chang, COUNT(*) AS so FROM gia_dinh GROUP BY chang');
    const theoTo = await bc.kho.nhieu(
      'SELECT to_id, COUNT(*) AS so FROM crm_tro_ly GROUP BY to_id');
    const viec = await bc.kho.mot(
      "SELECT COUNT(*) AS tong, SUM(CASE WHEN trang_thai='cho' THEN 1 ELSE 0 END) AS cho, " +
      "SUM(CASE WHEN trang_thai='cho-nguoi-duyet' THEN 1 ELSE 0 END) AS choNguoi FROM crm_viec");
    const bangChang = Object.fromEntries(theoChang.map((x) => [x.chang, Number(x.so)]));
    return dap.json({
      dat: true,
      soTroLy: await bc.kho.dem('SELECT COUNT(*) FROM crm_tro_ly'),
      to: tc.TO_CRM.map((t) => ({ ma: t.id, ten: t.ten, soKhai: t.so,
        soThucTe: Number((theoTo.find((x) => x.to_id === t.id) || {}).so || 0), viec: t.viec })),
      pheu: CHANG.map((c) => ({ chang: c, so: bangChang[c] || 0 })),
      viec: { tong: Number(viec.tong), dangCho: Number(viec.cho || 0),
        choNguoiDuyet: Number(viec.choNguoi || 0) },
      cayTien: 'Không hiện ở đây. Xem GET /api/crm/cay-tien, cần quyền riêng.',
    });
  }, 'Tổng quan CRM: phễu, tổ, hàng việc');

  them('POST', '/gia-dinh', async (bc) => {
    const chan = bc.canQuyen('crm.write');
    if (chan) return chan;
    const t = await bc.layThan();
    const ten = String(t.tenLienHe || '').trim();
    if (!ten) return dap.thieu('tenLienHe');
    if (!t.dienThoai && !t.email) {
      return dap.hong(400, 'thieu-duong-lien-he',
        'Phải có ít nhất một đường liên hệ: dienThoai hoặc email.');
    }
    // Chọn người tiếp nhận: trong tổ tiếp nhận, ai đang giữ ít gia đình nhất.
    const ds = await bc.kho.nhieu(
      'SELECT c.id, c.suc_chua_ngay, COUNT(g.id) AS dang_giu FROM crm_tro_ly c ' +
      'LEFT JOIN gia_dinh g ON g.tro_ly_id = c.id ' +
      "WHERE c.to_id = 'tiep-nhan' AND c.trang_thai != 'tam-nghi' " +
      'GROUP BY c.id ORDER BY dang_giu ASC, c.id ASC LIMIT 1');
    const id = maMoi();
    const now = bc.bayGio();
    await bc.kho.chen('gia_dinh', {
      id, ten_lien_he: ten,
      dien_thoai: t.dienThoai ? String(t.dienThoai).slice(0, 30) : null,
      email: t.email ? String(t.email).toLowerCase().slice(0, 254) : null,
      tinh_thanh: t.tinhThanh ? String(t.tinhThanh).slice(0, 100) : null,
      nguon_den: t.nguonDen ? String(t.nguonDen).slice(0, 100) : null,
      chang: 'moi', tro_ly_id: ds.length ? ds[0].id : null,
      created_at: now, updated_at: now,
    });
    await bc.ghiNhatKy('crm.tao-gia-dinh', id, { chang: 'moi' });
    return dap.json({ dat: true, id, troLy: ds.length ? ds[0].id : null }, 201);
  }, 'Nhận một đầu mối mới và giao cho tổ tiếp nhận');

  them('GET', '/gia-dinh', async (bc) => {
    const chan = bc.canQuyen('crm.read');
    if (chan) return chan;
    const chang = bc.url.searchParams.get('chang');
    const tham = [];
    let sql = 'SELECT * FROM gia_dinh';
    if (chang) { sql += ' WHERE chang = ?'; tham.push(chang); }
    sql += ' ORDER BY updated_at DESC LIMIT ? OFFSET ?';
    tham.push(bc.soTu('soDong', 30, 1, 100), bc.soTu('boQua', 0, 0));
    const ds = await bc.kho.nhieu(sql, tham);
    return dap.json({ dat: true, so: ds.length, giaDinh: ds.map(gonGiaDinh) });
  }, 'Danh sách gia đình, không kèm phân loại nội bộ');

  them('GET', '/gia-dinh/:id', async (bc) => {
    const chan = bc.canQuyen('crm.read');
    if (chan) return chan;
    const g = await bc.kho.mot('SELECT * FROM gia_dinh WHERE id = ?', [bc.thamSo.id]);
    if (!g) return dap.khongThay('gia đình');
    const hv = await bc.kho.nhieu(
      'SELECT h.user_id, h.quan_he, u.full_name FROM gia_dinh_hoc_vien h ' +
      'LEFT JOIN users u ON u.id = h.user_id WHERE h.gia_dinh_id = ?', [g.id]);
    const tt = await bc.kho.nhieu(
      'SELECT kenh, huong, tom_tat, at FROM crm_tuong_tac WHERE gia_dinh_id = ? ' +
      'ORDER BY at DESC LIMIT 20', [g.id]);
    const v = await bc.kho.nhieu(
      'SELECT id, loai, noi_dung, trang_thai, han FROM crm_viec WHERE gia_dinh_id = ? ' +
      'ORDER BY created_at DESC LIMIT 20', [g.id]);
    return dap.json({
      dat: true,
      giaDinh: gonGiaDinh(g),
      hocVien: hv.map((x) => ({ userId: x.user_id, ten: x.full_name, quanHe: x.quan_he })),
      tuongTac: tt.map((x) => ({ kenh: x.kenh, huong: x.huong, tomTat: x.tom_tat,
        luc: Number(x.at) })),
      viec: v.map((x) => ({ id: x.id, loai: x.loai, noiDung: x.noi_dung,
        trangThai: x.trang_thai, han: x.han ? Number(x.han) : null })),
    });
  }, 'Chi tiết một gia đình; phân loại nội bộ vẫn không ra theo đường này');

  them('POST', '/gia-dinh/:id/chang', async (bc) => {
    const chan = bc.canQuyen('crm.write');
    if (chan) return chan;
    const t = await bc.layThan();
    const moi = String(t.chang || '');
    if (!CHANG.includes(moi)) {
      return dap.hong(400, 'chang-khong-biet', 'Chặng phải là một trong: ' + CHANG.join(', ') + '.');
    }
    const g = await bc.kho.mot('SELECT chang FROM gia_dinh WHERE id = ?', [bc.thamSo.id]);
    if (!g) return dap.khongThay('gia đình');
    // Không nhảy chặng về phía trước quá một bước — phễu nhảy cóc là
    // phễu không phản ánh việc thật đã làm.
    const tuI = CHANG.indexOf(g.chang), denI = CHANG.indexOf(moi);
    if (denI > tuI + 1 && denI < CHANG.indexOf('tam-dung')) {
      return dap.hong(409, 'nhay-chang',
        'Đang ở chặng "' + g.chang + '", không nhảy thẳng sang "' + moi + '". ' +
        'Đi qua từng bước để phễu phản ánh đúng việc đã làm.');
    }
    await bc.kho.chay('UPDATE gia_dinh SET chang = ?, updated_at = ? WHERE id = ?',
      [moi, bc.bayGio(), bc.thamSo.id]);
    await bc.ghiNhatKy('crm.doi-chang', bc.thamSo.id, { tu: g.chang, sang: moi });
    return dap.json({ dat: true, tu: g.chang, sang: moi });
  }, 'Chuyển gia đình sang chặng kế tiếp');

  them('POST', '/viec', async (bc) => {
    const chan = bc.canQuyen('crm.write');
    if (chan) return chan;
    const t = await bc.layThan();
    const loai = String(t.loai || '');
    if (!LOAI_VIEC.includes(loai)) {
      return dap.hong(400, 'loai-viec-khong-biet',
        'Loại việc phải là một trong: ' + LOAI_VIEC.join(', ') + '.');
    }
    const g = await bc.kho.mot('SELECT id FROM gia_dinh WHERE id = ?', [String(t.giaDinhId || '')]);
    if (!g) return dap.khongThay('gia đình');
    const noiDung = String(t.noiDung || '').trim();
    if (!noiDung) return dap.thieu('noiDung');

    const toCua = { 'goi-dien': 'tiep-nhan', 'nhan-tin': 'tiep-nhan',
      'tu-van': 'tu-van', 'xep-lich-test': 'tu-van', 'bao-ket-qua': 'cham-soc',
      'cham-soc': 'cham-soc', 'nhac-hoc-phi': 'thu-hoi', 'xu-ly-phan-nan': 'cham-soc' }[loai];
    const ds = await bc.kho.nhieu(
      'SELECT c.id, COUNT(v.id) AS dang FROM crm_tro_ly c ' +
      "LEFT JOIN crm_viec v ON v.tro_ly_id = c.id AND v.trang_thai IN ('cho','dang-lam') " +
      "WHERE c.to_id = ? AND c.trang_thai != 'tam-nghi' " +
      'GROUP BY c.id ORDER BY dang ASC, c.id ASC LIMIT 1', [toCua]);

    const canNguoi = VIEC_CAN_NGUOI.includes(loai) ? 1 : 0;
    const id = maMoi();
    await bc.kho.chen('crm_viec', {
      id, gia_dinh_id: g.id, tro_ly_id: ds.length ? ds[0].id : null,
      loai, noi_dung: noiDung.slice(0, 2000),
      han: t.han ? Number(t.han) : null,
      trang_thai: 'cho', can_nguoi: canNguoi, created_at: bc.bayGio(),
    });
    return dap.json({ dat: true, id, troLy: ds.length ? ds[0].id : null,
      canNguoi: !!canNguoi,
      ghiChu: canNguoi
        ? 'Việc này phải có người duyệt trước khi gửi ra ngoài. Nhắc tiền và xử lý phàn nàn ' +
          'là hai việc dễ làm tổn thương nhất, nên tổ Công nợ để mức tự chủ 0.'
        : '' }, 201);
  }, 'Tạo một việc CRM và giao cho đúng tổ');

  them('POST', '/viec/:id/xong', async (bc) => {
    const chan = bc.canQuyen('crm.write');
    if (chan) return chan;
    const t = await bc.layThan();
    const v = await bc.kho.mot('SELECT * FROM crm_viec WHERE id = ?', [bc.thamSo.id]);
    if (!v) return dap.khongThay('việc');
    if (v.trang_thai === 'xong') return dap.hong(409, 'da-xong', 'Việc này đã xong.');
    const moi = v.can_nguoi && v.trang_thai !== 'cho-nguoi-duyet' ? 'cho-nguoi-duyet' : 'xong';
    const now = bc.bayGio();
    await bc.kho.chay(
      'UPDATE crm_viec SET trang_thai = ?, ket_qua = ?, xong_luc = ? WHERE id = ?',
      [moi, t.ketQua ? String(t.ketQua).slice(0, 2000) : null,
        moi === 'xong' ? now : null, v.id]);
    return dap.json({ dat: true, id: v.id, trangThai: moi });
  }, 'Báo xong một việc CRM');

  them('POST', '/tuong-tac', async (bc) => {
    const chan = bc.canQuyen('crm.write');
    if (chan) return chan;
    const t = await bc.layThan();
    const kenh = String(t.kenh || '');
    if (!['dien-thoai', 'tin-nhan', 'email', 'gap-mat', 'trang-web'].includes(kenh)) {
      return dap.hong(400, 'kenh-khong-biet', 'Kênh không nằm trong danh mục.');
    }
    const huong = String(t.huong || '');
    if (!['den', 'di'].includes(huong)) {
      return dap.hong(400, 'huong-khong-biet', 'Hướng phải là den hoặc di.');
    }
    const g = await bc.kho.mot('SELECT id FROM gia_dinh WHERE id = ?', [String(t.giaDinhId || '')]);
    if (!g) return dap.khongThay('gia đình');
    const id = maMoi();
    await bc.kho.chen('crm_tuong_tac', {
      id, gia_dinh_id: g.id, kenh, huong,
      tom_tat: String(t.tomTat || '').slice(0, 1000),
      tro_ly_id: t.troLyId ? String(t.troLyId) : null,
      nguoi_id: bc.nguoi.id, at: bc.bayGio(),
    });
    await bc.kho.chay('UPDATE gia_dinh SET updated_at = ? WHERE id = ?', [bc.bayGio(), g.id]);
    return dap.json({ dat: true, id }, 201);
  }, 'Ghi một lần tương tác với gia đình');

  them('GET', '/cay-tien', async (bc) => {
    // Đường duy nhất trong hệ thống để phân loại nội bộ đi ra, và nó đòi
    // một quyền riêng mà chỉ tầng quản trị có.
    const chan = bc.canQuyen('cay-tien.admin');
    if (chan) return chan;
    const ds = await bc.kho.nhieu(
      'SELECT cay_tien_nhom, COUNT(*) AS so FROM gia_dinh ' +
      'WHERE cay_tien_nhom IS NOT NULL GROUP BY cay_tien_nhom');
    const chuaPhan = await bc.kho.dem(
      'SELECT COUNT(*) FROM gia_dinh WHERE cay_tien_nhom IS NULL');
    await bc.ghiNhatKy('crm.xem-cay-tien', null, { boiAi: bc.nguoi.id });
    return dap.json({
      dat: true,
      theoNhom: ds.map((x) => ({ nhom: x.cay_tien_nhom, so: Number(x.so) })),
      chuaPhanLoai: chuaPhan,
      nhacNho: 'Con số này chỉ dùng để điều phối nguồn lực trong nội bộ. ' +
        'Nó không được xuất hiện ở bất kỳ câu trả lời nào tới gia đình, ' +
        'trong bất kỳ báo cáo nào gửi ra ngoài — Điều 8 của hiến pháp vận hành. ' +
        'Lượt xem này đã được ghi vào nhật ký kiểm toán.',
    });
  }, 'Phân loại nội bộ — chỉ tầng quản trị, và mỗi lượt xem đều bị ghi lại');

  them('GET', '/tro-ly', async (bc) => {
    const chan = bc.canQuyen('crm.read');
    if (chan) return chan;
    const ds = await bc.kho.nhieu(
      'SELECT c.*, COUNT(v.id) AS viec_dang_lam FROM crm_tro_ly c ' +
      "LEFT JOIN crm_viec v ON v.tro_ly_id = c.id AND v.trang_thai IN ('cho','dang-lam') " +
      'GROUP BY c.id ORDER BY c.id');
    return dap.json({ dat: true, so: ds.length, troLy: ds.map((d) => ({
      ma: d.id, ten: d.ten, to: d.to_id, vai: d.vai,
      mucTuChu: Number(d.muc_tu_chu), sucChuaNgay: Number(d.suc_chua_ngay),
      viecDangLam: Number(d.viec_dang_lam), trangThai: d.trang_thai })) });
  }, 'Năm mươi trợ lý quan hệ gia đình và tải việc hiện tại');
}

module.exports = { dangKy, gonGiaDinh, CHANG, LOAI_VIEC, VIEC_CAN_NGUOI };
