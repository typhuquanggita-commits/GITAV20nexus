'use strict';
/**
 * Tài chính kế toán — ghi sổ kép.
 *
 * Vì sao ghi sổ kép chứ không phải một bảng thu chi: bảng thu chi không
 * bao giờ tự phát hiện được sai. Ở đây tổng Nợ phải bằng tổng Có trong
 * TỪNG chứng từ, và lệch một đồng là chứng từ không ghi sổ được.
 *
 * Tiền là SỐ NGUYÊN ĐỒNG. Không dùng số thực cho tiền — 0.1 + 0.2 trong
 * số thực nhị phân không bằng 0.3, và một hệ kế toán không được phép có
 * chỗ nào như thế.
 *
 * Chứng từ đã ghi sổ thì không sửa và không xoá (Điều 9). Sai thì ghi
 * bút toán đảo và giữ cả hai — đó là cách một sổ sách chịu được kiểm tra.
 */

const dap = require('../_lib/dap.js');
const { maMoi } = require('../_lib/ma.js');

const LOAI_CT = ['thu', 'chi', 'ban-hang', 'mua-hang', 'luong', 'khau-hao',
  'ket-chuyen', 'dieu-chinh', 'khac'];

function kyCua(ngay) {
  return String(ngay).slice(0, 7);          // 'YYYY-MM'
}

/** Kiểm cân đối và trả về tổng Nợ, tổng Có của một danh sách bút toán. */
function canDoi(ds) {
  let no = 0, co = 0;
  for (const b of ds) {
    const t = Number(b.soTien);
    if (!Number.isInteger(t) || t <= 0) {
      return { hopLe: false, ma: 'so-tien-sai',
        loi: 'Số tiền phải là số nguyên đồng lớn hơn 0. Nhận được: ' + b.soTien };
    }
    if (!b.tkNo && !b.tkCo) {
      return { hopLe: false, ma: 'thieu-tai-khoan',
        loi: 'Mỗi dòng bút toán phải có ít nhất một bên: tkNo hoặc tkCo.' };
    }
    if (b.tkNo) no += t;
    if (b.tkCo) co += t;
  }
  if (no !== co) {
    return { hopLe: false, ma: 'lech-no-co',
      loi: 'Tổng Nợ ' + no + ' không bằng tổng Có ' + co + '. Lệch ' + Math.abs(no - co) + ' đồng.',
      tongNo: no, tongCo: co };
  }
  if (no === 0) {
    return { hopLe: false, ma: 'chung-tu-rong', loi: 'Chứng từ không có dòng nào.' };
  }
  return { hopLe: true, tongNo: no, tongCo: co };
}

function dangKy(them) {
  them('GET', '/tai-khoan', async (bc) => {
    const chan = bc.canQuyen('ketoan.read');
    if (chan) return chan;
    const tt = bc.url.searchParams.get('thongTu');
    const tham = [];
    let sql = 'SELECT * FROM tai_khoan_ke_toan WHERE hoat_dong = 1';
    if (tt) { sql += " AND thong_tu IN (?, 'ca-hai')"; tham.push(tt); }
    sql += ' ORDER BY so';
    const ds = await bc.kho.nhieu(sql, tham);
    return dap.json({ dat: true, so: ds.length, taiKhoan: ds.map((d) => ({
      so: d.so, ten: d.ten, loai: d.loai, duThuong: d.du_thuong, thongTu: d.thong_tu })),
      canCu: 'Thông tư 200/2014/TT-BTC và Thông tư 133/2016/TT-BTC.' });
  }, 'Hệ thống tài khoản kế toán');

  them('POST', '/ky', async (bc) => {
    const chan = bc.canQuyen('ketoan.post');
    if (chan) return chan;
    const t = await bc.layThan();
    const id = String(t.ky || '');
    if (!/^\d{4}-\d{2}$/.test(id)) {
      return dap.hong(400, 'ky-sai-dang', 'Kỳ phải có dạng YYYY-MM, ví dụ 2026-09.');
    }
    const [nam, thang] = id.split('-').map(Number);
    if (thang < 1 || thang > 12) return dap.hong(400, 'thang-sai', 'Tháng từ 01 đến 12.');
    const cuoi = new Date(Date.UTC(nam, thang, 0)).toISOString().slice(0, 10);
    await bc.kho.chay(
      "INSERT INTO ky_ke_toan (id, tu_ngay, den_ngay, trang_thai) VALUES (?, ?, ?, 'mo') " +
      'ON CONFLICT(id) DO NOTHING', [id, id + '-01', cuoi]);
    return dap.json({ dat: true, ky: id, tuNgay: id + '-01', denNgay: cuoi }, 201);
  }, 'Mở một kỳ kế toán');

  them('POST', '/chung-tu', async (bc) => {
    const chan = bc.canQuyen('ketoan.post');
    if (chan) return chan;
    const t = await bc.layThan();
    const loai = String(t.loai || '');
    if (!LOAI_CT.includes(loai)) {
      return dap.hong(400, 'loai-khong-biet', 'Loại chứng từ phải là một trong: ' + LOAI_CT.join(', ') + '.');
    }
    const ngay = String(t.ngayCt || '');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(ngay)) {
      return dap.hong(400, 'ngay-sai-dang', 'ngayCt phải có dạng YYYY-MM-DD.');
    }
    const dienGiai = String(t.dienGiai || '').trim();
    if (!dienGiai) return dap.thieu('dienGiai');
    const ds = Array.isArray(t.butToan) ? t.butToan : null;
    if (!ds) return dap.saiKieu('butToan', 'một mảng');

    const cd = canDoi(ds);
    if (!cd.hopLe) {
      return dap.hong(400, cd.ma, cd.loi,
        cd.tongNo === undefined ? {} : { tongNo: cd.tongNo, tongCo: cd.tongCo });
    }

    // Tài khoản phải có thật trong hệ thống tài khoản.
    const soTk = [...new Set(ds.flatMap((b) => [b.tkNo, b.tkCo]).filter(Boolean).map(String))];
    const co = await bc.kho.nhieu(
      'SELECT so FROM tai_khoan_ke_toan WHERE so IN (' + soTk.map(() => '?').join(',') + ')', soTk);
    if (co.length !== soTk.length) {
      const coSet = new Set(co.map((x) => x.so));
      return dap.hong(400, 'tai-khoan-khong-co',
        'Không có tài khoản: ' + soTk.filter((x) => !coSet.has(x)).join(', ') + '.');
    }

    const ky = kyCua(ngay);
    const k = await bc.kho.mot('SELECT trang_thai FROM ky_ke_toan WHERE id = ?', [ky]);
    if (!k) {
      return dap.hong(409, 'ky-chua-mo', 'Kỳ ' + ky + ' chưa mở. Mở kỳ trước khi lập chứng từ.');
    }
    if (k.trang_thai === 'khoa') {
      return dap.hong(409, 'ky-da-khoa',
        'Kỳ ' + ky + ' đã khoá. Ghi vào kỳ đã khoá là sửa lại quá khứ.');
    }

    const soCt = String(t.soCt || (loai.toUpperCase().slice(0, 2) + '-' + ngay.replace(/-/g, '') +
      '-' + Math.floor(bc.bayGio() % 100000)));
    const daCo = await bc.kho.mot('SELECT id FROM chung_tu WHERE so_ct = ?', [soCt]);
    if (daCo) return dap.trung('Số chứng từ ' + soCt);

    const id = maMoi();
    const now = bc.bayGio();
    await bc.kho.chen('chung_tu', {
      id, so_ct: soCt, ky_id: ky, ngay_ct: ngay,
      ngay_ghi_so: new Date(now).toISOString().slice(0, 10),
      loai, dien_giai: dienGiai, tong_tien: cd.tongNo,
      doi_tac: t.doiTac ? String(t.doiTac).slice(0, 200) : null,
      gia_dinh_id: t.giaDinhId ? String(t.giaDinhId) : null,
      chung_tu_goc: t.chungTuGoc ? String(t.chungTuGoc).slice(0, 100) : null,
      trang_thai: 'nhap', nguoi_lap: bc.nguoi.id, created_at: now,
    });
    let dong = 0;
    for (const b of ds) {
      dong += 1;
      await bc.kho.chen('but_toan', {
        id: maMoi(), chung_tu_id: id, dong,
        tk_no: b.tkNo ? String(b.tkNo) : null,
        tk_co: b.tkCo ? String(b.tkCo) : null,
        so_tien: Number(b.soTien),
        dien_giai: b.dienGiai ? String(b.dienGiai).slice(0, 500) : null,
        doi_tuong: b.doiTuong ? String(b.doiTuong).slice(0, 100) : null,
      });
    }
    await bc.ghiNhatKy('ke-toan.lap-chung-tu', id, { soCt, loai, tong: cd.tongNo });
    return dap.json({ dat: true, id, soCt, ky, tongTien: cd.tongNo, soDong: dong,
      trangThai: 'nhap',
      ghiChu: 'Chứng từ mới lập. Phải có người khác ghi sổ — Điều 14.' }, 201);
  }, 'Lập một chứng từ, bắt buộc cân đối Nợ–Có');

  them('POST', '/chung-tu/:id/ghi-so', async (bc) => {
    const chan = bc.canQuyen('ketoan.post');
    if (chan) return chan;
    const c = await bc.kho.mot('SELECT * FROM chung_tu WHERE id = ?', [bc.thamSo.id]);
    if (!c) return dap.khongThay('chứng từ');
    if (c.trang_thai === 'da-ghi-so') {
      return dap.hong(409, 'da-ghi-so', 'Chứng từ này đã ghi sổ rồi.');
    }
    if (c.nguoi_lap === bc.nguoi.id) {
      return dap.hong(403, 'tu-duyet',
        'Người lập chứng từ không tự ghi sổ chứng từ của mình. Chuyển cho người khác.');
    }
    // Cân đối lại từ kho, không tin con số đã ghi ở cột tong_tien.
    const bt = await bc.kho.nhieu(
      'SELECT tk_no, tk_co, so_tien FROM but_toan WHERE chung_tu_id = ? ORDER BY dong', [c.id]);
    const cd = canDoi(bt.map((b) => ({ tkNo: b.tk_no, tkCo: b.tk_co, soTien: Number(b.so_tien) })));
    if (!cd.hopLe) {
      return dap.hong(409, cd.ma, 'Chứng từ không cân đối khi kiểm lại: ' + cd.loi);
    }
    const now = bc.bayGio();
    await bc.kho.chay(
      "UPDATE chung_tu SET trang_thai = 'da-ghi-so', nguoi_duyet = ?, ghi_so_luc = ? WHERE id = ?",
      [bc.nguoi.id, now, c.id]);
    await bc.ghiNhatKy('ke-toan.ghi-so', c.id, { soCt: c.so_ct, tong: cd.tongNo });
    return dap.json({ dat: true, id: c.id, trangThai: 'da-ghi-so',
      tongNo: cd.tongNo, tongCo: cd.tongCo });
  }, 'Ghi sổ một chứng từ; người lập không tự ghi sổ');

  them('POST', '/chung-tu/:id/dao', async (bc) => {
    const chan = bc.canQuyen('ketoan.post');
    if (chan) return chan;
    const t = await bc.layThan();
    const lyDo = String(t.lyDo || '').trim();
    if (lyDo.length < 10) return dap.thieu('lyDo (từ 10 ký tự)');
    const c = await bc.kho.mot('SELECT * FROM chung_tu WHERE id = ?', [bc.thamSo.id]);
    if (!c) return dap.khongThay('chứng từ');
    if (c.trang_thai !== 'da-ghi-so') {
      return dap.hong(409, 'chua-ghi-so',
        'Chỉ đảo được chứng từ đã ghi sổ. Chứng từ chưa ghi sổ thì sửa thẳng.');
    }
    const daDao = await bc.kho.mot('SELECT id FROM chung_tu WHERE dao_cua_id = ?', [c.id]);
    if (daDao) return dap.hong(409, 'da-dao', 'Chứng từ này đã có bút toán đảo.', { daDao: daDao.id });

    const bt = await bc.kho.nhieu('SELECT * FROM but_toan WHERE chung_tu_id = ? ORDER BY dong',
      [c.id]);
    const id = maMoi();
    const now = bc.bayGio();
    const soCt = 'DAO-' + c.so_ct;
    await bc.kho.chen('chung_tu', {
      id, so_ct: soCt, ky_id: c.ky_id, ngay_ct: new Date(now).toISOString().slice(0, 10),
      ngay_ghi_so: new Date(now).toISOString().slice(0, 10),
      loai: 'dieu-chinh',
      dien_giai: 'Đảo chứng từ ' + c.so_ct + '. Lý do: ' + lyDo,
      tong_tien: Number(c.tong_tien), doi_tac: c.doi_tac,
      trang_thai: 'da-ghi-so', dao_cua_id: c.id,
      nguoi_lap: bc.nguoi.id, nguoi_duyet: bc.nguoi.id, ghi_so_luc: now, created_at: now,
    });
    let dong = 0;
    for (const b of bt) {
      dong += 1;
      // Đảo chiều: bên Nợ thành bên Có và ngược lại.
      await bc.kho.chen('but_toan', {
        id: maMoi(), chung_tu_id: id, dong,
        tk_no: b.tk_co, tk_co: b.tk_no, so_tien: Number(b.so_tien),
        dien_giai: 'Đảo dòng ' + b.dong, doi_tuong: b.doi_tuong,
      });
    }
    await bc.kho.chay("UPDATE chung_tu SET trang_thai = 'da-dao' WHERE id = ?", [c.id]);
    await bc.ghiNhatKy('ke-toan.dao', id, { daoCua: c.so_ct, lyDo });
    return dap.json({ dat: true, id, soCt, daoCua: c.so_ct, soDong: dong,
      ghiChu: 'Chứng từ gốc vẫn còn nguyên. Sổ giữ cả hai.' }, 201);
  }, 'Ghi bút toán đảo cho một chứng từ đã ghi sổ');

  them('GET', '/so-cai/:tk', async (bc) => {
    const chan = bc.canQuyen('ketoan.read');
    if (chan) return chan;
    const tk = bc.thamSo.tk;
    const t = await bc.kho.mot('SELECT * FROM tai_khoan_ke_toan WHERE so = ?', [tk]);
    if (!t) return dap.khongThay('tài khoản ' + tk);
    const tu = bc.url.searchParams.get('tuNgay') || '0000-00-00';
    const den = bc.url.searchParams.get('denNgay') || '9999-99-99';
    const ds = await bc.kho.nhieu(
      'SELECT c.so_ct, c.ngay_ghi_so, c.dien_giai, b.dong, b.tk_no, b.tk_co, b.so_tien ' +
      'FROM but_toan b JOIN chung_tu c ON c.id = b.chung_tu_id ' +
      "WHERE (b.tk_no = ? OR b.tk_co = ?) AND c.trang_thai = 'da-ghi-so' " +
      'AND c.ngay_ghi_so BETWEEN ? AND ? ORDER BY c.ngay_ghi_so, c.so_ct, b.dong',
      [tk, tk, tu, den]);
    let no = 0, co = 0;
    const dong = ds.map((d) => {
      const n = d.tk_no === tk ? Number(d.so_tien) : 0;
      const c2 = d.tk_co === tk ? Number(d.so_tien) : 0;
      no += n; co += c2;
      return { soCt: d.so_ct, ngay: d.ngay_ghi_so, dienGiai: d.dien_giai,
        no: n, co: c2, luyKeNo: no, luyKeCo: co };
    });
    const du = t.du_thuong === 'co' ? co - no : no - co;
    return dap.json({ dat: true, taiKhoan: { so: t.so, ten: t.ten, duThuong: t.du_thuong },
      soDong: dong.length, tongNo: no, tongCo: co, duCuoiKy: du, dong });
  }, 'Sổ cái một tài khoản');

  them('GET', '/can-doi/:ky', async (bc) => {
    const chan = bc.canQuyen('ketoan.read');
    if (chan) return chan;
    const ky = bc.thamSo.ky;
    const ds = await bc.kho.nhieu(
      'SELECT t.so, t.ten, t.loai, t.du_thuong, ' +
      '  COALESCE(SUM(CASE WHEN b.tk_no = t.so THEN b.so_tien ELSE 0 END), 0) AS no, ' +
      '  COALESCE(SUM(CASE WHEN b.tk_co = t.so THEN b.so_tien ELSE 0 END), 0) AS co ' +
      'FROM tai_khoan_ke_toan t ' +
      'LEFT JOIN but_toan b ON (b.tk_no = t.so OR b.tk_co = t.so) ' +
      'LEFT JOIN chung_tu c ON c.id = b.chung_tu_id ' +
      "  AND c.ky_id = ? AND c.trang_thai = 'da-ghi-so' " +
      'GROUP BY t.so HAVING no > 0 OR co > 0 ORDER BY t.so', [ky]);
    const tongNo = ds.reduce((s, x) => s + Number(x.no), 0);
    const tongCo = ds.reduce((s, x) => s + Number(x.co), 0);
    return dap.json({
      dat: true, ky, soTaiKhoan: ds.length,
      tongPhatSinhNo: tongNo, tongPhatSinhCo: tongCo,
      canDoi: tongNo === tongCo,
      lech: tongNo - tongCo,
      dong: ds.map((x) => ({ so: x.so, ten: x.ten, loai: x.loai,
        phatSinhNo: Number(x.no), phatSinhCo: Number(x.co),
        du: x.du_thuong === 'co' ? Number(x.co) - Number(x.no) : Number(x.no) - Number(x.co) })),
      ghiChu: tongNo === tongCo
        ? 'Cân đối. Tổng phát sinh Nợ bằng tổng phát sinh Có.'
        : 'LỆCH ' + Math.abs(tongNo - tongCo) + ' đồng. Có chứng từ ghi sổ mà không cân — ' +
          'phải tìm ra trước khi khoá kỳ.',
    });
  }, 'Bảng cân đối phát sinh một kỳ');

  them('POST', '/ky/:ky/khoa', async (bc) => {
    const chan = bc.canQuyen('ketoan.post');
    if (chan) return chan;
    const k = await bc.kho.mot('SELECT * FROM ky_ke_toan WHERE id = ?', [bc.thamSo.ky]);
    if (!k) return dap.khongThay('kỳ kế toán');
    if (k.trang_thai === 'khoa') return dap.hong(409, 'da-khoa', 'Kỳ này đã khoá.');
    const chuaGhi = await bc.kho.dem(
      "SELECT COUNT(*) FROM chung_tu WHERE ky_id = ? AND trang_thai IN ('nhap','cho-duyet')",
      [k.id]);
    if (chuaGhi > 0) {
      return dap.hong(409, 'con-chung-tu-chua-ghi-so',
        'Còn ' + chuaGhi + ' chứng từ chưa ghi sổ trong kỳ. Xử lý hết rồi mới khoá được.');
    }
    const r = await bc.kho.mot(
      'SELECT COALESCE(SUM(CASE WHEN b.tk_no IS NOT NULL THEN b.so_tien ELSE 0 END),0) AS no, ' +
      '       COALESCE(SUM(CASE WHEN b.tk_co IS NOT NULL THEN b.so_tien ELSE 0 END),0) AS co ' +
      'FROM but_toan b JOIN chung_tu c ON c.id = b.chung_tu_id ' +
      "WHERE c.ky_id = ? AND c.trang_thai = 'da-ghi-so'", [k.id]);
    if (Number(r.no) !== Number(r.co)) {
      return dap.hong(409, 'ky-khong-can-doi',
        'Kỳ lệch ' + Math.abs(Number(r.no) - Number(r.co)) + ' đồng. Không khoá được kỳ lệch.');
    }
    const now = bc.bayGio();
    await bc.kho.chay("UPDATE ky_ke_toan SET trang_thai = 'khoa', khoa_luc = ?, khoa_boi = ? WHERE id = ?",
      [now, bc.nguoi.id, k.id]);
    await bc.kho.chen('bao_cao_tai_chinh', {
      id: maMoi(), ky_id: k.id, loai: 'can-doi-phat-sinh',
      so_lieu_json: JSON.stringify({ tongNo: Number(r.no), tongCo: Number(r.co) }),
      can_doi: 1, lap_luc: now, nguoi_lap: bc.nguoi.id,
    });
    await bc.ghiNhatKy('ke-toan.khoa-ky', k.id, { tongNo: Number(r.no) });
    return dap.json({ dat: true, ky: k.id, trangThai: 'khoa',
      tongPhatSinh: Number(r.no) });
  }, 'Khoá một kỳ; không khoá được kỳ còn lệch');

  them('POST', '/hoc-phi', async (bc) => {
    const chan = bc.canQuyen('ketoan.post');
    if (chan) return chan;
    const t = await bc.layThan();
    const soTien = Number(t.soTien);
    if (!Number.isInteger(soTien) || soTien <= 0) {
      return dap.hong(400, 'so-tien-sai', 'Số tiền là số nguyên đồng lớn hơn 0.');
    }
    const u = await bc.kho.mot('SELECT id FROM users WHERE id = ?', [String(t.userId || '')]);
    if (!u) return dap.khongThay('học viên');
    const id = maMoi();
    await bc.kho.chen('hoc_phi', {
      id, user_id: u.id, gia_dinh_id: t.giaDinhId ? String(t.giaDinhId) : null,
      ky: String(t.ky || ''), khoan_muc: String(t.khoanMuc || 'Học phí'),
      so_tien: soTien, han_thu: t.hanThu ? String(t.hanThu).slice(0, 10) : null,
      trang_thai: 'cho-thu', created_at: bc.bayGio(),
    });
    return dap.json({ dat: true, id, soTien }, 201);
  }, 'Ghi một khoản học phí phải thu');

  them('GET', '/cong-no', async (bc) => {
    const chan = bc.canQuyen('ketoan.read');
    if (chan) return chan;
    const ds = await bc.kho.nhieu(
      'SELECT h.*, u.full_name FROM hoc_phi h LEFT JOIN users u ON u.id = h.user_id ' +
      "WHERE h.trang_thai IN ('cho-thu','thu-mot-phan') ORDER BY h.han_thu ASC LIMIT ?",
      [bc.soTu('soDong', 50, 1, 200)]);
    const tong = await bc.kho.mot(
      'SELECT COALESCE(SUM(so_tien - da_thu), 0) AS con FROM hoc_phi ' +
      "WHERE trang_thai IN ('cho-thu','thu-mot-phan')");
    return dap.json({ dat: true, tongConPhaiThu: Number(tong.con), so: ds.length,
      khoan: ds.map((d) => ({ id: d.id, hocVien: d.full_name, ky: d.ky,
        khoanMuc: d.khoan_muc, soTien: Number(d.so_tien), daThu: Number(d.da_thu),
        conLai: Number(d.so_tien) - Number(d.da_thu), hanThu: d.han_thu,
        trangThai: d.trang_thai })) });
  }, 'Công nợ học phí còn phải thu');
}

module.exports = { dangKy, canDoi, kyCua, LOAI_CT };
