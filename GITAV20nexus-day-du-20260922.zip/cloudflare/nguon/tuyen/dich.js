'use strict';
/** Dịch nội dung sang nhiều thứ tiếng, có bảng thuật ngữ bắt buộc. */

const dap = require('../_lib/dap.js');
const dichVu = require('../_lib/dich.js');
const { maMoi } = require('../_lib/ma.js');

function dangKy(them) {
  them('POST', '/translate', async (bc) => {
    const chan = bc.canQuyen('content.moderate');
    if (chan) return chan;
    const chanHm = await bc.canHanMuc('ai');
    if (chanHm) return chanHm;
    const t = await bc.layThan();
    const r = await dichVu.dichNoiDung(bc.kho, bc.moi, {
      loaiNoiDung: String(t.contentType || t.loaiNoiDung || ''),
      maNoiDung: String(t.contentId || t.maNoiDung || ''),
      truong: t.fields || t.truong,
      tuTieng: String(t.sourceLang || t.tuTieng || 'vi'),
      sangTieng: String(t.targetLang || t.sangTieng || ''),
    }, bc.bayGio());
    if (!r.dat) {
      const maHttp = r.ma === 'ai-khong-goi-duoc' ? 502 : 400;
      return dap.hong(maHttp, r.ma, r.loi, r.duongDaDi ? { duongDaDi: r.duongDaDi } : {});
    }
    await bc.ghiNhatKy('dich.tao', r.id, { sangTieng: t.targetLang || t.sangTieng });
    return dap.json(r, r.daCo ? 200 : 201);
  }, 'Dịch một nội dung sang tiếng khác');

  them('GET', '/:contentType/:contentId/:lang', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const r = await bc.kho.mot(
      'SELECT * FROM content_translations WHERE content_type = ? AND content_id = ? AND target_lang = ?',
      [bc.thamSo.contentType, bc.thamSo.contentId, bc.thamSo.lang]);
    if (!r) return dap.khongThay('bản dịch');
    return dap.json({
      dat: true, id: r.id,
      loaiNoiDung: r.content_type, maNoiDung: r.content_id,
      tuTieng: r.source_lang, sangTieng: r.target_lang,
      ban: JSON.parse(r.translated_json),
      trangThai: r.status,
      lacHau: r.status === 'stale',
      mauMay: r.model, diemChatLuong: r.quality_score,
      nguoiSoat: r.reviewed_by, soatLuc: r.reviewed_at,
      capNhat: Number(r.updated_at),
    });
  }, 'Lấy một bản dịch');

  them('POST', '/:id/review', async (bc) => {
    const chan = bc.canQuyen('content.moderate');
    if (chan) return chan;
    const t = await bc.layThan();
    const r = await bc.kho.mot('SELECT * FROM content_translations WHERE id = ?', [bc.thamSo.id]);
    if (!r) return dap.khongThay('bản dịch');
    if (r.status === 'stale') {
      return dap.hong(409, 'ban-dich-lac-hau',
        'Bản gốc đã đổi từ khi dịch. Dịch lại trước khi soát, đừng duyệt bản cũ.');
    }
    const quyet = String(t.decision || t.quyet || 'published');
    if (!['reviewed', 'published'].includes(quyet)) {
      return dap.hong(400, 'quyet-khong-biet', 'Quyết định phải là reviewed hoặc published.');
    }
    const ban = t.fields || t.ban;
    const now = bc.bayGio();
    await bc.kho.chay(
      'UPDATE content_translations SET status = ?, reviewed_by = ?, reviewed_at = ?, ' +
      '  translated_json = COALESCE(?, translated_json), updated_at = ? WHERE id = ?',
      [quyet, bc.nguoi.id, now, ban ? JSON.stringify(ban) : null, now, r.id]);
    await bc.ghiNhatKy('dich.soat', r.id, { quyet });
    return dap.json({ dat: true, id: r.id, trangThai: quyet });
  }, 'Soát và duyệt một bản dịch');

  them('POST', '/glossary', async (bc) => {
    const chan = bc.canQuyen('content.moderate');
    if (chan) return chan;
    const t = await bc.layThan();
    const tu = String(t.sourceLang || t.tuTieng || 'vi');
    const sang = String(t.targetLang || t.sangTieng || '');
    const goc = String(t.sourceTerm || t.thuatNguGoc || '').trim();
    const dich = String(t.targetTerm || t.thuatNguDich || '').trim();
    if (!dichVu.tiengHopLe(tu) || !dichVu.tiengHopLe(sang)) {
      return dap.hong(400, 'tieng-khong-ho-tro',
        'Chỉ hỗ trợ: ' + Object.keys(dichVu.TIENG).join(', ') + '.');
    }
    if (!goc) return dap.thieu('thuatNguGoc');
    if (!dich) return dap.thieu('thuatNguDich');
    const now = bc.bayGio();
    await bc.kho.chay(
      'INSERT INTO translation_glossary ' +
      '(id, source_lang, target_lang, source_term, target_term, context, created_by, created_at) ' +
      'VALUES (?, ?, ?, ?, ?, ?, ?, ?) ' +
      'ON CONFLICT(source_lang, target_lang, source_term) DO UPDATE SET ' +
      '  target_term = excluded.target_term, context = excluded.context',
      [maMoi(), tu, sang, goc, dich, t.context ? String(t.context).slice(0, 300) : null,
        bc.nguoi.id, now]);
    // Thuật ngữ đổi thì mọi bản dịch máy sang tiếng ấy phải soát lại.
    const anh = await bc.kho.chay(
      "UPDATE content_translations SET status = 'stale', updated_at = ? " +
      "WHERE target_lang = ? AND status = 'machine'", [now, sang]);
    await bc.ghiNhatKy('dich.thuat-ngu', goc, { tu, sang, dich });
    return dap.json({ dat: true, thuatNguGoc: goc, thuatNguDich: dich,
      banDichPhaiSoatLai: (anh && anh.meta && anh.meta.changes) || 0 }, 201);
  }, 'Thêm hoặc sửa một thuật ngữ bắt buộc');

  them('GET', '/glossary', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const sang = bc.url.searchParams.get('targetLang') || bc.url.searchParams.get('sangTieng');
    const tham = [];
    let sql = 'SELECT * FROM translation_glossary';
    if (sang) { sql += ' WHERE target_lang = ?'; tham.push(sang); }
    sql += ' ORDER BY source_term ASC LIMIT ?';
    tham.push(bc.soTu('soDong', 100, 1, 100));
    const ds = await bc.kho.nhieu(sql, tham);
    return dap.json({ dat: true, soMuc: ds.length,
      thuatNgu: ds.map((d) => ({ goc: d.source_term, dich: d.target_term,
        tu: d.source_lang, sang: d.target_lang, boiCanh: d.context })) });
  }, 'Danh sách thuật ngữ');

  them('GET', '/tieng', async () => dap.json({
    dat: true, tieng: Object.entries(dichVu.TIENG).map(([ma, ten]) => ({ ma, ten })),
  }), 'Các thứ tiếng hỗ trợ');
}

module.exports = { dangKy };
