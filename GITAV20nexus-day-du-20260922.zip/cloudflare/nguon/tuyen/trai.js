'use strict';
/**
 * Trại huấn luyện: Gel Alpha, Leader Boom, Kỹ năng học giỏi.
 *
 * Trại khác lớp học ở một chỗ: nó có ngưỡng vào và ngưỡng ra, và ngưỡng
 * ra là ngưỡng thật. Không đạt thì không có chứng nhận, và hệ thống nói
 * rõ thiếu điều nào — phát chứng nhận cho đủ mặt là làm hỏng giá trị
 * của chính tờ chứng nhận ấy.
 */

const dap = require('../_lib/dap.js');
const { maMoi } = require('../_lib/ma.js');

/** Đo một ngưỡng ra bằng số thật của học viên trong khoá. */
async function doNguongRa(kho, khoaId, userId, dk) {
  if (dk.do_bang === 'so-buoi') {
    const so = await kho.dem(
      'SELECT COUNT(*) FROM trai_diem_danh WHERE khoa_id = ? AND user_id = ? AND co_mat = 1',
      [khoaId, userId]);
    return { dat: so >= dk.nguong, so, can: dk.nguong };
  }
  if (dk.do_bang === 'diem-kiem-tra') {
    const r = await kho.mot(
      'SELECT AVG(diem) AS tb, COUNT(diem) AS so FROM trai_diem_danh ' +
      'WHERE khoa_id = ? AND user_id = ? AND diem IS NOT NULL', [khoaId, userId]);
    const so = Number(r.so);
    if (so === 0) return { dat: false, so: null, can: dk.nguong, thieuMau: true };
    return { dat: Number(r.tb) >= dk.nguong, so: Number(Number(r.tb).toFixed(2)), can: dk.nguong };
  }
  if (dk.do_bang === 'so-bai') {
    const so = await kho.dem(
      'SELECT COUNT(*) FROM luot_thi_tra_loi t JOIN luot_thi l ON l.id = t.luot_id ' +
      'WHERE l.user_id = ?', [userId]);
    return { dat: so >= dk.nguong, so, can: dk.nguong };
  }
  if (dk.do_bang === 'thoi-gian-giu') {
    const r = await kho.mot(
      'SELECT MIN(bat_dau) AS dau, MAX(bat_dau) AS cuoi, COUNT(*) AS so ' +
      'FROM buoi_hoc WHERE user_id = ?', [userId]);
    if (Number(r.so) < 2) return { dat: false, so: 0, can: dk.nguong, thieuMau: true };
    const ngay = Math.floor((Number(r.cuoi) - Number(r.dau)) / 86400000);
    return { dat: ngay >= dk.nguong, so: ngay, can: dk.nguong };
  }
  return { dat: false, so: null, can: dk.nguong, khongDoDuoc: true };
}

function dangKy(them) {
  them('GET', '/', async (bc) => {
    const ds = await bc.kho.nhieu('SELECT * FROM trai ORDER BY lop_tu');
    const ra = [];
    for (const t of ds) {
      const khoa = await bc.kho.dem('SELECT COUNT(*) FROM trai_khoa WHERE trai_id = ?', [t.id]);
      ra.push({
        ma: t.id, ten: t.ten, mucTieu: t.muc_tieu,
        lop: { tu: Number(t.lop_tu), den: Number(t.lop_den) },
        soNgay: Number(t.so_ngay), soGio: Number(t.so_gio),
        nguongVao: JSON.parse(t.nguong_vao_json),
        nguongRa: JSON.parse(t.nguong_ra_json),
        soKhoaDaMo: khoa,
      });
    }
    return dap.json({ dat: true, so: ra.length, trai: ra,
      ghiChu: 'Ngưỡng ra là ngưỡng thật. Không đạt thì không có chứng nhận.' });
  }, 'Ba trại và ngưỡng vào, ngưỡng ra của từng trại');

  them('POST', '/khoa', async (bc) => {
    const chan = bc.canQuyen('camp.manage');
    if (chan) return chan;
    const t = await bc.layThan();
    const tr = await bc.kho.mot('SELECT * FROM trai WHERE id = ?', [String(t.trai || '')]);
    if (!tr) return dap.khongThay('trại');
    const khai = Number(t.khaiMac), be = Number(t.beMac);
    if (!Number.isFinite(khai) || !Number.isFinite(be) || be <= khai) {
      return dap.hong(400, 'thoi-gian-sai', 'beMac phải sau khaiMac.');
    }
    const hinh = String(t.hinhThuc || 'truc-tuyen');
    if (!['truc-tiep', 'truc-tuyen', 'ket-hop'].includes(hinh)) {
      return dap.hong(400, 'hinh-thuc-khong-biet', 'Hình thức: truc-tiep, truc-tuyen hoặc ket-hop.');
    }
    const suc = Number(t.sucChua || 30);
    if (!Number.isInteger(suc) || suc < 1) return dap.hong(400, 'suc-chua-sai', 'Sức chứa từ 1 trở lên.');
    const id = maMoi();
    await bc.kho.chen('trai_khoa', {
      id, trai_id: tr.id, ten: String(t.ten || (tr.ten + ' — khoá mới')),
      khai_mac: khai, be_mac: be, dia_diem: t.diaDiem ? String(t.diaDiem).slice(0, 200) : null,
      hinh_thuc: hinh, suc_chua: suc, trang_thai: 'mo-ghi-danh', created_at: bc.bayGio(),
    });
    return dap.json({ dat: true, id, sucChua: suc }, 201);
  }, 'Mở một khoá trại');

  them('POST', '/khoa/:id/ghi-danh', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const k = await bc.kho.mot('SELECT * FROM trai_khoa WHERE id = ?', [bc.thamSo.id]);
    if (!k) return dap.khongThay('khoá trại');
    if (k.trang_thai !== 'mo-ghi-danh') {
      return dap.hong(409, 'khong-mo-ghi-danh', 'Khoá đang ở trạng thái ' + k.trang_thai + '.');
    }
    if (Number(k.da_ghi_danh) >= Number(k.suc_chua)) {
      return dap.hong(409, 'het-cho',
        'Khoá đã đủ ' + k.suc_chua + ' người. Nhận thêm là phá vỡ chất lượng trại.');
    }
    const da = await bc.kho.mot(
      'SELECT id FROM trai_hoc_vien WHERE khoa_id = ? AND user_id = ?', [k.id, bc.nguoi.id]);
    if (da) return dap.trung('Bạn đã ghi danh khoá này');

    const tr = await bc.kho.mot('SELECT * FROM trai WHERE id = ?', [k.trai_id]);
    const hs = await bc.kho.mot('SELECT lop FROM ho_so_hoc_vien WHERE user_id = ?', [bc.nguoi.id]);
    const xet = [];
    if (!hs || hs.lop === null) {
      xet.push({ ma: 'co-ho-so', dat: false, vi: 'Chưa có hồ sơ học viên hoặc chưa khai lớp.' });
    } else if (Number(hs.lop) < Number(tr.lop_tu) || Number(hs.lop) > Number(tr.lop_den)) {
      xet.push({ ma: 'dung-lop', dat: false,
        vi: 'Trại này dành cho lớp ' + tr.lop_tu + '–' + tr.lop_den + ', bạn đang lớp ' + hs.lop + '.' });
    } else {
      xet.push({ ma: 'dung-lop', dat: true, vi: 'Lớp ' + hs.lop + ' nằm trong khoảng của trại.' });
    }
    const chuaDat = xet.filter((x) => !x.dat);

    const id = maMoi();
    await bc.kho.chen('trai_hoc_vien', {
      id, khoa_id: k.id, user_id: bc.nguoi.id, ghi_danh_luc: bc.bayGio(),
      xet_vao_json: JSON.stringify(xet),
      trang_thai: chuaDat.length ? 'cho-xet' : 'duoc-vao',
    });
    if (!chuaDat.length) {
      await bc.kho.chay('UPDATE trai_khoa SET da_ghi_danh = da_ghi_danh + 1 WHERE id = ?', [k.id]);
    }
    return dap.json({ dat: true, id, trangThai: chuaDat.length ? 'cho-xet' : 'duoc-vao',
      xetNguongVao: xet,
      conThieu: chuaDat.map((x) => x.vi) }, 201);
  }, 'Ghi danh một khoá trại, xét ngưỡng vào ngay');

  them('POST', '/khoa/:id/diem-danh', async (bc) => {
    const chan = bc.canQuyen('camp.manage');
    if (chan) return chan;
    const t = await bc.layThan();
    const k = await bc.kho.mot('SELECT id FROM trai_khoa WHERE id = ?', [bc.thamSo.id]);
    if (!k) return dap.khongThay('khoá trại');
    const userId = String(t.userId || '');
    const changId = String(t.changId || t.chang || '');
    if (!userId) return dap.thieu('userId');
    if (!changId) return dap.thieu('changId');
    const diem = t.diem === undefined ? null : Number(t.diem);
    if (diem !== null && !(diem >= 0 && diem <= 10)) {
      return dap.hong(400, 'diem-ngoai-thang', 'Điểm từ 0 đến 10.');
    }
    await bc.kho.chay(
      'INSERT INTO trai_diem_danh (id, khoa_id, user_id, chang_id, co_mat, diem, nhan_xet, at) ' +
      'VALUES (?, ?, ?, ?, ?, ?, ?, ?) ' +
      'ON CONFLICT(khoa_id, user_id, chang_id) DO UPDATE SET co_mat = excluded.co_mat, ' +
      '  diem = excluded.diem, nhan_xet = excluded.nhan_xet, at = excluded.at',
      [maMoi(), k.id, userId, changId, t.coMat ? 1 : 0, diem,
        t.nhanXet ? String(t.nhanXet).slice(0, 500) : null, bc.bayGio()]);
    return dap.json({ dat: true, userId, changId, coMat: !!t.coMat, diem });
  }, 'Điểm danh và chấm một chặng trại');

  them('POST', '/khoa/:id/xet-ra/:userId', async (bc) => {
    const chan = bc.canQuyen('camp.manage');
    if (chan) return chan;
    const k = await bc.kho.mot('SELECT * FROM trai_khoa WHERE id = ?', [bc.thamSo.id]);
    if (!k) return dap.khongThay('khoá trại');
    const hv = await bc.kho.mot(
      'SELECT * FROM trai_hoc_vien WHERE khoa_id = ? AND user_id = ?',
      [k.id, bc.thamSo.userId]);
    if (!hv) return dap.khongThay('học viên trong khoá này');
    const tr = await bc.kho.mot('SELECT nguong_ra_json, ten FROM trai WHERE id = ?', [k.trai_id]);
    const nguong = JSON.parse(tr.nguong_ra_json);

    const chiTiet = [];
    let chuaDat = 0;
    for (const dk of nguong) {
      const r = await doNguongRa(bc.kho, k.id, bc.thamSo.userId, dk);
      chiTiet.push({ ma: dk.ma, moTa: dk.mo_ta, doBang: dk.do_bang,
        can: r.can, soThat: r.so, dat: r.dat,
        thieuMau: !!r.thieuMau, khongDoDuoc: !!r.khongDoDuoc });
      if (!r.dat) chuaDat++;
    }
    const dat = chuaDat === 0;
    const now = bc.bayGio();
    const chungNhan = dat ? 'cn-' + k.trai_id + '-' + maMoi().slice(0, 8) : null;
    await bc.kho.chay(
      'UPDATE trai_hoc_vien SET trang_thai = ?, diem_ra_json = ?, chung_nhan_id = ? WHERE id = ?',
      [dat ? 'hoan-thanh' : 'khong-dat', JSON.stringify(chiTiet), chungNhan, hv.id]);
    await bc.ghiNhatKy('trai.xet-ra', hv.id, { dat, chuaDat });

    return dap.json({
      dat: true, hocVien: bc.thamSo.userId, trai: tr.ten,
      ketQua: dat ? 'hoan-thanh' : 'khong-dat',
      chungNhan,
      chiTiet,
      noiThang: dat
        ? 'Đạt đủ ngưỡng ra. Chứng nhận có giá trị vì không ai được phát cho đủ mặt.'
        : 'Chưa đạt ' + chuaDat + ' điều kiện. Không cấp chứng nhận — xem chi tiết để biết thiếu gì.',
    });
  }, 'Xét ngưỡng ra; không đạt thì không có chứng nhận');

  them('GET', '/cua-toi', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const ds = await bc.kho.nhieu(
      'SELECT h.*, k.ten AS ten_khoa, k.khai_mac, k.be_mac, t.ten AS ten_trai ' +
      'FROM trai_hoc_vien h JOIN trai_khoa k ON k.id = h.khoa_id ' +
      'JOIN trai t ON t.id = k.trai_id WHERE h.user_id = ? ORDER BY h.ghi_danh_luc DESC',
      [bc.nguoi.id]);
    return dap.json({ dat: true, so: ds.length, khoa: ds.map((d) => ({
      id: d.id, trai: d.ten_trai, khoa: d.ten_khoa,
      khaiMac: Number(d.khai_mac), beMac: Number(d.be_mac),
      trangThai: d.trang_thai, chungNhan: d.chung_nhan_id,
      xetVao: d.xet_vao_json ? JSON.parse(d.xet_vao_json) : null,
      diemRa: d.diem_ra_json ? JSON.parse(d.diem_ra_json) : null })) });
  }, 'Các khoá trại của mình');
}

module.exports = { dangKy, doNguongRa };
