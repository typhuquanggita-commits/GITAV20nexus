'use strict';
/**
 * Chuỗi video bài giải.
 *
 * Ở đây giữ KỊCH BẢN và THỨ TỰ, không giữ tệp — Cloudflare Pages không
 * là chỗ để tệp video nằm. Tệp dựng xong nằm ở R2 hoặc nơi khác, bảng
 * chỉ lưu đường dẫn.
 *
 * Thứ tự sư phạm là thứ đáng giá nhất của một chuỗi bài giải: cùng một
 * đống video, xếp đúng thứ tự thì học được, xếp sai thì không. Nên thứ
 * tự là dữ liệu có ràng buộc duy nhất, không phải một trường gợi ý.
 */

const dap = require('../_lib/dap.js');
const { maMoi } = require('../_lib/ma.js');

const GIAY_TOI_DA = 3600;

function soiKichBan(kb) {
  if (!Array.isArray(kb) || kb.length === 0) {
    return { dat: false, loi: 'Kịch bản phải là một mảng cảnh, ít nhất một cảnh.' };
  }
  let tong = 0;
  for (let i = 0; i < kb.length; i++) {
    const c = kb[i];
    if (!c || typeof c !== 'object') return { dat: false, loi: 'Cảnh ' + (i + 1) + ' không phải đối tượng.' };
    if (!String(c.loiDoc || '').trim()) {
      return { dat: false, loi: 'Cảnh ' + (i + 1) + ' thiếu loiDoc — người xem nghe gì ở cảnh này?' };
    }
    if (!String(c.hienGi || '').trim()) {
      return { dat: false, loi: 'Cảnh ' + (i + 1) + ' thiếu hienGi — màn hình hiện gì ở cảnh này?' };
    }
    const g = Number(c.giay);
    if (!Number.isFinite(g) || g <= 0) {
      return { dat: false, loi: 'Cảnh ' + (i + 1) + ' có số giây không hợp lệ.' };
    }
    tong += g;
  }
  if (tong > GIAY_TOI_DA) {
    return { dat: false, loi: 'Tổng ' + tong + ' giây, vượt mức ' + GIAY_TOI_DA + ' giây một tập.' };
  }
  return { dat: true, tongGiay: Math.round(tong), soCanh: kb.length };
}

function dangKy(them) {
  them('POST', '/', async (bc) => {
    const chan = bc.canQuyen('video.manage');
    if (chan) return chan;
    const t = await bc.layThan();
    const ten = String(t.ten || '').trim();
    if (!ten) return dap.thieu('ten');
    if (!String(t.mucTieu || '').trim()) {
      return dap.thieu('mucTieu (chuỗi này dạy được điều gì)');
    }
    const id = maMoi();
    const now = bc.bayGio();
    await bc.kho.chen('chuoi_video', {
      id, o_id: t.oId ? String(t.oId) : null,
      chuyen_de_id: t.chuyenDeId ? String(t.chuyenDeId) : null,
      ten, muc_tieu: String(t.mucTieu), trang_thai: 'nhap',
      created_at: now, updated_at: now,
    });
    return dap.json({ dat: true, id }, 201);
  }, 'Tạo một chuỗi video');

  them('POST', '/:id/tap', async (bc) => {
    const chan = bc.canQuyen('video.manage');
    if (chan) return chan;
    const t = await bc.layThan();
    const c = await bc.kho.mot('SELECT * FROM chuoi_video WHERE id = ?', [bc.thamSo.id]);
    if (!c) return dap.khongThay('chuỗi video');
    const kb = t.kichBan;
    const soi = soiKichBan(kb);
    if (!soi.dat) return dap.hong(400, 'kich-ban-chua-du', soi.loi);

    const thuTu = t.thuTu === undefined
      ? (await bc.kho.dem('SELECT COALESCE(MAX(thu_tu),0) FROM video_tap WHERE chuoi_id = ?',
        [c.id])) + 1
      : Number(t.thuTu);
    const trung = await bc.kho.mot(
      'SELECT id FROM video_tap WHERE chuoi_id = ? AND thu_tu = ?', [c.id, thuTu]);
    if (trung) {
      return dap.hong(409, 'trung-thu-tu',
        'Chuỗi này đã có tập số ' + thuTu + '. Thứ tự sư phạm không cho hai tập cùng một chỗ.');
    }

    const id = maMoi();
    const now = bc.bayGio();
    await bc.kho.chen('video_tap', {
      id, chuoi_id: c.id, thu_tu: thuTu,
      ten: String(t.ten || ('Tập ' + thuTu)),
      bai_id: t.baiId ? String(t.baiId) : null,
      giay: soi.tongGiay, kich_ban_json: JSON.stringify(kb),
      giong_doc: t.giongDoc ? String(t.giongDoc).slice(0, 60) : null,
      trang_thai: 'kich-ban', created_at: now, updated_at: now,
    });
    const thu = await bc.kho.nhieu(
      'SELECT id FROM video_tap WHERE chuoi_id = ? ORDER BY thu_tu', [c.id]);
    await bc.kho.chay(
      'UPDATE chuoi_video SET so_tap = ?, thu_tu_json = ?, updated_at = ? WHERE id = ?',
      [thu.length, JSON.stringify(thu.map((x) => x.id)), now, c.id]);
    return dap.json({ dat: true, id, thuTu, soCanh: soi.soCanh, tongGiay: soi.tongGiay }, 201);
  }, 'Thêm một tập vào chuỗi, kèm kịch bản từng cảnh');

  them('GET', '/:id', async (bc) => {
    const c = await bc.kho.mot('SELECT * FROM chuoi_video WHERE id = ?', [bc.thamSo.id]);
    if (!c) return dap.khongThay('chuỗi video');
    const ds = await bc.kho.nhieu(
      'SELECT id, thu_tu, ten, bai_id, giay, giong_doc, duong_dan, trang_thai ' +
      'FROM video_tap WHERE chuoi_id = ? ORDER BY thu_tu', [c.id]);
    return dap.json({ dat: true,
      chuoi: { id: c.id, ten: c.ten, mucTieu: c.muc_tieu, o: c.o_id,
        chuyenDe: c.chuyen_de_id, trangThai: c.trang_thai, soTap: Number(c.so_tap) },
      tap: ds.map((d) => ({ id: d.id, thuTu: Number(d.thu_tu), ten: d.ten,
        baiId: d.bai_id, giay: Number(d.giay), giongDoc: d.giong_doc,
        daDung: !!d.duong_dan, trangThai: d.trang_thai })),
      tongGiay: ds.reduce((s, x) => s + Number(x.giay), 0) });
  }, 'Một chuỗi và các tập theo đúng thứ tự');

  them('GET', '/:id/tap/:tapId/kich-ban', async (bc) => {
    const chan = bc.canQuyen('video.manage');
    if (chan) return chan;
    const t = await bc.kho.mot('SELECT * FROM video_tap WHERE id = ? AND chuoi_id = ?',
      [bc.thamSo.tapId, bc.thamSo.id]);
    if (!t) return dap.khongThay('tập');
    return dap.json({ dat: true, id: t.id, ten: t.ten, thuTu: Number(t.thu_tu),
      giay: Number(t.giay), kichBan: JSON.parse(t.kich_ban_json), trangThai: t.trang_thai });
  }, 'Kịch bản từng cảnh của một tập');

  them('POST', '/:id/tap/:tapId/da-dung', async (bc) => {
    const chan = bc.canQuyen('video.manage');
    if (chan) return chan;
    const t = await bc.layThan();
    const duong = String(t.duongDan || '').trim();
    if (!duong) return dap.thieu('duongDan');
    if (!/^https?:\/\//.test(duong)) {
      return dap.hong(400, 'duong-dan-sai', 'Đường dẫn phải bắt đầu bằng http:// hoặc https://.');
    }
    const v = await bc.kho.mot('SELECT id FROM video_tap WHERE id = ? AND chuoi_id = ?',
      [bc.thamSo.tapId, bc.thamSo.id]);
    if (!v) return dap.khongThay('tập');
    await bc.kho.chay(
      "UPDATE video_tap SET duong_dan = ?, phu_de_vtt = ?, trang_thai = 'da-dung', updated_at = ? " +
      'WHERE id = ?', [duong, t.phuDe ? String(t.phuDe) : null, bc.bayGio(), v.id]);
    return dap.json({ dat: true, id: v.id, trangThai: 'da-dung' });
  }, 'Báo một tập đã dựng xong và nằm ở đâu');

  them('POST', '/:id/tap/:tapId/xem', async (bc) => {
    const t = await bc.layThan();
    const v = await bc.kho.mot('SELECT id, giay FROM video_tap WHERE id = ?', [bc.thamSo.tapId]);
    if (!v) return dap.khongThay('tập');
    const giay = Math.max(0, Math.min(Number(t.giayXem || 0), Number(v.giay)));
    await bc.kho.chen('video_luot_xem', {
      id: maMoi(), tap_id: v.id, user_id: bc.nguoi ? bc.nguoi.id : null,
      giay_xem: giay, xem_het: giay >= Number(v.giay) * 0.9 ? 1 : 0,
      tua_lai: Number(t.tuaLai || 0), at: bc.bayGio(),
    });
    return dap.json({ dat: true, giayXem: giay });
  }, 'Ghi một lượt xem');

  them('GET', '/:id/cho-kho-hieu', async (bc) => {
    const chan = bc.canQuyen('video.manage');
    if (chan) return chan;
    const ds = await bc.kho.nhieu(
      'SELECT v.id, v.thu_tu, v.ten, COUNT(x.id) AS luot, ' +
      '  COALESCE(SUM(x.tua_lai), 0) AS tua, ' +
      '  COALESCE(SUM(x.xem_het), 0) AS het ' +
      'FROM video_tap v LEFT JOIN video_luot_xem x ON x.tap_id = v.id ' +
      'WHERE v.chuoi_id = ? GROUP BY v.id ORDER BY v.thu_tu', [bc.thamSo.id]);
    return dap.json({
      dat: true,
      tap: ds.map((d) => {
        const luot = Number(d.luot);
        return {
          thuTu: Number(d.thu_tu), ten: d.ten, luotXem: luot,
          tuaLaiTrungBinh: luot ? Number((Number(d.tua) / luot).toFixed(2)) : null,
          tiLeXemHet: luot ? Number((Number(d.het) / luot).toFixed(3)) : null,
        };
      }),
      cachDoc: 'Tua lại nhiều ở một tập nghĩa là chỗ ấy khó hiểu — sửa kịch bản tập đó, ' +
        'đừng sửa người học.',
      duLieu: ds.some((d) => Number(d.luot) > 0),
    });
  }, 'Tập nào bị tua lại nhiều nhất — chỗ ấy khó hiểu');
}

module.exports = { dangKy, soiKichBan };
