'use strict';
/**
 * Tuyến hệ thống: sống chưa, ai đang đăng nhập, bảng phân quyền,
 * tình hình cổng AI và kho đệm.
 *
 * /api/health cố ý KHÔNG đòi đăng nhập và cố ý nói thật cả khi hỏng —
 * một trang tình trạng luôn báo "tốt" thì vô dụng.
 */

const dap = require('../_lib/dap.js');
const quyen = require('../_lib/quyen.js');
const congAi = require('../_lib/cong-ai.js');
const { KhoNghia } = require('../_lib/kho-nghia.js');
const nhatKy = require('../_lib/nhat-ky.js');

const PHIEN_BAN = '13.0.0';

function dangKy(them) {
  them('GET', '/api/health', async (bc) => {
    const ra = { phienBan: PHIEN_BAN, luc: new Date(bc.bayGio()).toISOString(), bo_phan: {} };
    let lanh = true;

    try {
      const n = await bc.kho.dem('SELECT COUNT(*) FROM users');
      const b = await bc.kho.dem(
        "SELECT COUNT(*) FROM sqlite_master WHERE type='table'");
      ra.bo_phan.kho = { dat: true, soNguoiDung: n, soBang: b };
    } catch (e) {
      lanh = false;
      ra.bo_phan.kho = { dat: false, loi: 'Chưa gắn kho D1 hoặc chưa chạy di trú.' };
    }

    ra.bo_phan.kvNong = { dat: !!bc.moi.KV, ghiChu: bc.moi.KV ? '' : 'Chưa gắn KV — kho đệm chạy ở hai tầng.' };
    ra.bo_phan.r2TepLon = { dat: !!bc.moi.R2, ghiChu: bc.moi.R2 ? '' : 'Chưa gắn R2 — không tải lên tệp lớn được.' };
    ra.bo_phan.workersAi = { dat: !!bc.moi.AI };

    const coKhoa = ['GEMINI_API_KEY', 'GROQ_API_KEY', 'OPENROUTER_API_KEY',
      'TOGETHER_API_KEY', 'HF_API_KEY'].filter((k) => !!bc.moi[k]);
    ra.bo_phan.nhaAi = {
      dat: coKhoa.length > 0 || !!bc.moi.AI,
      soNhaCoKhoa: coKhoa.length + (bc.moi.AI ? 1 : 0),
      ghiChu: (coKhoa.length === 0 && !bc.moi.AI)
        ? 'Chưa cắm khoá nhà cung cấp nào — mọi tuyến cần AI sẽ báo lỗi thật chứ không trả câu giả.'
        : '',
    };

    ra.dat = lanh;
    return dap.json(ra, lanh ? 200 : 503);
  }, 'Tình trạng thật của từng bộ phận');

  them('GET', '/api', async (bc) => dap.json({
    ten: 'GITAV20nexus — tầng Cloudflare',
    phienBan: PHIEN_BAN,
    soDuong: bc.soDuong,
    nhom: bc.nhomTuyen,
    ghiChu: 'Mỗi nhóm gắn ở một tiền tố riêng. Gọi GET /api/duong để xem đủ.',
  }), 'Giới thiệu tầng API');

  them('GET', '/api/duong', async (bc) => dap.json({
    soDuong: bc.dsDuong.length,
    duong: bc.dsDuong,
  }), 'Liệt kê toàn bộ đường');

  them('GET', '/api/phan-quyen', async () =>
    dap.json(quyen.banPhanQuyen()), 'Bảng phân quyền đầy đủ');

  them('GET', '/api/ai/tinh-hinh', async (bc) => {
    const chan = bc.canQuyen('agents.read');
    if (chan) return chan;
    return dap.json(await congAi.tinhHinh(bc.kho, bc.moi, bc.bayGio()));
  }, 'Hạn mức còn lại của sáu nhà cung cấp');

  them('GET', '/api/dem/tinh-hinh', async (bc) => {
    const chan = bc.canQuyen('agents.read');
    if (chan) return chan;
    const kn = KhoNghia(bc.kho, bc.moi.KV, bc.bayGio);
    return dap.json(await kn.tinhHinh());
  }, 'Hiệu quả kho đệm ba tầng');

  them('GET', '/api/nhat-ky/soi', async (bc) => {
    const chan = bc.canQuyen('audit.read');
    if (chan) return chan;
    return dap.json(await nhatKy.soiChuoi(bc.kho));
  }, 'Soi lại chuỗi băm của nhật ký kiểm toán');
}

module.exports = { dangKy, PHIEN_BAN };
