'use strict';
/** Gia sư AI: hồ sơ học tập, luồng trò chuyện, chấm điểm câu trả lời, nhận xét. */

const dap = require('../_lib/dap.js');
const gs = require('../_lib/gia-su.js');
const { maMoi } = require('../_lib/ma.js');

const TRUONG_HO_SO = {
  learning_style: ['visual', 'auditory', 'kinesthetic', 'reading', 'balanced'],
  pace: ['slow', 'normal', 'fast'],
  depth_pref: ['overview', 'balanced', 'deep'],
  response_style: ['warm', 'direct', 'socratic', 'humorous'],
};
const TAM_TRANG_HOP_LE = ['focused', 'tired', 'frustrated', 'curious', 'bored'];

function dangKy(them) {
  them('GET', '/profile', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const h = await gs.hoSo(bc.kho, bc.nguoi.id, bc.bayGio());
    return dap.json({
      dat: true,
      hoSo: {
        cachHoc: h.learning_style, nhipDo: h.pace, doSau: h.depth_pref,
        tieng: h.preferred_lang, phongCach: h.response_style, muiGio: h.timezone,
        quanTam: gs.docMang(h.interests_json), mucTieu: gs.docMang(h.goals_json),
      },
      chonDuoc: TRUONG_HO_SO,
    });
  }, 'Hồ sơ học tập của mình');

  them('PATCH', '/profile', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const t = await bc.layThan();
    await gs.hoSo(bc.kho, bc.nguoi.id, bc.bayGio());
    const doi = {};
    const map = { cachHoc: 'learning_style', learningStyle: 'learning_style',
      nhipDo: 'pace', pace: 'pace', doSau: 'depth_pref', depthPref: 'depth_pref',
      phongCach: 'response_style', responseStyle: 'response_style' };
    for (const k of Object.keys(map)) {
      if (t[k] === undefined) continue;
      const cot = map[k];
      if (!TRUONG_HO_SO[cot].includes(String(t[k]))) {
        return dap.hong(400, 'gia-tri-khong-biet',
          cot + ' phải là một trong: ' + TRUONG_HO_SO[cot].join(', ') + '.');
      }
      doi[cot] = String(t[k]);
    }
    for (const [k, cot] of [['quanTam', 'interests_json'], ['mucTieu', 'goals_json']]) {
      if (t[k] === undefined) continue;
      if (!Array.isArray(t[k])) return dap.saiKieu(k, 'một mảng chuỗi');
      doi[cot] = JSON.stringify(t[k].slice(0, 12).map((x) => String(x).slice(0, 60)));
    }
    if (t.tieng !== undefined) doi.preferred_lang = String(t.tieng).slice(0, 8);
    if (Object.keys(doi).length === 0) {
      return dap.hong(400, 'khong-co-gi-doi', 'Không có trường nào để đổi.');
    }
    doi.updated_at = bc.bayGio();
    const cot = Object.keys(doi);
    await bc.kho.chay('UPDATE tutor_profiles SET ' + cot.map((c) => c + ' = ?').join(', ') +
      ' WHERE user_id = ?', cot.map((c) => doi[c]).concat([bc.nguoi.id]));
    return dap.json({ dat: true, daDoi: cot.filter((c) => c !== 'updated_at') });
  }, 'Sửa hồ sơ học tập');

  them('POST', '/threads', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const t = await bc.layThan();
    const ten = String(t.title || t.ten || '').trim().slice(0, 200) || 'Buổi học mới';
    const id = maMoi();
    const now = bc.bayGio();
    await bc.kho.chen('tutor_threads', {
      id, user_id: bc.nguoi.id, level_id: t.levelId || t.maBai || null,
      title: ten, status: 'active', message_count: 0, tokens_used: 0,
      created_at: now, updated_at: now,
    });
    return dap.json({ dat: true, id, ten }, 201);
  }, 'Mở một luồng trò chuyện mới');

  them('GET', '/threads', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const ds = await bc.kho.nhieu(
      'SELECT id, title, level_id, status, message_count, tokens_used, updated_at ' +
      "FROM tutor_threads WHERE user_id = ? AND status != 'deleted' " +
      'ORDER BY updated_at DESC LIMIT ?', [bc.nguoi.id, bc.soTu('soDong', 30, 1, 100)]);
    return dap.json({ dat: true, luong: ds.map((d) => ({
      id: d.id, ten: d.title, maBai: d.level_id, trangThai: d.status,
      soTinNhan: Number(d.message_count), theDaDung: Number(d.tokens_used),
      capNhat: Number(d.updated_at) })) });
  }, 'Các luồng của mình');

  them('GET', '/threads/:id/messages', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const l = await bc.kho.mot('SELECT user_id, status FROM tutor_threads WHERE id = ?',
      [bc.thamSo.id]);
    if (!l) return dap.khongThay('luồng');
    const oCua = bc.canLaChinhMinh(l.user_id);
    if (oCua) return oCua;
    const ds = await bc.kho.nhieu(
      'SELECT id, role, content, content_json, mood, model, provider, helpful_rating, created_at ' +
      'FROM tutor_messages WHERE thread_id = ? ORDER BY created_at ASC LIMIT ?',
      [bc.thamSo.id, bc.soTu('soDong', 100, 1, 200)]);
    return dap.json({ dat: true, soTinNhan: ds.length, tinNhan: ds.map((m) => ({
      id: m.id, vai: m.role, chu: m.content,
      kem: m.content_json ? JSON.parse(m.content_json) : null,
      tamTrang: m.mood, nha: m.provider, mauMay: m.model,
      diem: m.helpful_rating, luc: Number(m.created_at) })) });
  }, 'Toàn bộ tin nhắn trong một luồng');

  them('DELETE', '/threads/:id', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const l = await bc.kho.mot('SELECT user_id FROM tutor_threads WHERE id = ?', [bc.thamSo.id]);
    if (!l) return dap.khongThay('luồng');
    const oCua = bc.canLaChinhMinh(l.user_id);
    if (oCua) return oCua;
    // Đánh dấu xoá chứ không xoá hẳn: tin nhắn còn dùng để rút tín hiệu học tập.
    await bc.kho.chay("UPDATE tutor_threads SET status = 'deleted', updated_at = ? WHERE id = ?",
      [bc.bayGio(), bc.thamSo.id]);
    return dap.json({ dat: true, ghiChu: 'Luồng đã ẩn khỏi danh sách; tin nhắn vẫn giữ để đo tiến bộ.' });
  }, 'Ẩn một luồng');

  them('POST', '/chat', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const chanHm = await bc.canHanMuc('ai');
    if (chanHm) return chanHm;
    const t = await bc.layThan();
    const maLuong = String(t.threadId || t.maLuong || '');
    const cauHoi = String(t.message || t.cauHoi || '');
    if (!maLuong) return dap.thieu('maLuong');
    if (!cauHoi.trim()) return dap.thieu('cauHoi');
    if (cauHoi.length > gs.DAI_TIN_TOI_DA) {
      return dap.hong(400, 'cau-hoi-qua-dai',
        'Câu hỏi tối đa ' + gs.DAI_TIN_TOI_DA + ' ký tự.');
    }
    if (t.tamTrang && !TAM_TRANG_HOP_LE.includes(String(t.tamTrang))) {
      return dap.hong(400, 'tam-trang-khong-biet',
        'Tâm trạng phải là một trong: ' + TAM_TRANG_HOP_LE.join(', ') + '.');
    }
    const l = await bc.kho.mot('SELECT user_id, status FROM tutor_threads WHERE id = ?', [maLuong]);
    if (!l) return dap.khongThay('luồng');
    if (l.user_id !== bc.nguoi.id) {
      return dap.hong(403, 'khong-phai-luong-cua-minh', 'Luồng này thuộc tài khoản khác.');
    }
    if (l.status === 'deleted') {
      return dap.hong(409, 'luong-da-an', 'Luồng đã ẩn, mở luồng mới để học tiếp.');
    }

    const r = await gs.troChuyen(bc.kho, bc.moi, {
      userId: bc.nguoi.id, vai: bc.nguoi.vai, maLuong, cauHoi,
      tamTrang: t.userMood || t.tamTrang,
      tenBai: t.levelTitle || t.tenBai, noiDungBai: t.levelContent || t.noiDungBai,
      trangThai: t.userState || t.trangThai,
    }, bc.bayGio());

    if (!r.dat) {
      const maHttp = r.ma === 'ai-khong-goi-duoc' ? 502
        : r.ma === 'cau-hoi-bi-chan' ? 400 : 422;
      return dap.hong(maHttp, r.ma, r.loi,
        Object.assign({}, r.lyDo ? { lyDo: r.lyDo } : {},
          r.duongDaDi ? { duongDaDi: r.duongDaDi } : {}));
    }
    return dap.json(r);
  }, 'Hỏi gia sư một câu');

  them('POST', '/messages/:id/rate', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const t = await bc.layThan();
    const diem = Number(t.rating === undefined ? t.diem : t.rating);
    if (!Number.isInteger(diem) || diem < 1 || diem > 5) {
      return dap.hong(400, 'diem-ngoai-khoang', 'Điểm phải là số nguyên từ 1 đến 5.');
    }
    const m = await bc.kho.mot('SELECT user_id, role FROM tutor_messages WHERE id = ?',
      [bc.thamSo.id]);
    if (!m) return dap.khongThay('tin nhắn');
    const oCua = bc.canLaChinhMinh(m.user_id);
    if (oCua) return oCua;
    if (m.role !== 'assistant') {
      return dap.hong(400, 'chi-cham-cau-tra-loi', 'Chỉ chấm điểm câu trả lời của gia sư.');
    }
    await bc.kho.chay('UPDATE tutor_messages SET helpful_rating = ? WHERE id = ?',
      [diem, bc.thamSo.id]);
    if (diem <= 2) {
      await bc.kho.chen('tutor_signals', {
        id: maMoi(), user_id: m.user_id, signal_type: 'confusion',
        content_id: bc.thamSo.id, strength: (3 - diem) / 2,
        evidence_json: JSON.stringify({ diemNguoiHocCham: diem }), created_at: bc.bayGio(),
      });
    }
    return dap.json({ dat: true, diem });
  }, 'Chấm điểm một câu trả lời của gia sư');

  them('GET', '/insights', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const tuan = 7 * 24 * 3600 * 1000;
    const tu = bc.bayGio() - tuan;
    const th = await bc.kho.nhieu(
      'SELECT signal_type, COUNT(*) AS so, AVG(strength) AS manh FROM tutor_signals ' +
      'WHERE user_id = ? AND created_at > ? GROUP BY signal_type', [bc.nguoi.id, tu]);
    const l = await bc.kho.mot(
      'SELECT COUNT(*) AS soLuong, COALESCE(SUM(message_count),0) AS soTin, ' +
      '       COALESCE(SUM(tokens_used),0) AS the FROM tutor_threads ' +
      "WHERE user_id = ? AND status != 'deleted'", [bc.nguoi.id]);
    const d = await bc.kho.mot(
      'SELECT AVG(helpful_rating) AS tb, COUNT(helpful_rating) AS so FROM tutor_messages ' +
      'WHERE user_id = ? AND helpful_rating IS NOT NULL', [bc.nguoi.id]);

    const theoLoai = Object.fromEntries(th.map((x) => [x.signal_type,
      { so: Number(x.so), manhTrungBinh: Number(Number(x.manh).toFixed(3)) }]));
    const boiRoi = theoLoai.confusion ? theoLoai.confusion.so : 0;
    const namDuoc = theoLoai.mastery ? theoLoai.mastery.so : 0;

    return dap.json({
      dat: true,
      tuanQua: { tinHieu: theoLoai, soLanBoiRoi: boiRoi, soLanNamDuoc: namDuoc },
      tongCong: { soLuong: Number(l.soLuong), soTinNhan: Number(l.soTin),
        theDaDung: Number(l.the) },
      diemNguoiHocCham: d.so ? { trungBinh: Number(Number(d.tb).toFixed(2)),
        soLanCham: Number(d.so) } : null,
      nhanXet: boiRoi + namDuoc === 0
        ? 'Chưa đủ dữ liệu để nói gì — cần vài buổi học nữa.'
        : (boiRoi > namDuoc * 2
          ? 'Tuần này bối rối nhiều hơn nắm được. Nên hạ nhịp độ xuống "slow" trong hồ sơ.'
          : (namDuoc > boiRoi ? 'Tuần này nắm bài tốt. Có thể nâng độ sâu lên "deep".'
            : 'Nhịp học đang cân bằng.')),
    });
  }, 'Nhận xét tiến bộ dựa trên tín hiệu thật');
}

module.exports = { dangKy };
