'use strict';
/** Đóng góp cộng đồng: bảng xếp hạng, hồ sơ của mình, ghi nhận việc đã làm. */

const dap = require('../_lib/dap.js');
const uyTin = require('../_lib/uy-tin.js');

function dangKy(them) {
  them('GET', '/leaderboard', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const ds = await bc.kho.nhieu(
      'SELECT r.user_id, u.full_name, r.total_points, r.level, r.reviews_count, ' +
      '       r.edits_count, r.approvals_count, r.reputation_score ' +
      'FROM reputation_scores r LEFT JOIN users u ON u.id = r.user_id ' +
      'ORDER BY r.total_points DESC, r.updated_at ASC LIMIT ?',
      [bc.soTu('soDong', 100, 1, 100)]);
    return dap.json({
      dat: true,
      bang: ds.map((d, i) => ({
        hang: i + 1, cuaAi: d.user_id, ten: d.full_name || '(đã xoá)',
        diem: Number(d.total_points), bac: d.level,
        soLanSoat: Number(d.reviews_count), soLanSua: Number(d.edits_count),
        soLanDuocDuyet: Number(d.approvals_count),
        tiLeDuocDuyet: Number(Number(d.reputation_score).toFixed(3)),
      })),
    });
  }, 'Bảng xếp hạng đóng góp');

  them('GET', '/me', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const s = await bc.kho.mot('SELECT * FROM reputation_scores WHERE user_id = ?', [bc.nguoi.id]);
    const huy = await bc.kho.nhieu(
      'SELECT badge_code, metadata_json, earned_at FROM user_badges WHERE user_id = ? ' +
      'ORDER BY earned_at DESC', [bc.nguoi.id]);
    const gan = await bc.kho.nhieu(
      'SELECT event_type, content_type, content_id, points_delta, created_at ' +
      'FROM contribution_events WHERE user_id = ? ORDER BY created_at DESC LIMIT 20',
      [bc.nguoi.id]);
    const homNay = await uyTin.diemHomNay(bc.kho, bc.nguoi.id, bc.bayGio());
    return dap.json({
      dat: true,
      diem: s ? Number(s.total_points) : 0,
      bac: s ? s.level : 'newcomer',
      soLanSoat: s ? Number(s.reviews_count) : 0,
      soLanSua: s ? Number(s.edits_count) : 0,
      diemHomNay: homNay,
      tranNgay: uyTin.TRAN_NGAY,
      huyHieu: huy.map((h) => Object.assign({ ma: h.badge_code, luc: Number(h.earned_at) },
        h.metadata_json ? JSON.parse(h.metadata_json) : {})),
      ganDay: gan.map((g) => ({ loai: g.event_type, loaiNoiDung: g.content_type,
        maNoiDung: g.content_id, diem: Number(g.points_delta), luc: Number(g.created_at) })),
    });
  }, 'Điểm, huy hiệu và việc gần đây của mình');

  them('POST', '/record', async (bc) => {
    const chan = bc.canDangNhap();
    if (chan) return chan;
    const chanHm = await bc.canHanMuc('ghi');
    if (chanHm) return chanHm;
    const t = await bc.layThan();
    if (!t.eventType && !t.loai) return dap.thieu('loai');
    if (!t.contentType && !t.loaiNoiDung) return dap.thieu('loaiNoiDung');
    if (!t.contentId && !t.maNoiDung) return dap.thieu('maNoiDung');

    const choAi = t.targetUserId || t.choAi || bc.nguoi.id;
    const r = await uyTin.ghiDongGop(bc.kho, {
      nguoiGhi: bc.nguoi.id,
      choAi,
      loai: t.eventType || t.loai,
      loaiNoiDung: t.contentType || t.loaiNoiDung,
      maNoiDung: t.contentId || t.maNoiDung,
      lyDo: t.reason || t.lyDo,
      duocKiemDuyet: bc.canQuyen('content.moderate') === null,
    }, bc.bayGio());

    if (!r.dat) {
      const maHttp = r.ma === 'qua-tran-ngay' ? 429
        : r.ma === 'khong-du-quyen-ghi-ho' ? 403 : 400;
      return dap.hong(maHttp, r.ma, r.loi);
    }
    await bc.ghiNhatKy('dong-gop.ghi', choAi,
      { loai: t.eventType || t.loai, diem: r.diemCong });
    return dap.json(Object.assign({ dat: true }, r), 201);
  }, 'Ghi nhận một việc đóng góp');
}

module.exports = { dangKy };
