'use strict';
/**
 * Bộ não vận hành: 600 trợ lý chuyên môn, bảng nhiệm vụ, quy trình,
 * KPI, và hiến pháp.
 *
 * Đường giao việc ở đây KHÔNG gọi mô hình ngôn ngữ. Nó xếp việc vào
 * hàng và chọn người theo sức chứa còn lại — chọn người là việc của
 * số học, không phải việc của một câu nhắc.
 */

const dap = require('../_lib/dap.js');
const tc = require('../_lib/to-chuc.js');
const hp = require('../_lib/hien-phap.js');
const { maMoi } = require('../_lib/ma.js');

function dangKy(them) {
  them('GET', '/', async (bc) => {
    const chan = bc.canQuyen('brain.read');
    if (chan) return chan;
    const tong = await bc.kho.dem('SELECT COUNT(*) FROM tro_ly');
    const theoBan = await bc.kho.nhieu(
      'SELECT b.id, b.ten, b.nhiem_vu, b.so_tro_ly, b.truong_ban_id, ' +
      '       COUNT(t.id) AS thuc_te FROM ban_chuyen_mon b ' +
      'LEFT JOIN tro_ly t ON t.ban_id = b.id GROUP BY b.id ORDER BY b.so_tro_ly DESC');
    const theoVai = await bc.kho.nhieu(
      'SELECT vai, COUNT(*) AS so FROM tro_ly GROUP BY vai ORDER BY so DESC');
    const theoTt = await bc.kho.nhieu(
      'SELECT trang_thai, COUNT(*) AS so FROM tro_ly GROUP BY trang_thai');
    return dap.json({
      dat: true,
      tongTroLy: tong,
      khopBangKhai: theoBan.every((b) => Number(b.thuc_te) === Number(b.so_tro_ly)),
      ban: theoBan.map((b) => ({ ma: b.id, ten: b.ten, nhiemVu: b.nhiem_vu,
        soKhai: Number(b.so_tro_ly), soThucTe: Number(b.thuc_te), truongBan: b.truong_ban_id })),
      theoVai: theoVai.map((v) => ({ vai: v.vai, ten: tc.TEN_VAI[v.vai], so: Number(v.so) })),
      theoTrangThai: Object.fromEntries(theoTt.map((x) => [x.trang_thai, Number(x.so)])),
      goiLa: 'Gọi là trợ lý AI chuyên môn — không gọi là đại lý.',
    });
  }, 'Bộ máy 600 trợ lý: ban nào bao nhiêu người, vai nào bao nhiêu');

  them('GET', '/tro-ly', async (bc) => {
    const chan = bc.canQuyen('brain.read');
    if (chan) return chan;
    const dk = [], tham = [];
    for (const [q, cot] of [['ban', 'ban_id'], ['vai', 'vai'], ['trangThai', 'trang_thai']]) {
      const v = bc.url.searchParams.get(q);
      if (v) { dk.push(cot + ' = ?'); tham.push(v); }
    }
    const where = dk.length ? ' WHERE ' + dk.join(' AND ') : '';
    const ds = await bc.kho.nhieu(
      'SELECT id, ban_id, ten, vai, pham_vi, suc_chua_ngay, trang_thai FROM tro_ly' + where +
      ' ORDER BY id LIMIT ? OFFSET ?',
      tham.concat([bc.soTu('soDong', 50, 1, 100), bc.soTu('boQua', 0, 0)]));
    const tong = await bc.kho.dem('SELECT COUNT(*) FROM tro_ly' + where, tham);
    return dap.json({ dat: true, tong, so: ds.length, troLy: ds.map((d) => ({
      ma: d.id, ban: d.ban_id, ten: d.ten, vai: d.vai, tenVai: tc.TEN_VAI[d.vai],
      phamVi: d.pham_vi, sucChuaNgay: Number(d.suc_chua_ngay), trangThai: d.trang_thai })) });
  }, 'Danh sách trợ lý, lọc theo ban, vai, trạng thái');

  them('GET', '/bang-nhiem-vu', async (bc) => {
    const chan = bc.canQuyen('brain.read');
    if (chan) return chan;
    const ds = await bc.kho.nhieu('SELECT * FROM bang_nhiem_vu ORDER BY ban_id, ma');
    return dap.json({ dat: true, so: ds.length, nhiemVu: ds.map((d) => ({
      ma: d.ma, ten: d.ten, ban: d.ban_id, vaiLam: d.vai_lam,
      dauVao: JSON.parse(d.dau_vao_json), dauRa: JSON.parse(d.dau_ra_json),
      tieuChuanDat: d.tieu_chuan_dat, phutDuKien: Number(d.phut_du_kien),
      canNguoiDuyet: !!d.can_nguoi_duyet, cam: JSON.parse(d.cam_json) })) });
  }, 'Bảng nhiệm vụ: việc nào ai làm, thế nào là làm xong đúng');

  them('GET', '/quy-trinh', async (bc) => {
    const chan = bc.canQuyen('brain.read');
    if (chan) return chan;
    const ds = await bc.kho.nhieu('SELECT * FROM quy_trinh ORDER BY ma');
    return dap.json({ dat: true, so: ds.length, quyTrinh: ds.map((d) => ({
      ma: d.ma, ten: d.ten, mucDich: d.muc_dich, buoc: JSON.parse(d.buoc_json),
      dauRa: d.dau_ra, phienBan: d.phien_ban })) });
  }, 'Các quy trình vận hành');

  them('POST', '/giao-viec', async (bc) => {
    const chan = bc.canQuyen('brain.assign');
    if (chan) return chan;
    const t = await bc.layThan();
    const ma = String(t.nhiemVu || '');
    const nv = await bc.kho.mot('SELECT * FROM bang_nhiem_vu WHERE ma = ?', [ma]);
    if (!nv) return dap.khongThay('nhiệm vụ mã ' + ma);

    // Kiểm đầu vào đúng theo bảng nhiệm vụ, không nhận thiếu.
    const canCo = JSON.parse(nv.dau_vao_json);
    const dauVao = t.dauVao && typeof t.dauVao === 'object' ? t.dauVao : {};
    const thieu = canCo.filter((k) => dauVao[k] === undefined);
    if (thieu.length) {
      return dap.hong(400, 'thieu-dau-vao',
        'Nhiệm vụ ' + ma + ' cần đủ đầu vào: ' + canCo.join(', ') + '. Thiếu: ' + thieu.join(', ') + '.');
    }

    // Chọn người: trong ban, đúng vai, còn sức chứa hôm nay, ít việc nhất.
    const ngay = new Date(bc.bayGio()).toISOString().slice(0, 10);
    const ds = await bc.kho.nhieu(
      'SELECT t.id, t.suc_chua_ngay, COALESCE(k.viec_nhan, 0) AS da_nhan ' +
      'FROM tro_ly t LEFT JOIN kpi_tro_ly k ON k.tro_ly_id = t.id AND k.ngay = ? ' +
      "WHERE t.ban_id = ? AND t.vai = ? AND t.trang_thai IN ('ranh','dang-lam') " +
      'ORDER BY da_nhan ASC, t.id ASC', [ngay, nv.ban_id, nv.vai_lam]);
    const chon = ds.find((x) => Number(x.da_nhan) < Number(x.suc_chua_ngay));
    if (!chon) {
      return dap.hong(503, 'het-suc-chua',
        'Ban ' + nv.ban_id + ' đã kín việc hôm nay ở vai ' + nv.vai_lam + '. ' +
        'Việc để ở hàng chờ, không giao ép quá sức chứa.',
        { soNguoi: ds.length });
    }

    const id = maMoi();
    const now = bc.bayGio();
    await bc.kho.chen('viec_giao', {
      id, nhiem_vu_ma: ma, tro_ly_id: chon.id,
      quy_trinh_ma: t.quyTrinh ? String(t.quyTrinh) : null,
      buoc: t.buoc === undefined ? null : Number(t.buoc),
      dau_vao_json: JSON.stringify(dauVao),
      trang_thai: 'cho', uu_tien: t.uuTien === undefined ? 5 : Number(t.uuTien),
      giao_luc: now,
    });
    await bc.kho.chay(
      'INSERT INTO kpi_tro_ly (id, tro_ly_id, ngay, viec_nhan) VALUES (?, ?, ?, 1) ' +
      'ON CONFLICT(tro_ly_id, ngay) DO UPDATE SET viec_nhan = viec_nhan + 1',
      [maMoi(), chon.id, ngay]);
    await bc.ghiNhatKy('bo-nao.giao-viec', id, { nhiemVu: ma, troLy: chon.id });
    return dap.json({ dat: true, id, troLy: chon.id,
      canNguoiDuyet: !!nv.can_nguoi_duyet, phutDuKien: Number(nv.phut_du_kien) }, 201);
  }, 'Giao một việc cho trợ lý còn sức chứa');

  them('GET', '/viec', async (bc) => {
    const chan = bc.canQuyen('brain.read');
    if (chan) return chan;
    const tt = bc.url.searchParams.get('trangThai');
    const tham = [];
    let sql = 'SELECT * FROM viec_giao';
    if (tt) { sql += ' WHERE trang_thai = ?'; tham.push(tt); }
    sql += ' ORDER BY uu_tien DESC, giao_luc ASC LIMIT ?';
    tham.push(bc.soTu('soDong', 50, 1, 200));
    const ds = await bc.kho.nhieu(sql, tham);
    return dap.json({ dat: true, so: ds.length, viec: ds.map((d) => ({
      id: d.id, nhiemVu: d.nhiem_vu_ma, troLy: d.tro_ly_id, quyTrinh: d.quy_trinh_ma,
      buoc: d.buoc, trangThai: d.trang_thai, uuTien: Number(d.uu_tien),
      giaoLuc: Number(d.giao_luc), xongLuc: d.xong_luc ? Number(d.xong_luc) : null,
      lyDoTraLai: d.ly_do_tra_lai })) });
  }, 'Hàng việc hiện tại');

  them('POST', '/viec/:id/xong', async (bc) => {
    const chan = bc.canQuyen('brain.assign');
    if (chan) return chan;
    const t = await bc.layThan();
    const v = await bc.kho.mot('SELECT * FROM viec_giao WHERE id = ?', [bc.thamSo.id]);
    if (!v) return dap.khongThay('việc');
    if (v.trang_thai === 'xong') return dap.hong(409, 'da-xong', 'Việc này đã xong rồi.');
    const nv = await bc.kho.mot('SELECT can_nguoi_duyet FROM bang_nhiem_vu WHERE ma = ?',
      [v.nhiem_vu_ma]);
    const now = bc.bayGio();
    const canDuyet = nv && nv.can_nguoi_duyet;
    const moi = canDuyet ? 'cho-duyet' : 'xong';
    await bc.kho.chay(
      'UPDATE viec_giao SET trang_thai = ?, ket_qua_json = ?, xong_luc = ? WHERE id = ?',
      [moi, t.ketQua === undefined ? null : JSON.stringify(t.ketQua),
        canDuyet ? null : now, v.id]);
    if (!canDuyet) {
      const ngay = new Date(now).toISOString().slice(0, 10);
      await bc.kho.chay(
        'INSERT INTO kpi_tro_ly (id, tro_ly_id, ngay, viec_xong) VALUES (?, ?, ?, 1) ' +
        'ON CONFLICT(tro_ly_id, ngay) DO UPDATE SET viec_xong = viec_xong + 1',
        [maMoi(), v.tro_ly_id, ngay]);
    }
    return dap.json({ dat: true, id: v.id, trangThai: moi,
      ghiChu: canDuyet
        ? 'Nhiệm vụ này phải có một con người bấm duyệt — Điều 14 của hiến pháp vận hành.'
        : '' });
  }, 'Báo xong một việc');

  them('GET', '/kpi', async (bc) => {
    const chan = bc.canQuyen('brain.read');
    if (chan) return chan;
    const soNgay = bc.soTu('soNgay', 7, 1, 90);
    const tu = new Date(bc.bayGio() - soNgay * 86400000).toISOString().slice(0, 10);
    const tong = await bc.kho.mot(
      'SELECT COALESCE(SUM(viec_nhan),0) AS nhan, COALESCE(SUM(viec_xong),0) AS xong, ' +
      'COALESCE(SUM(viec_tra_lai),0) AS tra FROM kpi_tro_ly WHERE ngay >= ?', [tu]);
    const theoBan = await bc.kho.nhieu(
      'SELECT t.ban_id, SUM(k.viec_nhan) AS nhan, SUM(k.viec_xong) AS xong ' +
      'FROM kpi_tro_ly k JOIN tro_ly t ON t.id = k.tro_ly_id ' +
      'WHERE k.ngay >= ? GROUP BY t.ban_id ORDER BY nhan DESC', [tu]);
    const nhan = Number(tong.nhan), xong = Number(tong.xong);
    return dap.json({
      dat: true, soNgay, tuNgay: tu,
      tong: { viecNhan: nhan, viecXong: xong, viecTraLai: Number(tong.tra),
        tiLeXong: nhan ? Number((xong / nhan).toFixed(4)) : null },
      theoBan: theoBan.map((b) => ({ ban: b.ban_id, nhan: Number(b.nhan),
        xong: Number(b.xong) })),
      duLieuThat: nhan > 0,
      ghiChu: nhan === 0 ? 'Chưa có việc nào được giao nên chưa có KPI để đo.' : '',
    });
  }, 'KPI theo ngày, đo bằng số việc thật');

  them('GET', '/hien-phap', async (bc) => {
    const ds = await bc.kho.nhieu('SELECT * FROM hien_phap ORDER BY dieu');
    const ban = hp.ban();
    return dap.json({
      dat: true,
      soDieu: ds.length || ban.soDieu,
      dieu: (ds.length ? ds.map((d) => ({
        dieu: Number(d.dieu), ten: d.ten, noiDung: d.noi_dung,
        canCu: JSON.parse(d.can_cu_json), viPhamThi: d.vi_pham_thi,
      })) : ban.dieu),
      nguonPhapLy: ban.nguonPhapLy,
      luuY: ban.luuY,
    });
  }, 'Hiến pháp vận hành và căn cứ pháp lý của từng điều');

  them('GET', '/vi-pham', async (bc) => {
    const chan = bc.canQuyen('audit.read');
    if (chan) return chan;
    const ds = await bc.kho.nhieu(
      'SELECT * FROM vi_pham_hien_phap ORDER BY at DESC LIMIT ?',
      [bc.soTu('soDong', 50, 1, 200)]);
    return dap.json({ dat: true, so: ds.length, viPham: ds.map((d) => ({
      dieu: Number(d.dieu), troLy: d.tro_ly_id, nguoi: d.user_id,
      bangChung: JSON.parse(d.bang_chung_json), xuLy: d.xu_ly, luc: Number(d.at) })) });
  }, 'Các vi phạm hiến pháp đã ghi nhận');

  them('POST', '/vi-pham', async (bc) => {
    const chan = bc.canQuyen('audit.read');
    if (chan) return chan;
    const t = await bc.layThan();
    const dieu = Number(t.dieu);
    const co = hp.DIEU.find((d) => d.dieu === dieu);
    if (!co) return dap.hong(400, 'dieu-khong-co', 'Hiến pháp không có điều số ' + t.dieu + '.');
    if (!t.bangChung) return dap.thieu('bangChung');
    const id = maMoi();
    await bc.kho.chen('vi_pham_hien_phap', {
      id, dieu, tro_ly_id: t.troLy || null, user_id: t.nguoi || null,
      bang_chung_json: JSON.stringify(t.bangChung),
      xu_ly: co.vi_pham_thi, at: bc.bayGio(),
    });
    await bc.ghiNhatKy('hien-phap.vi-pham', id, { dieu });
    return dap.json({ dat: true, id, dieu, ten: co.ten, xuLy: co.vi_pham_thi }, 201);
  }, 'Ghi nhận một vi phạm hiến pháp');
}

module.exports = { dangKy };
