'use strict';
/**
 * Tuyến bảo mật và bộ não — nguồn số liệu của Bảng quản trị tổng.
 *
 * Mọi đường ở đây đòi quyền quản trị, trừ một đường: /lop trả về danh
 * sách hai mươi hai lớp canh kèm lời khai lớp nào làm ĐỦ, lớp nào
 * không. Đường ấy mở cho mọi người đọc được, cố ý — một hệ nói rõ giới
 * hạn của chính nó thì đáng tin hơn một hệ chỉ khoe con số 22/22.
 */

const dap = require('../_lib/dap.js');
const baoMat = require('../_lib/bao-mat.js');
const boNao = require('../_lib/bo-nao-trung-tam.js');
const { maMoi, sha256, chuoiNgauNhien } = require('../_lib/ma.js');

const LOAI_CHAN = ['ip', 'tai-khoan', 'dai-chi-thu', 'dau-van-tay'];

function dangKy(them) {
  them('GET', '/lop', async () => {
    const b = baoMat.banLop();
    return dap.json(Object.assign({ dat: true }, b));
  }, 'Hai mươi hai lớp canh, kèm lời khai lớp nào chưa làm đủ');

  them('GET', '/tinh-hinh', async (bc) => {
    const chan = bc.canQuyen('audit.read');
    if (chan) return chan;
    const gio = bc.soTu('soGio', 24, 1, 720);
    const nao = await boNao.tinhHinh(bc.kho, bc.bayGio(), gio);
    const chanGanDay = await bc.kho.nhieu(
      'SELECT lop, giai_doan, ly_do, duong_dan, ip, user_id, at FROM nhat_ky_chan ' +
      'WHERE at > ? ORDER BY at DESC LIMIT 50', [bc.bayGio() - gio * 3600000]);
    const dangChan = await bc.kho.dem(
      'SELECT COUNT(*) FROM danh_sach_chan WHERE chan_den IS NULL OR chan_den > ?',
      [bc.bayGio()]);
    return dap.json({
      dat: true,
      boNao: nao,
      soMucDangChan: dangChan,
      chanGanDay: chanGanDay.map((c) => ({
        lop: c.lop, giaiDoan: c.giai_doan, lyDo: c.ly_do,
        duongDan: c.duong_dan, ip: c.ip, nguoi: c.user_id, luc: Number(c.at),
      })),
      lop: baoMat.banLop(),
    });
  }, 'Tình hình bộ não và lớp canh trong khoảng giờ');

  them('GET', '/lenh', async (bc) => {
    const chan = bc.canQuyen('audit.read');
    if (chan) return chan;
    const tt = bc.url.searchParams.get('trangThai');
    const tham = [];
    let sql = 'SELECT * FROM lenh_bo_nao';
    if (tt) { sql += ' WHERE trang_thai = ?'; tham.push(tt); }
    sql += ' ORDER BY at DESC LIMIT ?';
    tham.push(bc.soTu('soDong', 50, 1, 200));
    const ds = await bc.kho.nhieu(sql, tham);
    return dap.json({ dat: true, so: ds.length, lenh: ds.map((l) => ({
      id: l.id, loai: l.loai, uuTien: l.uu_tien, nguoi: l.user_id, vai: l.vai,
      duongDan: l.duong_dan, trangThai: l.trang_thai, chanTai: l.chan_tai,
      banGiao: l.ban_giao_json ? JSON.parse(l.ban_giao_json) : null,
      thanhTra: l.soi_json ? JSON.parse(l.soi_json) : null,
      ms: Number(l.ms), luc: Number(l.at) })) });
  }, 'Sổ lệnh đã đi qua bộ não');

  them('GET', '/danh-sach-chan', async (bc) => {
    const chan = bc.canQuyen('audit.read');
    if (chan) return chan;
    const ds = await bc.kho.nhieu(
      'SELECT * FROM danh_sach_chan ORDER BY created_at DESC LIMIT ?',
      [bc.soTu('soDong', 100, 1, 200)]);
    return dap.json({ dat: true, so: ds.length, muc: ds.map((d) => ({
      id: d.id, loai: d.loai, giaTri: d.gia_tri, lyDo: d.ly_do, lopBat: d.lop_bat,
      chanDen: d.chan_den ? Number(d.chan_den) : null,
      vinhVien: !d.chan_den, luc: Number(d.created_at) })) });
  }, 'Danh sách đang bị chặn');

  them('POST', '/danh-sach-chan', async (bc) => {
    const chan = bc.canQuyen('user.disable');
    if (chan) return chan;
    const t = await bc.layThan();
    const loai = String(t.loai || '');
    if (!LOAI_CHAN.includes(loai)) {
      return dap.hong(400, 'loai-chan-khong-biet',
        'Loại chặn phải là một trong: ' + LOAI_CHAN.join(', ') + '.');
    }
    const gt = String(t.giaTri || '').trim();
    if (!gt) return dap.thieu('giaTri');
    const lyDo = String(t.lyDo || '').trim();
    if (lyDo.length < 15) {
      return dap.hong(400, 'thieu-ly-do',
        'Chặn một địa chỉ hay một tài khoản phải nêu lý do từ 15 ký tự. '
        + 'Chặn nhầm một người dùng thật là thiệt hại có thật, nên phải nói được vì sao.');
    }
    if (loai === 'tai-khoan' && gt === bc.nguoi.id) {
      return dap.hong(400, 'tu-chan-minh', 'Không tự chặn tài khoản của mình được.');
    }
    await bc.kho.chay(
      'INSERT INTO danh_sach_chan (id, loai, gia_tri, ly_do, lop_bat, chan_den, nguoi_chan, created_at) ' +
      'VALUES (?, ?, ?, ?, ?, ?, ?, ?) ' +
      'ON CONFLICT(loai, gia_tri) DO UPDATE SET ly_do = excluded.ly_do, ' +
      '  chan_den = excluded.chan_den, nguoi_chan = excluded.nguoi_chan',
      [maMoi(), loai, gt, lyDo, t.lopBat ? String(t.lopBat) : null,
        t.chanDen ? Number(t.chanDen) : null, bc.nguoi.id, bc.bayGio()]);
    await bc.ghiNhatKy('bao-mat.chan', gt, { loai, lyDo });
    return dap.json({ dat: true, loai, giaTri: gt,
      vinhVien: !t.chanDen }, 201);
  }, 'Chặn một địa chỉ hoặc một tài khoản, bắt buộc nêu lý do');

  them('DELETE', '/danh-sach-chan/:id', async (bc) => {
    const chan = bc.canQuyen('user.disable');
    if (chan) return chan;
    const n = await bc.kho.xoa('danh_sach_chan', bc.thamSo.id);
    if (!n) return dap.khongThay('mục chặn');
    await bc.ghiNhatKy('bao-mat.bo-chan', bc.thamSo.id, null);
    return dap.json({ dat: true });
  }, 'Bỏ chặn một mục');

  them('POST', '/khoa-ky', async (bc) => {
    const chan = bc.canQuyen('user.create');
    if (chan) return chan;
    const t = await bc.layThan();
    const ten = String(t.ten || '').trim();
    if (!ten) return dap.thieu('ten');
    // Khoá sinh ở đây và CHỈ hiện đúng một lần. Kho giữ băm, không giữ khoá.
    const khoa = 'gk_' + chuoiNgauNhien(32);
    const id = maMoi();
    await bc.kho.chen('khoa_ky', {
      id, ten, bam_khoa: await sha256(khoa),
      pham_vi_json: JSON.stringify(Array.isArray(t.phamVi) ? t.phamVi.map(String) : []),
      het_han: t.hetHan ? Number(t.hetHan) : null,
      nguoi_tao: bc.nguoi.id, created_at: bc.bayGio(),
    });
    await bc.ghiNhatKy('bao-mat.tao-khoa-ky', id, { ten });
    return dap.json({ dat: true, id, khoa,
      canhBao: 'Khoá này chỉ hiện đúng một lần. Kho chỉ giữ băm của nó, '
        + 'nên mất thì không lấy lại được — phải tạo khoá mới và thu hồi khoá cũ.' }, 201);
  }, 'Tạo một khoá ký cho lệnh máy-gọi-máy');

  them('POST', '/khoa-ky/:id/thu-hoi', async (bc) => {
    const chan = bc.canQuyen('user.create');
    if (chan) return chan;
    const r = await bc.kho.chay(
      'UPDATE khoa_ky SET thu_hoi_luc = ? WHERE id = ? AND thu_hoi_luc IS NULL',
      [bc.bayGio(), bc.thamSo.id]);
    const n = (r && r.meta && r.meta.changes) || 0;
    if (!n) return dap.khongThay('khoá ký còn hiệu lực');
    await bc.ghiNhatKy('bao-mat.thu-hoi-khoa-ky', bc.thamSo.id, null);
    return dap.json({ dat: true });
  }, 'Thu hồi một khoá ký');

  them('GET', '/khoa-ky', async (bc) => {
    const chan = bc.canQuyen('user.read');
    if (chan) return chan;
    const ds = await bc.kho.nhieu(
      'SELECT id, ten, pham_vi_json, het_han, thu_hoi_luc, created_at, dung_lan_cuoi ' +
      'FROM khoa_ky ORDER BY created_at DESC LIMIT 100');
    return dap.json({ dat: true, so: ds.length, khoa: ds.map((k) => ({
      id: k.id, ten: k.ten, phamVi: JSON.parse(k.pham_vi_json),
      hetHan: k.het_han ? Number(k.het_han) : null,
      daThuHoi: !!k.thu_hoi_luc, dungLanCuoi: k.dung_lan_cuoi ? Number(k.dung_lan_cuoi) : null,
      tao: Number(k.created_at) })) });
  }, 'Danh sách khoá ký — không bao giờ trả về chính khoá');

  them('GET', '/nep/:userId', async (bc) => {
    const chan = bc.canQuyen('audit.read');
    if (chan) return chan;
    const n = await bc.kho.mot('SELECT * FROM nep_tai_khoan WHERE user_id = ?',
      [bc.thamSo.userId]);
    if (!n) {
      return dap.json({ dat: true, coNep: false,
        ghiChu: 'Chưa đủ lượt để dựng nếp thường ngày cho tài khoản này.' });
    }
    return dap.json({ dat: true, coNep: true,
      soLuot: Number(n.so_luot),
      theoGio: JSON.parse(n.gio_hay_dung || '{}'),
      nuocHayVao: n.nuoc_hay_vao,
      capNhat: Number(n.cap_nhat),
      dungDeLam: 'So hôm nay với nếp này. Lệch thì ĐÁNH DẤU để xem lại, '
        + 'không chặn — một hôm làm việc khác thường không phải một cuộc tấn công.' });
  }, 'Nếp thường ngày của một tài khoản');
}

module.exports = { dangKy };
