'use strict';
/**
 * Đo sức tiên đoán của chỉ báo học tập, và kiểm nghiệm ngược các ngưỡng.
 *
 * Đây là tầng biến những con số ĐƯỢC KHAI thành những con số ĐO ĐƯỢC.
 * Ngưỡng vượt cấp 90% trên 60 bài là một lời khai; tới khi nào dựng lại
 * được cảnh cũ và thấy nó dự báo đúng thì nó mới là một phép đo.
 *
 * Mọi đường ở đây đều tốn nhiều lượt đọc kho, nên đều đòi quyền quản trị
 * và đều chịu hạn mức.
 */

const dap = require('../_lib/dap.js');
const dtt = require('../_lib/do-tin-hieu.js');
const knn = require('../_lib/kiem-nghiem-nguoc.js');

const NGAY = 86400000;

function docKhoang(bc) {
  const soNgay = bc.soTu('soNgay', 180, 30, 1095);
  const den = bc.bayGio();
  return { tu: den - soNgay * NGAY, den, soNgay };
}

function dangKy(them) {
  them('GET', '/chi-bao', async () => dap.json({
    dat: true,
    so: dtt.CHI_BAO.length,
    chanTroi: dtt.CHAN_TROI,
    mauToiThieu: dtt.MAU_TOI_THIEU,
    mauDeTin: dtt.MAU_DE_TIN,
    chiBao: dtt.CHI_BAO.map((c) => ({
      ma: c.ma, ten: c.ten, y: c.y,
      chieu: c.chieu, chieuDoc: c.chieu > 0 ? 'cao thì tốt' : 'cao thì xấu',
    })),
    cachDo: 'Tương quan HẠNG giữa chỉ báo đo TRƯỚC một mốc và kết quả xảy ra SAU mốc ấy. '
      + 'Dùng hạng vì quan hệ hiếm khi thẳng, nhưng thứ tự thì có nghĩa. '
      + 'Mỗi hệ số đi kèm khoảng tin cậy; khoảng còn chứa số không nghĩa là chưa nói được gì.',
  }), 'Mười hai chỉ báo học tập và cách đo chúng');

  them('GET', '/suc-tien-doan', async (bc) => {
    const chan = bc.canQuyen('analytics.read');
    if (chan) return chan;
    const hm = await bc.canHanMuc('doc');
    if (hm) return hm;
    const k = docKhoang(bc);
    const mau = await knn.layMau(bc.kho, k.tu, k.den, bc.soTu('buocNgay', 7, 1, 30));
    if (!mau.length) {
      return dap.json({ dat: true, coDuLieu: false, khoang: k,
        noiThang: 'Không có lượt làm bài nào trong khoảng này nên không đo được gì. '
          + 'Đây là câu trả lời đúng, không phải lỗi.' });
    }
    const daDo = await dtt.doTatCa(bc.kho, mau);
    const dungDuoc = daDo.filter((d) => d.dungDuoc);
    return dap.json({
      dat: true, coDuLieu: true, khoang: k, soMau: mau.length,
      chiBao: daDo,
      soChiBaoDungDuoc: dungDuoc.length,
      xepHang: dungDuoc
        .slice()
        .sort((a, b) => Math.abs(b.ir || 0) - Math.abs(a.ir || 0))
        .map((d) => ({ ma: d.ma, ten: d.ten, ir: d.ir, icTrungBinh: d.icTrungBinh,
          suyGiam: d.suyGiam })),
      noiThang: dungDuoc.length === 0
        ? 'Không chỉ báo nào chứng minh được sức tiên đoán trên dữ liệu hiện có. '
          + 'Thường là vì chưa đủ mẫu, chứ không phải vì chỉ báo sai — nhưng chưa chứng '
          + 'minh được thì vẫn là chưa chứng minh được.'
        : dungDuoc.length + '/' + daDo.length + ' chỉ báo có sức tiên đoán đo được. '
          + 'Số còn lại chưa đủ bằng chứng và đang để trọng số bằng không.',
    });
  }, 'Đo sức tiên đoán của từng chỉ báo, có khoảng tin cậy');

  them('POST', '/kiem-nguong', async (bc) => {
    const chan = bc.canQuyen('roadmap.manage');
    if (chan) return chan;
    const hm = await bc.canHanMuc('doc');
    if (hm) return hm;
    const t = await bc.layThan();
    const tiLe = Number(t.tiLe === undefined ? 0.9 : t.tiLe);
    const soBai = Number(t.soBaiToiThieu === undefined ? 60 : t.soBaiToiThieu);
    if (!(tiLe > 0 && tiLe <= 1)) {
      return dap.hong(400, 'ti-le-ngoai-khoang', 'Tỉ lệ phải trong khoảng lớn hơn 0 tới 1.');
    }
    if (!Number.isInteger(soBai) || soBai < 1) {
      return dap.hong(400, 'so-bai-sai', 'Số bài tối thiểu là số nguyên từ 1.');
    }
    const k = docKhoang(bc);
    const mau = await knn.layMau(bc.kho, k.tu, k.den, 7);
    const r = await knn.thuNguong(bc.kho, mau,
      { tiLe, soBaiToiThieu: soBai },
      { tiLeSau: Number(t.tiLeSau === undefined ? 0.85 : t.tiLeSau) },
      Number(t.soNgaySau === undefined ? 30 : t.soNgaySau));
    return dap.json(Object.assign({ dat: true, khoang: k, soMauDauVao: mau.length }, r));
  }, 'Thử một ngưỡng vượt cấp trên dữ liệu đã có');

  them('POST', '/quet-nguong', async (bc) => {
    const chan = bc.canQuyen('roadmap.manage');
    if (chan) return chan;
    const hm = await bc.canHanMuc('doc');
    if (hm) return hm;
    const t = await bc.layThan();
    const dai = Array.isArray(t.dai) && t.dai.length
      ? t.dai.map(Number).filter((x) => x > 0 && x <= 1)
      : [0.7, 0.75, 0.8, 0.85, 0.9, 0.95];
    const k = docKhoang(bc);
    const mau = await knn.layMau(bc.kho, k.tu, k.den, 7);
    const r = await knn.quetDaiNguong(bc.kho, mau, dai,
      Number(t.soBaiToiThieu === undefined ? 60 : t.soBaiToiThieu),
      { tiLeSau: Number(t.tiLeSau === undefined ? 0.85 : t.tiLeSau) },
      Number(t.soNgaySau === undefined ? 30 : t.soNgaySau));
    return dap.json(Object.assign({ dat: true, khoang: k, soMauDauVao: mau.length }, r));
  }, 'Quét cả dải ngưỡng và bày ra số đo của từng mức');

  them('POST', '/hoc-truoc-kiem-sau', async (bc) => {
    const chan = bc.canQuyen('roadmap.manage');
    if (chan) return chan;
    const hm = await bc.canHanMuc('doc');
    if (hm) return hm;
    const t = await bc.layThan();
    const k = docKhoang(bc);
    const r = await knn.hocTruocKiemSau(bc.kho, k.tu, k.den,
      Array.isArray(t.dai) && t.dai.length ? t.dai.map(Number) : [0.7, 0.75, 0.8, 0.85, 0.9, 0.95],
      Number(t.soBaiToiThieu === undefined ? 60 : t.soBaiToiThieu),
      { tiLeSau: Number(t.tiLeSau === undefined ? 0.85 : t.tiLeSau) },
      Number(t.soNgaySau === undefined ? 30 : t.soNgaySau));
    return dap.json(Object.assign({ dat: true, khoang: k }, r));
  }, 'Chọn ngưỡng trên nửa đầu rồi kiểm trên nửa sau');

  them('POST', '/thu-tinh-huong', async (bc) => {
    const chan = bc.canQuyen('roadmap.manage');
    if (chan) return chan;
    const t = await bc.layThan();
    const k = docKhoang(bc);
    const mau = await knn.layMau(bc.kho, k.tu, k.den, 7);
    const r = await knn.thuTinhHuong(bc.kho, mau,
      { tiLe: Number(t.tiLe === undefined ? 0.9 : t.tiLe),
        soBaiToiThieu: Number(t.soBaiToiThieu === undefined ? 60 : t.soBaiToiThieu) },
      { tiLeSau: Number(t.tiLeSau === undefined ? 0.85 : t.tiLeSau) },
      Number(t.soNgaySau === undefined ? 30 : t.soNgaySau),
      Number(t.giuLai === undefined ? 0.5 : t.giuLai));
    return dap.json(Object.assign({ dat: true, khoang: k,
      cachLam: 'Bớt bớt dữ liệu thật đi rồi xem ngưỡng còn đứng không. '
        + 'Không sinh dữ liệu giả — bớt đi thì không bịa gì cả.' }, r));
  }, 'Thử ngưỡng khi chỉ còn một phần dữ liệu');

  them('GET', '/diem-gop/:userId', async (bc) => {
    const chan = bc.canLaChinhMinh(bc.thamSo.userId, 'analytics.read');
    if (chan) return chan;
    const k = docKhoang(bc);
    const mau = await knn.layMau(bc.kho, k.tu, k.den, 7);
    const daDo = await dtt.doTatCa(bc.kho, mau);
    const moc = bc.bayGio();
    const giaTri = {};
    for (const cb of dtt.CHI_BAO) {
      giaTri[cb.ma] = await cb.tinh(bc.kho, bc.thamSo.userId, moc);
    }
    const gop = dtt.gopDiem(daDo, giaTri);
    return dap.json({
      dat: true, userId: bc.thamSo.userId, moc,
      giaTriChiBao: giaTri,
      gop,
      luuY: 'Điểm gộp chỉ dùng để xếp thứ tự ưu tiên chú ý, KHÔNG dùng để quyết định '
        + 'mở cấp. Mở cấp đi qua điều kiện vượt cấp, và điều kiện ấy là dữ liệu chứ '
        + 'không phải một điểm số tổng hợp.',
    });
  }, 'Điểm gộp của một người học, trọng số theo IR đo được');
}

module.exports = { dangKy };
