'use strict';
/**
 * Sáu nhà cung cấp AI: còn bao nhiêu hạn mức, nhà nào đang hỏng,
 * đường chuyển tiếp đã đi qua những đâu.
 *
 * Trang này là thứ đầu tiên phải mở khi trợ lý AI im lặng, nên nó
 * không được nói dối: nhà chưa cắm khoá hiện đúng là chưa cắm khoá.
 */

const dap = require('../_lib/dap.js');
const congAi = require('../_lib/cong-ai.js');

function dangKy(them) {
  them('GET', '/status', async (bc) => {
    const chan = bc.canQuyen('agents.read');
    if (chan) return chan;
    const t = await congAi.tinhHinh(bc.kho, bc.moi, bc.bayGio());
    const sanSang = t.nha.filter((n) => n.coKhoa && n.conLai > 0 && n.tinhTrang !== 'down');
    return dap.json({
      dat: true,
      ngay: t.ngay,
      nha: t.nha,
      soNhaSanSang: sanSang.length,
      tongLuotConLai: t.tongConLai,
      canhBao: sanSang.length === 0
        ? 'Không nhà nào còn gọi được. Mọi tuyến cần AI sẽ trả lỗi 502 cho đến khi cắm thêm khoá hoặc sang ngày mới.'
        : (sanSang.length === 1
          ? 'Chỉ còn một nhà. Nhà ấy hỏng là mất hẳn phần AI — nên cắm thêm khoá dự phòng.'
          : ''),
    });
  }, 'Hạn mức và sức khoẻ của từng nhà cung cấp');

  them('GET', '/fallback-stats', async (bc) => {
    const chan = bc.canQuyen('agents.read');
    if (chan) return chan;
    const ngay = bc.soTu('soNgay', 7, 1, 90);
    const tu = congAi.ngayCua(bc.bayGio() - ngay * 86400000);
    const ds = await bc.kho.nhieu(
      'SELECT provider_code, SUM(requests_count) AS goi, SUM(failures_count) AS hong, ' +
      '       SUM(tokens_input) AS theVao, SUM(tokens_output) AS theRa, ' +
      '       AVG(avg_latency_ms) AS tre ' +
      'FROM ai_provider_usage WHERE day >= ? GROUP BY provider_code ORDER BY goi DESC', [tu]);

    const tong = ds.reduce((t, x) => t + Number(x.goi || 0), 0);
    return dap.json({
      dat: true, soNgay: ngay, tuNgay: tu, tongLuotGoi: tong,
      theoNha: ds.map((x) => {
        const goi = Number(x.goi || 0);
        const hong = Number(x.hong || 0);
        return {
          nha: x.provider_code,
          luotGoi: goi,
          luotHong: hong,
          tiLeHong: goi ? Number((hong / goi).toFixed(4)) : 0,
          tyTrong: tong ? Number((goi / tong).toFixed(4)) : 0,
          theVao: Number(x.theVao || 0),
          theRa: Number(x.theRa || 0),
          treTrungBinhMs: Math.round(Number(x.tre || 0)),
        };
      }),
      ghiChu: 'Tỷ trọng cao ở một nhà nghĩa là các nhà đứng trước nó trong thứ tự ' +
        'đang hỏng hoặc hết hạn mức — xem /status để biết nhà nào.',
    });
  }, 'Thống kê chuyển tiếp giữa các nhà');

  them('GET', '/suc-khoe-gan-day', async (bc) => {
    const chan = bc.canQuyen('agents.read');
    if (chan) return chan;
    const ds = await bc.kho.nhieu(
      'SELECT provider_code, status, latency_ms, error_msg, checked_at ' +
      'FROM ai_provider_health ORDER BY checked_at DESC LIMIT ?',
      [bc.soTu('soDong', 50, 1, 200)]);
    return dap.json({ dat: true, danhSach: ds });
  }, 'Nhật ký sức khoẻ gần đây của các nhà');
}

module.exports = { dangKy };
