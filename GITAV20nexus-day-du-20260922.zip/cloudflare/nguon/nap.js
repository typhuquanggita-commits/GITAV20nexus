'use strict';
/**
 * Bảng nhóm tuyến — SINH TỰ ĐỘNG bởi tao-nap.js, đừng sửa tay.
 * Chạy lại:  node cloudflare/nguon/tao-nap.js
 */

const nhomTuyen = {
  'he-thong': require('./tuyen/he-thong.js'),
  'tai-khoan': require('./tuyen/tai-khoan.js'),
  'nha-cung-cap': require('./tuyen/nha-cung-cap.js'),
  'dong-bo': require('./tuyen/dong-bo.js'),
  'dong-gop': require('./tuyen/dong-gop.js'),
  'dich': require('./tuyen/dich.js'),
  'gia-su': require('./tuyen/gia-su.js'),
  'chuong-trinh': require('./tuyen/chuong-trinh.js'),
  'kho-bai': require('./tuyen/kho-bai.js'),
  'luyen-thi': require('./tuyen/luyen-thi.js'),
  'khao-sat': require('./tuyen/khao-sat.js'),
  'lo-trinh': require('./tuyen/lo-trinh.js'),
  'trai': require('./tuyen/trai.js'),
  'bo-nao': require('./tuyen/bo-nao.js'),
  'crm': require('./tuyen/crm.js'),
  'ke-toan': require('./tuyen/ke-toan.js'),
  'chuoi-video': require('./tuyen/chuoi-video.js'),
  'bao-mat': require('./tuyen/bao-mat.js'),
  'tong': require('./tuyen/tong.js'),
  'tin-hieu': require('./tuyen/tin-hieu.js'),
};

module.exports = { nhomTuyen };
