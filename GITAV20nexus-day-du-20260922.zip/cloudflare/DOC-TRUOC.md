# Đưa GITAmath lên Cloudflare

## CHỌN ĐÚNG GÓI — đọc mục này trước

`npm run zip` xuất ra HAI gói, và tên của chúng nói thẳng việc:

| Tên gói | Dùng để |
|---|---|
| `TAI-LEN-CLOUDFLARE-<ngày>.zip` | **Gói này** — kéo thả vào ô tải lên của Cloudflare |
| `KHONG-TAI-LEN-CLOUDFLARE--ma-nguon-<ngày>.zip` | Mã nguồn — giải nén ở máy mình, KHÔNG tải lên |

Tải nhầm gói mã nguồn lên thì hai chuyện xảy ra: Cloudflare từ chối
`wrangler.toml` và dừng giữa chừng; còn nếu nó không từ chối thì toàn bộ mã
nguồn và `.env.example` sẽ nằm trên một trang web công khai.

Hai kịch bản `npm run cloudflare` và `npm run zip` đều soi và **từ chối
hoàn tất** nếu gói tĩnh mang một tệp thuộc sáu loại bị cấm.

## Ba cách đưa lên, chọn một

**1. Kéo thả (không cần cài gì)** — Cloudflare → Workers & Pages → Create →
Upload static files, rồi thả nguyên gói `TAI-LEN-CLOUDFLARE-<ngày>.zip`.

**2. Dòng lệnh, không cần tệp cấu hình:**
```bash
npx wrangler pages deploy cloudflare/dist --project-name gitamath
```

**3. Dòng lệnh, dùng tệp cấu hình sẵn có:**
```bash
cd cloudflare && npx wrangler pages deploy
```
(`wrangler.toml` nằm ở `cloudflare/`, KHÔNG nằm trong `dist/` — nó là cấu
hình cho lệnh chạy ở máy mình, không phải nội dung trang.)

## Cái gì lên được Cloudflare, cái gì không

Nói thẳng trước khi làm, vì đây là chỗ dễ hứa quá tay nhất.

**Lên được** (Cloudflare Pages phục vụ tệp tĩnh):

- Trang giới thiệu — dựng sẵn thành HTML, số liệu đóng băng tại ngày dựng
- Sơ đồ chương trình dạng ảnh SVG, năm góc nhìn
- 52 kịch bản lời đọc của bộ video hướng dẫn
- **Toàn bộ 28 tệp giao diện** — mười màn hình của ứng dụng

**Không lên được** — cần một máy chủ Node chạy thật:

- Đăng nhập, tài khoản, phiên làm việc
- Trợ lý trò chuyện (đọc dữ liệu học viên thật)
- Dựng video, dựng bài giảng, chụp ảnh hệ thống
- Mọi thứ ghi xuống đĩa

Lý do không phải thiếu sót của ai: Pages không chạy tiến trình lâu dài, không
có hệ tệp ghi được, và không giữ trạng thái giữa hai yêu cầu.

## Nối hai phần

1. Chạy máy chủ Node ở đâu cũng được — kể cả một máy trong văn phòng.
2. `cloudflared tunnel --url http://localhost:9999` đưa nó ra ngoài, không
   phải mở cổng nào trên tường lửa.
3. Trỏ một tên miền con (ví dụ `app.gitamath.vn`) vào đường hầm ấy.
4. Mở ba dòng trong `dist/_redirects`, đổi tên miền cho đúng.

Chưa mở ba dòng ấy thì mười màn giao diện **vẫn mở ra được**, chỉ là phần dữ
liệu báo chưa nối máy chủ — và chân trang nói rõ phải làm gì.

## Đếm lại sau khi tải lên

Mở `/ban-ke.json` trên tên miền vừa triển khai: nó liệt kê đủ số tệp và số
byte của từng tệp trong gói. Đối chiếu là biết ngay đã lên đủ chưa.

## Số liệu đóng băng

Trang tĩnh mang số liệu của **ngày dựng**, và mỗi trang in rõ ngày ấy. Số
liệu đổi thì dựng lại và đẩy lại — một lệnh.
