'use strict';
/**
 * Bộ ghép — gom cây mô-đun thành một tệp _worker.js duy nhất.
 *
 * VÌ SAO PHẢI TỰ GHÉP. Cloudflare Pages có hai cách chạy phần động:
 * thư mục functions/ (wrangler biên dịch lúc triển khai) và tệp
 * _worker.js ở gốc (Advanced Mode). Người dùng hệ này tải lên bằng cách
 * kéo thả một tệp nén vào bảng điều khiển — đường ấy KHÔNG biên dịch
 * functions/, chỉ nhận _worker.js. Nên mã phải gom thành một tệp.
 *
 * Bộ ghép này cố ý nhỏ và ngặt:
 *   · chỉ nhận require('./…') và require('../…') viết nguyên văn
 *   · không nhận require động, không nhận require gói ngoài
 *   · chết ngay nếu thấy require('node:…') — workerd không có chúng,
 *     và phát hiện lúc ghép tốt hơn phát hiện lúc trang trắng xoá
 *   · thứ tự tệp trong bản ghép là thứ tự duyệt sâu, tất định
 */

const fs = require('node:fs');
const path = require('node:path');

const GOC_DU_AN = path.resolve(__dirname, '..');
const VAO = path.join(__dirname, 'nguon', 'goc.js');

const RE_REQUIRE = /require\(\s*'(\.{1,2}\/[^']+)'\s*\)/g;
const RE_NODE = /require\(\s*'(node:[^']+)'\s*\)/g;
const RE_GOI_NGOAI = /require\(\s*'(?!node:)([^'.][^']*)'\s*\)/g;

function chuanTen(tep) {
  return path.relative(GOC_DU_AN, tep).split(path.sep).join('/');
}

function giaiDuong(tuTep, duong) {
  let p = path.resolve(path.dirname(tuTep), duong);
  if (fs.existsSync(p) && fs.statSync(p).isFile()) return p;
  for (const duoi of ['.js', '/index.js']) {
    if (fs.existsSync(p + duoi)) return p + duoi;
  }
  throw new Error('Không tìm thấy mô-đun ' + duong + ' (gọi từ ' + chuanTen(tuTep) + ')');
}

function gom(vao) {
  const thay = new Map();      // đường tuyệt đối -> { ten, ma, phuThuoc }
  const thuTu = [];
  const nodeDaGap = new Set();

  (function duyet(tep) {
    if (thay.has(tep)) return;
    const ma = fs.readFileSync(tep, 'utf8');

    // Mô-đun lõi của Node: workerd không có chúng khi chưa bật cờ
    // nodejs_compat. Không chặn ở đây, vì vài tệp dùng lại của hệ Node
    // có nhánh không bao giờ chạy trên Workers và đã nạp lười. Thay vào
    // đó thay bằng một mô-đun giả: chạm vào nó là ném lỗi nói rõ tên
    // tệp và tên hàm — tốt hơn nhiều so với một trang trắng xoá.
    for (const m of ma.matchAll(RE_NODE)) nodeDaGap.add(m[1] + '  ←  ' + chuanTen(tep));
    const ngoai = [...ma.matchAll(RE_GOI_NGOAI)].map((m) => m[1]);
    if (ngoai.length) {
      throw new Error(chuanTen(tep) + ' đòi gói ngoài: ' + ngoai.join(', ') +
        '. Kho mã nguồn này giữ luật không phụ thuộc gói ngoài.');
    }

    thay.set(tep, null);         // đánh dấu đang duyệt, chặn vòng lặp
    const phu = [];
    for (const m of ma.matchAll(RE_REQUIRE)) {
      const con = giaiDuong(tep, m[1]);
      phu.push({ nhu: m[1], tep: con });
      duyet(con);
    }
    thay.set(tep, { ten: chuanTen(tep), ma, phu });
    thuTu.push(tep);
  })(vao);

  return { thay, thuTu, nodeDaGap: [...nodeDaGap].sort() };
}

function ghep() {
  const { thay, thuTu, nodeDaGap } = gom(VAO);
  const phan = [];

  phan.push('// ═══════════════════════════════════════════════════════════════');
  phan.push('//  GITAV20nexus — tầng Cloudflare');
  phan.push('//');
  phan.push('//  TỆP NÀY SINH TỰ ĐỘNG. Đừng sửa tay — sửa ở cloudflare/nguon/');
  phan.push('//  rồi chạy lại:  node cloudflare/dung-worker.js');
  phan.push('//');
  phan.push('//  Gồm ' + thuTu.length + ' mô-đun, ghép theo thứ tự duyệt sâu.');
  phan.push('// ═══════════════════════════════════════════════════════════════');
  phan.push('');
  phan.push('const __kho = {};');
  phan.push('');
  phan.push('// Mô-đun lõi của Node không có trên workerd. Thay bằng bản giả:');
  phan.push('// chạm vào bất kỳ thứ gì trong đó là ném lỗi nói rõ đang cần gì.');
  phan.push('const __nodeGia = (ten) => new Proxy({}, {');
  phan.push('  get(_, k) {');
  phan.push('    throw new Error("Tầng Cloudflare không có " + ten + "." + String(k) +');
  phan.push('      " — nhánh mã này chỉ chạy được trên máy chủ Node.");');
  phan.push('  },');
  phan.push('});');
  phan.push('const __dem = {};');
  phan.push('function __nap(ten) {');
  phan.push('  if (__dem[ten]) return __dem[ten].exports;');
  phan.push('  const m = __kho[ten];');
  phan.push('  if (!m) throw new Error("Thiếu mô-đun trong bản ghép: " + ten);');
  phan.push('  const mod = { exports: {} };');
  phan.push('  __dem[ten] = mod;');
  phan.push('  m.goi(mod, mod.exports, m.giai);');
  phan.push('  return mod.exports;');
  phan.push('}');
  phan.push('');

  for (const tep of thuTu) {
    const m = thay.get(tep);
    const bang = {};
    for (const p of m.phu) bang[p.nhu] = chuanTen(p.tep);
    const coNode = RE_NODE.test(m.ma); RE_NODE.lastIndex = 0;
    phan.push('// ─── ' + m.ten + ' ' + '─'.repeat(Math.max(3, 62 - m.ten.length)));
    phan.push('__kho[' + JSON.stringify(m.ten) + '] = {');
    phan.push('  giai: (d) => (d.startsWith("node:") ? __nodeGia(d) : __nap(' +
      JSON.stringify(bang) + '[d])),');
    phan.push('  goi: function (module, exports, require) {');
    // Thụt vào hai dấu cách để dễ đọc khi phải dò lỗi trên bản đã triển khai.
    phan.push(m.ma.split('\n').map((d) => (d ? '    ' + d : '')).join('\n'));
    phan.push('  },');
    phan.push('};');
    phan.push('');
  }

  phan.push('const __goc = __nap(' + JSON.stringify(chuanTen(VAO)) + ');');
  phan.push('export default __goc.worker;');
  phan.push('');
  return { ma: phan.join('\n'), soMoDun: thuTu.length,
    tep: thuTu.map((t) => chuanTen(t)), nodeDaGap };
}

function chay() {
  const ra = ghep();
  const dich = path.join(__dirname, 'dist', '_worker.js');
  fs.mkdirSync(path.dirname(dich), { recursive: true });
  fs.writeFileSync(dich, ra.ma);
  const kb = (Buffer.byteLength(ra.ma) / 1024).toFixed(1);
  console.log('_worker.js · ' + ra.soMoDun + ' mô-đun · ' + kb + ' KB');
  if (ra.nodeDaGap.length) {
    console.log('  Nhánh dùng mô-đun lõi Node, đã thay bằng bản giả ném lỗi rõ ràng:');
    for (const x of ra.nodeDaGap) console.log('    · ' + x);
  }
  return ra;
}

if (require.main === module) {
  try {
    chay();
  } catch (e) {
    console.error('\n  KHÔNG GHÉP ĐƯỢC\n  ' + e.message + '\n');
    process.exit(1);
  }
}

module.exports = { ghep, chay, gom, VAO, GOC_DU_AN };
