'use strict';
/**
 * Giả lập môi trường Cloudflare bằng node:sqlite.
 *
 * Không phải bản giả lỏng lẻo: D1 và node:sqlite có cùng hình dạng
 * prepare/bind/first/all/run, nên câu SQL chạy ở đây là đúng câu sẽ
 * chạy trên D1 thật. Khác biệt duy nhất đã bọc lại ở dưới là D1 gói
 * kết quả all() vào {results}.
 */

const { DatabaseSync } = require('node:sqlite');
const fs = require('node:fs');
const path = require('node:path');

const THU_MUC_DI_TRU = path.join(__dirname, '..', 'migrations');

function D1Gia(db) {
  return {
    prepare(sql) {
      let thamSo = [];
      const cau = {
        bind(...t) { thamSo = t; return cau; },
        async first() {
          const r = db.prepare(sql).get(...thamSo);
          return r === undefined ? null : r;
        },
        async all() {
          return { results: db.prepare(sql).all(...thamSo), success: true };
        },
        async run() {
          const r = db.prepare(sql).run(...thamSo);
          return { success: true, meta: { changes: Number(r.changes), last_row_id: Number(r.lastInsertRowid) } };
        },
      };
      return cau;
    },
    async batch(ds) {
      const ra = [];
      for (const c of ds) ra.push(await c.run());
      return ra;
    },
    async exec(sql) { db.exec(sql); return { count: 1 }; },
    _db: db,
  };
}

/** KV giả — trong bộ nhớ, có tôn trọng expirationTtl. */
function KVGia(dongHo) {
  const bang = new Map();
  const now = dongHo || (() => Date.now());
  return {
    async get(k, kieu) {
      const v = bang.get(k);
      if (!v) return null;
      if (v.hetLuc && v.hetLuc <= now()) { bang.delete(k); return null; }
      return kieu === 'json' ? JSON.parse(v.chu) : v.chu;
    },
    async put(k, chu, tc) {
      bang.set(k, { chu: String(chu),
        hetLuc: tc && tc.expirationTtl ? now() + tc.expirationTtl * 1000 : 0 });
    },
    async delete(k) { bang.delete(k); },
    _size: () => bang.size,
  };
}

/** Kho tệp tĩnh giả — trả 404 để phân biệt rõ với tuyến API. */
const ASSETS_GIA = {
  async fetch(req) {
    return new Response('tep-tinh:' + new URL(req.url).pathname, { status: 200 });
  },
};

function dungMoi(themBien) {
  const db = new DatabaseSync(':memory:');
  db.exec('PRAGMA foreign_keys = ON');
  for (const f of fs.readdirSync(THU_MUC_DI_TRU).sort()) {
    if (f.endsWith('.sql')) db.exec(fs.readFileSync(path.join(THU_MUC_DI_TRU, f), 'utf8'));
  }
  return Object.assign({
    DB: D1Gia(db),
    KV: KVGia(),
    ASSETS: ASSETS_GIA,
    AI_PROVIDER_ORDER: 'gemini,groq',
    AI_PROVIDER_DAILY_CAP: '5',
  }, themBien || {});
}

/** Đồng hồ đứng yên — mọi mốc thời gian trong bộ thử đều xác định. */
function dongHoGia(batDau) {
  let t = batDau === undefined ? 1758000000000 : batDau;
  const f = () => t;
  f.tien = (ms) => { t += ms; return t; };
  f.dat = (x) => { t = x; return t; };
  return f;
}

function yeuCau(cach, duong, tuyChon) {
  const o = tuyChon || {};
  const h = new Headers(o.tieuDe || {});
  let than;
  if (o.than !== undefined) {
    h.set('content-type', 'application/json');
    than = JSON.stringify(o.than);
  }
  if (o.the) h.set('authorization', 'Bearer ' + o.the);
  return new Request('https://kiem-thu.local' + duong, { method: cach, headers: h, body: than });
}

async function doc(res) {
  const chu = await res.text();
  try { return JSON.parse(chu); } catch (e) { return { _chu: chu }; }
}

module.exports = { dungMoi, dongHoGia, yeuCau, doc, D1Gia, KVGia, ASSETS_GIA };
