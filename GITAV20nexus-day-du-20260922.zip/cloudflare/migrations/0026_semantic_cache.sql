-- =========================================================
-- V13: THREE-TIER SEMANTIC CACHE
-- L1: KV (hot, <1ms)  L2: D1 (warm, <10ms)  L3: Vectorize (semantic, <50ms)
-- =========================================================
-- L2 warm cache
CREATE TABLE semantic_cache_warm (
  content_hash    TEXT PRIMARY KEY,           -- SHA-256 của (prompt + model + params)
  cache_type      TEXT NOT NULL,              -- 'prompt','grade','translate','embed'
  response_json   TEXT NOT NULL,
  tokens_saved    INTEGER NOT NULL DEFAULT 0,
  hit_count       INTEGER NOT NULL DEFAULT 0,
  last_hit_at     INTEGER NOT NULL,
  created_at      INTEGER NOT NULL,
  expires_at      INTEGER NOT NULL
);
CREATE INDEX idx_cache_warm_expiry ON semantic_cache_warm(expires_at);
CREATE INDEX idx_cache_warm_type ON semantic_cache_warm(cache_type, last_hit_at DESC);
-- L3 semantic cache (near-duplicate prompts)
CREATE TABLE semantic_cache_index (
  id              TEXT PRIMARY KEY,
  cache_key       TEXT NOT NULL,              -- ref semantic_cache_warm.content_hash
  prompt_text     TEXT NOT NULL,              -- Full prompt for embedding
  cache_type      TEXT NOT NULL,
  embedding_json  TEXT NOT NULL,              -- Vector (1024-d)
  created_at      INTEGER NOT NULL
);
CREATE INDEX idx_sem_cache_type ON semantic_cache_index(cache_type);
