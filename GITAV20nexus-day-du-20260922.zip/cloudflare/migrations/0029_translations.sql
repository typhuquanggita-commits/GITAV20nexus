-- =========================================================
-- V13: MULTI-LANGUAGE PIPELINE — m2m100 miễn phí
-- =========================================================
CREATE TABLE content_translations (
  id              TEXT PRIMARY KEY,
  content_type    TEXT NOT NULL,              -- 'level','question','template'
  content_id      TEXT NOT NULL,
  source_lang     TEXT NOT NULL DEFAULT 'vi',
  target_lang     TEXT NOT NULL,              -- 'en','zh','ja','ko'
  translated_json TEXT NOT NULL,              -- Translated fields
  source_hash     TEXT NOT NULL,              -- Hash của bản gốc khi dịch
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','machine','reviewed','published','stale')),
  model           TEXT NOT NULL,
  quality_score   REAL,
  reviewed_by     TEXT,
  reviewed_at     INTEGER,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL,
  UNIQUE (content_type, content_id, target_lang)
);
CREATE INDEX idx_trans_status ON content_translations(status, target_lang);
CREATE INDEX idx_trans_hash ON content_translations(source_hash);
-- Glossary (thuật ngữ cố định — quan trọng cho giáo trình)
CREATE TABLE translation_glossary (
  id              TEXT PRIMARY KEY,
  source_lang     TEXT NOT NULL DEFAULT 'vi',
  target_lang     TEXT NOT NULL,
  source_term     TEXT NOT NULL,
  target_term     TEXT NOT NULL,
  context         TEXT,
  created_by      TEXT NOT NULL,
  created_at      INTEGER NOT NULL,
  UNIQUE (source_lang, target_lang, source_term)
);
CREATE INDEX idx_glossary_lookup ON translation_glossary(target_lang, source_lang);
