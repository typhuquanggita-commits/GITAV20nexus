-- =========================================================
-- BẢO MẬT VÀ BỘ NÃO
--
-- Hai mươi hai lớp canh, và một bộ não là CỬA VÀO DUY NHẤT của mọi
-- lệnh có hậu quả. Bảng dưới đây giữ ba thứ mà lớp canh cần nhớ giữa
-- các lượt gọi: danh sách chặn, nếp thường ngày của từng tài khoản, và
-- nhật ký chặn.
--
-- Một điều nói thẳng ngay ở đây: Workers chạy mỗi lượt trong một bản
-- cô lập riêng, không có trạng thái sống chung. Nên những lớp cần thấy
-- TOÀN CẢNH trong một giây — chặn lũ yêu cầu chẳng hạn — không thể làm
-- đủ trong mã này; phần ấy do chính hạ tầng Cloudflare đứng trước gánh.
-- Mã ở đây làm phần đếm được qua kho, và nói rõ phần nào nó không làm.
-- =========================================================

CREATE TABLE IF NOT EXISTS danh_sach_chan (
  id          TEXT PRIMARY KEY,
  loai        TEXT NOT NULL CHECK (loai IN ('ip','tai-khoan','dai-chi-thu','dau-van-tay')),
  gia_tri     TEXT NOT NULL,
  ly_do       TEXT NOT NULL,
  lop_bat     TEXT,                      -- lớp nào bắt được
  chan_den    INTEGER,                   -- NULL là chặn vĩnh viễn
  nguoi_chan  TEXT,
  created_at  INTEGER NOT NULL,
  UNIQUE (loai, gia_tri)
);
CREATE INDEX IF NOT EXISTS idx_chan_het ON danh_sach_chan(chan_den);

CREATE TABLE IF NOT EXISTS nhat_ky_chan (
  id          TEXT PRIMARY KEY,
  lop         TEXT NOT NULL,             -- 'D3_ma-doc' | 'L6_tiem-sql' …
  giai_doan   TEXT NOT NULL CHECK (giai_doan IN ('phong-ve','tang-trong','hien-phap','linh-gac')),
  ly_do       TEXT NOT NULL,
  duong_dan   TEXT,
  cach_goi    TEXT,
  ip          TEXT,
  user_id     TEXT,
  dau_hieu_json TEXT,
  at          INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_nkc_luc ON nhat_ky_chan(at DESC);
CREATE INDEX IF NOT EXISTS idx_nkc_lop ON nhat_ky_chan(lop, at DESC);

-- Nếp thường ngày của một tài khoản. Lớp canh hành vi so hôm nay với
-- nếp này; lệch quá xa thì dừng lại hỏi, không chặn thẳng — chặn thẳng
-- vì một hôm làm việc khác thường là đuổi người dùng thật đi.
CREATE TABLE IF NOT EXISTS nep_tai_khoan (
  user_id       TEXT PRIMARY KEY,
  so_luot       INTEGER NOT NULL DEFAULT 0,
  gio_hay_dung  TEXT,                    -- JSON: đếm theo 24 giờ
  duong_hay_goi TEXT,                    -- JSON: mười đường gọi nhiều nhất
  nuoc_hay_vao  TEXT,
  luot_moi_gio_tb REAL,
  cap_nhat      INTEGER NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Mỗi lệnh đi qua bộ não để lại một dòng. Đây là thứ trả lời được câu
-- "ai đã làm gì, lúc nào, và lệnh ấy đi qua những cửa nào".
CREATE TABLE IF NOT EXISTS lenh_bo_nao (
  id          TEXT PRIMARY KEY,
  loai        TEXT NOT NULL,
  uu_tien     TEXT NOT NULL DEFAULT 'thuong' CHECK (uu_tien IN ('thap','thuong','cao','khan')),
  user_id     TEXT,
  vai         TEXT,
  ip          TEXT,
  duong_dan   TEXT,
  trang_thai  TEXT NOT NULL
              CHECK (trang_thai IN ('nhan','chan-bao-mat','chan-hien-phap','dang-lam','xong','hong')),
  chan_tai    TEXT,                      -- lớp nào chặn
  ban_giao_json TEXT,                    -- ban nào nhận, kết quả ra sao
  soi_json    TEXT,                      -- thanh tra nói gì
  ms          INTEGER,
  at          INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_lenh_luc ON lenh_bo_nao(at DESC);
CREATE INDEX IF NOT EXISTS idx_lenh_tt  ON lenh_bo_nao(trang_thai, at DESC);

-- Khoá ký cho lệnh máy-gọi-máy. Chỉ lưu BĂM của khoá, không lưu khoá.
CREATE TABLE IF NOT EXISTS khoa_ky (
  id          TEXT PRIMARY KEY,
  ten         TEXT NOT NULL,
  bam_khoa    TEXT NOT NULL UNIQUE,
  pham_vi_json TEXT NOT NULL DEFAULT '[]',
  het_han     INTEGER,
  thu_hoi_luc INTEGER,
  nguoi_tao   TEXT NOT NULL,
  created_at  INTEGER NOT NULL,
  dung_lan_cuoi INTEGER
);
