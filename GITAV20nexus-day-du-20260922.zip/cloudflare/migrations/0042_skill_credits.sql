-- =========================================================
-- V18: SKILL CREDITS — Time banking (1 giờ dạy = 1 credit)
-- =========================================================
CREATE TABLE credit_wallets (
  user_id         TEXT PRIMARY KEY,
  balance         INTEGER NOT NULL DEFAULT 0,     -- In minutes (60 = 1 credit)
  total_earned    INTEGER NOT NULL DEFAULT 0,
  total_spent     INTEGER NOT NULL DEFAULT 0,
  reputation_score REAL NOT NULL DEFAULT 0,
  verified_seller INTEGER NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE TABLE credit_transactions (
  id              TEXT PRIMARY KEY,
  from_user_id    TEXT,                           -- NULL = mint
  to_user_id      TEXT,                           -- NULL = burn
  amount          INTEGER NOT NULL,                -- minutes
  tx_type         TEXT NOT NULL
                  CHECK (tx_type IN ('earn_session','spend_session','signup_bonus','referral_bonus','refund','platform_fee','admin_grant')),
  reference_type  TEXT,                           -- 'booking','referral','admin'
  reference_id    TEXT,
  note            TEXT,
  created_at      INTEGER NOT NULL
);
CREATE INDEX idx_tx_from ON credit_transactions(from_user_id, created_at DESC);
CREATE INDEX idx_tx_to ON credit_transactions(to_user_id, created_at DESC);
-- Skill exchange listings
CREATE TABLE skill_listings (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  -- Skill offered
  title           TEXT NOT NULL,
  description     TEXT NOT NULL,
  skill_tags_json TEXT DEFAULT '[]',
  proficiency     TEXT NOT NULL CHECK (proficiency IN ('beginner','intermediate','advanced','expert')),
  -- Format
  format          TEXT NOT NULL CHECK (format IN ('1on1','group','async','workshop')),
  duration_min    INTEGER NOT NULL DEFAULT 60,
  credits_cost    INTEGER NOT NULL,               -- minutes
  language        TEXT NOT NULL DEFAULT 'vi',
  -- Availability
  timezone        TEXT NOT NULL DEFAULT 'Asia/Ho_Chi_Minh',
  availability_json TEXT,                          -- [{dayOfWeek, slots:["09:00-10:00"]}]
  -- Status
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','paused','archived')),
  -- Metrics
  bookings_count  INTEGER NOT NULL DEFAULT 0,
  avg_rating      REAL NOT NULL DEFAULT 0,
  rating_count    INTEGER NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX idx_listings_status ON skill_listings(status, avg_rating DESC);
CREATE INDEX idx_listings_user ON skill_listings(user_id, status);
CREATE INDEX idx_listings_tags ON skill_listings(skill_tags_json);
-- Bookings
CREATE TABLE skill_bookings (
  id              TEXT PRIMARY KEY,
  listing_id      TEXT NOT NULL,
  buyer_id        TEXT NOT NULL,
  seller_id       TEXT NOT NULL,
  -- Schedule
  scheduled_at    INTEGER NOT NULL,
  duration_min    INTEGER NOT NULL,
  timezone        TEXT NOT NULL DEFAULT 'Asia/Ho_Chi_Minh',
  -- Platform
  meeting_url     TEXT,
  agenda          TEXT,
  -- Credits
  credits_held    INTEGER NOT NULL,               -- Escrowed credits
  credits_released INTEGER NOT NULL DEFAULT 0,
  -- Status
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','confirmed','in_progress','completed','cancelled','disputed','no_show')),
  -- Feedback
  buyer_rating    INTEGER CHECK (buyer_rating BETWEEN 1 AND 5),
  buyer_review    TEXT,
  seller_rating   INTEGER CHECK (seller_rating BETWEEN 1 AND 5),
  seller_review   TEXT,
  -- Meta
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL,
  completed_at    INTEGER,
  FOREIGN KEY (listing_id) REFERENCES skill_listings(id)
);
CREATE INDEX idx_bookings_buyer ON skill_bookings(buyer_id, status, scheduled_at DESC);
CREATE INDEX idx_bookings_seller ON skill_bookings(seller_id, status, scheduled_at DESC);
-- Reviews (public)
CREATE TABLE skill_reviews (
  id              TEXT PRIMARY KEY,
  listing_id      TEXT NOT NULL,
  booking_id      TEXT NOT NULL,
  reviewer_id     TEXT NOT NULL,
  reviewer_role   TEXT NOT NULL CHECK (reviewer_role IN ('buyer','seller')),
  rating          INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  review          TEXT NOT NULL,
  helpful_count   INTEGER NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL,
  UNIQUE (booking_id, reviewer_role)
);
CREATE INDEX idx_reviews_listing ON skill_reviews(listing_id, created_at DESC);
