-- =========================================================
-- V13: CRDT OFFLINE SYNC — Không cần server state
-- =========================================================
-- CRDT updates (append-only log)
CREATE TABLE crdt_updates (
  id              TEXT PRIMARY KEY,
  doc_id          TEXT NOT NULL,              -- 'level:<uuid>' hoặc 'question:<uuid>'
  user_id         TEXT NOT NULL,
  update_blob     TEXT NOT NULL,              -- Base64 Yjs update
  vector_clock    TEXT NOT NULL,              -- JSON {userId: counter}
  client_ts       INTEGER NOT NULL,
  server_ts       INTEGER NOT NULL,
  applied         INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_crdt_doc ON crdt_updates(doc_id, server_ts);
CREATE INDEX idx_crdt_user ON crdt_updates(user_id, server_ts);
-- Snapshots (compaction)
CREATE TABLE crdt_snapshots (
  id              TEXT PRIMARY KEY,
  doc_id          TEXT NOT NULL,
  snapshot_blob   TEXT NOT NULL,              -- Yjs state as base64
  up_to_seq       INTEGER NOT NULL,           -- Snapshot đến update nào
  created_at      INTEGER NOT NULL,
  UNIQUE (doc_id, up_to_seq)
);
-- Active peers (peer-to-peer signaling)
CREATE TABLE sync_peers (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  device_id       TEXT NOT NULL,
  doc_ids_json    TEXT NOT NULL,              -- Docs đang mở
  last_seen_at    INTEGER NOT NULL,
  connection_meta TEXT,                       -- WebRTC offer/answer
  created_at      INTEGER NOT NULL,
  UNIQUE (user_id, device_id)
);
CREATE INDEX idx_peers_active ON sync_peers(last_seen_at);
