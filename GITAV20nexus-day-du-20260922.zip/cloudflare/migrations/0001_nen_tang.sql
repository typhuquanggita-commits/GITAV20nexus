-- =========================================================
-- NỀN TẢNG — bảng người dùng, phiên đăng nhập, nhật ký kiểm toán
--
-- Đặc tả V13 tham chiếu users(id) ở 79 chỗ nhưng không định nghĩa
-- bảng này ở đâu cả (nó nằm ở các bản 0001–0024 không có trong tài
-- liệu). Tệp này dựng lại bảng ấy cho khớp: khoá chính TEXT, vì toàn
-- bộ 154 bảng V13 dùng khoá TEXT dạng uuid.
--
-- Vai trò lấy đúng theo hệ Node V20 đang chạy, thêm SUPER_ADMIN.
-- =========================================================

CREATE TABLE IF NOT EXISTS users (
  id             TEXT PRIMARY KEY,
  email          TEXT NOT NULL UNIQUE,
  password_hash  TEXT NOT NULL,          -- PBKDF2-SHA256, dạng: lặp$muối$băm
  full_name      TEXT NOT NULL,
  role           TEXT NOT NULL DEFAULT 'LEARNER',
                 -- SUPER_ADMIN | ADMIN | TEACHER | PARENT | LEARNER
  phone          TEXT,
  status         TEXT NOT NULL DEFAULT 'ACTIVE',   -- ACTIVE | DISABLED
  locale         TEXT NOT NULL DEFAULT 'vi',
  created_at     INTEGER NOT NULL,
  updated_at     INTEGER NOT NULL,
  last_login_at  INTEGER
);
CREATE INDEX IF NOT EXISTS idx_users_role   ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);

CREATE TABLE IF NOT EXISTS user_sessions (
  id          TEXT PRIMARY KEY,          -- băm SHA-256 của thẻ phiên, không lưu thẻ gốc
  user_id     TEXT NOT NULL,
  created_at  INTEGER NOT NULL,
  expires_at  INTEGER NOT NULL,
  revoked_at  INTEGER,
  user_agent  TEXT,
  FOREIGN KEY (user_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_user_sessions_user    ON user_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_user_sessions_expires ON user_sessions(expires_at);

-- Nhật ký nối chuỗi băm: mỗi dòng mang băm của dòng trước, sửa một
-- dòng là đứt chuỗi và soi ra được.
CREATE TABLE IF NOT EXISTS audit_log (
  id          TEXT PRIMARY KEY,
  seq         INTEGER NOT NULL,
  at          INTEGER NOT NULL,
  actor_id    TEXT,
  action      TEXT NOT NULL,
  target      TEXT,
  detail_json TEXT,
  prev_hash   TEXT NOT NULL,
  hash        TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_audit_log_seq ON audit_log(seq);
CREATE INDEX IF NOT EXISTS idx_audit_log_actor      ON audit_log(actor_id);

-- Hạn mức gọi theo ngày, dùng chung cho mọi tuyến tốn tài nguyên.
CREATE TABLE IF NOT EXISTS rate_counters (
  id        TEXT PRIMARY KEY,            -- <khoá>:<ngày YYYY-MM-DD>
  bucket    TEXT NOT NULL,
  day       TEXT NOT NULL,
  count     INTEGER NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_rate_counters_day ON rate_counters(day);
