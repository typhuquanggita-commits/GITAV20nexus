-- =========================================================
-- LUYỆN THI VÀ TỔ CHỨC THI — sáu hệ chuẩn
--
--   HSA 1300 · TSA 100 · SPT 1200 · IELTS 9.0 · SAT 1600 · TOEIC 990
--
-- Cấu trúc từng hệ KHÔNG nằm trong kho dữ liệu: nó nằm ở src/matran/chuan.js,
-- chép từ tài liệu gốc và có kiểm thử giữ. Bảng dưới đây chỉ giữ thứ THAY ĐỔI
-- theo thời gian: đề đã dựng, lượt thi, điểm, và lộ trình của từng người.
-- Làm ngược lại — chép cấu trúc vào kho — là mở đường cho hai con số khác
-- nhau cùng tự nhận là số câu của HSA.
-- =========================================================

CREATE TABLE IF NOT EXISTS ky_thi (
  id           TEXT PRIMARY KEY,          -- 'hsa','tsa','spt','ielts','sat','toeic'
  ten          TEXT NOT NULL,
  ngan         TEXT NOT NULL,
  diem_toi_da  INTEGER NOT NULL,
  don_vi_diem  TEXT NOT NULL,
  co_quan      TEXT NOT NULL,             -- đơn vị tổ chức thật
  ghi_chu      TEXT
);

-- Một đề đã dựng, gồm danh sách câu theo thứ tự.
CREATE TABLE IF NOT EXISTS de_thi (
  id           TEXT PRIMARY KEY,
  ky_thi_id    TEXT NOT NULL,
  ten          TEXT NOT NULL,
  loai         TEXT NOT NULL CHECK (loai IN ('thu','chinh-thuc','chan-doan','theo-phan')),
  cau_ids_json TEXT NOT NULL,             -- ["bai-1","bai-2",…] theo đúng thứ tự
  so_cau       INTEGER NOT NULL,
  so_phut      INTEGER NOT NULL,
  cau_truc_json TEXT NOT NULL,            -- ảnh chụp cấu trúc lúc dựng đề
  bam_de       TEXT NOT NULL,             -- băm của danh sách câu, chống sửa lén
  trang_thai   TEXT NOT NULL DEFAULT 'nhap'
               CHECK (trang_thai IN ('nhap','da-soat','mo','dong','thu-hoi')),
  mo_luc       INTEGER,
  dong_luc     INTEGER,
  nguoi_tao    TEXT,
  created_at   INTEGER NOT NULL,
  updated_at   INTEGER NOT NULL,
  FOREIGN KEY (ky_thi_id) REFERENCES ky_thi(id)
);
CREATE INDEX IF NOT EXISTS idx_de_thi_ky ON de_thi(ky_thi_id, trang_thai);

CREATE TABLE IF NOT EXISTS luot_thi (
  id           TEXT PRIMARY KEY,
  de_id        TEXT NOT NULL,
  user_id      TEXT NOT NULL,
  bat_dau      INTEGER NOT NULL,
  han_nop      INTEGER NOT NULL,
  nop_luc      INTEGER,
  trang_thai   TEXT NOT NULL DEFAULT 'dang-lam'
               CHECK (trang_thai IN ('dang-lam','da-nop','qua-han','huy')),
  diem_tho     REAL,
  diem_quy_doi REAL,
  nac          INTEGER,                   -- nấc 1–10 của hệ chuẩn ấy
  chi_tiet_json TEXT,
  created_at   INTEGER NOT NULL,
  FOREIGN KEY (de_id)   REFERENCES de_thi(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_luot_thi_nguoi ON luot_thi(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_luot_thi_de    ON luot_thi(de_id, trang_thai);

CREATE TABLE IF NOT EXISTS luot_thi_tra_loi (
  id           TEXT PRIMARY KEY,
  luot_id      TEXT NOT NULL,
  bai_id       TEXT NOT NULL,
  thu_tu       INTEGER NOT NULL,
  tra_loi_json TEXT,
  dung         INTEGER,                   -- 1 đúng, 0 sai, NULL chưa chấm
  diem         REAL,
  giay_lam     INTEGER,
  doi_dap_an   INTEGER NOT NULL DEFAULT 0,  -- số lần đổi ý, dùng để đo tự tin
  at           INTEGER NOT NULL,
  UNIQUE (luot_id, thu_tu),
  FOREIGN KEY (luot_id) REFERENCES luot_thi(id)
);
CREATE INDEX IF NOT EXISTS idx_ltl_luot ON luot_thi_tra_loi(luot_id, thu_tu);

-- Lộ trình luyện thi: từ cấp 0 tới điểm đích, chia thành chặng có điều kiện.
CREATE TABLE IF NOT EXISTS lo_trinh_thi (
  id           TEXT PRIMARY KEY,
  user_id      TEXT NOT NULL,
  ky_thi_id    TEXT NOT NULL,
  diem_dau     REAL,                      -- điểm bài chẩn đoán đầu vào
  diem_dich    REAL NOT NULL,
  han_dich     INTEGER,
  nac_hien_tai INTEGER NOT NULL DEFAULT 0,
  trang_thai   TEXT NOT NULL DEFAULT 'dang-chay'
               CHECK (trang_thai IN ('dang-chay','tam-dung','dat-dich','bo')),
  created_at   INTEGER NOT NULL,
  updated_at   INTEGER NOT NULL,
  UNIQUE (user_id, ky_thi_id),
  FOREIGN KEY (ky_thi_id) REFERENCES ky_thi(id),
  FOREIGN KEY (user_id)   REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS lo_trinh_chang (
  id           TEXT PRIMARY KEY,
  lo_trinh_id  TEXT NOT NULL,
  nac          INTEGER NOT NULL,
  ten          TEXT NOT NULL,
  muc_tieu     TEXT NOT NULL,
  dieu_kien_json TEXT NOT NULL,           -- điều kiện đo được để vượt chặng
  chuyen_de_ids_json TEXT NOT NULL DEFAULT '[]',
  bat_dau      INTEGER,
  hoan_thanh   INTEGER,
  trang_thai   TEXT NOT NULL DEFAULT 'chua-mo'
               CHECK (trang_thai IN ('chua-mo','dang-hoc','cho-kiem','dat','truot')),
  so_lan_kiem  INTEGER NOT NULL DEFAULT 0,
  UNIQUE (lo_trinh_id, nac),
  FOREIGN KEY (lo_trinh_id) REFERENCES lo_trinh_thi(id)
);
CREATE INDEX IF NOT EXISTS idx_chang_lt ON lo_trinh_chang(lo_trinh_id, nac);
