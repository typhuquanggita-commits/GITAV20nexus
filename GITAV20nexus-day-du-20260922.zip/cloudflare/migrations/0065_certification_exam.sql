-- =========================================================
-- AI SKILL CERTIFICATION EXAM — Full Schema
-- =========================================================
PRAGMA foreign_keys = ON;
-- ─────────────────────────────────────────────────────────
-- EXAM TEMPLATES
-- ─────────────────────────────────────────────────────────
CREATE TABLE exam_templates (
  id              TEXT PRIMARY KEY,
  code            TEXT NOT NULL UNIQUE,              -- 'CERT-AI-FOUNDATION-V1'
  title           TEXT NOT NULL,
  description     TEXT NOT NULL,
  -- Scope
  level_ids_json  TEXT NOT NULL,                     -- Levels covered
  skill_ids_json  TEXT DEFAULT '[]',
  category        TEXT NOT NULL,                     -- 'ai','business','mindset'
  difficulty_band TEXT NOT NULL DEFAULT 'intermediate'
                  CHECK (difficulty_band IN ('beginner','intermediate','advanced','expert')),
  -- Structure
  total_questions INTEGER NOT NULL DEFAULT 30,
  pass_threshold  REAL NOT NULL DEFAULT 0.7,
  time_limit_min  INTEGER NOT NULL DEFAULT 45,
  -- Adaptive testing (IRT)
  adaptive_enabled INTEGER NOT NULL DEFAULT 1,
  min_difficulty  REAL NOT NULL DEFAULT 2.0,
  max_difficulty  REAL NOT NULL DEFAULT 4.5,
  initial_difficulty REAL NOT NULL DEFAULT 3.0,
  -- Proctoring
  proctoring_level TEXT NOT NULL DEFAULT 'medium'
                   CHECK (proctoring_level IN ('none','light','medium','strict')),
  webcam_required INTEGER NOT NULL DEFAULT 0,
  screen_record_required INTEGER NOT NULL DEFAULT 0,
  max_integrity_events INTEGER NOT NULL DEFAULT 5,
  -- Certificate
  cert_title      TEXT NOT NULL,
  cert_validity_months INTEGER,                      -- NULL = perpetual
  -- Meta
  version         TEXT NOT NULL DEFAULT 'v1.0.0',
  status          TEXT NOT NULL DEFAULT 'draft'
                  CHECK (status IN ('draft','active','archived')),
  created_by      TEXT NOT NULL,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX idx_exam_templates_status ON exam_templates(status, category);
CREATE INDEX idx_exam_templates_code ON exam_templates(code);
-- ─────────────────────────────────────────────────────────
-- EXAM QUESTIONS (Item Response Theory)
-- ─────────────────────────────────────────────────────────
CREATE TABLE exam_questions (
  id              TEXT PRIMARY KEY,
  template_id     TEXT NOT NULL,
  source_question_id TEXT,                           -- Ref questions_v10 (optional)
  -- Content
  question_text   TEXT NOT NULL,
  question_type   TEXT NOT NULL CHECK (question_type IN ('mcq','true_false','fill_blank','scenario','code')),
  options_json    TEXT,
  correct_answer  TEXT NOT NULL,
  explanation     TEXT,
  -- IRT parameters
  difficulty      REAL NOT NULL DEFAULT 3.0 CHECK (difficulty BETWEEN 1 AND 5),
  discrimination  REAL NOT NULL DEFAULT 1.0 CHECK (discrimination BETWEEN 0.1 AND 3.0),
  guessing        REAL NOT NULL DEFAULT 0.25 CHECK (guessing BETWEEN 0 AND 0.5),
  -- Stats
  exposure_count  INTEGER NOT NULL DEFAULT 0,        -- How many times served
  correct_count   INTEGER NOT NULL DEFAULT 0,
  correct_rate    REAL NOT NULL DEFAULT 0.5,
  avg_time_sec    INTEGER NOT NULL DEFAULT 60,
  -- Meta
  tags_json       TEXT DEFAULT '[]',
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('draft','active','retired','compromised')),
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL,
  FOREIGN KEY (template_id) REFERENCES exam_templates(id) ON DELETE CASCADE
);
CREATE INDEX idx_exam_q_template ON exam_questions(template_id, status, difficulty);
CREATE INDEX idx_exam_q_exposure ON exam_questions(template_id, exposure_count) WHERE status = 'active';
-- ─────────────────────────────────────────────────────────
-- EXAM SESSIONS
-- ─────────────────────────────────────────────────────────
CREATE TABLE exam_sessions (
  id              TEXT PRIMARY KEY,
  template_id     TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  attempt_number  INTEGER NOT NULL DEFAULT 1,
  -- Status flow
  status          TEXT NOT NULL DEFAULT 'created'
                  CHECK (status IN (
                    'created','pre_check','in_progress','submitted',
                    'grading','passed','failed','disqualified',
                    'abandoned','expired','under_review'
                  )),
  -- Timing
  created_at      INTEGER NOT NULL,
  started_at      INTEGER,
  submitted_at    INTEGER,
  expires_at      INTEGER,
  duration_sec    INTEGER,
  -- Adaptive state
  current_ability REAL NOT NULL DEFAULT 3.0,         -- IRT theta
  ability_se      REAL NOT NULL DEFAULT 1.0,         -- Standard error
  -- Question tracking
  served_question_ids_json TEXT DEFAULT '[]',
  current_index   INTEGER NOT NULL DEFAULT 0,
  answers_json    TEXT DEFAULT '{}',                 -- {qId: {answer, timeSpentSec, changed, order}}
  -- Scoring
  raw_score       REAL,
  scaled_score    REAL,                              -- 0-100
  passed          INTEGER,
  -- Proctoring
  integrity_score REAL NOT NULL DEFAULT 1.0,         -- 0-1
  proctoring_events_count INTEGER NOT NULL DEFAULT 0,
  -- Certificate link
  certificate_id  TEXT,
  -- Environment
  ip_address      TEXT,
  user_agent      TEXT,
  device_id       TEXT,
  screen_resolution TEXT,
  -- Meta
  updated_at      INTEGER NOT NULL,
  FOREIGN KEY (template_id) REFERENCES exam_templates(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
);
CREATE INDEX idx_exam_sessions_user ON exam_sessions(user_id, template_id, status, created_at DESC);
CREATE INDEX idx_sessions_active ON exam_sessions(status, expires_at)
  WHERE status IN ('pre_check','in_progress','grading');
CREATE INDEX idx_sessions_review ON exam_sessions(status, integrity_score)
  WHERE status IN ('submitted','under_review');
-- ─────────────────────────────────────────────────────────
-- PROCTORING EVENTS
-- ─────────────────────────────────────────────────────────
CREATE TABLE exam_proctoring_events (
  id              TEXT PRIMARY KEY,
  session_id      TEXT NOT NULL,
  event_type      TEXT NOT NULL CHECK (event_type IN (
    'tab_switch','window_blur','copy_attempt','paste_attempt','right_click',
    'devtools_open','face_not_detected','multiple_faces','looking_away',
    'audio_detected','unusual_typing','network_anomaly','suspicious_pattern',
    'timeout_warning','screen_resize','fullscreen_exit','multi_monitor'
  )),
  severity        TEXT NOT NULL DEFAULT 'low'
                  CHECK (severity IN ('low','medium','high','critical')),
  -- Details
  details_json    TEXT,
  penalty_score   REAL NOT NULL DEFAULT 0,           -- 0-1 subtract from integrity
  -- Meta
  recorded_at     INTEGER NOT NULL,
  FOREIGN KEY (session_id) REFERENCES exam_sessions(id) ON DELETE CASCADE
);
CREATE INDEX idx_proctoring_session ON exam_proctoring_events(session_id, recorded_at DESC);
CREATE INDEX idx_proctoring_severity ON exam_proctoring_events(severity, recorded_at DESC)
  WHERE severity IN ('high','critical');
-- ─────────────────────────────────────────────────────────
-- EXAM ANSWERS (detailed)
-- ─────────────────────────────────────────────────────────
CREATE TABLE exam_answers (
  id              TEXT PRIMARY KEY,
  session_id      TEXT NOT NULL,
  question_id     TEXT NOT NULL,
  question_index  INTEGER NOT NULL,
  -- Answer
  answer_text     TEXT,
  answer_json     TEXT,
  time_spent_sec  INTEGER NOT NULL DEFAULT 0,
  answer_changed  INTEGER NOT NULL DEFAULT 0,
  -- Grading
  is_correct      INTEGER,
  partial_score   REAL,
  auto_graded     INTEGER NOT NULL DEFAULT 1,
  ai_grade_score  REAL,
  ai_grade_feedback TEXT,
  -- Meta
  submitted_at    INTEGER NOT NULL,
  FOREIGN KEY (session_id) REFERENCES exam_sessions(id) ON DELETE CASCADE,
  FOREIGN KEY (question_id) REFERENCES exam_questions(id),
  UNIQUE (session_id, question_id)
);
CREATE INDEX idx_exam_answers_session ON exam_answers(session_id, question_index);
-- ─────────────────────────────────────────────────────────
-- CERTIFICATE RECORDS (exam-specific)
-- ─────────────────────────────────────────────────────────
CREATE TABLE exam_certificates (
  id              TEXT PRIMARY KEY,
  session_id      TEXT NOT NULL UNIQUE,
  user_id         TEXT NOT NULL,
  template_id     TEXT NOT NULL,
  -- Certificate
  cert_number     TEXT NOT NULL UNIQUE,              -- Human-readable: 'GITA-AI-2026-00001'
  title           TEXT NOT NULL,
  -- Scores
  scaled_score    REAL NOT NULL,
  percentile      INTEGER,                           -- vs. all test-takers
  -- Signature (Ed25519)
  signed_payload  TEXT NOT NULL,
  signature       TEXT NOT NULL,
  public_key_id   TEXT NOT NULL,
  -- Public verification
  verify_code     TEXT NOT NULL UNIQUE,
  verify_url      TEXT NOT NULL,
  -- Validity
  issued_at       INTEGER NOT NULL,
  expires_at      INTEGER,
  revoked         INTEGER NOT NULL DEFAULT 0,
  revoked_at      INTEGER,
  revocation_reason TEXT,
  -- Blockchain (optional, from V21)
  onchain_tx_hash TEXT,
  onchain_chain   TEXT,
  -- Meta
  shared_linkedin_at INTEGER,
  download_count  INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_exam_certs_user ON exam_certificates(user_id, revoked, issued_at DESC);
CREATE INDEX idx_exam_certs_verify ON exam_certificates(verify_code);
-- ─────────────────────────────────────────────────────────
-- QUESTION CALIBRATION (IRT updates over time)
-- ─────────────────────────────────────────────────────────
CREATE TABLE exam_calibration_log (
  id              TEXT PRIMARY KEY,
  question_id     TEXT NOT NULL,
  -- Before/after IRT params
  old_difficulty  REAL NOT NULL,
  new_difficulty  REAL NOT NULL,
  old_discrimination REAL NOT NULL,
  new_discrimination REAL NOT NULL,
  -- Sample
  sample_size     INTEGER NOT NULL,
  -- Meta
  calibrated_at   INTEGER NOT NULL,
  FOREIGN KEY (question_id) REFERENCES exam_questions(id) ON DELETE CASCADE
);
CREATE INDEX idx_calibration_q ON exam_calibration_log(question_id, calibrated_at DESC);
-- ─────────────────────────────────────────────────────────
-- SEED TEMPLATE (mẫu cho admin)
-- ─────────────────────────────────────────────────────────
INSERT INTO exam_templates (
  id, code, title, description, level_ids_json, category, difficulty_band,
  total_questions, pass_threshold, time_limit_min, adaptive_enabled,
  proctoring_level, cert_title, version, status, created_by, created_at, updated_at
) VALUES (
  'tpl-ai-foundation',
  'CERT-AI-FOUNDATION-V1',
  'Chứng chỉ Nền tảng AI',
  'Đánh giá năng lực nền tảng về AI: khái niệm, ứng dụng, đạo đức, thực hành.',
  '[]',
  'ai',
  'intermediate',
  30, 0.7, 45, 1,
  'medium',
  'GITA365 Certified AI Foundation',
  'v1.0.0', 'draft', 'system', unixepoch() * 1000, unixepoch() * 1000
);
