-- =========================================================
-- V18: AI RESEARCH AGENT — ReAct loop tự research
-- Multi-step reasoning + RAG + citation enforcement
-- =========================================================
CREATE TABLE research_jobs (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  status          TEXT NOT NULL DEFAULT 'planning'
                  CHECK (status IN ('planning','researching','synthesizing','reviewing','ready','failed','cancelled')),
  -- Input
  topic           TEXT NOT NULL,
  research_question TEXT NOT NULL,
  depth           TEXT NOT NULL DEFAULT 'standard'
                  CHECK (depth IN ('quick','standard','deep','academic')),
  language        TEXT NOT NULL DEFAULT 'vi',
  max_iterations  INTEGER NOT NULL DEFAULT 5,
  -- Output
  report_md       TEXT,
  report_json     TEXT,                        -- Structured report
  key_findings_json TEXT DEFAULT '[]',
  open_questions_json TEXT DEFAULT '[]',
  recommendations_json TEXT DEFAULT '[]',
  -- Metrics
  total_citations INTEGER NOT NULL DEFAULT 0,
  total_iterations INTEGER NOT NULL DEFAULT 0,
  tokens_used     INTEGER NOT NULL DEFAULT 0,
  neurons_used    INTEGER NOT NULL DEFAULT 0,
  duration_ms     INTEGER,
  -- Meta
  error_log       TEXT,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL,
  completed_at    INTEGER
);
CREATE INDEX idx_research_user ON research_jobs(user_id, created_at DESC);
CREATE INDEX idx_research_status ON research_jobs(status);
-- Research steps (ReAct trace)
CREATE TABLE research_steps (
  id              TEXT PRIMARY KEY,
  job_id          TEXT NOT NULL,
  iteration       INTEGER NOT NULL,
  step_type       TEXT NOT NULL
                  CHECK (step_type IN ('thought','action','observation','reflection','synthesis')),
  -- Thought
  reasoning       TEXT,
  -- Action
  action_name     TEXT,                        -- 'search_sources','search_web','analyze','compare'
  action_input_json TEXT,
  -- Observation
  observation_json TEXT,
  -- Meta
  tokens_used     INTEGER NOT NULL DEFAULT 0,
  latency_ms      INTEGER,
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (job_id) REFERENCES research_jobs(id) ON DELETE CASCADE
);
CREATE INDEX idx_steps_job ON research_steps(job_id, iteration, created_at);
-- Research findings (extracted facts)
CREATE TABLE research_findings (
  id              TEXT PRIMARY KEY,
  job_id          TEXT NOT NULL,
  finding         TEXT NOT NULL,
  confidence      REAL NOT NULL DEFAULT 0.5,
  source_type     TEXT,                        -- 'level','course','source_chunk','web'
  source_id       TEXT,
  citation        TEXT,
  verified        INTEGER NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (job_id) REFERENCES research_jobs(id) ON DELETE CASCADE
);
CREATE INDEX idx_findings_job ON research_findings(job_id, confidence DESC);
