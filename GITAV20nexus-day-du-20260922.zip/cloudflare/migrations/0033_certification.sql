-- =========================================================
-- V16: CERTIFICATION — Chứng chỉ ký số Ed25519
-- Không cần blockchain, verify bằng public key
-- =========================================================
CREATE TABLE certificates (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  level_id        TEXT,                          -- NULL = tier certificate
  tier_number     INTEGER,                       -- 1-5 hoặc NULL
  cert_type       TEXT NOT NULL CHECK (cert_type IN ('level','tier','mastery','completion')),
  -- Content
  title           TEXT NOT NULL,
  description     TEXT NOT NULL,
  skills_json     TEXT DEFAULT '[]',             -- Skills demonstrated
  score           REAL,                          -- 0-1
  hours_spent     REAL,                          -- Estimated learning hours
  -- Signature
  signed_payload  TEXT NOT NULL,                 -- JSON của toàn bộ data
  signature       TEXT NOT NULL,                 -- Base64 Ed25519 signature
  public_key_id   TEXT NOT NULL,                 -- Ref tới key
  -- Verification
  verify_code     TEXT NOT NULL UNIQUE,          -- Short code for sharing
  verify_url      TEXT NOT NULL,
  -- Status
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','revoked','expired')),
  revoked_at      INTEGER,
  revoked_reason  TEXT,
  -- Timestamps
  issued_at       INTEGER NOT NULL,
  expires_at      INTEGER,                       -- NULL = không hết hạn
  -- External
  linkedin_shared_at INTEGER,
  download_count  INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_cert_user ON certificates(user_id, status);
CREATE INDEX idx_cert_code ON certificates(verify_code);
-- Signing keys (rotate định kỳ)
CREATE TABLE signing_keys (
  id              TEXT PRIMARY KEY,
  public_key_jwk  TEXT NOT NULL,                 -- JSON Web Key
  algorithm       TEXT NOT NULL DEFAULT 'Ed25519',
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','retired','compromised')),
  created_at      INTEGER NOT NULL,
  retired_at      INTEGER
);
-- Issuance criteria (rules)
CREATE TABLE cert_criteria (
  id              TEXT PRIMARY KEY,
  cert_type       TEXT NOT NULL,
  tier_number     INTEGER,
  criteria_json   TEXT NOT NULL,                 -- {min_levels: 10, min_avg_score: 0.8, ...}
  active          INTEGER NOT NULL DEFAULT 1,
  created_at      INTEGER NOT NULL
);
