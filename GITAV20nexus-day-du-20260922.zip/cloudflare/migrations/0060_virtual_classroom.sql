-- =========================================================
-- V22: VIRTUAL CLASSROOM — Phòng học ảo với AI host
-- Live session + breakout rooms + AI participation
-- =========================================================
CREATE TABLE classrooms (
  id              TEXT PRIMARY KEY,
  slug            TEXT NOT NULL UNIQUE,
  host_id         TEXT NOT NULL,
  level_id        TEXT,
  -- Content
  title           TEXT NOT NULL,
  description     TEXT NOT NULL,
  -- Schedule
  scheduled_at    INTEGER NOT NULL,
  duration_min    INTEGER NOT NULL DEFAULT 60,
  timezone        TEXT NOT NULL DEFAULT 'Asia/Ho_Chi_Minh',
  -- Capacity
  max_students    INTEGER NOT NULL DEFAULT 30,
  min_students    INTEGER NOT NULL DEFAULT 3,
  current_students INTEGER NOT NULL DEFAULT 0,
  -- Format
  format          TEXT NOT NULL CHECK (format IN ('lecture','workshop','discussion','qa','practice')),
  breakout_enabled INTEGER NOT NULL DEFAULT 1,
  breakout_size   INTEGER NOT NULL DEFAULT 4,
  ai_host_enabled INTEGER NOT NULL DEFAULT 1,
  ai_persona      TEXT NOT NULL DEFAULT 'facilitator'
                  CHECK (ai_persona IN ('facilitator','expert','socratic','tutor')),
  -- Status
  status          TEXT NOT NULL DEFAULT 'scheduled'
                  CHECK (status IN ('scheduled','live','ended','cancelled')),
  -- Recording
  recording_url   TEXT,
  transcript_md   TEXT,
  -- Metrics
  avg_engagement  REAL NOT NULL DEFAULT 0,
  avg_satisfaction REAL NOT NULL DEFAULT 0,
  -- Meta
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX idx_classrooms_host ON classrooms(host_id, status, scheduled_at DESC);
CREATE INDEX idx_classrooms_live ON classrooms(status, scheduled_at);
CREATE TABLE classroom_participants (
  id              TEXT PRIMARY KEY,
  classroom_id    TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  role            TEXT NOT NULL DEFAULT 'student'
                  CHECK (role IN ('student','co_host','observer','ai')),
  -- Breakout
  breakout_room   INTEGER,
  -- Engagement
  joined_at       INTEGER,
  left_at         INTEGER,
  total_minutes   INTEGER NOT NULL DEFAULT 0,
  messages_count  INTEGER NOT NULL DEFAULT 0,
  questions_count INTEGER NOT NULL DEFAULT 0,
  engagement_score REAL NOT NULL DEFAULT 0,
  -- Feedback
  satisfaction    INTEGER CHECK (satisfaction BETWEEN 1 AND 5),
  feedback        TEXT,
  -- Meta
  status          TEXT NOT NULL DEFAULT 'invited'
                  CHECK (status IN ('invited','joined','left','attended','no_show')),
  UNIQUE (classroom_id, user_id),
  FOREIGN KEY (classroom_id) REFERENCES classrooms(id) ON DELETE CASCADE
);
CREATE INDEX idx_participants_classroom ON classroom_participants(classroom_id, status);
CREATE INDEX idx_participants_user ON classroom_participants(user_id, joined_at DESC);
-- Live chat
CREATE TABLE classroom_messages (
  id              TEXT PRIMARY KEY,
  classroom_id    TEXT NOT NULL,
  user_id         TEXT,
  role            TEXT NOT NULL CHECK (role IN ('student','host','ai','system')),
  content         TEXT NOT NULL,
  content_type    TEXT NOT NULL DEFAULT 'text'
                  CHECK (content_type IN ('text','question','poll','resource','system')),
  -- Reactions
  upvotes         INTEGER NOT NULL DEFAULT 0,
  -- Meta
  breakout_room   INTEGER,
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (classroom_id) REFERENCES classrooms(id) ON DELETE CASCADE
);
CREATE INDEX idx_class_messages ON classroom_messages(classroom_id, created_at DESC);
-- Breakout rooms
CREATE TABLE breakout_rooms (
  id              TEXT PRIMARY KEY,
  classroom_id    TEXT NOT NULL,
  room_number     INTEGER NOT NULL,
  topic           TEXT NOT NULL,
  -- AI facilitator
  ai_facilitator_enabled INTEGER NOT NULL DEFAULT 1,
  ai_agent_id     TEXT,
  -- Members
  member_ids_json TEXT DEFAULT '[]',
  -- Status
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','active','wrapping_up','closed')),
  started_at      INTEGER,
  ended_at        INTEGER,
  -- Summary
  discussion_summary TEXT,
  key_insights_json TEXT DEFAULT '[]',
  created_at      INTEGER NOT NULL,
  UNIQUE (classroom_id, room_number),
  FOREIGN KEY (classroom_id) REFERENCES classrooms(id) ON DELETE CASCADE
);
CREATE INDEX idx_breakout_classroom ON breakout_rooms(classroom_id, status);
-- Live polls
CREATE TABLE classroom_polls (
  id              TEXT PRIMARY KEY,
  classroom_id    TEXT NOT NULL,
  question        TEXT NOT NULL,
  options_json    TEXT NOT NULL,                  -- [{id, text}]
  correct_option  TEXT,
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','closed')),
  created_by      TEXT NOT NULL,
  created_at      INTEGER NOT NULL,
  closed_at       INTEGER
);
CREATE TABLE classroom_poll_votes (
  id              TEXT PRIMARY KEY,
  poll_id         TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  option_id       TEXT NOT NULL,
  created_at      INTEGER NOT NULL,
  UNIQUE (poll_id, user_id),
  FOREIGN KEY (poll_id) REFERENCES classroom_polls(id) ON DELETE CASCADE
);
CREATE INDEX idx_poll_votes ON classroom_poll_votes(poll_id, option_id);
