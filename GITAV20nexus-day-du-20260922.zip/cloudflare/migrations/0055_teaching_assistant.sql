-- =========================================================
-- V21: TEACHING ASSISTANT — Trợ giảng AI cho creator
-- Tự trả lời 80% câu hỏi học viên, escalate 20% khó
-- =========================================================
CREATE TABLE ta_agents (
  id              TEXT PRIMARY KEY,
  creator_id      TEXT NOT NULL,
  -- Scope
  level_ids_json  TEXT DEFAULT '[]',
  course_ids_json TEXT DEFAULT '[]',
  -- Persona
  persona_name    TEXT NOT NULL DEFAULT 'Trợ giảng AI',
  persona_style   TEXT NOT NULL DEFAULT 'warm'
                  CHECK (persona_style IN ('warm','direct','socratic','professional')),
  intro_message   TEXT,
  -- Config
  auto_reply_threshold REAL NOT NULL DEFAULT 0.75,  -- Confidence để auto-send
  escalation_topics_json TEXT DEFAULT '[]',          -- Topics cần escalate
  working_hours_json TEXT DEFAULT '{"start":6,"end":23}',
  -- Stats
  total_replies   INTEGER NOT NULL DEFAULT 0,
  auto_sent       INTEGER NOT NULL DEFAULT 0,
  escalated       INTEGER NOT NULL DEFAULT 0,
  avg_helpfulness REAL NOT NULL DEFAULT 0,
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','paused','archived')),
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX idx_ta_agents_creator ON ta_agents(creator_id, status);
CREATE TABLE ta_conversations (
  id              TEXT PRIMARY KEY,
  agent_id        TEXT NOT NULL,
  student_id      TEXT NOT NULL,
  level_id        TEXT,
  course_id       TEXT,
  -- Status
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','resolved','escalated','closed')),
  -- Metrics
  total_turns     INTEGER NOT NULL DEFAULT 0,
  resolved_by_ai  INTEGER NOT NULL DEFAULT 0,
  escalated_to    TEXT,                            -- creator user_id if escalated
  escalated_at    INTEGER,
  escalation_reason TEXT,
  -- Meta
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL,
  FOREIGN KEY (agent_id) REFERENCES ta_agents(id) ON DELETE CASCADE
);
CREATE INDEX idx_ta_conv_student ON ta_conversations(student_id, status, updated_at DESC);
CREATE INDEX idx_ta_conv_agent ON ta_conversations(agent_id, status);
CREATE TABLE ta_messages (
  id              TEXT PRIMARY KEY,
  conversation_id TEXT NOT NULL,
  speaker         TEXT NOT NULL CHECK (speaker IN ('student','ai','creator','system')),
  content         TEXT NOT NULL,
  -- AI metadata
  confidence      REAL,
  citations_json  TEXT DEFAULT '[]',
  -- Feedback
  student_rating  INTEGER CHECK (student_rating BETWEEN 1 AND 5),
  -- Meta
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (conversation_id) REFERENCES ta_conversations(id) ON DELETE CASCADE
);
CREATE INDEX idx_ta_msg ON ta_messages(conversation_id, created_at ASC);
-- Training examples (creator-approved answers)
CREATE TABLE ta_training_examples (
  id              TEXT PRIMARY KEY,
  agent_id        TEXT NOT NULL,
  question        TEXT NOT NULL,
  answer          TEXT NOT NULL,
  context         TEXT,
  approved_by     TEXT NOT NULL,
  usage_count     INTEGER NOT NULL DEFAULT 0,
  quality_score   REAL NOT NULL DEFAULT 1.0,
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (agent_id) REFERENCES ta_agents(id) ON DELETE CASCADE
);
CREATE INDEX idx_ta_training ON ta_training_examples(agent_id, quality_score DESC);
