-- =========================================================
-- V17: LIVE COHORTS — Lớp học 30 ngày có cộng đồng
-- =========================================================
CREATE TABLE cohorts (
  id              TEXT PRIMARY KEY,
  slug            TEXT NOT NULL UNIQUE,
  course_id       TEXT,                          -- Optional: gắn course
  level_id        TEXT,                          -- Optional: gắn level
  name            TEXT NOT NULL,
  description     TEXT NOT NULL,
  -- Schedule
  start_date      INTEGER NOT NULL,
  end_date        INTEGER NOT NULL,
  duration_days   INTEGER NOT NULL DEFAULT 30,
  timezone        TEXT NOT NULL DEFAULT 'Asia/Ho_Chi_Minh',
  -- Capacity
  max_members     INTEGER NOT NULL DEFAULT 30,
  min_members     INTEGER NOT NULL DEFAULT 5,
  current_members INTEGER NOT NULL DEFAULT 0,
  -- Facilitator
  facilitator_id  TEXT NOT NULL,
  co_facilitators_json TEXT DEFAULT '[]',
  -- Status
  status          TEXT NOT NULL DEFAULT 'draft'
                  CHECK (status IN ('draft','open','full','running','completed','cancelled')),
  -- Chat channel (Telegram group hoặc custom)
  chat_provider   TEXT CHECK (chat_provider IN ('telegram','discord','internal')),
  chat_ref        TEXT,                          -- chat_id or invite link
  -- Metrics
  completion_rate REAL NOT NULL DEFAULT 0,
  avg_satisfaction REAL NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX idx_cohorts_status ON cohorts(status, start_date DESC);
CREATE INDEX idx_cohorts_facilitator ON cohorts(facilitator_id, status);
CREATE TABLE cohort_members (
  id              TEXT PRIMARY KEY,
  cohort_id       TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  role            TEXT NOT NULL DEFAULT 'member'
                  CHECK (role IN ('member','buddy','co_facilitator','facilitator')),
  -- Buddy pairing
  buddy_user_id   TEXT,
  -- Progress
  joined_at       INTEGER NOT NULL,
  completed_at    INTEGER,
  streak_days     INTEGER NOT NULL DEFAULT 0,
  points          INTEGER NOT NULL DEFAULT 0,
  -- Status
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('invited','active','inactive','dropped','completed')),
  -- Feedback
  satisfaction    INTEGER CHECK (satisfaction BETWEEN 1 AND 5),
  feedback        TEXT,
  UNIQUE (cohort_id, user_id),
  FOREIGN KEY (cohort_id) REFERENCES cohorts(id) ON DELETE CASCADE
);
CREATE INDEX idx_members_cohort ON cohort_members(cohort_id, status);
CREATE INDEX idx_members_user ON cohort_members(user_id, status);
-- Daily check-ins
CREATE TABLE cohort_checkins (
  id              TEXT PRIMARY KEY,
  cohort_id       TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  day_number      INTEGER NOT NULL,           -- 1..30
  content         TEXT NOT NULL,
  mood            TEXT,
  wins_json       TEXT DEFAULT '[]',
  blockers_json   TEXT DEFAULT '[]',
  created_at      INTEGER NOT NULL,
  UNIQUE (cohort_id, user_id, day_number)
);
CREATE INDEX idx_checkins_cohort_day ON cohort_checkins(cohort_id, day_number);
-- Weekly assignments
CREATE TABLE cohort_assignments (
  id              TEXT PRIMARY KEY,
  cohort_id       TEXT NOT NULL,
  week_number     INTEGER NOT NULL,           -- 1..4
  title           TEXT NOT NULL,
  description     TEXT NOT NULL,
  deliverable_md  TEXT NOT NULL,
  due_at          INTEGER NOT NULL,
  created_at      INTEGER NOT NULL,
  UNIQUE (cohort_id, week_number)
);
CREATE TABLE cohort_submissions (
  id              TEXT PRIMARY KEY,
  assignment_id   TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  content_md      TEXT NOT NULL,
  attachments_json TEXT DEFAULT '[]',
  peer_reviews_json TEXT DEFAULT '[]',        -- [{reviewerId, rating, feedback}]
  ai_score        REAL,
  ai_feedback     TEXT,
  final_score     REAL,
  submitted_at    INTEGER NOT NULL,
  UNIQUE (assignment_id, user_id)
);
-- Activity feed
CREATE TABLE cohort_activities (
  id              TEXT PRIMARY KEY,
  cohort_id       TEXT NOT NULL,
  user_id         TEXT,
  activity_type   TEXT NOT NULL,              -- 'join','checkin','submission','peer_review','milestone'
  data_json       TEXT,
  created_at      INTEGER NOT NULL
);
CREATE INDEX idx_activities_cohort ON cohort_activities(cohort_id, created_at DESC);
