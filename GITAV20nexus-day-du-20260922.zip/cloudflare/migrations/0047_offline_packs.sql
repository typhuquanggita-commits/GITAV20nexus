-- =========================================================
-- V19: OFFLINE PACKS — Download 1 lần, học offline vô hạn
-- Pack = ZIP chứa: content JSON + audio + video links + quiz
-- =========================================================
CREATE TABLE offline_packs (
  id              TEXT PRIMARY KEY,
  -- Source
  source_type     TEXT NOT NULL CHECK (source_type IN ('level','course','tier','custom')),
  source_id       TEXT NOT NULL,
  title           TEXT NOT NULL,
  description     TEXT,
  cover_url       TEXT,
  -- Content
  level_ids_json  TEXT DEFAULT '[]',
  course_ids_json TEXT DEFAULT '[]',
  -- Size & format
  version         TEXT NOT NULL DEFAULT 'v1.0.0',
  format          TEXT NOT NULL DEFAULT 'zip'
                  CHECK (format IN ('zip','tar.gz')),
  total_size_bytes INTEGER NOT NULL DEFAULT 0,
  compressed_size_bytes INTEGER NOT NULL DEFAULT 0,
  -- Files manifest
  manifest_json   TEXT NOT NULL,               -- [{path, sizeBytes, hash, type}]
  -- Access
  required_tier   TEXT NOT NULL DEFAULT 'free'
                  CHECK (required_tier IN ('free','verified','paid')),
  -- Meta
  status          TEXT NOT NULL DEFAULT 'building'
                  CHECK (status IN ('building','ready','failed','deprecated')),
  downloads_count INTEGER NOT NULL DEFAULT 0,
  avg_rating      REAL NOT NULL DEFAULT 0,
  rating_count    INTEGER NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX idx_packs_source ON offline_packs(source_type, source_id, status);
CREATE INDEX idx_packs_ready ON offline_packs(status, downloads_count DESC);
CREATE TABLE pack_downloads (
  id              TEXT PRIMARY KEY,
  pack_id         TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  -- Download
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','downloading','completed','failed','revoked')),
  bytes_downloaded INTEGER NOT NULL DEFAULT 0,
  -- Device tracking
  device_id       TEXT,
  device_os       TEXT,
  -- Verification (offline)
  license_key     TEXT,                          -- Signed key cho offline unlock
  license_expires_at INTEGER,
  -- Meta
  created_at      INTEGER NOT NULL,
  completed_at    INTEGER,
  UNIQUE (pack_id, user_id, device_id)
);
CREATE INDEX idx_downloads_user ON pack_downloads(user_id, status, created_at DESC);
CREATE INDEX idx_downloads_pack ON pack_downloads(pack_id, status);
-- User's offline library
CREATE TABLE offline_library (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  pack_id         TEXT NOT NULL,
  installed_at    INTEGER NOT NULL,
  last_opened_at  INTEGER,
  -- Local progress (synced back when online)
  local_progress_json TEXT DEFAULT '{}',
  synced_at       INTEGER,
  UNIQUE (user_id, pack_id)
);
CREATE INDEX idx_library_user ON offline_library(user_id, last_opened_at DESC);
