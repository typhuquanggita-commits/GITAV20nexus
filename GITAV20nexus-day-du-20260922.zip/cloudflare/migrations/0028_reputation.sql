-- =========================================================
-- V13: COMMUNITY REPUTATION — Huy động 1000 members
-- =========================================================
CREATE TABLE reputation_scores (
  user_id         TEXT PRIMARY KEY,
  total_points    INTEGER NOT NULL DEFAULT 0,
  level           TEXT NOT NULL DEFAULT 'newcomer'
                  CHECK (level IN ('newcomer','contributor','reviewer','expert','master')),
  reviews_count   INTEGER NOT NULL DEFAULT 0,
  edits_count     INTEGER NOT NULL DEFAULT 0,
  approvals_count INTEGER NOT NULL DEFAULT 0,
  rejections_count INTEGER NOT NULL DEFAULT 0,
  reputation_score REAL NOT NULL DEFAULT 0,   -- Weighted quality
  last_active_at  INTEGER,
  updated_at      INTEGER NOT NULL
);
CREATE TABLE contribution_events (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  event_type      TEXT NOT NULL
                  CHECK (event_type IN ('review','edit','approve','reject','flag','suggest')),
  content_type    TEXT NOT NULL,
  content_id      TEXT NOT NULL,
  points_delta    INTEGER NOT NULL,
  reason          TEXT,
  verified_by     TEXT,                       -- Ai xác nhận (peer/owner/auto)
  created_at      INTEGER NOT NULL
);
CREATE INDEX idx_contrib_user ON contribution_events(user_id, created_at DESC);
CREATE INDEX idx_contrib_content ON contribution_events(content_type, content_id);
-- Badges
CREATE TABLE user_badges (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  badge_code      TEXT NOT NULL,
  metadata_json   TEXT,
  earned_at       INTEGER NOT NULL,
  UNIQUE (user_id, badge_code)
);
-- Reward ledger (off-chain points)
CREATE TABLE reward_ledger (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  points          INTEGER NOT NULL,
  source          TEXT NOT NULL,              -- 'review','edit','publish','streak'
  reference_id    TEXT,
  created_at      INTEGER NOT NULL
);
CREATE INDEX idx_reward_user ON reward_ledger(user_id, created_at DESC);
