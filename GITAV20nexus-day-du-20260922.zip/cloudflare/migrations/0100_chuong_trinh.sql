-- =========================================================
-- CHƯƠNG TRÌNH HỌC — Toán · Tiếng Anh · Ngữ văn, lớp 1 đến 12
--
-- Bảy cấp độ, và chúng KHÔNG phải bảy cái tên cho cùng một thứ:
--   co-ban    — làm chủ chương trình chính khoá, đích là 9–10 điểm
--   nang-cao  — vượt trên yêu cầu sách giáo khoa
--   clc       — thi vào lớp chất lượng cao
--   hsg       — thi học sinh giỏi cấp trường, huyện, tỉnh
--   chuyen    — thi vào trường chuyên
--   dai-hoc   — thi tốt nghiệp và xét tuyển đại học
--   quoc-te   — thi giải quốc tế
--
-- Chuẩn kiến thức lấy từ ba nguồn có thật, ghi rõ nguồn ở cột nguon_chuan:
--   moet  — Chương trình giáo dục phổ thông 2018 của Bộ Giáo dục và Đạo tạo
--   us    — Common Core State Standards và khung của College Board
--   toan  — quy ước ký hiệu toán học quốc tế (ISO 80000-2)
-- Không có nguồn nào tên là "AI". Chuẩn do máy nghĩ ra không được vào bảng này.
-- =========================================================

CREATE TABLE IF NOT EXISTS mon_hoc (
  id          TEXT PRIMARY KEY,           -- 'toan' | 'tieng-anh' | 'ngu-van'
  ten         TEXT NOT NULL,
  ten_en      TEXT,
  thu_tu      INTEGER NOT NULL,
  mo_ta       TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS cap_do (
  id          TEXT PRIMARY KEY,           -- 'co-ban' … 'quoc-te'
  ten         TEXT NOT NULL,
  thu_tu      INTEGER NOT NULL,           -- 1..7, càng lớn càng khó
  dich_den    TEXT NOT NULL,              -- đích đo được của cấp độ này
  dieu_kien_vao TEXT NOT NULL             -- phải đạt gì mới được vào
);

-- Một ô của chương trình: môn × lớp × cấp độ.
CREATE TABLE IF NOT EXISTS o_chuong_trinh (
  id            TEXT PRIMARY KEY,         -- 'toan-l7-hsg'
  mon_id        TEXT NOT NULL,
  lop           INTEGER NOT NULL CHECK (lop BETWEEN 1 AND 12),
  cap_do_id     TEXT NOT NULL,
  so_chuyen_de  INTEGER NOT NULL DEFAULT 0,   -- đếm lại từ bảng chuyen_de
  so_bai        INTEGER NOT NULL DEFAULT 0,   -- đếm lại từ bảng bai_tap
  gio_du_kien   INTEGER,                      -- số giờ học dự kiến
  mo_ta         TEXT,
  UNIQUE (mon_id, lop, cap_do_id),
  FOREIGN KEY (mon_id)    REFERENCES mon_hoc(id),
  FOREIGN KEY (cap_do_id) REFERENCES cap_do(id)
);
CREATE INDEX IF NOT EXISTS idx_o_ct_mon ON o_chuong_trinh(mon_id, lop, cap_do_id);

-- Chuẩn kiến thức — mỗi dòng là một yêu cầu cần đạt, có nguồn.
CREATE TABLE IF NOT EXISTS chuan_kien_thuc (
  id           TEXT PRIMARY KEY,
  o_id         TEXT NOT NULL,
  ma           TEXT NOT NULL,             -- mã trong tài liệu gốc, ví dụ '7.ĐS.3'
  yeu_cau      TEXT NOT NULL,             -- yêu cầu cần đạt, chép từ nguồn
  nguon_chuan  TEXT NOT NULL CHECK (nguon_chuan IN ('moet','us','toan')),
  trich_dan    TEXT NOT NULL,             -- tên văn bản và mục cụ thể
  bac_nhan_thuc TEXT NOT NULL             -- thang Bloom
               CHECK (bac_nhan_thuc IN ('nho','hieu','van-dung','phan-tich','danh-gia','sang-tao')),
  created_at   INTEGER NOT NULL,
  UNIQUE (o_id, ma),
  FOREIGN KEY (o_id) REFERENCES o_chuong_trinh(id)
);
CREATE INDEX IF NOT EXISTS idx_chuan_o ON chuan_kien_thuc(o_id);
CREATE INDEX IF NOT EXISTS idx_chuan_nguon ON chuan_kien_thuc(nguon_chuan);

-- Chuyên đề — đơn vị giảng dạy. Đích của hệ: 8.000 chuyên đề.
CREATE TABLE IF NOT EXISTS chuyen_de (
  id            TEXT PRIMARY KEY,
  o_id          TEXT NOT NULL,
  ma            TEXT NOT NULL,
  ten           TEXT NOT NULL,
  thu_tu        INTEGER NOT NULL,
  tom_tat       TEXT,
  tien_quyet_json TEXT NOT NULL DEFAULT '[]',   -- mã chuyên đề phải học trước
  chuan_ids_json  TEXT NOT NULL DEFAULT '[]',   -- chuẩn kiến thức nó phủ
  so_bai        INTEGER NOT NULL DEFAULT 0,
  gio_du_kien   INTEGER,
  trang_thai    TEXT NOT NULL DEFAULT 'nhap'
                CHECK (trang_thai IN ('nhap','da-soat','da-xuat-ban','thu-hoi')),
  nguoi_tao     TEXT,
  created_at    INTEGER NOT NULL,
  updated_at    INTEGER NOT NULL,
  UNIQUE (o_id, ma),
  FOREIGN KEY (o_id) REFERENCES o_chuong_trinh(id)
);
CREATE INDEX IF NOT EXISTS idx_chuyen_de_o  ON chuyen_de(o_id, thu_tu);
CREATE INDEX IF NOT EXISTS idx_chuyen_de_tt ON chuyen_de(trang_thai);

-- Bài giảng thuộc chuyên đề.
CREATE TABLE IF NOT EXISTS bai_giang (
  id            TEXT PRIMARY KEY,
  chuyen_de_id  TEXT NOT NULL,
  ma            TEXT NOT NULL,
  ten           TEXT NOT NULL,
  thu_tu        INTEGER NOT NULL,
  noi_dung_md   TEXT,                     -- nội dung bài, viết bằng Markdown
  ky_hieu_chuan TEXT NOT NULL DEFAULT 'iso-80000-2',
  so_phut       INTEGER,
  video_id      TEXT,
  trang_thai    TEXT NOT NULL DEFAULT 'nhap'
                CHECK (trang_thai IN ('nhap','da-soat','da-xuat-ban','thu-hoi')),
  created_at    INTEGER NOT NULL,
  updated_at    INTEGER NOT NULL,
  UNIQUE (chuyen_de_id, ma),
  FOREIGN KEY (chuyen_de_id) REFERENCES chuyen_de(id)
);
CREATE INDEX IF NOT EXISTS idx_bai_giang_cd ON bai_giang(chuyen_de_id, thu_tu);
