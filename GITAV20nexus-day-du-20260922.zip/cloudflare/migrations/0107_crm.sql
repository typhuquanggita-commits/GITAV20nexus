-- =========================================================
-- CRM — 50 TRỢ LÝ CHUYÊN TRÁCH QUAN HỆ GIA ĐÌNH
--
-- Tầng này KHÔNG gộp vào 600 trợ lý chuyên môn. Lý do: 600 trợ lý kia
-- làm việc trên nội dung học, còn 50 người này đọc dữ liệu thật của
-- một gia đình. Hai kho dữ liệu, hai bộ quyền, hai nhật ký.
--
-- CÂY TIỀN: cách hệ thống phân loại khả năng chi trả của một gia đình
-- CHỈ tồn tại trong tầng quản trị. Không cột nào ở đây đi ra được
-- đường công khai; lớp canh đường ra chặn cả khi mã gọi nhầm.
-- =========================================================

CREATE TABLE IF NOT EXISTS crm_tro_ly (
  id           TEXT PRIMARY KEY,          -- 'crm-01' … 'crm-50'
  ten          TEXT NOT NULL,
  to_id        TEXT NOT NULL,             -- tổ: tiep-nhan, tu-van, cham-soc, thu-hoi, phan-tich
  vai          TEXT NOT NULL
               CHECK (vai IN ('to-truong','tiep-nhan','tu-van','cham-soc','thu-hoi','phan-tich')),
  suc_chua_ngay INTEGER NOT NULL DEFAULT 30,
  muc_tu_chu   INTEGER NOT NULL DEFAULT 1 CHECK (muc_tu_chu BETWEEN 0 AND 3),
  trang_thai   TEXT NOT NULL DEFAULT 'ranh'
               CHECK (trang_thai IN ('ranh','dang-lam','tam-nghi')),
  created_at   INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS gia_dinh (
  id           TEXT PRIMARY KEY,
  ten_lien_he  TEXT NOT NULL,
  dien_thoai   TEXT,
  email        TEXT,
  tinh_thanh   TEXT,
  nguon_den    TEXT,                      -- biết tới hệ thống từ đâu
  chang        TEXT NOT NULL DEFAULT 'moi'
               CHECK (chang IN ('moi','da-lien-he','da-tu-van','da-test','dang-hoc','tam-dung','roi-di')),
  tro_ly_id    TEXT,
  cay_tien_nhom TEXT,                     -- CHỈ tầng quản trị đọc được
  cay_tien_luc  INTEGER,
  ghi_chu      TEXT,
  created_at   INTEGER NOT NULL,
  updated_at   INTEGER NOT NULL,
  FOREIGN KEY (tro_ly_id) REFERENCES crm_tro_ly(id)
);
CREATE INDEX IF NOT EXISTS idx_gd_chang ON gia_dinh(chang, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_gd_troly ON gia_dinh(tro_ly_id);

CREATE TABLE IF NOT EXISTS gia_dinh_hoc_vien (
  id           TEXT PRIMARY KEY,
  gia_dinh_id  TEXT NOT NULL,
  user_id      TEXT NOT NULL,
  quan_he      TEXT NOT NULL,
  UNIQUE (gia_dinh_id, user_id),
  FOREIGN KEY (gia_dinh_id) REFERENCES gia_dinh(id),
  FOREIGN KEY (user_id)     REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS crm_viec (
  id           TEXT PRIMARY KEY,
  gia_dinh_id  TEXT NOT NULL,
  tro_ly_id    TEXT,
  loai         TEXT NOT NULL
               CHECK (loai IN ('goi-dien','nhan-tin','tu-van','xep-lich-test','bao-ket-qua','nhac-hoc-phi','cham-soc','xu-ly-phan-nan')),
  noi_dung     TEXT NOT NULL,
  han           INTEGER,
  trang_thai   TEXT NOT NULL DEFAULT 'cho'
               CHECK (trang_thai IN ('cho','dang-lam','cho-nguoi-duyet','xong','huy')),
  ket_qua      TEXT,
  can_nguoi    INTEGER NOT NULL DEFAULT 0,
  created_at   INTEGER NOT NULL,
  xong_luc     INTEGER,
  FOREIGN KEY (gia_dinh_id) REFERENCES gia_dinh(id),
  FOREIGN KEY (tro_ly_id)   REFERENCES crm_tro_ly(id)
);
CREATE INDEX IF NOT EXISTS idx_crm_viec_tt ON crm_viec(trang_thai, han);
CREATE INDEX IF NOT EXISTS idx_crm_viec_gd ON crm_viec(gia_dinh_id, created_at DESC);

CREATE TABLE IF NOT EXISTS crm_tuong_tac (
  id           TEXT PRIMARY KEY,
  gia_dinh_id  TEXT NOT NULL,
  kenh         TEXT NOT NULL CHECK (kenh IN ('dien-thoai','tin-nhan','email','gap-mat','trang-web')),
  huong        TEXT NOT NULL CHECK (huong IN ('den','di')),
  tom_tat      TEXT NOT NULL,
  tro_ly_id    TEXT,
  nguoi_id     TEXT,
  at           INTEGER NOT NULL,
  FOREIGN KEY (gia_dinh_id) REFERENCES gia_dinh(id)
);
CREATE INDEX IF NOT EXISTS idx_crm_tt_gd ON crm_tuong_tac(gia_dinh_id, at DESC);
