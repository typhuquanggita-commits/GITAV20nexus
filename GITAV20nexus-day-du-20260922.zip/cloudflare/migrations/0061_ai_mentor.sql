-- =========================================================
-- V22: PERSONAL AI MENTOR — Bộ nhớ dài hạn nhiều năm
-- Nhớ hành trình, giá trị, mục tiêu, bài học đã qua
-- =========================================================
CREATE TABLE mentor_profiles (
  user_id         TEXT PRIMARY KEY,
  -- Identity
  mentor_name     TEXT NOT NULL DEFAULT 'An',       -- AI mentor's name
  user_display_name TEXT,
  -- Long-term context
  life_stage      TEXT,                              -- 'student','early_career','mid_career','founder','retired'
  core_values_json TEXT DEFAULT '[]',                -- ['family','growth','integrity']
  long_term_vision TEXT,                              -- Vision 5-10 năm
  current_challenges_json TEXT DEFAULT '[]',
  -- Communication
  preferred_tone  TEXT NOT NULL DEFAULT 'warm'
                  CHECK (preferred_tone IN ('warm','direct','socratic','strategic')),
  preferred_depth TEXT NOT NULL DEFAULT 'balanced',
  -- Memory metrics
  memory_items_count INTEGER NOT NULL DEFAULT 0,
  sessions_count  INTEGER NOT NULL DEFAULT 0,
  days_known      INTEGER NOT NULL DEFAULT 0,
  -- Meta
  first_session_at INTEGER,
  last_session_at INTEGER,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX idx_mentor_active ON mentor_profiles(last_session_at DESC);
-- Long-term memory (facts mentor remembers)
CREATE TABLE mentor_memories (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  -- Memory
  memory_type     TEXT NOT NULL CHECK (memory_type IN (
    'fact','preference','goal','value','challenge','win','loss','insight','person','project'
  )),
  content         TEXT NOT NULL,
  -- Context
  context         TEXT,
  importance      REAL NOT NULL DEFAULT 0.5,         -- 0-1
  emotional_weight REAL NOT NULL DEFAULT 0,           -- -1 to 1 (negative → positive)
  -- Recall
  recall_count    INTEGER NOT NULL DEFAULT 0,
  last_recalled_at INTEGER,
  -- Source
  source_session_id TEXT,
  source_excerpt  TEXT,
  -- Status
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','archived','resolved','outdated')),
  -- Meta
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX idx_memories_user ON mentor_memories(user_id, status, importance DESC);
CREATE INDEX idx_memories_type ON mentor_memories(user_id, memory_type, importance DESC);
-- Mentor sessions (conversations)
CREATE TABLE mentor_sessions (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  -- Session
  session_type    TEXT NOT NULL CHECK (session_type IN (
    'daily_checkin','weekly_reflection','monthly_review','crisis','celebration','planning','ad_hoc'
  )),
  -- Messages count
  user_message_count INTEGER NOT NULL DEFAULT 0,
  ai_message_count INTEGER NOT NULL DEFAULT 0,
  duration_min    INTEGER,
  -- Content
  topic           TEXT,
  key_insights_json TEXT DEFAULT '[]',
  action_items_json TEXT DEFAULT '[]',
  mood_arc_json   TEXT,                              -- [{timestamp, mood}]
  -- Meta
  started_at      INTEGER NOT NULL,
  ended_at        INTEGER
);
CREATE INDEX idx_mentor_sessions ON mentor_sessions(user_id, started_at DESC);
CREATE TABLE mentor_messages (
  id              TEXT PRIMARY KEY,
  session_id      TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  role            TEXT NOT NULL CHECK (role IN ('user','mentor','system')),
  content         TEXT NOT NULL,
  -- Memory extraction
  memories_extracted_json TEXT DEFAULT '[]',
  -- Meta
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (session_id) REFERENCES mentor_sessions(id) ON DELETE CASCADE
);
CREATE INDEX idx_mentor_msgs ON mentor_messages(session_id, created_at);
-- Milestones (mentor celebrates with user)
CREATE TABLE mentor_milestones (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  milestone_type  TEXT NOT NULL,
  title           TEXT NOT NULL,
  description     TEXT,
  celebrated      INTEGER NOT NULL DEFAULT 0,
  celebrated_at   INTEGER,
  created_at      INTEGER NOT NULL
);
CREATE INDEX idx_milestones_user ON mentor_milestones(user_id, celebrated, created_at DESC);
