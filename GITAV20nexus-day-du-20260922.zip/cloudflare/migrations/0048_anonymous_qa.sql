-- =========================================================
-- V19: ANONYMOUS Q\&A — Hỏi đáp ẩn danh có moderation AI
-- =========================================================
CREATE TABLE qa_topics (
  id              TEXT PRIMARY KEY,
  slug            TEXT NOT NULL UNIQUE,
  name            TEXT NOT NULL,
  description     TEXT,
  category        TEXT NOT NULL,
  icon            TEXT,
  is_sensitive    INTEGER NOT NULL DEFAULT 0,     -- Cần moderation chặt
  post_count      INTEGER NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL
);
CREATE INDEX idx_qa_topics ON qa_topics(category, post_count DESC);
CREATE TABLE qa_questions (
  id              TEXT PRIMARY KEY,
  topic_id        TEXT,
  anonymous_handle TEXT NOT NULL,                  -- Vd: "Ẩn danh #A1B2"
  -- Content
  title           TEXT NOT NULL,
  body_md         TEXT NOT NULL,
  tags_json       TEXT DEFAULT '[]',
  -- Anonymous metadata (không lưu user_id trực tiếp)
  author_hash     TEXT NOT NULL,                   -- SHA-256(userId + salt) - dùng để rate limit
  -- Status
  status          TEXT NOT NULL DEFAULT 'published'
                  CHECK (status IN ('pending','published','flagged','hidden','deleted')),
  -- Moderation
  moderation_score REAL NOT NULL DEFAULT 0,        -- 0-1 (1 = toàn toxic)
  moderation_labels_json TEXT DEFAULT '[]',
  auto_moderated  INTEGER NOT NULL DEFAULT 0,
  -- Metrics
  views           INTEGER NOT NULL DEFAULT 0,
  upvotes         INTEGER NOT NULL DEFAULT 0,
  answer_count    INTEGER NOT NULL DEFAULT 0,
  -- Meta
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL,
  FOREIGN KEY (topic_id) REFERENCES qa_topics(id)
);
CREATE INDEX idx_qa_questions ON qa_questions(status, created_at DESC);
CREATE INDEX idx_qa_topic ON qa_questions(topic_id, status, created_at DESC);
CREATE INDEX idx_qa_author_hash ON qa_questions(author_hash, created_at DESC);
CREATE TABLE qa_answers (
  id              TEXT PRIMARY KEY,
  question_id     TEXT NOT NULL,
  anonymous_handle TEXT NOT NULL,
  author_hash     TEXT NOT NULL,
  -- Content
  body_md         TEXT NOT NULL,
  -- Verification
  is_verified     INTEGER NOT NULL DEFAULT 0,      -- Verified by GITA team
  verified_by     TEXT,
  -- Status
  status          TEXT NOT NULL DEFAULT 'published'
                  CHECK (status IN ('pending','published','flagged','hidden','deleted')),
  moderation_score REAL NOT NULL DEFAULT 0,
  -- Metrics
  upvotes         INTEGER NOT NULL DEFAULT 0,
  -- Meta
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL,
  FOREIGN KEY (question_id) REFERENCES qa_questions(id) ON DELETE CASCADE
);
CREATE INDEX idx_qa_answers ON qa_answers(question_id, upvotes DESC, created_at DESC);
CREATE TABLE qa_votes (
  id              TEXT PRIMARY KEY,
  target_type     TEXT NOT NULL CHECK (target_type IN ('question','answer')),
  target_id       TEXT NOT NULL,
  voter_hash      TEXT NOT NULL,                   -- Hashed user_id
  vote            INTEGER NOT NULL CHECK (vote IN (-1, 1)),
  created_at      INTEGER NOT NULL,
  UNIQUE (target_type, target_id, voter_hash)
);
CREATE INDEX idx_qa_votes_target ON qa_votes(target_type, target_id);
CREATE TABLE qa_reports (
  id              TEXT PRIMARY KEY,
  target_type     TEXT NOT NULL CHECK (target_type IN ('question','answer')),
  target_id       TEXT NOT NULL,
  reporter_hash   TEXT NOT NULL,
  reason          TEXT NOT NULL CHECK (reason IN ('spam','harassment','misinformation','off_topic','sensitive','other')),
  description     TEXT,
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','reviewed','actioned','dismissed')),
  reviewed_by     TEXT,
  reviewed_at     INTEGER,
  created_at      INTEGER NOT NULL
);
CREATE INDEX idx_reports_status ON qa_reports(status, created_at DESC);
-- Ban list (hashed)
CREATE TABLE qa_bans (
  id              TEXT PRIMARY KEY,
  author_hash     TEXT NOT NULL UNIQUE,
  reason          TEXT NOT NULL,
  banned_by       TEXT NOT NULL,
  expires_at      INTEGER,                          -- NULL = permanent
  created_at      INTEGER NOT NULL
);
