-- =========================================================
-- V21: MICRO-LEARNING — 5 phút/ngày, cá nhân hóa
-- =========================================================
CREATE TABLE micro_paths (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  -- Goal
  goal_title      TEXT NOT NULL,
  goal_level_ids_json TEXT DEFAULT '[]',
  -- Schedule
  minutes_per_day INTEGER NOT NULL DEFAULT 5,
  days_per_week   INTEGER NOT NULL DEFAULT 6,
  start_date      TEXT NOT NULL,                  -- 'YYYY-MM-DD'
  -- Generated plan
  total_days      INTEGER NOT NULL DEFAULT 30,
  plan_json       TEXT NOT NULL,                  -- [{day, levelId, section, focus, estimateMin}]
  -- Progress
  completed_days  INTEGER NOT NULL DEFAULT 0,
  current_day     INTEGER NOT NULL DEFAULT 1,
  -- Status
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','paused','completed','abandoned')),
  -- Meta
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX idx_micro_user ON micro_paths(user_id, status, updated_at DESC);
CREATE TABLE micro_sessions (
  id              TEXT PRIMARY KEY,
  path_id         TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  day_number      INTEGER NOT NULL,
  -- Content for this day
  chunk_json      TEXT NOT NULL,                  -- {title, contentMd, quiz, durationMin}
  -- Progress
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','in_progress','completed','skipped')),
  started_at      INTEGER,
  completed_at    INTEGER,
  time_spent_sec  INTEGER NOT NULL DEFAULT 0,
  -- Feedback
  difficulty_felt TEXT CHECK (difficulty_felt IN ('too_easy','just_right','too_hard')),
  mood            TEXT,
  -- Meta
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (path_id) REFERENCES micro_paths(id) ON DELETE CASCADE,
  UNIQUE (path_id, day_number)
);
CREATE INDEX idx_micro_sessions ON micro_sessions(path_id, day_number);
CREATE TABLE micro_streaks (
  user_id         TEXT PRIMARY KEY,
  current_streak  INTEGER NOT NULL DEFAULT 0,
  best_streak     INTEGER NOT NULL DEFAULT 0,
  last_completed  TEXT,                            -- 'YYYY-MM-DD'
  total_days      INTEGER NOT NULL DEFAULT 0,
  updated_at      INTEGER NOT NULL
);
