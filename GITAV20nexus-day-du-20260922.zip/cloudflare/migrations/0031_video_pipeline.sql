-- =========================================================
-- V16: VIDEO PIPELINE — Auto-generate slideshow video
-- Slides + TTS audio → MP4 via ffmpeg.wasm (client-side)
-- Server chỉ lưu metadata + R2 cho file
-- =========================================================
CREATE TABLE video_jobs (
  id              TEXT PRIMARY KEY,
  level_id        TEXT NOT NULL,
  user_id         TEXT,                         -- NULL = system-generated
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','generating','ready','failed','deleted')),
  -- Config
  voice_id        TEXT NOT NULL DEFAULT 'vi-VN-HoaiMyNeural',
  language        TEXT NOT NULL DEFAULT 'vi',
  theme           TEXT NOT NULL DEFAULT 'default',
  duration_sec    INTEGER,
  slide_count     INTEGER,
  -- Output
  r2_key          TEXT,                          -- video file
  thumbnail_key   TEXT,
  subtitle_key    TEXT,                          -- .vtt
  transcript_json TEXT,
  byte_size       INTEGER,
  -- Metrics
  view_count      INTEGER NOT NULL DEFAULT 0,
  download_count  INTEGER NOT NULL DEFAULT 0,
  -- Meta
  error_log       TEXT,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX idx_video_level ON video_jobs(level_id, status);
CREATE INDEX idx_video_user ON video_jobs(user_id, created_at DESC);
-- Slides data (JSON spec cho client render)
CREATE TABLE video_slides (
  id              TEXT PRIMARY KEY,
  job_id          TEXT NOT NULL,
  slide_index     INTEGER NOT NULL,
  slide_type      TEXT NOT NULL CHECK (slide_type IN ('title','content','image','quote','quiz','outro')),
  title           TEXT,
  body_md         TEXT,
  bg_color        TEXT,
  accent_color    TEXT,
  duration_ms     INTEGER NOT NULL,
  audio_text      TEXT,                          -- Text để TTS
  audio_r2_key    TEXT,                          -- Generated audio
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (job_id) REFERENCES video_jobs(id) ON DELETE CASCADE,
  UNIQUE (job_id, slide_index)
);
-- Video views (analytics)
CREATE TABLE video_views (
  id              TEXT PRIMARY KEY,
  video_id        TEXT NOT NULL,
  user_id         TEXT,
  watched_sec     INTEGER NOT NULL DEFAULT 0,
  completion_pct  REAL NOT NULL DEFAULT 0,
  device          TEXT,
  created_at      INTEGER NOT NULL
);
CREATE INDEX idx_views_video ON video_views(video_id, created_at DESC);
