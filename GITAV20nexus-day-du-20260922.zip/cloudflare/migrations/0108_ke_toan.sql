-- =========================================================
-- TÀI CHÍNH KẾ TOÁN — GHI SỔ KÉP
--
-- Vì sao ghi sổ kép chứ không phải một bảng thu chi: một bảng thu chi
-- không bao giờ tự phát hiện được sai. Ghi sổ kép thì tổng Nợ phải
-- bằng tổng Có ở từng chứng từ, và lệch một đồng là biết ngay — đây
-- chính là thứ phần mềm kế toán nghiêm túc nào cũng có.
--
-- Hệ thống tài khoản theo Thông tư 200/2014/TT-BTC (doanh nghiệp) và
-- Thông tư 133/2016/TT-BTC (doanh nghiệp nhỏ và vừa). Cột thong_tu ghi
-- rõ dòng ấy theo văn bản nào.
--
-- Chứng từ đã ghi sổ thì KHÔNG sửa và KHÔNG xoá. Sai thì ghi bút toán
-- đảo. Cột dao_cua_id giữ mối liên hệ ấy.
-- =========================================================

CREATE TABLE IF NOT EXISTS tai_khoan_ke_toan (
  so           TEXT PRIMARY KEY,          -- '111','131','511',…
  ten          TEXT NOT NULL,
  cap          INTEGER NOT NULL,
  cha_so       TEXT,
  loai         TEXT NOT NULL
               CHECK (loai IN ('tai-san','no-phai-tra','von-chu-so-huu','doanh-thu','chi-phi','khac')),
  du_thuong    TEXT NOT NULL CHECK (du_thuong IN ('no','co','khong')),
  thong_tu     TEXT NOT NULL CHECK (thong_tu IN ('tt200','tt133','ca-hai')),
  hoat_dong    INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_tkkt_cha ON tai_khoan_ke_toan(cha_so);

CREATE TABLE IF NOT EXISTS ky_ke_toan (
  id           TEXT PRIMARY KEY,          -- '2026-01'
  tu_ngay      TEXT NOT NULL,
  den_ngay     TEXT NOT NULL,
  trang_thai   TEXT NOT NULL DEFAULT 'mo' CHECK (trang_thai IN ('mo','khoa-mem','khoa')),
  khoa_luc     INTEGER,
  khoa_boi     TEXT
);

CREATE TABLE IF NOT EXISTS chung_tu (
  id           TEXT PRIMARY KEY,
  so_ct        TEXT NOT NULL UNIQUE,
  ky_id        TEXT NOT NULL,
  ngay_ct      TEXT NOT NULL,
  ngay_ghi_so  TEXT NOT NULL,
  loai         TEXT NOT NULL
               CHECK (loai IN ('thu','chi','ban-hang','mua-hang','luong','khau-hao','ket-chuyen','dieu-chinh','khac')),
  dien_giai    TEXT NOT NULL,
  tong_tien    INTEGER NOT NULL,          -- đồng, số nguyên — không dùng số thực cho tiền
  doi_tac      TEXT,
  gia_dinh_id  TEXT,
  chung_tu_goc TEXT,                      -- số hoá đơn, biên lai gốc
  trang_thai   TEXT NOT NULL DEFAULT 'nhap'
               CHECK (trang_thai IN ('nhap','cho-duyet','da-ghi-so','da-dao')),
  dao_cua_id   TEXT,                      -- chứng từ này đảo chứng từ nào
  nguoi_lap    TEXT NOT NULL,
  nguoi_duyet  TEXT,
  ghi_so_luc   INTEGER,
  created_at   INTEGER NOT NULL,
  FOREIGN KEY (ky_id) REFERENCES ky_ke_toan(id)
);
CREATE INDEX IF NOT EXISTS idx_ct_ky    ON chung_tu(ky_id, ngay_ghi_so);
CREATE INDEX IF NOT EXISTS idx_ct_loai  ON chung_tu(loai, trang_thai);

CREATE TABLE IF NOT EXISTS but_toan (
  id           TEXT PRIMARY KEY,
  chung_tu_id  TEXT NOT NULL,
  dong         INTEGER NOT NULL,
  tk_no        TEXT,
  tk_co        TEXT,
  so_tien      INTEGER NOT NULL CHECK (so_tien > 0),
  dien_giai    TEXT,
  doi_tuong    TEXT,                      -- chiều phân tích: học viên, lớp, chi nhánh
  UNIQUE (chung_tu_id, dong),
  FOREIGN KEY (chung_tu_id) REFERENCES chung_tu(id),
  CHECK ((tk_no IS NOT NULL) OR (tk_co IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS idx_bt_ct ON but_toan(chung_tu_id, dong);
CREATE INDEX IF NOT EXISTS idx_bt_no ON but_toan(tk_no);
CREATE INDEX IF NOT EXISTS idx_bt_co ON but_toan(tk_co);

CREATE TABLE IF NOT EXISTS hoc_phi (
  id           TEXT PRIMARY KEY,
  user_id      TEXT NOT NULL,
  gia_dinh_id  TEXT,
  ky           TEXT NOT NULL,
  khoan_muc    TEXT NOT NULL,
  so_tien      INTEGER NOT NULL,
  da_thu       INTEGER NOT NULL DEFAULT 0,
  han_thu      TEXT,
  trang_thai   TEXT NOT NULL DEFAULT 'cho-thu'
               CHECK (trang_thai IN ('cho-thu','thu-mot-phan','da-thu','mien-giam','xoa-no')),
  mien_giam_ly_do TEXT,
  chung_tu_id  TEXT,
  created_at   INTEGER NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_hp_nguoi ON hoc_phi(user_id, ky);
CREATE INDEX IF NOT EXISTS idx_hp_tt    ON hoc_phi(trang_thai, han_thu);

-- Kết quả báo cáo đã chốt — chụp lại để sau này đối chiếu, không tính lại.
CREATE TABLE IF NOT EXISTS bao_cao_tai_chinh (
  id           TEXT PRIMARY KEY,
  ky_id        TEXT NOT NULL,
  loai         TEXT NOT NULL
               CHECK (loai IN ('can-doi-phat-sinh','can-doi-ke-toan','ket-qua-kinh-doanh','luu-chuyen-tien-te')),
  so_lieu_json TEXT NOT NULL,
  can_doi      INTEGER NOT NULL,          -- 1 khi tổng Nợ = tổng Có
  lap_luc      INTEGER NOT NULL,
  nguoi_lap    TEXT NOT NULL,
  UNIQUE (ky_id, loai, lap_luc),
  FOREIGN KEY (ky_id) REFERENCES ky_ke_toan(id)
);
