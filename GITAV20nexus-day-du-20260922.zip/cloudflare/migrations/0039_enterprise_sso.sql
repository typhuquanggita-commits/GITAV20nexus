-- =========================================================
-- V17: ENTERPRISE — Multi-tenant, SSO, seat management
-- =========================================================
CREATE TABLE organizations (
  id              TEXT PRIMARY KEY,
  slug            TEXT NOT NULL UNIQUE,
  name            TEXT NOT NULL,
  domain          TEXT,                        -- auto-join domain
  logo_url        TEXT,
  primary_color   TEXT,
  plan            TEXT NOT NULL DEFAULT 'starter'
                  CHECK (plan IN ('starter','pro','enterprise')),
  seats_purchased INTEGER NOT NULL DEFAULT 10,
  seats_used      INTEGER NOT NULL DEFAULT 0,
  -- Billing
  billing_email   TEXT,
  -- Status
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','trial','suspended','cancelled')),
  trial_ends_at   INTEGER,
  -- Settings
  settings_json   TEXT DEFAULT '{}',           -- {autoEnroll, welcomeMessage, ...}
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX idx_orgs_domain ON organizations(domain);
CREATE INDEX idx_orgs_slug ON organizations(slug);
-- Org members
CREATE TABLE org_members (
  id              TEXT PRIMARY KEY,
  org_id          TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  role            TEXT NOT NULL DEFAULT 'member'
                  CHECK (role IN ('member','manager','admin','owner')),
  department      TEXT,
  job_title       TEXT,
  -- Seats
  seat_assigned   INTEGER NOT NULL DEFAULT 1,
  -- Status
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('invited','active','inactive','removed')),
  joined_at       INTEGER,
  created_at      INTEGER NOT NULL,
  UNIQUE (org_id, user_id),
  FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE
);
CREATE INDEX idx_org_members_user ON org_members(user_id, status);
CREATE INDEX idx_org_members_org ON org_members(org_id, status);
-- SSO configurations
CREATE TABLE sso_configs (
  id              TEXT PRIMARY KEY,
  org_id          TEXT NOT NULL,
  provider        TEXT NOT NULL CHECK (provider IN ('saml','oidc','google','azure','okta')),
  -- SAML
  saml_entry_point TEXT,
  saml_issuer     TEXT,
  saml_cert       TEXT,
  -- OIDC
  oidc_issuer     TEXT,
  oidc_client_id  TEXT,
  oidc_client_secret_enc TEXT,                 -- Encrypted at rest
  oidc_scopes     TEXT DEFAULT 'openid profile email',
  -- Attribute mapping
  attribute_mapping_json TEXT NOT NULL DEFAULT '{}',
  -- Status
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','disabled','testing')),
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL,
  UNIQUE (org_id, provider)
);
-- Invitations
CREATE TABLE org_invitations (
  id              TEXT PRIMARY KEY,
  org_id          TEXT NOT NULL,
  email           TEXT NOT NULL,
  role            TEXT NOT NULL DEFAULT 'member',
  department      TEXT,
  invited_by      TEXT NOT NULL,
  token           TEXT NOT NULL UNIQUE,
  expires_at      INTEGER NOT NULL,
  accepted_at     INTEGER,
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE
);
CREATE INDEX idx_invites_token ON org_invitations(token);
CREATE INDEX idx_invites_email ON org_invitations(email, accepted_at);
-- Learning assignments (org-wide)
CREATE TABLE org_assignments (
  id              TEXT PRIMARY KEY,
  org_id          TEXT NOT NULL,
  assigned_by     TEXT NOT NULL,
  title           TEXT NOT NULL,
  description     TEXT,
  -- Content
  level_ids_json  TEXT DEFAULT '[]',
  course_ids_json TEXT DEFAULT '[]',
  required        INTEGER NOT NULL DEFAULT 1,
  -- Targeting
  target_departments_json TEXT DEFAULT '[]',
  target_roles_json TEXT DEFAULT '[]',
  -- Deadline
  due_at          INTEGER,
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE
);
CREATE TABLE org_assignment_progress (
  id              TEXT PRIMARY KEY,
  assignment_id   TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  progress_pct    REAL NOT NULL DEFAULT 0,
  completed_at    INTEGER,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL,
  UNIQUE (assignment_id, user_id),
  FOREIGN KEY (assignment_id) REFERENCES org_assignments(id) ON DELETE CASCADE
);
-- Analytics (aggregated)
CREATE TABLE org_analytics_daily (
  id              TEXT PRIMARY KEY,
  org_id          TEXT NOT NULL,
  day             TEXT NOT NULL,
  active_users    INTEGER NOT NULL DEFAULT 0,
  lessons_done    INTEGER NOT NULL DEFAULT 0,
  avg_score       REAL NOT NULL DEFAULT 0,
  hours_learning  REAL NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL,
  UNIQUE (org_id, day)
);
CREATE INDEX idx_org_analytics ON org_analytics_daily(org_id, day DESC);
