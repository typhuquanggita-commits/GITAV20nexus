-- =========================================================
-- V21: CURRICULUM AUDITOR — Audit chất lượng tự động
-- =========================================================
CREATE TABLE audit_runs (
  id              TEXT PRIMARY KEY,
  scope           TEXT NOT NULL CHECK (scope IN ('full','tier','level','custom')),
  scope_ref       TEXT,                            -- tier id or level id
  run_by          TEXT NOT NULL,
  status          TEXT NOT NULL DEFAULT 'running'
                  CHECK (status IN ('running','completed','failed')),
  -- Results summary
  total_items     INTEGER NOT NULL DEFAULT 0,
  passed          INTEGER NOT NULL DEFAULT 0,
  warnings        INTEGER NOT NULL DEFAULT 0,
  critical        INTEGER NOT NULL DEFAULT 0,
  -- Metrics
  avg_quality_score REAL NOT NULL DEFAULT 0,
  avg_readability   REAL NOT NULL DEFAULT 0,
  avg_citation_density REAL NOT NULL DEFAULT 0,
  -- Meta
  tokens_used     INTEGER NOT NULL DEFAULT 0,
  duration_ms     INTEGER,
  created_at      INTEGER NOT NULL,
  completed_at    INTEGER
);
CREATE INDEX idx_audit_runs ON audit_runs(run_by, created_at DESC);
CREATE TABLE audit_findings (
  id              TEXT PRIMARY KEY,
  run_id          TEXT NOT NULL,
  level_id        TEXT NOT NULL,
  -- Finding
  category        TEXT NOT NULL CHECK (category IN (
    'readability','depth','citation','consistency','prerequisite','outdated','formatting','duplication','completeness'
  )),
  severity        TEXT NOT NULL CHECK (severity IN ('info','warning','critical')),
  title           TEXT NOT NULL,
  description     TEXT NOT NULL,
  suggestion      TEXT,
  -- Metrics
  metric_name     TEXT,
  metric_value    REAL,
  threshold       REAL,
  -- Meta
  resolved        INTEGER NOT NULL DEFAULT 0,
  resolved_by     TEXT,
  resolved_at     INTEGER,
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (run_id) REFERENCES audit_runs(id) ON DELETE CASCADE
);
CREATE INDEX idx_audit_findings_run ON audit_findings(run_id, severity);
CREATE INDEX idx_audit_findings_level ON audit_findings(level_id, resolved);
-- Audit rules (configurable)
CREATE TABLE audit_rules (
  id              TEXT PRIMARY KEY,
  code            TEXT NOT NULL UNIQUE,
  category        TEXT NOT NULL,
  name            TEXT NOT NULL,
  description     TEXT NOT NULL,
  threshold_json  TEXT NOT NULL,
  severity        TEXT NOT NULL DEFAULT 'warning',
  is_active       INTEGER NOT NULL DEFAULT 1,
  created_at      INTEGER NOT NULL
);
