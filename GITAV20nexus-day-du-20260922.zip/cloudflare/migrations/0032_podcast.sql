-- =========================================================
-- V16: PODCAST PIPELINE — Audio cho 50 levels + RSS feed
-- =========================================================
CREATE TABLE podcast_episodes (
  id              TEXT PRIMARY KEY,
  level_id        TEXT NOT NULL,
  season          INTEGER NOT NULL DEFAULT 1,
  episode_number  INTEGER NOT NULL,
  title           TEXT NOT NULL,
  description     TEXT NOT NULL,
  -- Audio
  audio_r2_key    TEXT,
  audio_duration  INTEGER,                       -- seconds
  audio_size      INTEGER,                       -- bytes
  voice_id        TEXT NOT NULL DEFAULT 'vi-VN-HoaiMyNeural',
  language        TEXT NOT NULL DEFAULT 'vi',
  -- Content
  transcript_md   TEXT,
  chapters_json   TEXT,                          -- [{time: 0, title: "Intro"}]
  -- Meta
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','generating','ready','failed','archived')),
  published_at    INTEGER,
  -- Metrics
  download_count  INTEGER NOT NULL DEFAULT 0,
  listen_count    INTEGER NOT NULL DEFAULT 0,
  avg_completion  REAL NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL,
  UNIQUE (level_id, language)
);
CREATE INDEX idx_podcast_status ON podcast_episodes(status, season, episode_number);
-- Podcast feed metadata
CREATE TABLE podcast_feed (
  id              TEXT PRIMARY KEY,
  name            TEXT NOT NULL,
  description     TEXT NOT NULL,
  author          TEXT NOT NULL,
  email           TEXT NOT NULL,
  language        TEXT NOT NULL DEFAULT 'vi',
  category        TEXT NOT NULL DEFAULT 'Education',
  subcategory     TEXT NOT NULL DEFAULT 'Language Learning',
  cover_image_url TEXT,
  website_url     TEXT,
  explicit        INTEGER NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
-- Listening progress
CREATE TABLE podcast_progress (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  episode_id      TEXT NOT NULL,
  position_sec    INTEGER NOT NULL DEFAULT 0,
  completed       INTEGER NOT NULL DEFAULT 0,
  last_listened   INTEGER NOT NULL,
  UNIQUE (user_id, episode_id)
);
CREATE INDEX idx_progress_user ON podcast_progress(user_id, last_listened DESC);
