-- =========================================================
-- V19: VOICE-FIRST — Học bằng giọng nói
-- Web Speech API (free) cho STT + TTS ở client
-- Server lưu conversation state
-- =========================================================
CREATE TABLE voice_sessions (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  level_id        TEXT,
  mode            TEXT NOT NULL CHECK (mode IN ('lesson','quiz','conversation','pronunciation')),
  language        TEXT NOT NULL DEFAULT 'vi',
  -- Status
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','paused','completed','abandoned')),
  -- Progress
  current_segment INTEGER NOT NULL DEFAULT 0,
  total_segments  INTEGER NOT NULL DEFAULT 0,
  completion_pct  REAL NOT NULL DEFAULT 0,
  -- Metrics
  total_duration_sec INTEGER NOT NULL DEFAULT 0,
  -- Meta
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL,
  completed_at    INTEGER
);
CREATE INDEX idx_voice_sessions_user ON voice_sessions(user_id, status, created_at DESC);
CREATE TABLE voice_turns (
  id              TEXT PRIMARY KEY,
  session_id      TEXT NOT NULL,
  turn_index      INTEGER NOT NULL,
  -- Content
  speaker         TEXT NOT NULL CHECK (speaker IN ('ai','user','system')),
  text            TEXT NOT NULL,
  audio_text      TEXT,                          -- Text cho TTS (khác text hiển thị)
  -- User input metadata
  transcript_confidence REAL,                    -- 0-1 từ STT
  audio_duration_ms INTEGER,
  -- AI response metadata
  emotion         TEXT,                          -- 'encouraging','neutral','correcting'
  -- Evaluation (cho quiz mode)
  score           REAL,
  feedback        TEXT,
  -- Meta
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (session_id) REFERENCES voice_sessions(id) ON DELETE CASCADE,
  UNIQUE (session_id, turn_index)
);
CREATE INDEX idx_voice_turns ON voice_turns(session_id, turn_index);
-- Pronunciation attempts
CREATE TABLE pronunciation_attempts (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  target_text     TEXT NOT NULL,
  recognized_text TEXT NOT NULL,
  -- Scoring
  accuracy_score  REAL NOT NULL,                -- 0-1
  word_scores_json TEXT,                        -- [{word, score, hint}]
  phoneme_issues_json TEXT DEFAULT '[]',        -- [{phoneme, expected, got}]
  -- Meta
  language        TEXT NOT NULL DEFAULT 'vi',
  created_at      INTEGER NOT NULL
);
CREATE INDEX idx_pron_user ON pronunciation_attempts(user_id, created_at DESC);
-- Voice phrase templates (for quick practice)
CREATE TABLE voice_phrase_bank (
  id              TEXT PRIMARY KEY,
  category        TEXT NOT NULL,
  phrase          TEXT NOT NULL,
  translation     TEXT,
  difficulty      INTEGER NOT NULL DEFAULT 3 CHECK (difficulty BETWEEN 1 AND 5),
  language        TEXT NOT NULL DEFAULT 'vi',
  usage_count     INTEGER NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL
);
CREATE INDEX idx_phrases_cat ON voice_phrase_bank(category, difficulty);
