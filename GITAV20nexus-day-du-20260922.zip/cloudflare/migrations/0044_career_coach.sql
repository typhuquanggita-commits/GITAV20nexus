-- =========================================================
-- V18: CAREER COACH — 1:1 AI coach với goal tracking
-- Weekly check-in + adaptive nudges + progress chart
-- =========================================================
CREATE TABLE coaching_goals (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  title           TEXT NOT NULL,
  description     TEXT NOT NULL,
  category        TEXT NOT NULL CHECK (category IN ('career','skill','business','health','finance','relationship','personal')),
  -- SMART
  specific        TEXT NOT NULL,
  measurable      TEXT NOT NULL,
  achievable      TEXT NOT NULL,
  relevant        TEXT NOT NULL,
  time_bound      INTEGER NOT NULL,
  -- Progress
  progress_pct    REAL NOT NULL DEFAULT 0,
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('draft','active','at_risk','paused','achieved','abandoned')),
  -- Tracking
  milestones_json TEXT DEFAULT '[]',           -- [{title, targetDate, done, doneAt}]
  current_focus   TEXT,                        -- What to focus on this week
  -- Meta
  coach_notes_json TEXT DEFAULT '[]',           -- AI coach's observations
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX idx_goals_user ON coaching_goals(user_id, status, updated_at DESC);
CREATE TABLE coaching_sessions (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  goal_id         TEXT,
  session_type    TEXT NOT NULL CHECK (session_type IN ('weekly_checkin','ad_hoc','milestone_review','crisis')),
  -- Content
  user_input      TEXT NOT NULL,
  coach_response  TEXT NOT NULL,
  -- Analysis
  mood_detected   TEXT,
  blockers_json   TEXT DEFAULT '[]',
  wins_json       TEXT DEFAULT '[]',
  next_actions_json TEXT DEFAULT '[]',
  -- Scheduled follow-up
  next_checkin_at INTEGER,
  -- Meta
  model           TEXT,
  tokens_used     INTEGER NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (goal_id) REFERENCES coaching_goals(id) ON DELETE SET NULL
);
CREATE INDEX idx_coaching_sessions_user ON coaching_sessions(user_id, created_at DESC);
CREATE INDEX idx_sessions_goal ON coaching_sessions(goal_id, created_at DESC);
-- Weekly nudges (cron-generated)
CREATE TABLE coaching_nudges (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  goal_id         TEXT,
  nudge_type      TEXT NOT NULL CHECK (nudge_type IN ('reminder','encouragement','accountability','celebration','reflection')),
  content         TEXT NOT NULL,
  scheduled_at    INTEGER NOT NULL,
  sent_at         INTEGER,
  dismissed_at    INTEGER,
  created_at      INTEGER NOT NULL
);
CREATE INDEX idx_nudges_pending ON coaching_nudges(scheduled_at) WHERE sent_at IS NULL;
-- Habit tracking (micro-habits supporting goals)
CREATE TABLE coaching_habits (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  goal_id         TEXT,
  name            TEXT NOT NULL,
  frequency       TEXT NOT NULL CHECK (frequency IN ('daily','weekly','3x_week')),
  target_count    INTEGER NOT NULL DEFAULT 1,
  current_streak  INTEGER NOT NULL DEFAULT 0,
  best_streak     INTEGER NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL
);
CREATE TABLE coaching_habit_logs (
  id              TEXT PRIMARY KEY,
  habit_id        TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  logged_at       INTEGER NOT NULL,
  note            TEXT
);
-- SQLite không cho đặt biểu thức trong ràng buộc UNIQUE của bảng.
-- Ý đồ của đặc tả — mỗi thói quen chỉ ghi nhận một lần mỗi ngày —
-- diễn đạt đúng bằng chỉ mục UNIQUE trên biểu thức.
CREATE UNIQUE INDEX IF NOT EXISTS idx_coaching_habit_logs_ngay
  ON coaching_habit_logs(habit_id, date(logged_at, 'unixepoch'));
