-- =========================================================
-- V20: DIGITAL TWIN — AI mô phỏng cách học của user
-- Dùng để dự đoán + đề xuất cá nhân hóa
-- =========================================================
CREATE TABLE twin_profiles (
  user_id         TEXT PRIMARY KEY,
  -- Behavioral fingerprint
  avg_session_min INTEGER NOT NULL DEFAULT 0,
  avg_lessons_per_session REAL NOT NULL DEFAULT 0,
  best_time_hour  INTEGER,                        -- 0-23
  best_day_dow    INTEGER,                        -- 0-6
  avg_score       REAL NOT NULL DEFAULT 0,
  score_variance  REAL NOT NULL DEFAULT 0,        -- Stability indicator
  -- Learning preferences (inferred)
  preferred_formats_json TEXT DEFAULT '[]',       -- ['video','quiz','podcast']
  difficulty_preference TEXT NOT NULL DEFAULT 'balanced'
                  CHECK (difficulty_preference IN ('easy','balanced','challenging')),
  social_learning REAL NOT NULL DEFAULT 0.5,      -- 0-1: prefer solo vs group
  -- Prediction features
  features_json   TEXT NOT NULL DEFAULT '{}',
  -- Meta
  confidence      REAL NOT NULL DEFAULT 0,        -- 0-1, based on data volume
  last_computed   INTEGER,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE TABLE twin_predictions (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  prediction_type TEXT NOT NULL CHECK (prediction_type IN (
    'next_score','completion_probability','dropout_risk','optimal_next_level','session_duration','best_time'
  )),
  prediction_json TEXT NOT NULL,                  -- {value, confidence, features}
  actual_value    TEXT,                            -- Filled later for accuracy
  accuracy_score  REAL,
  created_at      INTEGER NOT NULL,
  resolved_at     INTEGER
);
CREATE INDEX idx_twin_predictions ON twin_predictions(user_id, prediction_type, created_at DESC);
-- Recommendations with expected impact
CREATE TABLE twin_recommendations (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  rec_type        TEXT NOT NULL,
  title           TEXT NOT NULL,
  description     TEXT NOT NULL,
  expected_impact_json TEXT,                      -- {metric, delta, confidence}
  action_json     TEXT,                            -- {type, payload}
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','accepted','dismissed','expired')),
  created_at      INTEGER NOT NULL,
  expires_at      INTEGER
);
CREATE INDEX idx_twin_recs ON twin_recommendations(user_id, status, created_at DESC);
-- Simulation scenarios (what-if)
CREATE TABLE twin_simulations (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  scenario_json   TEXT NOT NULL,                  -- {changes: {study_minutes: +10, time: 'morning'}}
  predicted_outcome_json TEXT NOT NULL,
  run_at          INTEGER NOT NULL
);
CREATE INDEX idx_twin_sims ON twin_simulations(user_id, run_at DESC);
