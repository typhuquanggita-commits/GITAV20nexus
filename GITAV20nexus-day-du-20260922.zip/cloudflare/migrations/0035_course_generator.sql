-- =========================================================
-- V17: AI COURSE GENERATOR — 1 prompt → full course
-- =========================================================
CREATE TABLE course_generation_jobs (
  id              TEXT PRIMARY KEY,
  creator_id      TEXT NOT NULL,
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','analyzing','outlining','expanding','qa','ready','failed','cancelled')),
  -- Input
  input_prompt    TEXT NOT NULL,
  input_params_json TEXT NOT NULL,           -- {targetAudience, hours, level, category, language}
  -- Progress
  total_steps     INTEGER NOT NULL DEFAULT 6,
  current_step    INTEGER NOT NULL DEFAULT 0,
  progress_pct    REAL NOT NULL DEFAULT 0,
  -- Output (accumulated)
  outline_json    TEXT,                       -- Course outline
  modules_json    TEXT,                       -- Generated modules
  -- Link to final course
  course_id       TEXT,
  -- Metrics
  tokens_used     INTEGER NOT NULL DEFAULT 0,
  neurons_used    INTEGER NOT NULL DEFAULT 0,
  latency_ms      INTEGER,
  error_log       TEXT,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX idx_gen_jobs_creator ON course_generation_jobs(creator_id, created_at DESC);
CREATE INDEX idx_gen_jobs_status ON course_generation_jobs(status);
-- Step-level checkpoints (resumable)
CREATE TABLE course_generation_steps (
  id              TEXT PRIMARY KEY,
  job_id          TEXT NOT NULL,
  step_index      INTEGER NOT NULL,
  step_type       TEXT NOT NULL CHECK (step_type IN (
    'analyze_intent','create_outline','expand_modules','generate_lessons',
    'generate_quizzes','generate_media_briefs','quality_check','finalize'
  )),
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','running','done','failed','skipped')),
  input_json      TEXT,
  output_json     TEXT,
  tokens_used     INTEGER NOT NULL DEFAULT 0,
  error_log       TEXT,
  started_at      INTEGER,
  finished_at     INTEGER,
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (job_id) REFERENCES course_generation_jobs(id) ON DELETE CASCADE,
  UNIQUE (job_id, step_index)
);
-- Prompt templates for each step (versionable)
CREATE TABLE generator_templates (
  id              TEXT PRIMARY KEY,
  step_type       TEXT NOT NULL,
  version         TEXT NOT NULL,
  prompt_template TEXT NOT NULL,
  schema_json     TEXT,
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('draft','active','deprecated')),
  created_at      INTEGER NOT NULL,
  UNIQUE (step_type, version)
);
