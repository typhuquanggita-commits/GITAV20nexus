-- =========================================================
-- V21: BLOCKCHAIN CREDENTIALS — Chứng chỉ on-chain
-- Polygon Amoy Testnet FREE, upgrade lên Mainnet khi cần
-- =========================================================
CREATE TABLE onchain_certificates (
  id              TEXT PRIMARY KEY,
  certificate_id  TEXT NOT NULL,                   -- ref certificates (V16)
  user_id         TEXT NOT NULL,
  -- Chain
  chain           TEXT NOT NULL DEFAULT 'polygon-amoy'
                  CHECK (chain IN ('polygon-amoy','polygon-mainnet','base-sepolia')),
  contract_address TEXT NOT NULL,
  token_id        TEXT,                            -- ERC-721 token id
  -- Transaction
  tx_hash         TEXT,
  block_number    INTEGER,
  -- Status
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','submitting','minted','confirmed','failed','revoked')),
  -- Metadata (IPFS-style URI)
  metadata_uri    TEXT,
  metadata_json   TEXT NOT NULL,                   -- ERC-721 metadata
  -- Verification
  wallet_address  TEXT,                            -- User's wallet if provided
  -- Meta
  error_log       TEXT,
  created_at      INTEGER NOT NULL,
  confirmed_at    INTEGER
);
CREATE INDEX idx_onchain_cert ON onchain_certificates(certificate_id);
CREATE INDEX idx_onchain_user ON onchain_certificates(user_id, status);
CREATE INDEX idx_onchain_tx ON onchain_certificates(tx_hash) WHERE tx_hash IS NOT NULL;
-- Wallet connections
CREATE TABLE user_wallets (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  address         TEXT NOT NULL,
  chain           TEXT NOT NULL,
  -- Verification
  verified        INTEGER NOT NULL DEFAULT 0,
  nonce           TEXT,
  -- Meta
  connected_at    INTEGER NOT NULL,
  UNIQUE (user_id, address, chain),
  UNIQUE (address, chain)
);
CREATE INDEX idx_wallets_user ON user_wallets(user_id, verified);
-- Chain config (cho multi-chain support)
CREATE TABLE chain_configs (
  chain           TEXT PRIMARY KEY,
  name            TEXT NOT NULL,
  chain_id        INTEGER NOT NULL,
  rpc_url         TEXT NOT NULL,
  contract_address TEXT NOT NULL,
  explorer_url    TEXT NOT NULL,
  is_testnet      INTEGER NOT NULL DEFAULT 1,
  gas_price_gwei  REAL NOT NULL DEFAULT 30,
  created_at      INTEGER NOT NULL
);
