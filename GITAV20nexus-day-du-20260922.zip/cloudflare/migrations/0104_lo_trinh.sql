-- =========================================================
-- LỘ TRÌNH CÁ NHÂN HOÁ, GIÁM SÁT VÀ ĐIỀU KIỆN VƯỢT CẤP
--
-- Luật cứng của hệ đa tầng: KHÔNG NHẢY CẤP. Cấp n+1 chỉ mở khi cấp n
-- có bằng chứng đo được. Bảng dieu_kien_vuot giữ đúng các điều kiện ấy
-- dưới dạng dữ liệu chứ không phải mã, nên đổi chuẩn không phải sửa mã
-- — và mọi thay đổi đều để lại dấu ở nhật ký kiểm toán.
-- =========================================================

CREATE TABLE IF NOT EXISTS lo_trinh_hoc (
  id           TEXT PRIMARY KEY,
  user_id      TEXT NOT NULL,
  mon_id       TEXT NOT NULL,
  o_id_dau     TEXT NOT NULL,             -- ô chương trình bắt đầu
  o_id_dich    TEXT NOT NULL,
  tang         INTEGER NOT NULL DEFAULT 1 CHECK (tang BETWEEN 1 AND 5),
  cap          INTEGER NOT NULL DEFAULT 0 CHECK (cap BETWEEN 0 AND 10),
  gio_moi_tuan INTEGER,
  han_dich     INTEGER,
  trang_thai   TEXT NOT NULL DEFAULT 'dang-chay'
               CHECK (trang_thai IN ('dang-chay','tam-dung','dat-dich','bo')),
  created_at   INTEGER NOT NULL,
  updated_at   INTEGER NOT NULL,
  UNIQUE (user_id, mon_id),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (mon_id)  REFERENCES mon_hoc(id)
);

-- Điều kiện vượt từ một ô sang ô kế. Khắt khe, và đo được bằng máy.
CREATE TABLE IF NOT EXISTS dieu_kien_vuot (
  id           TEXT PRIMARY KEY,
  o_id         TEXT NOT NULL,
  ma           TEXT NOT NULL,
  mo_ta        TEXT NOT NULL,
  do_bang      TEXT NOT NULL
               CHECK (do_bang IN ('ti-le-dung','so-bai','diem-kiem-tra','so-buoi','chuan-phu','thoi-gian-giu')),
  nguong       REAL NOT NULL,
  tren_mau     INTEGER,                   -- cần bao nhiêu lượt mới tính là đủ mẫu
  bat_buoc     INTEGER NOT NULL DEFAULT 1,
  UNIQUE (o_id, ma),
  FOREIGN KEY (o_id) REFERENCES o_chuong_trinh(id)
);
CREATE INDEX IF NOT EXISTS idx_dkv_o ON dieu_kien_vuot(o_id);

CREATE TABLE IF NOT EXISTS xet_vuot_cap (
  id           TEXT PRIMARY KEY,
  user_id      TEXT NOT NULL,
  o_id         TEXT NOT NULL,
  xet_luc      INTEGER NOT NULL,
  ket_qua      TEXT NOT NULL CHECK (ket_qua IN ('dat','chua-dat','thieu-mau')),
  chi_tiet_json TEXT NOT NULL,            -- từng điều kiện: đạt hay chưa, số thật
  nguoi_duyet  TEXT,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (o_id)    REFERENCES o_chuong_trinh(id)
);
CREATE INDEX IF NOT EXISTS idx_xvc_nguoi ON xet_vuot_cap(user_id, xet_luc DESC);

-- Giám sát: mỗi buổi học để lại một dòng đo được.
CREATE TABLE IF NOT EXISTS buoi_hoc (
  id           TEXT PRIMARY KEY,
  user_id      TEXT NOT NULL,
  chuyen_de_id TEXT,
  bat_dau      INTEGER NOT NULL,
  ket_thuc     INTEGER,
  so_bai_lam   INTEGER NOT NULL DEFAULT 0,
  so_bai_dung  INTEGER NOT NULL DEFAULT 0,
  giay_tap_trung INTEGER,
  ngat_quang   INTEGER NOT NULL DEFAULT 0,
  ghi_chu      TEXT,
  FOREIGN KEY (user_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_buoi_hoc_nguoi ON buoi_hoc(user_id, bat_dau DESC);

CREATE TABLE IF NOT EXISTS canh_bao_hoc_tap (
  id           TEXT PRIMARY KEY,
  user_id      TEXT NOT NULL,
  loai         TEXT NOT NULL
               CHECK (loai IN ('tut-doc','nghi-lau','doan-bua','qua-tai','sai-lap-lai','dat-dich-som')),
  muc          TEXT NOT NULL CHECK (muc IN ('nhac','luu-y','khan')),
  bang_chung_json TEXT NOT NULL,
  da_xu_ly     INTEGER NOT NULL DEFAULT 0,
  nguoi_xu_ly  TEXT,
  xu_ly_luc    INTEGER,
  created_at   INTEGER NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_cbht_nguoi ON canh_bao_hoc_tap(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_cbht_chua  ON canh_bao_hoc_tap(da_xu_ly, muc);
