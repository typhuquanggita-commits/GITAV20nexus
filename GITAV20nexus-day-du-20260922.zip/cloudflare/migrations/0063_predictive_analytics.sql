-- =========================================================
-- V22: PREDICTIVE ANALYTICS — Dự đoán xu hướng toàn platform
-- =========================================================
CREATE TABLE platform_metrics_daily (
  id              TEXT PRIMARY KEY,
  day             TEXT NOT NULL UNIQUE,
  -- Users
  total_users     INTEGER NOT NULL DEFAULT 0,
  new_users       INTEGER NOT NULL DEFAULT 0,
  active_users    INTEGER NOT NULL DEFAULT 0,
  churned_users   INTEGER NOT NULL DEFAULT 0,
  -- Content
  levels_published INTEGER NOT NULL DEFAULT 0,
  levels_ai_drafted INTEGER NOT NULL DEFAULT 0,
  courses_published INTEGER NOT NULL DEFAULT 0,
  questions_added INTEGER NOT NULL DEFAULT 0,
  -- Engagement
  total_sessions  INTEGER NOT NULL DEFAULT 0,
  total_lessons_completed INTEGER NOT NULL DEFAULT 0,
  avg_session_min REAL NOT NULL DEFAULT 0,
  avg_score       REAL NOT NULL DEFAULT 0,
  -- Community
  forum_posts     INTEGER NOT NULL DEFAULT 0,
  peer_reviews    INTEGER NOT NULL DEFAULT 0,
  -- Financial (if applicable)
  revenue_vnd     INTEGER NOT NULL DEFAULT 0,
  -- Meta
  computed_at     INTEGER NOT NULL
);
CREATE INDEX idx_platform_metrics ON platform_metrics_daily(day DESC);
CREATE TABLE predictions (
  id              TEXT PRIMARY KEY,
  prediction_type TEXT NOT NULL CHECK (prediction_type IN (
    'user_growth','content_growth','churn_rate','revenue','engagement',
    'level_completion','cohort_retention'
  )),
  -- Target
  target_metric   TEXT NOT NULL,
  -- Horizon
  horizon_days    INTEGER NOT NULL DEFAULT 30,
  -- Prediction
  predicted_value REAL NOT NULL,
  confidence_low  REAL,
  confidence_high REAL,
  confidence      REAL NOT NULL DEFAULT 0.5,
  -- Model
  model_name      TEXT NOT NULL DEFAULT 'ensemble',
  features_used_json TEXT NOT NULL,
  -- Actual (filled later)
  actual_value    REAL,
  accuracy_score  REAL,
  -- Meta
  created_at      INTEGER NOT NULL,
  resolved_at     INTEGER
);
CREATE INDEX idx_predictions_type ON predictions(prediction_type, created_at DESC);
-- Anomalies detected
CREATE TABLE anomalies (
  id              TEXT PRIMARY KEY,
  metric_name     TEXT NOT NULL,
  day             TEXT NOT NULL,
  actual_value    REAL NOT NULL,
  expected_value  REAL NOT NULL,
  deviation_pct   REAL NOT NULL,
  severity        TEXT NOT NULL CHECK (severity IN ('low','medium','high','critical')),
  detected_at     INTEGER NOT NULL,
  acknowledged    INTEGER NOT NULL DEFAULT 0,
  acknowledged_by TEXT,
  note            TEXT
);
CREATE INDEX idx_anomalies ON anomalies(acknowledged, severity, day DESC);
-- Cohort retention
CREATE TABLE cohort_retention (
  id              TEXT PRIMARY KEY,
  cohort_week     TEXT NOT NULL,                    -- 'YYYY-WW'
  week_offset     INTEGER NOT NULL,                  -- 0, 1, 2, ...
  cohort_size     INTEGER NOT NULL,
  retained_count  INTEGER NOT NULL,
  retention_rate  REAL NOT NULL,
  computed_at     INTEGER NOT NULL,
  UNIQUE (cohort_week, week_offset)
);
CREATE INDEX idx_cohort_retention ON cohort_retention(cohort_week, week_offset);
-- Trending topics (content trends)
CREATE TABLE trending_topics (
  id              TEXT PRIMARY KEY,
  day             TEXT NOT NULL,
  topic           TEXT NOT NULL,
  frequency       INTEGER NOT NULL,
  growth_rate     REAL NOT NULL,                     -- vs 7 days ago
  category        TEXT,
  computed_at     INTEGER NOT NULL,
  UNIQUE (day, topic)
);
CREATE INDEX idx_trending ON trending_topics(day DESC, growth_rate DESC);
