-- =========================================================
-- V19: AI DEBATE PARTNER — Tranh luận có cấu trúc
-- Rèn tư duy phản biện + lập luận
-- =========================================================
CREATE TABLE debate_topics (
  id              TEXT PRIMARY KEY,
  slug            TEXT NOT NULL UNIQUE,
  title           TEXT NOT NULL,
  context_md      TEXT NOT NULL,
  category        TEXT NOT NULL,
  -- Pro/Con sides
  pro_position    TEXT NOT NULL,
  con_position    TEXT NOT NULL,
  -- Difficulty
  difficulty      INTEGER NOT NULL DEFAULT 3 CHECK (difficulty BETWEEN 1 AND 5),
  -- Meta
  debate_count    INTEGER NOT NULL DEFAULT 0,
  avg_quality     REAL NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL
);
CREATE INDEX idx_debate_topics ON debate_topics(category, difficulty);
CREATE TABLE debate_sessions (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  topic_id        TEXT NOT NULL,
  user_side       TEXT NOT NULL CHECK (user_side IN ('pro','con')),
  ai_side         TEXT NOT NULL CHECK (ai_side IN ('pro','con')),
  -- Config
  style           TEXT NOT NULL DEFAULT 'socratic'
                  CHECK (style IN ('socratic','aggressive','formal','collaborative')),
  rounds_planned  INTEGER NOT NULL DEFAULT 5,
  -- Status
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','completed','abandoned')),
  current_round   INTEGER NOT NULL DEFAULT 1,
  -- Scores
  final_score     REAL,
  quality_breakdown_json TEXT,                     -- {logic: 0.8, evidence: 0.7, rhetoric: 0.9, rebuttal: 0.6}
  -- Feedback
  overall_feedback TEXT,
  strengths_json  TEXT DEFAULT '[]',
  improvements_json TEXT DEFAULT '[]',
  -- Meta
  created_at      INTEGER NOT NULL,
  completed_at    INTEGER,
  FOREIGN KEY (topic_id) REFERENCES debate_topics(id)
);
CREATE INDEX idx_debate_sessions_user ON debate_sessions(user_id, status, created_at DESC);
CREATE TABLE debate_turns (
  id              TEXT PRIMARY KEY,
  session_id      TEXT NOT NULL,
  round_number    INTEGER NOT NULL,
  -- Speaker
  speaker         TEXT NOT NULL CHECK (speaker IN ('user','ai','system')),
  -- Content
  content_md      TEXT NOT NULL,
  -- For user turns: AI critique
  critique_json   TEXT,                            -- {logic, evidence, rhetoric, fallacies, suggestions}
  score           REAL,
  -- For AI turns: metadata
  strategy        TEXT,                            -- 'counter','rebut','extend','clarify'
  -- Meta
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (session_id) REFERENCES debate_sessions(id) ON DELETE CASCADE
);
CREATE INDEX idx_debate_turns ON debate_turns(session_id, round_number, created_at);
-- Fallacy library
CREATE TABLE fallacy_library (
  id              TEXT PRIMARY KEY,
  code            TEXT NOT NULL UNIQUE,
  name            TEXT NOT NULL,
  description     TEXT NOT NULL,
  example         TEXT NOT NULL,
  counter_strategy TEXT,
  created_at      INTEGER NOT NULL
);
-- User progress
CREATE TABLE debate_progress (
  user_id         TEXT PRIMARY KEY,
  total_debates   INTEGER NOT NULL DEFAULT 0,
  avg_score       REAL NOT NULL DEFAULT 0,
  best_score      REAL NOT NULL DEFAULT 0,
  favorite_side   TEXT,
  fallacy_stats_json TEXT DEFAULT '{}',            -- {fallacyCode: count}
  updated_at      INTEGER NOT NULL
);
