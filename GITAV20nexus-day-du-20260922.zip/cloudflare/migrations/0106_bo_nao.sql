-- =========================================================
-- BỘ NÃO VẬN HÀNH — 600 TRỢ LÝ CHUYÊN MÔN
--
-- Gọi là "trợ lý AI chuyên môn", không gọi là "đại lý" hay "agent" ở
-- mọi chỗ người dùng đọc được.
--
-- Bốn thứ giữ cho 600 trợ lý không thành 600 chỗ hỏng:
--   bang_nhiem_vu — việc nào ai làm, đầu vào và đầu ra là gì
--   quy_trinh     — trình tự bước, ai duyệt ở bước nào
--   kpi_tro_ly    — đo bằng số, không đo bằng cảm giác
--   hien_phap     — điều gì tuyệt đối không được làm, kèm căn cứ pháp lý
-- =========================================================

CREATE TABLE IF NOT EXISTS ban_chuyen_mon (
  id           TEXT PRIMARY KEY,          -- 'toan','tieng-anh','ngu-van','khao-thi',…
  ten          TEXT NOT NULL,
  nhiem_vu     TEXT NOT NULL,
  so_tro_ly    INTEGER NOT NULL,
  truong_ban_id TEXT
);

CREATE TABLE IF NOT EXISTS tro_ly (
  id           TEXT PRIMARY KEY,          -- 'tl-0001' … 'tl-0600'
  ban_id       TEXT NOT NULL,
  ten          TEXT NOT NULL,
  vai          TEXT NOT NULL
               CHECK (vai IN ('truong-ban','hoach-dinh','thuc-thi','tham-dinh','huan-luyen','tra-cuu','canh-gac')),
  chuyen_mon   TEXT NOT NULL,
  cong_cu_json TEXT NOT NULL DEFAULT '[]',
  pham_vi      TEXT NOT NULL DEFAULT 'chung' CHECK (pham_vi IN ('chung','pham-vi','minh')),
  suc_chua_ngay INTEGER NOT NULL DEFAULT 20,
  trang_thai   TEXT NOT NULL DEFAULT 'ranh'
               CHECK (trang_thai IN ('ranh','dang-lam','tam-nghi','loi','dang-huan-luyen')),
  created_at   INTEGER NOT NULL,
  FOREIGN KEY (ban_id) REFERENCES ban_chuyen_mon(id)
);
CREATE INDEX IF NOT EXISTS idx_tro_ly_ban ON tro_ly(ban_id, vai);
CREATE INDEX IF NOT EXISTS idx_tro_ly_tt  ON tro_ly(trang_thai);

CREATE TABLE IF NOT EXISTS bang_nhiem_vu (
  id           TEXT PRIMARY KEY,
  ma           TEXT NOT NULL UNIQUE,
  ten          TEXT NOT NULL,
  ban_id       TEXT NOT NULL,
  vai_lam      TEXT NOT NULL,
  dau_vao_json TEXT NOT NULL,
  dau_ra_json  TEXT NOT NULL,
  tieu_chuan_dat TEXT NOT NULL,           -- thế nào là làm xong đúng
  phut_du_kien INTEGER NOT NULL,
  can_nguoi_duyet INTEGER NOT NULL DEFAULT 0,
  cam_json     TEXT NOT NULL DEFAULT '[]',   -- việc con tuyệt đối không được làm
  FOREIGN KEY (ban_id) REFERENCES ban_chuyen_mon(id)
);

CREATE TABLE IF NOT EXISTS quy_trinh (
  id           TEXT PRIMARY KEY,
  ma           TEXT NOT NULL UNIQUE,
  ten          TEXT NOT NULL,
  muc_dich     TEXT NOT NULL,
  buoc_json    TEXT NOT NULL,             -- [{thu_tu, viec, ban, duyet_boi}]
  dau_ra       TEXT NOT NULL,
  phien_ban    TEXT NOT NULL DEFAULT '1',
  hieu_luc_tu  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS viec_giao (
  id           TEXT PRIMARY KEY,
  nhiem_vu_ma  TEXT NOT NULL,
  tro_ly_id    TEXT,
  quy_trinh_ma TEXT,
  buoc         INTEGER,
  dau_vao_json TEXT,
  ket_qua_json TEXT,
  trang_thai   TEXT NOT NULL DEFAULT 'cho'
               CHECK (trang_thai IN ('cho','dang-lam','cho-duyet','xong','tra-lai','huy')),
  uu_tien      INTEGER NOT NULL DEFAULT 5,
  giao_luc     INTEGER NOT NULL,
  nhan_luc     INTEGER,
  xong_luc     INTEGER,
  nguoi_duyet  TEXT,
  ly_do_tra_lai TEXT,
  FOREIGN KEY (tro_ly_id) REFERENCES tro_ly(id)
);
CREATE INDEX IF NOT EXISTS idx_viec_tt   ON viec_giao(trang_thai, uu_tien DESC, giao_luc);
CREATE INDEX IF NOT EXISTS idx_viec_troly ON viec_giao(tro_ly_id, trang_thai);

CREATE TABLE IF NOT EXISTS kpi_tro_ly (
  id           TEXT PRIMARY KEY,
  tro_ly_id    TEXT NOT NULL,
  ngay         TEXT NOT NULL,
  viec_nhan    INTEGER NOT NULL DEFAULT 0,
  viec_xong    INTEGER NOT NULL DEFAULT 0,
  viec_tra_lai INTEGER NOT NULL DEFAULT 0,
  phut_trung_binh REAL,
  ti_le_dat    REAL,
  UNIQUE (tro_ly_id, ngay),
  FOREIGN KEY (tro_ly_id) REFERENCES tro_ly(id)
);
CREATE INDEX IF NOT EXISTS idx_kpi_ngay ON kpi_tro_ly(ngay);

-- Hiến pháp: điều luật, căn cứ pháp lý, và hình phạt khi vi phạm.
CREATE TABLE IF NOT EXISTS hien_phap (
  id           TEXT PRIMARY KEY,
  dieu         INTEGER NOT NULL UNIQUE,
  ten          TEXT NOT NULL,
  noi_dung     TEXT NOT NULL,
  can_cu_json  TEXT NOT NULL,             -- [{van_ban, dieu, nuoc}]
  bat_buoc     INTEGER NOT NULL DEFAULT 1,
  vi_pham_thi  TEXT NOT NULL,             -- điều gì xảy ra khi vi phạm
  hieu_luc_tu  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS vi_pham_hien_phap (
  id           TEXT PRIMARY KEY,
  dieu         INTEGER NOT NULL,
  tro_ly_id    TEXT,
  user_id      TEXT,
  bang_chung_json TEXT NOT NULL,
  xu_ly        TEXT,
  at           INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_vp_dieu ON vi_pham_hien_phap(dieu, at DESC);
