-- =========================================================
-- V18: LIVE EVENTS — Webinar/workshop + RSVP + replay
-- Video hosting: Cloudflare Stream (free 1000 min)
-- =========================================================
CREATE TABLE events (
  id              TEXT PRIMARY KEY,
  slug            TEXT NOT NULL UNIQUE,
  host_id         TEXT NOT NULL,
  co_hosts_json   TEXT DEFAULT '[]',
  -- Basic
  title           TEXT NOT NULL,
  description     TEXT NOT NULL,
  cover_url       TEXT,
  category        TEXT NOT NULL,
  tags_json       TEXT DEFAULT '[]',
  language        TEXT NOT NULL DEFAULT 'vi',
  -- Schedule
  starts_at       INTEGER NOT NULL,
  ends_at         INTEGER NOT NULL,
  timezone        TEXT NOT NULL DEFAULT 'Asia/Ho_Chi_Minh',
  -- Format
  event_type      TEXT NOT NULL CHECK (event_type IN ('webinar','workshop','ama','panel','masterclass')),
  is_online       INTEGER NOT NULL DEFAULT 1,
  join_url        TEXT,
  location_text   TEXT,
  -- Capacity & pricing
  max_attendees   INTEGER,
  price           INTEGER NOT NULL DEFAULT 0,     -- VND
  -- Status
  status          TEXT NOT NULL DEFAULT 'draft'
                  CHECK (status IN ('draft','published','live','ended','cancelled')),
  -- Recording
  stream_id       TEXT,                           -- Cloudflare Stream ID
  recording_url   TEXT,
  replay_available INTEGER NOT NULL DEFAULT 0,
  -- Metrics
  rsvp_count      INTEGER NOT NULL DEFAULT 0,
  attended_count  INTEGER NOT NULL DEFAULT 0,
  replay_views    INTEGER NOT NULL DEFAULT 0,
  rating_avg      REAL NOT NULL DEFAULT 0,
  rating_count    INTEGER NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX idx_events_status ON events(status, starts_at DESC);
CREATE INDEX idx_events_host ON events(host_id, status);
CREATE INDEX idx_events_upcoming ON events(starts_at) WHERE status = 'published';
CREATE TABLE event_rsvps (
  id              TEXT PRIMARY KEY,
  event_id        TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  status          TEXT NOT NULL DEFAULT 'going'
                  CHECK (status IN ('going','maybe','not_going','waitlist','attended','no_show')),
  -- Payment
  escrow_tx_id    TEXT,
  amount_paid     INTEGER NOT NULL DEFAULT 0,
  -- Attendance
  joined_at       INTEGER,
  left_at         INTEGER,
  duration_sec    INTEGER,
  -- Feedback
  rating          INTEGER CHECK (rating BETWEEN 1 AND 5),
  feedback        TEXT,
  -- Meta
  reminder_sent_at INTEGER,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL,
  UNIQUE (event_id, user_id),
  FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
);
CREATE INDEX idx_rsvps_event ON event_rsvps(event_id, status);
CREATE INDEX idx_rsvps_user ON event_rsvps(user_id, created_at DESC);
-- Q\&A during event
CREATE TABLE event_questions (
  id              TEXT PRIMARY KEY,
  event_id        TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  question        TEXT NOT NULL,
  upvotes         INTEGER NOT NULL DEFAULT 0,
  answered        INTEGER NOT NULL DEFAULT 0,
  answer_md       TEXT,
  answered_by     TEXT,
  answered_at     INTEGER,
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
);
CREATE INDEX idx_questions_event ON event_questions(event_id, upvotes DESC, created_at);
CREATE TABLE event_question_votes (
  id              TEXT PRIMARY KEY,
  question_id     TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  created_at      INTEGER NOT NULL,
  UNIQUE (question_id, user_id)
);
-- Live chat messages
CREATE TABLE event_chat_messages (
  id              TEXT PRIMARY KEY,
  event_id        TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  content         TEXT NOT NULL,
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
);
CREATE INDEX idx_chat_event ON event_chat_messages(event_id, created_at DESC);
