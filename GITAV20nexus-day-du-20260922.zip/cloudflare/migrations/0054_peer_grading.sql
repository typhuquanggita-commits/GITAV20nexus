-- =========================================================
-- V20: PEER GRADING — Sinh viên chấm bài lẫn nhau
-- AI moderation + calibration
-- =========================================================
CREATE TABLE peer_grading_assignments (
  id              TEXT PRIMARY KEY,
  submission_id   TEXT NOT NULL,                  -- ref grading_submissions
  level_id        TEXT NOT NULL,
  question_id     TEXT NOT NULL,
  author_id       TEXT NOT NULL,
  -- Reviewer
  reviewer_id     TEXT,
  -- Status
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','assigned','in_review','submitted','disputed','resolved','expired')),
  -- Scoring
  peer_score      REAL,
  peer_feedback   TEXT,
  -- AI check
  ai_score        REAL,                            -- AI's own score for calibration
  -- Author feedback
  author_rating_of_review INTEGER CHECK (author_rating_of_review BETWEEN 1 AND 5),
  author_response TEXT,
  -- Meta
  assigned_at     INTEGER,
  submitted_at    INTEGER,
  expires_at      INTEGER,
  created_at      INTEGER NOT NULL,
  UNIQUE (submission_id, reviewer_id)
);
CREATE INDEX idx_peer_assignments ON peer_grading_assignments(reviewer_id, status, created_at DESC);
CREATE INDEX idx_peer_author ON peer_grading_assignments(author_id, status);
-- Reviewer reputation
CREATE TABLE peer_reviewer_stats (
  user_id         TEXT PRIMARY KEY,
  total_reviews   INTEGER NOT NULL DEFAULT 0,
  avg_review_time_min REAL NOT NULL DEFAULT 0,
  -- Quality
  agreement_score REAL NOT NULL DEFAULT 0.5,      -- Agreement with AI (0-1)
  helpfulness_score REAL NOT NULL DEFAULT 0.5,     -- Author ratings
  -- Calibration
  calibration_offset REAL NOT NULL DEFAULT 0,      -- Systematic bias
  -- Trust
  trust_tier      TEXT NOT NULL DEFAULT 'novice'
                  CHECK (trust_tier IN ('novice','apprentice','trusted','expert','master')),
  -- Meta
  total_authors_rated INTEGER NOT NULL DEFAULT 0,
  updated_at      INTEGER NOT NULL
);
-- Calibration examples (for training new reviewers)
CREATE TABLE peer_calibration_examples (
  id              TEXT PRIMARY KEY,
  question_id     TEXT NOT NULL,
  answer_text     TEXT NOT NULL,
  reference_score REAL NOT NULL,
  reference_feedback TEXT NOT NULL,
  difficulty      INTEGER NOT NULL DEFAULT 3,
  times_used      INTEGER NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL
);
CREATE INDEX idx_calibration ON peer_calibration_examples(question_id, difficulty);
-- Review outcomes (disputes)
CREATE TABLE peer_review_disputes (
  id              TEXT PRIMARY KEY,
  assignment_id   TEXT NOT NULL,
  raised_by       TEXT NOT NULL,
  reason          TEXT NOT NULL,
  evidence        TEXT,
  -- Resolution
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','resolved','escalated')),
  resolver_id     TEXT,
  resolution_note TEXT,
  final_score     REAL,
  resolved_at     INTEGER,
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (assignment_id) REFERENCES peer_grading_assignments(id) ON DELETE CASCADE
);
CREATE INDEX idx_disputes_status ON peer_review_disputes(status, created_at DESC);
