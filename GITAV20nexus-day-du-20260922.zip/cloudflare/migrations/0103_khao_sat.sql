-- =========================================================
-- KHẢO SÁT VÀ TEST CHUYÊN SÂU
--
-- Sáu nhóm phiếu: DISC · MBTI · kỹ năng · tâm lý học đường ·
-- nền kiến thức · kỹ năng xử lý tình huống.
--
-- MỘT ĐIỀU PHẢI GIỮ: kết quả tâm lý học đường KHÔNG phải chẩn đoán.
-- Cột canh_bao của bang phieu ghi sẵn câu ấy, và mọi đường trả kết quả
-- đều phải kèm nó ra ngoài. Một phiếu đo tâm lý mà trình bày như một
-- chẩn đoán y tế là thứ gây hại thật cho một đứa trẻ.
-- =========================================================

CREATE TABLE IF NOT EXISTS bo_phieu (
  id          TEXT PRIMARY KEY,           -- 'disc','mbti','ky-nang',…
  ten         TEXT NOT NULL,
  nhom        TEXT NOT NULL
              CHECK (nhom IN ('tinh-cach','ky-nang','tam-ly','nen-kien-thuc','xu-ly-tinh-huong')),
  so_cau      INTEGER NOT NULL,
  so_phut     INTEGER,
  cach_cham   TEXT NOT NULL,              -- mô tả cách quy điểm
  canh_bao    TEXT NOT NULL,              -- câu phải đi kèm mọi kết quả
  nguon       TEXT NOT NULL,              -- cơ sở của bộ phiếu
  phien_ban   TEXT NOT NULL DEFAULT '1',
  hoat_dong   INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS phieu_cau (
  id          TEXT PRIMARY KEY,
  bo_id       TEXT NOT NULL,
  thu_tu      INTEGER NOT NULL,
  cau         TEXT NOT NULL,
  dang        TEXT NOT NULL CHECK (dang IN ('thang-do','chon-mot','chon-nhieu','tinh-huong','tu-luan')),
  lua_chon_json TEXT,
  truc        TEXT,                       -- trục mà câu này đo: 'D','I','S','C','E','I'…
  trong_so    REAL NOT NULL DEFAULT 1,
  dao_chieu   INTEGER NOT NULL DEFAULT 0, -- câu hỏi ngược, chấm đảo thang
  UNIQUE (bo_id, thu_tu),
  FOREIGN KEY (bo_id) REFERENCES bo_phieu(id)
);
CREATE INDEX IF NOT EXISTS idx_phieu_cau_bo ON phieu_cau(bo_id, thu_tu);

CREATE TABLE IF NOT EXISTS luot_khao_sat (
  id          TEXT PRIMARY KEY,
  bo_id       TEXT NOT NULL,
  user_id     TEXT NOT NULL,
  cho_ai      TEXT,                       -- phụ huynh làm hộ con thì ghi tên con
  bat_dau     INTEGER NOT NULL,
  nop_luc     INTEGER,
  tra_loi_json TEXT,
  ket_qua_json TEXT,
  do_tin_cay  REAL,                       -- đo bằng câu đảo chiều và thời gian làm
  co_the_tin  INTEGER,                    -- 0 khi làm quá nhanh hoặc mâu thuẫn
  vi_sao_khong_tin TEXT,
  created_at  INTEGER NOT NULL,
  FOREIGN KEY (bo_id)   REFERENCES bo_phieu(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_luot_ks_nguoi ON luot_khao_sat(user_id, created_at DESC);

-- Hồ sơ khách hàng: gom mọi thứ biết được về một người học.
CREATE TABLE IF NOT EXISTS ho_so_hoc_vien (
  user_id      TEXT PRIMARY KEY,
  ho_ten       TEXT NOT NULL,
  ngay_sinh    TEXT,
  lop          INTEGER CHECK (lop BETWEEN 1 AND 12),
  truong       TEXT,
  tinh_thanh   TEXT,
  phu_huynh_id TEXT,
  muc_tieu_json TEXT NOT NULL DEFAULT '[]',
  mon_quan_tam_json TEXT NOT NULL DEFAULT '[]',
  ky_thi_dich_json  TEXT NOT NULL DEFAULT '[]',
  disc         TEXT,                      -- kết quả gần nhất, dạng 'DI'
  mbti         TEXT,
  phong_cach_hoc TEXT,
  ghi_chu      TEXT,
  created_at   INTEGER NOT NULL,
  updated_at   INTEGER NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Test đầu vào: đo nền kiến thức theo môn và lớp, ra cấp độ phù hợp.
CREATE TABLE IF NOT EXISTS test_dau_vao (
  id           TEXT PRIMARY KEY,
  user_id      TEXT NOT NULL,
  mon_id       TEXT NOT NULL,
  lop          INTEGER NOT NULL,
  de_id        TEXT,
  bat_dau      INTEGER NOT NULL,
  nop_luc      INTEGER,
  diem         REAL,
  cap_do_de_xuat TEXT,
  o_id_de_xuat   TEXT,
  lo_hong_json   TEXT,                    -- chuẩn kiến thức chưa đạt
  diem_manh_json TEXT,
  trang_thai   TEXT NOT NULL DEFAULT 'dang-lam'
               CHECK (trang_thai IN ('dang-lam','da-nop','da-xep-lop','huy')),
  created_at   INTEGER NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (mon_id)  REFERENCES mon_hoc(id)
);
CREATE INDEX IF NOT EXISTS idx_tdv_nguoi ON test_dau_vao(user_id, created_at DESC);
