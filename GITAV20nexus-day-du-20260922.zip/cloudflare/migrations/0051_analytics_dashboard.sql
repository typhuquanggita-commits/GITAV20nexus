-- =========================================================
-- V20: ANALYTICS DASHBOARD — Heatmap, skill radar, insights
-- =========================================================
-- Daily activity heatmap
CREATE TABLE analytics_activity_heatmap (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  day             TEXT NOT NULL,                  -- 'YYYY-MM-DD'
  minutes_learned INTEGER NOT NULL DEFAULT 0,
  lessons_done    INTEGER NOT NULL DEFAULT 0,
  quiz_attempts   INTEGER NOT NULL DEFAULT 0,
  avg_score       REAL NOT NULL DEFAULT 0,
  streak_kept     INTEGER NOT NULL DEFAULT 0,
  UNIQUE (user_id, day)
);
CREATE INDEX idx_heatmap_user ON analytics_activity_heatmap(user_id, day DESC);
-- Skill radar (aggregated từ user_skills)
CREATE TABLE analytics_skill_radar (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  category        TEXT NOT NULL,                  -- 'cognitive','technical','social','business','creative'
  level           REAL NOT NULL DEFAULT 0,        -- 0-5
  delta_30d       REAL NOT NULL DEFAULT 0,        -- Change in last 30 days
  computed_at     INTEGER NOT NULL,
  UNIQUE (user_id, category)
);
-- Learning insights (AI-generated)
CREATE TABLE analytics_insights (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  insight_type    TEXT NOT NULL CHECK (insight_type IN ('pattern','recommendation','warning','celebration','prediction')),
  title           TEXT NOT NULL,
  body            TEXT NOT NULL,
  severity        TEXT NOT NULL DEFAULT 'info' CHECK (severity IN ('info','success','warning','error')),
  action_json     TEXT,                            -- {type, label, payload}
  seen_at         INTEGER,
  dismissed_at    INTEGER,
  created_at      INTEGER NOT NULL
);
CREATE INDEX idx_insights_user ON analytics_insights(user_id, created_at DESC);
CREATE INDEX idx_insights_unseen ON analytics_insights(user_id, seen_at) WHERE seen_at IS NULL;
-- Time-of-day performance pattern
CREATE TABLE analytics_time_patterns (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  hour_of_day     INTEGER NOT NULL CHECK (hour_of_day BETWEEN 0 AND 23),
  day_of_week     INTEGER NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
  avg_score       REAL NOT NULL DEFAULT 0,
  sessions_count  INTEGER NOT NULL DEFAULT 0,
  updated_at      INTEGER NOT NULL,
  UNIQUE (user_id, hour_of_day, day_of_week)
);
-- Comparison with cohort (anonymous percentile)
CREATE TABLE analytics_percentiles (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  metric          TEXT NOT NULL,                  -- 'lessons_per_week','avg_score','streak'
  value           REAL NOT NULL,
  percentile      INTEGER NOT NULL,               -- 0-100
  computed_at     INTEGER NOT NULL,
  UNIQUE (user_id, metric)
);
