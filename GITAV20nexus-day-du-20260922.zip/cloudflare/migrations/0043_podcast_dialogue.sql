-- =========================================================
-- V18: PODCAST DIALOGUE — 2 host AI đối thoại
-- Thay thế podcast 1 host bằng dialogue tự nhiên
-- =========================================================
CREATE TABLE podcast_hosts (
  id              TEXT PRIMARY KEY,
  name            TEXT NOT NULL,
  role            TEXT NOT NULL,               -- 'host','cohost','expert','comedian'
  personality     TEXT NOT NULL,               -- Mô tả tính cách cho prompt
  voice_id        TEXT NOT NULL,               -- TTS voice
  tone            TEXT NOT NULL DEFAULT 'warm',
  bio             TEXT,
  avatar_url      TEXT,
  language        TEXT NOT NULL DEFAULT 'vi',
  is_active       INTEGER NOT NULL DEFAULT 1,
  created_at      INTEGER NOT NULL
);
CREATE TABLE dialogue_episodes (
  id              TEXT PRIMARY KEY,
  level_id        TEXT,                        -- Ref tới level (optional)
  topic           TEXT NOT NULL,
  -- Hosts
  host_a_id       TEXT NOT NULL,
  host_b_id       TEXT NOT NULL,
  -- Content
  script_json     TEXT NOT NULL,               -- [{speaker, text, emphasis}]
  audio_r2_key    TEXT,
  audio_duration  INTEGER,
  -- Dialogue style
  style           TEXT NOT NULL DEFAULT 'conversational'
                  CHECK (style IN ('conversational','interview','debate','storytelling','teaching')),
  target_duration_min INTEGER NOT NULL DEFAULT 15,
  language        TEXT NOT NULL DEFAULT 'vi',
  -- Chapters
  chapters_json   TEXT DEFAULT '[]',
  -- Meta
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','scripting','recording','ready','failed')),
  published_at    INTEGER,
  listen_count    INTEGER NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL,
  FOREIGN KEY (host_a_id) REFERENCES podcast_hosts(id),
  FOREIGN KEY (host_b_id) REFERENCES podcast_hosts(id)
);
CREATE INDEX idx_dialogue_status ON dialogue_episodes(status, published_at DESC);
-- Individual speaker turns (for TTS processing)
CREATE TABLE dialogue_turns (
  id              TEXT PRIMARY KEY,
  episode_id      TEXT NOT NULL,
  turn_index      INTEGER NOT NULL,
  host_id         TEXT NOT NULL,
  text            TEXT NOT NULL,
  emphasis_json   TEXT DEFAULT '[]',            -- Words to emphasize
  audio_r2_key    TEXT,
  audio_duration_ms INTEGER,
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (episode_id) REFERENCES dialogue_episodes(id) ON DELETE CASCADE,
  UNIQUE (episode_id, turn_index)
);
CREATE INDEX idx_turns_episode ON dialogue_turns(episode_id, turn_index);
-- Dialogue templates
CREATE TABLE dialogue_templates (
  id              TEXT PRIMARY KEY,
  style           TEXT NOT NULL,
  name            TEXT NOT NULL,
  prompt_template TEXT NOT NULL,
  is_active       INTEGER NOT NULL DEFAULT 1,
  created_at      INTEGER NOT NULL
);
