-- =========================================================
-- CHUỖI VIDEO BÀI GIẢI
--
-- Video ở đây không phải tệp — Cloudflare Pages không giữ tệp lớn.
-- Bảng này giữ KỊCH BẢN và THỨ TỰ: chuỗi bài giải được sắp theo đúng
-- trình tự sư phạm, mỗi cảnh nói gì, hiện gì, dài bao nhiêu giây.
-- Tệp dựng xong nằm ở R2 hoặc nơi khác, chỉ lưu đường dẫn.
-- =========================================================

CREATE TABLE IF NOT EXISTS chuoi_video (
  id           TEXT PRIMARY KEY,
  o_id         TEXT,
  chuyen_de_id TEXT,
  ten          TEXT NOT NULL,
  muc_tieu     TEXT NOT NULL,
  so_tap       INTEGER NOT NULL DEFAULT 0,
  thu_tu_json  TEXT NOT NULL DEFAULT '[]',
  trang_thai   TEXT NOT NULL DEFAULT 'nhap'
               CHECK (trang_thai IN ('nhap','da-soat','da-xuat-ban','thu-hoi')),
  created_at   INTEGER NOT NULL,
  updated_at   INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS video_tap (
  id           TEXT PRIMARY KEY,
  chuoi_id     TEXT NOT NULL,
  thu_tu       INTEGER NOT NULL,
  ten          TEXT NOT NULL,
  bai_id       TEXT,                      -- bài tập mà tập này giải
  giay         INTEGER NOT NULL,
  kich_ban_json TEXT NOT NULL,            -- [{canh, loi_doc, hien_gi, giay}]
  giong_doc    TEXT,
  duong_dan    TEXT,                      -- nơi tệp đã dựng nằm
  phu_de_vtt   TEXT,
  trang_thai   TEXT NOT NULL DEFAULT 'kich-ban'
               CHECK (trang_thai IN ('kich-ban','da-soat','dang-dung','da-dung','thu-hoi')),
  created_at   INTEGER NOT NULL,
  updated_at   INTEGER NOT NULL,
  UNIQUE (chuoi_id, thu_tu),
  FOREIGN KEY (chuoi_id) REFERENCES chuoi_video(id)
);
CREATE INDEX IF NOT EXISTS idx_vt_chuoi ON video_tap(chuoi_id, thu_tu);

CREATE TABLE IF NOT EXISTS video_luot_xem (
  id           TEXT PRIMARY KEY,
  tap_id       TEXT NOT NULL,
  user_id      TEXT,
  giay_xem     INTEGER NOT NULL DEFAULT 0,
  xem_het      INTEGER NOT NULL DEFAULT 0,
  tua_lai      INTEGER NOT NULL DEFAULT 0,   -- tua lại nhiều = chỗ khó hiểu
  at           INTEGER NOT NULL,
  FOREIGN KEY (tap_id) REFERENCES video_tap(id)
);
CREATE INDEX IF NOT EXISTS idx_vlx_tap ON video_luot_xem(tap_id, at DESC);
