-- =========================================================
-- V22: LEGAL COMPLIANCE — Auto-check Luật 91 + chính sách
-- =========================================================
CREATE TABLE legal_rules (
  id              TEXT PRIMARY KEY,
  code            TEXT NOT NULL UNIQUE,
  jurisdiction    TEXT NOT NULL DEFAULT 'VN',
  source          TEXT NOT NULL,                   -- 'luat_91_2025','gdpr','internal_policy','coppa'
  category        TEXT NOT NULL CHECK (category IN (
    'data_privacy','content_safety','minor_protection','ip_copyright',
    'advertising','financial','health_claims','personal_data','consent','retention'
  )),
  severity        TEXT NOT NULL DEFAULT 'high'
                  CHECK (severity IN ('low','medium','high','critical')),
  title           TEXT NOT NULL,
  description     TEXT NOT NULL,
  -- Detection
  detection_type  TEXT NOT NULL CHECK (detection_type IN ('keyword','regex','ai_classifier','hybrid')),
  detection_config_json TEXT NOT NULL,             -- {keywords: [], regex: '...', aiPrompt: '...'}
  -- Remediation
  remediation     TEXT NOT NULL,
  -- Meta
  is_active       INTEGER NOT NULL DEFAULT 1,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX idx_legal_rules ON legal_rules(jurisdiction, category, is_active);
CREATE TABLE compliance_checks (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  -- Target
  content_type    TEXT NOT NULL,                   -- 'level','course','question','user_upload','chat'
  content_id      TEXT,
  content_excerpt TEXT NOT NULL,
  -- Result
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','running','pass','warn','fail')),
  risk_level      TEXT NOT NULL DEFAULT 'none'
                  CHECK (risk_level IN ('none','low','medium','high','critical')),
  risk_score      REAL NOT NULL DEFAULT 0,
  -- Findings
  violations_json TEXT DEFAULT '[]',               -- [{ruleId, severity, excerpt, remediation}]
  -- AI analysis
  ai_analysis     TEXT,
  -- Meta
  tokens_used     INTEGER NOT NULL DEFAULT 0,
  duration_ms     INTEGER,
  created_at      INTEGER NOT NULL,
  completed_at    INTEGER
);
CREATE INDEX idx_compliance_user ON compliance_checks(user_id, created_at DESC);
CREATE INDEX idx_compliance_content ON compliance_checks(content_type, content_id);
CREATE INDEX idx_compliance_risk ON compliance_checks(risk_level, created_at DESC) WHERE status != 'pass';
-- Compliance issues (persistent tracker)
CREATE TABLE compliance_issues (
  id              TEXT PRIMARY KEY,
  check_id        TEXT NOT NULL,
  rule_id         TEXT NOT NULL,
  -- Status
  status          TEXT NOT NULL DEFAULT 'open'
                  CHECK (status IN ('open','in_review','resolved','dismissed','escalated')),
  severity        TEXT NOT NULL,
  -- Resolution
  resolved_by     TEXT,
  resolution_note TEXT,
  -- Meta
  created_at      INTEGER NOT NULL,
  resolved_at     INTEGER,
  FOREIGN KEY (check_id) REFERENCES compliance_checks(id) ON DELETE CASCADE,
  FOREIGN KEY (rule_id) REFERENCES legal_rules(id)
);
CREATE INDEX idx_issues_status ON compliance_issues(status, severity, created_at DESC);
-- Policy acceptance log
CREATE TABLE policy_acceptances (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  policy_code     TEXT NOT NULL,                   -- 'terms_v1','privacy_v2','dpa_v1'
  policy_version  TEXT NOT NULL,
  accepted        INTEGER NOT NULL,
  ip_address      TEXT,
  user_agent      TEXT,
  signature       TEXT,
  created_at      INTEGER NOT NULL,
  UNIQUE (user_id, policy_code, policy_version)
);
CREATE INDEX idx_policy_user ON policy_acceptances(user_id, policy_code, accepted);
