-- =========================================================
-- KHO BÀI TẬP — đích của hệ thống là 800.000 bài
--
-- Bảng phu_song ở cuối là thứ quan trọng nhất ở đây. Nó ĐẾM bài thật
-- trong kho chứ không giữ một con số do người khai. Trang nào muốn nói
-- "kho có bao nhiêu bài" đều phải đọc từ đó, nên không có chỗ nào trong
-- hệ thống nói được một con số mà kho không đỡ nổi.
-- =========================================================

CREATE TABLE IF NOT EXISTS bai_tap (
  id            TEXT PRIMARY KEY,
  chuyen_de_id  TEXT NOT NULL,
  o_id          TEXT NOT NULL,            -- lặp lại để lọc nhanh, đồng bộ bằng ứng dụng
  ma            TEXT NOT NULL UNIQUE,
  dang          TEXT NOT NULL             -- dạng câu hỏi
                CHECK (dang IN ('trac-nghiem','dung-sai','dien-so','tu-luan','ghep-doi','sap-xep','noi-nghe','noi-viet')),
  do_kho        INTEGER NOT NULL CHECK (do_kho BETWEEN 1 AND 10),
  de_bai        TEXT NOT NULL,
  lua_chon_json TEXT,                     -- với trắc nghiệm: ["A…","B…"]
  dap_an_json   TEXT NOT NULL,
  loi_giai      TEXT,                     -- lời giải từng bước
  chuan_ids_json TEXT NOT NULL DEFAULT '[]',
  nguon         TEXT NOT NULL,            -- sách, đề thi năm nào, hay tự soạn
  ky_hieu_chuan TEXT NOT NULL DEFAULT 'iso-80000-2',
  bam_noi_dung  TEXT NOT NULL,            -- SHA-256 của đề, để bắt bài trùng
  trang_thai    TEXT NOT NULL DEFAULT 'nhap'
                CHECK (trang_thai IN ('nhap','da-soat','da-xuat-ban','thu-hoi')),
  diem_chat_luong REAL,
  so_lan_dung   INTEGER NOT NULL DEFAULT 0,
  ti_le_dung    REAL,                     -- tỉ lệ làm đúng thực tế
  nguoi_tao     TEXT,
  nguoi_soat    TEXT,
  created_at    INTEGER NOT NULL,
  updated_at    INTEGER NOT NULL,
  FOREIGN KEY (chuyen_de_id) REFERENCES chuyen_de(id)
);
CREATE INDEX IF NOT EXISTS idx_bai_tap_cd   ON bai_tap(chuyen_de_id, do_kho);
CREATE INDEX IF NOT EXISTS idx_bai_tap_o    ON bai_tap(o_id, trang_thai, do_kho);
CREATE UNIQUE INDEX IF NOT EXISTS idx_bai_tap_bam ON bai_tap(bam_noi_dung);

-- Mỗi lần một bài bị sửa đều để lại dấu — kho bài là tài sản, không phải nháp.
CREATE TABLE IF NOT EXISTS bai_tap_lich_su (
  id          TEXT PRIMARY KEY,
  bai_id      TEXT NOT NULL,
  viec        TEXT NOT NULL,              -- 'tao','sua','soat','xuat-ban','thu-hoi'
  nguoi       TEXT,
  truoc_json  TEXT,
  sau_json    TEXT,
  ly_do       TEXT,
  at          INTEGER NOT NULL,
  FOREIGN KEY (bai_id) REFERENCES bai_tap(id)
);
CREATE INDEX IF NOT EXISTS idx_bai_ls ON bai_tap_lich_su(bai_id, at DESC);

-- Phủ sóng: đếm lại từ kho thật, không ai khai tay được.
CREATE TABLE IF NOT EXISTS phu_song (
  id            TEXT PRIMARY KEY,         -- trùng o_id
  o_id          TEXT NOT NULL UNIQUE,
  so_chuyen_de  INTEGER NOT NULL DEFAULT 0,
  so_bai_nhap   INTEGER NOT NULL DEFAULT 0,
  so_bai_soat   INTEGER NOT NULL DEFAULT 0,
  so_bai_xuat   INTEGER NOT NULL DEFAULT 0,
  so_chuan      INTEGER NOT NULL DEFAULT 0,
  so_chuan_co_bai INTEGER NOT NULL DEFAULT 0,
  dem_luc       INTEGER NOT NULL,
  FOREIGN KEY (o_id) REFERENCES o_chuong_trinh(id)
);
