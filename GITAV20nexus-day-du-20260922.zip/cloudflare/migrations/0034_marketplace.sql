-- =========================================================
-- V16: MARKETPLACE UGC — Creator economy + escrow V9
-- =========================================================
-- Creator profiles
CREATE TABLE creators (
  user_id         TEXT PRIMARY KEY,
  display_name    TEXT NOT NULL,
  bio             TEXT,
  avatar_url      TEXT,
  website         TEXT,
  total_courses   INTEGER NOT NULL DEFAULT 0,
  total_students  INTEGER NOT NULL DEFAULT 0,
  total_revenue   INTEGER NOT NULL DEFAULT 0,     -- VND
  avg_rating      REAL NOT NULL DEFAULT 0,
  reputation_tier TEXT NOT NULL DEFAULT 'new'
                  CHECK (reputation_tier IN ('new','verified','rising','top','elite')),
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','suspended','banned')),
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
-- Courses (UGC products)
CREATE TABLE courses (
  id              TEXT PRIMARY KEY,
  creator_id      TEXT NOT NULL,
  slug            TEXT NOT NULL UNIQUE,
  title           TEXT NOT NULL,
  subtitle        TEXT,
  description     TEXT NOT NULL,
  cover_url      TEXT,
  -- Content
  content_json    TEXT NOT NULL,                  -- Course structure: modules, lessons
  preview_json    TEXT DEFAULT '{}',              -- Free preview
  outcomes_json   TEXT DEFAULT '[]',
  prerequisites   TEXT DEFAULT '[]',
  -- Pricing
  price           INTEGER NOT NULL DEFAULT 0,     -- VND
  sale_price      INTEGER,                        -- Optional
  sale_ends_at    INTEGER,
  currency        TEXT NOT NULL DEFAULT 'VND',
  -- Meta
  language        TEXT NOT NULL DEFAULT 'vi',
  level           TEXT NOT NULL DEFAULT 'beginner'
                  CHECK (level IN ('beginner','intermediate','advanced','all')),
  category        TEXT NOT NULL,                  -- 'mindset','skill','business','ethics','practice'
  tags_json       TEXT DEFAULT '[]',
  -- Duration
  total_lessons   INTEGER NOT NULL DEFAULT 0,
  total_duration  INTEGER NOT NULL DEFAULT 0,     -- seconds
  -- Status
  status          TEXT NOT NULL DEFAULT 'draft'
                  CHECK (status IN ('draft','in_review','published','archived','rejected')),
  published_at    INTEGER,
  -- Metrics
  enrollments     INTEGER NOT NULL DEFAULT 0,
  completions     INTEGER NOT NULL DEFAULT 0,
  avg_rating      REAL NOT NULL DEFAULT 0,
  rating_count    INTEGER NOT NULL DEFAULT 0,
  -- Revenue split (creator gets this %)
  creator_share   REAL NOT NULL DEFAULT 0.7,      -- 70%
  platform_share  REAL NOT NULL DEFAULT 0.3,      -- 30%
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX idx_courses_status ON courses(status, published_at DESC);
CREATE INDEX idx_courses_creator ON courses(creator_id, status);
CREATE INDEX idx_courses_category ON courses(category, status);
-- Enrollments
CREATE TABLE course_enrollments (
  id              TEXT PRIMARY KEY,
  course_id       TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  escrow_tx_id    TEXT,                            -- Ref tới escrow V9
  amount_paid     INTEGER NOT NULL,
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','completed','refunded','disputed')),
  progress_pct    REAL NOT NULL DEFAULT 0,
  -- Metrics
  last_lesson_id  TEXT,
  completed_at    INTEGER,
  certificate_id  TEXT,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL,
  UNIQUE (course_id, user_id)
);
CREATE INDEX idx_enrollments_user ON course_enrollments(user_id, created_at DESC);
CREATE INDEX idx_enrollments_course ON course_enrollments(course_id, status);
-- Course reviews
CREATE TABLE course_reviews (
  id              TEXT PRIMARY KEY,
  course_id       TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  enrollment_id   TEXT NOT NULL,
  rating          INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  title           TEXT,
  content         TEXT NOT NULL,
  helpful_count   INTEGER NOT NULL DEFAULT 0,
  status          TEXT NOT NULL DEFAULT 'published'
                  CHECK (status IN ('published','hidden','flagged')),
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL,
  UNIQUE (course_id, user_id)
);
CREATE INDEX idx_reviews_course ON course_reviews(course_id, status, created_at DESC);
-- Creator payouts
CREATE TABLE creator_payouts (
  id              TEXT PRIMARY KEY,
  creator_id      TEXT NOT NULL,
  period_start    INTEGER NOT NULL,
  period_end      INTEGER NOT NULL,
  gross_revenue   INTEGER NOT NULL,
  platform_fee    INTEGER NOT NULL,
  net_payout      INTEGER NOT NULL,
  -- Payment
  payout_method   TEXT,
  payout_ref      TEXT,
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','processing','paid','failed','on_hold')),
  paid_at         INTEGER,
  notes           TEXT,
  created_at      INTEGER NOT NULL
);
CREATE INDEX idx_payouts_creator ON creator_payouts(creator_id, status, period_start DESC);
