-- =========================================================
-- V20: TRANSLATOR PRO — Glossary domain + voice dub
-- =========================================================
CREATE TABLE translation_glossaries (
  id              TEXT PRIMARY KEY,
  user_id         TEXT,                            -- NULL = system glossary
  name            TEXT NOT NULL,
  source_lang     TEXT NOT NULL DEFAULT 'vi',
  target_lang     TEXT NOT NULL,
  domain          TEXT NOT NULL,                  -- 'business','tech','education','medical'
  terms_json      TEXT NOT NULL,                  -- [{source, target, context, priority}]
  is_public       INTEGER NOT NULL DEFAULT 0,
  usage_count     INTEGER NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL
);
CREATE INDEX idx_glossaries ON translation_glossaries(target_lang, domain, is_public);
CREATE TABLE translation_jobs (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  source_type     TEXT NOT NULL CHECK (source_type IN ('level','course','question','custom')),
  source_id       TEXT,
  source_lang     TEXT NOT NULL DEFAULT 'vi',
  target_lang     TEXT NOT NULL,
  -- Config
  glossary_id     TEXT,
  tone            TEXT NOT NULL DEFAULT 'neutral'
                  CHECK (tone IN ('neutral','formal','casual','technical','marketing')),
  -- Status
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','running','ready','failed')),
  -- Output
  source_text     TEXT NOT NULL,
  translated_text TEXT,
  quality_score   REAL,
  -- Metrics
  tokens_used     INTEGER NOT NULL DEFAULT 0,
  char_count      INTEGER NOT NULL DEFAULT 0,
  cost_estimate   REAL NOT NULL DEFAULT 0,
  -- Meta
  created_at      INTEGER NOT NULL,
  completed_at    INTEGER
);
CREATE INDEX idx_trans_jobs_user ON translation_jobs(user_id, created_at DESC);
-- Voice dub jobs
CREATE TABLE voice_dub_jobs (
  id              TEXT PRIMARY KEY,
  translation_job_id TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  voice_id        TEXT NOT NULL DEFAULT 'vi-VN-HoaiMyNeural',
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','recording','ready','failed')),
  audio_r2_key    TEXT,
  audio_duration  INTEGER,
  -- Meta
  created_at      INTEGER NOT NULL,
  completed_at    INTEGER
);
CREATE INDEX idx_dub_jobs ON voice_dub_jobs(translation_job_id, status);
