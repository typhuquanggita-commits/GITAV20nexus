-- =========================================================
-- V20: LESSON REMIXER — 1 level → 10 formats
-- Podcast, quiz, video script, mindmap, flashcard, cheatsheet,
-- case study, debate topic, exercise pack, social posts
-- =========================================================
CREATE TABLE remix_formats (
  id              TEXT PRIMARY KEY,
  code            TEXT NOT NULL UNIQUE,
  name            TEXT NOT NULL,
  description     TEXT NOT NULL,
  output_schema_json TEXT NOT NULL,
  prompt_template TEXT NOT NULL,
  icon            TEXT,
  is_active       INTEGER NOT NULL DEFAULT 1,
  created_at      INTEGER NOT NULL
);
CREATE TABLE remix_jobs (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  level_id        TEXT NOT NULL,
  format_code     TEXT NOT NULL,
  -- Config
  options_json    TEXT DEFAULT '{}',              -- {tone, length, language, ...}
  -- Status
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','running','ready','failed')),
  -- Output
  output_json     TEXT,
  output_md       TEXT,
  -- Meta
  tokens_used     INTEGER NOT NULL DEFAULT 0,
  latency_ms      INTEGER,
  error_log       TEXT,
  created_at      INTEGER NOT NULL,
  completed_at    INTEGER
);
CREATE INDEX idx_remix_user ON remix_jobs(user_id, status, created_at DESC);
CREATE INDEX idx_remix_level ON remix_jobs(level_id, format_code);
-- Shared remixes (cache to avoid re-generation)
CREATE TABLE remix_cache (
  id              TEXT PRIMARY KEY,
  level_id        TEXT NOT NULL,
  format_code     TEXT NOT NULL,
  content_hash    TEXT NOT NULL,                  -- SHA-256 của level content
  output_json     TEXT NOT NULL,
  output_md       TEXT NOT NULL,
  hit_count       INTEGER NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL,
  UNIQUE (level_id, format_code, content_hash)
);
CREATE INDEX idx_remix_cache_lookup ON remix_cache(level_id, format_code, content_hash);
