-- =========================================================
-- V17: AI INTERVIEW PREP — Mock interview + feedback theo STAR
-- =========================================================
CREATE TABLE interview_roles (
  id              TEXT PRIMARY KEY,
  slug            TEXT NOT NULL UNIQUE,
  title           TEXT NOT NULL,              -- 'Frontend Developer', 'Marketing Manager'
  category        TEXT NOT NULL,
  level           TEXT NOT NULL CHECK (level IN ('junior','mid','senior','lead','executive')),
  description     TEXT,
  -- Question bank
  question_categories_json TEXT NOT NULL,     -- ['behavioral','technical','situational','case','culture']
  -- Meta
  created_at      INTEGER NOT NULL
);
CREATE TABLE interview_questions (
  id              TEXT PRIMARY KEY,
  role_id         TEXT,                        -- NULL = universal
  category        TEXT NOT NULL CHECK (category IN ('behavioral','technical','situational','case','culture')),
  difficulty      INTEGER NOT NULL DEFAULT 3 CHECK (difficulty BETWEEN 1 AND 5),
  question_text   TEXT NOT NULL,
  -- Evaluation
  ideal_answer_md TEXT,
  rubric_json     TEXT NOT NULL,               -- [{criterion, weight, description}]
  star_expectations_json TEXT,                 -- {situation, task, action, result} prompts
  keywords_json   TEXT DEFAULT '[]',
  -- Meta
  usage_count     INTEGER NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL
);
CREATE INDEX idx_questions_role ON interview_questions(role_id, category, difficulty);
CREATE TABLE interview_sessions (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  role_id         TEXT NOT NULL,
  mode            TEXT NOT NULL CHECK (mode IN ('quick','full','targeted')),
  language        TEXT NOT NULL DEFAULT 'vi',
  voice_enabled   INTEGER NOT NULL DEFAULT 0,
  -- Status
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','completed','abandoned')),
  total_questions INTEGER NOT NULL DEFAULT 5,
  answered_count  INTEGER NOT NULL DEFAULT 0,
  -- Overall
  overall_score   REAL,
  overall_feedback TEXT,
  strengths_json  TEXT DEFAULT '[]',
  improvements_json TEXT DEFAULT '[]',
  -- Meta
  duration_sec    INTEGER,
  tokens_used     INTEGER NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL,
  completed_at    INTEGER
);
CREATE INDEX idx_interview_sessions_user ON interview_sessions(user_id, status, created_at DESC);
CREATE TABLE interview_answers (
  id              TEXT PRIMARY KEY,
  session_id      TEXT NOT NULL,
  question_id     TEXT NOT NULL,
  question_index  INTEGER NOT NULL,
  -- Answer
  answer_text     TEXT NOT NULL,
  answer_audio_r2_key TEXT,
  duration_sec    INTEGER,
  -- AI Evaluation
  overall_score   REAL NOT NULL,               -- 0-1
  star_breakdown_json TEXT,                    -- {situation: 0.8, task: 0.7, action: 0.9, result: 0.6}
  criteria_scores_json TEXT,                   -- [{criterion, score, feedback}]
  strengths_json  TEXT DEFAULT '[]',
  improvements_json TEXT DEFAULT '[]',
  improved_answer_md TEXT,                     -- AI's better version
  keywords_matched_json TEXT DEFAULT '[]',
  -- Meta
  model           TEXT,
  tokens_used     INTEGER NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (session_id) REFERENCES interview_sessions(id) ON DELETE CASCADE,
  UNIQUE (session_id, question_index)
);
CREATE INDEX idx_interview_answers_session ON interview_answers(session_id, question_index);
-- Progress tracking
CREATE TABLE interview_progress (
  user_id         TEXT PRIMARY KEY,
  total_sessions  INTEGER NOT NULL DEFAULT 0,
  total_questions INTEGER NOT NULL DEFAULT 0,
  avg_score       REAL NOT NULL DEFAULT 0,
  best_score      REAL NOT NULL DEFAULT 0,
  score_history_json TEXT DEFAULT '[]',       -- [{date, score, roleId}]
  strengths_last_5_json TEXT DEFAULT '[]',
  updated_at      INTEGER NOT NULL
);
