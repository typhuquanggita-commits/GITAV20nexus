-- =========================================================
-- V17: GLOBAL SKILL GRAPH — Đồ thị kỹ năng toàn cầu
-- =========================================================
CREATE TABLE skills (
  id              TEXT PRIMARY KEY,
  slug            TEXT NOT NULL UNIQUE,
  name            TEXT NOT NULL,
  description     TEXT,
  category        TEXT NOT NULL,              -- 'technical','cognitive','social','business','creative'
  tags_json       TEXT DEFAULT '[]',
  -- Demand signal
  market_demand   REAL NOT NULL DEFAULT 0,    -- 0-1, job posting frequency
  growth_rate     REAL NOT NULL DEFAULT 0,    -- YoY growth
  avg_salary_usd  INTEGER,                    -- Avg salary for this skill
  -- Meta
  is_core         INTEGER NOT NULL DEFAULT 0, -- Foundational skill
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX idx_skills_category ON skills(category, market_demand DESC);
-- Skill dependencies (DAG)
CREATE TABLE skill_dependencies (
  id              TEXT PRIMARY KEY,
  from_skill      TEXT NOT NULL,
  to_skill        TEXT NOT NULL,
  relation        TEXT NOT NULL CHECK (relation IN ('prerequisite','complements','alternative','specialization')),
  strength        REAL NOT NULL DEFAULT 1.0,
  created_at      INTEGER NOT NULL,
  UNIQUE (from_skill, to_skill, relation),
  FOREIGN KEY (from_skill) REFERENCES skills(id),
  FOREIGN KEY (to_skill) REFERENCES skills(id)
);
CREATE INDEX idx_dep_from ON skill_dependencies(from_skill, relation);
CREATE INDEX idx_dep_to ON skill_dependencies(to_skill, relation);
-- Map GITA levels → skills
CREATE TABLE level_skills (
  level_id        TEXT NOT NULL,
  skill_id        TEXT NOT NULL,
  mastery_level   INTEGER NOT NULL DEFAULT 1 CHECK (mastery_level BETWEEN 1 AND 5),
  confidence      REAL NOT NULL DEFAULT 0.5,
  PRIMARY KEY (level_id, skill_id)
);
-- Map courses → skills
CREATE TABLE course_skills (
  course_id       TEXT NOT NULL,
  skill_id        TEXT NOT NULL,
  mastery_level   INTEGER NOT NULL DEFAULT 1 CHECK (mastery_level BETWEEN 1 AND 5),
  PRIMARY KEY (course_id, skill_id)
);
-- User skill profiles (inferred)
CREATE TABLE user_skills (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  skill_id        TEXT NOT NULL,
  mastery_level   INTEGER NOT NULL DEFAULT 0 CHECK (mastery_level BETWEEN 0 AND 5),
  evidence_json   TEXT DEFAULT '[]',           -- [{sourceType, sourceId, weight}]
  verified        INTEGER NOT NULL DEFAULT 0,
  last_updated    INTEGER NOT NULL,
  UNIQUE (user_id, skill_id)
);
CREATE INDEX idx_user_skills ON user_skills(user_id, mastery_level DESC);
-- Career paths
CREATE TABLE career_paths (
  id              TEXT PRIMARY KEY,
  slug            TEXT NOT NULL UNIQUE,
  title           TEXT NOT NULL,
  description     TEXT NOT NULL,
  required_skills_json TEXT NOT NULL,          -- [{skillId, minLevel, priority}]
  nice_to_have_json TEXT DEFAULT '[]',
  avg_salary_usd  INTEGER,
  growth_outlook  TEXT,                        -- 'declining','stable','growing','hot'
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
-- User career goals
CREATE TABLE user_career_goals (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  career_path_id  TEXT NOT NULL,
  current_gap_json TEXT,                        -- Computed gaps
  target_date     INTEGER,
  status          TEXT NOT NULL DEFAULT 'exploring'
                  CHECK (status IN ('exploring','committed','in_progress','achieved','abandoned')),
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
