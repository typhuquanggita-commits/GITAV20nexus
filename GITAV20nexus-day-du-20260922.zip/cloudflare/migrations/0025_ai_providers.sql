-- =========================================================
-- V13: MULTI-PROVIDER AI GATEWAY — Nhân bản free tier ×6
-- =========================================================
CREATE TABLE ai_providers (
  id              TEXT PRIMARY KEY,
  code            TEXT NOT NULL UNIQUE,       -- 'cf-workers-ai','gemini','groq','openrouter','together','hf'
  name            TEXT NOT NULL,
  base_url        TEXT NOT NULL,
  api_key_env     TEXT NOT NULL,              -- Tên env var chứa key
  models_json     TEXT NOT NULL,              -- [{id, tier, contextLength, costWeight}]
  daily_quota     INTEGER NOT NULL,           -- requests/day
  rpm_limit       INTEGER NOT NULL,           -- requests/minute
  tpm_limit       INTEGER,                    -- tokens/minute
  priority        INTEGER NOT NULL DEFAULT 5,
  enabled         INTEGER NOT NULL DEFAULT 1,
  healthy         INTEGER NOT NULL DEFAULT 1,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
-- Usage tracking per provider per day
CREATE TABLE ai_provider_usage (
  id              TEXT PRIMARY KEY,
  provider_code   TEXT NOT NULL,
  day             TEXT NOT NULL,              -- 'YYYY-MM-DD'
  requests_count  INTEGER NOT NULL DEFAULT 0,
  tokens_input    INTEGER NOT NULL DEFAULT 0,
  tokens_output   INTEGER NOT NULL DEFAULT 0,
  failures_count  INTEGER NOT NULL DEFAULT 0,
  avg_latency_ms  INTEGER,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL,
  UNIQUE (provider_code, day)
);
-- Health check log
CREATE TABLE ai_provider_health (
  id              TEXT PRIMARY KEY,
  provider_code   TEXT NOT NULL,
  status          TEXT NOT NULL CHECK (status IN ('healthy','degraded','down')),
  latency_ms      INTEGER,
  error_msg       TEXT,
  checked_at      INTEGER NOT NULL
);
CREATE INDEX idx_health_provider ON ai_provider_health(provider_code, checked_at DESC);
