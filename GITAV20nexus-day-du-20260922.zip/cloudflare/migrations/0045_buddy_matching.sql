-- =========================================================
-- V19: STUDY BUDDY — Ghép cặp học thông minh
-- Thuật toán: goals + timezone + level + learning style + pace
-- =========================================================
CREATE TABLE buddy_profiles (
  user_id         TEXT PRIMARY KEY,
  -- Availability
  timezone        TEXT NOT NULL DEFAULT 'Asia/Ho_Chi_Minh',
  weekly_hours    INTEGER NOT NULL DEFAULT 5,       -- Số giờ/tuần có thể học cùng
  preferred_slots_json TEXT DEFAULT '[]',           -- ["evening","weekend"] hoặc [{dayOfWeek, hour}]
  -- Goals
  active_goals_json TEXT DEFAULT '[]',              -- ['career','skill','mindset']
  target_topics_json TEXT DEFAULT '[]',             -- ['ai','business','leadership']
  -- Learning profile
  learning_style  TEXT NOT NULL DEFAULT 'balanced',
  pace            TEXT NOT NULL DEFAULT 'normal',
  preferred_lang  TEXT NOT NULL DEFAULT 'vi',
  -- Matching prefs
  preferred_gender TEXT CHECK (preferred_gender IN ('any','male','female','non_binary')),
  preferred_age_range TEXT CHECK (preferred_age_range IN ('any','18-24','25-34','35-44','45-54','55+')),
  same_level_only INTEGER NOT NULL DEFAULT 1,
  -- Status
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','paused','matched','inactive')),
  -- Meta
  total_matches   INTEGER NOT NULL DEFAULT 0,
  successful_goals INTEGER NOT NULL DEFAULT 0,
  avg_partner_rating REAL NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX idx_buddy_status ON buddy_profiles(status);
CREATE INDEX idx_buddy_tz ON buddy_profiles(timezone, status);
CREATE TABLE buddy_matches (
  id              TEXT PRIMARY KEY,
  user_a_id       TEXT NOT NULL,
  user_b_id       TEXT NOT NULL,
  -- Matching
  match_score     REAL NOT NULL,                    -- 0-1
  score_breakdown_json TEXT,                        -- {goals: 0.8, tz: 0.9, ...}
  match_type      TEXT NOT NULL DEFAULT 'auto'
                  CHECK (match_type IN ('auto','manual','mutual')),
  -- Status
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','accepted_a','accepted_b','active','declined','expired','completed','dissolved')),
  -- Activity
  messages_count  INTEGER NOT NULL DEFAULT 0,
  shared_sessions INTEGER NOT NULL DEFAULT 0,
  last_active_at  INTEGER,
  -- Feedback
  rating_a_to_b   INTEGER CHECK (rating_a_to_b BETWEEN 1 AND 5),
  rating_b_to_a   INTEGER CHECK (rating_b_to_a BETWEEN 1 AND 5),
  -- Meta
  expires_at      INTEGER,                          -- NULL = no expiry
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL,
  UNIQUE (user_a_id, user_b_id)
);
CREATE INDEX idx_matches_user_a ON buddy_matches(user_a_id, status);
CREATE INDEX idx_matches_user_b ON buddy_matches(user_b_id, status);
CREATE INDEX idx_matches_pending ON buddy_matches(status, created_at DESC);
CREATE TABLE buddy_messages (
  id              TEXT PRIMARY KEY,
  match_id        TEXT NOT NULL,
  from_user_id    TEXT NOT NULL,
  content         TEXT NOT NULL,
  content_type    TEXT NOT NULL DEFAULT 'text'
                  CHECK (content_type IN ('text','system','goal','session_link')),
  read_at         INTEGER,
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (match_id) REFERENCES buddy_matches(id) ON DELETE CASCADE
);
CREATE INDEX idx_buddy_msg ON buddy_messages(match_id, created_at DESC);
CREATE TABLE buddy_sessions (
  id              TEXT PRIMARY KEY,
  match_id        TEXT NOT NULL,
  scheduled_at    INTEGER NOT NULL,
  duration_min    INTEGER NOT NULL DEFAULT 60,
  topic           TEXT NOT NULL,
  notes           TEXT,
  status          TEXT NOT NULL DEFAULT 'scheduled'
                  CHECK (status IN ('scheduled','completed','cancelled','no_show')),
  -- Feedback
  rating_a        INTEGER CHECK (rating_a BETWEEN 1 AND 5),
  rating_b        INTEGER CHECK (rating_b BETWEEN 1 AND 5),
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL,
  FOREIGN KEY (match_id) REFERENCES buddy_matches(id) ON DELETE CASCADE
);
CREATE INDEX idx_buddy_sessions ON buddy_sessions(match_id, scheduled_at DESC);
-- Match request queue
CREATE TABLE buddy_match_requests (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  requested_at    INTEGER NOT NULL,
  status          TEXT NOT NULL DEFAULT 'queued'
                  CHECK (status IN ('queued','processing','matched','expired','cancelled')),
  created_at      INTEGER NOT NULL
);
CREATE INDEX idx_match_requests ON buddy_match_requests(status, requested_at);
