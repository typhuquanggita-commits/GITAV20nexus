-- =========================================================
-- TRẠI HUẤN LUYỆN
--   Gel Alpha        — nền nếp học và sức bền tinh thần
--   Leader Boom      — dẫn dắt, nói trước đám đông, làm việc nhóm
--   Kỹ năng học giỏi — phương pháp học, lớp 1 đến 12
--
-- Trại khác lớp học ở một điểm: nó có NGƯỠNG VÀO và NGƯỠNG RA. Ai không
-- qua ngưỡng ra thì không nhận chứng nhận, và hệ thống nói thẳng điều
-- đó thay vì phát cho đủ mặt.
-- =========================================================

CREATE TABLE IF NOT EXISTS trai (
  id           TEXT PRIMARY KEY,          -- 'gel-alpha','leader-boom','hoc-gioi'
  ten          TEXT NOT NULL,
  muc_tieu     TEXT NOT NULL,
  lop_tu       INTEGER NOT NULL CHECK (lop_tu BETWEEN 1 AND 12),
  lop_den      INTEGER NOT NULL CHECK (lop_den BETWEEN 1 AND 12),
  so_ngay      INTEGER NOT NULL,
  so_gio       INTEGER NOT NULL,
  nguong_vao_json TEXT NOT NULL,          -- điều kiện được dự trại
  nguong_ra_json  TEXT NOT NULL,          -- điều kiện nhận chứng nhận
  suc_chua     INTEGER,
  mo_ta        TEXT NOT NULL,
  CHECK (lop_den >= lop_tu)
);

CREATE TABLE IF NOT EXISTS trai_chang (
  id           TEXT PRIMARY KEY,
  trai_id      TEXT NOT NULL,
  thu_tu       INTEGER NOT NULL,
  ten          TEXT NOT NULL,
  so_gio       INTEGER NOT NULL,
  muc_tieu     TEXT NOT NULL,
  hoat_dong_json TEXT NOT NULL DEFAULT '[]',
  do_bang      TEXT NOT NULL,             -- chặng này đo bằng gì
  UNIQUE (trai_id, thu_tu),
  FOREIGN KEY (trai_id) REFERENCES trai(id)
);

CREATE TABLE IF NOT EXISTS trai_khoa (
  id           TEXT PRIMARY KEY,
  trai_id      TEXT NOT NULL,
  ten          TEXT NOT NULL,
  khai_mac     INTEGER NOT NULL,
  be_mac       INTEGER NOT NULL,
  dia_diem     TEXT,
  hinh_thuc    TEXT NOT NULL CHECK (hinh_thuc IN ('truc-tiep','truc-tuyen','ket-hop')),
  suc_chua     INTEGER NOT NULL,
  da_ghi_danh  INTEGER NOT NULL DEFAULT 0,
  trang_thai   TEXT NOT NULL DEFAULT 'mo-ghi-danh'
               CHECK (trang_thai IN ('sap-mo','mo-ghi-danh','dong-ghi-danh','dang-chay','da-xong','huy')),
  created_at   INTEGER NOT NULL,
  FOREIGN KEY (trai_id) REFERENCES trai(id)
);
CREATE INDEX IF NOT EXISTS idx_trai_khoa ON trai_khoa(trai_id, khai_mac DESC);

CREATE TABLE IF NOT EXISTS trai_hoc_vien (
  id           TEXT PRIMARY KEY,
  khoa_id      TEXT NOT NULL,
  user_id      TEXT NOT NULL,
  ghi_danh_luc INTEGER NOT NULL,
  xet_vao_json TEXT,                      -- kết quả xét ngưỡng vào
  trang_thai   TEXT NOT NULL DEFAULT 'cho-xet'
               CHECK (trang_thai IN ('cho-xet','duoc-vao','tu-choi','dang-hoc','hoan-thanh','khong-dat','bo')),
  diem_ra_json TEXT,
  chung_nhan_id TEXT,
  UNIQUE (khoa_id, user_id),
  FOREIGN KEY (khoa_id) REFERENCES trai_khoa(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_trai_hv ON trai_hoc_vien(user_id, ghi_danh_luc DESC);

CREATE TABLE IF NOT EXISTS trai_diem_danh (
  id           TEXT PRIMARY KEY,
  khoa_id      TEXT NOT NULL,
  user_id      TEXT NOT NULL,
  chang_id     TEXT NOT NULL,
  co_mat       INTEGER NOT NULL DEFAULT 0,
  diem         REAL,
  nhan_xet     TEXT,
  at           INTEGER NOT NULL,
  UNIQUE (khoa_id, user_id, chang_id),
  FOREIGN KEY (khoa_id)  REFERENCES trai_khoa(id),
  FOREIGN KEY (chang_id) REFERENCES trai_chang(id)
);
