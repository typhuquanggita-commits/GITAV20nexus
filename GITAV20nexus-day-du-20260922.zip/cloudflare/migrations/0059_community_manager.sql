-- =========================================================
-- V21: COMMUNITY MANAGER — AI tự moderate + engage
-- =========================================================
CREATE TABLE community_channels (
  id              TEXT PRIMARY KEY,
  -- Channel
  platform        TEXT NOT NULL CHECK (platform IN ('telegram','discord','internal')),
  channel_ref     TEXT NOT NULL,                  -- chat_id / channel_id
  name            TEXT NOT NULL,
  -- Purpose
  purpose         TEXT NOT NULL CHECK (purpose IN ('general','support','announcements','study','qa','off_topic')),
  -- AI config
  ai_enabled      INTEGER NOT NULL DEFAULT 1,
  ai_persona      TEXT DEFAULT 'friendly',
  -- Auto-moderation
  mod_level       TEXT NOT NULL DEFAULT 'medium'
                  CHECK (mod_level IN ('off','light','medium','strict')),
  -- Rate limiting
  max_posts_per_hour INTEGER NOT NULL DEFAULT 20,
  -- Stats
  total_messages  INTEGER NOT NULL DEFAULT 0,
  ai_replies      INTEGER NOT NULL DEFAULT 0,
  mod_actions     INTEGER NOT NULL DEFAULT 0,
  -- Meta
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','paused','archived')),
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX idx_comm_channels ON community_channels(platform, channel_ref, status);
CREATE TABLE community_messages (
  id              TEXT PRIMARY KEY,
  channel_id      TEXT NOT NULL,
  platform_msg_id TEXT,
  author_id       TEXT,                            -- Hashed user id
  content         TEXT NOT NULL,
  -- Moderation
  mod_action      TEXT CHECK (mod_action IN ('none','warn','delete','mute','ban','escalate')),
  mod_score       REAL NOT NULL DEFAULT 0,
  mod_labels_json TEXT DEFAULT '[]',
  -- AI engagement
  ai_responded    INTEGER NOT NULL DEFAULT 0,
  ai_response_id  TEXT,
  -- Meta
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (channel_id) REFERENCES community_channels(id) ON DELETE CASCADE
);
CREATE INDEX idx_comm_msgs ON community_messages(channel_id, created_at DESC);
CREATE INDEX idx_comm_flagged ON community_messages(mod_score) WHERE mod_score > 0.6;
-- AI engagement rules
CREATE TABLE community_engagement_rules (
  id              TEXT PRIMARY KEY,
  channel_id      TEXT NOT NULL,
  rule_type       TEXT NOT NULL CHECK (rule_type IN (
    'welcome_new_member','answer_question','celebrate_milestone',
    'daily_tip','weekly_digest','keyword_trigger','react_to_positive'
  )),
  config_json     TEXT NOT NULL,                   -- {trigger, response_template, ...}
  is_active       INTEGER NOT NULL DEFAULT 1,
  trigger_count   INTEGER NOT NULL DEFAULT 0,
  created_at      INTEGER NOT NULL,
  FOREIGN KEY (channel_id) REFERENCES community_channels(id) ON DELETE CASCADE
);
CREATE INDEX idx_comm_rules ON community_engagement_rules(channel_id, is_active);
-- Moderation actions log
CREATE TABLE community_mod_log (
  id              TEXT PRIMARY KEY,
  channel_id      TEXT NOT NULL,
  message_id      TEXT,
  action          TEXT NOT NULL,
  reason          TEXT NOT NULL,
  actor           TEXT NOT NULL CHECK (actor IN ('ai','human')),
  actor_id        TEXT,
  target_user_id  TEXT,
  created_at      INTEGER NOT NULL
);
CREATE INDEX idx_mod_log ON community_mod_log(channel_id, created_at DESC);
