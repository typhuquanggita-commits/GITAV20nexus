'use strict';
/**
 * CHỐNG LỪA ĐẢO
 *
 * Bộ kiểm này dựng KỊCH BẢN TẤN CÔNG THẬT rồi xem hệ thống chặn tới đâu —
 * không kiểm "hàm có chạy không".
 *
 * Năm kịch bản, mỗi cái là một đường vòng có thật mà lừa đảo hay dùng:
 *   1. Kẻ lừa được mật khẩu rồi định khoá chủ nhà ra ngoài
 *   2. Kẻ chiếm được phiên rồi định gắn máy của mình vào
 *   3. Người dùng quét mặt trên một trang giả mạo
 *   4. Có bản sao khoá riêng đang chạy song song
 *   5. Dò hàng loạt tên để biết tài khoản nào có thật
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { Database } = require('../src/data/repository');
const AccountService = require('../src/security/accounts');
const KhuonMat = require('../src/an-toan/khuon-mat');
const ChongLuaDao = require('../src/an-toan/chong-lua-dao');

const MK = 'Trung6Chim9Bay2Xa!';

function moHe() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cld-'));
  const db = new Database({ dir });
  const cld = new ChongLuaDao();
  const acc = new AccountService({
    users: db.collection('users', { indexes: ['role', 'username'] }),
    learners: db.collection('learners', { indexes: [] }),
    classes: db.collection('classes', { indexes: [] }),
    khuonMat: new KhuonMat({ tenMay: 'localhost', cacGoc: ['http://localhost:9999'] }),
    chongLuaDao: cld,
  });
  acc.create({ username: 'co_lan', password: MK, role: 'TEACHER', fullName: 'Cô Lan' });
  return { db, acc, cld };
}

// ── KỊCH BẢN 1: LỪA ĐƯỢC MẬT KHẨU ─────────────────────────────────────────

test('Lừa đảo: có mật khẩu vẫn KHÔNG đổi được mật khẩu — phải quét mặt', () => {
  // Đây là bước đầu của mọi vụ chiếm tài khoản: vào được rồi khoá chủ nhà ra
  // ngoài. Nếu mật khẩu là đủ để đổi mật khẩu thì lừa được mật khẩu là mất
  // tài khoản.
  const { db, acc } = moHe();
  const vao = acc.login({ username: 'co_lan', password: MK, ip: '9.9.9.9' });
  assert.equal(vao.ok, true);
  assert.equal(vao.cachVao, 'mat-khau');

  const doi = acc.doiMatKhauCoCanh(vao.token, MK, 'Nui7Song8Bien4Rong!');
  assert.equal(doi.ok, false);
  assert.equal(doi.error, 'CAN_XAC_THUC_LAI');
  assert.ok(doi.canGi.includes('Quét khuôn mặt'), 'phải nói rõ cần làm gì');
  assert.ok(doi.vi.includes('khoá chủ nhà ra ngoài'), 'phải nói rõ vì sao nguy hiểm');
  db.close();
});

test('Lừa đảo: vào bằng KHUÔN MẶT thì đổi mật khẩu được ngay — không làm phiền người thật', () => {
  // Chặn kẻ tấn công mà làm phiền người thật thì người thật sẽ tìm cách đi
  // vòng, và lúc ấy lớp bảo vệ mất tác dụng.
  const { db, acc, cld } = moHe();
  const vao = acc.login({ username: 'co_lan', password: MK });
  cld.ghiXacThucLai(vao.token, { bangKhuonMat: true });
  const doi = acc.doiMatKhauCoCanh(vao.token, MK, 'Nui7Song8Bien4Rong!');
  assert.equal(doi.ok, true, doi.error || '');
  db.close();
});

test('Lừa đảo: gõ lại mật khẩu KHÔNG tính là xác thực lại', () => {
  // Kẻ đã chiếm được phiên thường cũng đã có mật khẩu. Bắt gõ lại mật khẩu
  // chỉ làm phiền người thật mà không chặn được ai.
  const { db, cld } = moHe();
  const r = cld.ghiXacThucLai('ve-nao-do', { bangKhuonMat: false });
  assert.equal(r.ok, false);
  assert.equal(r.loi, 'PHAI_XAC_THUC_BANG_KHUON_MAT');
  db.close();
});

test('Lừa đảo: vé xác thực lại hết hạn sau năm phút', () => {
  let gio = 1_000_000;
  const cld = new ChongLuaDao({ bayGio: () => gio });
  cld.ghiXacThucLai('t', { bangKhuonMat: true });
  assert.equal(cld.choLamViec('t', 'doi-mat-khau').cho, true);
  gio += 5 * 60_000 + 1;
  assert.equal(cld.choLamViec('t', 'doi-mat-khau').cho, false);
});

test('Lừa đảo: đăng xuất thì vé xác thực lại chết theo', () => {
  const { db, acc, cld } = moHe();
  const vao = acc.login({ username: 'co_lan', password: MK });
  cld.ghiXacThucLai(vao.token, { bangKhuonMat: true });
  assert.equal(cld.choLamViec(vao.token, 'doi-mat-khau').cho, true);
  acc.logout(vao.token);
  assert.equal(cld.choLamViec(vao.token, 'doi-mat-khau').cho, false, 'vé sống sót qua lần đăng xuất');
  db.close();
});

// ── KỊCH BẢN 2: CHIẾM PHIÊN RỒI GẮN MÁY CỦA MÌNH ──────────────────────────

test('Lừa đảo: chiếm được phiên vẫn KHÔNG gắn hay gỡ được máy', () => {
  // Gắn máy lạ là mở một cửa sau vĩnh viễn; gỡ hết máy của chủ nhà là bước
  // chuẩn bị chiếm tài khoản.
  const { db, acc } = moHe();
  const vao = acc.login({ username: 'co_lan', password: MK });
  const gan = acc.ghiKhuonMat(vao.token, { thachThuc: 'x', id: 'y', clientDataJSON: 'z', attestationObject: 'w' });
  assert.equal(gan.error, 'CAN_XAC_THUC_LAI');
  const go = acc.goKhuonMat(vao.token, 'ma-nao-do');
  assert.equal(go.error, 'CAN_XAC_THUC_LAI');
  db.close();
});

// ── KỊCH BẢN 3: TRANG GIẢ MẠO ─────────────────────────────────────────────

test('Lừa đảo: chữ ký ký trên trang giả KHÔNG dùng được ở trang thật', () => {
  // Đây là điều mật khẩu không bao giờ làm được. Người dùng không cần tinh ý,
  // không cần nhìn thanh địa chỉ — chữ ký gắn chặt vào gốc, và máy chủ thật
  // thấy gốc sai thì từ chối.
  const may = new KhuonMat({ tenMay: 'localhost', cacGoc: ['http://localhost:9999'] });
  const { thachThuc } = may.tuyChonDangNhap();
  const cd = Buffer.from(JSON.stringify({
    type: 'webauthn.get', challenge: thachThuc, origin: 'http://gitamath-that.vn',
  }), 'utf8').toString('base64url');
  const r = may.kiemDangNhap({
    thachThuc, clientDataJSON: cd, authenticatorData: 'AA', signature: 'AA',
    khoaDaLuu: { khoaCong: 'x' },
  });
  assert.equal(r.ok, false);
  assert.ok(r.loi.includes('Gốc') || r.loi.includes('gốc'), r.loi);
});

test('Lừa đảo: gốc sai ghi thành dấu hiệu NẶNG kèm việc phải làm', () => {
  const cld = new ChongLuaDao();
  const d = cld.ghiDauHieu('GOC_SAI', { nguoiDungId: 'U1', chiTiet: 'gitamath-that.vn' });
  assert.equal(d.nang, 3, 'gốc sai là dấu vết trực tiếp của trang giả mạo — phải là mức nặng nhất');
  assert.ok(d.lam.includes('Liên hệ người dùng'), 'phải nói rõ việc cần làm');
  const t = cld.tinhHinh();
  assert.equal(t.nang.length, 1);
  assert.ok(t.canLamNgay.length > 0, 'dấu hiệu nặng phải sinh ra việc làm ngay');
});

// ── KỊCH BẢN 4: BẢN SAO KHOÁ ──────────────────────────────────────────────

test('Lừa đảo: bộ đếm không tăng sinh dấu hiệu nặng', () => {
  const cld = new ChongLuaDao();
  const d = cld.ghiDauHieu('BAN_SAO_KHOA', { nguoiDungId: 'U1' });
  assert.equal(d.nang, 3);
  assert.ok(d.vi.includes('hai bản đang chạy'));
});

// ── KỊCH BẢN 5: DÒ TÀI KHOẢN ──────────────────────────────────────────────

test('Lừa đảo: thử nhiều TÊN từ một nguồn bị bắt; sai mật khẩu một tên thì không', () => {
  // Một người gõ sai mật khẩu mười lần vẫn chỉ là một tên. Thử mười tên khác
  // nhau mới là dò. Đếm nhầm chỗ này là báo oan người dùng thật.
  const cld = new ChongLuaDao();
  for (let i = 0; i < 10; i++) {
    assert.equal(cld.ghiThuTen('1.1.1.1|ChromeA', 'co_lan'), null, 'cùng một tên không được tính là dò');
  }
  let bat = null;
  for (const t of ['a', 'b', 'c', 'd', 'e']) bat = cld.ghiThuTen('2.2.2.2|ChromeB', t) || bat;
  assert.ok(bat, 'thử năm tên khác nhau mà không bắt được');
  assert.equal(bat.ma, 'DO_TAI_KHOAN');
});

test('Lừa đảo: câu trả lời cho tài khoản CÓ và KHÔNG CÓ là giống hệt nhau', () => {
  // Khác nhau một chữ là cho người lạ một cách dò xem ai có tài khoản ở đây.
  const { db, acc } = moHe();
  const co = acc.xinDangNhapKhuonMat({ username: 'co_lan' });
  const khong = acc.xinDangNhapKhuonMat({ username: 'khong_co_nguoi_nay' });
  assert.equal(co.ok, khong.ok);
  assert.deepEqual(co.tuyChon.allowCredentials, khong.tuyChon.allowCredentials);
  assert.deepEqual(Object.keys(co).sort(), Object.keys(khong).sort());
  db.close();
});

// ── MÁY ĐÃ BIẾT ───────────────────────────────────────────────────────────

test('Lừa đảo: máy đầu tiên KHÔNG phải máy lạ, máy thứ hai thì có', () => {
  // Báo động ngay lần đăng nhập đầu là báo oan mọi người dùng mới.
  const { db, acc } = moHe();
  const a = acc.login({ username: 'co_lan', password: MK, ip: '1.1.1.1', userAgent: 'ChromeA' });
  assert.equal(a.mayLa, false, 'máy đầu tiên bị coi là lạ — báo oan người dùng mới');
  const b = acc.login({ username: 'co_lan', password: MK, ip: '2.2.2.2', userAgent: 'ChromeB' });
  assert.equal(b.mayLa, true, 'máy thứ hai không bị nhận ra là lạ');
  const lai = acc.login({ username: 'co_lan', password: MK, ip: '1.1.1.1', userAgent: 'ChromeA' });
  assert.equal(lai.mayLa, false, 'máy quen lại bị coi là lạ');
  db.close();
});

test('Lừa đảo: KHÔNG giữ nguyên bản địa chỉ mạng hay chuỗi trình duyệt', () => {
  // Giữ nguyên bản là dựng lại được thói quen đi lại của một đứa trẻ. Băm lại
  // thì đủ nhận ra lần sau, không đủ để theo dõi ai.
  const { db, acc, cld } = moHe();
  acc.login({ username: 'co_lan', password: MK, ip: '203.0.113.42', userAgent: 'Mozilla/5.0 ChromeX' });
  const u = acc.users.find((x) => x.username === 'co_lan');
  const chuoi = JSON.stringify(cld.dsMay(u.id));
  assert.ok(!chuoi.includes('203.0.113.42'), 'địa chỉ mạng bị giữ nguyên bản');
  assert.ok(!chuoi.includes('ChromeX'), 'chuỗi trình duyệt bị giữ nguyên bản');
  db.close();
});

// ── BẢNG DẤU HIỆU ─────────────────────────────────────────────────────────

test('Lừa đảo: mọi dấu hiệu đều nói được VÌ SAO và VIỆC PHẢI LÀM', () => {
  // Một hệ chặn người mà không nói được vì sao thì người bị chặn oan không có
  // đường nào kêu.
  for (const [ma, d] of Object.entries(ChongLuaDao.DAU_HIEU)) {
    assert.ok(d.ten && d.ten.length > 10, `${ma}: thiếu tên đọc được`);
    assert.ok(d.vi && d.vi.length > 30, `${ma}: thiếu câu nói vì sao đáng ngờ`);
    assert.ok(d.lam && d.lam.length > 15, `${ma}: thiếu việc phải làm`);
    assert.ok([1, 2, 3].includes(d.nang), `${ma}: mức nặng phải là 1, 2 hoặc 3`);
  }
  for (const [ma, v] of Object.entries(ChongLuaDao.VIEC_NGUY_HIEM)) {
    assert.ok(v.ten && v.vi && v.vi.length > 20, `${ma}: việc nguy hiểm phải nói rõ vì sao`);
  }
});

test('Lừa đảo: dấu hiệu chưa khai trong bảng thì KHÔNG ghi được', () => {
  const cld = new ChongLuaDao();
  assert.throws(() => cld.ghiDauHieu('MOT_DAU_HIEU_CHUA_KHAI'), /chưa khai/);
});

test('Lừa đảo: KHÔNG chấm một "điểm an toàn" tổng hợp', () => {
  // Một con số như vậy nghe gọn nhưng không ai hành động được theo nó, và khi
  // nó xuống thì không ai biết phải sửa gì.
  const cld = new ChongLuaDao();
  cld.ghiDauHieu('MAY_LA', { nguoiDungId: 'U' });
  const t = cld.tinhHinh();
  const chuoi = JSON.stringify(t).toLowerCase();
  for (const cam of ['diemantoan', 'diemtincay', 'riskscore', 'trustscore']) {
    assert.ok(!chuoi.includes(cam), `có "${cam}" — một con số không ai hành động được theo`);
  }
  assert.ok(Array.isArray(t.canLamNgay), 'phải trả về việc làm, không phải một con số');
});
