'use strict';
/**
 * Sản xuất phim — kiểm theo đúng thứ tự dữ liệu chạy qua: đọc kịch bản →
 * hồ sơ nhân vật → phân cảnh → dự toán → soát → bản nháp.
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const { docKichBan } = require('../src/film/screenplay');
const { dungHoSo, soatKhoa, nhacToi, rutNetNgoaiHinh } = require('../src/film/characters');
const { phanCanhQuay, doThoiLuongThoai, catCanhQuay, GIAY_TOI_DA } = require('../src/film/shots');
const { chonModel, duToan, soSanhUuTien, MODEL } = require('../src/film/models');
const { soat } = require('../src/film/qc');
const { veKhung, veBang } = require('../src/film/storyboard');
const A = require('../src/film/assemble');
const { CongVideo } = require('../src/film/providers');
const { FilmService } = require('../src/film/service');
const { VoiceService } = require('../src/voice/service');
const { buildRoster } = require('../src/agents/roster');

const KICH_BAN = fs.readFileSync(path.join(__dirname, '..', 'kich-ban-mau', 'nguoi-thay-cuoi-cung.txt'), 'utf8');

// ── 1. ĐỌC KỊCH BẢN ────────────────────────────────────────────────────────

test('đọc kịch bản ra đúng cảnh, nhân vật và lời thoại — không cần mô hình nào', () => {
  const r = docKichBan(KICH_BAN);
  assert.equal(r.ok, true);
  assert.equal(r.tieuDe, 'Người Thầy Cuối Cùng');
  assert.equal(r.theLoai, 'Chính kịch ngắn');
  assert.equal(r.canh.length, 3);
  assert.equal(r.nhanVat.length, 2);

  const thay = r.nhanVat.find((n) => n.ten === 'THẦY GIÁO');
  assert.ok(thay, 'phải nhận ra THẦY GIÁO');
  assert.equal(thay.soLuotThoai, 4);
  assert.ok(thay.huongDan.includes('lẩm bẩm'));

  assert.equal(r.canh[0].noiQuay.code, 'INT');
  assert.equal(r.canh[0].diaDiem, 'LỚP HỌC CŨ');
  assert.equal(r.canh[0].thoiDiem.name, 'Chiều muộn');
  assert.equal(r.canh[2].noiQuay.code, 'EXT');
  assert.equal(r.canh[2].thoiDiem.name, 'Buổi trưa');
});

test('đọc kịch bản là TẤT ĐỊNH — chạy mười lần ra một kết quả', () => {
  const a = JSON.stringify(docKichBan(KICH_BAN));
  for (let i = 0; i < 9; i++) assert.equal(JSON.stringify(docKichBan(KICH_BAN)), a);
});

test('lời thoại được giữ nguyên văn, không bị sửa cho "mượt"', () => {
  const r = docKichBan(KICH_BAN);
  const loi = r.canh.flatMap((c) => c.khoi.filter((k) => k.kind === 'thoai').map((k) => k.loi));
  assert.ok(loi.includes('Ba mươi năm rồi, ngày mai là ngày cuối cùng.'));
  assert.ok(loi.includes('Thầy không buồn. Vì thầy biết các em sẽ tiếp tục học.'));
  for (const l of loi) assert.ok(!l.startsWith('"') && !l.endsWith('"'), `còn dấu ngoặc kép: ${l}`);
});

test('kịch bản hỏng bị báo lỗi rõ ràng chứ không đoán bừa', () => {
  assert.equal(docKichBan('').error, 'KỊCH_BẢN_RỖNG');
  assert.equal(docKichBan('   ').error, 'KỊCH_BẢN_RỖNG');
  const khongCanh = docKichBan('TIÊU ĐỀ: X\nMột đoạn văn xuôi không có cảnh nào.');
  assert.equal(khongCanh.ok, true, 'có nội dung thì gom vào cảnh mở đầu');
  assert.ok(khongCanh.canhBao.some((c) => c.loai === 'THIẾU_TIÊU_ĐỀ_CẢNH'));
});

test('câu mô tả có dấu hai chấm không bị nhầm thành lời thoại', () => {
  const r = docKichBan('CẢNH 1 - INT. PHÒNG - NGÀY\nTrên tường có dòng chữ: Học, học nữa, học mãi.\nHẾT');
  assert.equal(r.nhanVat.length, 0, 'không được sinh ra nhân vật giả');
  assert.equal(r.canh[0].khoi[0].kind, 'hanhDong');
});

// ── 2. HỒ SƠ NHÂN VẬT ──────────────────────────────────────────────────────

test('rút đúng nét ngoại hình có trong kịch bản, mỗi nhóm một nét', () => {
  const net = rutNetNgoaiHinh('ông giáo già, tóc bạc, đeo kính gọng vàng, mặc áo sơ mi trắng đã ngả màu');
  const vi = net.map((n) => n.vi);
  assert.ok(vi.includes('tóc bạc'));
  assert.ok(vi.includes('kính gọng vàng'));
  assert.ok(!vi.includes('đeo kính'), 'nét cụ thể đã có thì không thêm nét chung');
  assert.ok(vi.includes('áo sơ mi trắng'));
});

test('hồ sơ nhân vật lấy được tuổi, giới và khoá ngoại hình ổn định', () => {
  const kb = docKichBan(KICH_BAN);
  const h = dungHoSo(kb);
  const thay = h.nhanVat.find((n) => n.ten === 'THẦY GIÁO');
  const be = h.nhanVat.find((n) => n.ten === 'CÔ BÉ');

  assert.equal(thay.tuoi, 60);
  assert.equal(thay.gioiTinh, 'nam');
  assert.ok(thay.khoaNgoaiHinh.includes('silver grey hair'));
  assert.ok(thay.khoaNgoaiHinh.includes('gold-rimmed glasses'));
  assert.equal(be.tuoi, 10);
  assert.equal(be.gioiTinh, 'nữ');
  assert.ok(be.khoaNgoaiHinh.includes('twin braids'));

  assert.equal(h.canhBao.length, 0, 'kịch bản mẫu tả đủ nên không được cảnh báo');
  assert.equal(thay.anhThamChieu.length, 4);
  for (const a of thay.anhThamChieu) assert.ok(a.prompt.includes(thay.khoaNgoaiHinh));

  // Khoá phải tất định
  const lai = dungHoSo(docKichBan(KICH_BAN));
  assert.equal(lai.nhanVat[0].maKhoa, h.nhanVat[0].maKhoa);
});

test('nhân vật bị tả sơ sài thì bị cảnh báo, không im lặng cho qua', () => {
  const h = dungHoSo(docKichBan('CẢNH 1 - INT. PHÒNG - NGÀY\nMột người bước vào.\nNGƯỜI LẠ: "Xin chào."\nHẾT'));
  assert.ok(h.canhBao.some((c) => c.loai === 'THIẾU_MÔ_TẢ_NGOẠI_HÌNH'));
});

test('đoạn tả căn phòng không bị gán nhầm cho nhân vật', () => {
  const kb = docKichBan(KICH_BAN);
  const h = dungHoSo(kb);
  const taPhong = 'Một lớp học cũ ở vùng quê, ánh nắng chiều vàng vọt qua cửa sổ. Bàn ghế gỗ cũ kỹ, bảng đen đã phai.';
  assert.deepEqual(nhacToi(taPhong, h.nhanVat), [], 'toàn cảnh lớp trống không được gắn nhân vật nào');
  const taThay = 'Một ông giáo già, khoảng 60 tuổi, tóc bạc, đeo kính gọng vàng, mặc áo sơ mi trắng đã ngả màu, khuôn mặt nhiều nếp nhăn. Ông đang lau bảng.';
  assert.deepEqual(nhacToi(taThay, h.nhanVat), ['nv-thay-giao']);
});

// ── 3. PHÂN CẢNH & ĐO THỜI LƯỢNG THOẠI ─────────────────────────────────────

test('thời lượng lời thoại được ĐO, không ước theo số chữ', () => {
  const ngan = doThoiLuongThoai('Chào em.');
  const dai = doThoiLuongThoai('Các em nhớ nhé, học không phải để thoát khỏi quê hương, mà để mang quê hương đi xa hơn.');
  assert.ok(ngan.ms > 300 && ngan.ms < 2000, `câu ngắn: ${ngan.ms}ms`);
  assert.ok(dai.ms > 4000, `câu dài phải trên 4 giây, đo được ${dai.ms}ms`);
  assert.ok(dai.syllables >= 20, `đếm âm tiết: ${dai.syllables}`);
  assert.equal(dai.unknown.length, 0);
  // Đo lại phải ra đúng con số cũ
  assert.equal(doThoiLuongThoai('Chào em.').ms, ngan.ms);
});

test('cảnh quay có thoại dài đúng bằng thời gian đọc cộng khoảng đệm', () => {
  const kb = docKichBan(KICH_BAN);
  const h = dungHoSo(kb);
  const pc = phanCanhQuay(kb, h.nhanVat, {});
  for (const c of pc.canhQuay) {
    if (!c.thoai) continue;
    assert.ok(c.giay >= c.doThoai.giay, `${c.id}: cảnh ${c.giay}s ngắn hơn lời thoại ${c.doThoai.giay}s`);
    assert.ok(c.giay - c.doThoai.giay >= 1.0, `${c.id}: thiếu khoảng đệm quanh lời thoại`);
  }
  assert.ok(pc.soCanhQuay >= 8);
  assert.ok(pc.tongGiay > 30);
});

test('mọi prompt đều mang khoá ngoại hình của đúng nhân vật trong cảnh', () => {
  const kb = docKichBan(KICH_BAN);
  const h = dungHoSo(kb);
  const pc = phanCanhQuay(kb, h.nhanVat, {});
  for (const c of pc.canhQuay) {
    const r = soatKhoa(c.prompt, c.nhanVat, h.nhanVat);
    assert.equal(r.ok, true, `${c.id} thiếu khoá: ${JSON.stringify(r.thieu)}`);
    assert.ok(/cinematic|photorealistic/.test(c.prompt), `${c.id}: prompt thiếu phần phong cách`);
  }
});

test('người nói liền mấy câu thì đổi cỡ cảnh, không lặp hình', () => {
  const kb = docKichBan('CẢNH 1 - INT. PHÒNG - NGÀY\nMột ông già tóc bạc, đeo kính, áo sơ mi trắng.\nÔNG GIÀ: "Câu một."\nÔNG GIÀ: "Câu hai."\nÔNG GIÀ: "Câu ba."\nHẾT');
  const h = dungHoSo(kb);
  const pc = phanCanhQuay(kb, h.nhanVat, {});
  const thoai = pc.canhQuay.filter((c) => c.thoai);
  assert.equal(thoai.length, 3);
  assert.equal(new Set(thoai.map((c) => c.co)).size, 3, 'ba câu liền phải ba cỡ cảnh khác nhau');
  assert.equal(new Set(thoai.map((c) => c.prompt)).size, 3, 'prompt không được trùng nhau');
});

test('cảnh quá dài được cắt thành nhiều cảnh nối tiếp', () => {
  const goc = { id: 'q1', giay: 30, co: 'can-canh', moTaViet: 'x', prompt: 'p', nhanVat: [], thoai: null };
  const ra = catCanhQuay(goc, 10);
  assert.equal(ra.length, 3);
  assert.ok(Math.abs(ra.reduce((a, c) => a + c.giay, 0) - 30) < 0.5);
  assert.equal(new Set(ra.map((c) => c.id)).size, 3);
  for (const c of ra) assert.equal(c.catTu, 'q1');
});

// ── 4. CHỌN MÔ HÌNH & DỰ TOÁN ──────────────────────────────────────────────

test('chọn mô hình theo nhu cầu thật của cảnh, và nói rõ vì sao', () => {
  const coNguoi = chonModel({ id: 'a', giay: 6, co: 'can-canh', nhanVat: ['nv1'], thoai: 'xin chào', chuyenDong: 'tinh' }, { uuTien: 'can-bang' });
  assert.equal(coNguoi.ok, true);
  assert.ok(coNguoi.vi.includes('khuôn mặt'), coNguoi.vi);

  const lia = chonModel({ id: 'b', giay: 6, co: 'toan-canh', nhanVat: [], thoai: null, chuyenDong: 'lia' }, { uuTien: 'chat-luong' });
  assert.equal(lia.ok, true);

  // Cảnh dài hơn mọi mô hình thì phải báo, không chọn liều
  const qua = chonModel({ id: 'c', giay: 90, co: 'toan-canh', nhanVat: [], thoai: null }, {});
  assert.equal(qua.ok, false);
  assert.equal(qua.error, 'KHÔNG_MÔ_HÌNH_NÀO_DỰNG_ĐƯỢC');
  assert.ok(qua.goi.includes('Sora'));
});

test('ưu tiên tiết kiệm phải rẻ hơn ưu tiên chất lượng', () => {
  const kb = docKichBan(KICH_BAN);
  const h = dungHoSo(kb);
  const pc = phanCanhQuay(kb, h.nhanVat, {});
  const ss = soSanhUuTien(pc.canhQuay);
  const cl = ss.find((x) => x.uuTien === 'chat-luong');
  const tk = ss.find((x) => x.uuTien === 'tiet-kiem');
  assert.ok(tk.usd <= cl.usd, `tiết kiệm $${tk.usd} phải ≤ chất lượng $${cl.usd}`);
  assert.ok(cl.usd > 0);
});

test('dự toán cộng đúng theo giá niêm yết của từng mô hình', () => {
  const cq = [
    { id: 'a', giay: 5, co: 'can-canh', nhanVat: ['x'], thoai: 'a', chuyenDong: 'tinh' },
    { id: 'b', giay: 10, co: 'can-canh', nhanVat: ['x'], thoai: 'b', chuyenDong: 'tinh' },
  ];
  const d = duToan(cq, { uuTien: 'can-bang' });
  assert.equal(d.ok, true);
  assert.equal(d.giay, 15);
  const tinhTay = d.theoModel.reduce((a, m) => a + m.gia, 0);
  assert.ok(Math.abs(d.usd - tinhTay) < 0.01, 'tổng phải bằng tổng từng mô hình');
  const m = MODEL[chonModel(cq[0], { uuTien: 'can-bang' }).model.id];
  assert.ok(m.giaMoi5Giay > 0);
});

// ── 5. SOÁT CHẤT LƯỢNG ─────────────────────────────────────────────────────

test('soát bắt được lời thoại dài hơn cảnh quay — trước khi tiêu tiền', () => {
  const kb = docKichBan(KICH_BAN);
  const h = dungHoSo(kb);
  const pc = phanCanhQuay(kb, h.nhanVat, {});
  const sach = soat({ kichBan: kb, hoSoNhanVat: h.nhanVat, canhQuay: pc.canhQuay });
  assert.equal(sach.ok, true, `kịch bản mẫu phải sạch: ${JSON.stringify(sach.loi.slice(0, 2))}`);
  assert.equal(sach.diem, 100);

  // Ép một cảnh thoại ngắn lại → phải bị chặn
  const hong = pc.canhQuay.map((c) => (c.thoai ? { ...c, giay: 2.5 } : c));
  const r = soat({ kichBan: kb, hoSoNhanVat: h.nhanVat, canhQuay: hong });
  assert.equal(r.ok, false);
  assert.ok(r.loi.some((l) => l.loai === 'THOẠI_TRÀN_KHỎI_CẢNH'));
  assert.ok(r.loi.some((l) => l.loai === 'CẢNH_QUÁ_NGẮN'));
  assert.ok(r.ketLuan.includes('KHÔNG được dựng'));
});

test('soát bắt được prompt mất khoá ngoại hình', () => {
  const kb = docKichBan(KICH_BAN);
  const h = dungHoSo(kb);
  const pc = phanCanhQuay(kb, h.nhanVat, {});
  const hong = pc.canhQuay.map((c) => (c.nhanVat.length ? { ...c, prompt: 'close-up of a person' } : c));
  const r = soat({ kichBan: kb, hoSoNhanVat: h.nhanVat, canhQuay: hong });
  assert.equal(r.ok, false);
  assert.ok(r.loi.some((l) => l.loai === 'PROMPT_THIẾU_KHOÁ_NGOẠI_HÌNH'));
});

test('soát chặn khi vượt ngân sách và khi cảnh vượt thời lượng mô hình', () => {
  const kb = docKichBan(KICH_BAN);
  const h = dungHoSo(kb);
  const pc = phanCanhQuay(kb, h.nhanVat, {});
  const d = duToan(pc.canhQuay, { uuTien: 'can-bang' });
  const r = soat({ kichBan: kb, hoSoNhanVat: h.nhanVat, canhQuay: pc.canhQuay, duToan: d, nganSachUsd: 0.5 });
  assert.equal(r.ok, false);
  assert.ok(r.loi.some((l) => l.loai === 'VƯỢT_NGÂN_SÁCH'));

  const qua = [{ ...pc.canhQuay[0], giay: 30, model: 'pika' }];
  const r2 = soat({ kichBan: kb, hoSoNhanVat: h.nhanVat, canhQuay: qua });
  assert.ok(r2.loi.some((l) => l.loai === 'VƯỢT_THỜI_LƯỢNG_MÔ_HÌNH'));
});

// ── 6. BẢNG PHÂN CẢNH & DỰNG ───────────────────────────────────────────────

test('vẽ được khung phân cảnh hợp lệ cho mọi cảnh quay', () => {
  const kb = docKichBan(KICH_BAN);
  const h = dungHoSo(kb);
  const pc = phanCanhQuay(kb, h.nhanVat, {});
  const bang = veBang(pc.canhQuay, h.nhanVat);
  assert.equal(bang.length, pc.canhQuay.length);
  for (const b of bang) {
    assert.ok(b.svg.startsWith('<svg'), `${b.id} không phải SVG`);
    assert.ok(b.svg.trim().endsWith('</svg>'));
    assert.ok(!/undefined|NaN/.test(b.svg), `${b.id} có giá trị hỏng trong SVG`);
  }
  // Cảnh có lời thoại phải hiện lời trên khung
  const coThoai = pc.canhQuay.findIndex((c) => c.thoai);
  assert.ok(bang[coThoai].svg.includes('“'), 'khung của cảnh thoại phải in lời thoại');
});

test('mốc thời gian và EDL khớp nhau tới từng cảnh', () => {
  const kb = docKichBan(KICH_BAN);
  const h = dungHoSo(kb);
  const pc = phanCanhQuay(kb, h.nhanVat, {});
  const moc = A.dungMocThoiGian(pc.canhQuay);
  assert.equal(moc[0].batDau, 0);
  for (let i = 1; i < moc.length; i++) {
    assert.equal(moc[i].batDau, moc[i - 1].ketThuc, `cảnh ${moc[i].id} không nối liền cảnh trước`);
  }
  const edl = A.dungEDL(pc.canhQuay, { tieuDe: 'X' });
  assert.ok(edl.startsWith('TITLE: X'));
  for (const c of pc.canhQuay) assert.ok(edl.includes(`${c.id}.mp4`), `EDL thiếu ${c.id}`);
  assert.equal(A.timecode(0), '00:00:00:00');
  assert.equal(A.timecode(65.5), '00:01:05:12', 'khung hình phải cắt chứ không làm tròn');
});

test('kịch bản ffmpeg sinh ra có chặn khi thiếu clip', () => {
  const kb = docKichBan(KICH_BAN);
  const h = dungHoSo(kb);
  const pc = phanCanhQuay(kb, h.nhanVat, {});
  const g = A.dungKichBanGhep(pc.canhQuay, { tenPhim: 'thu' });
  assert.equal(g.concat.split('\n').length, pc.canhQuay.length);
  assert.ok(g.sh.includes('command -v ffmpeg'), 'phải kiểm tra ffmpeg trước');
  assert.ok(g.sh.includes('Thiếu clip'), 'phải dừng khi thiếu clip');
  assert.ok(g.sh.includes('duong-tieng.wav'), 'phải ghép đường tiếng');
});

// ── 7. CHỐT CHI TIÊU ───────────────────────────────────────────────────────

test('không có khoá thì không gọi API, và nói rõ vẫn dựng được bản nháp', () => {
  const c = new CongVideo();
  const t = c.trangThai();
  assert.equal(t.nhap.sanSang, true);
  assert.equal(t.that.sanSang, false);
  assert.equal(t.that.ly, 'THIẾU_KHOÁ');
  const chot = c.chotChiTieu({ duToan: { usd: 3 } });
  assert.equal(chot.ok, false);
  assert.equal(chot.error, 'CHƯA_CÓ_CỔNG_DỰNG_VIDEO');
  assert.ok(chot.goi.includes('bản nháp'));
});

test('bảng phân cảnh dựng được mọi cảnh mà không tốn đồng nào', async () => {
  const kb = docKichBan(KICH_BAN);
  const h = dungHoSo(kb);
  const pc = phanCanhQuay(kb, h.nhanVat, {});
  const c = new CongVideo();
  const r = await c.nhap.dung(pc.canhQuay[0], { hoSoNhanVat: h.nhanVat });
  assert.equal(r.ok, true);
  assert.equal(r.usd, 0);
  assert.equal(r.loai, 'svg');
  assert.equal(c.nhap.tinhTien, false);
});

// ── 8. TRỌN VÒNG QUA DỊCH VỤ ───────────────────────────────────────────────

test('trọn vòng: chuẩn bị → bản nháp có tiếng thật → chặn dựng thật', async () => {
  const { agents } = buildRoster();
  const voice = new VoiceService({ agents });
  const film = new FilmService({ voice });

  const p = film.chuanBi(KICH_BAN, { uuTien: 'can-bang' });
  assert.equal(p.ok, true);
  assert.equal(p.trangThai, 'SẴN_SÀNG_DỰNG');
  assert.equal(p.qc.ok, true);
  assert.ok(p.canhQuay >= 8);
  assert.ok(p.duToan.usd > 0);
  assert.equal(p.soSanhGia.length, 3);

  const n = await film.dungNhap(p.duAn);
  assert.equal(n.ok, true);
  assert.equal(n.khung, p.canhQuay);
  assert.ok(n.tiengGiay > 30, `đường tiếng quá ngắn: ${n.tiengGiay}s`);
  assert.equal(n.cauThoai, 5);
  assert.equal(n.duongTiengWav.toString('ascii', 0, 4), 'RIFF');
  assert.ok(Math.abs(n.doVang - (-14)) < 1.5, `độ vang đường tiếng: ${n.doVang}`);
  assert.ok(n.phimNhapHtml.includes('<audio'), 'phim nháp phải nhúng đường tiếng');
  assert.ok(n.phimNhapHtml.includes('do máy tổng hợp'), 'phải công bố nội dung AI');
  // Mỗi nhân vật một giọng riêng, đúng giới
  const g = n.giongNoi;
  assert.equal(g.length, 2);
  assert.equal(new Set(g.map((x) => x.voiceId)).size, 2);

  const t = await film.dungThat(p.duAn, {});
  assert.equal(t.ok, false);
  assert.equal(t.error, 'CHƯA_CÓ_CỔNG_DỰNG_VIDEO');

  const ds = film.danhSach();
  assert.equal(ds.tong, 1);
  assert.equal(ds.items[0].coBanNhap, true);
  assert.equal(film.layDuAn('PHIM-KHONG-CO').ok, false);
});

test('soát chưa đạt thì không cho dựng thật, kể cả khi đã xác nhận', async () => {
  const { agents } = buildRoster();
  const film = new FilmService({ voice: new VoiceService({ agents }) });
  // Ngân sách 0,5 đô cho cả phim là lỗi CHẶN thật, không phải lỗi dựng ra.
  const p = film.chuanBi(KICH_BAN, { nganSachUsd: 0.5 });
  assert.equal(p.ok, true);
  assert.equal(p.qc.ok, false);
  assert.equal(p.trangThai, 'CẦN_SỬA');
  assert.ok(p.qc.loi.some((l) => l.loai === 'VƯỢT_NGÂN_SÁCH'));

  const t = await film.dungThat(p.duAn, { xacNhan: true });
  assert.equal(t.ok, false);
  assert.equal(t.error, 'CHƯA_QUA_SOÁT_CHẤT_LƯỢNG');
  assert.ok(t.goi.includes('đốt tiền'));
});

test('phim quá dài bị chặn ngay ở khâu chuẩn bị', () => {
  const { agents } = buildRoster();
  const film = new FilmService({ voice: new VoiceService({ agents }) });
  const canh = Array.from({ length: 140 }, (_, i) =>
    `CẢNH ${i + 1} - INT. PHÒNG - NGÀY\nMột người đàn ông tóc đen, áo sơ mi trắng đứng im rất lâu và suy nghĩ về nhiều thứ khác nhau.`).join('\n\n');
  const p = film.chuanBi(canh);
  assert.equal(p.ok, false);
  assert.equal(p.error, 'PHIM_QUÁ_DÀI');
  assert.ok(p.giay > p.tranGiay);
});
