'use strict';
/** Miền GITAV20nexus: chương trình, kho bài, bộ não 600 trợ lý, hiến pháp. */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const { dungMoi, dongHoGia, yeuCau, doc } = require('../cloudflare/kiem-thu/gia-lap.js');
const { xuLy } = require('../cloudflare/nguon/goc.js');
const { Kho } = require('../cloudflare/nguon/_lib/kho.js');
const phien = require('../cloudflare/nguon/_lib/phien.js');
const { maMoi } = require('../cloudflare/nguon/_lib/ma.js');
const gieoVu = require('../cloudflare/nguon/_lib/gieo.js');
const tc = require('../cloudflare/nguon/_lib/to-chuc.js');
const hp = require('../cloudflare/nguon/_lib/hien-phap.js');

const goi = (moi, cach, duong, tc2, dh) => xuLy(yeuCau(cach, duong, tc2), moi, {}, dh);

async function nguoi(moi, dh, vai, email) {
  const kho = Kho(moi.DB);
  const id = maMoi();
  await kho.chen('users', { id, email: email || (vai.toLowerCase() + '@gita.vn'),
    password_hash: await phien.bamMatKhau('Nexus#Thu2026xyz', 2000),
    full_name: 'Người ' + vai, role: vai, status: 'ACTIVE', locale: 'vi',
    created_at: dh(), updated_at: dh() });
  const p = await phien.moPhien(kho, { id, role: vai }, 'thu', dh());
  return { id, the: p.the };
}

async function dungNen(moi, dh) {
  await gieoVu.gieo(Kho(moi.DB), dh());
}

test('bộ máy sinh ra đúng 600 trợ lý và 50 người CRM, không hơn không kém', () => {
  const ds = tc.danhSachTroLy();
  assert.equal(ds.length, 600);
  assert.equal(tc.danhSachCrm().length, 50);
  const theoBan = {};
  for (const x of ds) theoBan[x.ban_id] = (theoBan[x.ban_id] || 0) + 1;
  for (const b of tc.BAN) {
    assert.equal(theoBan[b.id], b.so, 'ban ' + b.id + ' lệch số khai');
  }
  assert.equal(ds.filter((x) => x.vai === 'truong-ban').length, tc.BAN.length);
  const ma = ds.map((x) => x.id);
  assert.equal(new Set(ma).size, 600, 'mã trợ lý phải duy nhất');
});

test('gieo hai lần không nhân đôi thứ gì', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  const kho = Kho(moi.DB);
  await gieoVu.gieo(kho, dh());
  const lan1 = await kho.dem('SELECT COUNT(*) FROM tro_ly');
  await gieoVu.gieo(kho, dh.tien(1000));
  assert.equal(await kho.dem('SELECT COUNT(*) FROM tro_ly'), lan1);
  assert.equal(await kho.dem('SELECT COUNT(*) FROM crm_tro_ly'), 50);
  assert.equal(await kho.dem('SELECT COUNT(*) FROM hien_phap'), hp.DIEU.length);
  assert.equal(await kho.dem('SELECT COUNT(*) FROM tai_khoan_ke_toan'), 38);
});

test('chương trình nói thẳng rằng 800.000 là đích chứ không phải số đang có', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await dungNen(moi, dh);
  const j = await doc(await goi(moi, 'GET', '/api/chuong-trinh/'));
  assert.equal(j.kho.baiDaCo, 0);
  assert.equal(j.kho.baiDich, 800000);
  assert.match(j.noiThang, /ĐÍCH/);
  assert.ok(j.soO > 150, 'phải có ô chương trình');
  assert.equal(j.mon.length, 3);
  assert.equal(j.capDo.length, 7);
});

test('cấp Đại học không mở cho lớp dưới 10, cấp Quốc tế không mở cho lớp dưới 6', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await dungNen(moi, dh);
  const kho = Kho(moi.DB);
  assert.equal(await kho.dem(
    "SELECT COUNT(*) FROM o_chuong_trinh WHERE cap_do_id='dai-hoc' AND lop < 10"), 0);
  assert.equal(await kho.dem(
    "SELECT COUNT(*) FROM o_chuong_trinh WHERE cap_do_id='quoc-te' AND lop < 6"), 0);
  assert.ok(await kho.dem(
    "SELECT COUNT(*) FROM o_chuong_trinh WHERE cap_do_id='dai-hoc' AND lop = 12") > 0);
});

test('chuẩn kiến thức không nhận nguồn do máy nghĩ ra', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await dungNen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const xau = await goi(moi, 'POST', '/api/chuong-trinh/chuan', { the: ad.the, than: {
    oId: 'toan-l7-co-ban', ma: '7.1', yeuCau: 'Cộng phân số', nguon: 'ai',
    trichDan: 'do mô hình sinh' } }, dh);
  assert.equal(xau.status, 400);
  const j = await doc(xau);
  assert.equal(j.ma, 'nguon-chuan-khong-hop-le');
  assert.match(j.loi, /Điều 6/);

  const tot = await goi(moi, 'POST', '/api/chuong-trinh/chuan', { the: ad.the, than: {
    oId: 'toan-l7-co-ban', ma: '7.1', yeuCau: 'Cộng hai phân số khác mẫu',
    nguon: 'moet', trichDan: 'Chương trình GDPT 2018, môn Toán lớp 7, mục Số hữu tỉ',
    bac: 'van-dung' } }, dh);
  assert.equal(tot.status, 201);
});

test('chuẩn thiếu trích dẫn thì không ghi được', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await dungNen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const r = await goi(moi, 'POST', '/api/chuong-trinh/chuan', { the: ad.the, than: {
    oId: 'toan-l7-co-ban', ma: '7.2', yeuCau: 'x', nguon: 'moet' } }, dh);
  assert.equal(r.status, 400);
  assert.equal((await doc(r)).ma, 'thieu-truong');
});

test('bài trùng đề không vào kho được lần thứ hai', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await dungNen(moi, dh);
  const gv = await nguoi(moi, dh, 'TEACHER');
  const cd = await doc(await goi(moi, 'POST', '/api/kho-bai/chuyen-de', { the: gv.the, than: {
    oId: 'toan-l7-co-ban', ma: 'cd-01', ten: 'Số hữu tỉ' } }, dh));
  assert.equal(cd.dat, true);

  const than = { chuyenDeId: cd.id, deBai: 'Tính 1/2 + 1/3.', dang: 'dien-so',
    doKho: 3, dapAn: '5/6', nguon: 'Sách giáo khoa Toán 7, bài 2' };
  const a = await goi(moi, 'POST', '/api/kho-bai/bai', { the: gv.the, than }, dh);
  assert.equal(a.status, 201);

  // Cùng đề, chỉ khác khoảng trắng và hoa thường: vẫn là một bài.
  const b = await goi(moi, 'POST', '/api/kho-bai/bai', { the: gv.the,
    than: Object.assign({}, than, { deBai: '  tính   1/2 + 1/3.  ' }) }, dh);
  assert.equal(b.status, 409);
  assert.equal((await doc(b)).ma, 'bai-trung');
});

test('bài không khai nguồn thì không vào kho', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await dungNen(moi, dh);
  const gv = await nguoi(moi, dh, 'TEACHER');
  const cd = await doc(await goi(moi, 'POST', '/api/kho-bai/chuyen-de', { the: gv.the, than: {
    oId: 'toan-l7-co-ban', ma: 'cd-02', ten: 'Số thực' } }, dh));
  const r = await goi(moi, 'POST', '/api/kho-bai/bai', { the: gv.the, than: {
    chuyenDeId: cd.id, deBai: 'Tính căn 2.', dang: 'dien-so', doKho: 4, dapAn: '1,414' } }, dh);
  assert.equal(r.status, 400);
  const j = await doc(r);
  assert.equal(j.ma, 'thieu-nguon');
  assert.match(j.loi, /Điều 11/);
});

test('không ai thẩm định bài do chính mình soạn, và chưa thẩm định thì chưa xuất bản', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await dungNen(moi, dh);
  const gv1 = await nguoi(moi, dh, 'TEACHER', 'gv1@gita.vn');
  const gv2 = await nguoi(moi, dh, 'TEACHER', 'gv2@gita.vn');
  const ad = await nguoi(moi, dh, 'ADMIN');
  const cd = await doc(await goi(moi, 'POST', '/api/kho-bai/chuyen-de', { the: gv1.the, than: {
    oId: 'toan-l8-co-ban', ma: 'cd-01', ten: 'Hằng đẳng thức' } }, dh));
  const bai = await doc(await goi(moi, 'POST', '/api/kho-bai/bai', { the: gv1.the, than: {
    chuyenDeId: cd.id, deBai: 'Khai triển (a+b)^2.', dang: 'tu-luan', doKho: 2,
    dapAn: 'a^2 + 2ab + b^2', nguon: 'Sách giáo khoa Toán 8' } }, dh));

  const tu = await goi(moi, 'POST', '/api/kho-bai/bai/' + bai.id + '/tham-dinh',
    { the: gv1.the, than: { quyet: 'dat', diem: 9 } }, dh);
  assert.equal(tu.status, 403);
  assert.equal((await doc(tu)).ma, 'tu-tham-dinh');

  const som = await goi(moi, 'POST', '/api/kho-bai/bai/' + bai.id + '/xuat-ban',
    { the: ad.the }, dh);
  assert.equal(som.status, 409);
  assert.equal((await doc(som)).ma, 'chua-tham-dinh');

  const ok = await goi(moi, 'POST', '/api/kho-bai/bai/' + bai.id + '/tham-dinh',
    { the: gv2.the, than: { quyet: 'dat', diem: 9 } }, dh);
  assert.equal(ok.status, 200);
  const xb = await goi(moi, 'POST', '/api/kho-bai/bai/' + bai.id + '/xuat-ban',
    { the: ad.the }, dh);
  assert.equal(xb.status, 200);

  const ls = await doc(await goi(moi, 'GET', '/api/kho-bai/bai/' + bai.id + '/lich-su',
    { the: ad.the }, dh));
  assert.deepEqual(ls.lichSu.map((x) => x.viec), ['tao', 'soat', 'xuat-ban']);
});

test('trả lại bài thì bắt buộc nói lý do', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await dungNen(moi, dh);
  const gv1 = await nguoi(moi, dh, 'TEACHER', 'a@gita.vn');
  const gv2 = await nguoi(moi, dh, 'TEACHER', 'b@gita.vn');
  const cd = await doc(await goi(moi, 'POST', '/api/kho-bai/chuyen-de', { the: gv1.the, than: {
    oId: 'ngu-van-l9-co-ban', ma: 'cd-01', ten: 'Nghị luận xã hội' } }, dh));
  const bai = await doc(await goi(moi, 'POST', '/api/kho-bai/bai', { the: gv1.the, than: {
    chuyenDeId: cd.id, deBai: 'Viết đoạn 200 chữ về lòng biết ơn.', dang: 'tu-luan',
    doKho: 5, dapAn: 'theo thang điểm', nguon: 'Đề thi thử 2025' } }, dh));
  const r = await goi(moi, 'POST', '/api/kho-bai/bai/' + bai.id + '/tham-dinh',
    { the: gv2.the, than: { quyet: 'tra-lai' } }, dh);
  assert.equal(r.status, 400);
  assert.match((await doc(r)).loi, /lyDo/);
});

test('học viên không thấy đáp án', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await dungNen(moi, dh);
  const gv = await nguoi(moi, dh, 'TEACHER', 'gv@gita.vn');
  const hv = await nguoi(moi, dh, 'LEARNER', 'hv@gita.vn');
  const cd = await doc(await goi(moi, 'POST', '/api/kho-bai/chuyen-de', { the: gv.the, than: {
    oId: 'tieng-anh-l6-co-ban', ma: 'cd-01', ten: 'Present simple' } }, dh));
  const bai = await doc(await goi(moi, 'POST', '/api/kho-bai/bai', { the: gv.the, than: {
    chuyenDeId: cd.id, deBai: 'She ___ to school every day.', dang: 'trac-nghiem',
    luaChon: ['go', 'goes', 'going', 'gone'], doKho: 2, dapAn: 1,
    nguon: 'Sách bài tập Tiếng Anh 6' } }, dh));

  const nhinHv = await doc(await goi(moi, 'GET', '/api/kho-bai/bai/' + bai.id, { the: hv.the }, dh));
  assert.equal(nhinHv.anDapAn, true);
  assert.equal(nhinHv.bai.dapAn, undefined);
  assert.ok(Array.isArray(nhinHv.bai.luaChon));

  const nhinGv = await doc(await goi(moi, 'GET', '/api/kho-bai/bai/' + bai.id, { the: gv.the }, dh));
  assert.equal(nhinGv.anDapAn, false);
  assert.equal(nhinGv.bai.dapAn, 1);
});

test('bộ não báo đúng 600 và khớp bảng khai', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await dungNen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const j = await doc(await goi(moi, 'GET', '/api/bo-nao/', { the: ad.the }, dh));
  assert.equal(j.tongTroLy, 600);
  assert.equal(j.khopBangKhai, true);
  assert.equal(j.ban.length, 10);
  assert.match(j.goiLa, /trợ lý AI chuyên môn/);
});

test('giao việc thiếu đầu vào thì từ chối, đủ thì chọn đúng người còn sức chứa', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await dungNen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');

  const thieu = await goi(moi, 'POST', '/api/bo-nao/giao-viec', { the: ad.the, than: {
    nhiemVu: 'soan-bai-tap', dauVao: { chuyen_de_id: 'x' } } }, dh);
  assert.equal(thieu.status, 400);
  assert.equal((await doc(thieu)).ma, 'thieu-dau-vao');

  const du = await doc(await goi(moi, 'POST', '/api/bo-nao/giao-viec', { the: ad.the, than: {
    nhiemVu: 'soan-bai-tap', dauVao: { chuyen_de_id: 'x', do_kho: 3, dang: 'tu-luan' } } }, dh));
  assert.equal(du.dat, true);
  assert.match(du.troLy, /^tl-\d{4}$/);
});

test('giao quá sức chứa thì dừng lại chứ không ép', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await dungNen(moi, dh);
  const kho = Kho(moi.DB);
  const ad = await nguoi(moi, dh, 'ADMIN');
  // Ban ky-thuat có 15 người; vai thực thi ít nhất, sức chứa 24/ngày.
  const soThucThi = await kho.dem(
    "SELECT COUNT(*) FROM tro_ly WHERE ban_id='ky-thuat' AND vai='thuc-thi'");
  const tran = soThucThi * 24;
  let cuoi;
  for (let i = 0; i < tran + 1; i++) {
    cuoi = await goi(moi, 'POST', '/api/bo-nao/giao-viec', { the: ad.the, than: {
      nhiemVu: 'theo-han-muc-ai', dauVao: {} } }, dh);
    if (cuoi.status !== 201) break;
  }
  assert.equal(cuoi.status, 503);
  assert.equal((await doc(cuoi)).ma, 'het-suc-chua');
});

test('việc cần người duyệt thì không tự nhảy sang xong', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await dungNen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const v = await doc(await goi(moi, 'POST', '/api/bo-nao/giao-viec', { the: ad.the, than: {
    nhiemVu: 'dung-de', dauVao: { ky_thi_id: 'hsa', loai: 'thu' } } }, dh));
  assert.equal(v.canNguoiDuyet, true);
  const x = await doc(await goi(moi, 'POST', '/api/bo-nao/viec/' + v.id + '/xong',
    { the: ad.the, than: { ketQua: { de: 'xong' } } }, dh));
  assert.equal(x.trangThai, 'cho-duyet');
  assert.match(x.ghiChu, /Điều 14/);
});

test('hiến pháp: mỗi điều đều dẫn được văn bản pháp lý thật', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await dungNen(moi, dh);
  const j = await doc(await goi(moi, 'GET', '/api/bo-nao/hien-phap'));
  assert.ok(j.soDieu >= 15);
  for (const d of j.dieu) {
    assert.ok(Array.isArray(d.canCu) && d.canCu.length > 0, 'Điều ' + d.dieu + ' thiếu căn cứ');
    for (const c of d.canCu) {
      assert.ok(c.van_ban && c.so, 'căn cứ phải có tên văn bản và số hiệu');
      assert.ok(['VN', 'quoc-te'].includes(c.nuoc));
    }
    assert.ok(d.viPhamThi.length > 20, 'Điều ' + d.dieu + ' không nói vi phạm thì sao');
  }
  assert.ok(j.nguonPhapLy.vietNam.length >= 10);
  assert.ok(j.nguonPhapLy.quocTe.length >= 5);
  assert.match(j.luuY, /chuyên môn pháp lý/);
});

test('ghi vi phạm vào điều không tồn tại thì từ chối', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await dungNen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const r = await goi(moi, 'POST', '/api/bo-nao/vi-pham',
    { the: ad.the, than: { dieu: 999, bangChung: { x: 1 } } }, dh);
  assert.equal(r.status, 400);
  const ok = await goi(moi, 'POST', '/api/bo-nao/vi-pham',
    { the: ad.the, than: { dieu: 2, bangChung: { cau: 'Học hai tuần là con giỏi toán' } } }, dh);
  assert.equal(ok.status, 201);
  assert.match((await doc(ok)).xuLy, /chặn/);
});

test('phủ sóng đếm lại từ kho thật, không phải số khai', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await dungNen(moi, dh);
  const kho = Kho(moi.DB);
  const gv = await nguoi(moi, dh, 'TEACHER');
  const cd = await doc(await goi(moi, 'POST', '/api/kho-bai/chuyen-de', { the: gv.the, than: {
    oId: 'toan-l1-co-ban', ma: 'cd-01', ten: 'Đếm đến 10' } }, dh));
  for (let i = 0; i < 3; i++) {
    await goi(moi, 'POST', '/api/kho-bai/bai', { the: gv.the, than: {
      chuyenDeId: cd.id, deBai: 'Đếm từ 1 đến ' + (i + 5) + '.', dang: 'dien-so',
      doKho: 1, dapAn: i + 5, nguon: 'Sách giáo khoa Toán 1' } }, dh);
  }
  // Sửa lén con số trong bảng phủ sóng rồi đếm lại: phải về đúng số thật.
  moi.DB._db.exec("UPDATE phu_song SET so_bai_nhap = 999999 WHERE o_id = 'toan-l1-co-ban'");
  await gieoVu.demLaiPhuSong(kho, dh());
  const p = await kho.mot("SELECT * FROM phu_song WHERE o_id = 'toan-l1-co-ban'");
  assert.equal(Number(p.so_bai_nhap), 3);
  assert.equal(Number(p.so_chuyen_de), 1);
});
