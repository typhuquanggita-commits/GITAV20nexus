'use strict';
/**
 * THẺ ĐIỂM CÂN BẰNG
 *
 * Thẻ điểm hỏng theo những cách rất giống nhau ở mọi tổ chức, và cả bộ kiểm
 * này chỉ canh đúng những cách ấy: mục tiêu không nối vào đâu, chỉ tiêu đặt
 * cho thứ chưa đo được, rủi ro có "biện pháp" viết bằng động từ mềm, và một
 * hệ thống phần mềm tự tuyên bố mình tuân thủ pháp luật.
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const BD = require('../src/chien-luoc/ban-do');
const TD = require('../src/chien-luoc/thuoc-do');
const RR = require('../src/chien-luoc/rui-ro');
const AT = require('../src/chien-luoc/an-toan');
const RS = require('../src/chien-luoc/ra-soat');
const THE = require('../src/chien-luoc/the-diem');

test('Bản đồ chiến lược: không mồ côi, không vòng lặp, không nhảy tầng', () => {
  const s = BD.soiBanDo();
  assert.deepEqual(s.loi, [], s.loi.join(' · '));
  assert.equal(s.soVienCanh, 4);
  assert.ok(s.soMucTieu >= 15);
  assert.ok(s.soChuoi > 0);
});

test('Mọi chuỗi nhân quả kết thúc ở tầng tài chính', () => {
  // Chuỗi tắt giữa đường nghĩa là ta không biết mục tiêu ấy dẫn tới đâu.
  for (const m of BD.MUC_TIEU) {
    if (m.vienCanh === 'TC') continue;
    for (const c of BD.chuoiTu(m.ma)) {
      const cuoi = BD.MT_INDEX.get(c[c.length - 1]);
      assert.ok(cuoi && cuoi.vienCanh === 'TC',
        `chuỗi từ ${m.ma} tắt ở ${c[c.length - 1]}`);
    }
  }
});

test('Cạnh phòng tổn thất KHÔNG dùng được để nhảy tầng cho tiện', () => {
  // Nếu không siết chỗ này thì `chan` thành cửa sau để lách luật một-tầng.
  for (const m of BD.MUC_TIEU) {
    for (const d of (m.chan || [])) {
      const dich = BD.MT_INDEX.get(d);
      assert.ok(dich, `${m.ma} chặn vào ${d} không tồn tại`);
      assert.equal(dich.laPhongTonThat, true,
        `${m.ma} ⇢ ${d}: cạnh phòng tổn thất trỏ vào mục tiêu không phải phòng tổn thất`);
    }
  }
  assert.ok(BD.MUC_TIEU.some((m) => (m.chan || []).length), 'không có cạnh phòng tổn thất nào');
});

test('Mọi mục tiêu ngoài tầng nền đều có chuỗi dẫn tới', () => {
  // Bộ soi tìm ra hai mục tiêu tài chính mồ côi đầu vào ngay ở bản dựng đầu:
  // một kết quả mong muốn mà không nói nó đến từ đâu.
  const vao = new Set();
  for (const m of BD.MUC_TIEU) {
    for (const d of m.dan) vao.add(d);
    for (const d of (m.chan || [])) vao.add(d);
  }
  const moCoi = BD.MUC_TIEU.filter((m) => m.vienCanh !== 'HH' && !vao.has(m.ma)).map((m) => m.ma);
  assert.deepEqual(moCoi, []);
});

test('KHÔNG đặt chỉ tiêu cho thước đo chưa nối được nguồn', () => {
  // Đây là luật quan trọng nhất của tầng này. "Giữ chân 85%" trong khi hệ
  // thống chưa có khái niệm "đang là khách hàng" không sai — nó vô nghĩa, và
  // tệ hơn là làm người đọc tưởng có ai đó đang theo dõi.
  const xau = TD.THUOC_DO.filter((d) => d.chuaNoiNguon && d.chiTieu).map((d) => d.ma);
  assert.deepEqual(xau, []);
  const thieu = TD.THUOC_DO.filter((d) => !d.chuaNoiNguon && !d.chiTieu).map((d) => d.ma);
  assert.deepEqual(thieu, []);
});

test('Mỗi mục tiêu có ít nhất một chỉ báo DẪN DẮT đo được', () => {
  // Thẻ điểm toàn chỉ báo kết quả thì đọc xong chuyện đã rồi, không can thiệp
  // được nữa. Mục kiểm này từng bắt hai mục tiêu ở đúng tình trạng ấy.
  const s = TD.soiThuocDo();
  assert.deepEqual(s.loi, [], s.loi.join(' · '));
  for (const m of BD.MUC_TIEU) {
    if (m.chuaNoiNguon) continue;
    const dan = TD.cuaMucTieu(m.ma).filter((d) => d.loai === 'dan-dat' && !d.chuaNoiNguon);
    assert.ok(dan.length > 0, `${m.ma} không có chỉ báo dẫn dắt đo được`);
  }
});

test('Mọi thước đo có chủ và có nguồn', () => {
  for (const d of TD.THUOC_DO) {
    assert.ok(BD.MT_INDEX.has(d.mucTieu), `${d.ma} gắn vào mục tiêu không tồn tại`);
    assert.ok(d.ai && d.ai.length >= 4, `${d.ma} là thước đo vô chủ`);
    assert.ok(d.nguon && d.nguon.length >= 8, `${d.ma} không nói lấy số từ đâu`);
    assert.ok(['dan-dat', 'ket-qua'].includes(d.loai));
  }
  assert.equal(new Set(TD.THUOC_DO.map((d) => d.ma)).size, TD.THUOC_DO.length, 'có mã trùng');
});

test('Biện pháp chặn rủi ro là TỆP MÃ CÓ THẬT, không phải động từ mềm', () => {
  // Phần lớn sổ rủi ro là danh sách nỗi lo kèm cột "tăng cường, chú trọng,
  // nâng cao". Ở đây mỗi biện pháp phải có địa chỉ, và địa chỉ bị đi kiểm.
  const s = RR.soiRuiRo();
  assert.deepEqual(s.loi, [], s.loi.join(' · '));
  const goc = path.join(__dirname, '..');
  for (const r of RR.RUI_RO) {
    assert.ok(r.chan.length > 0, `${r.ma} không có biện pháp chặn`);
    for (const f of r.chan) {
      assert.ok(fs.existsSync(path.join(goc, f)), `${r.ma} khai chặn bằng ${f} — không tồn tại`);
    }
    assert.ok(!/tăng cường|chú trọng|nâng cao|đẩy mạnh/i.test(r.cachChan || ''),
      `${r.ma} mô tả biện pháp bằng động từ mềm`);
  }
});

test('Rủi ro NGHIÊM TRỌNG phải có cả mục soi lẫn kịch bản trực', () => {
  const TT = require('../src/thanh-tra/to-thanh-tra');
  const ST = require('../src/quy-trinh/so-tay');
  const maVien = new Set(TT.THANH_TRA_VIEN.map((v) => v.ma));
  const nang = RR.RUI_RO.filter((r) => r.muc === 'NGHIEM_TRONG');
  assert.ok(nang.length > 0);
  for (const r of nang) {
    assert.ok(r.thay.some((t) => maVien.has(t)), `${r.ma} nghiêm trọng mà không mục soi nào canh`);
    assert.ok(ST.KICH_BAN_INDEX.has(r.xuLy), `${r.ma} nghiêm trọng mà không có kịch bản trực`);
  }
});

test('Rủi ro không ai canh tự động được NÊU TÊN, không bị giấu', () => {
  const s = RR.soiRuiRo();
  assert.equal(s.coMucSoiTuDong + s.khongCoMucSoi.length, s.tong);
  // Ba rủi ro không có mục soi là chấp nhận có ý thức, nhưng phải liệt kê ra.
  for (const r of s.khongCoMucSoi) {
    assert.ok(r.ma && r.ten && r.muc, 'rủi ro không mục soi phải nêu đủ mã, tên, mức');
    assert.notEqual(r.muc, 'NGHIEM_TRONG', `${r.ma} nghiêm trọng mà không ai canh`);
  }
});

test('An toàn tài chính: chặn CỨNG, và chỗ mù nêu tên', () => {
  const a = AT.anToanTaiChinh();
  assert.ok(a.soCuaChanCung >= 3);
  for (const c of a.cua) assert.equal(c.kieu, 'chan-cung', `${c.ma} chỉ cảnh báo chứ không chặn`);
  // Phải khớp với sổ cái dòng tiền — hai chỗ không được nói hai điều khác nhau.
  const soCai = require('../src/dong-tien/so-cai');
  const chuaNoi = Object.values(soCai.KHOAN).filter((k) => k.tinCay === 'chua-co');
  assert.equal(a.chuaNoiNguon.length, chuaNoi.length);
  // Chưa nối doanh thu thì KHÔNG được kết luận gì về rủi ro tập trung.
  assert.equal(a.ruiRoTapTrung.doDuoc, false);
  assert.ok(a.khongNoiDuoc.length > 0, 'không nêu được chỗ nào chưa nói được — đáng ngờ');
});

test('Hệ thống KHÔNG tự chứng nhận tuân thủ pháp luật', () => {
  // Một hệ thống phần mềm không thể tự chứng nhận mình tuân thủ pháp luật, và
  // không có chế độ nào để bật việc đó.
  const p = AT.anToanPhapLy();
  assert.equal(p.tuChungNhan, false);
  assert.ok(/KHÔNG TỰ CHỨNG NHẬN/.test(p.canhBao));
  // Nghĩa vụ chưa có người ký thì trạng thái là chưa xác nhận, không phải đạt.
  for (const n of AT.NGHIA_VU) {
    if (!n.nguoiXacNhan) {
      assert.ok(p.chuaCoNguoiKy.some((x) => x.ma === n.ma), `${n.ma} chưa ký mà không bị nêu tên`);
    }
  }
  // Số hiệu văn bản phải tự khai là do người dựng khai, không do máy tra cứu.
  assert.ok(/do người dựng hệ thống khai/.test(p.soHieuVanBan));
  for (const n of AT.NGHIA_VU) {
    if (/\d+\/20\d\d\/QH\d+/.test(n.canCu)) {
      assert.ok(/do người dựng khai|cần đối chiếu/.test(n.canCu),
        `${n.ma} dẫn số hiệu văn bản mà không nói rõ đó là khai báo chưa xác minh`);
    }
  }
  assert.deepEqual(p.loiDuongDan, []);
});

test('Nhịp rà soát: ba nhịp ba câu hỏi, và chỉ nhịp quý được sửa bản đồ', () => {
  const r = RS.nhipRaSoat();
  assert.equal(r.nhip.length, 3);
  assert.equal(new Set(r.nhip.map((n) => n.cauHoi)).size, 3, 'ba nhịp hỏi cùng một câu');
  const suaBanDo = r.nhip.filter((n) => /sửa BẢN ĐỒ|Sửa BẢN ĐỒ/.test(n.raQuyetDinh));
  assert.equal(suaBanDo.length, 1, 'phải có đúng một nhịp được sửa bản đồ');
  assert.equal(suaBanDo[0].ma, 'RS-QUY');
  for (const n of r.nhip) assert.ok(n.camLam && n.camLam.length > 10, `${n.ma} thiếu mục cấm`);
  // Chưa có kho biên bản thì phải nói thẳng là chưa theo dõi được.
  assert.equal(r.theoDoiDuoc, false);
  assert.ok(r.cauHoiQuy.length >= 5);
});

test('Thẻ điểm in phần CHƯA BIẾT trước phần đã biết', () => {
  const t = THE.theDiem();
  const khoa = Object.keys(t);
  assert.equal(khoa[0], 'chuaBiet', 'thẻ điểm không đặt phần chưa biết lên đầu');
  assert.ok(t.chuaBiet.length > 0, 'thẻ điểm khai mình biết hết — đáng ngờ');
  assert.equal(t.ok, true);
  // Mọi con số trong tóm tắt phải khớp với nguồn của nó.
  assert.equal(t.tomTat.mucTieu, BD.MUC_TIEU.length);
  assert.equal(t.tomTat.thuocDo, TD.THUOC_DO.length);
  assert.equal(t.tomTat.ruiRo, RR.RUI_RO.length);
  assert.equal(t.tomTat.nghiaVuPhapLy, AT.NGHIA_VU.length);
});

test('Tầng chiến lược không lọt chữ của bảng phân loại nội bộ ra mặt khách', () => {
  // Thẻ điểm là tài liệu điều hành; nó không đi tới gia đình. Nhưng bản đồ
  // chiến lược thì được trích dẫn trong tài liệu đối ngoại, nên phần MỤC TIÊU
  // và GIẢ THUYẾT phải sạch.
  const tuong = require('../src/cay-tien/buc-tuong');
  const r = tuong.soiRoRi(JSON.stringify(BD.MUC_TIEU.map((m) => [m.ten, m.viSao])));
  assert.equal(r.sach, true, JSON.stringify(r.roRi));
});
