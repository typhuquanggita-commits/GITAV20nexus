'use strict';
/** Tầng Cloudflare V13: sáu nhà cung cấp, đồng bộ ngoại tuyến, uy tín, dịch. */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const { dungMoi, dongHoGia, yeuCau, doc } = require('../cloudflare/kiem-thu/gia-lap.js');
const { xuLy } = require('../cloudflare/nguon/goc.js');
const { Kho } = require('../cloudflare/nguon/_lib/kho.js');
const phien = require('../cloudflare/nguon/_lib/phien.js');
const { maMoi } = require('../cloudflare/nguon/_lib/ma.js');
const congAi = require('../cloudflare/nguon/_lib/cong-ai.js');
const uyTin = require('../cloudflare/nguon/_lib/uy-tin.js');
const dichVu = require('../cloudflare/nguon/_lib/dich.js');

const goi = (moi, cach, duong, tc, dh) => xuLy(yeuCau(cach, duong, tc), moi, {}, dh);

async function taoNguoi(moi, dh, vai, email) {
  const kho = Kho(moi.DB);
  const id = maMoi();
  await kho.chen('users', { id, email: email || (vai.toLowerCase() + '@gita.vn'),
    password_hash: await phien.bamMatKhau('Nexus#Thu2026xyz', 2000),
    full_name: 'Người ' + vai, role: vai, status: 'ACTIVE', locale: 'vi',
    created_at: dh(), updated_at: dh() });
  const p = await phien.moPhien(kho, { id, role: vai }, 'thu', dh());
  return { id, the: p.the, kho };
}

/** Thay một nhà cung cấp bằng bản giả, trả lại hàm khôi phục. */
function gaNhaGia(ma, traVe) {
  const cu = congAi.NHA[ma].goi;
  let soLan = 0;
  congAi.NHA[ma].goi = async (moi, tuyChon) => {
    soLan++;
    const r = traVe(tuyChon, soLan);
    if (r instanceof Error) throw r;
    return r;
  };
  return { go: () => { congAi.NHA[ma].goi = cu; }, soLan: () => soLan };
}

test('tình hình nhà cung cấp cảnh báo đúng khi không nhà nào cắm khoá', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  const a = await taoNguoi(moi, dh, 'ADMIN');
  const j = await doc(await goi(moi, 'GET', '/api/v13/providers/status', { the: a.the }, dh));
  assert.equal(j.soNhaSanSang, 0);
  assert.match(j.canhBao, /trả lỗi 502/);
});

test('cổng AI chuyển sang nhà sau khi nhà đầu hỏng, và ghi lại đường đã đi', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  moi.GEMINI_API_KEY = 'x'; moi.GROQ_API_KEY = 'y';
  const kho = Kho(moi.DB);
  const g1 = gaNhaGia('gemini', () => new Error('gemini-429'));
  const g2 = gaNhaGia('groq', () => ({ chu: 'xong', mauMay: 'llama', theVao: 10, theRa: 5 }));
  try {
    const r = await congAi.sinh(kho, moi, { loiNhac: 'chào' }, dh);
    assert.equal(r.nha, 'groq');
    assert.deepEqual(r.duongDaDi, ['gemini:loi:gemini-429', 'groq:dat']);
  } finally { g1.go(); g2.go(); }

  const h = await kho.nhieu('SELECT provider_code, status FROM ai_provider_health ORDER BY rowid');
  assert.deepEqual(h.map((x) => x.provider_code + ':' + x.status), ['gemini:degraded', 'groq:healthy']);
});

test('hết trần ngày thì bỏ qua nhà ấy chứ không gọi phí một lượt', async () => {
  const moi = dungMoi(), dh = dongHoGia();     // AI_PROVIDER_DAILY_CAP = 5
  moi.GEMINI_API_KEY = 'x'; moi.GROQ_API_KEY = 'y';
  const kho = Kho(moi.DB);
  const g1 = gaNhaGia('gemini', () => ({ chu: 'a', mauMay: 'm', theVao: 1, theRa: 1 }));
  const g2 = gaNhaGia('groq', () => ({ chu: 'b', mauMay: 'n', theVao: 1, theRa: 1 }));
  try {
    for (let i = 0; i < 5; i++) await congAi.sinh(kho, moi, { loiNhac: 'x' }, dh);
    assert.equal(g1.soLan(), 5);
    const r = await congAi.sinh(kho, moi, { loiNhac: 'x' }, dh);
    assert.equal(r.nha, 'groq');
    assert.equal(g1.soLan(), 5, 'không gọi nhà đã hết trần thêm lần nào');
    assert.ok(r.duongDaDi.includes('gemini:het-han-muc'));
  } finally { g1.go(); g2.go(); }
});

test('cả sáu nhà im lặng thì báo lỗi thật, không bịa câu trả lời', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  const kho = Kho(moi.DB);
  await assert.rejects(
    () => congAi.sinh(kho, moi, { loiNhac: 'x' }, dh),
    (e) => e.ma === 'ai-khong-goi-duoc' && /gemini|groq/.test(e.duongDaDi.join(',')));
});

test('đồng bộ: đẩy rồi kéo, gói máy khách đã có bị lọc ra', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  const u = await taoNguoi(moi, dh, 'LEARNER');
  const day = await doc(await goi(moi, 'POST', '/api/v13/sync/push', { the: u.the, than: {
    maTaiLieu: 'bai:1',
    goi: [
      { than: 'AAAA', dongHoVecto: { may1: 1 }, clientTs: dh() },
      { than: 'BBBB', dongHoVecto: { may1: 2 }, clientTs: dh() },
    ],
  } }, dh));
  assert.equal(day.daNhan, 2);

  const heo = await doc(await goi(moi, 'POST', '/api/v13/sync/pull', { the: u.the, than: {
    maTaiLieu: 'bai:1', sinceServerTs: 0, dongHoVecto: {},
  } }, dh));
  assert.equal(heo.soGoi, 2);

  const heo2 = await doc(await goi(moi, 'POST', '/api/v13/sync/pull', { the: u.the, than: {
    maTaiLieu: 'bai:1', sinceServerTs: 0, dongHoVecto: { may1: 2 },
  } }, dh));
  assert.equal(heo2.soGoi, 0, 'máy khách đã có tới may1:2 thì không nhận lại gì');
  assert.equal(heo2.daBoQua, 2);
});

test('đồng bộ: chụp ảnh xong thì dọn gói cũ, chụp lại ở cùng mốc không nhân đôi', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  const u = await taoNguoi(moi, dh, 'LEARNER');
  await goi(moi, 'POST', '/api/v13/sync/push', { the: u.the, than: {
    maTaiLieu: 'bai:2', goi: [{ than: 'AAAA', dongHoVecto: { m: 1 } }] } }, dh);
  dh.tien(1000);
  const a = await doc(await goi(moi, 'POST', '/api/v13/sync/snapshot',
    { the: u.the, than: { maTaiLieu: 'bai:2', anhChup: 'TRANGTHAI' } }, dh));
  assert.equal(a.denSo, 1);
  assert.equal(a.goiDaDon, 1);
  const b = await doc(await goi(moi, 'POST', '/api/v13/sync/snapshot',
    { the: u.the, than: { maTaiLieu: 'bai:2', anhChup: 'TRANGTHAI' } }, dh));
  assert.equal(b.daCo, true, 'không có gói mới thì không chụp lại');
  assert.equal(await Kho(moi.DB).dem('SELECT COUNT(*) FROM crdt_snapshots'), 1);

  // Gói mới đến sau: mốc phải tăng tiếp từ 1 lên 2, không tụt về 1.
  dh.tien(1000);
  await goi(moi, 'POST', '/api/v13/sync/push', { the: u.the, than: {
    maTaiLieu: 'bai:2', goi: [{ than: 'CCCC', dongHoVecto: { m: 2 } }] } }, dh);
  dh.tien(1000);
  const c = await doc(await goi(moi, 'POST', '/api/v13/sync/snapshot',
    { the: u.the, than: { maTaiLieu: 'bai:2', anhChup: 'TRANGTHAI2' } }, dh));
  assert.equal(c.denSo, 2);
  assert.equal(await Kho(moi.DB).dem('SELECT COUNT(*) FROM crdt_snapshots'), 2);
});

test('đồng bộ: chỉ thấy bạn còn hoạt động, và không thấy chính mình', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  const a = await taoNguoi(moi, dh, 'LEARNER', 'a@gita.vn');
  const b = await taoNguoi(moi, dh, 'LEARNER', 'b@gita.vn');
  for (const x of [a, b]) {
    await goi(moi, 'POST', '/api/v13/sync/peer/register',
      { the: x.the, than: { maMay: 'may-' + x.id.slice(0, 4), maTaiLieu: ['bai:9'] } }, dh);
  }
  const t1 = await doc(await goi(moi, 'GET', '/api/v13/sync/peer/find?maTaiLieu=bai:9',
    { the: a.the }, dh));
  assert.equal(t1.soBan, 1);
  assert.equal(t1.ban[0].cuaAi, b.id);

  dh.tien(6 * 60 * 1000);
  const t2 = await doc(await goi(moi, 'GET', '/api/v13/sync/peer/find?maTaiLieu=bai:9',
    { the: a.the }, dh));
  assert.equal(t2.soBan, 0, 'quá năm phút thì coi như đã rời đi');
});

test('uy tín: không ai tự cộng điểm "được duyệt" cho chính mình', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  const u = await taoNguoi(moi, dh, 'LEARNER');
  const r = await goi(moi, 'POST', '/api/v13/contributions/record', { the: u.the, than: {
    loai: 'approve', loaiNoiDung: 'bai', maNoiDung: 'b1' } }, dh);
  assert.equal(r.status, 400);
  assert.equal((await doc(r)).ma, 'tu-cong-diem');

  const ok = await goi(moi, 'POST', '/api/v13/contributions/record', { the: u.the, than: {
    loai: 'edit', loaiNoiDung: 'bai', maNoiDung: 'b1' } }, dh);
  assert.equal(ok.status, 201);
  assert.equal((await doc(ok)).diemCong, 5);
});

test('uy tín: ghi hộ người khác cần quyền kiểm duyệt', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  const hv = await taoNguoi(moi, dh, 'LEARNER', 'hv@gita.vn');
  const gv = await taoNguoi(moi, dh, 'TEACHER', 'gv@gita.vn');
  // Học viên cộng điểm cho giáo viên: không phải tự ghi, nên phải có quyền kiểm duyệt.
  const cam = await goi(moi, 'POST', '/api/v13/contributions/record', { the: hv.the,
    than: { loai: 'approve', loaiNoiDung: 'bai', maNoiDung: 'b2', choAi: gv.id } }, dh);
  assert.equal(cam.status, 403);
  assert.equal((await doc(cam)).ma, 'khong-du-quyen-ghi-ho');

  // Giáo viên có content.moderate:scope, cộng điểm cho học viên thì được.
  const cho = await goi(moi, 'POST', '/api/v13/contributions/record', { the: gv.the,
    than: { loai: 'approve', loaiNoiDung: 'bai', maNoiDung: 'b2', choAi: hv.id } }, dh);
  assert.equal(cho.status, 201);
  assert.equal((await doc(cho)).tong, 10);
});

test('uy tín: trần ngày chặn đúng và mở lại vào hôm sau', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  const kho = Kho(moi.DB);
  const u = await taoNguoi(moi, dh, 'LEARNER');
  let cuoi;
  for (let i = 0; i < 45; i++) {
    cuoi = await uyTin.ghiDongGop(kho,
      { nguoiGhi: u.id, choAi: u.id, loai: 'edit', loaiNoiDung: 'b', maNoiDung: String(i) }, dh());
  }
  assert.equal(cuoi.dat, false);
  assert.equal(cuoi.ma, 'qua-tran-ngay');
  assert.equal(await uyTin.diemHomNay(kho, u.id, dh()), uyTin.TRAN_NGAY);

  dh.tien(26 * 3600 * 1000);
  const sau = await uyTin.ghiDongGop(kho,
    { nguoiGhi: u.id, choAi: u.id, loai: 'edit', loaiNoiDung: 'b', maNoiDung: 'moi' }, dh());
  assert.equal(sau.dat, true);
  assert.equal(sau.bac, 'contributor', '205 điểm thì lên bậc contributor');
});

test('dịch: thuật ngữ bắt buộc được ép vào lời nhắc và soát lại sau khi dịch', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  moi.GEMINI_API_KEY = 'x';
  const ad = await taoNguoi(moi, dh, 'ADMIN');
  await goi(moi, 'POST', '/api/v13/translations/glossary', { the: ad.the, than: {
    tuTieng: 'vi', sangTieng: 'en', thuatNguGoc: 'đạo hàm', thuatNguDich: 'derivative' } }, dh);

  let loiNhacThay = '';
  const g = gaNhaGia('gemini', (tc) => {
    loiNhacThay = tc.loiNhac;
    return { chu: '{"tieuDe":"The derivative of a function"}', mauMay: 'gemini-1.5-flash',
      theVao: 20, theRa: 10 };
  });
  try {
    const r = await doc(await goi(moi, 'POST', '/api/v13/translations/translate', { the: ad.the, than: {
      loaiNoiDung: 'bai', maNoiDung: 'b1', sangTieng: 'en',
      truong: { tieuDe: 'Đạo hàm của một hàm số' } } }, dh));
    assert.equal(r.dat, true);
    assert.match(loiNhacThay, /"đạo hàm" → "derivative"/);
    assert.equal(r.soThuatNguApDung, 1);
    assert.deepEqual(r.thuatNguLech, []);
    assert.equal(r.diemChatLuong, 1);
    assert.equal(r.canNguoiSoat, false);
  } finally { g.go(); }
});

test('dịch: máy bỏ qua thuật ngữ thì báo lệch chứ không lặng lẽ duyệt', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  moi.GEMINI_API_KEY = 'x';
  const ad = await taoNguoi(moi, dh, 'ADMIN');
  await goi(moi, 'POST', '/api/v13/translations/glossary', { the: ad.the, than: {
    sangTieng: 'en', thuatNguGoc: 'đạo hàm', thuatNguDich: 'derivative' } }, dh);
  const g = gaNhaGia('gemini', () =>
    ({ chu: '{"tieuDe":"The slope of a function"}', mauMay: 'm', theVao: 1, theRa: 1 }));
  try {
    const r = await doc(await goi(moi, 'POST', '/api/v13/translations/translate', { the: ad.the, than: {
      loaiNoiDung: 'bai', maNoiDung: 'b2', sangTieng: 'en',
      truong: { tieuDe: 'Đạo hàm của một hàm số' } } }, dh));
    assert.deepEqual(r.thuatNguLech, [{ goc: 'đạo hàm', phaiLa: 'derivative' }]);
    assert.equal(r.canNguoiSoat, true);
    assert.equal(r.diemChatLuong, 0);
  } finally { g.go(); }
});

test('dịch: bản gốc đổi thì bản dịch tự thành lạc hậu và không duyệt được', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  moi.GEMINI_API_KEY = 'x';
  const ad = await taoNguoi(moi, dh, 'ADMIN');
  const g = gaNhaGia('gemini', () => ({ chu: '{"t":"one"}', mauMay: 'm', theVao: 1, theRa: 1 }));
  let id;
  try {
    const r = await doc(await goi(moi, 'POST', '/api/v13/translations/translate', { the: ad.the, than: {
      loaiNoiDung: 'bai', maNoiDung: 'b3', sangTieng: 'en', truong: { t: 'một' } } }, dh));
    id = r.id;
  } finally { g.go(); }

  const bamMoi = await dichVu.bamGoc({ t: 'hai' });
  const n = await dichVu.danhDauLacHau(Kho(moi.DB), 'bai', 'b3', bamMoi, dh());
  assert.equal(n, 1);

  const soat = await goi(moi, 'POST', '/api/v13/translations/' + id + '/review',
    { the: ad.the, than: { quyet: 'published' } }, dh);
  assert.equal(soat.status, 409);
  assert.equal((await doc(soat)).ma, 'ban-dich-lac-hau');
});

test('dịch: bản dịch không phải JSON thì không lưu bản hỏng', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  moi.GEMINI_API_KEY = 'x';
  const ad = await taoNguoi(moi, dh, 'ADMIN');
  const g = gaNhaGia('gemini', () => ({ chu: 'xin lỗi tôi không dịch được',
    mauMay: 'm', theVao: 1, theRa: 1 }));
  try {
    const r = await goi(moi, 'POST', '/api/v13/translations/translate', { the: ad.the, than: {
      loaiNoiDung: 'bai', maNoiDung: 'b4', sangTieng: 'en', truong: { t: 'một' } } }, dh);
    assert.equal(r.status, 400);
    assert.equal((await doc(r)).ma, 'ban-dich-khong-phai-json');
  } finally { g.go(); }
  assert.equal(await Kho(moi.DB).dem('SELECT COUNT(*) FROM content_translations'), 0);
});

test('dịch: thêm thuật ngữ mới thì bản dịch máy cũ phải soát lại', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  moi.GEMINI_API_KEY = 'x';
  const ad = await taoNguoi(moi, dh, 'ADMIN');
  const g = gaNhaGia('gemini', () => ({ chu: '{"t":"one"}', mauMay: 'm', theVao: 1, theRa: 1 }));
  try {
    await goi(moi, 'POST', '/api/v13/translations/translate', { the: ad.the, than: {
      loaiNoiDung: 'bai', maNoiDung: 'b5', sangTieng: 'en', truong: { t: 'một' } } }, dh);
  } finally { g.go(); }
  const r = await doc(await goi(moi, 'POST', '/api/v13/translations/glossary', { the: ad.the, than: {
    sangTieng: 'en', thuatNguGoc: 'một', thuatNguDich: 'one' } }, dh));
  assert.equal(r.banDichPhaiSoatLai, 1);
});
