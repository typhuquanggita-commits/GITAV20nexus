'use strict';
/**
 * CỔNG QUYỀN
 *
 * Bộ kiểm này canh một lỗ thủng đã từng có thật: 295 trong 300 cổng API mở cho
 * bất kỳ ai, trong đó POST /accounts cho phép tự đúc một tài khoản ADMIN mà
 * không cần đăng nhập — nghĩa là mọi bức tường phía sau đều vô giá trị.
 *
 * Nên các mục dưới đây kiểm NGUYÊN TẮC chứ không kiểm từng cổng một: mặc định
 * phải là ĐÓNG, và muốn mở thì phải khai tên. Thêm một nhóm cổng mới mà quên
 * khai mức thì nó phải rơi vào mức chặt nhất.
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const cq = require('../src/api/cong-quyen');

const R = (method, pattern, group) => ({ method, pattern, group });

test('Nhóm cổng chưa khai mức thì rơi vào mức CHẶT NHẤT', () => {
  assert.equal(cq.mucCua(R('GET', '/nhom-moi-nao-do', 'NHOM_CHUA_KHAI')), 'quan-tri');
  assert.equal(cq.mucCua(R('POST', '/x', undefined)), 'quan-tri');
});

test('Danh sách công khai ngắn, và không chứa cổng ghi dữ liệu', () => {
  const mo = [...cq.CONG_KHAI];
  assert.ok(mo.length <= 12, `có tới ${mo.length} cổng công khai`);
  const ghi = mo.filter((k) => /^(POST|PUT|PATCH|DELETE) /.test(k));
  // Cổng ghi mở được phép TẤT CẢ đều là cổng để VÀO, không phải cổng đổi dữ
  // liệu nghiệp vụ: đăng nhập, đăng xuất, hai cổng khởi tạo của két Super
  // Admin, và hai cổng đăng nhập bằng khuôn mặt.
  //
  // Hai cổng khuôn mặt thêm vào đây có lý do đi kèm, không phải nới cho vừa:
  //   · xin-dang-nhap chỉ phát một thách thức ngẫu nhiên sống hai phút trong
  //     bộ nhớ, không đụng một bản ghi nghiệp vụ nào, và KHÔNG tiết lộ tài
  //     khoản nào tồn tại — tài khoản không có trả về danh sách rỗng y hệt
  //     tài khoản có thật mà chưa gắn khuôn mặt.
  //   · dang-nhap mở phiên, đúng việc mà /accounts/login vẫn làm, và đi qua
  //     đúng hàng rào khoá tài khoản ấy.
  //
  // Mọi cổng GẮN và GỠ khuôn mặt vẫn đòi phiên đang đăng nhập.
  const LY_DO_MO = /login|logout|initialize|khuon-mat\/(xin-)?dang-nhap/;
  for (const k of ghi) {
    assert.match(k, LY_DO_MO, `cổng ghi mở không có lý do: ${k}`);
  }
  // Và chặn chiều ngược lại: không cổng GẮN hay GỠ khuôn mặt nào được mở.
  for (const k of mo) {
    assert.ok(
      !/khuon-mat\/(dang-ky|may)/.test(k),
      `cổng gắn hoặc gỡ khuôn mặt bị mở công khai: ${k}`,
    );
  }
});

test('Cổng tạo tài khoản ở mức quản trị — đây chính là lỗ thủng cũ', () => {
  assert.equal(cq.mucCua(R('POST', '/accounts', 'ACCOUNTS')), 'quan-tri');
  assert.equal(cq.CONG_KHAI.has('POST /accounts'), false);
});

test('Kho học liệu không mở: đề bài kèm đáp án và có cả cổng ghi', () => {
  assert.equal(cq.mucCua(R('GET', '/bank/items', 'CURRICULUM')), 'giao-vien');
  assert.equal(cq.mucCua(R('GET', '/bank/items/:id', 'CURRICULUM')), 'giao-vien');
  assert.equal(cq.mucCua(R('POST', '/bank/items/:id/publish', 'CURRICULUM')), 'quan-tri');
  assert.equal(cq.mucCua(R('POST', '/bank/items/:id/retire', 'CURRICULUM')), 'quan-tri');
});

test('Cổng gọi mô hình ngôn ngữ không mở — mở cho người lạ là mở ví', () => {
  assert.equal(cq.mucCua(R('POST', '/chat', 'CORE')), 'giao-vien');
});

test('Dữ liệu tâm lý học đường đòi đăng nhập', () => {
  assert.equal(cq.mucCua(R('POST', '/khao-sat/tam-ly/cham', 'KHAOSAT')), 'hoc-vien');
});

test('Thứ bậc quyền: vai thấp không với tới cổng của vai cao', () => {
  const N = { accounts: { session: () => ({ role: 'LEARNER', user: { id: 'U1' } }) } };
  const hd = { authorization: 'Bearer x' };
  assert.equal(cq.kiemQuyen(N, R('GET', '/nha-nao-do', 'PRACTICE'), hd, {}).ok, true);
  const chan = cq.kiemQuyen(N, R('GET', '/agents', 'AGENTS'), hd, {});
  assert.equal(chan.ok, false);
  assert.equal(chan.status, 403);
  // Lời từ chối KHÔNG nói cổng này thuộc về vai nào — nói ra là vẽ đường cho người dò.
  assert.equal(/quản trị|ADMIN|admin/.test(chan.reason), false, `lời từ chối lộ vai: ${chan.reason}`);
});

test('Không phiên đăng nhập thì 401, không phải 403', () => {
  const N = { accounts: { session: () => null } };
  const r = cq.kiemQuyen(N, R('GET', '/agents', 'AGENTS'), {}, {});
  assert.equal(r.ok, false);
  assert.equal(r.status, 401);
  assert.equal(r.error, 'CHƯA_ĐĂNG_NHẬP');
});

test('Cổng công khai không đòi phiên', () => {
  const N = { accounts: { session: () => null } };
  for (const k of ['GET /', 'GET /api', 'GET /health']) {
    const [method, pattern] = k.split(' ');
    assert.equal(cq.kiemQuyen(N, R(method, pattern, 'CORE'), {}, {}).ok, true, `${k} bị chặn`);
  }
});

test('Cửa khởi tạo: chỉ mở khi chưa có quản trị, chỉ cho vai ADMIN, chỉ đúng cổng ấy', () => {
  const gia = (so) => ({ accounts: { list: () => ({ total: so, items: [] }) } });
  const cong = R('POST', '/accounts', 'ACCOUNTS');
  assert.equal(cq.laCuaKhoiTao(gia(0), cong, { role: 'ADMIN' }), true);
  assert.equal(cq.laCuaKhoiTao(gia(1), cong, { role: 'ADMIN' }), false);
  assert.equal(cq.laCuaKhoiTao(gia(0), cong, { role: 'TEACHER' }), false);
  assert.equal(cq.laCuaKhoiTao(gia(0), cong, {}), false);
  assert.equal(cq.laCuaKhoiTao(gia(0), R('GET', '/agents', 'AGENTS'), { role: 'ADMIN' }), false);
  // Kho tài khoản hỏng thì cửa ĐÓNG, không mở vì "không đếm được".
  assert.equal(cq.laCuaKhoiTao({ accounts: { list() { throw new Error('hỏng'); } } }, cong, { role: 'ADMIN' }), false);
});

test('Cửa khởi tạo đi qua kiemQuyen thì được đánh dấu để ghi nhật ký', () => {
  const N = { accounts: { session: () => null, list: () => ({ total: 0, items: [] }) } };
  const r = cq.kiemQuyen(N, R('POST', '/accounts', 'ACCOUNTS'), {}, { role: 'ADMIN' });
  assert.equal(r.ok, true);
  assert.equal(r.khoiTao, true);
});

test('Phiên đọc được từ cả cookie lẫn header', () => {
  const N = { accounts: { session: (t) => (t === 'abc' ? { role: 'ADMIN' } : null) } };
  assert.ok(cq.phienCua(N, { cookie: 'gita_token=abc; khac=1' }));
  assert.ok(cq.phienCua(N, { authorization: 'Bearer abc' }));
  assert.equal(cq.phienCua(N, { authorization: 'Bearer sai' }), null);
  assert.equal(cq.phienCua(N, {}), null);
});
