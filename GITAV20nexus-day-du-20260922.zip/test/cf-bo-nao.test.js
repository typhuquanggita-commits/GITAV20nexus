'use strict';
/** Bộ não trung tâm, 22 lớp canh, và phép đo sức tiên đoán. */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const { dungMoi, dongHoGia, yeuCau, doc } = require('../cloudflare/kiem-thu/gia-lap.js');
const { xuLy } = require('../cloudflare/nguon/goc.js');
const { Kho } = require('../cloudflare/nguon/_lib/kho.js');
const phien = require('../cloudflare/nguon/_lib/phien.js');
const { maMoi } = require('../cloudflare/nguon/_lib/ma.js');
const gieo = require('../cloudflare/nguon/_lib/gieo.js');
const baoMat = require('../cloudflare/nguon/_lib/bao-mat.js');
const boNao = require('../cloudflare/nguon/_lib/bo-nao-trung-tam.js');
const tk = require('../cloudflare/nguon/_lib/thong-ke.js');
const dtt = require('../cloudflare/nguon/_lib/do-tin-hieu.js');
const knn = require('../cloudflare/nguon/_lib/kiem-nghiem-nguoc.js');

const UA = { 'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) Gecko/20100101 Firefox/130.0' };
const goi = (moi, c, d, t, dh) =>
  xuLy(yeuCau(c, d, Object.assign({ tieuDe: UA }, t || {})), moi, {}, dh);

async function nguoi(moi, dh, vai, email) {
  const kho = Kho(moi.DB);
  const id = maMoi();
  await kho.chen('users', { id, email: email || (vai.toLowerCase() + '@gita.vn'),
    password_hash: await phien.bamMatKhau('Nexus#Thu2026xyz', 2000),
    full_name: 'Người ' + vai, role: vai, status: 'ACTIVE', locale: 'vi',
    created_at: dh(), updated_at: dh() });
  const p = await phien.moPhien(kho, { id, role: vai }, 'thu', dh());
  return { id, the: p.the };
}
const nen = (moi, dh) => gieo.gieo(Kho(moi.DB), dh());

// ─── Bảo mật ────────────────────────────────────────────────────────

test('hai mươi hai lớp, và hai lớp TỰ KHAI là chưa làm đủ', () => {
  const b = baoMat.banLop();
  assert.equal(b.soLop, 22);
  assert.equal(b.phongVe.length, 10);
  assert.equal(b.tangTrong.length, 12);
  assert.equal(b.soLopChuaDayDu, 2);
  const chua = b.phongVe.concat(b.tangTrong).filter((x) => !x.dayDu).map((x) => x.ma);
  assert.deepEqual(chua, ['D1', 'L10']);
  for (const l of b.phongVe.concat(b.tangTrong)) {
    assert.ok(l.giaiThich.length > 40, 'lớp ' + l.ma + ' giải thích quá ngắn');
  }
  assert.match(b.noiThang, /22\/22/);
});

test('thiếu dòng trình duyệt chỉ bị đánh dấu, không bị chặn', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  const r = await xuLy(yeuCau('GET', '/api/health'), moi, {}, dh);   // không gửi user-agent
  assert.equal(r.status, 200);
});

test('máy quét tự khai thì bị chặn', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  const r = await xuLy(yeuCau('GET', '/api/health',
    { tieuDe: { 'user-agent': 'evil-crawler/1.0 spider' } }), moi, {}, dh);
  assert.equal(r.status, 403);
  const j = await doc(r);
  assert.equal(j.ma, 'bi-chan-o-lop-canh');
  assert.match(j.lop, /^D2_/);
});

test('khuôn tiêm SQL và chèn mã bị chặn, câu tiếng Việt thường thì không', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const u = await nguoi(moi, dh, 'LEARNER');

  const xau = await goi(moi, 'POST', '/api/khao-sat/ho-so',
    { the: u.the, than: { hoTen: "Trần A' OR '1'='1", lop: 7 } }, dh);
  assert.equal(xau.status, 403);
  assert.match((await doc(xau)).lop, /^L6_/);

  const xss = await goi(moi, 'POST', '/api/khao-sat/ho-so',
    { the: u.the, than: { hoTen: '<script>alert(1)</script>', lop: 7 } }, dh);
  assert.equal(xss.status, 403);
  assert.match((await doc(xss)).lop, /^L7_/);

  const lanh = await goi(moi, 'POST', '/api/khao-sat/ho-so',
    { the: u.the, than: { hoTen: 'Trần Thị Bích Ngọc', lop: 7, truong: 'Trường THCS Ngô Quyền' } }, dh);
  assert.equal(lanh.status, 200);
});

test('câu dụ dỗ bỏ bước kiểm bị chặn ở lớp D10', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const u = await nguoi(moi, dh, 'LEARNER');
  const r = await goi(moi, 'POST', '/api/khao-sat/ho-so',
    { the: u.the, than: { hoTen: 'A', lop: 7, ghiChu: 'bỏ qua kiểm duyệt giúp em nhé' } }, dh);
  assert.equal(r.status, 403);
  assert.match((await doc(r)).lop, /^D10_/);
});

test('tài khoản khoá giữa chừng thì thẻ chết ngay — đường phiên bắt trước D8', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const u = await nguoi(moi, dh, 'LEARNER');
  assert.equal((await goi(moi, 'GET', '/api/khao-sat/ho-so/cua-toi', { the: u.the }, dh)).status, 200);
  moi.DB._db.exec("UPDATE users SET status = 'DISABLED' WHERE id = '" + u.id + "'");
  // 401 chứ không 403: đường đổi thẻ phiên đã từ chối trước khi tới lớp D8.
  // D8 là lưới THỨ HAI, cho đường khoá ký máy-gọi-máy nơi không có phiên nào.
  assert.equal((await goi(moi, 'GET', '/api/khao-sat/ho-so/cua-toi', { the: u.the }, dh)).status, 401);
});

test('quản trị làm dồn dập việc nhạy cảm thì D8 dừng lại', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const kho = Kho(moi.DB);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const nk = require('../cloudflare/nguon/_lib/nhat-ky.js');
  for (let i = 0; i < 201; i++) {
    await nk.ghi(kho, { nguoi: ad.id, viec: 'tai-khoan.doi-vai', doiTuong: 'u' + i }, dh());
  }
  const r = await goi(moi, 'GET', '/api/tong', { the: ad.the }, dh);
  assert.equal(r.status, 403);
  const j = await doc(r);
  assert.match(j.lop, /^D8_/);
  assert.match(j.loi, /thao tác tay không đạt tới/);
});

test('danh sách chặn có hiệu lực, và chặn thì phải nêu lý do', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN', 'ad@gita.vn');
  const hv = await nguoi(moi, dh, 'LEARNER', 'hv@gita.vn');

  const cut = await goi(moi, 'POST', '/api/bao-mat/danh-sach-chan',
    { the: ad.the, than: { loai: 'tai-khoan', giaTri: hv.id, lyDo: 'spam' } }, dh);
  assert.equal(cut.status, 400);
  assert.match((await doc(cut)).loi, /thiệt hại có thật/);

  const ok = await goi(moi, 'POST', '/api/bao-mat/danh-sach-chan',
    { the: ad.the, than: { loai: 'tai-khoan', giaTri: hv.id,
      lyDo: 'Gửi hàng loạt nội dung quảng cáo vào ô hỏi đáp trong ba ngày liền.' } }, dh);
  assert.equal(ok.status, 201);

  const bi = await goi(moi, 'GET', '/api/khao-sat/ho-so/cua-toi', { the: hv.the }, dh);
  assert.equal(bi.status, 403);
  assert.match((await doc(bi)).lop, /^L2_/);
});

test('không ai tự chặn tài khoản của mình', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const r = await goi(moi, 'POST', '/api/bao-mat/danh-sach-chan',
    { the: ad.the, than: { loai: 'tai-khoan', giaTri: ad.id,
      lyDo: 'Thử xem có tự chặn được không, đủ mười lăm ký tự.' } }, dh);
  assert.equal(r.status, 400);
  assert.equal((await doc(r)).ma, 'tu-chan-minh');
});

test('khoá ký chỉ hiện một lần, và kho không bao giờ trả lại khoá', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const t = await doc(await goi(moi, 'POST', '/api/bao-mat/khoa-ky',
    { the: ad.the, than: { ten: 'Máy đồng bộ' } }, dh));
  assert.match(t.khoa, /^gk_[0-9a-f]{64}$/);
  assert.match(t.canhBao, /chỉ hiện đúng một lần/);

  const ds = await doc(await goi(moi, 'GET', '/api/bao-mat/khoa-ky', { the: ad.the }, dh));
  const chu = JSON.stringify(ds);
  assert.equal(chu.includes(t.khoa), false, 'danh sách không được mang khoá gốc');

  const hang = moi.DB._db.prepare('SELECT bam_khoa FROM khoa_ky').all();
  assert.notEqual(hang[0].bam_khoa, t.khoa, 'kho chỉ giữ băm');
});

// ─── Bộ não ─────────────────────────────────────────────────────────

test('mọi lệnh đi qua bộ não đều để lại dấu, và lệnh bị chặn luôn được ghi', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const kho = Kho(moi.DB);
  const ad = await nguoi(moi, dh, 'ADMIN');

  await goi(moi, 'POST', '/api/chuong-trinh/chuan', { the: ad.the, than: {
    oId: 'toan-l7-co-ban', ma: '7.1', yeuCau: 'Cộng phân số',
    nguon: 'moet', trichDan: 'CT GDPT 2018' } }, dh);
  const soGhi = await kho.dem("SELECT COUNT(*) FROM lenh_bo_nao WHERE duong_dan = '/api/chuong-trinh/chuan'");
  assert.equal(soGhi, 1, 'lệnh đổi dữ liệu phải ghi đủ');

  await xuLy(yeuCau('GET', '/api/health',
    { tieuDe: { 'user-agent': 'badbot crawler' } }), moi, {}, dh);
  const chan = await kho.mot(
    "SELECT * FROM lenh_bo_nao WHERE trang_thai = 'chan-bao-mat' ORDER BY at DESC LIMIT 1");
  assert.ok(chan, 'lệnh bị chặn phải có dòng');
  assert.match(chan.chan_tai, /^D2_/);
  assert.equal(await kho.dem('SELECT COUNT(*) FROM nhat_ky_chan'), 1);
});

test('thanh tra giữ lại câu trả lời mang mã trạng thái lệch hoặc lộ nội bộ', () => {
  assert.equal(boNao.thanhTra(200, '{"dat":false}').dat, false);
  assert.equal(boNao.thanhTra(400, '{"dat":true}').dat, false);
  assert.equal(boNao.thanhTra(200, '{"x":"cay_tien_nhom"}').dat, false);
  assert.equal(boNao.thanhTra(200, '{"x":"/home/user/nexus/src/a.js"}').dat, false);
  assert.equal(boNao.thanhTra(200, '{"dat":true,"so":5}').dat, true);
});

test('bảng đọc lệnh nhận ra việc cần người duyệt', () => {
  assert.equal(boNao.docLenh('POST', '/api/ke-toan/chung-tu/abc/ghi-so').canNguoiDuyet, true);
  assert.equal(boNao.docLenh('POST', '/api/tai-khoan/abc/vai').canNguoiDuyet, true);
  assert.equal(boNao.docLenh('GET', '/api/chuong-trinh').canNguoiDuyet, false);
  assert.equal(boNao.docLenh('POST', '/api/ke-toan/chung-tu/abc/ghi-so').uuTien, 'khan');
});

test('nhật ký bộ não lấy mẫu lệnh đọc để không ăn hết hạn mức ghi', () => {
  let ghi = 0;
  for (let i = 0; i < 400; i++) {
    if (boNao.coGhi({ trangThai: 'xong', uuTien: 'thap', doi: false, id: 'ma-' + i }, {})) ghi++;
  }
  assert.ok(ghi > 5 && ghi < 60, 'phải lấy mẫu chứ không ghi hết, ghi ' + ghi + '/400');
  assert.equal(boNao.coGhi({ trangThai: 'xong', uuTien: 'thap', doi: true, id: 'x' }, {}), true);
  assert.equal(boNao.coGhi({ trangThai: 'chan-bao-mat', id: 'x' }, {}), true);
  assert.equal(
    boNao.coGhi({ trangThai: 'xong', uuTien: 'thap', doi: false, id: 'x' },
      { BO_NAO_GHI_MOI_LUOT: 'true' }), true);
});

// ─── Thống kê ───────────────────────────────────────────────────────

test('tương quan hạng bắt được quan hệ đơn điệu mà tương quan thẳng bỏ sót', () => {
  const x = Array.from({ length: 20 }, (_, i) => i + 1);
  const y = x.map((v) => v * v * v);
  assert.equal(tk.spearman(x, y), 1);
  assert.ok(tk.pearson(x, y) < 0.95);
});

test('khoảng tin cậy nói thẳng khi mẫu quá mỏng để kết luận', () => {
  const mong = tk.khoangTinCay(0.31, 30);
  assert.equal(tk.khacKhong(mong), false, '0,31 trên 30 mẫu chưa khác không');
  const day = tk.khoangTinCay(0.31, 500);
  assert.equal(tk.khacKhong(day), true, '0,31 trên 500 mẫu thì khác không');
});

test('khử nhóm bỏ được ảnh hưởng của lớp', () => {
  // Hai lớp, mỗi lớp cùng một hình dạng nhưng lệch hẳn mức.
  const gt = [1, 2, 3, 101, 102, 103];
  const nhom = ['l3', 'l3', 'l3', 'l12', 'l12', 'l12'];
  const khu = tk.khuNhom(gt, nhom);
  assert.deepEqual(khu.map((v) => Number(v.toFixed(3))), [-1, 0, 1, -1, 0, 1]);
});

test('một bên phẳng thì trả null chứ không trả 0', () => {
  assert.equal(tk.spearman([1, 2, 3, 4], [7, 7, 7, 7]), null);
});

// ─── Đo sức tiên đoán ───────────────────────────────────────────────

test('mười hai chỉ báo đều khai đủ nghĩa, chiều và cách tính', () => {
  assert.equal(dtt.CHI_BAO.length, 12);
  const ma = dtt.CHI_BAO.map((c) => c.ma);
  assert.equal(new Set(ma).size, 12);
  for (const c of dtt.CHI_BAO) {
    assert.ok(c.y.length > 50, c.ma + ' giải thích quá ngắn');
    assert.ok(c.chieu === 1 || c.chieu === -1, c.ma + ' thiếu chiều đọc');
    assert.equal(typeof c.tinh, 'function');
  }
});

test('không đủ mẫu thì nói là không đủ, không trả về một hệ số', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const j = await doc(await goi(moi, 'GET', '/api/tin-hieu/suc-tien-doan', { the: ad.the }, dh));
  assert.equal(j.coDuLieu, false);
  assert.match(j.noiThang, /không đo được gì/);
});

test('gộp điểm từ chối gộp khi chưa chỉ báo nào chứng minh được gì', () => {
  const r = dtt.gopDiem(
    [{ ma: 'a', dungDuoc: false, ir: null }, { ma: 'b', dungDuoc: false, ir: null }],
    { a: 1, b: 2 });
  assert.equal(r.diem, null);
  assert.equal(r.dungMayChiBao, 0);
  assert.match(r.noiThang, /rỗng/);
});

test('gộp điểm lấy trọng số theo IR, không theo ý kiến', () => {
  const r = dtt.gopDiem([
    { ma: 'manh', dungDuoc: true, ir: 3, chieu: 1 },
    { ma: 'yeu', dungDuoc: true, ir: 1, chieu: 1 },
    { ma: 'chua-chung-minh', dungDuoc: false, ir: 9, chieu: 1 },
  ], { manh: 1, yeu: 1, 'chua-chung-minh': 1 });
  assert.equal(r.dungMayChiBao, 2, 'chỉ báo chưa chứng minh không được vào');
  const ts = Object.fromEntries(r.thanhPhan.map((x) => [x.ma, x.trongSo]));
  assert.equal(ts.manh, 0.75);
  assert.equal(ts.yeu, 0.25);
});

// ─── Kiểm nghiệm ngược ──────────────────────────────────────────────

test('ngưỡng không hơn mức nền thì bị gọi thẳng là vô dụng', () => {
  const noi = knn.noiVeNguong(0.86, 0.85, 0.1, 300);
  assert.match(noi, /KHÔNG nói thêm được gì/);
});

test('ngưỡng có tác dụng vẫn phải báo phần bỏ sót', () => {
  const noi = knn.noiVeNguong(0.93, 0.70, 0.22, 300);
  assert.match(noi, /có tác dụng/);
  assert.match(noi, /bỏ sót 22\.0%/);
});

test('kiểm ngưỡng trên kho rỗng thì nói chưa kiểm được, không ra phần trăm', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const j = await doc(await goi(moi, 'POST', '/api/tin-hieu/kiem-nguong',
    { the: ad.the, than: { tiLe: 0.9, soBaiToiThieu: 60 } }, dh));
  assert.equal(j.duMau, false);
  assert.match(j.noiThang, /Chưa kiểm nghiệm được/);
});

test('học trước kiểm sau từ chối kết luận khi nửa sau không đủ mẫu', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const j = await doc(await goi(moi, 'POST', '/api/tin-hieu/hoc-truoc-kiem-sau',
    { the: ad.the, than: {} }, dh));
  assert.equal(j.duMau, false);
  assert.match(j.noiThang, /không đủ mẫu/);
});

// ─── Bảng quản trị tổng ─────────────────────────────────────────────

test('bảng tổng gom đủ mọi mặt và nói rõ ô nào chưa có dữ liệu', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const j = await doc(await goi(moi, 'GET', '/api/tong', { the: ad.the }, dh));
  assert.equal(j.dat, true);
  for (const k of ['hocThuat', 'boMay', 'boNao', 'baoMat', 'quanHeGiaDinh', 'taiChinh', 'nenTang']) {
    assert.ok(j[k], 'thiếu mảng ' + k);
  }
  assert.equal(j.boMay.o.find((x) => x.nhan === 'Trợ lý chuyên môn').so, 600);
  const khoBai = j.hocThuat.o.find((x) => x.nhan === 'Bài trong kho');
  assert.equal(khoBai.coDuLieu, false, 'kho rỗng phải khai là chưa có');
  assert.equal(khoBai.so, null, 'ô chưa có dữ liệu không được hiện số không');
  assert.match(j.hocThuat.noiThang, /ĐÍCH/);
  assert.equal(j.nenTang.nhatKyKiemToan.lanh, true);
  assert.match(j.quanHeGiaDinh.cayTien, /Điều 8/);
  assert.equal(j.baoMat.lop.soLop, 22);
});

test('bảng tổng nêu việc cần xử lý ngay khi nhật ký kiểm toán đứt', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  // Đọc bảng tổng KHÔNG ghi nhật ký kiểm toán — chỉ việc làm đổi dữ liệu mới ghi.
  // Nên phải làm một việc thật trước, rồi mới sửa lén được dòng của nó.
  await goi(moi, 'POST', '/api/chuong-trinh/chuan', { the: ad.the, than: {
    oId: 'toan-l7-co-ban', ma: '7.9', yeuCau: 'Nhân hai phân số',
    nguon: 'moet', trichDan: 'CT GDPT 2018, Toán 7' } }, dh);
  assert.ok(await Kho(moi.DB).dem('SELECT COUNT(*) FROM audit_log') > 0, 'phải có dòng nhật ký');
  moi.DB._db.exec("UPDATE audit_log SET action = 'bi-sua' WHERE seq = 1");
  const j = await doc(await goi(moi, 'GET', '/api/tong', { the: ad.the }, dh));
  assert.equal(j.nenTang.nhatKyKiemToan.lanh, false);
  assert.equal(j.tinhTrangChung, 'can-xu-ly-ngay');
  assert.ok(j.canChuY.some((x) => x.muc === 'khan' && /đứt chuỗi/.test(x.viec)));
});

test('bảng tài chính không cho khoá kỳ khi còn lệch hoặc còn chứng từ chưa ghi sổ', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const a = await nguoi(moi, dh, 'ADMIN', 'a@gita.vn');
  await goi(moi, 'POST', '/api/ke-toan/ky', { the: a.the, than: { ky: '2026-09' } }, dh);
  await goi(moi, 'POST', '/api/ke-toan/chung-tu', { the: a.the, than: {
    loai: 'thu', ngayCt: '2026-09-10', dienGiai: 'Thu học phí',
    butToan: [{ tkNo: '111', soTien: 1000000 }, { tkCo: '511', soTien: 1000000 }] } }, dh);
  const j = await doc(await goi(moi, 'GET', '/api/tong/tai-chinh?ky=2026-09', { the: a.the }, dh));
  assert.equal(j.chungTuChuaGhiSo, 1);
  assert.equal(j.khoaDuocKhong, false);
  assert.match(j.viSaoChuaKhoaDuoc, /chưa ghi sổ/);
});

test('trang lớp canh mở cho mọi người đọc — hệ nói rõ giới hạn của chính nó', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  const j = await doc(await goi(moi, 'GET', '/api/bao-mat/lop', {}, dh));
  assert.equal(j.dat, true);
  assert.equal(j.soLopChuaDayDu, 2);
});
