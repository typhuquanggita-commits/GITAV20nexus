'use strict';
/**
 * Bản ghép _worker.js — thứ THẬT SỰ chạy trên Cloudflare.
 *
 * Phép thử ở các tệp khác nạp mã nguồn bằng require của Node. Tệp này
 * nạp đúng tệp đã ghép, bằng đúng cách workerd nạp nó (mô-đun ES,
 * export default), rồi bắn yêu cầu vào. Nếu bộ ghép làm hỏng thứ gì
 * thì chỗ này thấy, còn các tệp kia thì không.
 */
const { test, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { pathToFileURL } = require('node:url');

const { chay } = require('../cloudflare/dung-worker.js');
const { dungMoi, dongHoGia, yeuCau, doc } = require('../cloudflare/kiem-thu/gia-lap.js');
const { Kho } = require('../cloudflare/nguon/_lib/kho.js');
const gieo = require('../cloudflare/nguon/_lib/gieo.js');
const phien = require('../cloudflare/nguon/_lib/phien.js');
const { maMoi } = require('../cloudflare/nguon/_lib/ma.js');

let worker, banGhep, duongMjs;

before(async () => {
  banGhep = chay();
  // workerd nạp _worker.js như một mô-đun ES. Đổi đuôi sang .mjs để Node
  // cũng nạp đúng như thế, thay vì đoán theo package.json.
  const thu = fs.mkdtempSync(path.join(os.tmpdir(), 'gita-ghep-'));
  duongMjs = path.join(thu, 'worker.mjs');
  fs.copyFileSync(path.join(__dirname, '..', 'cloudflare', 'dist', '_worker.js'), duongMjs);
  worker = (await import(pathToFileURL(duongMjs).href)).default;
});

test('bản ghép nạp được như một mô-đun ES và có đủ fetch, scheduled', () => {
  assert.equal(typeof worker.fetch, 'function');
  assert.equal(typeof worker.scheduled, 'function');
  assert.ok(banGhep.soMoDun >= 40, 'phải ghép đủ mô-đun, có ' + banGhep.soMoDun);
});

test('bản ghép không mang theo mô-đun lõi Node nào chạy được', () => {
  const ma = fs.readFileSync(duongMjs, 'utf8');
  // Chỉ còn tên trong chuỗi của bản giả và trong mã nguồn đã bọc —
  // không có câu import nào ở tầng cao nhất.
  assert.equal(/^import\s/m.test(ma), false, 'bản ghép không được có import tầng cao nhất');
  assert.equal(ma.includes('export default __goc.worker;'), true);
});

test('bản ghép trả lời được yêu cầu thật, với kho D1 thật', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  const r = await worker.fetch(yeuCau('GET', '/api/health'), moi, {});
  const j = await doc(r);
  assert.equal(r.status, 200);
  assert.equal(j.bo_phan.kho.dat, true);
  assert.ok(j.bo_phan.kho.soBang >= 200, 'kho phải có đủ bảng');
});

test('bản ghép chạy đủ đường đăng ký, đăng nhập, đọc hồ sơ', async () => {
  const moi = dungMoi();
  const MK = 'Nexus#BanGhep2026';
  const dk = await worker.fetch(yeuCau('POST', '/api/tai-khoan/dang-ky',
    { than: { email: 'ghep@gita.vn', ten: 'Người Ghép', matKhau: MK } }), moi, {});
  assert.equal(dk.status, 201);

  const dn = await doc(await worker.fetch(yeuCau('POST', '/api/tai-khoan/dang-nhap',
    { than: { email: 'ghep@gita.vn', matKhau: MK } }), moi, {}));
  assert.ok(dn.the);

  const toi = await doc(await worker.fetch(yeuCau('GET', '/api/tai-khoan/toi',
    { the: dn.the }), moi, {}));
  assert.equal(toi.toi.email, 'ghep@gita.vn');
});

test('bản ghép chạy được phần miền: gieo, chương trình, bộ não, hiến pháp', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await gieo.gieo(Kho(moi.DB), dh());

  const ct = await doc(await worker.fetch(yeuCau('GET', '/api/chuong-trinh'), moi, {}));
  assert.equal(ct.mon.length, 3);
  assert.equal(ct.capDo.length, 7);

  const hp = await doc(await worker.fetch(yeuCau('GET', '/api/bo-nao/hien-phap'), moi, {}));
  assert.ok(hp.soDieu >= 15);
  assert.ok(hp.nguonPhapLy.vietNam.length >= 10);

  // Bản ghép chạy bằng đồng hồ thật của máy — nó không nhận đồng hồ giả
  // qua fetch. Nên phiên phải mở bằng thời gian thật, không thì nó đã
  // hết hạn trước khi bản ghép kịp đọc.
  const kho = Kho(moi.DB);
  const id = maMoi();
  const bayGio = Date.now();
  await kho.chen('users', { id, email: 'ad@gita.vn',
    password_hash: await phien.bamMatKhau('x', 2000), full_name: 'Quản trị',
    role: 'ADMIN', status: 'ACTIVE', locale: 'vi', created_at: bayGio, updated_at: bayGio });
  const p = await phien.moPhien(kho, { id, role: 'ADMIN' }, 'thu', bayGio);
  const bn = await doc(await worker.fetch(yeuCau('GET', '/api/bo-nao', { the: p.the }), moi, {}));
  assert.equal(bn.tongTroLy, 600);
  assert.equal(bn.khopBangKhai, true);
});

test('bản ghép giao tệp tĩnh cho ASSETS, không tự trả lời', async () => {
  const moi = dungMoi();
  const r = await worker.fetch(yeuCau('GET', '/ho-so.html'), moi, {});
  assert.equal(await r.text(), 'tep-tinh:/ho-so.html');
});

test('bản ghép nói đúng khi chưa gắn D1', async () => {
  const moi = dungMoi(); moi.DB = null;
  const j = await doc(await worker.fetch(yeuCau('GET', '/api/health'), moi, {}));
  assert.equal(j.ma, 'chua-gan-kho');
  assert.match(j.loi, /D1 database bindings/);
});

test('lịch dọn dẹp chạy được trong bản ghép', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await gieo.gieo(Kho(moi.DB), dh());
  await worker.scheduled({ cron: '0 3 * * *' }, moi, {});   // không được ném
  assert.ok(true);
});

test('nhánh chỉ chạy được trên Node ném lỗi nói rõ, không âm thầm hỏng', async () => {
  const ma = fs.readFileSync(duongMjs, 'utf8');
  assert.match(ma, /Tầng Cloudflare không có/);
  assert.match(ma, /chỉ chạy được trên máy chủ Node/);
});
