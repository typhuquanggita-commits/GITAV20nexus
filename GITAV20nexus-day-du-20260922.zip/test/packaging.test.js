'use strict';
/** Đóng gói và tài liệu vận hành: cài được, chạy được, người vận hành đọc được. */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.join(__dirname, '..');
const read = (...p) => fs.readFileSync(path.join(ROOT, ...p), 'utf8');

test('sổ tay vận hành trả lời đủ những câu hỏi lúc có sự cố', () => {
  const rb = read('RUNBOOK.md');
  const musts = [
    'Quên mật khẩu Super Admin',
    'Hệ thống chậm hoặc từ chối việc',
    'Nghi ngờ dữ liệu bị sửa',
    'Khôi phục về một thời điểm',
    'Kho học liệu hết bài',
    'Sao lưu',
  ];
  for (const m of musts) assert.ok(rb.includes(m), `sổ tay thiếu mục "${m}"`);
  assert.ok(rb.length > 4000, 'sổ tay quá sơ sài');
});

test('sổ tay nêu rõ những điều hệ thống KHÔNG làm', () => {
  const rb = read('RUNBOOK.md');
  assert.ok(rb.includes('không** làm') || rb.includes('KHÔNG** làm'), 'thiếu mục giới hạn');
  for (const m of ['Không kết tội học viên', 'Không tự phát hành', 'Không kết luận từ mẫu nhỏ']) {
    assert.ok(rb.includes(m), `thiếu giới hạn "${m}"`);
  }
});

test('mọi lệnh npm nêu trong tài liệu đều tồn tại thật', () => {
  const pkg = JSON.parse(read('package.json'));
  const docs = read('README.md') + read('RUNBOOK.md');
  // Lớp ký tự PHẢI có dấu gạch nối. Bản đầu viết [a-z:]+ nên "npm run
  // hang-rao" bị cắt thành "hang", rồi mục kiểm báo rằng tài liệu nhắc một
  // lệnh không tồn tại — trong khi lệnh ấy có thật và tài liệu viết đúng.
  //
  // Mục kiểm đọc sai đầu vào thì nó không canh tài liệu nữa; nó canh chính
  // cái biểu thức của nó. Và nó chỉ lộ ra khi có người đặt tên lệnh bằng hai
  // từ — tức là muộn.
  const mentioned = [...new Set([...docs.matchAll(/npm run ([a-z][a-z0-9:-]*)/g)].map((m) => m[1]))];
  for (const s of mentioned) {
    assert.ok(pkg.scripts[s], `tài liệu nhắc "npm run ${s}" nhưng package.json không có`);
  }
  assert.ok(mentioned.length >= 4);
});

test('mọi script trong package.json đều trỏ tới tệp có thật', () => {
  const pkg = JSON.parse(read('package.json'));
  for (const [name, cmd] of Object.entries(pkg.scripts)) {
    const m = cmd.match(/(?:node|bash)\s+(?:--\S+\s+)*([^\s'"]+)/);
    if (!m || m[1].includes('*') || m[1] === '-e') continue;
    assert.ok(fs.existsSync(path.join(ROOT, m[1])), `script "${name}" trỏ tới tệp không có: ${m[1]}`);
  }
});

test('bản cài Windows đóng gói đủ mọi thứ cần để chạy độc lập', () => {
  const pkg = JSON.parse(read('desktop', 'package.json'));
  const needed = ['../src', '../ui', '../package.json'];
  const froms = pkg.build.extraResources.map((r) => r.from);
  for (const n of needed) assert.ok(froms.includes(n), `bản cài thiếu ${n}`);
  for (const r of pkg.build.extraResources) {
    assert.ok(fs.existsSync(path.join(ROOT, 'desktop', r.from)), `tài nguyên không tồn tại: ${r.from}`);
  }
  assert.ok(froms.includes('../RUNBOOK.md'), 'bản cài nên kèm sổ tay vận hành');
});

test('bản cài mở cổng chọn vai, không ném thẳng người dùng vào console quản trị', () => {
  const main = read('desktop', 'main.js');
  assert.match(main, /cong\.html/, 'cửa sổ phải mở trang chọn vai');
  for (const page of ['hoc-vien.html', 'giao-vien.html', 'index.html']) {
    assert.ok(main.includes(page), `menu thiếu lối vào ${page}`);
  }
});

test('.env.example ghi đủ biến mà mã thật có đọc', () => {
  const env = read('.env.example');
  const src = [];
  const walk = (d) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) walk(p);
      else if (e.name.endsWith('.js')) src.push(fs.readFileSync(p, 'utf8'));
    }
  };
  walk(path.join(ROOT, 'src'));
  const used = new Set([...src.join('\n').matchAll(/process\.env\.([A-Z][A-Z0-9_]+)/g)].map((m) => m[1]));
  // Những biến do Node hoặc hệ điều hành đặt thì không cần ghi vào mẫu.
  // PATH là biến của hệ điều hành — dùng để dò xem edge-tts đã cài chưa,
  // không phải thứ người dùng đặt trong .env.
  const skip = new Set(['NODE_ENV', 'GEMINI_API_KEY', 'PATH']);
  const missing = [...used].filter((v) => !skip.has(v) && !env.includes(v));
  assert.deepEqual(missing, [], `.env.example thiếu: ${missing.join(', ')}`);
});

test('README phản ánh đúng quy mô thật của hệ thống', () => {
  const rd = read('README.md');
  const { FORMS } = require('../src/curriculum/hierarchy');
  const { BLUEPRINTS } = require('../src/content/blueprint');
  assert.ok(rd.includes(`${FORMS.length} dạng`), `README nói sai số dạng (thật: ${FORMS.length})`);
  assert.ok(rd.includes(`${BLUEPRINTS.length} bản thiết kế`), `README nói sai số bản thiết kế (thật: ${BLUEPRINTS.length})`);
  assert.ok(rd.includes('RUNBOOK.md'), 'README phải trỏ tới sổ tay vận hành');
});

test('không còn thư mục dữ liệu thật lọt vào kho mã', () => {
  const ignore = read('.gitignore');
  for (const p of ['data/', 'node_modules/', '.env']) {
    assert.ok(ignore.includes(p), `.gitignore thiếu ${p}`);
  }
});
