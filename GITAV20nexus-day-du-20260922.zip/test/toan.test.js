'use strict';
// Kho dữ liệu RIÊNG cho lần chạy này. Bộ kiểm mà ghi thẳng vào data/db thì nó
// vừa làm bẩn dữ liệu thật (tài khoản kiểm thử ở lại, cửa khởi tạo đóng luôn
// cho lần sau), vừa có quyền xoá và nén ảnh chụp của dữ liệu thật. Đặt biến
// môi trường TRƯỚC khi require('../src/index'), vì tầng dữ liệu đọc chúng ngay
// lúc nạp mô-đun.
const _tmpKho = require('node:fs').mkdtempSync(require('node:path').join(require('node:os').tmpdir(), 'gita-test-'));
process.env.DB_DIR = require('node:path').join(_tmpKho, 'db');
process.env.SNAPSHOT_DIR = require('node:path').join(_tmpKho, 'snap');

/**
 * CHUẨN KÝ HIỆU TOÁN VÀ NHÀ KHOA HỌC TOÁN
 *
 * Mọi mục ở đây kiểm bằng kết quả đo được: ký hiệu ra đúng ký tự Unicode nào,
 * câu đọc lên thành lời gì, nghiệm thay ngược vào phương trình có đúng không.
 * Không mục nào chỉ hỏi "hàm có chạy không".
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const K = require('../src/math/kyhieu');
const { kiemVanPhong } = require('../src/math/vanphong');
const { thamDinh, rutPhuongTrinh, rutTapNghiem } = require('../src/math/thamdinh');
const { MathScientist, PHUONG_PHAP, soDep } = require('../src/math/scientist');
const CHU = require('../src/photo/chu');
const { toSpeech } = require('../src/voice/speech-text');

// ═══ CẤP 1 — KÝ HIỆU ═══════════════════════════════════════════════════════

test('Lối viết của máy được đổi sang ký hiệu toán quốc tế', () => {
  assert.equal(K.chuanHoa('x^2 - 5x + 6 = 0'), 'x² − 5x + 6 = 0');
  assert.equal(K.chuanHoa('x_1 = 3'), 'x₁ = 3');
  assert.equal(K.chuanHoa('x^(n+1)'), 'x⁽ⁿ⁺¹⁾');
  assert.equal(K.chuanHoa('2^10'), '2¹⁰');
  assert.equal(K.chuanHoa('Delta = b^2 - 4ac'), '∆ = b² − 4ac');
  assert.equal(K.chuanHoa('sqrt(x+1)'), '√(x + 1)');
  assert.equal(K.chuanHoa('vec(AB)'), 'AB⃗');
  assert.equal(K.chuanHoa('abs(x)'), '|x|');
  assert.equal(K.chuanHoa('a <= b != c'), 'a ≤ b ≠ c');
  // Δ (chữ cái Hy Lạp) và ∆ (ký hiệu toán) là hai ký tự khác nhau.
  assert.equal(K.chuanHoa('Δ = 1'), '∆ = 1');
  assert.notEqual('Δ', '∆');
});

test('LaTeX dựng thành ký hiệu phẳng, có bọc ngoặc đúng chỗ', () => {
  assert.equal(K.chuanHoa('\\dfrac{-b+\\sqrt{\\Delta}}{2a}'), '(−b + √∆)⁄(2a)');
  assert.equal(K.chuanHoa('\\dfrac{1}{2}'), '½');
  assert.equal(K.chuanHoa('\\dfrac{x_1+x_2}{2}'), '(x₁ + x₂)⁄2');
  assert.equal(K.chuanHoa('x \\in \\mathbb{R}'), 'x ∈ ℝ');
  // Mẫu là một tích thì BẮT BUỘC có ngoặc: a⁄2b đọc được hai nghĩa.
  assert.match(K.chuanHoa('\\dfrac{a}{2b}'), /a⁄\(2b\)/);
});

test('Dấu / và − trong tiếng Việt KHÔNG bị đổi bừa', () => {
  // Đây là chỗ một bộ chuẩn hoá cẩu thả sẽ phá hỏng văn bản.
  for (const t of ['Ngày 20/11 xe chạy 60 km/h', 'Bài 3-4 trang 5',
    'đen-ta và cô-sin', 'Xem http://gita.vn/a/b', 'và/hoặc', 'Tầng 2-5']) {
    assert.equal(K.chuanHoa(t), t, `đã làm hỏng: "${t}"`);
  }
  // Nhưng trong ngữ cảnh toán thì phải đổi.
  assert.equal(K.chuanHoa('1/2 + 3/4'), '½ + ¾');
  assert.equal(K.chuanHoa('5 - 3 = 2'), '5 − 3 = 2');
});

test('Không nuốt ký tự khi Unicode không có bản mũ tương ứng', () => {
  // "q" không có dạng mũ trong Unicode. Nuốt mất là đổi nghĩa công thức.
  assert.equal(K.chuanHoa('x^q'), 'x^q');
  assert.equal(K.kiemKyHieu('x^q').ok, false, 'phải báo để người soạn biết mà sửa');
});

test('Bộ soát ký hiệu chỉ ra đúng chỗ sai và cách sửa', () => {
  const r = K.kiemKyHieu('Ta có x^2 và sqrt(9), Δ = 1, a/b');
  assert.equal(r.ok, false);
  const ma = r.loi.map((l) => l.ma);
  for (const m of ['MU_THO', 'CAN_THO', 'DELTA_SAI', 'CHIA_THO']) assert.ok(ma.includes(m), `thiếu ${m}`);
  for (const l of r.loi) assert.ok(l.cach && l.cach.length > 4, 'lỗi nào cũng phải kèm cách sửa');
  assert.equal(K.kiemKyHieu('x² − 5x + 6 = 0 với x ∈ ℝ').ok, true);
});

test('Đường về: ký hiệu phẳng đọc lại được bằng máy', () => {
  assert.equal(K.veAscii('x² − 5x + 6 = 0'), 'x^(2) - 5x + 6 = 0');
  assert.equal(K.veAscii('(−b + √∆)⁄(2a)'), '(-b + sqrt(Delta))/(2a)');
  assert.equal(K.veAscii('½'), '(1/2)');
});

// ═══ ĐỌC THÀNH LỜI ═════════════════════════════════════════════════════════

test('Công thức Unicode đọc lên thành tiếng Việt đúng, không nuốt dấu mũ', () => {
  const doc = (t) => toSpeech(t).text;
  assert.match(doc('Ta có ∆ = b² − 4ac = 1 > 0.'), /đen-ta bằng bê bình phương trừ bốn ac/);
  assert.match(doc('x₁ = 3'), /ích một bằng ba/);
  assert.match(doc('Diện tích bằng πr².'), /pi .*bình phương/);
  assert.match(doc('Với mọi x ∈ ℝ ta có x² ≥ 0.'), /thuộc tập số thực.*lớn hơn hoặc bằng không/);
  assert.match(doc('x = (−b + √∆)⁄(2a)'), /căn bậc hai của đen-ta trên hai a/);
  // Không được đọc ra ký tự thô.
  for (const t of ['x² + x₁ = √∆', 'a⁄b ≤ ℝ']) {
    const r = doc(t);
    for (const xau of ['²', '₁', '√', '⁄', 'ℝ', '\\']) assert.ok(!r.includes(xau), `còn đọc thô "${xau}" trong "${r}"`);
  }
  // Lời văn thường không được đụng vào.
  assert.equal(doc('Hôm nay học bài mới.'), 'Hôm nay học bài mới.');
});

test('Phông chữ vẽ được mọi ký hiệu mà máy ký hiệu sinh ra', () => {
  const mau = 'x² − 5x + 6 = 0 ∆ b² 4ac x₁ ∈ ℝ √∆ (−b)⁄(2a) ½ ≤ ≥ ≠ π ∅ ⇒ ∛ ∑ ∫ ∞ ° α β θ ⊂ ∪ ∩ ∀ ∃';
  const anh = { width: 24, height: 24, data: Buffer.alloc(24 * 24 * 4) };
  const thieu = [];
  for (const ch of new Set(mau.replace(/\s/g, ''))) {
    if (CHU.veChu(anh, ch, 2, 2, { co: 1 }).boQua) thieu.push(ch);
  }
  assert.deepEqual(thieu, [], `phông thiếu chữ: ${thieu.join(' ')} — khung hình sẽ thủng lỗ đúng chỗ công thức`);
});

// ═══ CẤP 2 — VĂN PHONG ═════════════════════════════════════════════════════

test('Bắt được giọng máy, viết tắt và biểu tượng cảm xúc', () => {
  const r = kiemVanPhong('Tôi sẽ giải bài này. Tuyệt vời! pt có 2 nghiệm ✅ đc kl là x = 2');
  assert.equal(r.ok, false);
  const ma = new Set(r.loi.map((l) => l.ma));
  for (const m of ['GIONG_MAY', 'VIET_TAT', 'EMOJI']) assert.ok(ma.has(m), `thiếu ${m}`);
});

test('Ký hiệu toán KHÔNG bị nhầm thành biểu tượng cảm xúc', () => {
  // ∆ ∑ ∫ ⇒ ≤ nằm trong dải Unicode của ký hiệu, rất dễ bị bắt oan.
  const r = kiemVanPhong('Ta có ∆ > 0 ⇒ x ≤ 3, ∑ và ∫ đều dùng được.');
  assert.equal(r.loi.filter((l) => l.ma === 'EMOJI').length, 0);
});

test('Mã dạng bài không bị bắt oan là viết tắt', () => {
  const r = kiemVanPhong('Dạng M9.PT2.GIAI và M10.BPT.BAC2 thuộc đại số.');
  assert.equal(r.loi.filter((l) => l.ma === 'VIET_TAT').length, 0);
});

test('Bài giải viết đúng lối sách giáo khoa thì không bị bắt lỗi', () => {
  const bai = ['Đề bài: Giải phương trình x² − 5x + 6 = 0.',
    'Lời giải: Ta có ∆ = b² − 4ac = 1 > 0. Suy ra phương trình có hai nghiệm phân biệt x₁ = 3; x₂ = 2.',
    'Kiểm tra lại: thay x = 2 vào phương trình thấy thỏa mãn.',
    'Kết luận: Vậy phương trình có tập nghiệm S = {2; 3}.'].join('\n');
  const r = kiemVanPhong(bai, { loai: 'bai-giai' });
  assert.equal(r.ok, true, JSON.stringify(r.loi));
  assert.equal(r.diem, 100);
});

// ═══ CẤP 4 — NỘI DUNG TOÁN ═════════════════════════════════════════════════

const BAI_DUNG = ['**Đề bài:** Giải phương trình x² − 5x + 6 = 0.', '',
  '**Lời giải:**', '', 'Ta có ∆ = b² − 4ac = 25 − 24 = 1 > 0.',
  'Suy ra phương trình có hai nghiệm phân biệt x₁ = 3 và x₂ = 2.', '',
  '**Kiểm tra lại:** thay x = 2 vào phương trình thấy hai vế bằng nhau.', '',
  '**Kết luận:** Vậy phương trình có tập nghiệm S = {2; 3}.'].join('\n');

test('Rút đúng phương trình ra khỏi lời văn, không ngoạm chữ bên cạnh', () => {
  assert.equal(rutPhuongTrinh(BAI_DUNG), 'x^(2) - 5x + 6 = 0');
  assert.deepEqual(rutTapNghiem(BAI_DUNG), [2, 3]);
  // Tập nghiệm không được nhận nhầm thành phương trình cần giải.
  assert.equal(rutPhuongTrinh('Vậy S = {2; 3}.'), null);
  assert.deepEqual(rutTapNghiem('Phương trình vô nghiệm.'), []);
  assert.deepEqual(rutTapNghiem('S = {1⁄2; 3}'), [0.5, 3]);
});

test('Đáp số sai thì TRƯỢT, dù trình bày đẹp đến đâu', () => {
  assert.equal(thamDinh(BAI_DUNG).dat, true);
  const sai = BAI_DUNG.replace('S = {2; 3}', 'S = {2; 5}');
  const r = thamDinh(sai);
  assert.equal(r.dat, false, 'bài sai đáp số mà vẫn đạt là bộ thẩm định vô dụng');
  assert.equal(r.cap1KyHieu.ok, true, 'ký hiệu vẫn đúng — chỉ nội dung sai');
  assert.equal(r.cap2VanPhong.ok, true);
  assert.equal(r.cap4NoiDung.daKiemToan, true, 'phải thật sự thay nghiệm vào kiểm');
  assert.match(r.cap4NoiDung.loi[0].moTa, /thiếu nghiệm 3|thừa nghiệm 5/);
});

test('Bốn cấp soát bốn thứ khác nhau, không chồng lên nhau', () => {
  const r = thamDinh('Tôi sẽ giải: x^2 = 4 ✅');
  assert.equal(r.cap1KyHieu.ok, false, 'còn dấu ^');
  assert.equal(r.cap2VanPhong.ok, false, 'giọng máy và emoji');
  assert.equal(r.cap3CauTruc.ok, false, 'thiếu phần');
  assert.equal(r.dat, false);
  assert.ok(r.diem < 50);
});

// ═══ NHÀ KHOA HỌC TOÁN ═════════════════════════════════════════════════════

test('Giải đúng và tự kiểm: nghiệm nguyên, nghiệm hữu tỉ, nghiệm kép, vô nghiệm', () => {
  const s = new MathScientist({});
  const ca = [
    ['x^2 - 5x + 6 = 0', 'S = {2; 3}', 1],
    ['2x^2 - 7x + 3 = 0', 'S = {1⁄2; 3}', 25],
    ['x^2 - 6x + 9 = 0', 'S = {3}', 0],
    ['x^2 + x + 5 = 0', 'S = ∅', -19],
    ['3x - 12 = 0', 'S = {4}', null],
  ];
  for (const [de, dap, delta] of ca) {
    const g = s.giaiDaCach(de);
    assert.equal(g.ok, true, de);
    assert.equal(g.tapNghiem, dap, de);
    if (delta !== null) assert.equal(g.bietThuc, String(delta).replace('-', '−'), `∆ của ${de}`);
    assert.equal(g.nhatQuan, true, `các cách giải của "${de}" cho kết quả lệch nhau`);
    const t = s.trinhBay(g);
    assert.equal(t.thamDinh.dat, true, `${de} → ${JSON.stringify(t.thamDinh.canSua)}`);
    assert.equal(t.thamDinh.daThayNghiemVaoKiem, true);
  }
});

test('Cách giải chỉ hiện khi THẬT SỰ áp dụng được — không dập khuôn', () => {
  const s = new MathScientist({});
  const ten = (de) => s.giaiDaCach(de).cacCach.map((c) => c.phuongPhap);
  // a + b + c = 0 → nhẩm được
  assert.ok(ten('x^2 - 3x + 2 = 0').includes('nhẩm nghiệm'));
  // a + b + c ≠ 0 và a − b + c ≠ 0 → KHÔNG được bày cách nhẩm
  assert.ok(!ten('x^2 - 5x + 6 = 0').includes('nhẩm nghiệm'));
  // ∆ = 0 → hằng đẳng thức; ∆ ≠ 0 thì không
  assert.ok(ten('x^2 - 6x + 9 = 0').includes('bình phương đúng'));
  assert.ok(!ten('x^2 - 5x + 6 = 0').includes('bình phương đúng'));
  // nghiệm không nguyên → không bày Vi-ét đảo
  assert.ok(!ten('2x^2 - 7x + 3 = 0').includes('Vi-ét đảo'));
  assert.ok(ten('x^2 - 5x + 6 = 0').includes('Vi-ét đảo'));
});

test('Đọc vị đề bài nêu được bẫy tính từ chính hệ số của đề', () => {
  const s = new MathScientist({});
  const r = s.docVi('Giải phương trình 2x^2 - 7x + 3 = 0');
  assert.equal(r.ok, true);
  assert.equal(r.bacPhuongTrinh, 2);
  assert.equal(r.bietThuc, 25);
  assert.deepEqual(r.duKien.map((d) => d.giaTri), ['2', '−7', '3']);
  const bay = r.bay.map((b) => b.moTa).join(' | ');
  assert.match(bay, /a = 2 ≠ 1/, 'phải cảnh báo mẫu 2a khi a ≠ 1');
  assert.match(bay, /b = −7 âm/, 'phải cảnh báo bình phương số âm');
});

test('Pháp đồ đi theo đúng nhánh mà biệt thức quyết định', () => {
  const s = new MathScientist({});
  assert.equal(s.phapDo(s.docVi('x^2 + x + 5 = 0')).cayQuyetDinh.dangDi, '∆ < 0');
  assert.equal(s.phapDo(s.docVi('x^2 - 6x + 9 = 0')).cayQuyetDinh.dangDi, '∆ = 0');
  assert.equal(s.phapDo(s.docVi('x^2 - 5x + 6 = 0')).cayQuyetDinh.dangDi, '∆ > 0');
});

test('Ghép phương pháp học tất định và bám đúng dấu hiệu học sinh nói', () => {
  const s = new MathScientist({});
  const a = s.ghepPhuongPhap('em học trước quên sau');
  assert.equal(a.ok, true);
  assert.ok(['lap-lai-ngat-quang', 'so-do-tu-duy'].includes(a.deXuat[0].id), a.deXuat[0].id);
  for (let i = 0; i < 20; i++) assert.deepEqual(s.ghepPhuongPhap('em học trước quên sau'), a);
  assert.equal(s.ghepPhuongPhap('em hay trì hoãn').deXuat[0].id, 'bat-dau-3-phut');
  assert.equal(s.ghepPhuongPhap('trời hôm nay đẹp quá').deXuat.length, 0, 'không khớp thì phải nói không khớp');
  assert.equal(Object.keys(PHUONG_PHAP).length, 24);
});

test('Số hữu tỉ hiện thành phân số, không thành dãy thập phân vô hạn', () => {
  assert.equal(soDep(0.5), '1⁄2');
  assert.equal(soDep(1 / 3), '1⁄3');
  assert.equal(soDep(-0.25), '−1⁄4');
  assert.equal(soDep(3), '3');
  assert.equal(soDep(-7), '−7');
});

test('Phiếu học tập lấy bài từ kho đã thẩm định, không bịa đề', async () => {
  const { boot } = require('../src/index');
  const N = await boot({ quiet: true });
  try {
    const p = N.scientist.phieuHocTap('M9.PT2.GIAI', { soBai: 6 });
    assert.equal(p.ok, true, p.error);
    assert.equal(p.daThamDinh, true);
    assert.ok(p.baiTap.length >= 1);
    assert.match(p.nguon, /xác minh toán học/);
    for (const b of p.baiTap) assert.ok(b.dapAn !== undefined, 'bài nào cũng phải có đáp án');
    const chu = N.scientist.phieuRaChu(p);
    assert.match(chu, /## D. Bài tập tự luyện/);
    assert.equal(N.scientist.phieuHocTap('M1.SO.DEM20', { soBai: 3 }).ok !== undefined, true);
  } finally {
    await N.shutdown();
  }
});

test('Bài giảng dựng ra mang ký hiệu đúng chuẩn và có biên bản thẩm định', async () => {
  const { boot } = require('../src/index');
  const N = await boot({ quiet: true });
  try {
    const r = await N.baiGiang.tao({ maDang: 'M9.PT2.GIAI', kho: 'nhap', soBaiMau: 1 });
    assert.equal(r.ok, true, r.error);
    assert.ok(r.thamDinh, 'bài giảng phải kèm biên bản thẩm định');
    assert.equal(r.thamDinh.dat, true, JSON.stringify(r.thamDinh.canSua));
    // Chữ trên khung hình không được còn lệnh LaTeX hay dấu ^ thô.
    const chu = r.mocThoiGian.map((m) => m.tieuDe).join(' ');
    assert.ok(!/\\dfrac|\\sqrt|\^\{/.test(chu), `còn LaTeX trên khung hình: ${chu}`);
  } finally {
    await N.shutdown();
  }
});

test('Không có hai route trùng đường dẫn — route sau sẽ chết lặng', async () => {
  // Đây là lỗi đã thật sự xảy ra: /math/solve được đăng ký hai lần, route
  // thứ hai không bao giờ chạy và không có thông báo nào cho biết.
  const { boot } = require('../src/index');
  const createRouter = require('../src/api/router');
  const N = await boot({ quiet: true });
  try {
    const { routes } = createRouter(N);
    const thay = new Map();
    const trung = [];
    for (const r of routes) {
      const khoa = `${r.method} ${r.pattern}`;
      if (thay.has(khoa)) trung.push(`${khoa} (nhóm ${thay.get(khoa)} và ${r.group})`);
      else thay.set(khoa, r.group);
    }
    assert.deepEqual(trung, [], `route bị đăng ký trùng: ${trung.join(', ')}`);
    assert.ok(routes.length > 200, `chỉ có ${routes.length} route`);
  } finally {
    await N.shutdown();
  }
});
