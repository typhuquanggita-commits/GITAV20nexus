'use strict';
/** Lộ trình 90 ngày: sinh từ chân dung, cắt theo sức chứa thật, chỉnh mỗi tuần có lý do. */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const Telemetry = require('../src/learner/telemetry');
const Mastery = require('../src/learner/mastery');
const ProfileStore = require('../src/learner/profile');
const BehaviorAnalyzer = require('../src/learner/behavior');
const RoadmapService = require('../src/learner/roadmap');
const { FORM_INDEX } = require('../src/curriculum/hierarchy');
const { MASTERY_THRESHOLD } = Mastery;
const { WEEKS, CHECKPOINT_WEEKS } = RoadmapService;

function rig(level = 3) {
  const telemetry = new Telemetry();
  const mastery = new Mastery();
  const profiles = new ProfileStore({ telemetry, mastery });
  profiles.register('HV', { fullName: 'Học viên', grade: 9 });
  profiles.get('HV').currentLevel = level;
  const behavior = new BehaviorAnalyzer({ telemetry, mastery });
  return { telemetry, mastery, profiles, behavior, svc: new RoadmapService({ profiles, mastery, telemetry, behavior }) };
}

test('lộ trình đủ 13 tuần, có mốc kiểm và kết thúc bằng thi cuối tầng', () => {
  const { svc } = rig();
  const rm = svc.generate({ learnerId: 'HV' });
  assert.equal(rm.ok, true);
  assert.equal(rm.weeks.length, WEEKS);
  const checks = rm.weeks.filter((w) => w.checkpoint);
  assert.deepEqual(checks.map((c) => c.week), CHECKPOINT_WEEKS);
  assert.equal(checks.at(-1).checkpoint.kind, 'EXIT_EXAM');
});

test('không ôm quá sức: cắt theo số bài thật sự làm được, phần dư để lại', () => {
  const { svc } = rig();
  const rm = svc.generate({ learnerId: 'HV', sessionsPerWeek: 3 });
  assert.ok(rm.formsPlanned <= rm.formsWanted);
  assert.ok(rm.feasibility.itemsPerForm >= 12,
    `mỗi dạng chỉ ${rm.feasibility.itemsPerForm} bài — học qua loa`);
  if (rm.formsDeferred > 0) {
    assert.match(rm.feasibility.verdict, /để sang chu kỳ sau/);
    assert.equal(rm.leftoverForms.length, rm.formsDeferred + (rm.formsWanted - rm.formsPlanned - rm.formsDeferred));
  }
});

test('tăng số buổi thì ôm được nhiều dạng hơn', () => {
  const a = rig().svc.generate({ learnerId: 'HV', sessionsPerWeek: 3 });
  const b = rig().svc.generate({ learnerId: 'HV', sessionsPerWeek: 6 });
  assert.ok(b.formsPlanned > a.formsPlanned, `${a.formsPlanned} → ${b.formsPlanned}`);
});

test('dạng đã thạo không đưa vào lộ trình nữa', () => {
  const { svc, mastery, profiles } = rig();
  const base = svc.generate({ learnerId: 'HV' });
  const target = base.weeks[0].focusForms[0].code;
  for (let i = 0; i < 40; i++) mastery.update('HV', { formCode: target, stars: 2, correct: true, hintsUsed: 0 });
  assert.ok(mastery.map('HV')[target] >= MASTERY_THRESHOLD, 'phải đạt ngưỡng thạo trước đã');

  const again = svc.generate({ learnerId: 'HV' });
  const all = again.weeks.flatMap((w) => w.focusForms.map((f) => f.code));
  assert.ok(!all.includes(target), 'dạng đã thạo mà vẫn bắt học lại là phí thời gian');
});

test('dạng đi theo thứ tự tiên quyết, không nhảy cóc', () => {
  const { svc } = rig();
  const rm = svc.generate({ learnerId: 'HV' });
  const order = rm.weeks.flatMap((w) => w.focusForms.map((f) => f.code));
  const pos = new Map(order.map((c, i) => [c, i]));
  for (const c of order) {
    for (const pr of FORM_INDEX.get(c)?.prereq || []) {
      if (pos.has(pr)) assert.ok(pos.get(pr) <= pos.get(c), `${pr} phải học trước ${c}`);
    }
  }
});

test('khối lượng mỗi buổi lấy từ ngưỡng chú ý đo được, không đoán', () => {
  const { svc, telemetry } = rig();
  const chua = svc.generate({ learnerId: 'HV' });
  assert.match(chua.attentionNote, /Chưa đủ dữ liệu/);

  // Bơm dữ liệu một người đuối rất sớm.
  for (let i = 0; i < 20; i++) {
    telemetry.attempt('HV', { itemId: `I${i}`, formCode: 'M9.PT2.GIAI', correct: i < 6, ms: 150_000, hintsUsed: 0, stars: 3 });
  }
  const co = svc.generate({ learnerId: 'HV' });
  assert.match(co.attentionNote, /ngưỡng chú ý đo được/);
  assert.ok(co.itemsPerSession < 12, `đuối sớm mà vẫn giữ ${co.itemsPerSession} bài/buổi là ép`);
});

test('mục tiêu mỗi tuần là con số đo được, siết dần', () => {
  const { svc } = rig();
  const rm = svc.generate({ learnerId: 'HV' });
  for (let i = 1; i < rm.weeks.length; i++) {
    assert.ok(rm.weeks[i].targetMastery >= rm.weeks[i - 1].targetMastery, 'mục tiêu không được hạ xuống');
    assert.ok(rm.weeks[i].targetAccuracy >= rm.weeks[i - 1].targetAccuracy);
  }
  assert.ok(rm.weeks[0].targetMastery > 0 && rm.weeks.at(-1).targetMastery <= 0.95);
});

test('rà soát tuần: làm quá ít thì dời dạng, không dồn cục', () => {
  const { svc, telemetry } = rig();
  const rm = svc.generate({ learnerId: 'HV' });
  const before = rm.weeks[1].focusForms.length;
  // Tuần 1 gần như không học gì.
  telemetry.attempt('HV', { itemId: 'X1', formCode: rm.weeks[0].focusForms[0].code, correct: true, ms: 150_000, hintsUsed: 0, stars: 2 });
  const r = svc.weeklyReview('HV', { week: 1 });
  assert.equal(r.verdict, 'CHẬM TIẾN ĐỘ');
  assert.ok(r.changes.some((c) => c.kind === 'DỜI_DẠNG'));
  assert.ok(svc.get('HV').weeks[1].focusForms.length > before);
  for (const c of r.changes) assert.ok(c.reason && c.reason.length > 10, 'mọi thay đổi phải có lý do');
});

test('rà soát tuần: sai nhiều thì giảm dạng mới, dồn cho củng cố', () => {
  const { svc, telemetry } = rig();
  const rm = svc.generate({ learnerId: 'HV' });
  const code = rm.weeks[0].focusForms[0].code;
  const shareBefore = rm.weeks[5].newShare;
  for (let i = 0; i < 50; i++) {
    telemetry.attempt('HV', { itemId: `Y${i}`, formCode: code, correct: i % 5 === 0, ms: 150_000, hintsUsed: 0, stars: 3 });
  }
  const r = svc.weeklyReview('HV', { week: 1 });
  assert.ok(r.changes.some((c) => c.kind === 'GIẢM_DẠNG_MỚI'), JSON.stringify(r.changes.map((c) => c.kind)));
  assert.ok(svc.get('HV').weeks[5].newShare < shareBefore);
});

test('rà soát tuần: vượt tiến độ thì tăng dạng mới', () => {
  const { svc, telemetry } = rig();
  const rm = svc.generate({ learnerId: 'HV' });
  const code = rm.weeks[0].focusForms[0].code;
  const shareBefore = rm.weeks[5].newShare;
  for (let i = 0; i < rm.weeks[0].totalItems + 5; i++) {
    telemetry.attempt('HV', { itemId: `Z${i}`, formCode: code, correct: true, ms: 100_000, hintsUsed: 0, stars: 3 });
  }
  const r = svc.weeklyReview('HV', { week: 1 });
  assert.equal(r.verdict, 'ĐÚNG TIẾN ĐỘ');
  assert.ok(r.changes.some((c) => c.kind === 'TĂNG_DẠNG_MỚI'));
  assert.ok(svc.get('HV').weeks[5].newShare > shareBefore);
});

test('dạng tắc lâu thì lùi về dạng tiên quyết, nói rõ nguyên nhân nằm ở nền', () => {
  const { svc, telemetry } = rig();
  const rm = svc.generate({ learnerId: 'HV' });
  const stuck = rm.weeks[0].focusForms.find((f) => (FORM_INDEX.get(f.code)?.prereq || []).length);
  if (!stuck) return;
  for (let i = 0; i < 30; i++) {
    telemetry.attempt('HV', { itemId: `W${i}`, formCode: stuck.code, correct: false, ms: 200_000, hintsUsed: 2, stars: 3 });
  }
  const r = svc.weeklyReview('HV', { week: 1 });
  const back = r.changes.find((c) => c.kind === 'LÙI_VỀ_NỀN');
  if (back) assert.match(back.reason, /nằm ở nền|tắc ở mức thạo/);
});

test('mọi lần chỉnh đều lưu lại để còn xem lại vì sao đổi', () => {
  const { svc, telemetry } = rig();
  const rm = svc.generate({ learnerId: 'HV' });
  telemetry.attempt('HV', { itemId: 'A1', formCode: rm.weeks[0].focusForms[0].code, correct: false, ms: 150_000, hintsUsed: 0, stars: 3 });
  svc.weeklyReview('HV', { week: 1 });
  svc.weeklyReview('HV', { week: 2 });
  const stored = svc.get('HV');
  assert.equal(stored.adjustments.length, 2);
  for (const a of stored.adjustments) {
    assert.ok(a.verdict && typeof a.itemsDone === 'number' && Array.isArray(a.changes));
  }
});

test('tiến độ chu kỳ so tiến độ nội dung với tiến độ thời gian', () => {
  const { svc } = rig();
  svc.generate({ learnerId: 'HV' });
  const p = svc.progress('HV');
  assert.equal(p.ok, true);
  assert.ok(p.formsPlanned > 0);
  assert.ok(p.timeElapsed >= 0 && p.timeElapsed <= 1);
  assert.equal(typeof p.onTrack, 'boolean');
  assert.equal(p.checkpoints.length, CHECKPOINT_WEEKS.length);
});

test('việc tuần này nêu rõ mức thạo hiện tại của từng dạng trọng tâm', () => {
  const { svc } = rig();
  svc.generate({ learnerId: 'HV' });
  const w = svc.thisWeek('HV');
  assert.equal(w.ok, true);
  assert.equal(w.week, 1);
  for (const f of w.focusForms) {
    assert.equal(typeof f.currentMastery, 'number');
    assert.equal(typeof f.reached, 'boolean');
  }
});

test('chưa có lộ trình hoặc học viên lạ thì báo rõ', () => {
  const { svc } = rig();
  assert.equal(svc.generate({ learnerId: 'KHONG-CO' }).error, 'LEARNER_NOT_FOUND');
  assert.equal(svc.thisWeek('HV').error, 'NO_ROADMAP');
  assert.equal(svc.weeklyReview('HV').error, 'NO_ROADMAP');
});
