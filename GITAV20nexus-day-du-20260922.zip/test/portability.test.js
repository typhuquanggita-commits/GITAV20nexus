'use strict';
/** Nhập/xuất: không dòng nào bị bỏ qua im lặng. */
const { test, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { Database } = require('../src/data/repository');
const Organization = require('../src/school/organization');
const Portability = require('../src/data/portability');
const { parseCSV, toCSV, detectDelimiter } = Portability;

let db, org, io, learners, classes;

before(() => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'gita-io-'));
  db = new Database({ dir });
  learners = db.collection('learners', { indexes: ['classId'] });
  classes = db.collection('classes', { indexes: ['teacherId'] });
  const schools = db.collection('schools');
  const items = db.collection('items', { indexes: ['formCode'] });
  org = new Organization({ schools, classes, learners });
  io = new Portability({ learners, classes, items, org });
  org.createClass({ id: 'CL-9A', name: '9A', grade: 9, capacity: 10 });
});

// ── Bóc CSV ─────────────────────────────────────────────────────────────────

test('CSV: ô có dấu phân cách, ngoặc kép và xuống dòng bên trong', () => {
  const t = 'a,b,c\n"có, phẩy","có ""ngoặc""","hai\ndòng"\n';
  const p = parseCSV(t);
  assert.equal(p.rows.length, 2);
  assert.deepEqual(p.rows[1].cells, ['có, phẩy', 'có "ngoặc"', 'hai\ndòng']);
});

test('CSV: tự nhận dấu chấm phẩy của Excel bản Việt', () => {
  assert.equal(detectDelimiter('ho ten;lop;ghi chu'), ';');
  assert.equal(detectDelimiter('ho ten,lop,ghi chu'), ',');
  assert.equal(detectDelimiter('ho ten\tlop\tghi chu'), '\t');
});

test('CSV: bỏ BOM, bỏ dòng trống nhưng giữ đúng số dòng gốc', () => {
  const p = parseCSV('﻿a,b\n\n\nx,y\n');
  assert.equal(p.rows.length, 2);
  assert.equal(p.rows[0].cells[0], 'a', 'BOM phải bị bóc');
  assert.equal(p.rows[1].line, 4, 'dòng dữ liệu nằm ở dòng 4 của tệp');
});

test('CSV xuất ra có BOM và thoát ký tự đúng', () => {
  const out = toCSV([{ a: 'x,y', b: 'có "ngoặc"' }]);
  assert.ok(out.startsWith('﻿'));
  assert.ok(out.includes('"x,y"'));
  assert.ok(out.includes('"có ""ngoặc"""'));
});

// ── Nhập học viên ───────────────────────────────────────────────────────────

const GOOD = `Họ tên,Lớp,Ngày sinh,Giới tính,Phụ huynh,SĐT phụ huynh
Nguyễn Văn An,9,05/09/2012,Nam,Nguyễn Văn Bình,0912345678
Trần Thị Bình,9,2012-03-12,Nữ,Trần Văn Cường,0987654321
Lê Minh Cường,9,20/11/2012,Nam,,
`;

test('chạy thử không ghi gì, nhưng báo đúng kết quả sẽ ra', () => {
  const before = learners.count();
  const r = io.importLearners(GOOD, { classId: 'CL-9A', dryRun: true });
  assert.equal(r.ok, true);
  assert.equal(r.dryRun, true);
  assert.equal(r.accepted, 3);
  assert.equal(r.rejected, 0);
  assert.equal(r.written, 0);
  assert.equal(learners.count(), before, 'chạy thử mà ghi dữ liệu là sai');
  assert.equal(r.preview[0].fullName, 'Nguyễn Văn An');
});

test('nhập thật: ghi đủ, vào đúng lớp, kết quả khớp lúc chạy thử', () => {
  const r = io.importLearners(GOOD, { classId: 'CL-9A', dryRun: false });
  assert.equal(r.accepted, 3);
  assert.equal(r.written, 3);
  assert.equal(learners.count(), 3);
  assert.equal(org.getClass('CL-9A').size, 3);
  const an = learners.find((l) => l.fullName === 'Nguyễn Văn An');
  assert.equal(an.grade, 9);
  assert.equal(an.gender, 'nam');
  assert.equal(new Date(an.dob).toISOString().slice(0, 10), '2012-09-05');
  assert.equal(an.parentPhone, '0912345678');
});

test('tên cột viết kiểu gì cũng khớp — hoa thường, có dấu, không dấu', () => {
  const r = io.importLearners('HO TEN;lop;NGAY SINH\nPhạm Thu Dung;9;01/01/2012\n', { classId: 'CL-9A', dryRun: true });
  assert.equal(r.accepted, 1);
  assert.equal(r.preview[0].fullName, 'Phạm Thu Dung');
});

test('mỗi dòng hỏng đều có số dòng và lý do bằng tiếng Việt', () => {
  const bad = `Họ tên,Lớp,Ngày sinh,Email
,9,01/01/2012,
Hoàng Văn Em,99,01/01/2012,
Vũ Thị Phương,9,không-phải-ngày,
Đỗ Văn Giang,9,01/01/2012,khong-phai-email
Bùi Thị Hoa,9,01/01/2099,
`;
  const r = io.importLearners(bad, { classId: 'CL-9A', dryRun: true });
  assert.equal(r.accepted, 0);
  assert.equal(r.rejected, 5);
  const byLine = Object.fromEntries(r.problems.map((p) => [p.line, p.reason]));
  assert.match(byLine[2], /thiếu họ tên/);
  assert.match(byLine[3], /lớp "99" không hợp lệ/);
  assert.match(byLine[4], /ngày sinh .* không đọc được/);
  assert.match(byLine[5], /email .* không hợp lệ/);
  assert.match(byLine[6], /ngày sinh ở tương lai/);
});

test('trùng trong chính tệp bị chỉ đích danh dòng trước đó', () => {
  const dup = `Họ tên,Lớp,Ngày sinh
Ngô Văn Inh,9,01/02/2012
Ngô Văn Inh,9,01/02/2012
`;
  const r = io.importLearners(dup, { classId: 'CL-9A', dryRun: true });
  assert.equal(r.accepted, 1);
  assert.equal(r.rejected, 1);
  assert.match(r.problems[0].reason, /trùng với dòng 2 trong cùng tệp/);
});

test('trùng với người đã có trong hệ thống: từ chối, trừ khi cho phép cập nhật', () => {
  const again = io.importLearners(GOOD, { classId: 'CL-9A', dryRun: true });
  assert.equal(again.accepted, 0);
  assert.equal(again.rejected, 3);
  assert.match(again.problems[0].reason, /đã có trong hệ thống/);

  const upd = io.importLearners(GOOD, { classId: 'CL-9A', dryRun: true, allowUpdate: true });
  assert.equal(upd.accepted, 3);
  assert.equal(upd.preview[0].mode, 'cập nhật');
});

test('cập nhật giữ nguyên tầng đã đạt, không đẩy học viên về mốc 0', () => {
  const an = learners.find((l) => l.fullName === 'Nguyễn Văn An');
  learners.patch(an.id, { level: 4 });
  io.importLearners(GOOD, { classId: 'CL-9A', dryRun: false, allowUpdate: true });
  assert.equal(learners.get(an.id).level, 4, 'nhập lại mà xoá tiến độ là mất dữ liệu học tập');
});

test('lớp đầy thì dừng đúng chỗ, phần còn lại được báo rõ', () => {
  const rows = ['Họ tên,Lớp'];
  for (let i = 1; i <= 20; i++) rows.push(`Người Thứ ${i},9`);
  const r = io.importLearners(rows.join('\n'), { classId: 'CL-9A', dryRun: true });
  assert.equal(r.accepted, 7, 'lớp 10 chỗ, đã có 3 người');
  assert.equal(r.rejected, 13);
  assert.match(r.problems[0].reason, /đã đủ sĩ số/);
});

test('cảnh báo khác từ chối: số phụ huynh sai thì bỏ qua chứ không loại cả dòng', () => {
  const r = io.importLearners('Họ tên,Lớp,SĐT phụ huynh\nMai Văn Khoa,9,abc-xyz\n', { classId: null, dryRun: true });
  assert.equal(r.accepted, 1);
  assert.equal(r.warnings, 1);
  assert.match(r.warningList[0].warning, /phụ huynh/);
});

test('thiếu cột họ tên thì từ chối cả tệp và nói rõ thiếu gì', () => {
  const r = io.importLearners('Lớp,Ngày sinh\n9,01/01/2012\n', { dryRun: true });
  assert.equal(r.ok, false);
  assert.equal(r.error, 'MISSING_COLUMN');
  assert.equal(r.need, 'Họ tên');
});

test('tệp rỗng và lớp không tồn tại được báo đúng lỗi', () => {
  assert.equal(io.importLearners('', { dryRun: true }).error, 'EMPTY_FILE');
  assert.equal(io.importLearners(GOOD, { classId: 'KHONG-CO', dryRun: true }).error, 'CLASS_NOT_FOUND');
});

// ── Xuất ────────────────────────────────────────────────────────────────────

test('xuất rồi nhập lại ra đúng số người — vòng tròn khép kín', () => {
  const out = io.exportLearners({ classId: 'CL-9A' });
  assert.equal(out.ok, true);
  assert.ok(out.content.startsWith('﻿'));
  const back = io.importLearners(out.content, { dryRun: true, allowUpdate: true });
  assert.equal(back.accepted, out.count, 'xuất ra phải nhập lại được trọn vẹn');
  assert.equal(back.rejected, 0);
});

test('xuất JSON và xuất CSV cho cùng một bộ dữ liệu', () => {
  const j = io.exportLearners({ classId: 'CL-9A', format: 'json' });
  const c = io.exportLearners({ classId: 'CL-9A', format: 'csv' });
  assert.equal(j.count, c.count);
  assert.equal(j.data[0].ho_ten, 'Lê Minh Cường', 'phải sắp theo tên tiếng Việt');
});

test('mẫu tệp nhập dùng được ngay, không cần đoán tên cột', () => {
  // Kho trắng: mẫu phải nhập trôi 100% mà không phải sửa gì.
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'gita-tpl-'));
  const d2 = new Database({ dir });
  const io2 = new Portability({
    learners: d2.collection('learners'), classes: d2.collection('classes'), items: d2.collection('items'),
  });
  const t = io2.learnerTemplate();
  const r = io2.importLearners(t.content, { dryRun: false });
  assert.equal(r.ok, true);
  assert.equal(r.accepted, 2);
  assert.equal(r.rejected, 0);
  assert.equal(r.warnings, 0);
  assert.equal(d2.collection('learners').count(), 2);
  d2.close();
});
