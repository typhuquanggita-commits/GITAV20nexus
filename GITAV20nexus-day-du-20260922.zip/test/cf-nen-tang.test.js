'use strict';
/** Tầng Cloudflare: di trú, định tuyến, phiên, phân quyền, nhật ký, hạn mức. */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const { dungMoi, dongHoGia, yeuCau, doc } = require('../cloudflare/kiem-thu/gia-lap.js');
const { xuLy, dungBo } = require('../cloudflare/nguon/goc.js');
const quyen = require('../cloudflare/nguon/_lib/quyen.js');
const nhatKy = require('../cloudflare/nguon/_lib/nhat-ky.js');
const { Kho } = require('../cloudflare/nguon/_lib/kho.js');

const MK = 'Nexus#Cloudflare2026';

async function goi(moi, cach, duong, tuyChon, dongHo) {
  return xuLy(yeuCau(cach, duong, tuyChon), moi, {}, dongHo);
}

test('di trú dựng đủ bảng và mọi khoá ngoại lành', () => {
  const moi = dungMoi();
  const db = moi.DB._db;
  const bang = db.prepare("SELECT COUNT(*) c FROM sqlite_master WHERE type='table'").get().c;
  assert.ok(bang >= 173, 'phải có ít nhất 173 bảng, có ' + bang);
  assert.equal(db.prepare('PRAGMA foreign_key_check').all().length, 0);
});

test('đường không phải /api thì rơi xuống tệp tĩnh', async () => {
  const moi = dungMoi();
  const r = await goi(moi, 'GET', '/ho-so.html');
  assert.equal(r.status, 200);
  assert.equal(await r.text(), 'tep-tinh:/ho-so.html');
});

test('chưa gắn D1 thì nói thẳng cách gắn, không đổ lỗi mơ hồ', async () => {
  const moi = dungMoi(); moi.DB = null;
  const r = await goi(moi, 'GET', '/api/health');
  const j = await doc(r);
  assert.equal(r.status, 503);
  assert.equal(j.ma, 'chua-gan-kho');
  assert.match(j.loi, /D1 database bindings/);
});

test('đường không có trả 404, đúng đường sai cách trả 405 kèm cách đúng', async () => {
  const moi = dungMoi();
  const a = await doc(await goi(moi, 'GET', '/api/khong-ton-tai'));
  assert.equal(a.ma, 'khong-co-duong');

  const r = await goi(moi, 'GET', '/api/tai-khoan/dang-nhap');
  const b = await doc(r);
  assert.equal(r.status, 405);
  assert.deepEqual(b.cachDung, ['POST']);
});

test('sức khoẻ nói thật khi thiếu khoá AI thay vì báo tốt cho xong', async () => {
  const moi = dungMoi();
  const j = await doc(await goi(moi, 'GET', '/api/health'));
  assert.equal(j.dat, true);
  assert.equal(j.bo_phan.nhaAi.dat, false);
  assert.match(j.bo_phan.nhaAi.ghiChu, /không trả câu giả/);
});

test('đăng ký chặn mật khẩu yếu và không cho trùng thư điện tử', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  const yeu = await doc(await goi(moi, 'POST', '/api/tai-khoan/dang-ky',
    { than: { email: 'a@gita.vn', ten: 'A', matKhau: '123456' } }, dh));
  assert.equal(yeu.ma, 'mat-khau-yeu');

  const ok = await goi(moi, 'POST', '/api/tai-khoan/dang-ky',
    { than: { email: 'a@gita.vn', ten: 'Nguyễn A', matKhau: MK } }, dh);
  assert.equal(ok.status, 201);

  const lai = await goi(moi, 'POST', '/api/tai-khoan/dang-ky',
    { than: { email: 'A@GITA.VN', ten: 'Nguyễn A', matKhau: MK } }, dh);
  assert.equal(lai.status, 409, 'thư điện tử khác hoa thường vẫn là một');
});

test('đăng nhập sai không tiết lộ tài khoản nào có thật', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await goi(moi, 'POST', '/api/tai-khoan/dang-ky',
    { than: { email: 'b@gita.vn', ten: 'B', matKhau: MK } }, dh);

  const saiMk = await doc(await goi(moi, 'POST', '/api/tai-khoan/dang-nhap',
    { than: { email: 'b@gita.vn', matKhau: 'Sai#MatKhau2026' } }, dh));
  const khongCo = await doc(await goi(moi, 'POST', '/api/tai-khoan/dang-nhap',
    { than: { email: 'khong-co@gita.vn', matKhau: 'Sai#MatKhau2026' } }, dh));
  assert.equal(saiMk.loi, khongCo.loi, 'hai câu trả lời phải giống hệt nhau');
});

test('thẻ phiên không nằm trong kho — kho chỉ giữ băm của nó', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await goi(moi, 'POST', '/api/tai-khoan/dang-ky',
    { than: { email: 'c@gita.vn', ten: 'C', matKhau: MK } }, dh);
  const dn = await doc(await goi(moi, 'POST', '/api/tai-khoan/dang-nhap',
    { than: { email: 'c@gita.vn', matKhau: MK } }, dh));
  assert.ok(dn.the && dn.the.length >= 64);

  const hang = moi.DB._db.prepare('SELECT id FROM user_sessions').all();
  assert.equal(hang.length, 1);
  assert.notEqual(hang[0].id, dn.the, 'kho không được giữ thẻ gốc');

  const toi = await doc(await goi(moi, 'GET', '/api/tai-khoan/toi', { the: dn.the }, dh));
  assert.equal(toi.toi.email, 'c@gita.vn');
  assert.equal(toi.toi.vai, 'LEARNER');
});

test('phiên hết hạn thì không dùng được nữa', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await goi(moi, 'POST', '/api/tai-khoan/dang-ky',
    { than: { email: 'd@gita.vn', ten: 'D', matKhau: MK } }, dh);
  const dn = await doc(await goi(moi, 'POST', '/api/tai-khoan/dang-nhap',
    { than: { email: 'd@gita.vn', matKhau: MK } }, dh));

  dh.tien(4 * 3600 * 1000 - 1000);
  assert.equal((await goi(moi, 'GET', '/api/tai-khoan/toi', { the: dn.the }, dh)).status, 200);
  dh.tien(2000);
  assert.equal((await goi(moi, 'GET', '/api/tai-khoan/toi', { the: dn.the }, dh)).status, 401);
});

test('đổi mật khẩu giết mọi phiên đang mở, kể cả phiên kẻ trộm', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await goi(moi, 'POST', '/api/tai-khoan/dang-ky',
    { than: { email: 'e@gita.vn', ten: 'E', matKhau: MK } }, dh);
  const p1 = await doc(await goi(moi, 'POST', '/api/tai-khoan/dang-nhap',
    { than: { email: 'e@gita.vn', matKhau: MK } }, dh));
  const p2 = await doc(await goi(moi, 'POST', '/api/tai-khoan/dang-nhap',
    { than: { email: 'e@gita.vn', matKhau: MK } }, dh));

  const doi = await goi(moi, 'POST', '/api/tai-khoan/doi-mat-khau',
    { the: p1.the, than: { matKhauCu: MK, matKhauMoi: 'Nexus#Moi2026xyz' } }, dh);
  assert.equal(doi.status, 200);
  assert.equal((await goi(moi, 'GET', '/api/tai-khoan/toi', { the: p2.the }, dh)).status, 401);
  assert.equal((await goi(moi, 'GET', '/api/tai-khoan/toi', { the: p1.the }, dh)).status, 401);
});

test('học viên không xem được danh sách tài khoản', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await goi(moi, 'POST', '/api/tai-khoan/dang-ky',
    { than: { email: 'f@gita.vn', ten: 'F', matKhau: MK } }, dh);
  const dn = await doc(await goi(moi, 'POST', '/api/tai-khoan/dang-nhap',
    { than: { email: 'f@gita.vn', matKhau: MK } }, dh));
  const r = await goi(moi, 'GET', '/api/tai-khoan', { the: dn.the }, dh);
  assert.equal(r.status, 403);
  assert.equal((await doc(r)).ma, 'khong-du-quyen');
});

test('không ai cấp được vai ngang hoặc cao hơn vai của chính mình', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  const kho = Kho(moi.DB);
  const phien = require('../cloudflare/nguon/_lib/phien.js');
  const { maMoi } = require('../cloudflare/nguon/_lib/ma.js');

  const tao = async (email, vai) => {
    const id = maMoi();
    await kho.chen('users', { id, email, password_hash: await phien.bamMatKhau(MK, 2000),
      full_name: email, role: vai, status: 'ACTIVE', locale: 'vi',
      created_at: dh(), updated_at: dh() });
    return id;
  };
  const idAdmin = await tao('admin@gita.vn', 'ADMIN');
  const idGv = await tao('gv@gita.vn', 'TEACHER');
  const p = await phien.moPhien(kho, { id: idAdmin, role: 'ADMIN' }, 'thu', dh());

  const len = await goi(moi, 'POST', '/api/tai-khoan/' + idGv + '/vai',
    { the: p.the, than: { vai: 'SUPER_ADMIN' } }, dh);
  assert.equal(len.status, 403);
  assert.equal((await doc(len)).ma, 'vuot-bac');

  const xuong = await goi(moi, 'POST', '/api/tai-khoan/' + idGv + '/vai',
    { the: p.the, than: { vai: 'PARENT' } }, dh);
  assert.equal(xuong.status, 200);
});

test('nhật ký nối chuỗi băm bắt được cả sửa nội dung lẫn xoá dòng giữa', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  const kho = Kho(moi.DB);
  for (let i = 0; i < 5; i++) {
    await nhatKy.ghi(kho, { nguoi: 'u1', viec: 'thu.' + i, doiTuong: 'x' + i }, dh.tien(1000));
  }
  assert.equal((await nhatKy.soiChuoi(kho)).lanh, true);

  moi.DB._db.exec("UPDATE audit_log SET action = 'bi-sua' WHERE seq = 3");
  const sua = await nhatKy.soiChuoi(kho);
  assert.equal(sua.lanh, false);
  assert.equal(sua.ma, 'sua-noi-dung');
  assert.equal(sua.tai, 3);

  const moi2 = dungMoi();
  const kho2 = Kho(moi2.DB);
  const dh2 = dongHoGia();
  for (let i = 0; i < 5; i++) {
    await nhatKy.ghi(kho2, { nguoi: 'u1', viec: 'thu.' + i }, dh2.tien(1000));
  }
  moi2.DB._db.exec('DELETE FROM audit_log WHERE seq = 3');
  const xoa = await nhatKy.soiChuoi(kho2);
  assert.equal(xoa.lanh, false);
  assert.equal(xoa.ma, 'thieu-dong');
});

test('hạn mức đăng nhập chặn đúng ở ngưỡng và không đếm quá', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  const hanMuc = require('../cloudflare/nguon/_lib/han-muc.js');
  const kho = Kho(moi.DB);
  let cuoi;
  for (let i = 0; i < 52; i++) cuoi = await hanMuc.xin(kho, 'dang-nhap', 'ip1', dh());
  assert.equal(cuoi.cho, false);
  const xem = await hanMuc.xem(kho, 'dang-nhap', 'ip1', dh());
  assert.equal(xem.da, 50, 'không đếm vượt trần');

  dh.tien(25 * 3600 * 1000);
  assert.equal((await hanMuc.xin(kho, 'dang-nhap', 'ip1', dh())).cho, true, 'sang ngày mới mở lại');
});

test('bảng phân quyền dựng ra được và cấm tuyệt đối không thủng', () => {
  const b = quyen.banPhanQuyen();
  assert.ok(b.vai.length === 6);
  assert.ok(b.viec.length > 30);
  assert.ok(b.camTuyetDoi.length >= 5);
  for (const c of b.camTuyetDoi) {
    assert.equal(quyen.coQuyen('SUPER_ADMIN', c.ma), false, c.ma + ' phải cấm cả SUPER_ADMIN');
    assert.ok(c.lyDo.length > 30, 'lý do cấm phải nói được vì sao');
  }
});

test('mọi đường khai báo đều gọi được và không trùng nhau', () => {
  const bo = dungBo();
  const thay = new Set();
  for (const d of bo.duong) {
    const k = d.cach + ' ' + d.mau;
    assert.equal(thay.has(k), false, 'đường trùng: ' + k);
    thay.add(k);
    assert.match(d.mau, /^\/api(\/|$)/, 'đường phải nằm dưới /api: ' + d.mau);
    assert.ok(d.ghiChu.length > 0, 'đường thiếu ghi chú: ' + k);
  }
});
