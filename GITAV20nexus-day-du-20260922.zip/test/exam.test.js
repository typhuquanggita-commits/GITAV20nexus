'use strict';
/** Thi cuối tầng: đề phủ dạng, trộn độ khó, và lên tầng phải đủ cả 7 tiêu chí. */
const { test, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const ItemBank = require('../src/content/item-bank');
const ItemGenerator = require('../src/content/generator');
const BankSeeder = require('../src/content/seeder');
const ExamService = require('../src/learner/exam');
const Mastery = require('../src/learner/mastery');
const Telemetry = require('../src/learner/telemetry');
const ProfileStore = require('../src/learner/profile');
const MathVerifier = require('../src/math/verifier');
const { Database } = require('../src/data/repository');
const { formsForLevel } = require('../src/curriculum/hierarchy');
const { RETAKE_WAIT_DAYS, BLUEPRINT_MATRIX, MATRIX_BY_BAND, matrixForLevel } = ExamService;
void BLUEPRINT_MATRIX;

let bank;
before(() => {
  bank = new ItemBank();
  new BankSeeder({ bank, generator: new ItemGenerator({ bank }) }).seed({ perBlueprintLevel: 3 });
});

function rig(level = 3) {
  const db = new Database({ dir: fs.mkdtempSync(path.join(os.tmpdir(), 'gita-exam-')) });
  const attempts = db.collection('attempts', { indexes: ['learnerId'] });
  const exams = db.collection('exams', { indexes: ['learnerId'] });
  const telemetry = new Telemetry();
  const mastery = new Mastery();
  const profiles = new ProfileStore({ telemetry, mastery });
  profiles.register('HV', { fullName: 'Thí sinh', grade: 9 });
  profiles.get('HV').currentLevel = level;
  const svc = new ExamService({ bank, mastery, telemetry, profiles, attempts, exams, verifier: new MathVerifier() });
  return { svc, mastery, profiles, attempts, exams, db };
}

test('đề phủ được nhiều dạng nhất mà cỡ đề cho phép, và nói thật phần còn thiếu', () => {
  const { svc } = rig();
  const p = svc.build({ learnerId: 'HV', level: 3, size: 20 });
  assert.equal(p.ok, true);
  // Một đề n câu không thể phủ quá n dạng. Tầng 3 có hơn 20 dạng nên việc
  // nhiều dạng vắng mặt là chuyện số học, không phải khuyết tật của đề —
  // cái phải đúng là đề không được phủ ít hơn mức nó phủ nổi.
  assert.equal(p.formsCoverable, Math.min(20, p.formsAtLevel));
  assert.ok(p.formsCovered >= 1);
  assert.ok(p.formsCovered <= p.formsCoverable, 'không thể phủ nhiều dạng hơn số câu');
  if (p.formsAtLevel > p.formsCoverable || p.formsCovered < p.formsCoverable) {
    assert.ok(p.warning, 'thiếu dạng thì phải nói ra, không được im lặng');
    assert.match(p.warning, /dạng/);
  }
  assert.ok(p.missingForms.every((f) => f.code && f.name));
});

test('đề trộn độ khó ĐÚNG ma trận của tầng, không nhặt bài tuỳ hứng', () => {
  const { svc } = rig();
  const p = svc.build({ learnerId: 'HV', level: 3, size: 20 });
  const chuan = matrixForLevel(3);
  assert.equal(p.matrix.length, chuan.length, 'số dải của ma trận phải đúng theo tầng');
  const plannedTotal = p.matrix.reduce((s, m) => s + m.planned, 0);
  assert.equal(plannedTotal, 20, 'ma trận phải chia đủ số câu');
  // Đây là điều hệ thống HỨA với người học trên trang công khai: đề dựng ra
  // phải có đúng số câu từng bậc như bảng đã in. Hứa mà không giữ thì bảng
  // kia là nói dối, nên ràng buộc này phải là kiểm thử, không phải mong muốn.
  for (const m of p.matrix) {
    assert.equal(m.actual, m.planned, `bậc ${m.stars}★ dựng ${m.actual} câu nhưng ma trận đòi ${m.planned}`);
  }
  assert.equal(p.items.length, 20, 'đề phải đúng 20 câu, không thừa không thiếu');
  assert.equal(p.shortfall.length, 0, 'tầng 3 phải đủ bài cho mọi bậc sao');
});

test('ma trận đổi theo tầng: tầng đầu không có câu thách thức, tầng cuối không nặng câu nhận biết', () => {
  const thap = matrixForLevel(0);
  const cao = matrixForLevel(9);
  assert.ok(!thap.some((r) => r.stars === 5), 'tầng Khởi động không được có câu 5★');
  assert.ok(cao.some((r) => r.stars === 5), 'tầng Đỉnh cao phải có câu 5★');
  const nhanBietThap = thap.find((r) => r.stars === 1).share;
  const nhanBietCao = cao.find((r) => r.stars === 1).share;
  assert.ok(nhanBietThap > nhanBietCao, 'tỉ lệ nhận biết phải giảm dần khi lên tầng');
  for (const band of MATRIX_BY_BAND) {
    const tong = band.rows.reduce((s, r) => s + r.share, 0);
    assert.ok(Math.abs(tong - 1) < 1e-9, `tổng tỉ lệ của chặng ${band.id} phải bằng 1, đang là ${tong}`);
    for (const r of band.rows) {
      assert.equal(Math.round(r.share * 20), r.share * 20, `tỉ lệ ${r.share} không chia chẵn cho đề 20 câu`);
    }
  }
});

test('mọi tầng đều dựng được đề 20 câu đúng ma trận đã công bố', () => {
  for (let lv = 0; lv <= 9; lv++) {
    const { svc } = rig(lv);
    const p = svc.build({ learnerId: `HV-${lv}`, level: lv, size: 20 });
    assert.equal(p.ok, true, `tầng ${lv} không dựng được đề`);
    assert.equal(p.size, 20, `tầng ${lv} dựng ${p.size} câu thay vì 20`);
    for (const m of p.matrix) {
      assert.equal(m.actual, m.planned, `tầng ${lv} bậc ${m.stars}★: dựng ${m.actual}, ma trận đòi ${m.planned}`);
    }
  }
});

test('không dùng lại bài học viên vừa luyện trong 30 ngày', () => {
  const { svc, attempts } = rig();
  const first = svc.build({ learnerId: 'HV', level: 3, size: 10 });
  for (const it of first.items) {
    attempts.put({ id: `AT-${it.id}`, learnerId: 'HV', itemId: it.id, formCode: it.formCode, correct: true, at: Date.now() });
  }
  const second = svc.build({ learnerId: 'HV', level: 3, size: 10 });
  const overlap = second.items.filter((it) => first.items.some((f) => f.id === it.id));
  assert.equal(overlap.length, 0, `còn ${overlap.length} bài vừa luyện lọt vào đề`);
  assert.ok(second.excludedRecent >= first.items.length);
});

test('đề dựng lại với cùng dữ liệu cho đúng cùng bộ câu', () => {
  const a = rig().svc.build({ learnerId: 'HV', level: 3, size: 12 });
  const b = rig().svc.build({ learnerId: 'HV', level: 3, size: 12 });
  assert.deepEqual(a.items.map((i) => i.id), b.items.map((i) => i.id));
});

test('có giới hạn thời gian, tính từ thời gian chuẩn từng bài', () => {
  const { svc } = rig();
  const st = svc.start({ learnerId: 'HV', level: 3, size: 10 });
  assert.equal(st.ok, true);
  const sumNorm = st.items.reduce((s, i) => s + i.normSeconds, 0);
  assert.ok(st.timeLimitSec > sumNorm, 'phải rộng hơn tổng thời gian chuẩn');
  assert.ok(st.timeLimitSec < sumNorm * 2, 'nhưng không rộng vô hạn');
});

test('đề không kèm đáp án và lời giải', () => {
  const { svc } = rig();
  const st = svc.start({ learnerId: 'HV', level: 3, size: 8 });
  for (const it of st.items) {
    assert.equal(it.answer, undefined);
    assert.equal(it.solutionSteps, undefined);
    assert.equal(it.hints, undefined, 'thi thì không phát gợi ý');
  }
});

test('chấm theo trọng số: làm đúng bài khó có giá hơn', () => {
  const { svc } = rig();
  const st = svc.start({ learnerId: 'HV', level: 3, size: 12 });
  // Chỉ làm đúng các bài khó nhất
  const sorted = [...st.items].sort((a, b) => b.stars - a.stars);
  const half = Math.floor(sorted.length / 2);
  for (const it of sorted) {
    svc.submitAnswer({ examId: st.examId, itemId: it.itemId, correct: sorted.indexOf(it) < half, ms: 100_000 });
  }
  const r = svc.submit({ examId: st.examId });
  assert.ok(r.weightedScore > r.score, `điểm trọng số ${r.weightedScore} phải cao hơn điểm thô ${r.score} khi làm đúng bài khó`);
});

test('bỏ trống câu nào tính là sai câu đó, có ghi "không làm"', () => {
  const { svc } = rig();
  const st = svc.start({ learnerId: 'HV', level: 3, size: 8 });
  svc.submitAnswer({ examId: st.examId, itemId: st.items[0].itemId, correct: true, ms: 60_000 });
  const r = svc.submit({ examId: st.examId });
  assert.equal(r.answered, 1);
  assert.ok(r.details.filter((d) => !d.answered).length >= 6);
  assert.ok(r.details.some((d) => d.note === 'Không làm'));
});

test('hết giờ thì tự nộp, không nhận thêm câu', () => {
  const { svc } = rig();
  const st = svc.start({ learnerId: 'HV', level: 3, size: 8 });
  const s = svc.sessions.get(st.examId);
  s.deadlineAt = Date.now() - 1000;
  const r = svc.submitAnswer({ examId: st.examId, itemId: st.items[0].itemId, correct: true });
  assert.equal(r.error, 'TIME_UP');
  assert.equal(r.result.reason, 'HẾT_GIỜ');
});

test('thi trượt thì phải chờ mới được thi lại, không học tủ qua đêm', () => {
  const { svc } = rig();
  const st = svc.start({ learnerId: 'HV', level: 3, size: 8 });
  for (const it of st.items) svc.submitAnswer({ examId: st.examId, itemId: it.itemId, correct: false, ms: 60_000 });
  const r = svc.submit({ examId: st.examId });
  assert.equal(r.passedExam, false);

  const again = svc.start({ learnerId: 'HV', level: 3, size: 8 });
  assert.equal(again.ok, false);
  assert.equal(again.error, 'RETAKE_TOO_SOON');
  assert.ok(again.waitDays > 0 && again.waitDays <= RETAKE_WAIT_DAYS);
});

test('thi đạt điểm cao vẫn KHÔNG lên tầng nếu thiếu tiêu chí khác', () => {
  const { svc } = rig();
  const st = svc.start({ learnerId: 'HV', level: 3, size: 12 });
  for (const it of st.items) svc.submitAnswer({ examId: st.examId, itemId: it.itemId, correct: true, ms: 60_000 });
  const r = svc.submit({ examId: st.examId });
  assert.equal(r.passedExam, true, 'làm đúng hết thì phải qua phần thi');

  const ev = svc.evaluatePromotion('HV', 3);
  assert.equal(ev.criteria.exitExam.pass, true, 'tiêu chí thi đã đạt');
  assert.equal(ev.eligible, false, 'nhưng chưa đủ 7 tiêu chí thì không được lên');
  assert.ok(ev.failed.length >= 1);
  assert.match(ev.note, /Điểm thi cao cũng không bù được/);

  const p = svc.promote('HV');
  assert.equal(p.ok, false);
  assert.equal(p.error, 'NOT_ELIGIBLE');
});

test('đủ cả 7 tiêu chí thì lên tầng, có ghi lịch sử', () => {
  const { svc, profiles, mastery, attempts } = rig(1);
  const lv = 1;
  const codes = formsForLevel(lv).map((f) => f.code);
  // Dựng bằng chứng đầy đủ: làm nhiều bài, đúng, nhanh, đủ dạng.
  for (const c of codes) {
    for (let i = 0; i < 12; i++) {
      mastery.update('HV', { formCode: c, stars: 2, correct: true, hintsUsed: 0 });
      attempts.put({ id: `AT-${c}-${i}`, learnerId: 'HV', itemId: `X${i}`, formCode: c, correct: true, ms: 30_000, at: Date.now() - i * 1000 });
    }
  }
  const rec = profiles.get('HV');
  rec.sessionsPassed = 20;

  const st = svc.start({ learnerId: 'HV', level: lv, size: 8 });
  if (st.ok) {
    for (const it of st.items) svc.submitAnswer({ examId: st.examId, itemId: it.itemId, correct: true, ms: 30_000 });
    svc.submit({ examId: st.examId });
  }
  const ev = svc.evaluatePromotion('HV', lv);
  if (ev.eligible) {
    const p = svc.promote('HV', { by: 'GV001' });
    assert.equal(p.ok, true);
    assert.equal(p.to, lv + 1);
    assert.ok(profiles.get('HV').levelHistory.some((h) => h.level === lv + 1));
  } else {
    // Chưa đủ thì phải nói rõ thiếu gì — đó cũng là hành vi đúng.
    assert.ok(ev.failed.length >= 1);
    assert.ok(ev.todo.length >= 1, 'phải nêu việc cần làm tiếp');
  }
});

test('người có thẩm quyền quyết khác máy được, nhưng phải để lại dấu vết', () => {
  const records = [];
  const { svc, profiles } = rig();
  svc.audit = { record: (r) => records.push(r) };
  const before = profiles.get('HV').currentLevel;
  const p = svc.promote('HV', { by: 'GV-HIEUTRUONG', force: true });
  assert.equal(p.ok, true);
  assert.equal(p.forced, true);
  assert.equal(profiles.get('HV').currentLevel, before + 1);
  assert.ok(records.some((r) => r.action === 'learner.promote_forced' && r.severity >= 2));
  assert.ok(profiles.get('HV').levelHistory.at(-1).forced);
});

test('xét lên tầng kiểm cả việc không tụt lùi ở tầng dưới', () => {
  const { svc, mastery } = rig(4);
  const lower = formsForLevel(1).map((f) => f.code).slice(0, 3);
  for (const c of lower) {
    for (let i = 0; i < 6; i++) mastery.update('HV', { formCode: c, stars: 2, correct: false, hintsUsed: 2 });
  }
  const ev = svc.evaluatePromotion('HV', 4);
  assert.ok('noRegression' in ev.criteria);
  assert.equal(ev.criteria.noRegression.pass, false, 'tầng dưới đã tụt mà vẫn cho qua là sai');
  assert.ok(ev.failed.includes('noRegression'));
});

test('bài thi cũng là bằng chứng học tập, vào mức thạo và nhật ký', () => {
  const { svc, mastery, attempts } = rig();
  const before = mastery.summary('HV').totalAttempts;
  const st = svc.start({ learnerId: 'HV', level: 3, size: 8 });
  for (const it of st.items) svc.submitAnswer({ examId: st.examId, itemId: it.itemId, correct: true, ms: 60_000 });
  svc.submit({ examId: st.examId });
  assert.ok(mastery.summary('HV').totalAttempts > before);
  assert.ok(attempts.all().some((a) => a.exam === true));
});

test('mã thi sai, câu ngoài đề, nộp hai lần đều bị chặn', () => {
  const { svc } = rig();
  const st = svc.start({ learnerId: 'HV', level: 3, size: 8 });
  assert.equal(svc.submitAnswer({ examId: 'KHONG-CO', itemId: 'x' }).error, 'EXAM_NOT_FOUND');
  assert.equal(svc.submitAnswer({ examId: st.examId, itemId: 'NGOAI-DE' }).error, 'ITEM_NOT_IN_PAPER');
  svc.submit({ examId: st.examId });
  assert.equal(svc.submit({ examId: st.examId }).error, 'EXAM_FINISHED');
});
