'use strict';
/** Các nhóm API mới: tài khoản, tổ chức, nhập/xuất, biên soạn, đánh giá, lộ trình. */
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

let N, server, base;

before(async () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'gita-api-'));
  process.env.DB_DIR = path.join(tmp, 'db');
  process.env.SNAPSHOT_DIR = path.join(tmp, 'snap');
  const { boot, createServer } = require('../src/index');
  N = await boot({ quiet: true });
  server = createServer(N);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${server.address().port}`;
  // Từ bản vá cổng quyền, phần lớn cổng đòi đăng nhập. Bộ kiểm này đăng nhập
  // THẬT như một client thật — qua cửa khởi tạo rồi POST /accounts/login — chứ
  // không chèn cửa sau cho riêng nó. Một bộ kiểm đi đường riêng thì nó không
  // còn kiểm cái mà người dùng gặp.
  await fetch(`${base}/accounts`, {
    method: 'POST', headers: hd({ 'content-type': 'application/json' }),
    body: JSON.stringify({ username: 'kiem_thu_admin', password: 'Khuon7Dao-Vuon9Xanh!', role: 'ADMIN', fullName: 'Kiểm thử' }),
  });
  const dn = await (await fetch(`${base}/accounts/login`, {
    method: 'POST', headers: hd({ 'content-type': 'application/json' }),
    body: JSON.stringify({ username: 'kiem_thu_admin', password: 'Khuon7Dao-Vuon9Xanh!' }),
  })).json();
  token = dn.token || null;
});

/** Phiên quản trị dùng chung cho cả tệp. */
let token = null;
const hd = (them = {}) => (token ? { ...them, authorization: `Bearer ${token}` } : them);

after(async () => {
  server.close();
  await N.shutdown();
});

const get = async (p) => { const r = await fetch(base + p, { headers: hd() }); return { status: r.status, body: await r.json() }; };
const getRaw = async (p) => { const r = await fetch(base + p, { headers: hd() }); return { status: r.status, text: await r.text(), type: r.headers.get('content-type') }; };
const post = async (p, b) => {
  const r = await fetch(base + p, { method: 'POST', headers: hd({ 'content-type': 'application/json' }), body: JSON.stringify(b) });
  return { status: r.status, body: await r.json() };
};

test('API có đủ các nhóm endpoint', async () => {
  const root = await get('/');
  assert.equal(root.status, 200);
  assert.ok(root.body.endpoints >= 265, `mới có ${root.body.endpoints}`);
  for (const g of ['ACCOUNTS', 'ORG', 'IO', 'AUTHORING', 'ASSESS', 'INSIGHT', 'REPORT',
    'VOICE', 'FILM', 'PHOTO', 'BAIGIANG', 'KHOAHOC', 'NGONNGU']) {
    assert.ok(root.body.groups.includes(g), `thiếu nhóm ${g}`);
  }
});

test('giọng nói: liệt kê giọng, đọc thử, trả về WAV có dấu AI', async () => {
  const st = await get('/voice/status');
  assert.equal(st.status, 200);
  assert.equal(st.body.voices.agentVoices, 500);
  assert.equal(st.body.providers.effective, 'offline', 'mặc định phải là bộ tổng hợp nội bộ');
  assert.equal(st.body.compliance.checklist.ok, true, 'phải đủ 7/7 yêu cầu của luật');

  const vs = await get('/voice/voices?limit=5');
  assert.equal(vs.body.total, 503);
  assert.equal(vs.body.items.length, 5);

  const one = await get(`/voice/voices/${vs.body.items[0].voiceId}`);
  assert.equal(one.status, 200);
  assert.equal((await get('/voice/voices/khong-co-giong-nay')).status, 404);

  const ins = await post('/voice/inspect', { text: 'Giải phương trình $x^{2}=4$.' });
  assert.equal(ins.body.ok, true);
  assert.ok(ins.body.spoken.includes('bình phương'));
  assert.equal(ins.body.unknown.length, 0);

  // Tệp WAV thật, không phải JSON bọc base64
  const res = await fetch(`${base}/voice/say?text=${encodeURIComponent('Chào em')}&agentId=MTH-001`, { headers: hd() });
  assert.match(res.headers.get('content-type'), /audio\/wav/);
  const bytes = Buffer.from(await res.arrayBuffer());
  assert.equal(bytes.toString('ascii', 0, 4), 'RIFF');
  assert.ok(bytes.length > 10_000, `tệp quá nhỏ: ${bytes.length}`);

  // Dấu AI trong sóng âm phải đọc lại được
  const ver = await post('/voice/verify-audio', { audioBase64: bytes.toString('base64') });
  assert.equal(ver.body.aiGenerated, true);
  assert.equal(ver.body.mark.voiceId, 'gv-mth-001');
});

test('giọng nói: tuyến chuyên biệt, nhạc lý và hát qua API', async () => {
  const pl = await get('/voice/pipelines');
  assert.equal(pl.status, 200);
  assert.equal(pl.body.speech.purposes.length, 6);
  assert.ok(pl.body.speech.purposes.some((p) => p.id === 'tep-roi'), 'thiếu tuyến xuất tệp tiếng rời (edge-tts)');
  for (const p of pl.body.speech.purposes) assert.equal(p.effective, 'offline', `${p.id} phải lùi về bộ nội bộ`);
  assert.equal(pl.body.singing.engines[0].id, 'offline-formant');
  assert.equal(pl.body.singing.engines[0].available, true);

  const pre = await get('/voice/studio/presets');
  assert.ok(pre.body.presets.length >= 5);
  assert.equal(pre.body.engine, 'JS_DSP');

  // Ký âm chữ → MIDI → đọc lại: vòng tròn phải khép kín
  const parsed = await post('/voice/music/parse', { melody: 'đô4:1 rê4:1 mi4:2', bpm: 100 });
  assert.equal(parsed.body.ok, true);
  assert.equal(parsed.body.notes.length, 3);
  assert.equal(parsed.body.notes[0].ms, 600);

  const exported = await post('/voice/music/export-midi', { melody: 'đô4:1 rê4:1 mi4:2', bpm: 100 });
  assert.equal(exported.body.ok, true);
  assert.ok(exported.body.bytes > 20);
  const reread = await post('/voice/music/parse', { midiBase64: exported.body.midiBase64 });
  assert.equal(reread.body.ok, true);
  assert.equal(reread.body.bpm, 100);
  assert.equal(reread.body.leadNotes, 3);
  assert.equal((await post('/voice/music/parse', { melody: 'sai:1' })).body.error, 'KÝ_ÂM_SAI');

  // Kiểm bài trước khi hát
  const chk = await post('/voice/song/check', {
    lyrics: 'Quê hương là chùm khế ngọt',
    melody: 'sol4:1 la4:1 si4:1 đô5:1 si4:1 la4:2', bpm: 80, range: 'mezzo',
  });
  assert.equal(chk.body.ok, true);
  assert.equal(chk.body.pitched, 6);
  assert.equal(chk.body.alignment.ok, true);
  assert.equal((await post('/voice/song/check', {})).status, 400);

  // Hát thật, có hậu kỳ và có dấu AI
  const sing = await post('/voice/song/sing', {
    lyrics: 'Quê hương là chùm khế ngọt',
    melody: 'sol4:1 la4:1 si4:1 đô5:1 si4:1 la4:2', bpm: 80, style: 'ballad',
  });
  assert.equal(sing.body.ok, true);
  assert.equal(sing.body.engine, 'offline-formant');
  assert.equal(sing.body.notesSung, 6);
  assert.equal(sing.body.watermarked, true);
  assert.ok(sing.body.studio, 'bản hát phải qua hậu kỳ');
  assert.ok(Math.abs(sing.body.studio.after.lufs - (-14)) < 1.5);
  const wav = Buffer.from(sing.body.audioBase64, 'base64');
  assert.equal(wav.toString('ascii', 0, 4), 'RIFF');
  const mark = await post('/voice/verify-audio', { audioBase64: sing.body.audioBase64 });
  assert.equal(mark.body.aiGenerated, true);
  assert.equal(mark.body.mark.provider, 'sing:offline-formant');

  // Hậu kỳ một tệp có sẵn
  const master = await post('/voice/studio/master', { audioBase64: sing.body.audioBase64, preset: 'phat-thanh' });
  assert.equal(master.body.ok, true);
  assert.ok(Math.abs(master.body.after.lufs - (-14)) < 1.5);
  assert.ok(master.body.steps.length >= 5);

  // Đổi giọng hát: không có đủ đồng ý thì không đi tiếp
  const conv = await post('/voice/song/convert', { audioBase64: 'AAAA', singerId: 'HV-X', targetOwnerId: 'CA-SI-Y' });
  assert.equal(conv.body.ok, false);
  assert.equal(conv.body.error, 'NGƯỜI_HÁT_GỐC_CHƯA_ĐỒNG_Ý');
  assert.equal((await post('/voice/song/convert', {})).status, 400);

  const styles = await get('/voice/song/styles');
  assert.ok(styles.body.styles.length >= 5);
  assert.ok(styles.body.ranges.length >= 6);
});

test('giọng nói: kịch bản giảng bài và hàng rào pháp lý qua API', async () => {
  const nar = await post('/voice/narrate', {
    item: {
      id: 'IT-API', formName: 'Phương trình bậc hai',
      stem: 'Giải $x^{2}-5x+6=0$.', solutionSteps: ['Tính $\\Delta=1$.'],
      hints: [], traps: [], answer: '$x=2$ hoặc $x=3$',
    },
    level: 2,
  });
  assert.equal(nar.body.ok, true);
  assert.ok(nar.body.segments.length >= 6);
  assert.ok(nar.body.estimatedSeconds > 5);
  assert.equal((await post('/voice/narrate', {})).status, 400);

  // Chưa có phiếu đồng ý thì không được phát giọng gắn với học viên
  const denied = await post('/voice/speak', { text: 'xin chào', learnerId: 'HV-API-1' });
  assert.equal(denied.body.ok, false);
  assert.equal(denied.body.error, 'CHƯA_CÓ_ĐỒNG_Ý');

  const bad = await post('/voice/consent', { subjectId: 'HV-API-1', kind: 'VOICE_LISTEN' });
  assert.equal(bad.body.error, 'CHƯA_XÁC_MINH_TUỔI');

  const granted = await post('/voice/consent', { subjectId: 'HV-API-1', kind: 'VOICE_LISTEN', age: 20, method: 'tích chọn trên web' });
  assert.equal(granted.body.ok, true);

  const allowed = await post('/voice/speak', { text: 'xin chào', learnerId: 'HV-API-1' });
  assert.equal(allowed.body.ok, true);
  assert.ok(allowed.body.audioBase64.length > 1000);
  assert.equal(allowed.body.watermarked, true);
  assert.equal(allowed.body.disclosure.aiGenerated, true);

  // Quyền được xoá: xoá xong là hết quyền phát, và có biên bản
  const forgotten = await post('/voice/forget', { subjectId: 'HV-API-1' });
  assert.equal(forgotten.body.ok, true);
  assert.ok(forgotten.body.receipt);
  assert.equal((await post('/voice/speak', { text: 'xin chào', learnerId: 'HV-API-1' })).body.error, 'CHƯA_CÓ_ĐỒNG_Ý');

  const audit = await get('/voice/audit?limit=10');
  assert.equal(audit.body.chain.ok, true, 'chuỗi nhật ký phải nguyên vẹn');
  assert.ok(audit.body.entries.length >= 1);
});

test('tài khoản: tạo, đăng nhập, kiểm quyền qua API', async () => {
  const roles = await get('/accounts/roles');
  assert.equal(roles.body.roles.length, 5);

  const created = await post('/accounts', {
    username: 'gv_api', password: 'Gi4oVien#Api2026', role: 'TEACHER', fullName: 'Giáo viên API',
  });
  assert.equal(created.status, 200);
  assert.equal(created.body.user.passwordHash, undefined, 'không được trả băm mật khẩu');

  const bad = await post('/accounts/login', { username: 'gv_api', password: 'sai' });
  assert.equal(bad.status, 401, 'đăng nhập sai phải trả 401');

  const ok = await post('/accounts/login', { username: 'gv_api', password: 'Gi4oVien#Api2026' });
  assert.equal(ok.status, 200);
  const token = ok.body.token;

  const allow = await post('/accounts/authorize', { token, permission: 'item.read' });
  assert.equal(allow.body.ok, true);
  const deny = await post('/accounts/authorize', { token, permission: 'user.create' });
  assert.equal(deny.status, 403);
});

test('tổ chức: tạo trường, lớp, nhận học viên, chia nhóm', async () => {
  await post('/org/schools', { id: 'SCH-API', name: 'Trường API' });
  const cls = await post('/org/classes', { id: 'CL-API', name: '9X', grade: 9, schoolId: 'SCH-API' });
  assert.equal(cls.status, 200);

  await post('/learner/register', { userId: 'HV-API-1', fullName: 'Học viên Một', grade: 9 });
  await post('/learner/register', { userId: 'HV-API-2', fullName: 'Học viên Hai', grade: 9 });
  assert.equal((await post('/org/classes/CL-API/enroll', { learnerId: 'HV-API-1' })).body.ok, true);
  assert.equal((await post('/org/classes/CL-API/enroll', { learnerId: 'HV-API-2' })).body.ok, true);

  const roster = await get('/org/classes/CL-API/roster');
  assert.equal(roster.body.size, 2);
  const groups = await post('/org/classes/CL-API/auto-group', { maxPerGroup: 1 });
  assert.equal(groups.body.ok, true);
  assert.ok(groups.body.groups.length >= 1);

  assert.equal((await get('/org/classes/KHONG-CO')).status, 404);
});

test('nhập/xuất: mẫu tải về dùng được, xuất ra CSV thật', async () => {
  const tpl = await getRaw('/io/learner-template');
  assert.equal(tpl.status, 200);
  assert.match(tpl.type, /text\/csv/);
  assert.ok(tpl.text.includes('ho_ten'));

  const dry = await post('/io/import-learners', { csv: tpl.text, classId: 'CL-API', dryRun: true });
  assert.equal(dry.body.ok, true);
  assert.equal(dry.body.dryRun, true);
  assert.ok(dry.body.accepted >= 1);

  const res = await fetch(base + '/io/export-learners?classId=CL-API', { headers: hd() });
  assert.match(res.headers.get('content-type'), /text\/csv/);
  // fetch().text() nuốt BOM theo chuẩn WHATWG, nên phải soi byte thô.
  const bytes = new Uint8Array(await res.arrayBuffer());
  assert.deepEqual([...bytes.slice(0, 3)], [0xEF, 0xBB, 0xBF], 'CSV xuất ra phải có BOM cho Excel');
  const text = Buffer.from(bytes).toString('utf8');
  assert.ok(text.includes('ho_ten'), 'tệp rỗng cũng phải có dòng tiêu đề');
});

test('biên soạn: bản thiết kế, sinh bài thử, độ phủ kho', async () => {
  const bp = await get('/authoring/blueprints');
  assert.ok(bp.body.count >= 20);
  for (const b of bp.body.items) assert.ok(b.intent && b.targetTrap);

  const gen = await post('/authoring/generate', { formCode: 'M9.PT2.GIAI', level: 3, count: 3, dryRun: true });
  assert.equal(gen.body.ok, true);
  assert.ok(gen.body.produced >= 1);

  const cov = await get('/authoring/coverage');
  assert.equal(cov.body.ok, true);
  assert.ok(cov.body.ratio > 0.9, `độ phủ mới ${cov.body.ratio}`);
});

test('thẩm định toán học qua API: giải, so tương đương, soát nghiệm', async () => {
  assert.deepEqual((await post('/math/solve', { equation: 'x^2-5x+6=0' })).body.roots, [2, 3]);
  assert.equal((await post('/math/equivalent', { a: '(a+b)^2', b: 'a^2+2ab+b^2' })).body.equal, true);
  const wrong = await post('/math/check-roots', { equation: 'x^2-5x+6=0', answer: 'x = 2' });
  assert.equal(wrong.body.correct, false);
  assert.deepEqual(wrong.body.missing, [3]);
});

test('chẩn đoán đầu vào chạy trọn vòng qua API', async () => {
  const st = await post('/placement/start', { learnerId: 'HV-API-1', grade: 9 });
  assert.equal(st.body.ok, true);
  let cur = st.body.item;
  let last = null;
  for (let i = 0; i < 25 && cur; i++) {
    const r = await post('/placement/answer', { sessionId: st.body.sessionId, itemId: cur.id, correct: i % 3 !== 2, ms: 100_000 });
    assert.equal(r.body.ok, true);
    if (r.body.done) { last = r.body; break; }
    cur = r.body.item;
  }
  assert.ok(last, 'phiên chẩn đoán phải kết thúc');
  assert.ok(last.placedLevel >= 0 && last.placedLevel <= 9);
  assert.ok(last.recommendation.length >= 1);
});

test('luyện tập chạy trọn vòng qua API và chấm tự động', async () => {
  const st = await post('/practice/start', { learnerId: 'HV-API-1', size: 6 });
  assert.equal(st.body.ok, true);
  assert.ok(st.body.plan.every((p) => p.why));

  let cur = st.body.item;
  let done = null;
  for (let i = 0; i < 15 && cur; i++) {
    const r = await post('/practice/answer', { sessionId: st.body.sessionId, itemId: cur.itemId, correct: true, ms: 90_000 });
    assert.equal(r.body.ok, true);
    if (r.body.done) { done = r.body; break; }
    cur = r.body.next;
  }
  const rep = done || (await post('/practice/finish', { sessionId: st.body.sessionId })).body;
  assert.ok(rep.answered >= 1);
  assert.ok(rep.nextAdvice.length >= 1);
});

test('thi cuối tầng và xét lên tầng qua API', async () => {
  const st = await post('/exam/start', { learnerId: 'HV-API-2', level: 3, size: 8 });
  if (st.body.ok) {
    for (const it of st.body.items) {
      await post('/exam/answer', { examId: st.body.examId, itemId: it.itemId, correct: true, ms: 60_000 });
    }
    const r = await post('/exam/submit', { examId: st.body.examId });
    assert.equal(r.body.ok, true);
    assert.ok(r.body.weightedScore >= 0);
  }
  const pr = await get('/promotion/HV-API-2');
  assert.equal(pr.body.ok, true);
  assert.equal(typeof pr.body.eligible, 'boolean');
  assert.ok(Array.isArray(pr.body.failed));
});

test('hành vi và lộ trình qua API', async () => {
  const b = await get('/behavior/HV-API-1');
  assert.equal(b.body.ok, true);
  for (const k of ['guessing', 'attentionSpan', 'anomalies', 'trend']) assert.ok(k in b.body);

  const rm = await post('/roadmap/generate', { learnerId: 'HV-API-1' });
  assert.equal(rm.body.ok, true);
  assert.equal(rm.body.weeks.length, 13);

  const wk = await get('/roadmap/HV-API-1/this-week');
  assert.equal(wk.body.ok, true);
  const pg = await get('/roadmap/HV-API-1/progress');
  assert.equal(pg.body.ok, true);
  const rev = await post('/roadmap/HV-API-1/weekly-review', { week: 1 });
  assert.equal(rev.body.ok, true);
  assert.ok(rev.body.summary.length > 10);
});

test('làm phim: đọc kịch bản, chuẩn bị, bản nháp, chặn dựng thật qua API', async () => {
  const res = await fetch(`${base}/film/sample-script`, { headers: hd() });
  assert.match(res.headers.get('content-type'), /text\/plain/);
  const kichBan = await res.text();
  assert.ok(kichBan.includes('CẢNH 1'));

  const parsed = await post('/film/parse', { kichBan });
  assert.equal(parsed.body.ok, true);
  assert.equal(parsed.body.canh.length, 3);
  assert.equal(parsed.body.nhanVat.length, 2);
  assert.equal((await post('/film/parse', {})).status, 400);

  const models = await get('/film/models');
  assert.ok(models.body.models.length >= 6);
  assert.equal(models.body.uuTien.length, 3);

  // NẤC 1 — tiền kỳ, không tốn đồng nào
  const p = await post('/film/prepare', { kichBan, uuTien: 'can-bang' });
  assert.equal(p.body.ok, true);
  assert.ok(p.body.canhQuay >= 8);
  assert.ok(p.body.duToan.usd > 0);
  assert.equal(p.body.qc.ok, true);
  assert.equal(p.body.soSanhGia.length, 3);
  assert.equal(p.body.trangThai, 'SẴN_SÀNG_DỰNG');
  const duAn = p.body.duAn;

  // Vượt ngân sách là lỗi CHẶN, và phải nói rõ
  const ngheo = await post('/film/prepare', { kichBan, nganSachUsd: 0.5 });
  assert.equal(ngheo.body.qc.ok, false);
  assert.ok(ngheo.body.qc.loi.some((l) => l.loai === 'VƯỢT_NGÂN_SÁCH'));

  // NẤC 2 — bản nháp: đường tiếng thật
  const d = await post(`/film/projects/${duAn}/draft`, {});
  assert.equal(d.body.ok, true);
  assert.equal(d.body.khung, p.body.canhQuay);
  assert.ok(d.body.tiengGiay > 30);
  assert.ok(d.body.duongTiengBase64.length > 10_000);

  const wav = await fetch(`${base}/film/projects/${duAn}/soundtrack`, { headers: hd() });
  assert.match(wav.headers.get('content-type'), /audio\/wav/);
  const bytes = Buffer.from(await wav.arrayBuffer());
  assert.equal(bytes.toString('ascii', 0, 4), 'RIFF');

  const ani = await fetch(`${base}/film/projects/${duAn}/animatic`, { headers: hd() });
  assert.match(ani.headers.get('content-type'), /text\/html/);
  const html = await ani.text();
  assert.ok(html.includes('<audio'));
  assert.ok(html.includes('do máy tổng hợp'), 'phim nháp phải công bố nội dung AI');

  const sb = await fetch(`${base}/film/projects/${duAn}/storyboard/q001`, { headers: hd() });
  assert.match(sb.headers.get('content-type'), /image\/svg/);
  assert.ok((await sb.text()).startsWith('<svg'));

  const edl = await fetch(`${base}/film/projects/${duAn}/edl`, { headers: hd() });
  assert.ok((await edl.text()).startsWith('TITLE:'));
  const sh = await fetch(`${base}/film/projects/${duAn}/ffmpeg`, { headers: hd() });
  assert.ok((await sh.text()).includes('ffmpeg'));

  // NẤC 3 — chưa có khoá thì chặn, và trả 503 chứ không phải 200
  const r = await post(`/film/projects/${duAn}/render`, { xacNhan: true });
  assert.equal(r.status, 503);
  assert.equal(r.body.error, 'CHƯA_CÓ_CỔNG_DỰNG_VIDEO');

  const ds = await get('/film/projects');
  assert.ok(ds.body.tong >= 1);
  assert.equal((await get('/film/projects/PHIM-KHONG-CO')).status, 404);
});

test('xưởng ảnh: chuẩn bị, khung dựng, hậu kỳ 8 tầng, đo chất lượng qua API', async () => {
  const PNGmod = require('../src/photo/png');
  const st = await get('/photo/status');
  assert.equal(st.status, 200);
  assert.equal(st.body.mayAnh.length, 9);
  assert.equal(st.body.phim.length, 7);
  assert.deepEqual(st.body.dinhDangDocDuoc, ['png', 'jpeg (baseline)']);

  const cam = await get('/photo/cameras');
  assert.ok(cam.body.mayAnh.every((m) => m.ten && m.mau));

  const bc = await get('/photo/compositions?kieuAnh=chan-dung');
  assert.ok(bc.body.boCuc.length >= 2);
  assert.ok(bc.body.boCuc.every((b) => b.chuThe && b.chuThe.x > 0), 'bố cục phải có toạ độ thật');

  // Tầng 1–2: không cần mạng
  const pr = await post('/photo/prepare', { moTa: 'Chân dung phụ nữ áo dài đỏ bên hồ sen', kieuAnh: 'chan-dung', mayAnh: 'Fujifilm', phim: 'KodakPortra400' });
  assert.equal(pr.body.ok, true);
  assert.ok(pr.body.prompt.length > 100);
  assert.ok(pr.body.daThem.length >= 5);
  assert.ok(pr.body.khungDungByte > 500);
  assert.equal((await post('/photo/prepare', {})).status, 400);

  const fr = await fetch(`${base}/photo/framing`, {
    method: 'POST', headers: hd({ 'content-type': 'application/json' }),
    body: JSON.stringify({ moTa: 'chân dung', kieuAnh: 'chan-dung' }),
  });
  assert.match(fr.headers.get('content-type'), /image\/svg/);
  const svg = await fr.text();
  assert.ok(svg.startsWith('<svg') && svg.includes('không phải ảnh chụp'));

  // Tầng 3–8: hậu kỳ trên ảnh có sẵn — không cần mạng, không cần khoá
  const W = 240; const H = 160;
  const anh = PNGmod.taoAnh(W, H);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const i = (y * W + x) * 4;
      anh.data[i] = 70 + (x % 60); anh.data[i + 1] = 90 + (y % 50); anh.data[i + 2] = 120; anh.data[i + 3] = 255;
    }
  }
  const b64 = PNGmod.ghiPNG(anh).toString('base64');

  const en = await post('/photo/enhance', { anhBase64: b64, mayAnh: 'Fujifilm', phim: 'KodakPortra400', chatLuong: 'hd' });
  assert.equal(en.body.ok, true);
  assert.equal(en.body.rong, 1280);
  assert.ok(Math.abs(en.body.rong / en.body.cao - W / H) < 0.01, 'phải giữ tỉ lệ khung hình');
  assert.ok(en.body.buoc.length >= 6);
  assert.ok(en.body.cham.chiTiet.length === 7);
  assert.ok(en.body.soSanh.bang.length === 7);
  const png = Buffer.from(en.body.pngBase64, 'base64');
  const jpg = Buffer.from(en.body.jpegBase64, 'base64');
  assert.equal(PNGmod.nhanDang(png), 'png');
  assert.equal(PNGmod.nhanDang(jpg), 'jpeg');
  assert.equal(PNGmod.docPNG(png).width, 1280);
  assert.ok(en.body.sieuDuLieu.Make, 'phải gắn siêu dữ liệu máy ảnh');

  const me = await post('/photo/measure', { anhBase64: b64 });
  assert.equal(me.status, 200);
  assert.equal(me.body.chiTiet.length, 7);
  assert.equal((await post('/photo/measure', {})).status, 400);
  assert.equal((await post('/photo/enhance', { anhBase64: Buffer.from('rác').toString('base64') })).status, 415);

  const cc = await get('/photo/compare-cameras?a=Hasselblad&b=ARRI');
  assert.ok(cc.body.khacBiet.tuongPhan, 'phải nói rõ hai hồ sơ khác nhau ở đâu');

  // Sinh ảnh cần mạng — môi trường này chặn, nên phải trả 503 kèm lối ra
  const g = await post('/photo/generate', { moTa: 'thử' });
  if (!g.body.ok) {
    assert.equal(g.status, 503);
    assert.ok(g.body.goi.includes('hậu kỳ'), 'phải chỉ ra vẫn dùng được hậu kỳ');
  }
});

test('mọi endpoint mới trả mã HTTP đúng nghĩa khi hỏng', async () => {
  assert.equal((await get('/accounts/KHONG-CO')).status, 404);
  assert.equal((await get('/roadmap/KHONG-CO/this-week')).status, 404);
  assert.equal((await post('/placement/start', {})).status, 400);
  assert.equal((await post('/practice/answer', { sessionId: 'KHONG-CO' })).status, 404);
  assert.equal((await post('/org/classes/KHONG-CO/enroll', { learnerId: 'x' })).status, 404);
  assert.equal((await post('/accounts', { username: 'gv_api', password: 'Gi4oVien#Api2026', role: 'TEACHER' })).status, 409,
    'tên đăng nhập trùng là xung đột, không phải lỗi cú pháp');
  assert.equal((await post('/exam/submit', { examId: 'KHONG-CO' })).status, 404);
});
