'use strict';
/** Biên soạn có ràng buộc: hết ý đồ mới đến tham số, máy tự soát, chống trùng ở cửa. */
const { test } = require('node:test');
const { cacBuoc, vanBanDayDu } = require('../src/content/loi-giai');
const assert = require('node:assert/strict');

const ItemBank = require('../src/content/item-bank');
const ItemGenerator = require('../src/content/generator');
const MathVerifier = require('../src/math/verifier');
const { FORM_INDEX } = require('../src/curriculum/hierarchy');
const { BLUEPRINTS, validateBlueprints, blueprintsForForm } = require('../src/content/blueprint');

const fresh = () => { const bank = new ItemBank(); return { bank, gen: new ItemGenerator({ bank }) }; };

// ── Bản thiết kế ────────────────────────────────────────────────────────────

test('mọi bản thiết kế đều hợp lệ và gắn vào bẫy có thật của dạng', () => {
  const v = validateBlueprints(FORM_INDEX);
  assert.equal(v.ok, true, v.errors.join('; '));
  assert.ok(v.blueprints >= 12, `mới có ${v.blueprints} bản thiết kế`);
  assert.ok(v.forms >= 8);
});

test('mỗi bản thiết kế có ý đồ sư phạm riêng, không trùng nhau', () => {
  const intents = BLUEPRINTS.map((b) => b.intent);
  assert.equal(new Set(intents).size, intents.length, 'có hai bản thiết kế cùng một ý đồ');
});

test('không gian tham số sinh ra bộ tham số thoả ràng buộc toán học', () => {
  const bp = BLUEPRINTS.find((b) => b.id === 'BP.M9.PT2.NGHIEM_NGUYEN');
  let n = 0;
  for (const p of bp.space()) {
    const delta = p.b * p.b - 4 * p.a * p.c;
    assert.ok(delta > 0, `Δ phải dương: ${JSON.stringify(p)}`);
    assert.ok(Number.isInteger(Math.sqrt(delta)), `Δ phải chính phương: ${JSON.stringify(p)}`);
    assert.notEqual(p.r1, p.r2);
    if (++n > 200) break;
  }
  assert.ok(n > 20, 'không gian quá hẹp');
});

test('bản thiết kế Δ<0 chỉ sinh phương trình vô nghiệm thật', () => {
  const bp = BLUEPRINTS.find((b) => b.id === 'BP.M9.PT2.DELTA_AM');
  const v = new MathVerifier();
  let n = 0;
  for (const p of bp.space()) {
    assert.ok(p.b * p.b - 4 * p.a * p.c < 0);
    if (++n > 30) break;
  }
  const first = bp.space().next().value;
  assert.deepEqual(v.solve(bp.render(first).check.equation).roots, []);
});

// ── Sinh bài ────────────────────────────────────────────────────────────────

test('dùng hết ý đồ trước, mới quay lại lặp tham số', () => {
  const { gen } = fresh();
  const pool = blueprintsForForm('M9.PT2.GIAI').filter((b) => b.levels[0] <= 3 && b.levels[1] >= 3);
  const r = gen.generate({ formCode: 'M9.PT2.GIAI', level: 3, count: pool.length, seed: 'x' });
  assert.equal(r.produced, pool.length);
  assert.equal(r.blueprintsUsed, pool.length, 'bài đầu tiên của mỗi ý đồ phải khác nhau hết');
  assert.equal(new Set(r.items.map((i) => i.blueprintId)).size, pool.length);
});

test('mỗi bài mang theo xuất xứ: bản thiết kế, ý đồ, bộ tham số', () => {
  const { gen } = fresh();
  const r = gen.generate({ formCode: 'M8.HANGDANGTHUC.BAY', level: 3, count: 3, seed: 'x' });
  for (const it of r.items) {
    assert.ok(it.blueprintId, 'thiếu mã bản thiết kế');
    assert.ok(it.intent && it.intent.length > 20);
    assert.ok(it.params && Object.keys(it.params).length > 0);
    assert.ok(it.traps.length >= 1, 'phải nêu bẫy nhắm tới');
  }
});

test('cùng seed ra đúng cùng bộ bài, từng chữ một', () => {
  const a = fresh().gen.generate({ formCode: 'M8.PT.BACNHAT', level: 3, count: 5, seed: 'ket-qua-on-dinh' });
  const b = fresh().gen.generate({ formCode: 'M8.PT.BACNHAT', level: 3, count: 5, seed: 'ket-qua-on-dinh' });
  assert.deepEqual(a.items.map((i) => i.stem), b.items.map((i) => i.stem));
  assert.deepEqual(a.items.map((i) => i.answer), b.items.map((i) => i.answer));
});

test('seed khác cho bộ bài khác — vẫn tất định, không phải ngẫu nhiên', () => {
  const a = fresh().gen.generate({ formCode: 'M8.PT.BACNHAT', level: 3, count: 5, seed: 'lop-9a' });
  const b = fresh().gen.generate({ formCode: 'M8.PT.BACNHAT', level: 3, count: 5, seed: 'lop-9b' });
  assert.notDeepEqual(a.items.map((i) => i.stem), b.items.map((i) => i.stem));
});

test('mọi bài sinh ra đều qua được bộ kiểm tra toán học độc lập', () => {
  const { gen } = fresh();
  const v = new MathVerifier();
  let checked = 0;
  for (const form of ['M9.PT2.GIAI', 'M8.PT.BACNHAT', 'M8.HANGDANGTHUC.BAY', 'M9.HPT.BACNHAT']) {
    const r = gen.generate({ formCode: form, level: 3, count: 4, seed: 'kiem-dinh' });
    for (const it of r.items) {
      const verdict = v.verifyItem(it);
      assert.equal(verdict.verified, true, `${it.blueprintId}: ${verdict.reason}`);
      checked++;
    }
  }
  assert.ok(checked >= 10, `mới kiểm được ${checked} bài`);
});

test('hạn mức khung bài bám chặt: không khuôn nào vượt quá 3 bài', () => {
  const { gen } = fresh();
  const { structuralSignature, answerShape } = require('../src/content/dedupe');
  const { STRUCTURAL_QUOTA } = require('../src/content/dedupe');
  const r = gen.generate({ formCode: 'M9.PT2.GIAI', level: 3, count: 60, seed: 'in-hang-loat' });

  const byShape = {};
  for (const it of r.items) {
    const sig = structuralSignature('M9.PT2.GIAI', it.stem, answerShape(it));
    byShape[sig] = (byShape[sig] || 0) + 1;
  }
  const worst = Math.max(...Object.values(byShape));
  assert.ok(worst <= (STRUCTURAL_QUOTA || 3), `có khuôn bị in ${worst} lần`);
  assert.ok(r.produced < 60, `sinh được ${r.produced}/60 — hạn mức chưa bám`);
  assert.ok(r.rejected > r.produced, `loại ${r.rejected} / nhận ${r.produced} — phải loại áp đảo khi khuôn đã cạn`);
  assert.ok(r.rejections.some((x) => /trùng|TEMPLATE_OVERUSE|hết/.test(x.reason)), JSON.stringify(r.rejections.slice(0, 3)));
  assert.match(r.note, /phải có thêm BẢN THIẾT KẾ/);
});

test('đổi dấu hệ số vẫn là cùng một khuôn, không phải bài mới', () => {
  const { structuralSignature } = require('../src/content/dedupe');
  const a = structuralSignature('M9.PT2.GIAI', 'Giải phương trình $x^{2} + 11x + 30 = 0$.', 'roots:2');
  const b = structuralSignature('M9.PT2.GIAI', 'Giải phương trình $x^{2} - 3x - 10 = 0$.', 'roots:2');
  assert.equal(a, b, 'chỉ đổi dấu và đổi số thì vẫn là một khuôn');
});

test('cùng khuôn nhưng đáp án khác hẳn thì là họ bài khác', () => {
  const { structuralSignature } = require('../src/content/dedupe');
  const coNghiem = structuralSignature('M9.PT2.GIAI', 'Giải phương trình $x^{2} - 3x - 10 = 0$.', 'roots:2');
  const voNghiem = structuralSignature('M9.PT2.GIAI', 'Giải phương trình $x^{2} + 3x + 8 = 0$.', 'roots:0');
  assert.notEqual(coNghiem, voNghiem, 'vô nghiệm đòi kết luận khác hẳn, không thể gộp chung hạn mức');
});

test('bản ghi bài đi qua được JSON — còn phải ghi đĩa và trả qua API', () => {
  const { bank, gen } = fresh();
  const r = gen.generate({ formCode: 'M9.PT2.GIAI', level: 3, count: 2, seed: 'json' });
  for (const it of r.items) {
    const stored = bank.get(it.id);
    const json = JSON.stringify(stored);           // BigInt ở đây là ném lỗi ngay
    assert.ok(json.length > 100);
    assert.equal(typeof JSON.parse(json).fingerprint.simhash, 'string');
  }
});

test('không có bản thiết kế thì nói thẳng, không sinh bừa', () => {
  const { gen } = fresh();
  // Lấy một dạng CHƯA có bản thiết kế ngay lúc chạy: khi kho bản thiết kế lớn
  // dần, dạng nào cũng có thể được phủ, nên không được ghim cứng mã dạng nào.
  const { BLUEPRINTS } = require('../src/content/blueprint');
  const coBanVe = new Set(BLUEPRINTS.map((b) => b.formCode));
  const trong = [...FORM_INDEX.values()].find((f) => !coBanVe.has(f.code));
  if (!trong) return;                 // mọi dạng đã có bản thiết kế: không còn gì để thử
  const r = gen.generate({ formCode: trong.code, level: trong.levelRange[0], count: 3 });
  assert.equal(r.ok, false);
  assert.equal(r.error, 'NO_BLUEPRINT');
  assert.match(r.hint, /KHÔNG được sinh bừa/);
});

test('dạng lạ và tầng ngoài phạm vi bị từ chối', () => {
  const { gen } = fresh();
  assert.equal(gen.generate({ formCode: 'KHONG.CO', level: 3 }).error, 'UNKNOWN_FORM');
  assert.equal(gen.generate({ formCode: 'M9.PT2.GIAI', level: 9 }).error, 'LEVEL_OUT_OF_RANGE');
});

test('bài vào kho ở trạng thái đã được máy thẩm định', () => {
  const { bank, gen } = fresh();
  const r = gen.generate({ formCode: 'M9.PT2.GIAI', level: 3, count: 3, seed: 'kho' });
  for (const it of r.items) {
    const stored = bank.get(it.id);
    assert.equal(stored.status, 'VERIFIED', 'máy đã tự giải lại nên phải là VERIFIED, chưa PUBLISHED');
    assert.equal(stored.verification.verifierId, 'MATH-ENGINE');
  }
});

test('chạy thử không ghi vào kho', () => {
  const { bank, gen } = fresh();
  const r = gen.generate({ formCode: 'M9.PT2.GIAI', level: 3, count: 3, seed: 'thu', dryRun: true });
  assert.equal(r.produced, 3);
  assert.equal(bank.items.size, 0);
});

test('soạn phủ một tầng: đi qua mọi dạng có bản thiết kế', () => {
  const { gen } = fresh();
  const r = gen.generateForLevel({ level: 3, perForm: 2, seed: 'tang3' });
  assert.ok(r.forms >= 5, `mới phủ ${r.forms} dạng`);
  assert.ok(r.produced >= r.forms, 'mỗi dạng ít nhất một bài');
  assert.ok(r.coverage > 0.5, `độ phủ ${r.coverage}`);
});

test('bài sinh ra đạt chuẩn 5★ về trình bày và sư phạm', () => {
  const { gen } = fresh();
  const r = gen.generate({ formCode: 'M9.PT2.VIET', level: 5, count: 2, seed: 'chatluong' });
  for (const it of r.items) {
    assert.equal(it.quality.blockers.length, 0, JSON.stringify(it.quality.blockers));
    assert.ok(it.quality.weighted >= 4.5, `điểm ${it.quality.weighted}`);
    assert.ok(it.solutionSteps.length >= 3, 'lời giải phải đủ bước');
    assert.ok(it.hints.length >= 3, 'phải có đủ gợi ý bậc thang');
  }
});

test('bài thực tế có bối cảnh thật, không phải đại số khoác áo', () => {
  const { gen } = fresh();
  const r = gen.generate({ formCode: 'M5.TISO.PHANTRAM', level: 5, count: 2, seed: 'thucte' });
  assert.ok(r.produced >= 1);
  for (const it of r.items) {
    assert.match(it.context, /thực tế/);
    assert.match(it.stem, /đồng/);
    // Bước giải nay gồm hai phần: thao tác và CĂN CỨ. Cả hai đều là lời văn
    // người học đọc, nên phép kiểm phải soi cả hai chứ không chỉ phần thao tác.
    const loi = cacBuoc(it).map(vanBanDayDu).join(' ');
    assert.match(loi, /mốc|GIÁ MỚI|khác nhau/, 'phải giải thích vì sao không về chỗ cũ');
  }
});
