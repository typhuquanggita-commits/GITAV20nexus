'use strict';
/** Báo cáo: mỗi con số kèm cỡ mẫu, mẫu nhỏ thì nói thẳng là chưa đủ căn cứ. */
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const ReportService = require('../src/report/reports');
const { MIN_SAMPLE } = ReportService;

let N;

before(async () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'gita-rep-'));
  process.env.DB_DIR = path.join(tmp, 'db');
  process.env.SNAPSHOT_DIR = path.join(tmp, 'snap');
  N = await require('../src/index').boot({ quiet: true });

  N.org.createSchool({ id: 'SCH-R', name: 'Trường báo cáo' });
  N.org.createClass({ id: 'CL-R', name: '9R', grade: 9, schoolId: 'SCH-R', capacity: 20 });

  // Ba học viên với ba hồ sơ khác hẳn nhau.
  const setup = [
    { id: 'HV-GIOI', name: 'Em Giỏi', n: 40, ok: (i) => i % 10 !== 0 },
    { id: 'HV-YEU', name: 'Em Yếu', n: 40, ok: (i) => i % 3 === 0 },
    { id: 'HV-ITBAI', name: 'Em Ít Bài', n: 3, ok: () => true },
    { id: 'HV-CHUAHOC', name: 'Em Chưa Học', n: 0, ok: () => true },
  ];
  for (const s of setup) {
    N.profiles.register(s.id, { fullName: s.name, grade: 9 });
    N.org.enroll('CL-R', s.id);
    for (let i = 0; i < s.n; i++) {
      const formCode = i % 2 === 0 ? 'M9.PT2.GIAI' : 'M8.PT.BACNHAT';
      N.telemetry.attempt(s.id, { itemId: `I${i}`, formCode, correct: s.ok(i), ms: 120_000, hintsUsed: 0, stars: 3 });
      N.mastery.update(s.id, { formCode, stars: 3, correct: s.ok(i), hintsUsed: 0 });
    }
  }
});

after(async () => { await N.shutdown(); });

// ── Học viên ────────────────────────────────────────────────────────────────

test('báo cáo học viên có đủ khối lượng, kết quả, theo dạng và xu hướng', () => {
  const r = N.reports.learner('HV-GIOI');
  assert.equal(r.ok, true);
  assert.equal(r.kind, 'LEARNER');
  assert.equal(r.learner.fullName, 'Em Giỏi');
  assert.ok(r.volume.itemsInPeriod >= 30);
  assert.ok(r.performance.accuracy > 0.8);
  assert.equal(r.performance.sampleSize, r.volume.itemsInPeriod);
  assert.ok(r.byForm.length >= 2);
  assert.ok(r.weeklyVolume.length >= 4, 'phải có đường đi theo tuần');
  assert.ok(r.summary.includes('Em Giỏi'));
});

test('mẫu nhỏ thì báo cáo nói thẳng là chưa đủ căn cứ', () => {
  const r = N.reports.learner('HV-ITBAI');
  assert.equal(r.ok, true);
  assert.equal(r.performance.sampleSize, 3);
  assert.ok(r.performance.note, 'phải có cảnh báo cỡ mẫu');
  assert.match(r.performance.note, /chưa đủ căn cứ/);
  assert.match(r.summary, /cỡ mẫu còn nhỏ/);
});

test('học viên chưa làm bài nào được nói rõ, không báo 0% như thể đã cố', () => {
  const r = N.reports.learner('HV-CHUAHOC');
  assert.equal(r.volume.itemsInPeriod, 0);
  assert.equal(r.performance.accuracy, null, 'chưa làm bài thì không có tỉ lệ đúng');
  assert.match(r.summary, /chưa làm bài nào/);
});

test('báo cáo chỉ ra dạng yếu nhất dựa trên số bài đủ lớn', () => {
  const r = N.reports.learner('HV-YEU');
  assert.ok(r.weakest.length >= 1);
  for (const w of r.weakest) {
    assert.ok(w.enough, 'không được kết luận yếu dựa trên vài bài');
    assert.ok(w.accuracy < 0.6);
  }
});

// ── Lớp ─────────────────────────────────────────────────────────────────────

test('báo cáo lớp tách bạch em có học và em chưa học', () => {
  const r = N.reports.classReport('CL-R');
  assert.equal(r.ok, true);
  assert.equal(r.class.size, 4);
  assert.equal(r.participation.active, 3);
  assert.equal(r.participation.inactive, 1);
  assert.equal(r.participation.inactiveLearners[0].fullName, 'Em Chưa Học');
});

test('tỉ lệ của lớp chỉ tính trên em đủ số bài, và nói rõ đã loại ai', () => {
  const r = N.reports.classReport('CL-R');
  assert.ok(r.performance.measurable <= r.class.size);
  assert.ok(r.performance.note, 'phải nói rõ có em không được tính');
  assert.match(r.performance.note, new RegExp(`${MIN_SAMPLE} bài`));
  assert.ok(r.performance.median > 0 && r.performance.median <= 1);
  assert.ok(r.performance.spread >= 0, 'phải đo được độ phân hoá của lớp');
});

test('danh sách cần chú ý gom đúng em yếu, em tụt và em chưa học', () => {
  const r = N.reports.classReport('CL-R');
  const ids = r.needAttention.map((x) => x.id);
  assert.ok(ids.includes('HV-YEU'), 'em yếu phải có trong danh sách');
  assert.ok(ids.includes('HV-CHUAHOC'), 'em chưa làm bài nào phải có trong danh sách');
  assert.ok(!ids.includes('HV-GIOI'), 'em đang học tốt không nên bị gắn cờ');
});

test('chỉ ra dạng cả lớp cùng yếu để dạy lại chung', () => {
  const r = N.reports.classReport('CL-R');
  assert.ok(Array.isArray(r.classWideWeakForms));
  for (const f of r.classWideWeakForms) {
    assert.ok(f.items >= MIN_SAMPLE, 'không kết luận cả lớp yếu từ vài bài');
    assert.ok(f.learners >= 2, 'phải nhiều em cùng yếu mới là vấn đề của lớp');
    assert.ok(f.accuracy < 0.6);
  }
});

test('phổ trình độ của lớp được thống kê', () => {
  const r = N.reports.classReport('CL-R');
  assert.ok(r.levelSpread.byLevel);
  assert.ok(r.levelSpread.max >= r.levelSpread.min);
});

// ── Hệ thống ────────────────────────────────────────────────────────────────

test('báo cáo hệ thống đếm kho, người dùng và mức sử dụng', () => {
  const r = N.reports.system();
  assert.equal(r.ok, true);
  assert.ok(r.content.total > 50);
  assert.ok(r.content.coverage.ratio >= 0.9);
  assert.ok(r.people.learners >= 4);
  assert.ok(r.usage.totalAttempts > 50);
  assert.ok(r.fleet, 'phải kèm tình trạng đội agent');
});

test('phát hiện của hệ thống luôn kèm việc cần làm', () => {
  const r = N.reports.system();
  assert.ok(r.findings.length >= 1);
  for (const f of r.findings) {
    assert.ok(['cao', 'vừa', 'thấp'].includes(f.severity), f.severity);
    assert.ok(f.what, 'phát hiện phải nói rõ vấn đề gì');
    if (f.what !== 'Không có vấn đề nổi bật') {
      assert.ok(f.action && f.action.length > 10, `"${f.what}" không nói được nên làm gì`);
    }
  }
});

test('hệ thống không gợi ý hạ chuẩn để lấp kho', () => {
  const r = N.reports.system();
  const all = r.findings.map((f) => f.action).join(' ');
  assert.ok(!/hạ ngưỡng|nới lỏng chống trùng|giảm tiêu chuẩn/i.test(all) || /không được hạ chuẩn/.test(all));
});

// ── Xuất CSV ────────────────────────────────────────────────────────────────

test('xuất báo cáo lớp và học viên ra CSV dùng được ngay', () => {
  const cls = N.reports.exportCSV('class', 'CL-R');
  assert.equal(cls.ok, true);
  assert.ok(cls.content.startsWith('﻿'), 'phải có BOM cho Excel');
  assert.ok(cls.content.includes('ho_ten'));
  assert.equal(cls.content.trim().split('\n').length, 5, '1 tiêu đề + 4 học viên');

  const ln = N.reports.exportCSV('learner', 'HV-GIOI');
  assert.equal(ln.ok, true);
  assert.ok(ln.content.includes('ten_dang'));

  const sys = N.reports.exportCSV('system');
  assert.equal(sys.ok, true);
  assert.ok(sys.content.includes('nen_lam'));

  assert.equal(N.reports.exportCSV('khong-co').ok, false);
});

test('lớp lạ và học viên lạ báo đúng lỗi', () => {
  assert.equal(N.reports.classReport('KHONG-CO').error, 'CLASS_NOT_FOUND');
  assert.equal(N.reports.learner('KHONG-CO').error, 'LEARNER_NOT_FOUND');
});
