'use strict';
/**
 * Giọng nói giảng viên — kiểm thử theo đúng thứ tự dữ liệu chạy qua hệ thống:
 * chữ → cách đọc → âm vị → sóng → dấu AI → pháp lý → API.
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const { parseSyllable, phonemize, TONES } = require('../src/voice/phonemizer');
const { readNumber, readMath, toSpeech } = require('../src/voice/speech-text');
const { VoiceSynth, toWav, fromWav } = require('../src/voice/synth');
const { VoiceProfileRegistry, profileFor } = require('../src/voice/profiles');
const { ProviderRegistry } = require('../src/voice/providers');
const { VoiceCompliance, extractWatermark, CONSENT_KINDS } = require('../src/voice/compliance');
const { NarrationBuilder } = require('../src/voice/narration');
const { VoiceService } = require('../src/voice/service');
const { buildRoster } = require('../src/agents/roster');

const ITEM = {
  id: 'IT-TEST',
  formCode: 'M9.PT2.GIAI',
  formName: 'Giải phương trình bậc hai',
  stem: 'Giải phương trình $x^{2}-5x+6=0$.',
  solutionSteps: ['Tính $\\Delta = 25 - 24 = 1$.', 'Hai nghiệm là $x_{1}=3$ và $x_{2}=2$.'],
  hints: ['Nhớ $\\Delta = b^{2}-4ac$.'],
  traps: ['Quên xét dấu delta'],
  answer: '$x=2$ hoặc $x=3$',
};

// ── 1. ÂM VỊ HỌC TIẾNG VIỆT ────────────────────────────────────────────────

test('tách âm tiết đúng cấu trúc âm đầu — đệm — chính — cuối — thanh', () => {
  const ng = parseSyllable('nguyễn');
  assert.equal(ng.ok, true);
  assert.equal(ng.initial, 'ng');
  assert.equal(ng.glide, 'u');
  assert.equal(ng.nucleus.text, 'yê');
  assert.equal(ng.nucleus.kind, 'diphthong');
  assert.equal(ng.coda, 'n');
  assert.equal(ng.tone, 'ngã');
  assert.equal(ng.toneId, 4);

  // "gi" là âm đầu, nhưng "gì" nguyên từ thì không được cắt mất nguyên âm
  assert.equal(parseSyllable('giáo').initial, 'gi');
  // "qu" được tách thành âm đầu q + âm đệm u, đúng mô tả ngữ âm học
  assert.equal(parseSyllable('quả').initial, 'q');
  assert.equal(parseSyllable('quả').glide, 'u');
  const toan = parseSyllable('toán');
  assert.equal(toan.glide, 'o');
  assert.equal(toan.nucleus.text, 'a');
  assert.equal(toan.coda, 'n');
  assert.equal(parseSyllable('học').tone, 'nặng');
});

test('sáu thanh điệu có đường nét khác nhau, không thanh nào trùng thanh nào', () => {
  const ids = Object.keys(TONES);
  assert.equal(ids.length, 6);
  const shapes = new Set(ids.map((t) => TONES[t].contour.join(',')));
  assert.equal(shapes.size, 6, 'hai thanh có cùng đường nét cao độ là đọc sai tiếng Việt');
  // huyền phải đi xuống, sắc phải đi lên
  assert.ok(TONES.huyen.contour[3] < TONES.huyen.contour[0]);
  assert.ok(TONES.sac.contour[3] > TONES.sac.contour[0]);
});

test('phiên âm cả câu: đếm đúng âm tiết, không bỏ sót chữ nào', () => {
  const r = phonemize('Chào em, hôm nay mình học phương trình bậc hai.');
  assert.equal(r.syllables, 10);
  assert.equal(r.unknown.length, 0, `không đọc được: ${r.unknown.join(', ')}`);
  assert.ok(r.pauses >= 2, 'dấu phẩy và dấu chấm phải thành chỗ ngắt');
  assert.ok(r.estimatedMs > 1000);
});

// ── 2. ĐỌC SỐ VÀ ĐỌC TOÁN ──────────────────────────────────────────────────

test('đọc số theo đúng lệ tiếng Việt, kể cả các ca bất quy tắc', () => {
  const cases = [
    [0, 'không'], [5, 'năm'], [10, 'mười'], [15, 'mười lăm'], [21, 'hai mươi mốt'],
    [24, 'hai mươi bốn'], [105, 'một trăm lẻ năm'], [1000, 'một nghìn'],
    [1015, 'một nghìn không trăm mười lăm'],
    [1234567, 'một triệu hai trăm ba mươi bốn nghìn năm trăm sáu mươi bảy'],
    [3.14, 'ba phẩy một bốn'], [-7, 'âm bảy'],
  ];
  for (const [n, want] of cases) assert.equal(readNumber(n), want, `đọc sai số ${n}`);
});

test('đọc công thức toán, kể cả phân thức lồng căn', () => {
  assert.equal(readMath('x^{2}-5x+6=0'), 'x bình phương trừ năm x cộng sáu bằng không');
  assert.equal(readMath('x^{3}'), 'x lập phương');
  // đổi chữ cái thành tên đọc là việc của toSpeech, sau khi đã đọc xong công thức
  assert.equal(toSpeech('$x^{2}=4$').text, 'ích bình phương bằng bốn');
  const nghiem = readMath('\\dfrac{-b+\\sqrt{b^{2}-4ac}}{2a}');
  assert.ok(nghiem.includes('trên'), `mất chữ "trên": ${nghiem}`);
  assert.ok(nghiem.includes('căn bậc hai của'), nghiem);
  assert.ok(nghiem.startsWith('âm b'), `dấu trừ đầu tử phải đọc là "âm": ${nghiem}`);
  // dấu trừ giữa hai số hạng thì đọc là "trừ", không phải "âm"
  assert.ok(readMath('a-b').includes('trừ'));
});

test('đọc viết tắt và ký hiệu mà không cắt nhầm chữ tiếng Việt', () => {
  const s = toSpeech('Số tiền 50000 VNĐ, ĐKXĐ là $x>0$, tính ƯCLN(12,18).');
  assert.ok(s.ok);
  assert.ok(!s.text.includes('VNĐ'), s.text);
  assert.ok(s.text.includes('đồng'), s.text);
  assert.ok(s.text.includes('điều kiện xác định'), s.text);
  assert.ok(s.text.includes('ước chung lớn nhất của mười hai và mười tám'), s.text);
  assert.ok(!s.text.includes('mười hai phẩy'), `dấu phẩy trong ngoặc không phải dấu thập phân: ${s.text}`);
  // Δ không được tách thành "đen trừ ta"
  assert.ok(!toSpeech('$\\Delta > 0$').text.includes('trừ ta'));
});

// ── 3. TỔNG HỢP SÓNG ÂM ────────────────────────────────────────────────────

/** Đo cao độ bằng tự tương quan — dùng để kiểm chứng thanh điệu thật sự đúng. */
function measureF0(samples, sr, from, to) {
  const a = Math.floor(from * sr); const b = Math.min(samples.length, Math.floor(to * sr));
  const win = samples.slice(a, b);
  if (win.length < 400) return 0;
  let best = 0; let bestLag = 0;
  for (let lag = Math.floor(sr / 400); lag <= Math.floor(sr / 70); lag++) {
    let sum = 0;
    for (let i = 0; i + lag < win.length; i++) sum += win[i] * win[i + lag];
    if (sum > best) { best = sum; bestLag = lag; }
  }
  return bestLag ? sr / bestLag : 0;
}

test('dựng được sóng thật, đúng định dạng WAV, biên độ không vỡ', () => {
  const s = new VoiceSynth({ f0: 120, seed: 'test' });
  const r = s.render('Xin chào các em học sinh');
  assert.ok(r.ms > 1000, `quá ngắn: ${r.ms}ms`);
  assert.equal(r.unknown.length, 0);
  let peak = 0;
  for (const x of r.samples) peak = Math.max(peak, Math.abs(x));
  assert.ok(peak > 0.5 && peak <= 1.0, `biên độ bất thường: ${peak}`);

  const wav = toWav(r.samples, r.sampleRate);
  assert.equal(wav.toString('ascii', 0, 4), 'RIFF');
  assert.equal(wav.toString('ascii', 8, 12), 'WAVE');
  const back = fromWav(wav);
  assert.equal(back.sampleRate, r.sampleRate);
  assert.equal(back.samples.length, r.samples.length);
});

test('thanh huyền đi xuống, thanh sắc đi lên — đo trên sóng thật', () => {
  const s = new VoiceSynth({ f0: 120, f0Range: 0, jitter: 0, seed: 'tone' });
  const huyen = s.render('à');
  const sac = s.render('á');
  const srH = huyen.sampleRate;
  const dH = huyen.samples.length / srH;
  const dS = sac.samples.length / srH;
  const hStart = measureF0(huyen.samples, srH, dH * 0.15, dH * 0.35);
  const hEnd = measureF0(huyen.samples, srH, dH * 0.65, dH * 0.85);
  const sStart = measureF0(sac.samples, srH, dS * 0.15, dS * 0.35);
  const sEnd = measureF0(sac.samples, srH, dS * 0.65, dS * 0.85);
  assert.ok(hEnd < hStart - 3, `thanh huyền phải hạ giọng: ${hStart} → ${hEnd}`);
  assert.ok(sEnd > sStart + 3, `thanh sắc phải lên giọng: ${sStart} → ${sEnd}`);
});

test('cùng câu, cùng giọng thì sóng giống hệt nhau — tổng hợp tất định', () => {
  const a = new VoiceSynth({ f0: 130, seed: 'x' }).render('kiểm tra tất định');
  const b = new VoiceSynth({ f0: 130, seed: 'x' }).render('kiểm tra tất định');
  assert.equal(a.samples.length, b.samples.length);
  for (let i = 0; i < a.samples.length; i += 97) assert.equal(a.samples[i], b.samples[i]);
});

// ── 4. 500 GIỌNG GIẢNG VIÊN ────────────────────────────────────────────────

test('mỗi agent một giọng riêng, ổn định qua mỗi lần dựng lại', () => {
  const { agents } = buildRoster();
  const reg = new VoiceProfileRegistry({ agents });
  const st = reg.stats();
  assert.equal(st.agentVoices, 500);
  assert.equal(st.total, 503, 'phải có thêm 3 giọng hệ thống');
  assert.ok(st.distinctRatio >= 0.99, `giọng trùng nhau quá nhiều: ${st.distinctRatio}`);
  assert.ok(st.byGender['nam'] > 200 && st.byGender['nữ'] > 200, JSON.stringify(st.byGender));
  // cao độ phải nằm trong quãng người thật
  assert.ok(st.f0Min >= 95 && st.f0Max <= 245, `${st.f0Min}–${st.f0Max} Hz`);

  const again = profileFor(agents[7]);
  assert.deepEqual(again.params, reg.forAgent(agents[7].id).params, 'giọng phải tất định');
});

test('chọn giọng theo ngữ cảnh: tầng thấp được giọng đọc chậm', () => {
  const { agents } = buildRoster();
  const reg = new VoiceProfileRegistry({ agents });
  assert.equal(reg.pick({ level: 0 }).voiceId, 'giang-bai-cham');
  assert.equal(reg.pick({ agentId: agents[0].id }).agentId, agents[0].id);
  assert.equal(reg.pick({}).voiceId, 'he-thong-nu');
});

// ── 5. NHÀ CUNG CẤP ────────────────────────────────────────────────────────

test('bộ tổng hợp nội bộ luôn sẵn sàng; cổng không chính thức mặc định bị tắt', async () => {
  const reg = new ProviderRegistry();
  const st = reg.status();
  assert.equal(st.effective, 'offline');
  const off = st.providers.find((p) => p.id === 'offline');
  assert.equal(off.available, true);
  const un = st.providers.find((p) => p.id === 'google-translate-unofficial');
  assert.equal(un.available, false, 'cổng dịch không chính thức không được bật sẵn');
  assert.equal(un.official, false);
  for (const p of st.providers.filter((x) => x.needsKey)) {
    assert.equal(p.available, false, `${p.id} không có khoá mà báo sẵn sàng`);
    assert.ok(p.fix, 'phải nói rõ thiếu gì');
  }
});

test('hỏng nhà cung cấp ngoài thì lùi về bộ nội bộ, không trả lỗi cho học viên', async () => {
  const reg = new ProviderRegistry();
  const out = await reg.synthesize('một hai ba', profileFor({ id: 'MTH-001', division: 'MATH', rank: 'WORKER' }), { prefer: 'elevenlabs' });
  assert.equal(out.ok, true);
  assert.equal(out.provider, 'offline');
});

// ── 6. PHÁP LÝ ─────────────────────────────────────────────────────────────

test('đồng ý: thiếu văn bản hoặc thiếu người giám hộ thì không cấp', () => {
  const c = new VoiceCompliance({});
  assert.equal(c.consents.grant({ subjectId: 'HV-1', kind: 'VOICE_CLONE', age: 30 }).error, 'THIẾU_VĂN_BẢN');
  assert.equal(c.consents.grant({ subjectId: 'HV-1', kind: 'VOICE_CLONE', age: 15, documentRef: 'HS-1' }).error, 'THIẾU_ĐỒNG_Ý_NGƯỜI_GIÁM_HỘ');
  assert.equal(c.consents.grant({ subjectId: 'HV-1', kind: 'VOICE_LISTEN' }).error, 'CHƯA_XÁC_MINH_TUỔI');
  assert.equal(c.consents.grant({ subjectId: 'HV-1', kind: 'KHÔNG_CÓ', age: 20 }).error, 'LOẠI_ĐỒNG_Ý_KHÔNG_HỢP_LỆ');

  const ok = c.consents.grant({
    subjectId: 'HV-1', kind: 'VOICE_CLONE', age: 15, documentRef: 'HS-1',
    guardian: { name: 'Nguyễn Văn A', relation: 'bố', documentRef: 'GH-1' },
  });
  assert.equal(ok.ok, true);
  assert.equal(ok.consent.minor, true);
  assert.equal(c.consents.check('HV-1', 'VOICE_CLONE').ok, true);

  assert.equal(c.consents.revoke(ok.consent.consentId).ok, true);
  assert.equal(c.consents.check('HV-1', 'VOICE_CLONE').error, 'ĐÃ_RÚT_ĐỒNG_Ý');
});

test('chưa đồng ý thì không phát được giọng cho học viên có định danh', () => {
  const c = new VoiceCompliance({});
  assert.equal(c.authorize({ subjectId: 'HV-X' }).ok, false);
  assert.equal(c.authorize({ subjectId: null }).ok, true, 'đọc không gắn với ai thì không cần đồng ý');
});

test('mọi tệp âm thanh đều mang dấu AI đọc lại được', () => {
  const c = new VoiceCompliance({});
  const r = new VoiceSynth({ f0: 120, seed: 'wm' }).render('đây là giọng máy');
  const st = c.stamp(r.samples, { voiceId: 'gv-mth-001', provider: 'offline', text: 'đây là giọng máy' });
  assert.equal(st.watermarked, true);
  assert.ok(st.copies >= 1, 'dấu phải được lặp lại để cắt đoạn vẫn còn');

  const back = c.verifyAudio(st.wav);
  assert.equal(back.aiGenerated, true);
  assert.equal(back.mark.voiceId, 'gv-mth-001');
  assert.equal(back.mark.provider, 'offline');

  // Tệp không có dấu phải bị báo là không có dấu, không được đoán bừa.
  const plain = toWav(r.samples, r.sampleRate);
  assert.equal(extractWatermark(plain).ok, false);
});

test('dấu chìm không làm hỏng tiếng: sai lệch dưới một phần nghìn', () => {
  const c = new VoiceCompliance({});
  const r = new VoiceSynth({ f0: 120, seed: 'wm2' }).render('kiểm tra chất lượng');
  const st = c.stamp(r.samples, { voiceId: 'v', provider: 'offline', text: 'x', audible: false });
  const back = fromWav(st.wav);
  let maxDiff = 0;
  for (let i = 0; i < r.samples.length; i++) maxDiff = Math.max(maxDiff, Math.abs(back.samples[i] - r.samples[i]));
  assert.ok(maxDiff < 0.001, `dấu chìm làm méo tiếng: ${maxDiff}`);
});

test('nhật ký không sửa được, nhưng vẫn xoá được định danh khi học viên yêu cầu', () => {
  const c = new VoiceCompliance({});
  c.consents.grant({ subjectId: 'HV-9', kind: 'VOICE_LISTEN', age: 20 });
  const r = new VoiceSynth({ f0: 120, seed: 'a' }).render('một hai');
  c.stamp(r.samples, { voiceId: 'v1', provider: 'offline', text: 'một hai', subjectId: 'HV-9' });
  assert.equal(c.audit.verify().ok, true);
  assert.equal(c.audit.ofSubject('HV-9').length, 1);

  const f = c.forget('HV-9');
  assert.equal(f.ok, true);
  assert.equal(f.consentsRemoved, 1);
  assert.equal(f.auditAnonymized, 1);
  assert.ok(f.receipt, 'xoá xong phải có biên bản');
  assert.equal(c.audit.ofSubject('HV-9').length, 0);
  assert.equal(c.audit.verify().ok, true, 'xoá định danh không được làm đứt chuỗi băm');

  // Sửa tay một mắt xích thì phải bị phát hiện.
  c.audit.entries[0].event = 'GIẢ_MẠO';
  assert.equal(c.audit.verify().ok, false);
});

test('bảy yêu cầu của Luật 116/2025/QH15 đều có mã thi hành', () => {
  const c = new VoiceCompliance({});
  const list = c.checklist();
  assert.equal(list.items.length, 7);
  assert.equal(list.ok, true);
  for (const i of list.items) assert.ok(i.impl && i.impl.length > 5, `yêu cầu ${i.no} chưa có phần mã nào lo`);
  assert.equal(Object.keys(CONSENT_KINDS).length, 3);
});

// ── 7. KỊCH BẢN GIẢNG BÀI ──────────────────────────────────────────────────

test('kịch bản giảng bài có đủ các vai và có chỗ nghỉ để học viên nghĩ', () => {
  const nb = new NarrationBuilder({});
  const s = nb.forItem(ITEM, { level: 2 });
  assert.equal(s.ok, true);
  const roles = s.segments.map((x) => x.role);
  for (const r of ['CONG_BO', 'TEN_DANG', 'DE_BAI', 'SUY_NGHI', 'GOI_Y', 'BUOC_GIAI', 'CANH_BAO', 'DAP_AN']) {
    assert.ok(roles.includes(r), `thiếu phân đoạn ${r}`);
  }
  const think = s.segments.find((x) => x.role === 'SUY_NGHI');
  assert.ok(think.pauseAfterMs >= 2000, 'chỗ nghỉ suy nghĩ quá ngắn');
  assert.ok(s.estimatedSeconds > 10);
  // đề phải được đọc thành lời, không còn ký hiệu LaTeX
  const de = s.segments.find((x) => x.role === 'DE_BAI');
  assert.ok(!de.spoken.includes('^'), de.spoken);
  assert.ok(de.spoken.includes('bình phương'), de.spoken);
});

test('tầng thấp đọc chậm hơn và được nghe hết gợi ý', () => {
  const nb = new NarrationBuilder({});
  const thap = nb.forItem(ITEM, { level: 0 });
  const cao = nb.forItem(ITEM, { level: 9 });
  assert.ok(thap.baseRate < cao.baseRate, `${thap.baseRate} phải chậm hơn ${cao.baseRate}`);
  const item2 = { ...ITEM, hints: ['gợi ý một', 'gợi ý hai', 'gợi ý ba'] };
  assert.equal(nb.forItem(item2, { level: 1 }).segments.filter((x) => x.role === 'GOI_Y').length, 3);
  assert.equal(nb.forItem(item2, { level: 8 }).segments.filter((x) => x.role === 'GOI_Y').length, 1);
});

test('chế độ chỉ đọc đề thì không được lỡ miệng nói đáp án', () => {
  const nb = new NarrationBuilder({});
  const s = nb.forItem(ITEM, { mode: 'de' });
  assert.ok(!s.segments.some((x) => x.role === 'DAP_AN'), 'đọc đề mà lộ đáp án là hỏng buổi học');
  assert.ok(!s.segments.some((x) => x.role === 'BUOC_GIAI'));
  const g = nb.forItem(ITEM, { mode: 'goi-y' });
  assert.ok(g.segments.some((x) => x.role === 'GOI_Y'));
  assert.ok(!g.segments.some((x) => x.role === 'DAP_AN'));
});

// ── 8. DỊCH VỤ HỢP NHẤT ────────────────────────────────────────────────────

test('dịch vụ giọng: đọc được, có dấu, có nhật ký, có đệm', async () => {
  const { agents } = buildRoster();
  const v = new VoiceService({ agents });
  const r = await v.speak('Chào em, hôm nay mình học phương trình bậc hai.', { agentId: agents[0].id });
  assert.equal(r.ok, true);
  assert.equal(r.provider, 'offline');
  assert.equal(r.watermarked, true);
  assert.equal(r.voiceId, `gv-${agents[0].id.toLowerCase()}`);
  assert.ok(r.wav.length > 10_000);
  assert.ok(r.auditId, 'mỗi lần tạo giọng phải có một mắt xích nhật ký');
  assert.ok(r.disclosure.aiGenerated);

  const r2 = await v.speak('Chào em, hôm nay mình học phương trình bậc hai.', { agentId: agents[0].id });
  assert.equal(r2.cached, true, 'đọc lại đúng câu đó phải lấy từ bộ đệm');
  assert.equal(v.cache.status().hits, 1);
});

test('dịch vụ giọng chặn đúng các trường hợp hỏng', async () => {
  const { agents } = buildRoster();
  const v = new VoiceService({ agents });
  assert.equal((await v.speak('')).error, 'THIẾU_NỘI_DUNG');
  assert.equal((await v.speak('a'.repeat(9000))).error, 'QUÁ_DÀI');
  const denied = await v.speak('xin chào', { learnerId: 'HV-CHƯA-ĐỒNG-Ý' });
  assert.equal(denied.ok, false);
  assert.equal(denied.error, 'CHƯA_CÓ_ĐỒNG_Ý');
  assert.ok(denied.howToFix);
});

test('soi trước khi đọc: báo đúng số âm tiết và chữ không đọc được', () => {
  const { agents } = buildRoster();
  const v = new VoiceService({ agents });
  const r = v.inspect('Giải phương trình $x^{2}=4$.');
  assert.equal(r.ok, true);
  assert.ok(r.spoken.includes('bình phương'));
  assert.equal(r.unknown.length, 0);
  assert.ok(r.syllables >= 8);
});

test('dựng cả bài giảng thành âm thanh thật, có tổng thời lượng', async () => {
  const { agents } = buildRoster();
  const v = new VoiceService({ agents });
  const s = await v.narrateItem(ITEM, { level: 3, render: true, agentId: agents[0].id });
  assert.equal(s.ok, true);
  assert.ok(s.audio.length >= 5);
  assert.ok(s.renderedMs > 8000, `bài giảng quá ngắn: ${s.renderedMs}ms`);
  for (const a of s.audio) assert.equal(a.wav.toString('ascii', 0, 4), 'RIFF');
});
