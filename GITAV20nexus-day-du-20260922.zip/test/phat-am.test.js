'use strict';
/**
 * Bộ phát âm tiếng Anh: âm vị · hình thái · trọng âm · cặp tối thiểu ·
 * chẩn đoán lỗi người Việt · dựng sóng âm. Và bộ ngữ pháp dùng để KIỂM LẠI
 * học liệu tiếng Anh.
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const EN = require('../src/voice/en-phonemizer');
const ENS = require('../src/voice/en-speech');
const G = require('../src/lang/en-grammar');
const { kiemTiengAnh } = require('../src/lang/en-verifier');
const { dongTuCho, cumDuyNhat } = require('../src/lang/en-collocation');
const MathVerifier = require('../src/math/verifier');

test('mọi dòng phiên âm trong từ điển đều tách được thành âm vị đã khai báo', () => {
  const hong = [];
  for (const [tu, ipa] of Object.entries(EN.TU_DIEN)) {
    const t = EN.tachIPA(ipa);
    if (t.khong.length) hong.push(`${tu} "${ipa}" → ${t.khong.map((x) => x.ky).join('')}`);
    assert.ok(t.am.length > 0, `${tu} phiên âm rỗng`);
  }
  assert.deepEqual(hong, [], 'từ điển còn ký hiệu nằm ngoài bảng âm vị');
  assert.ok(Object.keys(EN.TU_DIEN).length >= 400);
});

test('chia động từ đúng cả luật lẫn bất quy tắc', () => {
  const mong = {
    study: ['studies', 'studied', 'studied', 'studying'],
    stop: ['stops', 'stopped', 'stopped', 'stopping'],
    carry: ['carries', 'carried', 'carried', 'carrying'],
    watch: ['watches', 'watched', 'watched', 'watching'],
    take: ['takes', 'took', 'taken', 'taking'],
    write: ['writes', 'wrote', 'written', 'writing'],
    go: ['goes', 'went', 'gone', 'going'],
    // "visit" có hai âm tiết nên KHÔNG nhân đôi phụ âm cuối.
    visit: ['visits', 'visited', 'visited', 'visiting'],
  };
  for (const [v, [ba, qk, pp, ing]] of Object.entries(mong)) {
    assert.equal(G.ngoiBa(v), ba, `ngôi ba của ${v}`);
    assert.equal(G.quaKhu(v), qk, `quá khứ của ${v}`);
    assert.equal(G.phanTu(v), pp, `phân từ của ${v}`);
    assert.equal(G.dangIng(v), ing, `dạng -ing của ${v}`);
  }
});

test('đếm đúng âm tiết, kể cả âm tiết do phụ âm làm hạt nhân', () => {
  const mong = { sheep: 1, films: 1, world: 1, happy: 2, little: 2, student: 2, seven: 2, beautiful: 3, photograph: 3, education: 4 };
  for (const [tu, so] of Object.entries(mong)) {
    assert.equal(EN.phienAm(tu).soAmTiet, so, `${tu} phải có ${so} âm tiết`);
  }
});

test('đuôi -s đọc theo ÂM đứng trước, không theo chữ cái', () => {
  const lay = (tu) => EN.phienAm(tu).am.at(-1);
  assert.equal(lay('makes'), 's', 'sau /k/ phải là /s/ dù chữ trước là "e"');
  assert.equal(lay('cats'), 's');
  assert.equal(lay('dogs'), 'z');
  assert.equal(lay('trees'), 'z');
  const watches = EN.phienAm('watches').am;
  assert.deepEqual(watches.slice(-2), ['ɪ', 'z'], 'sau âm xuýt phải thêm hẳn một âm tiết /ɪz/');
});

test('trọng âm lấy từ từ điển thì giữ nguyên, không có thì suy bằng luật', () => {
  const a = EN.phienAm('important');
  assert.equal(a.nguon, 'từ điển');
  assert.equal(a.nhan, 1, 'important nhấn âm tiết thứ hai');
  const b = EN.phienAm('education');
  assert.match(b.ipa, /ˈkeɪ/, 'trọng âm chính rơi vào "ca"');
  assert.match(b.ipa, /ˌ/, 'phải giữ cả trọng âm phụ');
  const c = EN.phienAm('thirteenth');
  assert.match(c.nguon, /hậu tố/, 'từ có hậu tố đều thì phải tra gốc trong từ điển');
});

test('mỗi cặp tối thiểu chỉ khác nhau ĐÚNG một âm, và khác cùng loại', () => {
  const kho = EN.khoCapToiThieu();
  assert.ok(kho.length >= 300, `mới có ${kho.length} cặp`);
  for (const c of kho) {
    const A = EN.tachIPA(EN.TU_DIEN[c.a]).am;
    const B = EN.tachIPA(EN.TU_DIEN[c.b]).am;
    assert.equal(A.length, B.length);
    const lech = A.map((x, i) => (x === B[i] ? null : i)).filter((x) => x !== null);
    assert.equal(lech.length, 1, `${c.a}/${c.b} lệch ${lech.length} chỗ`);
    assert.equal(lech[0], c.viTri);
    assert.equal(EN.LA_NGUYEN_AM(A[c.viTri]), EN.LA_NGUYEN_AM(B[c.viTri]));
  }
});

test('bài dạy /iː/ – /ɪ/ dựng được, cặp luyện đúng chiều', () => {
  const b = EN.baiHocAm('iː', 'ɪ');
  assert.equal(b.ok, true);
  assert.ok(b.luyenCap.length >= 6);
  for (const c of b.luyenCap) {
    assert.ok(EN.phienAm(c.tu1).am.includes('iː'), `${c.tu1} phải chứa /iː/`);
    assert.ok(EN.phienAm(c.tu2).am.includes('ɪ'), `${c.tu2} phải chứa /ɪ/`);
  }
  assert.ok(b.cauLuyen.every((c) => c.cau.includes(' ') && c.ipa.startsWith('/')));
  // Câu luyện phải đúng ngữ pháp với mọi cặp từ, nên dùng khung trích dẫn.
  assert.ok(b.cauLuyen.some((c) => /Say "/.test(c.cau)));
});

test('chẩn đoán lỗi người Việt chỉ báo cái có thật trong từ', () => {
  const a = EN.chanDoan('thirteenth');
  assert.ok(a.canhBao.some((c) => c.am === 'θ' && c.loai === 'âm khó'));
  assert.ok(a.canhBao.some((c) => c.loai === 'âm cuối'), 'âm cuối /θ/ phải được cảnh báo');
  assert.ok(a.canhBao.some((c) => c.loai === 'trọng âm'));

  const b = EN.chanDoan('the');
  assert.ok(!b.canhBao.some((c) => c.loai === 'trọng âm'), 'từ một âm tiết không có bài trọng âm');
  assert.ok(!b.canhBao.some((c) => c.loai === 'cụm phụ âm'));
});

test('từ chức năng KHÔNG bị nuốt khi đứng đầu hoặc cuối câu', () => {
  const hoi = EN.phienAmCau('Are you a student?');
  assert.match(hoi.ipa, /^\/ˈɑː/, 'từ đầu câu phải đọc dạng mạnh');
  const dap = EN.phienAmCau('Yes, I am.');
  assert.match(dap.ipa, /ˈæm/, 'từ cuối câu phải đọc dạng mạnh');
  const giua = EN.phienAmCau('I can see a sheep on the ship.');
  assert.match(giua.ipa, /kən/, 'từ chức năng giữa câu thì đọc dạng yếu');
});

test('nối âm chỉ báo khi phụ âm cuối gặp nguyên âm đầu', () => {
  const r = EN.phienAmCau('I can see a sheep on the ship.');
  assert.ok(r.noiAm.some((n) => n.truoc === 'sheep' && n.sau === 'on'));
  assert.ok(!r.noiAm.some((n) => n.truoc === 'the'));
});

test('dựng được sóng âm thật và kết quả TẤT ĐỊNH', () => {
  const a = ENS.doc('I can see a sheep on the ship.');
  assert.equal(a.ok, true);
  assert.ok(a.ms > 800, `đọc quá nhanh: ${a.ms} ms`);
  assert.equal(a.wav.slice(0, 4).toString('latin1'), 'RIFF');
  assert.equal(a.wav.slice(8, 12).toString('latin1'), 'WAVE');
  const b = ENS.doc('I can see a sheep on the ship.');
  assert.ok(a.wav.equals(b.wav), 'hai lần đọc cùng một câu phải cho cùng một tệp');

  const cau = ENS.doc('Are you a student?');
  assert.equal(cau.nguDieu, 'hỏi có không');
  assert.equal(ENS.doc('What is your name?').nguDieu, 'hỏi có từ hỏi');
});

test('đọc cặp tối thiểu có khoảng lặng để tai kịp so sánh', () => {
  const r = ENS.docCapToiThieu('sheep', 'ship');
  assert.equal(r.ok, true);
  assert.equal(r.ipa1, '/ˈʃiːp/');
  assert.equal(r.ipa2, '/ˈʃɪp/');
  assert.ok(r.ms > 3000, 'đọc hai lần, có nghỉ giữa các từ');
});

// ── Bộ giải lại ngữ pháp: chốt kiểm cho học liệu tiếng Anh ──────────────────

test('bộ giải lại đọc được câu nguồn rồi tự biến đổi', () => {
  assert.equal(kiemTiengAnh({ kieu: 'bi dong', nguon: 'He wrote the letter.' }, 'The letter was written by him.').dat, true);
  assert.equal(kiemTiengAnh({ kieu: 'bi dong', nguon: 'He wrote the letter.' }, 'The letter was wrote by him.').dat, false);
  assert.equal(kiemTiengAnh({ kieu: 'thi', nguon: 'She writes the report.', thiDich: 'hien tai hoan thanh' }, 'She has written the report.').dat, true);
  assert.equal(kiemTiengAnh({ kieu: 'thi', nguon: 'She writes the report.', thiDich: 'hien tai hoan thanh' }, 'She have written the report.').dat, false);
  const tt = kiemTiengAnh({ kieu: 'tuong thuat', nguon: 'I clean the room.', nguoiNoi: 'Tom', trangNgu: 'today' }, 'Tom said that he cleaned the room that day.');
  assert.equal(tt.dat, true, tt.chiTiet);
});

test('mệnh đề quan hệ: dấu phẩy bị soát riêng vì nó đổi NGHĨA', () => {
  const chung = { kieu: 'quan he', nguonB: 'He repairs the machine.', danhTu: 'The man', nguoi: true, cauChinh: '§ is my neighbour.' };
  assert.equal(kiemTiengAnh({ ...chung, xacDinh: true }, 'The man who repairs the machine is my neighbour.').dat, true);
  const thieuPhay = kiemTiengAnh({ ...chung, xacDinh: false }, 'The man who repairs the machine is my neighbour.');
  assert.equal(thieuPhay.dat, false);
  assert.match(thieuPhay.chiTiet, /dấu phẩy/);
});

test('kết hợp từ: đề chỉ ra được khi cụm đi với ĐÚNG một động từ', () => {
  for (const { cum, dung } of cumDuyNhat()) {
    assert.deepEqual(dongTuCho(cum), [dung], `"${cum}" phải chỉ đi với "${dung}"`);
  }
  // "a promise" đi được với make / keep / break → không ra đề một đáp án được.
  assert.ok(dongTuCho('a promise').length > 1);
  const hong = kiemTiengAnh({ kieu: 'ket hop tu', cum: 'a promise', dapAnDung: 'make', nhieu: ['keep', 'do'] }, 'make');
  assert.equal(hong.dat, false);
  assert.match(hong.chiTiet, /mập mờ|không ra đề/);
});

test('bộ kiểm chứng nhận cả bài tiếng Anh, và từ chối đáp án sai', () => {
  const V = new MathVerifier();
  const dung = V.verifyItem({ answer: 'The room is cleaned by her.', check: { english: { kieu: 'bi dong', nguon: 'She cleans the room.' } } });
  assert.equal(dung.verified, true, dung.reason);
  const sai = V.verifyItem({ answer: 'The room was cleaned by her.', check: { english: { kieu: 'bi dong', nguon: 'She cleans the room.' } } });
  assert.equal(sai.verified, false);
  assert.equal(sai.verdict, 'SAI');
});

test('mọi bài tiếng Anh trong kho bản thiết kế đều có chốt kiểm và đều qua chốt', () => {
  const { BP_TIENG_ANH } = require('../src/content/blueprints/tieng-anh');
  const V = new MathVerifier();
  let dem = 0;
  for (const bp of BP_TIENG_ANH) {
    let n = 0;
    for (const p of bp.space()) {
      if (++n > 8) break;
      const it = bp.render(p);
      assert.ok(it.check, `${bp.id} thiếu phần máy tự kiểm`);
      const r = V.verifyItem(it);
      assert.equal(r.verified, true, `${bp.id}: ${r.reason}`);
      dem++;
    }
  }
  assert.ok(dem >= 60, `mới kiểm được ${dem} bài`);
});

test('bài nghe rút được phần lời thoại ra để đọc', () => {
  const { VoiceService } = require('../src/voice/service');
  const V = new VoiceService({});
  const r = V.docBaiNghe('Nghe rồi trả lời:\n[NGHE]The meeting starts at nine.[/NGHE]\nCâu hỏi…');
  assert.equal(r.ok, true);
  assert.equal(r.kichBan, 'The meeting starts at nine.');
  assert.equal(r.wav.slice(0, 4).toString('latin1'), 'RIFF');
  assert.equal(V.docBaiNghe('không có phần nghe').ok, false);
});
