'use strict';
/** Hành vi dưới tải: rải việc ra toàn đội, giữ đúng trần, không mất dữ liệu. */
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

let N;

before(async () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'gita-load-'));
  process.env.DB_DIR = path.join(tmp, 'db');
  process.env.SNAPSHOT_DIR = path.join(tmp, 'snap');
  N = await require('../src/index').boot({ quiet: true });
});

after(async () => { await N.shutdown(); });

test('chọn agent rải đều, không dồn hết vào một người', () => {
  // Gọi liên tiếp khi chưa ai chạy: trạng thái đọc ra giống hệt nhau.
  // Nếu chỉ lấy người điểm cao nhất thì 50 lần gọi ra cùng một agent.
  const picked = [];
  for (let i = 0; i < 50; i++) picked.push(N.scheduler.select('vietnamese').id);
  const unique = new Set(picked);
  assert.ok(unique.size >= 8, `50 lần chọn chỉ ra ${unique.size} agent khác nhau — sẽ dồn tải`);
});

test('chọn agent vẫn tất định: cùng thứ tự gọi cho cùng kết quả', async () => {
  const run = async () => {
    const M = await require('../src/index').boot({ quiet: true });
    const out = [];
    for (let i = 0; i < 20; i++) out.push(M.scheduler.select('vietnamese').id);
    await M.shutdown();
    return out;
  };
  assert.deepEqual(await run(), await run(), 'hai lần chạy phải cho cùng chuỗi chọn');
});

test('trăm việc ùa vào cùng lúc: phần lớn chạy được, không từ chối sạch', async () => {
  const burst = 150;
  const results = await Promise.all(Array.from({ length: burst }, (_, i) =>
    N.scheduler.dispatch({ type: 'vietnamese', input: `Việc dồn số ${i} trong đợt kiểm thử tải.`, maxTokens: 100 })
      .catch((e) => ({ ok: false, error: e.message }))));
  const ok = results.filter((r) => r.ok).length;
  const capped = results.filter((r) => !r.ok && ['CAPACITY_LIMIT', 'NO_AGENT_AVAILABLE'].includes(r.error)).length;

  assert.ok(ok > burst * 0.5, `chỉ ${ok}/${burst} việc chạy được — đội 500 agent mà từ chối quá nhiều`);
  assert.equal(ok + capped, burst, 'mọi việc phải có kết cục rõ ràng: chạy hoặc bị từ chối vì quá tải');
});

test('trần công suất toàn hệ không bị vượt dù bị dồn', async () => {
  const limit = N.capacity.status().global.limit;
  await Promise.all(Array.from({ length: limit * 3 }, (_, i) =>
    N.scheduler.dispatch({ type: 'vietnamese', input: `Ép trần công suất, việc số ${i}.`, maxTokens: 100 }).catch(() => null)));
  const peak = N.capacity.status().global.peak;
  assert.ok(peak <= limit, `đỉnh ${peak} vượt trần ${limit} — sẽ vỡ quota khi chạy mô hình thật`);
});

test('sau khi chịu tải: đội hình còn nguyên, nhật ký bất biến không vỡ', async () => {
  await Promise.all(Array.from({ length: 80 }, (_, i) =>
    N.scheduler.dispatch({ type: 'vietnamese', input: `Việc chịu tải số ${i}.`, maxTokens: 80 }).catch(() => null)));
  const fleet = N.shield.fleetReadiness();
  assert.ok(fleet.readiness >= 0.95, `chỉ còn ${Math.round(fleet.readiness * 100)}% đội hình sẵn sàng`);
  assert.equal(N.audit.verify().ok, true, 'nhật ký bất biến bị vỡ sau tải');
  assert.equal(N.agents.length, 500, 'mất agent sau tải');
});

test('nhiều học viên luyện tập cùng lúc không lẫn dữ liệu của nhau', async () => {
  const ids = Array.from({ length: 12 }, (_, i) => `LOAD-HV-${i}`);
  for (const id of ids) {
    N.profiles.register(id, { fullName: `Học viên ${id}`, grade: 9 });
    N.profiles.get(id).currentLevel = 3;
  }
  await Promise.all(ids.map(async (id) => {
    const st = N.practice.start({ learnerId: id, size: 4 });
    if (!st.ok) return;
    let cur = st.item;
    for (let k = 0; k < 4 && cur; k++) {
      const r = N.practice.answer({ sessionId: st.sessionId, itemId: cur.itemId, correct: true, ms: 60_000 });
      if (r.done) break;
      cur = r.next;
    }
  }));
  // Mỗi em phải có đúng dữ liệu của mình, không nhận nhầm của em khác.
  for (const id of ids) {
    const at = N.telemetry.attemptsOf(id);
    assert.ok(at.length >= 1, `${id} không có dữ liệu nào`);
    const other = ids.filter((x) => x !== id);
    for (const o of other) {
      const mine = new Set(at.map((a) => a.itemId));
      const theirs = new Set(N.telemetry.attemptsOf(o).map((a) => a.itemId));
      // Trùng bài thì được (kho chung), nhưng số lượt phải tách bạch.
      assert.ok(mine.size <= 4 && theirs.size <= 4, 'lượt làm bài bị gộp giữa các học viên');
    }
  }
});
