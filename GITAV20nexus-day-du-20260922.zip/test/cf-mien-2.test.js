'use strict';
/** Miền: khảo sát, lộ trình, trại, CRM, kế toán, video. */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const { dungMoi, dongHoGia, yeuCau, doc } = require('../cloudflare/kiem-thu/gia-lap.js');
const { xuLy } = require('../cloudflare/nguon/goc.js');
const { Kho } = require('../cloudflare/nguon/_lib/kho.js');
const phien = require('../cloudflare/nguon/_lib/phien.js');
const { maMoi } = require('../cloudflare/nguon/_lib/ma.js');
const gieoVu = require('../cloudflare/nguon/_lib/gieo.js');
const keToan = require('../cloudflare/nguon/tuyen/ke-toan.js');
const video = require('../cloudflare/nguon/tuyen/chuoi-video.js');
const khaoSat = require('../cloudflare/nguon/tuyen/khao-sat.js');

const goi = (moi, c, d, t, dh) => xuLy(yeuCau(c, d, t), moi, {}, dh);

async function nguoi(moi, dh, vai, email) {
  const kho = Kho(moi.DB);
  const id = maMoi();
  await kho.chen('users', { id, email: email || (vai.toLowerCase() + '@gita.vn'),
    password_hash: await phien.bamMatKhau('Nexus#Thu2026xyz', 2000),
    full_name: 'Người ' + vai, role: vai, status: 'ACTIVE', locale: 'vi',
    created_at: dh(), updated_at: dh() });
  const p = await phien.moPhien(kho, { id, role: vai }, 'thu', dh());
  return { id, the: p.the };
}
const nen = (moi, dh) => gieoVu.gieo(Kho(moi.DB), dh());

// ─── Khảo sát ───────────────────────────────────────────────────────

test('bộ phiếu tâm lý tự khai điều nó KHÔNG hỏi', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  const j = await doc(await goi(moi, 'GET', '/api/khao-sat/bo-phieu/tam-ly-hoc-duong'));
  assert.ok(j.khongLam, 'phải nói rõ bộ này không hỏi gì');
  assert.match(j.khongLam, /tự hại/);
  assert.match(j.canhBao, /không phải chẩn đoán/);
});

test('mọi kết quả khảo sát đều mang câu cảnh báo, và làm quá nhanh thì không tin', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const u = await nguoi(moi, dh, 'LEARNER');
  const de = await doc(await goi(moi, 'GET', '/api/khao-sat/bo-phieu/disc'));
  const traLoi = de.cau.map((c) => ({
    so: c.so, dungNhat: c.luaChon[0].ma, itDungNhat: c.luaChon[3].ma }));

  const nhanh = await doc(await goi(moi, 'POST', '/api/khao-sat/lam/disc',
    { the: u.the, than: { traLoi, giayLam: 5 } }, dh));
  assert.equal(nhanh.dat, true);
  assert.match(nhanh.canhBao, /không phải chẩn đoán/);
  assert.equal(nhanh.coTheTin, false);
  assert.ok(nhanh.viSaoKhongTin.some((x) => /nhanh hơn mức đọc kịp/.test(x)));
});

test('độ tin hạ khi chọn cùng một mức ở gần hết các câu', () => {
  const traLoi = [];
  for (let i = 1; i <= 20; i++) traLoi.push({ so: i, diem: 3 });
  const r = khaoSat.doTinCay(20, 600, traLoi);
  assert.ok(r.diem < 1);
  assert.ok(r.lyDo.some((x) => /cùng một mức/.test(x)));
});

test('test đầu vào cao nhất chỉ mở tới cấp Nâng cao', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const u = await nguoi(moi, dh, 'LEARNER');
  const t = await doc(await goi(moi, 'POST', '/api/khao-sat/test-dau-vao',
    { the: u.the, than: { mon: 'toan', lop: 8 } }, dh));
  const r = await doc(await goi(moi, 'POST', '/api/khao-sat/test-dau-vao/' + t.id + '/nop',
    { the: u.the, than: { diem: 10 } }, dh));
  assert.equal(r.capDoDeXuat, 'nang-cao');
  assert.equal(r.oDeXuat, 'toan-l8-nang-cao');
  assert.match(r.ghiChu, /Điều 7/);
});

// ─── Lộ trình ───────────────────────────────────────────────────────

test('xét vượt cấp khi chưa đủ mẫu thì trả thiếu-mẫu, không trả đạt', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const hv = await nguoi(moi, dh, 'LEARNER', 'hv@gita.vn');

  await goi(moi, 'POST', '/api/lo-trinh/dieu-kien', { the: ad.the, than: {
    oId: 'toan-l6-co-ban' } }, dh);

  const r = await doc(await goi(moi, 'POST',
    '/api/lo-trinh/xet-vuot/' + hv.id + '/toan-l6-co-ban', { the: ad.the }, dh));
  assert.equal(r.ketQua, 'thieu-mau');
  assert.match(r.noiThang, /mới làm ba bài|đủ mẫu/);
  const tl = r.chiTiet.find((x) => x.doBang === 'ti-le-dung');
  assert.equal(tl.duMau, false);
});

test('xét vượt cấp khi chưa đặt điều kiện thì từ chối xét', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const hv = await nguoi(moi, dh, 'LEARNER', 'hv2@gita.vn');
  const r = await goi(moi, 'POST', '/api/lo-trinh/xet-vuot/' + hv.id + '/toan-l3-co-ban',
    { the: ad.the }, dh);
  assert.equal(r.status, 409);
  assert.equal((await doc(r)).ma, 'chua-dat-dieu-kien');
});

test('mở cấp bằng tay bắt buộc nêu lý do và luôn để lại dấu', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const kho = Kho(moi.DB);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const hv = await nguoi(moi, dh, 'LEARNER', 'hv3@gita.vn');

  const cut = await goi(moi, 'POST',
    '/api/lo-trinh/mo-cap-bang-tay/' + hv.id + '/toan-l5-clc',
    { the: ad.the, than: { lyDo: 'ok' } }, dh);
  assert.equal(cut.status, 400);
  assert.match((await doc(cut)).loi, /Điều 7/);

  const ok = await goi(moi, 'POST',
    '/api/lo-trinh/mo-cap-bang-tay/' + hv.id + '/toan-l5-clc',
    { the: ad.the, than: { lyDo: 'Em đã có giải nhì cấp tỉnh năm ngoái, hồ sơ đính kèm.' } }, dh);
  assert.equal(ok.status, 201);
  const n = await kho.dem(
    "SELECT COUNT(*) FROM audit_log WHERE action = 'lo-trinh.mo-cap-bang-tay'");
  assert.equal(n, 1);
});

test('cảnh báo học tập không có bằng chứng thì không ghi được', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const hv = await nguoi(moi, dh, 'LEARNER', 'hv4@gita.vn');
  const r = await goi(moi, 'POST', '/api/lo-trinh/canh-bao/' + hv.id,
    { the: ad.the, than: { loai: 'tut-doc', muc: 'luu-y' } }, dh);
  assert.equal(r.status, 400);
  assert.match((await doc(r)).loi, /tin đồn/);
});

// ─── Trại ───────────────────────────────────────────────────────────

test('trại: không đạt ngưỡng ra thì không có chứng nhận, và nói rõ thiếu gì', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const hv = await nguoi(moi, dh, 'LEARNER', 'hv@gita.vn');
  await goi(moi, 'POST', '/api/khao-sat/ho-so',
    { the: hv.the, than: { hoTen: 'Trần B', lop: 8 } }, dh);

  const k = await doc(await goi(moi, 'POST', '/api/trai/khoa', { the: ad.the, than: {
    trai: 'gel-alpha', ten: 'Khoá 1', khaiMac: dh(), beMac: dh() + 86400000 * 21,
    hinhThuc: 'truc-tuyen', sucChua: 2 } }, dh));
  const gd = await doc(await goi(moi, 'POST', '/api/trai/khoa/' + k.id + '/ghi-danh',
    { the: hv.the }, dh));
  assert.equal(gd.trangThai, 'duoc-vao');

  const xet = await doc(await goi(moi, 'POST',
    '/api/trai/khoa/' + k.id + '/xet-ra/' + hv.id, { the: ad.the }, dh));
  assert.equal(xet.ketQua, 'khong-dat');
  assert.equal(xet.chungNhan, null);
  assert.ok(xet.chiTiet.length >= 3);
  assert.match(xet.noiThang, /Không cấp chứng nhận/);
});

test('trại: sai lớp thì chỉ ở trạng thái chờ xét, không chiếm chỗ', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const be = await nguoi(moi, dh, 'LEARNER', 'be@gita.vn');
  await goi(moi, 'POST', '/api/khao-sat/ho-so',
    { the: be.the, than: { hoTen: 'Bé A', lop: 2 } }, dh);
  const k = await doc(await goi(moi, 'POST', '/api/trai/khoa', { the: ad.the, than: {
    trai: 'leader-boom', khaiMac: dh(), beMac: dh() + 86400000 * 14, sucChua: 5 } }, dh));
  const gd = await doc(await goi(moi, 'POST', '/api/trai/khoa/' + k.id + '/ghi-danh',
    { the: be.the }, dh));
  assert.equal(gd.trangThai, 'cho-xet');
  assert.ok(gd.conThieu.some((x) => /lớp 6–12/.test(x)));
  const kho = Kho(moi.DB);
  const sau = await kho.mot('SELECT da_ghi_danh FROM trai_khoa WHERE id = ?', [k.id]);
  assert.equal(Number(sau.da_ghi_danh), 0);
});

test('trại: hết chỗ thì không nhận thêm', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const k = await doc(await goi(moi, 'POST', '/api/trai/khoa', { the: ad.the, than: {
    trai: 'hoc-gioi', khaiMac: dh(), beMac: dh() + 86400000 * 10, sucChua: 1 } }, dh));
  for (const [e, lop] of [['a@g.vn', 5], ['b@g.vn', 5]]) {
    const u = await nguoi(moi, dh, 'LEARNER', e);
    await goi(moi, 'POST', '/api/khao-sat/ho-so',
      { the: u.the, than: { hoTen: e, lop } }, dh);
    var cuoi = await goi(moi, 'POST', '/api/trai/khoa/' + k.id + '/ghi-danh', { the: u.the }, dh);
  }
  assert.equal(cuoi.status, 409);
  assert.equal((await doc(cuoi)).ma, 'het-cho');
});

// ─── CRM ────────────────────────────────────────────────────────────

test('cây tiền không ra theo bất kỳ đường CRM thường nào', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const kho = Kho(moi.DB);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const g = await doc(await goi(moi, 'POST', '/api/crm/gia-dinh', { the: ad.the, than: {
    tenLienHe: 'Chị Hoa', dienThoai: '0912345678' } }, dh));
  await kho.chay("UPDATE gia_dinh SET cay_tien_nhom = 'nhom-3' WHERE id = ?", [g.id]);

  for (const duong of ['/api/crm/gia-dinh', '/api/crm/gia-dinh/' + g.id, '/api/crm/']) {
    const chu = await (await goi(moi, 'GET', duong, { the: ad.the }, dh)).text();
    assert.equal(chu.includes('nhom-3'), false, 'lộ phân loại ở ' + duong);
    assert.equal(chu.includes('cay_tien_nhom'), false, 'lộ tên cột ở ' + duong);
  }
});

test('đường cây tiền đòi quyền riêng và ghi lại mỗi lượt xem', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const kho = Kho(moi.DB);
  const gv = await nguoi(moi, dh, 'TEACHER', 'gv@gita.vn');
  const ad = await nguoi(moi, dh, 'ADMIN', 'ad@gita.vn');

  assert.equal((await goi(moi, 'GET', '/api/crm/cay-tien', { the: gv.the }, dh)).status, 403);

  const j = await doc(await goi(moi, 'GET', '/api/crm/cay-tien', { the: ad.the }, dh));
  assert.equal(j.dat, true);
  assert.match(j.nhacNho, /Điều 8/);
  assert.equal(await kho.dem(
    "SELECT COUNT(*) FROM audit_log WHERE action = 'crm.xem-cay-tien'"), 1);
});

test('phễu CRM không cho nhảy cóc chặng', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const g = await doc(await goi(moi, 'POST', '/api/crm/gia-dinh', { the: ad.the, than: {
    tenLienHe: 'Anh Nam', email: 'nam@example.vn' } }, dh));
  const coc = await goi(moi, 'POST', '/api/crm/gia-dinh/' + g.id + '/chang',
    { the: ad.the, than: { chang: 'dang-hoc' } }, dh);
  assert.equal(coc.status, 409);
  assert.equal((await doc(coc)).ma, 'nhay-chang');

  const buoc = await goi(moi, 'POST', '/api/crm/gia-dinh/' + g.id + '/chang',
    { the: ad.the, than: { chang: 'da-lien-he' } }, dh);
  assert.equal(buoc.status, 200);
});

test('việc nhắc học phí luôn phải qua người', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const g = await doc(await goi(moi, 'POST', '/api/crm/gia-dinh', { the: ad.the, than: {
    tenLienHe: 'Chị Lan', dienThoai: '0987654321' } }, dh));
  const v = await doc(await goi(moi, 'POST', '/api/crm/viec', { the: ad.the, than: {
    giaDinhId: g.id, loai: 'nhac-hoc-phi', noiDung: 'Nhắc học phí tháng 9' } }, dh));
  assert.equal(v.canNguoi, true);
  const x = await doc(await goi(moi, 'POST', '/api/crm/viec/' + v.id + '/xong',
    { the: ad.the, than: { ketQua: 'đã soạn tin' } }, dh));
  assert.equal(x.trangThai, 'cho-nguoi-duyet');
});

// ─── Kế toán ────────────────────────────────────────────────────────

test('chứng từ lệch Nợ–Có thì không lập được', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  await goi(moi, 'POST', '/api/ke-toan/ky', { the: ad.the, than: { ky: '2026-09' } }, dh);
  const r = await goi(moi, 'POST', '/api/ke-toan/chung-tu', { the: ad.the, than: {
    loai: 'thu', ngayCt: '2026-09-15', dienGiai: 'Thu học phí',
    butToan: [{ tkNo: '111', soTien: 5000000 }, { tkCo: '511', soTien: 4900000 }] } }, dh);
  assert.equal(r.status, 400);
  const j = await doc(r);
  assert.equal(j.ma, 'lech-no-co');
  assert.equal(j.tongNo - j.tongCo, 100000);
});

test('tiền phải là số nguyên đồng', () => {
  assert.equal(keToan.canDoi([{ tkNo: '111', soTien: 1.5 }, { tkCo: '511', soTien: 1.5 }]).ma,
    'so-tien-sai');
  assert.equal(keToan.canDoi([{ tkNo: '111', soTien: 0 }, { tkCo: '511', soTien: 0 }]).ma,
    'so-tien-sai');
});

test('người lập chứng từ không tự ghi sổ chứng từ của mình', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const a = await nguoi(moi, dh, 'ADMIN', 'a@gita.vn');
  const b = await nguoi(moi, dh, 'ADMIN', 'b@gita.vn');
  await goi(moi, 'POST', '/api/ke-toan/ky', { the: a.the, than: { ky: '2026-09' } }, dh);
  const c = await doc(await goi(moi, 'POST', '/api/ke-toan/chung-tu', { the: a.the, than: {
    loai: 'thu', ngayCt: '2026-09-15', dienGiai: 'Thu học phí tháng 9',
    butToan: [{ tkNo: '111', soTien: 5000000 }, { tkCo: '511', soTien: 5000000 }] } }, dh));
  assert.equal(c.dat, true);

  const tu = await goi(moi, 'POST', '/api/ke-toan/chung-tu/' + c.id + '/ghi-so', { the: a.the }, dh);
  assert.equal(tu.status, 403);
  assert.equal((await doc(tu)).ma, 'tu-duyet');

  const ok = await goi(moi, 'POST', '/api/ke-toan/chung-tu/' + c.id + '/ghi-so', { the: b.the }, dh);
  assert.equal(ok.status, 200);
});

test('chứng từ đã ghi sổ chỉ đảo được, và sổ giữ cả hai', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const kho = Kho(moi.DB);
  const a = await nguoi(moi, dh, 'ADMIN', 'a@gita.vn');
  const b = await nguoi(moi, dh, 'ADMIN', 'b@gita.vn');
  await goi(moi, 'POST', '/api/ke-toan/ky', { the: a.the, than: { ky: '2026-09' } }, dh);
  const c = await doc(await goi(moi, 'POST', '/api/ke-toan/chung-tu', { the: a.the, than: {
    loai: 'thu', ngayCt: '2026-09-15', dienGiai: 'Thu nhầm',
    butToan: [{ tkNo: '111', soTien: 2000000 }, { tkCo: '511', soTien: 2000000 }] } }, dh));
  await goi(moi, 'POST', '/api/ke-toan/chung-tu/' + c.id + '/ghi-so', { the: b.the }, dh);

  const cut = await goi(moi, 'POST', '/api/ke-toan/chung-tu/' + c.id + '/dao',
    { the: b.the, than: { lyDo: 'ngan' } }, dh);
  assert.equal(cut.status, 400);

  const d = await doc(await goi(moi, 'POST', '/api/ke-toan/chung-tu/' + c.id + '/dao',
    { the: b.the, than: { lyDo: 'Ghi nhầm sang tài khoản doanh thu, phải đảo lại.' } }, dh));
  assert.equal(d.dat, true);
  assert.equal(await kho.dem('SELECT COUNT(*) FROM chung_tu'), 2, 'sổ phải giữ cả hai');

  const bt = await kho.nhieu(
    'SELECT tk_no, tk_co FROM but_toan WHERE chung_tu_id = ? ORDER BY dong', [d.id]);
  assert.equal(bt[0].tk_co, '111', 'dòng đảo phải đổi chiều');
  assert.equal(bt[0].tk_no, null);

  const lai = await goi(moi, 'POST', '/api/ke-toan/chung-tu/' + c.id + '/dao',
    { the: b.the, than: { lyDo: 'Đảo lần thứ hai cho vui.' } }, dh);
  assert.equal(lai.status, 409);
});

test('bảng cân đối một kỳ phải cân, và kỳ lệch thì không khoá được', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const kho = Kho(moi.DB);
  const a = await nguoi(moi, dh, 'ADMIN', 'a@gita.vn');
  const b = await nguoi(moi, dh, 'ADMIN', 'b@gita.vn');
  await goi(moi, 'POST', '/api/ke-toan/ky', { the: a.the, than: { ky: '2026-09' } }, dh);
  const c = await doc(await goi(moi, 'POST', '/api/ke-toan/chung-tu', { the: a.the, than: {
    loai: 'thu', ngayCt: '2026-09-10', dienGiai: 'Thu học phí',
    butToan: [{ tkNo: '111', soTien: 3000000 }, { tkCo: '511', soTien: 3000000 }] } }, dh));
  await goi(moi, 'POST', '/api/ke-toan/chung-tu/' + c.id + '/ghi-so', { the: b.the }, dh);

  const cd = await doc(await goi(moi, 'GET', '/api/ke-toan/can-doi/2026-09', { the: a.the }, dh));
  assert.equal(cd.canDoi, true);
  assert.equal(cd.tongPhatSinhNo, 3000000);

  // Phá hoại kho: sửa lén một bút toán cho lệch.
  moi.DB._db.exec("UPDATE but_toan SET so_tien = 2999999 WHERE tk_co = '511'");
  const cd2 = await doc(await goi(moi, 'GET', '/api/ke-toan/can-doi/2026-09', { the: a.the }, dh));
  assert.equal(cd2.canDoi, false);
  assert.match(cd2.ghiChu, /LỆCH/);

  const khoa = await goi(moi, 'POST', '/api/ke-toan/ky/2026-09/khoa', { the: a.the }, dh);
  assert.equal(khoa.status, 409);
  assert.equal((await doc(khoa)).ma, 'ky-khong-can-doi');
});

test('không ghi được vào kỳ đã khoá', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const a = await nguoi(moi, dh, 'ADMIN', 'a@gita.vn');
  await goi(moi, 'POST', '/api/ke-toan/ky', { the: a.the, than: { ky: '2026-08' } }, dh);
  const k = await goi(moi, 'POST', '/api/ke-toan/ky/2026-08/khoa', { the: a.the }, dh);
  assert.equal(k.status, 200);
  const r = await goi(moi, 'POST', '/api/ke-toan/chung-tu', { the: a.the, than: {
    loai: 'chi', ngayCt: '2026-08-20', dienGiai: 'Chi muộn',
    butToan: [{ tkNo: '642', soTien: 100000 }, { tkCo: '111', soTien: 100000 }] } }, dh);
  assert.equal(r.status, 409);
  assert.equal((await doc(r)).ma, 'ky-da-khoa');
});

// ─── Video ──────────────────────────────────────────────────────────

test('kịch bản thiếu lời đọc hoặc thiếu phần hiện thì không nhận', () => {
  assert.equal(video.soiKichBan([{ loiDoc: 'xin chào', giay: 10 }]).dat, false);
  assert.equal(video.soiKichBan([{ hienGi: 'đề bài', giay: 10 }]).dat, false);
  assert.equal(video.soiKichBan([{ loiDoc: 'a', hienGi: 'b', giay: 0 }]).dat, false);
  const ok = video.soiKichBan([{ loiDoc: 'a', hienGi: 'b', giay: 30 }]);
  assert.equal(ok.dat, true);
  assert.equal(ok.tongGiay, 30);
});

test('hai tập không cùng một chỗ trong chuỗi', async () => {
  const moi = dungMoi(), dh = dongHoGia();
  await nen(moi, dh);
  const ad = await nguoi(moi, dh, 'ADMIN');
  const c = await doc(await goi(moi, 'POST', '/api/chuoi-video', { the: ad.the, than: {
    ten: 'Giải phương trình bậc hai', mucTieu: 'Giải thành thạo mọi dạng bậc hai.' } }, dh));
  const kb = [{ loiDoc: 'Ta xét phương trình', hienGi: 'ax^2 + bx + c = 0', giay: 20 }];
  const t1 = await goi(moi, 'POST', '/api/chuoi-video/' + c.id + '/tap',
    { the: ad.the, than: { ten: 'Tập 1', kichBan: kb, thuTu: 1 } }, dh);
  assert.equal(t1.status, 201);
  const t2 = await goi(moi, 'POST', '/api/chuoi-video/' + c.id + '/tap',
    { the: ad.the, than: { ten: 'Tập 1 khác', kichBan: kb, thuTu: 1 } }, dh);
  assert.equal(t2.status, 409);
  assert.equal((await doc(t2)).ma, 'trung-thu-tu');
});
