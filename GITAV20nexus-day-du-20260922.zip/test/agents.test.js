'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');

const { DIVISIONS, RANKS, ALLOCATION, SQUAD_SIZE, validateTaxonomy } = require('../src/agents/taxonomy');
const { buildRoster, assignmentTable } = require('../src/agents/roster');
const KPITracker = require('../src/agents/kpi');
const CapacityGovernor = require('../src/agents/capacity');

test('bảng phân công hợp lệ theo cả hai chiều', () => {
  const c = validateTaxonomy();
  assert.equal(c.ok, true, c.errors.join(' | '));
  assert.equal(c.total, 500);
  assert.equal(c.squads, 25);
});

test('tổng theo khối đúng 500 và khớp quy mô từng khối', () => {
  const sum = Object.values(DIVISIONS).reduce((s, d) => s + d.size, 0);
  assert.equal(sum, 500);
  for (const [id, d] of Object.entries(DIVISIONS)) {
    const row = Object.values(ALLOCATION[id]).reduce((a, b) => a + b, 0);
    assert.equal(row, d.size, `khối ${id}`);
  }
});

test('tổng theo cấp bậc đúng chỉ tiêu 10/400/30/20/20/20', () => {
  const expected = { PLANNER: 10, WORKER: 400, CRITIC: 30, COACH: 20, RESEARCHER: 20, GUARDIAN: 20 };
  for (const [rank, n] of Object.entries(expected)) {
    assert.equal(RANKS[rank].total, n, `chỉ tiêu ${rank}`);
    const col = Object.values(ALLOCATION).reduce((s, row) => s + row[rank], 0);
    assert.equal(col, n, `cột ${rank}`);
  }
});

test('roster sinh đúng 500 agent, 25 tổ, mỗi tổ 20 người', () => {
  const { agents, squads } = buildRoster();
  assert.equal(agents.length, 500);
  assert.equal(squads.length, 25);
  for (const s of squads) assert.equal(s.size, SQUAD_SIZE, s.id);
});

test('roster TẤT ĐỊNH — hai lần sinh cho kết quả giống hệt', () => {
  const a = buildRoster().agents.map((x) => `${x.id}|${x.division}|${x.squad}|${x.rank}|${x.tier}`);
  const b = buildRoster().agents.map((x) => `${x.id}|${x.division}|${x.squad}|${x.rank}|${x.tier}`);
  assert.deepEqual(a, b);
});

test('mỗi tổ có đúng một trưởng tổ, không trùng giữa các tổ', () => {
  const { squads } = buildRoster();
  const leads = squads.map((s) => s.lead);
  assert.equal(new Set(leads).size, squads.length);
  for (const s of squads) assert.ok(s.members.includes(s.lead), s.id);
});

test('mọi agent có đủ vai trò, quyền hạn, công suất, ngưỡng KPI', () => {
  const { agents } = buildRoster();
  for (const a of agents) {
    assert.ok(a.id && a.division && a.squad && a.rank, 'định danh');
    assert.ok(a.duty && a.mission && a.systemPrompt, 'chức năng');
    assert.ok(a.permissions.includes('task.execute'), 'quyền cơ bản');
    assert.ok(a.permissions.some((p) => p.endsWith('.*')), 'quyền phạm vi khối');
    assert.ok(a.capacity.maxConcurrent > 0 && a.capacity.tokensPerMin > 0 && a.capacity.tasksPerHour > 0, 'công suất');
    assert.ok(a.kpiTargets.successRate > 0 && a.kpiTargets.p95LatencyMs > 0, 'ngưỡng KPI');
  }
});

test('phân bổ cấp bậc trong mỗi khối khớp ma trận', () => {
  const { agents } = buildRoster();
  for (const [divId, row] of Object.entries(ALLOCATION)) {
    for (const [rank, n] of Object.entries(row)) {
      const actual = agents.filter((a) => a.division === divId && a.rank === rank).length;
      assert.equal(actual, n, `${divId}/${rank}`);
    }
  }
});

test('bảng tổng hợp phân công cộng đúng', () => {
  const { agents } = buildRoster();
  const t = assignmentTable(agents);
  assert.equal(t.total, 500);
  assert.equal(t.byDivision.reduce((s, d) => s + d.total, 0), 500);
  assert.equal(t.byRank.reduce((s, r) => s + r.total, 0), 500);
  assert.equal(t.capacityTotals.concurrent, agents.reduce((s, a) => s + a.capacity.maxConcurrent, 0));
});

test('KPI: chấm điểm và xếp hạng hoạt động', () => {
  const { agents } = buildRoster();
  const kpi = new KPITracker({ agents });
  const id = agents[0].id;
  for (let i = 0; i < 20; i++) {
    kpi.record(id, { ok: true, ms: 800, quality: 0.9, tokensIn: 100, tokensOut: 200, costUsd: 0.0005 });
  }
  const s = kpi.agent(id);
  assert.equal(s.tasks, 20);
  assert.equal(s.successRate, 1);
  assert.ok(s.kpiScore > 0.5, `kpiScore=${s.kpiScore}`);
  assert.ok(s.efficiency > 0);
  assert.equal(kpi.system().agents, 500);
  assert.ok(kpi.groupBy('division').length === 6);
  assert.ok(kpi.groupBy('rank').length === 6);
  assert.ok(kpi.leaderboard(5).length >= 1);
});

test('KPI: agent kém bị đánh dấu dưới ngưỡng', () => {
  const { agents } = buildRoster();
  const kpi = new KPITracker({ agents });
  const id = agents[1].id;
  for (let i = 0; i < 20; i++) kpi.record(id, { ok: false, ms: 20000, quality: 0.2, costUsd: 0.05 });
  assert.equal(kpi.agent(id).belowTarget, true);
  assert.ok(kpi.system().belowTarget >= 1);
});

test('công suất: chặn ở tầng agent và trả chỗ đúng', () => {
  const { agents } = buildRoster();
  const cap = new CapacityGovernor({ agents });
  const worker = agents.find((a) => a.rank === 'WORKER');
  const limit = worker.capacity.maxConcurrent;
  for (let i = 0; i < limit; i++) assert.equal(cap.admit(worker.id, 10).ok, true, `lần ${i}`);
  const denied = cap.admit(worker.id, 10);
  assert.equal(denied.ok, false);
  assert.equal(denied.reason, 'AGENT_CONCURRENCY');
  cap.release(worker.id, 100);
  assert.equal(cap.admit(worker.id, 10).ok, true);
  cap.stop();
});

test('công suất: chặn ở trần toàn hệ', () => {
  const { agents } = buildRoster();
  const cap = new CapacityGovernor({ agents });
  cap.globalLimit = 3;
  const picks = agents.filter((a) => a.rank === 'WORKER').slice(0, 10);
  let admitted = 0;
  for (const a of picks) if (cap.admit(a.id, 10).ok) admitted++;
  assert.equal(admitted, 3);
  cap.stop();
});

test('công suất: chặn theo ngân sách token', () => {
  const { agents } = buildRoster();
  const cap = new CapacityGovernor({ agents });
  const a = agents.find((x) => x.rank === 'WORKER');
  const r1 = cap.admit(a.id, 100);
  assert.equal(r1.ok, true);
  cap.release(a.id, a.capacity.tokensPerMin); // tiêu hết hạn mức phút
  const r2 = cap.admit(a.id, 100);
  assert.equal(r2.ok, false);
  assert.equal(r2.reason, 'AGENT_TOKEN_BUDGET');
  cap.stop();
});
