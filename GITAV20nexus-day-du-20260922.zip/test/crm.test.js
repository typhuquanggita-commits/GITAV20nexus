'use strict';
/**
 * BAN QUẢN TRỊ QUAN HỆ GIA ĐÌNH (CRM)
 *
 * Bộ kiểm này KHÔNG đếm xem có đủ ba mươi trợ lý hay không — đếm thì dễ và
 * không nói lên điều gì. Nó canh đúng những chỗ một hệ CRM chạy bằng trợ lý
 * AI hỏng, và hỏng lặng lẽ:
 *
 *   · công cụ trả dữ liệu bịa thay vì nói "chưa có"
 *   · một trợ lý tự gửi thư cho gia đình mà không ai gật đầu
 *   · hàng chờ duyệt để im lặng trôi thành đồng ý
 *   · bảng điểm chấm cả những chỉ số chưa có chỗ lấy số
 *   · Super Admin nâng quyền cho một trợ lý bằng một lệnh lúc đang gấp
 *   · lời trả lời mang theo cách phân loại nội bộ ra ngoài
 *
 * Mỗi mục dưới đây đều đã được thử ngược: gỡ chỗ nó canh ra thì nó phải đỏ.
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { Database } = require('../src/data/repository');
const SO = require('../src/crm/so-tro-ly');
const DT = require('../src/crm/dinh-tuyen');
const MTC = require('../src/crm/muc-tu-chu');
const KhoCRM = require('../src/crm/kho');
const KhoCongCu = require('../src/crm/kho-cong-cu');
const ChoDuyet = require('../src/crm/cho-duyet');
const TinHieu = require('../src/crm/tin-hieu');
const KpiCRM = require('../src/crm/kpi');
const QuanTriCRM = require('../src/crm/quan-tri');
const DieuPhoiCRM = require('../src/crm/dieu-phoi');
const LichViec = require('../src/crm/lich-viec');
const HopTac = require('../src/crm/hop-tac');
const tuong = require('../src/cay-tien/buc-tuong');

function moKho() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'crm-test-'));
  const db = new Database({ dir });
  return { db, kho: new KhoCRM({ db }), dir };
}

function nexusGia(db) {
  return {
    db, audit: null, llm: null,
    learners: { count: () => 0, get: () => null },
    users: { count: () => 0 },
    agents: [], kpi: null, soCai: null, khaoSat: null, linguist: null,
  };
}

// ── SỔ TRỢ LÝ ─────────────────────────────────────────────────────────────

test('Sổ trợ lý tự soi mình và không có mục nào vượt trần cấp', () => {
  const r = SO.soiSo();
  assert.ok(r.dat, `Sổ trợ lý có lỗi: ${r.loi.join(' · ')}`);
  assert.equal(r.soTroLy, 30);
  assert.deepEqual(r.theoCap, { 1: 5, 2: 8, 3: 12, 4: 5 });
});

test('Không trợ lý nào được cấp mức chạm ra ngoài hệ thống', () => {
  // Đây là luật cứng nhất của cả ban: một trợ lý AI không được tự mình nhắn
  // tin cho mẹ của một đứa trẻ. Luật này nằm trong hàm soi, nhưng kiểm lại ở
  // đây vì nó là thứ dễ bị nới nhất khi có người vội.
  for (const t of SO.DS) {
    assert.ok(
      t.tuChuToiDa < SO.MUC_PHAI_CO_NGUOI,
      `${t.ma} được cấp mức ${t.tuChuToiDa} — mức ${SO.MUC_PHAI_CO_NGUOI} phải qua người thật`,
    );
  }
});

test('Chỉ số KPI nào cũng khai rõ có nguồn đo hay chưa', () => {
  // Bảng điểm hỏng theo một cách rất quen: đặt chỉ tiêu cho thứ chưa đo được,
  // rồi báo cáo màu xanh. Ở đây cờ doDuoc phải khớp với việc có nguồn hay không.
  let chuaCo = 0;
  for (const t of SO.DS) {
    for (const k of t.kpi) {
      assert.equal(k.doDuoc, k.nguon !== null, `${t.ma}/${k.ma}: cờ doDuoc không khớp nguồn`);
      assert.ok(Number.isFinite(k.nguong), `${t.ma}/${k.ma}: thiếu ngưỡng`);
      if (!k.doDuoc) chuaCo++;
    }
  }
  // Có chỉ số chưa nối nguồn là chuyện bình thường và trung thực. Nhưng nếu
  // MỌI chỉ số đều chưa nối nguồn thì bảng điểm chỉ là một tờ giấy.
  const tong = SO.DS.flatMap((t) => t.kpi).length;
  assert.ok(chuaCo < tong * 0.6, `${chuaCo}/${tong} chỉ số chưa nối nguồn — bảng điểm gần như rỗng`);
});

// ── ĐỊNH TUYẾN ────────────────────────────────────────────────────────────

test('Bảng định tuyến không trỏ vào trợ lý không tồn tại', () => {
  const r = DT.soiBang();
  assert.ok(r.dat, `Bảng định tuyến có lỗi: ${r.loi.join(' · ')}`);
  assert.ok(r.soYDinh >= 20, `mới ${r.soYDinh} loại việc — quá hẹp để dùng thật`);
});

test('Đọc không ra ý định thì nói là không ra, KHÔNG đẩy bừa cho trợ lý điều hành', async () => {
  // Bản thiết kế gốc, khi không phân loại được, ném câu hỏi cho trợ lý điều
  // hành tổng với độ tin 0,3. Người dùng nhận lại một câu trả lời trôi chảy
  // từ một trợ lý không được giao việc ấy — tệ hơn im lặng.
  const d = new DT({ llm: null, loi: 'tu-khoa' });
  const r = await d.doc('qwertyuiop zxcvbnm không có nghĩa gì');
  assert.equal(r.doc, false);
  assert.equal(r.yDinh, 'khong-ro');
  assert.ok(!r.troLyChinh, 'không được chọn trợ lý nào khi chưa đọc ra ý định');
  assert.ok(r.lamGiTiepTheo, 'phải nói cho người hỏi biết làm gì tiếp');
});

test('Lối ghép ưu tiên phần tất định, để kết quả lặp lại được', async () => {
  const d = new DT({ llm: null, loi: 'ghep' });
  const a = await d.doc('Kiểm tra công nợ học phí');
  const b = await d.doc('Kiểm tra công nợ học phí');
  assert.equal(a.nguon, 'tu-khoa');
  assert.equal(a.yDinh, b.yDinh);
  assert.equal(a.troLyChinh.ma, b.troLyChinh.ma);
});

// ── MỨC TỰ CHỦ ────────────────────────────────────────────────────────────

test('Việc chạm ra ngoài hệ thống LUÔN cần người, dù điểm rủi ro thấp', () => {
  const m = new MTC();
  const t = SO.INDEX.get('tinh-hieu-qua');   // trợ lý nhẹ nhất, mức 1
  const r = m.can({ troLy: t, yDinh: 'tra_cuu', soTien: 0, mucCongCu: [1, 4] });
  assert.ok(r.diem < 0.35, 'điểm rủi ro phải thấp thì phép thử này mới có nghĩa');
  assert.equal(r.canNguoi, true, 'có công cụ mức 4 mà vẫn cho tự chạy');
});

test('Vừa chạm dữ liệu một em nhỏ vừa ghi thì luôn cần người', () => {
  // Luật này viết ra sau khi thấy một lượt như vậy ra điểm 0,347 — lọt qua
  // ngưỡng 0,35 do phép cộng, không do ai cân nhắc.
  const m = new MTC();
  const t = SO.INDEX.get('ho-so-360');
  const ghi = m.can({ troLy: t, yDinh: 'ghi_nhat_ky', chamHocVien: true, mucCongCu: [1, 3] });
  assert.equal(ghi.canNguoi, true);
  const chiDoc = m.can({ troLy: t, yDinh: 'tra_cuu', chamHocVien: true, mucCongCu: [1, 1] });
  assert.equal(chiDoc.canNguoi, false, 'chỉ đọc kết luận khảo sát là việc thường ngày, không nên chặn');
});

test('Điểm rủi ro vượt ngưỡng chặn thì không cho làm, không đưa ra hàng chờ', () => {
  const m = new MTC();
  const r = m.can({
    troLy: SO.INDEX.get('ban-hoc-phi'), yDinh: 'xoa',
    soTien: 90_000_000, chamHocVien: true, mucCongCu: [1, 2, 3],
  });
  assert.equal(r.choLam, false);
  assert.equal(r.nhan, 'chan');
});

// ── KHO DỮ LIỆU ───────────────────────────────────────────────────────────

test('Đường đồng hành không đi lùi, trừ lối quay lại sau khi đã dừng', () => {
  const { db, kho } = moKho();
  const gd = kho.moGiaDinh({ nguoiDungId: 'U1' }).giaDinh;
  assert.equal(kho.chuyenChang(gd.id, 'dang-hoc').ok, true);
  assert.equal(kho.chuyenChang(gd.id, 'quan-tam').ok, false, 'lùi chặng phải bị chặn');
  assert.equal(kho.chuyenChang(gd.id, 'da-dung').ok, true);
  assert.equal(kho.chuyenChang(gd.id, 'quan-tam').ok, true, 'gia đình quay lại là chuyện có thật');
  db.close();
});

test('Điểm không kèm dấu hiệu thì không nhận', () => {
  // Một con số không giải thích được là một con số không cãi lại được, và
  // thứ không cãi lại được thì không sửa được khi nó sai.
  const { db, kho } = moKho();
  const gd = kho.moGiaDinh({ nguoiDungId: 'U1' }).giaDinh;
  assert.equal(kho.chamDiem({ giaDinhId: gd.id, loai: 'muc-gan-bo', giaTri: 80 }).loi, 'THIEU_DAU_HIEU');
  assert.equal(kho.chamDiem({ giaDinhId: gd.id, loai: 'muc-gan-bo', giaTri: 80, dauHieu: [] }).loi, 'THIEU_DAU_HIEU');
  assert.equal(kho.chamDiem({ giaDinhId: gd.id, loai: 'muc-gan-bo', giaTri: 80, dauHieu: ['đi đủ tám buổi liên tiếp'] }).ok, true);
  db.close();
});

test('Chiến dịch khai chi phí mà không khai nguồn thì bị từ chối', () => {
  // Cùng một luật với sổ cái dòng tiền: một tỷ số tính từ chi phí đoán mò
  // còn hại hơn là không có tỷ số nào.
  const { db, kho } = moKho();
  assert.equal(kho.moChienDich({ ten: 'Thu 2026', kenh: 'gioi-thieu', chiPhiUsd: 500 }).loi, 'CHI_PHI_CHUA_NOI_NGUON');
  const cd = kho.moChienDich({ ten: 'Thu 2026', kenh: 'gioi-thieu', chiPhiUsd: 500, nguonChiPhi: 'hoá đơn quảng cáo tháng 8' });
  assert.equal(cd.ok, true);
  const hq = kho.hieuQuaChienDich(cd.chienDich.id);
  assert.equal(hq.tinhDuoc, false, 'chưa có gia đình nào thì chưa có tử số');
  assert.ok(hq.lyDo.includes('tử số'), 'phải nói rõ thiếu vế nào');
  db.close();
});

test('Mười bước phục hồi là trình tự, không phải thực đơn chọn món', () => {
  const { db, kho } = moKho();
  const { BUOC } = require('../src/trai-nghiem/phuc-hoi');
  const yc = kho.moYeuCau({ noiDung: 'Phụ huynh phản ánh con không theo kịp lớp' }).yeuCau;
  assert.equal(kho.ghiBuocPhucHoi(yc.id, 3).loi, 'NHAY_BUOC');
  for (let i = 1; i <= BUOC.length; i++) {
    const r = kho.ghiBuocPhucHoi(yc.id, i);
    assert.equal(r.ok, true, `bước ${i} phải ghi được`);
  }
  assert.equal(kho.yeuCau.get(yc.id).trangThai, 'xong');
  db.close();
});

test('Kỳ học phí đã thu thì không quay về chưa thu', () => {
  const { db, kho } = moKho();
  const gd = kho.moGiaDinh({ nguoiDungId: 'U1' }).giaDinh;
  const hp = kho.ghiKyHocPhi({ giaDinhId: gd.id, ky: '2026-09', soTien: 2_000_000 }).kyHocPhi;
  assert.equal(kho.capNhatHocPhi(hp.id, 'da-thu').ok, true);
  assert.equal(kho.capNhatHocPhi(hp.id, 'qua-han').loi, 'DA_THU_KHONG_LUI');
  db.close();
});

// ── KHO CÔNG CỤ ───────────────────────────────────────────────────────────

test('Kho rỗng thì công cụ nói "chưa có", KHÔNG đắp số vào cho đỡ trống', async () => {
  // Đây là điểm khác lớn nhất so với bản thiết kế gốc, nơi mỗi công cụ trả về
  // "Công ty ABC, 500 triệu, đang thương lượng". Chạy thì đẹp, nhưng ngày cắm
  // vào việc thật thì có người đọc phải những con số chưa từng tồn tại.
  const { db, kho } = moKho();
  const kc = new KhoCongCu({ N: nexusGia(db), kho });
  for (const ten of ['doc_gia_dinh', 'doc_hoc_phi', 'doc_yeu_cau', 'doc_chien_dich']) {
    const r = await kc.goi(ten, {});
    assert.equal(r.ok, true, `${ten} phải chạy được`);
    assert.equal(r.ketQua.coDuLieu, false, `${ten} trả về dữ liệu khi kho đang rỗng`);
    assert.ok(r.ketQua.loiNhan && /[Cc]hưa có/.test(r.ketQua.loiNhan), `${ten} phải nói rõ là chưa có`);
    const chuoi = JSON.stringify(r.ketQua);
    assert.ok(!/\d{6,}/.test(chuoi), `${ten} trả về một con số lớn trong khi kho rỗng: ${chuoi.slice(0, 200)}`);
  }
  db.close();
});

test('Mọi công cụ đều khai mức động chạm, và chỉ đúng MỘT công cụ chạm ra ngoài', async () => {
  const { db, kho } = moKho();
  const kc = new KhoCongCu({ N: nexusGia(db), kho });
  const ds = kc.danhSach();
  assert.equal(ds.length, 20);
  for (const c of ds) {
    assert.ok([1, 2, 3, 4].includes(c.mucDongCham), `${c.ten}: mức động chạm không hợp lệ`);
    assert.ok(c.moTa && c.moTa.length > 10, `${c.ten}: thiếu mô tả`);
  }
  const raNgoai = ds.filter((c) => c.mucDongCham === 4);
  assert.equal(raNgoai.length, 1, 'càng nhiều cửa ra ngoài thì càng nhiều chỗ để quên khoá');
  assert.equal(raNgoai[0].ten, 'gui_thu');
  db.close();
});

test('Gọi thẳng công cụ gửi thư vẫn KHÔNG gửi được', async () => {
  // Tầng điều phối đã chặn ở trên. Chặn lần thứ hai ngay trong công cụ là cố
  // ý: một ngày nào đó có người gọi thẳng vào đây và quên mất tầng trên.
  const { db, kho } = moKho();
  const kc = new KhoCongCu({ N: nexusGia(db), kho });
  const gd = kho.moGiaDinh({ nguoiDungId: 'U1', tenGoi: 'Nhà An' }).giaDinh;
  const r = await kc.goi('gui_thu', { giaDinhId: gd.id, tieuDe: 'Nhắc học phí', noiDung: 'Kính gửi quý phụ huynh, kỳ học phí tháng này đã tới hạn.' });
  assert.equal(r.ketQua.ok, false);
  assert.equal(r.ketQua.loi, 'PHAI_CO_NGUOI_DUYET');
  db.close();
});

test('Bản thảo mang phân loại nội bộ thì không ra khỏi công cụ', async () => {
  const { db, kho } = moKho();
  const kc = new KhoCongCu({ N: nexusGia(db), kho });
  const gd = kho.moGiaDinh({ nguoiDungId: 'U1', tenGoi: 'Nhà An' }).giaDinh;
  const ban = kc._soatBanThao('Gia đình này thuộc nhóm cây đang lớn nên cần chăm sóc thêm.');
  assert.equal(ban.dat, false, 'bức tường phải bắt được cụm phân loại nội bộ');
  const sach = await kc.goi('soan_thu', { giaDinhId: gd.id, yKien: 'Kỳ học phí tháng này đã tới hạn, mong quý phụ huynh thu xếp giúp.' });
  assert.equal(sach.ketQua.ok, true);
  assert.equal(tuong.soiRoRi(sach.ketQua.banThao).sach, true);
  db.close();
});

// ── HÀNG CHỜ DUYỆT ────────────────────────────────────────────────────────

test('Im lặng không bao giờ được tính là đồng ý', () => {
  const { db } = moKho();
  let gio = 1_000_000;
  const cd = new ChoDuyet({
    repo: db.collection('crm-duyet', { indexes: ['trangThai', 'phienId', 'troLyMa'] }),
    hanMs: 1000, bayGio: () => gio,
  });
  const v = cd.xin({ phienId: 'P1', troLyMa: 'ban-hoc-phi', viec: 'Gửi thư nhắc học phí', deXuat: [{ congCu: 'gui_thu' }] }).viecCho;
  gio += 5000;
  const r = cd.quyet(v.id, { trangThai: 'dong-y', nguoiQuyet: 'Cô Lan' });
  assert.equal(r.ok, false);
  assert.equal(r.loi, 'DA_HET_HAN');
  assert.equal(cd.get(v.id).trangThai, 'het-han', 'quá hạn phải thành het-han, không thành dong-y');
  db.close();
});

test('Xin duyệt mà không kèm việc cụ thể thì bị từ chối', () => {
  const { db } = moKho();
  const cd = new ChoDuyet({ repo: db.collection('crm-duyet', { indexes: ['trangThai'] }) });
  const r = cd.xin({ phienId: 'P1', troLyMa: 'x', viec: 'Làm một việc gì đó', deXuat: [] });
  assert.equal(r.loi, 'THIEU_DE_XUAT');
  db.close();
});

test('Quyết phải ghi tên người, và đã quyết thì không quyết lại', () => {
  const { db } = moKho();
  const cd = new ChoDuyet({ repo: db.collection('crm-duyet', { indexes: ['trangThai'] }) });
  const v = cd.xin({ phienId: 'P1', troLyMa: 'x', viec: 'Gửi thư nhắc', deXuat: [{ congCu: 'gui_thu' }] }).viecCho;
  assert.equal(cd.quyet(v.id, { trangThai: 'dong-y' }).loi, 'THIEU_NGUOI_QUYET');
  assert.equal(cd.quyet(v.id, { trangThai: 'dong-y', nguoiQuyet: 'he' }).ok, true);
  assert.equal(cd.quyet(v.id, { trangThai: 'tu-choi', nguoiQuyet: 'he' }).loi, 'DA_QUYET_ROI');
  db.close();
});

// ── KPI ───────────────────────────────────────────────────────────────────

test('Bảng điểm chỉ chấm trên chỉ số có nguồn, và nói rõ còn bao nhiêu chưa nối', () => {
  const { db, kho } = moKho();
  const kpi = new KpiCRM({ kho, tinHieu: new TinHieu({ repo: db.collection('crm-tin-hieu', { indexes: ['phienId', 'troLyMa'] }) }) });
  const b = kpi.bangDiem();
  assert.ok(b.doPhuChiSo.chuaNoiNguon > 0, 'phải đếm được phần chưa nối nguồn');
  assert.equal(b.doPhuChiSo.tong, b.doPhuChiSo.coNguonDo + b.doPhuChiSo.chuaNoiNguon);
  const r = kpi.cham('dieu-hanh-tong');
  for (const h of r.hang) {
    if (!h.doDuoc) assert.equal(h.diem, null, `${h.ma}: chấm điểm cho chỉ số chưa có nguồn`);
  }
  db.close();
});

test('Chưa đủ lượt thì không chấm, thay vì chấm ra một con số vô nghĩa', () => {
  const { db, kho } = moKho();
  const kpi = new KpiCRM({ kho, tinHieu: new TinHieu({ repo: db.collection('crm-tin-hieu', { indexes: ['phienId', 'troLyMa'] }) }) });
  const r = kpi.cham('phan-tich-chien-dich');
  assert.equal(r.chamDuoc, false);
  assert.ok(/lượt/.test(r.lyDo), 'phải nói rõ vì sao chưa chấm');
  db.close();
});

test('Chỉ số "thấp là tốt" được quy đổi đúng chiều', () => {
  // Trộn hai chiều vào một phép trung bình là lỗi kinh điển của bảng điểm:
  // "số lần vi phạm = 0" mà bị chấm 0 điểm thì cả bảng lộn ngược.
  const kpi = new KpiCRM({});
  const thapTot = { nguong: 5, chieu: 'thap-tot' };
  assert.equal(kpi._quyVe(thapTot, 0), 100, 'không vi phạm lần nào phải được điểm tối đa');
  assert.equal(kpi._quyVe(thapTot, 5), 100, 'đúng ngưỡng thì đạt');
  assert.equal(kpi._quyVe(thapTot, 10), 0, 'gấp đôi ngưỡng thì không đạt');
  const caoTot = { nguong: 80, chieu: 'cao-tot' };
  assert.equal(kpi._quyVe(caoTot, 80), 100);
  assert.equal(kpi._quyVe(caoTot, 40), 50);
});

// ── QUẢN TRỊ SUPER ADMIN ──────────────────────────────────────────────────

test('Super Admin hạ được mức tự chủ, nhưng KHÔNG nâng được', () => {
  // Trần trong sổ là kết quả của một lần cân nhắc có ghi lý do. Một lệnh nâng
  // lúc đang gấp thì không. Vì vậy bàn điều khiển chỉ đi được một chiều.
  const q = new QuanTriCRM({ mucTuChu: new MTC() });
  const t = SO.INDEX.get('ban-cham-soc');
  assert.equal(q.hanMuc(t.ma, 1, { boi: 'SA' }).ok, true);
  assert.equal(q.mucThatCua(t.ma).muc, 1);
  // dieu-hanh-tong có trần 1; xin mức 2 và 3 đều nằm trong khoảng hợp lệ,
  // nên thứ chặn nó phải đúng là luật "chỉ hạ, không nâng".
  assert.equal(q.hanMuc('dieu-hanh-tong', 2, { boi: 'SA' }).loi, 'KHONG_NANG_DUOC');
  assert.equal(q.hanMuc('dieu-hanh-tong', 3, { boi: 'SA' }).loi, 'KHONG_NANG_DUOC');
  assert.equal(q.mucThatCua('dieu-hanh-tong').muc, 1, 'lệnh bị từ chối mà mức vẫn đổi');
});

test('Super Admin không cấp được mức chạm ra ngoài cho bất kỳ ai', () => {
  const q = new QuanTriCRM({ mucTuChu: new MTC() });
  const r = q.hanMuc('cham-diem-quan-tam', SO.MUC_PHAI_CO_NGUOI, { boi: 'SA' });
  assert.equal(r.ok, false);
  assert.equal(r.loi, 'MUC_KHONG_HOP_LE');
});

test('Mọi lệnh quản trị đều đòi tên người ra lệnh', () => {
  const q = new QuanTriCRM({ mucTuChu: new MTC() });
  assert.equal(q.hanMuc('ban-cham-soc', 1, {}).loi, 'THIEU_NGUOI_RA_LENH');
  assert.equal(q.khoa('ban-cham-soc', { lyDo: 'nghi có chuyện' }).loi, 'THIEU_NGUOI_RA_LENH');
  assert.equal(q.dungToanBan({ lyDo: 'nghi có chuyện' }).loi, 'THIEU_NGUOI_RA_LENH');
  assert.equal(q.datNguong({ canNguoi: 0.3 }).loi, 'THIEU_NGUOI_RA_LENH');
});

test('Khoá một trợ lý phải ghi lý do, và khoá thì mức thật về không', () => {
  const q = new QuanTriCRM({ mucTuChu: new MTC() });
  assert.equal(q.khoa('ban-cham-soc', { boi: 'SA' }).loi, 'THIEU_LY_DO');
  assert.equal(q.khoa('ban-cham-soc', { boi: 'SA', lyDo: 'nghi rò rỉ dữ liệu' }).ok, true);
  assert.equal(q.mucThatCua('ban-cham-soc').muc, 0);
  assert.equal(q.moKhoa('ban-cham-soc', { boi: 'SA' }).ok, true);
});

test('Ngưỡng cần người không nới được quá 0,60', () => {
  // Nới cao hơn thì gần như mọi việc tự chạy và hàng chờ duyệt thành hộp rỗng
  // — đúng chỗ mà hệ thống duyệt tự động hay chết mà không ai để ý.
  const m = new MTC();
  const q = new QuanTriCRM({ mucTuChu: m });
  assert.equal(q.datNguong({ canNguoi: 0.9, boi: 'SA' }).loi, 'NGUONG_NGOAI_KHOANG');
  assert.equal(m.nguongCanNguoi, 0.35, 'ngưỡng không được đổi khi lệnh bị từ chối');
  assert.equal(q.datNguong({ canNguoi: 0.2, boi: 'SA' }).ok, true);
  assert.equal(m.nguongCanNguoi, 0.2);
});

test('Dừng toàn ban thì mọi trợ lý về mức không', () => {
  const q = new QuanTriCRM({ mucTuChu: new MTC() });
  assert.equal(q.dungToanBan({ boi: 'SA', lyDo: 'nghi có rò rỉ' }).ok, true);
  for (const t of SO.DS) assert.equal(q.mucThatCua(t.ma).muc, 0, `${t.ma} vẫn chạy khi cả ban đã dừng`);
  assert.equal(q.chayLaiToanBan({ boi: 'SA' }).ok, true);
  assert.ok(q.mucThatCua('dieu-hanh-tong').muc > 0);
});

// ── ĐIỀU PHỐI: CHÍN CỬA ───────────────────────────────────────────────────

test('Lượt CRM đi đủ chín cửa và trả về đủ vết để đọc lại', async () => {
  const { db, kho } = moKho();
  const N = nexusGia(db);
  const crm = new DieuPhoiCRM({ N, loiDinhTuyen: 'tu-khoa' });
  const r = await crm.chay({ cauHoi: 'Kiểm tra công nợ học phí', boi: 'kiem-thu' });
  assert.equal(r.ok, true);
  for (const truong of ['phienId', 'yDinh', 'troLyChinh', 'kieuGhep', 'mucTuChuThat', 'diemRuiRo', 'phanRuiRo', 'canNguoiDuyet', 'tinHieuId']) {
    assert.ok(r[truong] != null, `thiếu trường "${truong}" — không đọc lại được lượt này`);
  }
  db.close();
});

test('Lượt không ghi tên người hỏi thì bị từ chối', () => {
  const { db } = moKho();
  const crm = new DieuPhoiCRM({ N: nexusGia(db), loiDinhTuyen: 'tu-khoa' });
  return crm.chay({ cauHoi: 'Kiểm tra công nợ' }).then((r) => {
    assert.equal(r.ok, false);
    assert.equal(r.loi, 'THIEU_NGUOI_HOI');
    db.close();
  });
});

test('Cả ban đang dừng thì không lượt nào chạy', async () => {
  const { db } = moKho();
  const crm = new DieuPhoiCRM({ N: nexusGia(db), loiDinhTuyen: 'tu-khoa' });
  crm.quanTri.dungToanBan({ boi: 'SA', lyDo: 'kiểm thử công tắc lớn' });
  const r = await crm.chay({ cauHoi: 'Kiểm tra công nợ học phí', boi: 'kiem-thu' });
  assert.equal(r.ok, false);
  assert.equal(r.loi, 'TOAN_BAN_DANG_DUNG');
  db.close();
});

test('Trợ lý bị khoá thì lượt trỏ vào họ dừng lại, không lặng lẽ đổi người', async () => {
  const { db } = moKho();
  const crm = new DieuPhoiCRM({ N: nexusGia(db), loiDinhTuyen: 'tu-khoa' });
  crm.quanTri.khoa('quan-ly-cong-no', { boi: 'SA', lyDo: 'đang rà lại cách tính' });
  const r = await crm.chay({ cauHoi: 'Kiểm tra công nợ học phí', boi: 'kiem-thu' });
  assert.equal(r.ok, false);
  assert.equal(r.loi, 'TRO_LY_DANG_KHOA');
  db.close();
});

test('Việc cần duyệt thì sinh ra một bản ghi CHỜ THẬT, không phải một dòng chữ', async () => {
  // Bản thiết kế gốc để "cần phê duyệt" là một chuỗi trong câu trả lời. Chuỗi
  // ấy không chờ ai, không ai duyệt được, và việc thì trôi qua.
  const { db } = moKho();
  const crm = new DieuPhoiCRM({ N: nexusGia(db), loiDinhTuyen: 'tu-khoa' });
  const r = await crm.chay({ cauHoi: 'Kiểm tra công nợ học phí', boi: 'kiem-thu' });
  assert.equal(r.canNguoiDuyet, true);
  assert.ok(r.viecCho && r.viecCho.id, 'phải có bản ghi chờ duyệt');
  const v = crm.choDuyet.get(r.viecCho.id);
  assert.equal(v.trangThai, 'cho');
  assert.ok(v.deXuat.length > 0, 'người duyệt phải thấy mình đang gật đầu với việc gì');
  const q = crm.quyetViecCho(v.id, { trangThai: 'dong-y', nguoiQuyet: 'Cô Lan' });
  assert.equal(q.ok, true);
  // Vòng học khép lại: quyết xong thì tín hiệu biết.
  assert.equal(crm.tinHieu.bangTong().phanHoiCuaNguoi.dongY, 1);
  db.close();
});

test('Đề xuất gửi lên người duyệt không có hai dòng trùng nhau', async () => {
  const { db } = moKho();
  const crm = new DieuPhoiCRM({ N: nexusGia(db), loiDinhTuyen: 'tu-khoa' });
  const r = await crm.chay({ cauHoi: 'Kiểm tra công nợ học phí', boi: 'kiem-thu' });
  const v = crm.choDuyet.get(r.viecCho.id);
  const ten = v.deXuat.map((d) => d.congCu);
  assert.equal(new Set(ten).size, ten.length, `đề xuất trùng: ${ten.join(', ')}`);
  db.close();
});

test('Câu trả lời mang phân loại nội bộ bị giữ lại trước khi ra khỏi hệ', async () => {
  const { db } = moKho();
  const crm = new DieuPhoiCRM({ N: nexusGia(db), loiDinhTuyen: 'tu-khoa' });
  // Thay tổ trưởng bằng một tổ trưởng trả về đúng thứ bức tường phải chặn.
  crm.toTruong.chayTo = async () => ({
    traLoiCuoi: 'Gia đình này thuộc nhóm cây đang lớn, điểm giá trị cao.',
    cacLuot: [{ troLyMa: 'x', congCuDaGoi: [] }],
    kieuGhep: 'mot-nguoi', chuoiTroLy: ['x'], congCuGoi: [], moHinh: null, ms: 1,
  });
  const r = await crm.chay({ cauHoi: 'Kiểm tra công nợ học phí', boi: 'kiem-thu' });
  assert.equal(r.ok, true);
  assert.equal(tuong.soiRoRi(r.traLoi).sach, true, 'phân loại nội bộ lọt ra ngoài');
  assert.equal(crm.dem.tuongChan, 1);
  db.close();
});

// ── HỢP TÁC VỚI LỰC LƯỢNG 500 ─────────────────────────────────────────────

test('CRM chỉ giao xuống lực lượng những loại việc đã khai', async () => {
  const h = new HopTac({ N: { scheduler: { dispatch: async () => ({ ok: true, output: 'xong', agentId: 'BIZ-1' }) }, agents: [] } });
  const tot = await h.giaoMotViec({ loaiViec: 'business_analysis', noiDung: 'Phân tích công nợ quý này giúp tôi' });
  assert.equal(tot.ok, true);
  const xau = await h.giaoMotViec({ loaiViec: 'code_generation', noiDung: 'Viết một hàm nào đó cho tôi' });
  assert.equal(xau.loi, 'LOAI_VIEC_KHONG_CHO_PHEP');
});

test('Nhà khoa học chỉ mở đúng những việc đã khai cho CRM', async () => {
  const h = new HopTac({ N: { linguist: { soat: () => ({ ok: true, loi: [] }) }, scientist: {} } });
  assert.equal((await h.hoiNhaKhoaHoc({ nganh: 'ngon-ngu', viec: 'soat', thamSo: { chu: 'Xin chào.' } })).ok, true);
  assert.equal((await h.hoiNhaKhoaHoc({ nganh: 'ngon-ngu', viec: 'xoa-het' })).loi, 'VIEC_KHONG_CHO_PHEP');
  assert.equal((await h.hoiNhaKhoaHoc({ nganh: 'hoa-hoc', viec: 'x' })).loi, 'NGANH_LA');
});

// ── LỊCH VIỆC ─────────────────────────────────────────────────────────────

test('Lịch việc không chồng lượt một việc đang chạy', async () => {
  const { db } = moKho();
  const crm = new DieuPhoiCRM({ N: nexusGia(db), loiDinhTuyen: 'tu-khoa' });
  const lv = new LichViec({ crm });
  const v = lv.viec.get('quet-bat-thuong');
  v.dangChay = true;
  assert.equal(v.toiLuotChua(Date.now()), false, 'việc đang chạy mà vẫn tới lượt — sẽ chồng lượt');
  v.dangChay = false;
  assert.equal(v.toiLuotChua(Date.now()), true);
  db.close();
});

test('Việc nền hỏng thì ghi lại, không kéo sập vòng lặp', async () => {
  const { db } = moKho();
  const crm = new DieuPhoiCRM({ N: nexusGia(db), loiDinhTuyen: 'tu-khoa' });
  const lv = new LichViec({ crm });
  lv.viec.get('cham-kpi').chay = async () => { throw new Error('hỏng có chủ ý'); };
  const r = await lv.chayNgay('cham-kpi');
  assert.equal(r.ok, false);
  assert.equal(lv.viec.get('cham-kpi').soLoi, 1);
  assert.equal(lv.viec.get('cham-kpi').loiCuoi, 'hỏng có chủ ý');
  // Vòng lặp vẫn sống: việc khác vẫn chạy được.
  assert.equal((await lv.chayNgay('don-het-han')).ok, true);
  db.close();
});

test('Bản tin sáng đếm lại từ kho, không chép lại bản tin trước', async () => {
  const { db, kho } = moKho();
  const crm = new DieuPhoiCRM({ N: nexusGia(db), loiDinhTuyen: 'tu-khoa' });
  crm.kho = kho;
  const lv = new LichViec({ crm });
  const a = await lv.chayNgay('ban-tin-sang');
  const gd = crm.kho.moGiaDinh({ nguoiDungId: 'U9' }).giaDinh;
  crm.kho.chuyenChang(gd.id, 'dang-hoc');
  const b = await lv.chayNgay('ban-tin-sang');
  const truoc = a.ketQua.baConSo.find((x) => x.ten === 'Gia đình đang học').so;
  const sau = b.ketQua.baConSo.find((x) => x.ten === 'Gia đình đang học').so;
  assert.equal(truoc, 0);
  assert.equal(sau, 1, 'bản tin không đếm lại từ kho');
  db.close();
});

// ── CỔNG API ──────────────────────────────────────────────────────────────

test('Không cổng CRM nào công khai', () => {
  const createRouter = require('../src/api/router');
  const cq = require('../src/api/cong-quyen');
  const { routes } = createRouter({
    crm: null, lichCrm: null, agents: [], squads: [],
    llm: { available: () => ['mock'] }, linguist: {},
  });
  const crm = routes.filter((r) => r.group === 'CRM' || r.group === 'CRMSUPER');
  assert.ok(crm.length >= 25, `mới ${crm.length} cổng CRM`);
  for (const r of crm) {
    assert.equal(cq.mucCua(r), 'quan-tri', `${r.method} ${r.pattern} không ở mức quản trị`);
  }
});

test('Mọi công cụ trong sổ trợ lý đều có thật trong kho công cụ', () => {
  // Một trợ lý cầm công cụ không tồn tại thì lúc chạy mới biết, và lúc ấy là
  // trước mặt người đang chờ câu trả lời.
  const { db, kho } = moKho();
  const kc = new KhoCongCu({ N: nexusGia(db), kho });
  const co = new Set(kc.danhSach().map((c) => c.ten));
  for (const t of SO.DS) {
    for (const c of t.congCu) {
      assert.ok(co.has(c), `${t.ma} cầm công cụ "${c}" không có trong kho`);
    }
  }
  // Và ngược lại: công cụ không ai cầm là công cụ chết.
  const can = new Set(SO.DS.flatMap((t) => t.congCu));
  for (const c of co) assert.ok(can.has(c), `công cụ "${c}" không trợ lý nào cầm — công cụ chết`);
  db.close();
});

test('Bộ đệm chỉ giữ NHÃN ý định, không bao giờ giữ câu trả lời', async () => {
  // Bản thiết kế gốc đệm mọi lượt gọi mô hình. Đặt bộ đệm ở chỗ trả lời thì
  // nguy: lời nhắc gửi cho mô hình có kèm SỐ LIỆU đọc lúc ấy, nên câu trả lời
  // đệm lại là một bức ảnh chụp số liệu cũ — và lần sau nó được đưa ra như số
  // hôm nay. Sai kiểu ấy không ai nhìn ra, vì câu trả lời vẫn trôi chảy.
  const daDem = [];
  const boDemGia = {
    async get() { return null; },
    async set(khoa, giaTri) { daDem.push({ khoa, giaTri }); return true; },
  };
  const llmGia = {
    async call() {
      return { ok: true, provider: 'gia', text: '{"yDinh":"cong-no","doTin":0.9,"viSao":"hỏi về tiền chưa thu"}' };
    },
  };
  const d = new DT({ llm: llmGia, loi: 'mo-hinh', boDem: boDemGia });
  const r = await d.doc('Nhà nào còn thiếu tiền kỳ này');
  assert.equal(r.doc, true);
  assert.equal(r.yDinh, 'cong-no');
  assert.equal(daDem.length, 1, 'phải đệm đúng một lần');
  // Thứ được đệm chỉ gồm nhãn, độ tin, lý do ngắn và tên mô hình — không có
  // một con số nghiệp vụ nào.
  assert.deepEqual(Object.keys(daDem[0].giaTri).sort(), ['doTin', 'moHinh', 'viSao', 'yDinh']);
  assert.ok(!/traLoi|soLieu|congNo|tienChuaThu/i.test(JSON.stringify(daDem[0].giaTri)),
    'bộ đệm đang giữ nội dung trả lời chứ không chỉ giữ nhãn');
});

test('Bộ đệm hỏng thì vẫn định tuyến được, không kéo theo cả lượt', async () => {
  const boDemHong = {
    async get() { throw new Error('bộ đệm chết'); },
    async set() { throw new Error('bộ đệm chết'); },
  };
  const llmGia = {
    async call() { return { ok: true, provider: 'gia', text: '{"yDinh":"cong-no","doTin":0.9}' }; },
  };
  const d = new DT({ llm: llmGia, loi: 'mo-hinh', boDem: boDemHong });
  const r = await d.doc('Nhà nào còn thiếu tiền kỳ này');
  assert.equal(r.doc, true);
  assert.equal(r.yDinh, 'cong-no');
});
