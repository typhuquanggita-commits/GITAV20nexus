'use strict';
/**
 * Hậu kỳ phòng thu, nhạc lý và giọng hát — kiểm bằng phép đo trên sóng thật,
 * không kiểm bằng "hàm có trả về object không".
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const D = require('../src/voice/dsp');
const M = require('../src/voice/music');
const { SingingVoice, alignLyrics, prepare, STYLES } = require('../src/voice/singing');
const { SingingPipeline } = require('../src/voice/pipelines/singing');
const { ConversionPipeline } = require('../src/voice/pipelines/conversion');
const { VietnameseSpeechPipeline, PURPOSE } = require('../src/voice/pipelines/speech');
const { ProviderRegistry } = require('../src/voice/providers');
const NV = require('../src/voice/neural-providers');
const { VoiceCompliance } = require('../src/voice/compliance');
const { VoiceSynth, fromWav } = require('../src/voice/synth');
const { profileFor } = require('../src/voice/profiles');

const SR = 22050;

/** Sóng thử: hình sin có biên độ thay đổi, để đo được cả độ vang lẫn nén. */
function tone(hz, ms, amp = 0.5, sr = SR) {
  const n = Math.round(ms / 1000 * sr);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) out[i] = amp * Math.sin(2 * Math.PI * hz * i / sr);
  return out;
}

const magnitudeAt = (x, hz, sr = SR) => D.magnitudeAt(x, hz, sr);

/** Ước lượng biên độ trung bình bình phương của một dải tần qua bộ lọc băng. */
function bandEnergy(x, hz, sr = SR) {
  const y = new D.Biquad().bandpass(hz, sr, 3).run(x);
  let s = 0;
  for (let i = 0; i < y.length; i++) s += y[i] * y[i];
  return Math.sqrt(s / y.length);
}

// ── 1. BIQUAD ──────────────────────────────────────────────────────────────

test('bộ lọc thông cao chặn đúng tần số thấp và giữ tần số cao', () => {
  const low = tone(60, 400);
  const high = tone(2000, 400);
  const f = () => new D.Biquad().highpass(300, SR, 0.707);
  const lowOut = D.peakOf(f().run(low));
  const highOut = D.peakOf(f().run(high));
  assert.ok(lowOut < 0.12, `60 Hz phải bị chặn, còn ${lowOut.toFixed(3)}`);
  assert.ok(highOut > 0.45, `2 kHz phải đi qua, còn ${highOut.toFixed(3)}`);
});

test('EQ chuông nâng đúng dải được chỉ định, không đụng dải khác', () => {
  const mix = new Float32Array(SR * 0.4);
  const a = tone(500, 400, 0.3); const b = tone(3000, 400, 0.3);
  for (let i = 0; i < mix.length; i++) mix[i] = a[i] + b[i];
  const out = new D.Biquad().peaking(3000, SR, 6, 1).run(mix);
  const before3k = bandEnergy(mix, 3000);
  const after3k = bandEnergy(out, 3000);
  const before500 = bandEnergy(mix, 500);
  const after500 = bandEnergy(out, 500);
  assert.ok(after3k / before3k > 1.5, `dải 3 kHz phải được nâng, tỉ lệ ${(after3k / before3k).toFixed(2)}`);
  assert.ok(Math.abs(after500 / before500 - 1) < 0.25, `dải 500 Hz không được đụng tới, tỉ lệ ${(after500 / before500).toFixed(2)}`);
});

test('tần số cắt vượt Nyquist không làm hỏng bộ lọc', () => {
  // Đặt EQ 18 kHz trên tín hiệu 22,05 kHz — phải tự kẹp lại, không ra NaN.
  const out = new D.Biquad().peaking(18000, SR, 6, 0.7).run(tone(1000, 200));
  for (let i = 0; i < out.length; i++) assert.ok(Number.isFinite(out[i]), `NaN tại mẫu ${i}`);
});

// ── 2. NÉN, DE-ESSER, BÃO HOÀ, GIỚI HẠN ────────────────────────────────────

test('bộ nén kéo tín hiệu to xuống và ghi nhận đúng độ giảm', () => {
  const loud = tone(440, 600, 0.9);
  const r = D.compress(loud, SR, { thresholdDb: -20, ratio: 6, attackMs: 2, releaseMs: 50 });
  assert.ok(r.maxReductionDb < -5, `phải nén ít nhất 5 dB, mới ${r.maxReductionDb}`);
  assert.ok(D.peakOf(r.samples) < D.peakOf(loud), 'đỉnh sau nén phải thấp hơn');
});

test('nén song song giữ lại biên độ động, không san phẳng như nén thẳng', () => {
  const x = new Float32Array(SR);
  const soft = tone(440, 500, 0.12); const loud = tone(440, 500, 0.9);
  x.set(soft, 0); x.set(loud, soft.length);
  const straight = D.compress(x, SR, { thresholdDb: -24, ratio: 8 }).samples;
  const parallel = D.parallelCompress(x, SR, { mix: 0.45, thresholdDb: -24, ratio: 8 }).samples;
  const ratioOf = (y) => D.peakOf(y.slice(soft.length)) / Math.max(1e-6, D.peakOf(y.slice(0, soft.length)));
  assert.ok(ratioOf(parallel) > ratioOf(straight),
    `nén song song phải giữ chênh lệch to–nhỏ nhiều hơn (${ratioOf(parallel).toFixed(2)} so với ${ratioOf(straight).toFixed(2)})`);
});

test('de-esser chỉ hạ dải xì, giữ nguyên phần thân giọng', () => {
  const mix = new Float32Array(Math.round(SR * 0.5));
  const body = tone(700, 500, 0.35); const sss = tone(6500, 500, 0.5);
  for (let i = 0; i < mix.length; i++) mix[i] = body[i] + sss[i];
  const r = D.deEss(mix, SR, { thresholdDb: -30, ratio: 5, freq: 6500 });
  const hissBefore = bandEnergy(mix, 6500); const hissAfter = bandEnergy(r.samples, 6500);
  const bodyBefore = bandEnergy(mix, 700); const bodyAfter = bandEnergy(r.samples, 700);
  assert.ok(hissAfter < hissBefore * 0.8, `dải xì phải giảm (${hissBefore.toFixed(3)} → ${hissAfter.toFixed(3)})`);
  assert.ok(bodyAfter > bodyBefore * 0.9, `thân giọng phải giữ nguyên (${bodyBefore.toFixed(3)} → ${bodyAfter.toFixed(3)})`);
  assert.ok(r.actedRatio > 0, 'phải có can thiệp');
});

test('bão hoà hài thật sự sinh ra hài bậc cao', () => {
  const x = tone(500, 400, 0.6);
  const y = D.saturate(x, { drive: 0.6, even: 0.6 });
  const h2Before = magnitudeAt(x, 1000); const h2After = magnitudeAt(y, 1000);
  const h3Before = magnitudeAt(x, 1500); const h3After = magnitudeAt(y, 1500);
  assert.ok(h2After > h2Before + 0.01 && h2After > h2Before * 3,
    `phải sinh hài bậc 2 (${h2Before.toFixed(5)} → ${h2After.toFixed(5)})`);
  assert.ok(h3After > h3Before + 0.005 && h3After > h3Before * 3,
    `phải sinh hài bậc 3 (${h3Before.toFixed(5)} → ${h3After.toFixed(5)})`);
  // Tần số cơ bản vẫn phải là thành phần mạnh nhất — bão hoà là thêm, không phải thay.
  assert.ok(magnitudeAt(y, 500) > h2After, 'tần số cơ bản phải còn lớn hơn hài bậc 2');
});

test('giới hạn đỉnh giữ đúng trần và không cắt ngọn sóng', () => {
  const x = tone(300, 400, 0.98);
  const r = D.limit(x, SR, { ceilingDb: -3, lookaheadMs: 5 });
  const ceiling = D.dbToLin(-3);
  assert.ok(D.peakOf(r.samples) <= ceiling + 1e-4, `vượt trần: ${D.linToDb(D.peakOf(r.samples)).toFixed(2)} dB`);
  assert.ok(r.limitedSamples > 0, 'phải có lúc can thiệp');
  // Không được cắt phẳng: đếm số mẫu nằm sát trần phải nhỏ
  let flat = 0;
  for (const v of r.samples) if (Math.abs(Math.abs(v) - ceiling) < 1e-5) flat++;
  assert.ok(flat < r.samples.length * 0.05, `cắt phẳng ${flat} mẫu — đó là hard clip, không phải limiter`);
});

// ── 3. ĐO ĐỘ VANG THEO BS.1770 ─────────────────────────────────────────────

test('đo độ vang: tín hiệu to hơn cho chỉ số cao hơn, đúng bậc thang dB', () => {
  const a = D.measureLoudness(tone(1000, 2000, 0.2), SR);
  const b = D.measureLoudness(tone(1000, 2000, 0.4), SR);
  assert.ok(b.lufs > a.lufs, 'to gấp đôi phải cho LUFS cao hơn');
  // Gấp đôi biên độ ≈ +6 dB
  assert.ok(Math.abs((b.lufs - a.lufs) - 6) < 0.6, `chênh lệch phải xấp xỉ 6 dB, đo được ${(b.lufs - a.lufs).toFixed(2)}`);
  assert.ok(a.gated > 0, 'phải có khối vượt cổng');
});

test('chuẩn độ vang kéo mọi nguồn về đúng mục tiêu', () => {
  for (const amp of [0.05, 0.3, 0.9]) {
    const x = tone(440, 3000, amp);
    const r = D.normalizeLoudness(x, SR, { targetLufs: -16 });
    const after = D.measureLoudness(r.samples, SR);
    assert.ok(Math.abs(after.lufs - (-16)) < 0.6,
      `biên độ ${amp}: sau chuẩn hoá phải là −16 LUFS, đo được ${after.lufs}`);
  }
});

// ── 4. CHUỖI HẬU KỲ ────────────────────────────────────────────────────────

test('chuỗi hậu kỳ đưa lời giảng về đúng độ vang và trần đỉnh', () => {
  const speech = new VoiceSynth({ f0: 118, seed: 'dsp' }).render('Chào các em, hôm nay mình học phương trình bậc hai');
  for (const preset of ['giang-bai', 'phat-thanh', 'hat-pop', 'hat-ballad', 'moc']) {
    const r = D.StudioChain.process(speech.samples, speech.sampleRate, { preset });
    assert.equal(r.ok, true);
    assert.ok(r.steps.length >= 2, `${preset}: quá ít khâu`);
    const target = D.PRESETS[preset].targetLufs;
    assert.ok(Math.abs(r.after.lufs - target) < 1.2,
      `${preset}: mục tiêu ${target} LUFS, đo được ${r.after.lufs}`);
    assert.ok(r.after.peakDb <= D.PRESETS[preset].ceilingDb + 0.2,
      `${preset}: đỉnh ${r.after.peakDb} vượt trần ${D.PRESETS[preset].ceilingDb}`);
    for (const v of r.samples) assert.ok(Number.isFinite(v), `${preset}: có mẫu NaN`);
  }
});

test('có đủ cài đặt hậu kỳ cho cả nói lẫn hát', () => {
  const list = D.StudioChain.presets();
  assert.ok(list.length >= 5);
  for (const p of list) { assert.ok(p.name); assert.ok(p.note); assert.ok(p.targetLufs < 0); }
});

// ── 5. NHẠC LÝ ─────────────────────────────────────────────────────────────

test('đọc tên nốt cả tiếng Việt lẫn tiếng Anh, kể cả dấu hoá', () => {
  const cases = [['C4', 60], ['đô4', 60], ['rê4', 62], ['mi4', 64], ['fa4', 65], ['sol4', 67],
    ['la4', 69], ['si4', 71], ['F#3', 54], ['Eb3', 51], ['sib3', 58], ['đô#5', 73], ['A4', 69]];
  for (const [t, want] of cases) assert.equal(M.noteToMidi(t), want, `sai ở ${t}`);
  assert.equal(M.noteToMidi('xyz'), null);
  assert.equal(Math.round(M.midiToFreq(69)), 440);
  assert.equal(M.midiName(60), 'C4');
});

test('ký âm chữ ra đúng số nốt và đúng trường độ theo nhịp độ', () => {
  const m = M.parseMelody('đô4:1 rê4:1 mi4:2 -:1 sol4:2', { bpm: 120 });
  assert.equal(m.ok, true);
  assert.equal(m.notes.length, 5);
  assert.equal(m.notes.filter((n) => n.rest).length, 1);
  assert.equal(m.notes[0].ms, 500, '120 bpm thì một phách là 500ms');
  assert.equal(m.notes[2].ms, 1000);
  assert.equal(m.totalMs, 3500);
  const bad = M.parseMelody('đô4:1 xxx9:1', { bpm: 100 });
  assert.equal(bad.ok, false);
  assert.ok(bad.errors.length >= 1);
});

test('ghi và đọc lại tệp MIDI cho đúng từng nốt', () => {
  const m = M.parseMelody('đô4:1 rê4:1 mi4:1 fa4:1 sol4:2', { bpm: 100 });
  const buf = M.writeMidi(m.notes, { bpm: 100 });
  assert.equal(buf.toString('ascii', 0, 4), 'MThd');
  const back = M.parseMidi(buf);
  assert.equal(back.ok, true);
  assert.equal(back.bpm, 100);
  const pitched = m.notes.filter((n) => !n.rest);
  assert.equal(back.notes.length, pitched.length);
  back.notes.forEach((n, i) => {
    assert.equal(n.midi, pitched[i].midi, `nốt ${i} sai cao độ`);
    assert.ok(Math.abs(n.ms - pitched[i].ms) <= 2, `nốt ${i} sai trường độ: ${n.ms} vs ${pitched[i].ms}`);
  });
  assert.equal(M.parseMidi(Buffer.from('không phải midi')).ok, false);
});

test('tách bè chính: nhiều nốt cùng lúc thì lấy nốt cao nhất', () => {
  const chord = [
    { at: 0, ms: 500, midi: 60, rest: false }, { at: 0, ms: 500, midi: 64, rest: false }, { at: 0, ms: 500, midi: 67, rest: false },
    { at: 500, ms: 500, midi: 62, rest: false }, { at: 500, ms: 500, midi: 71, rest: false },
  ];
  const lead = M.extractLeadLine(chord);
  assert.equal(lead.length, 2);
  assert.equal(lead[0].midi, 67);
  assert.equal(lead[1].midi, 71);
});

test('dịch giọng cho vừa quãng người hát, và báo khi bài quá rộng', () => {
  const low = M.parseMelody('đô2:1 rê2:1 mi2:1', { bpm: 100 });
  const fit = M.fitToRange(low.notes, 'soprano');
  assert.equal(fit.ok, true);
  assert.ok(fit.shift > 0 && fit.shift % 12 === 0, `phải dịch theo quãng tám, đang là ${fit.shift}`);
  assert.equal(fit.outOfRange, 0);

  const wide = M.parseMelody('đô2:1 đô7:1', { bpm: 100 });
  const bad = M.fitToRange(wide.notes, 'alto');
  assert.equal(bad.ok, false);
  assert.equal(bad.error, 'BÀI_RỘNG_HƠN_QUÃNG_GIỌNG');
  assert.ok(bad.detail.includes('nửa cung'));
});

// ── 6. HÁT ─────────────────────────────────────────────────────────────────

test('ghép lời vào nốt: đếm đúng, phát hiện thừa thiếu, hiểu dấu luyến', () => {
  const notes = M.parseMelody('đô4:1 rê4:1 mi4:1 fa4:1', { bpm: 100 }).notes;
  const ok = alignLyrics('một hai ba bốn', notes);
  assert.equal(ok.ok, true);
  assert.equal(ok.syllables, 4);
  assert.equal(ok.melisma, 0);

  const mel = alignLyrics('một hai - bốn', notes);
  assert.equal(mel.melisma, 1);
  assert.equal(mel.plan[2].syllable, 'hai', 'dấu luyến phải ngân tiếp âm tiết trước');

  const thieu = alignLyrics('một hai', notes);
  assert.equal(thieu.ok, false);
  assert.ok(thieu.warning.includes('Thiếu lời'));

  const thua = alignLyrics('một hai ba bốn năm sáu', notes);
  assert.equal(thua.ok, false);
  assert.ok(thua.warning.includes('Thừa'));
});

test('hát đúng cao độ của từng nốt — đo trên sóng thật', () => {
  const notes = M.parseMelody('sol4:2 la4:2 si4:2 đô5:2', { bpm: 70 }).notes;
  const sv = new SingingVoice({ f0: 200, rate: 1, timbre: 1.1, breathiness: 0.06, jitter: 0.006, gain: 0.62, seed: 'sing' }, { style: 'pop' });
  const r = sv.sing('la la la la', notes);
  assert.equal(r.ok, true);
  assert.equal(r.notesSung, 4);

  const sr = r.sampleRate;
  const f0 = (win) => {
    let best = 0; let lag = 0;
    for (let L = Math.floor(sr / 800); L <= Math.floor(sr / 150); L++) {
      let s = 0;
      for (let i = 0; i + L < win.length; i++) s += win[i] * win[i + L];
      if (s > best) { best = s; lag = L; }
    }
    return lag ? sr / lag : 0;
  };
  let at = 0;
  for (const s of r.sung) {
    const a = Math.round((at + s.ms * 0.5) / 1000 * sr);
    const b = Math.round((at + s.ms * 0.8) / 1000 * sr);
    const measured = f0(r.samples.slice(a, b));
    const cents = Math.abs(1200 * Math.log2(measured / s.hz));
    assert.ok(cents < 60, `nốt ${s.note}: mong ${s.hz} Hz, đo ${measured.toFixed(1)} Hz — lệch ${cents.toFixed(0)} cent`);
    at += s.ms;
  }
});

test('âm tiết được kéo dài cho vừa nốt, và nốt càng dài thì tiếng càng dài', () => {
  const short = M.parseMelody('đô4:1', { bpm: 120 }).notes;      // 500ms
  const long = M.parseMelody('đô4:4', { bpm: 120 }).notes;       // 2000ms
  const sv = new SingingVoice({ f0: 200, seed: 'x' }, { style: 'pop' });
  const a = sv.sing('la', short);
  const b = sv.sing('la', long);
  assert.ok(Math.abs(a.ms - 500) < 90, `nốt ngắn phải ~500ms, được ${a.ms}`);
  assert.ok(Math.abs(b.ms - 2000) < 120, `nốt dài phải ~2000ms, được ${b.ms}`);
});

test('năm cách hát khác nhau thật sự cho ra sóng khác nhau', () => {
  const notes = M.parseMelody('sol4:2 la4:2', { bpm: 80 }).notes;
  const seen = new Set();
  for (const style of Object.keys(STYLES)) {
    const r = new SingingVoice({ f0: 200, seed: 'k' }, { style }).sing('quê hương', notes);
    assert.equal(r.ok, true);
    assert.equal(r.style, style);
    let acc = 0;
    for (let i = 0; i < r.samples.length; i += 53) acc += Math.abs(r.samples[i]);
    seen.add(acc.toFixed(3));
  }
  assert.equal(seen.size, Object.keys(STYLES).length, 'có hai thể loại cho ra sóng y hệt nhau');
});

test('rung giọng chỉ xuất hiện ở nốt đủ dài', () => {
  const sv = new SingingVoice({ f0: 200, seed: 'v' }, { style: 'ballad' });
  const curveLong = sv._pitchCurve(440, null, 'ngang', 1500);
  const curveShort = sv._pitchCurve(440, null, 'ngang', 200);
  const spread = (curve, ms) => {
    let lo = Infinity; let hi = -Infinity;
    for (let t = 0.5; t < 1; t += 0.01) { const v = curve(t, t * ms); lo = Math.min(lo, v); hi = Math.max(hi, v); }
    return hi - lo;
  };
  assert.ok(spread(curveLong, 1500) > 3, 'nốt dài phải có rung giọng');
  assert.ok(spread(curveShort, 200) < 0.5, 'nốt ngắn không được rung');
});

test('chuẩn bị bài hát: nhận cả ký âm chữ lẫn tệp MIDI, báo lỗi rõ ràng', () => {
  const a = prepare({ lyrics: 'một hai ba', melody: 'đô4:1 rê4:1 mi4:1', bpm: 100 });
  assert.equal(a.ok, true);
  assert.equal(a.source.kind, 'ký âm chữ');

  const midi = M.writeMidi(M.parseMelody('đô4:1 rê4:1 mi4:1', { bpm: 100 }).notes, { bpm: 100 });
  const b = prepare({ lyrics: 'một hai ba', midi });
  assert.equal(b.ok, true);
  assert.equal(b.source.kind, 'midi');
  assert.equal(b.align.ok, true);

  assert.equal(prepare({ lyrics: 'x' }).error, 'THIẾU_GIAI_ĐIỆU');
  assert.equal(prepare({ lyrics: 'x', melody: 'zzz:1' }).error, 'KÝ_ÂM_SAI');
});

// ── 7. TUYẾN CHUYÊN BIỆT ───────────────────────────────────────────────────

test('tuyến nói chọn bộ tổng hợp theo mục đích, luôn có đường lùi', () => {
  const pipe = new VietnameseSpeechPipeline({ providers: new ProviderRegistry() });
  for (const id of Object.keys(PURPOSE)) {
    const pl = pipe.plan(id);
    assert.equal(pl.chosen, 'offline', `${id}: chưa cài mô hình nơ-ron thì phải lùi về bộ nội bộ`);
    assert.ok(pl.chain.length >= 2);
    for (const s of pl.skipped) assert.ok(s.reason && s.fix, `${s.id} phải nói rõ thiếu gì và sửa thế nào`);
  }
  assert.equal(pipe.plan('truc-tiep').studio, false, 'phát trực tiếp không chạy được hậu kỳ cả câu');
  assert.equal(pipe.plan('bai-dai').studio, true);
});

test('tuyến nói dựng tiếng và chạy hậu kỳ đúng cài đặt của mục đích', async () => {
  const pipe = new VietnameseSpeechPipeline({ providers: new ProviderRegistry() });
  const profile = profileFor({ id: 'MTH-001', division: 'MATH', rank: 'PLANNER' });
  const r = await pipe.synthesize('Giải phương trình $x^{2}=4$.', profile, { purpose: 'giang-bai' });
  assert.equal(r.ok, true);
  assert.equal(r.provider, 'offline');
  assert.ok(r.spoken.includes('bình phương'));
  assert.equal(r.studio.preset, 'giang-bai');
  assert.ok(Math.abs(r.studio.after.lufs - (-16)) < 1.2, `độ vang sau hậu kỳ: ${r.studio.after.lufs}`);

  const live = await pipe.synthesize('xin chào', profile, { purpose: 'truc-tiep' });
  assert.equal(live.studio, null, 'phát trực tiếp không được chạy hậu kỳ');
});

test('bộ tổng hợp nơ-ron chưa cài thì báo rõ, không giả vờ chạy', async () => {
  for (const C of [NV.ZeroTtsProvider, NV.VieNeuProvider, NV.GOmniVoiceProvider]) {
    const p = new C();
    const av = p.available();
    assert.equal(av.ok, false);
    assert.equal(av.reason, 'CHƯA_CÀI');
    assert.ok(av.fix.includes('_URL') && av.fix.includes('_DIR'), `${p.id}: phải chỉ ra cả hai cách cài`);
    const r = await p.synthesize('xin chào', { params: {} });
    assert.equal(r.ok, false);
  }
});

test('SoulX-Singer tự khai chưa có tiếng Việt thay vì hát bừa', async () => {
  const p = new NV.SoulXSingerProvider();
  assert.equal(p.supportsLanguage('vi'), false);
  assert.equal(p.supportsLanguage('zh'), true);
  assert.ok(p.note.includes('CHƯA'));
});

test('tuyến hát chạy được ngay không cần cài mô hình nào', async () => {
  const pipe = new SingingPipeline({
    neural: { soulx: new NV.SoulXSingerProvider(), openUtau: new NV.OpenUtauDiffSingerProvider() },
  });
  const engines = pipe.engines();
  assert.equal(engines[0].id, 'offline-formant');
  assert.equal(engines[0].available, true);
  assert.ok(engines.slice(1).every((e) => !e.available), 'mô hình ngoài chưa cài thì phải báo chưa sẵn sàng');

  const r = await pipe.sing({
    lyrics: 'Quê hương là chùm khế ngọt',
    melody: 'sol4:1 la4:1 si4:1 đô5:1 si4:1 la4:2', bpm: 80, style: 'ballad',
    profile: { f0: 205, timbre: 1.1, seed: 'p' },
  });
  assert.equal(r.ok, true);
  assert.equal(r.engine, 'offline-formant');
  assert.equal(r.notesSung, 6);
  assert.equal(r.wav.toString('ascii', 0, 4), 'RIFF');
  assert.ok(r.studio, 'hát xong phải qua hậu kỳ');
  assert.ok(Math.abs(r.studio.after.lufs - (-14)) < 1.2);
});

test('tuyến hát chặn bài quá dài và giai điệu sai', async () => {
  const pipe = new SingingPipeline({ neural: {} });
  const long = pipe.check({ lyrics: 'la', melody: 'đô4:2000', bpm: 60 });
  assert.equal(long.ok, false);
  assert.equal(long.error, 'BÀI_QUÁ_DÀI');
  assert.equal(pipe.check({ lyrics: 'la', melody: 'sai:1' }).error, 'KÝ_ÂM_SAI');
});

// ── 8. ĐỔI GIỌNG HÁT: CỔNG PHÁP LÝ HAI ĐẦU ─────────────────────────────────

test('đổi giọng hát đòi đủ đồng ý của cả hai người, không có đường vòng', async () => {
  const comp = new VoiceCompliance({});
  const pipe = new ConversionPipeline({ neural: { soVits: new NV.SoVitsSvcProvider() }, compliance: comp });
  const src = Buffer.from('giả lập bản thu');

  assert.equal((await pipe.convert({ sourceWav: src, targetOwnerId: 'B' })).error, 'THIẾU_NGƯỜI_HÁT_GỐC');
  assert.equal((await pipe.convert({ sourceWav: src, singerId: 'A' })).error, 'THIẾU_CHỦ_GIỌNG_ĐÍCH');
  assert.equal((await pipe.convert({ sourceWav: src, singerId: 'A', targetOwnerId: 'B' })).error, 'NGƯỜI_HÁT_GỐC_CHƯA_ĐỒNG_Ý');

  comp.consents.grant({ subjectId: 'A', kind: 'VOICE_RECORD', age: 22, documentRef: 'HS-A' });
  assert.equal((await pipe.convert({ sourceWav: src, singerId: 'A', targetOwnerId: 'B' })).error, 'CHỦ_GIỌNG_ĐÍCH_CHƯA_ĐỒNG_Ý');

  comp.consents.grant({ subjectId: 'B', kind: 'VOICE_CLONE', age: 30, documentRef: 'HS-B' });
  const r = await pipe.convert({ sourceWav: src, singerId: 'A', targetOwnerId: 'B' });
  // Đủ đồng ý rồi thì mới tới chuyện thiếu mô hình — và phải nói thẳng là
  // không có bản thay thế nội bộ.
  assert.equal(r.error, 'BỘ_ĐỔI_GIỌNG_CHƯA_SẴN_SÀNG');
  assert.ok(r.note.includes('không có bản thay thế nội bộ'));
  assert.equal(comp.audit.verify().ok, true);
  assert.ok(comp.audit.entries.some((e) => e.event === 'TỪ_CHỐI_ĐỔI_GIỌNG_HÁT'));
});
