'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');

const C = require('../src/security/crypto');
const SuperAdminVault = require('../src/security/superadmin-vault');
const RecoveryService = require('../src/security/recovery');
const SnapshotStore = require('../src/security/snapshot');
const ResilienceShield = require('../src/security/resilience');
const Constitution = require('../src/governance/constitution');
const AuditChain = require('../src/governance/audit-chain');
const EventStore = require('../src/kernel/event-store');
const Guardrails = require('../src/governance/guardrails');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { buildRoster } = require('../src/agents/roster');
const CapacityGovernor = require('../src/agents/capacity');

/** Thư mục tạm riêng cho mỗi lần chạy — ảnh chụp ghi ra đĩa nên không được dùng chung. */
const tmpDir = () => fs.mkdtempSync(path.join(os.tmpdir(), 'gita-snap-'));

const PW = 'Tr4n#Quang!Vu@2026Zx';
const PW2 = 'Ph4m#Thi!Lan@2026Qw';

function newVault() {
  const es = new EventStore({});
  const audit = new AuditChain({ eventStore: es, guardrails: new Guardrails() });
  return { vault: new SuperAdminVault({ audit, constitution: new Constitution() }), es, audit };
}

// ══════════════════ NGUYÊN THUỶ MẬT MÃ ══════════════════
test('scrypt: băm và xác minh mật khẩu', () => {
  const h = C.hashPassword(PW, 'pepper');
  assert.ok(h.startsWith('scrypt$'));
  assert.equal(C.verifyPassword(PW, h, 'pepper'), true);
  assert.equal(C.verifyPassword('sai', h, 'pepper'), false);
  assert.equal(C.verifyPassword(PW, h, 'pepper-khac'), false, 'đổi pepper phải hỏng');
  assert.notEqual(C.hashPassword(PW, 'pepper'), h, 'muối ngẫu nhiên mỗi lần');
});

test('TOTP RFC 6238: sinh, xác minh, chống mã sai', () => {
  const s = C.totpSecret();
  assert.equal(C.totpVerify(s, C.totpNow(s)), true);
  assert.equal(C.totpVerify(s, '000000'), false);
  assert.equal(C.totpVerify(s, 'abcdef'), false);
  // Cửa sổ ±1 bước
  assert.equal(C.totpVerify(s, C.totpNow(s, 30, Date.now() - 30000)), true);
  // Ngoài cửa sổ
  assert.equal(C.totpVerify(s, C.totpNow(s, 30, Date.now() - 300000)), false);
  assert.ok(C.otpauthURL(s).startsWith('otpauth://totp/'));
});

test('Shamir 3-of-5: đủ mảnh mới khôi phục được', () => {
  const secret = Buffer.from('KHOA-GOC-GITAmath-NexusV20-2026!');
  const shares = C.splitSecret(secret, 5, 3);
  assert.equal(shares.length, 5);
  assert.equal(C.combineShares([shares[0], shares[2], shares[4]]).toString(), secret.toString());
  assert.equal(C.combineShares(shares).toString(), secret.toString());
  assert.notEqual(C.combineShares([shares[0], shares[1]]).toString(), secret.toString(), '2 mảnh không được khôi phục');
});

test('HMAC ký lệnh: phát hiện sửa lệnh', () => {
  const key = C.randomToken(32);
  const payload = { command: 'system.halt', args: { reason: 'x' } };
  const sig = C.signCommand(payload, key);
  assert.equal(C.verifyCommand(payload, sig, key), true);
  assert.equal(C.verifyCommand({ ...payload, args: { reason: 'y' } }, sig, key), false);
  assert.equal(C.verifyCommand(payload, sig, 'khoa-khac'), false);
});

// ══════════════════ 15 TẦNG BẢO VỆ ══════════════════
test('Két Super Admin công bố đủ 15 tầng', () => {
  assert.equal(SuperAdminVault.LAYERS.length, 15);
  const ids = SuperAdminVault.LAYERS.map((l) => l.id);
  assert.equal(new Set(ids).size, 15);
  assert.deepEqual(ids[0], 'L01');
  assert.deepEqual(ids[14], 'L15');
});

test('L03: chính sách mật khẩu chặn mật khẩu yếu', () => {
  const { vault } = newVault();
  assert.equal(vault.initialize({ username: 'superadmin', password: 'abc123' }).error, 'WEAK_PASSWORD');
  assert.equal(vault.initialize({ username: 'superadmin', password: 'khongcochuhoa@2026x' }).error, 'WEAK_PASSWORD');
  assert.equal(vault.initialize({ username: 'superadmin', password: 'Gita#Math@2026!Nexus' }).error, 'WEAK_PASSWORD', 'chứa tên sản phẩm');
  assert.equal(vault.initialize({ username: 'superadmin', password: PW }).ok, true);
});

test('khởi tạo chỉ chạy một lần và trả đủ bí mật', () => {
  const { vault } = newVault();
  const r = vault.initialize({ username: 'superadmin', password: PW });
  assert.equal(r.ok, true);
  assert.equal(r.recoveryCodes.length, 10);
  assert.equal(r.guardianShares.length, 5);
  assert.equal(r.guardianPolicy, '3-of-5');
  assert.ok(r.breakGlassKey && r.totpSecret);
  assert.equal(vault.initialize({ username: 'x', password: PW }).error, 'ALREADY_INITIALIZED');
});

test('L01/L02/L04: đăng nhập cần đủ mật khẩu và 2FA', () => {
  const { vault } = newVault();
  const init = vault.initialize({ username: 'superadmin', password: PW });
  assert.equal(vault.login({ username: 'ai-do', password: PW }).layer, 'L01');
  assert.equal(vault.login({ username: 'superadmin', password: 'sai' }).layer, 'L02');
  assert.equal(vault.login({ username: 'superadmin', password: PW }).error, 'MFA_REQUIRED');
  const ok = vault.login({ username: 'superadmin', password: PW, totpToken: C.totpNow(init.totpSecret), deviceId: 'd1', ip: '1.2.3.4' });
  assert.equal(ok.ok, true);
  assert.equal(ok.mfaMethod, 'TOTP');
  assert.ok(ok.layersPassed.includes('L04'));
  assert.ok(ok.token && ok.sessionKey);
});

test('L05: mã khôi phục dùng được một lần duy nhất', () => {
  const { vault } = newVault();
  const init = vault.initialize({ username: 'superadmin', password: PW });
  const code = init.recoveryCodes[0];
  const a = vault.login({ username: 'superadmin', password: PW, recoveryCode: code, ip: '1.1.1.1' });
  assert.equal(a.ok, true);
  assert.equal(a.mfaMethod, 'RECOVERY_CODE');
  assert.equal(a.recoveryCodesLeft, 9);
  const b = vault.login({ username: 'superadmin', password: PW, recoveryCode: code, ip: '1.1.1.1' });
  assert.equal(b.ok, false, 'mã đã dùng không được dùng lại');
});

test('L08: khoá luỹ tiến sau 5 lần sai', () => {
  const { vault } = newVault();
  vault.initialize({ username: 'superadmin', password: PW });
  let last;
  for (let i = 0; i < 5; i++) last = vault.login({ username: 'superadmin', password: 'sai', ip: '9.9.9.9' });
  assert.ok(last.lockedUntil, 'phải bị khoá');
  const locked = vault.login({ username: 'superadmin', password: PW, ip: '9.9.9.9' });
  assert.equal(locked.error, 'LOCKED_OUT');
  assert.equal(locked.layer, 'L08');
  assert.ok(locked.retryAfterMs > 0);
});

test('L09: phát hiện thiết bị lạ', () => {
  const { vault } = newVault();
  const init = vault.initialize({ username: 'superadmin', password: PW });
  const a = vault.login({ username: 'superadmin', password: PW, totpToken: C.totpNow(init.totpSecret), deviceId: 'may-1', ip: '1.2.3.4' });
  assert.ok(a.anomalies.includes('THIET_BI_LA'), 'lần đầu luôn là thiết bị lạ');
  const b = vault.login({ username: 'superadmin', password: PW, totpToken: C.totpNow(init.totpSecret), deviceId: 'may-1', ip: '1.2.3.4' });
  assert.ok(!b.anomalies.includes('THIET_BI_LA'), 'thiết bị đã biết thì thôi');
});

test('L07+L10+L11: lệnh huỷ diệt cần step-up, chữ ký và kiểm soát kép', () => {
  const { vault } = newVault();
  const init = vault.initialize({ username: 'superadmin', password: PW });
  const s = vault.login({ username: 'superadmin', password: PW, totpToken: C.totpNow(init.totpSecret), deviceId: 'd', ip: '1.2.3.4' });

  // Lệnh thường: qua ngay
  const normal = vault.authorize(s.token, 'agents.status', {});
  assert.equal(normal.ok, true);
  assert.equal(normal.destructive, false);

  // Lệnh huỷ diệt không ký → chặn ở L10
  const unsigned = vault.authorize(s.token, 'system.halt', {});
  assert.equal(unsigned.error, 'SIGNATURE_REQUIRED');
  assert.equal(unsigned.layer, 'L10');

  // Ký sai → chặn ở L10
  const badSig = vault.authorize(s.token, 'system.halt', {}, 'chu-ky-gia');
  assert.equal(badSig.error, 'INVALID_SIGNATURE');

  // Ký đúng → vướng L11
  const sig = C.signCommand({ command: 'system.halt', args: {} }, s.sessionKey);
  const first = vault.authorize(s.token, 'system.halt', {}, sig);
  assert.equal(first.error, 'DUAL_CONTROL_PENDING');
  assert.equal(first.layer, 'L11');

  // Người thứ hai duyệt → thông
  const ap = vault.approveDual(first.requestId, 'CTO');
  assert.equal(ap.ready, true);
  const second = vault.authorize(s.token, 'system.halt', {}, sig);
  assert.equal(second.ok, true);
  assert.ok(second.layersPassed.includes('L11'));
  assert.ok(second.layersPassed.includes('L15'));
});

test('L07: hết cửa sổ step-up thì lệnh huỷ diệt bị chặn', () => {
  const { vault } = newVault();
  const init = vault.initialize({ username: 'superadmin', password: PW });
  const s = vault.login({ username: 'superadmin', password: PW, totpToken: C.totpNow(init.totpSecret), deviceId: 'd', ip: '1.2.3.4' });
  const sess = vault.getSession(s.token);
  sess.lastAuthAt = Date.now() - 10 * 60_000; // quá 5 phút
  const r = vault.authorize(s.token, 'system.reset', {}, 'x');
  assert.equal(r.error, 'STEP_UP_REQUIRED');
  assert.equal(r.layer, 'L07');

  const up = vault.stepUp(s.token, { password: PW, totpToken: C.totpNow(init.totpSecret) });
  assert.equal(up.ok, true);
  const after = vault.authorize(s.token, 'system.reset', {}, C.signCommand({ command: 'system.reset', args: {} }, s.sessionKey));
  assert.equal(after.error, 'DUAL_CONTROL_PENDING', 'qua L07 rồi, giờ mới tới L11');
});

test('L14: chìa khoá phá kính dùng một lần', () => {
  const { vault } = newVault();
  const init = vault.initialize({ username: 'superadmin', password: PW });
  assert.equal(vault.breakGlass('khoa-sai', 'thu').error, 'INVALID_BREAK_GLASS_KEY');
  const r = vault.breakGlass(init.breakGlassKey, 'mất TOTP và mã khôi phục');
  assert.equal(r.ok, true);
  assert.ok(r.token);
  assert.equal(vault.breakGlass(init.breakGlassKey, 'lần hai').error, 'BREAK_GLASS_ALREADY_USED');
  assert.equal(vault.status().breakGlassAvailable, false);
});

test('L12: mọi hành động Super Admin vào nhật ký bất biến', () => {
  const { vault, audit } = newVault();
  const init = vault.initialize({ username: 'superadmin', password: PW });
  const s = vault.login({ username: 'superadmin', password: PW, totpToken: C.totpNow(init.totpSecret), deviceId: 'd', ip: '1.2.3.4' });
  vault.authorize(s.token, 'agents.status', {});
  assert.equal(audit.verify().ok, true);
  const q = audit.query({ limit: 100 });
  assert.ok(q.items.some((r) => r.payload.action === 'superadmin.login'));
  assert.ok(q.items.some((r) => r.payload.action === 'superadmin.agents.status'));
});

// ══════════════════ KHÔI PHỤC ══════════════════
test('khôi phục mật khẩu bằng nhóm giám hộ 3-of-5', () => {
  const { vault, es, audit } = newVault();
  const init = vault.initialize({ username: 'superadmin', password: PW });
  const snapshots = new SnapshotStore({ collect: () => ({}), apply: () => ({}), dir: tmpDir() });
  const rec = new RecoveryService({ vault, snapshots, audit });

  const ch = rec.start({ username: 'superadmin', method: 'GUARDIAN_QUORUM' });
  assert.equal(ch.ok, true);
  assert.equal(rec.submitShare(ch.challengeId, init.guardianShares[0]).need, 2);
  assert.equal(rec.submitShare(ch.challengeId, init.guardianShares[0]).error, 'DUPLICATE_SHARE');
  rec.submitShare(ch.challengeId, init.guardianShares[2]);
  const third = rec.submitShare(ch.challengeId, init.guardianShares[4]);
  assert.equal(third.verified, true);

  const done = rec.complete(ch.challengeId, { newPassword: PW2 });
  assert.equal(done.ok, true);
  assert.equal(vault.login({ username: 'superadmin', password: PW2, totpToken: C.totpNow(init.totpSecret), ip: '1.1.1.1' }).ok, true);
  assert.equal(vault.login({ username: 'superadmin', password: PW, totpToken: C.totpNow(init.totpSecret), ip: '1.1.1.1' }).ok, false);
});

test('khôi phục chặn tái dùng mật khẩu cũ', () => {
  const { vault, audit } = newVault();
  const init = vault.initialize({ username: 'superadmin', password: PW });
  const snapshots = new SnapshotStore({ collect: () => ({}), apply: () => ({}), dir: tmpDir() });
  const rec = new RecoveryService({ vault, snapshots, audit });
  const ch = rec.start({ username: 'superadmin', method: 'TOTP' });
  const r = rec.complete(ch.challengeId, { newPassword: PW, currentPassword: PW, totpToken: C.totpNow(init.totpSecret) });
  assert.equal(r.error, 'PASSWORD_REUSED');
});

test('khôi phục không tiết lộ tài khoản có tồn tại hay không', () => {
  const { vault, audit } = newVault();
  vault.initialize({ username: 'superadmin', password: PW });
  const snapshots = new SnapshotStore({ collect: () => ({}), apply: () => ({}), dir: tmpDir() });
  const rec = new RecoveryService({ vault, snapshots, audit });
  const r = rec.start({ username: 'khong-ton-tai', method: 'TOTP' });
  assert.equal(r.ok, true, 'vẫn trả ok để không lộ thông tin');
  assert.ok(r.hint.includes('Nếu tài khoản tồn tại'));
});

// ══════════════════ BẢO LƯU PHIÊN BẢN / THỜI ĐIỂM ══════════════════
test('ảnh chụp: đánh phiên bản, băm móc xích, phát hiện sửa đổi', async () => {
  let state = { x: 1 };
  const s = new SnapshotStore({ collect: () => ({ app: { ...state } }), apply: (d) => { state = d.app; return { ok: true }; }, dir: tmpDir() });
  const a = await s.take({ label: 'moc-a' });
  state.x = 2;
  const b = await s.take({ label: 'moc-b' });
  assert.equal(a.version, 'v20.00001');
  assert.equal(b.version, 'v20.00002');
  assert.equal(s.verify().ok, true);

  s.snapshots[0].data.app.x = 999; // sửa lén
  const v = s.verify();
  assert.equal(v.ok, false);
  assert.equal(v.brokenAt, 'v20.00001');
});

test('ảnh chụp: khôi phục theo phiên bản và theo thời điểm', async () => {
  let state = { x: 'ban-dau' };
  const s = new SnapshotStore({ collect: () => ({ app: { ...state } }), apply: (d) => { state = { ...d.app }; return { restored: true }; }, dir: tmpDir() });
  const v1 = await s.take({ label: 'v1' });
  const t1 = Date.now();
  await new Promise((r) => setTimeout(r, 10));
  state.x = 'da-doi';
  await s.take({ label: 'v2' });

  assert.equal(state.x, 'da-doi');
  const r = s.restore(`SNAP-${v1.version}`);
  assert.equal(r.ok, true);
  assert.equal(state.x, 'ban-dau', 'khôi phục theo phiên bản');

  state.x = 'doi-lan-nua';
  const byTime = s.resolve({ at: t1 });
  assert.equal(byTime.version, v1.version, 'chọn ảnh gần nhất trước mốc thời gian');
  s.restore(byTime.id);
  assert.equal(state.x, 'ban-dau', 'khôi phục theo thời điểm');
});

test('ảnh chụp: chính sách giữ luôn giữ ảnh thủ công', async () => {
  const s = new SnapshotStore({ collect: () => ({ n: 1 }), apply: () => ({}), dir: tmpDir() });
  await s.take({ label: 'quan-trong', auto: false });
  for (let i = 0; i < 20; i++) await s.take({ label: 'auto', auto: true });
  assert.ok(s.snapshots.some((x) => x.label === 'quan-trong'), 'ảnh thủ công không bị xoá');
  assert.ok(s.snapshots.length <= 21);
});

// ══════════════════ CHỐNG NHIỄU CHO 500 AGENT ══════════════════
function newShield() {
  const { agents } = buildRoster();
  const capacity = new CapacityGovernor({ agents });
  const shield = new ResilienceShield({ agents, capacity, runtime: null, queue: { waiting: 0 }, scheduler: null });
  return { shield, agents, capacity };
}

test('lọc nhiễu: chặn đầu vào rác, cho qua đầu vào sạch', () => {
  const { shield } = newShield();
  assert.equal(shield.filterInput('').ok, false);
  assert.equal(shield.filterInput('a'.repeat(100)).rule, 'REPEAT_CHAR');
  assert.equal(shield.filterInput('x'.repeat(40000)).rule, 'TOO_LONG');
  assert.equal(shield.filterInput('\u0000\u0001 xin chao').rule, 'CONTROL_CHARS');
  assert.equal(shield.filterInput('A'.repeat(500) + '=').rule, 'REPEAT_CHAR');
  assert.equal(shield.filterInput('spam '.repeat(50)).rule, 'REPEAT_TOKEN');
  const ok = shield.filterInput('Giải phương trình bậc hai có tham số m');
  assert.equal(ok.ok, true);
  assert.ok(ok.signal > 0);
  shield.stop();
});

test('cách ly: 5 lỗi liên tiếp thì agent bị loại khỏi vòng phân công', () => {
  const { shield, agents } = newShield();
  const id = agents.find((a) => a.rank === 'WORKER').id;
  assert.equal(shield.isEligible(id), true);
  for (let i = 0; i < 2; i++) shield.reportFailure(id);
  assert.equal(shield.health.get(id).state, 'DEGRADED');
  assert.equal(shield.isEligible(id), true, 'suy giảm vẫn được nhận việc');
  for (let i = 0; i < 3; i++) shield.reportFailure(id);
  assert.equal(shield.health.get(id).state, 'QUARANTINED');
  assert.equal(shield.isEligible(id), false, 'bị cách ly thì không nhận việc');
  shield.stop();
});

test('tự chữa: hết hạn cách ly thì trở lại đội hình', () => {
  const { shield, agents } = newShield();
  const id = agents[10].id;
  for (let i = 0; i < 5; i++) shield.reportFailure(id);
  assert.equal(shield.isEligible(id), false);
  shield.health.get(id).quarantinedUntil = Date.now() - 1;
  shield.sweep();
  assert.equal(shield.health.get(id).state, 'HEALTHY');
  assert.equal(shield.isEligible(id), true);
  shield.stop();
});

test('chó canh: phát hiện agent treo và giải phóng chỗ bị kẹt', () => {
  const { shield, agents, capacity } = newShield();
  const id = agents[20].id;
  capacity.admit(id, 100);
  assert.equal(capacity.freeSlots(id), agents[20].capacity.maxConcurrent - 1);
  shield.markInflight(id);
  shield.health.get(id).inflightSince = Date.now() - 200_000; // treo 200s
  const r = shield.sweep();
  assert.equal(r.stalled, 1);
  assert.equal(r.reclaimed, 1);
  assert.equal(capacity.freeSlots(id), agents[20].capacity.maxConcurrent, 'chỗ đã được trả lại');
  shield.stop();
});

test('giảm chấn dao động: agent lúc tốt lúc xấu bị giữ lại', () => {
  const { shield, agents } = newShield();
  const id = agents[30].id;
  for (let i = 0; i < 4; i++) {
    shield.reportFailure(id); shield.reportFailure(id);
    shield.reportSuccess(id);
  }
  const h = shield.health.get(id);
  assert.ok(h.holdUntil > Date.now(), 'phải bị giữ do dao động');
  assert.equal(shield.isEligible(id), false);
  assert.ok(shield.stats.flapsDamped >= 1);
  shield.stop();
});

test('áp lực ngược: hàng đợi quá sâu thì từ chối việc không khẩn', () => {
  const { shield } = newShield();
  shield.queue = { waiting: 5000 };
  assert.equal(shield.admissionCheck({ input: 'viec thuong', priority: 'normal' }).error, 'BACKPRESSURE');
  assert.equal(shield.admissionCheck({ input: 'viec khan', priority: 'critical' }).ok, true);
  shield.stop();
});

test('ngăn khoang: sức khoẻ tính riêng theo từng khối', () => {
  const { shield, agents } = newShield();
  const mathIds = agents.filter((a) => a.division === 'MATH').slice(0, 45).map((a) => a.id);
  for (const id of mathIds) for (let i = 0; i < 5; i++) shield.reportFailure(id);
  const dh = shield.divisionHealth();
  const math = dh.find((d) => d.division === 'MATH');
  const code = dh.find((d) => d.division === 'CODE');
  assert.ok(math.quarantined >= 45);
  assert.equal(math.breached, true, 'khối MATH mất quá nửa đội hình');
  assert.equal(code.availability, 1, 'khối CODE không bị ảnh hưởng');
  shield.stop();
});

test('chỉ số sẵn sàng đội hình 500 agent', () => {
  const { shield, agents } = newShield();
  assert.equal(shield.fleetReadiness().total, 500);
  assert.equal(shield.fleetReadiness().readiness, 1);
  for (const a of agents.slice(0, 50)) for (let i = 0; i < 5; i++) shield.reportFailure(a.id);
  const f = shield.fleetReadiness();
  assert.equal(f.eligible, 450);
  assert.equal(f.readiness, 0.9);
  const healed = shield.healAll();
  assert.equal(healed.healed, 50);
  assert.equal(shield.fleetReadiness().readiness, 1);
  shield.stop();
});
