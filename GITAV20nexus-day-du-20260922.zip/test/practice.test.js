'use strict';
/** Phiên luyện tập: chọn đúng bài, chấm được đáp án viết khác cách, thích ứng trong phiên. */
const { test, before, beforeEach } = require('node:test');
const assert = require('node:assert/strict');

const ItemBank = require('../src/content/item-bank');
const ItemGenerator = require('../src/content/generator');
const BankSeeder = require('../src/content/seeder');
const PracticeEngine = require('../src/learner/practice');
const Mastery = require('../src/learner/mastery');
const Telemetry = require('../src/learner/telemetry');
const ProfileStore = require('../src/learner/profile');
const MathVerifier = require('../src/math/verifier');
const { SOURCES } = PracticeEngine;
const { MASTERY_THRESHOLD } = Mastery;

let bank;
before(() => {
  bank = new ItemBank();
  new BankSeeder({ bank, generator: new ItemGenerator({ bank }) }).seed({ perBlueprintLevel: 3 });
});

function rig(level = 3) {
  const telemetry = new Telemetry();
  const mastery = new Mastery();
  const profiles = new ProfileStore({ telemetry, mastery });
  profiles.register('HV', { fullName: 'Học viên thử', grade: 9 });
  profiles.get('HV').currentLevel = level;
  const engine = new PracticeEngine({ bank, mastery, telemetry, profiles, verifier: new MathVerifier() });
  return { engine, mastery, telemetry, profiles };
}

/** Chạy hết một phiên với luật trả lời cho trước. */
function play(engine, sessionId, firstItem, decide) {
  let cur = firstItem;
  let n = 0;
  let last = null;
  while (cur && n < 40) {
    const r = engine.answer({ sessionId, itemId: cur.itemId, ...decide(cur, n) });
    assert.equal(r.ok, true, JSON.stringify(r));
    n++;
    if (r.done) { last = r; break; }
    cur = r.next;
  }
  return last || engine.finish(sessionId);
}

test('phiên nêu rõ vì sao chọn từng bài, không bốc bừa', () => {
  const { engine } = rig();
  const st = engine.start({ learnerId: 'HV', size: 8 });
  assert.equal(st.ok, true);
  assert.ok(st.size > 0);
  for (const p of st.plan) {
    assert.ok(Object.keys(SOURCES).includes(p.source), p.source);
    assert.ok(p.why && p.why.length > 10, `bài ${p.formCode} không nói được vì sao chọn`);
  }
  assert.ok(st.composition.length >= 1);
});

test('nợ ôn tập được ưu tiên trước mọi thứ khác', () => {
  const { engine, mastery } = rig();
  // Tạo nợ ôn: làm một dạng rồi đẩy hạn ôn về quá khứ.
  mastery.update('HV', { formCode: 'M9.PT2.GIAI', stars: 2, correct: true, hintsUsed: 0 });
  const rec = mastery.get('HV', 'M9.PT2.GIAI');
  rec.nextDueAt = Date.now() - 5 * 86400000;

  const plan = engine.plan({ learnerId: 'HV', size: 8 });
  const first = plan.queue[0];
  assert.equal(first.source, SOURCES.REVIEW.code, `bài đầu là ${first.source}, đáng lẽ phải là nợ ôn`);
  assert.equal(first.formCode, 'M9.PT2.GIAI');
  assert.match(first.why, /quá hạn 5 ngày/);
});

test('không nhảy cóc: dạng mới chỉ vào phiên khi tiên quyết đã đủ', () => {
  const { engine, mastery } = rig();
  const plan = engine.plan({ learnerId: 'HV', size: 12 });
  const { FORM_INDEX } = require('../src/curriculum/hierarchy');
  const map = mastery.map('HV');
  for (const q of plan.queue.filter((x) => x.source === SOURCES.NEW.code)) {
    for (const pr of FORM_INDEX.get(q.formCode)?.prereq || []) {
      if (!FORM_INDEX.has(pr)) continue;
      assert.ok((map[pr] ?? 0) >= 0.5 || q.why.includes('cửa vào'),
        `${q.formCode} vào phiên nhưng tiên quyết ${pr} mới ${map[pr] ?? 0}`);
    }
  }
});

test('phiên thứ hai đổi thành phần vì đã có dữ liệu học', () => {
  const { engine } = rig();
  const st1 = engine.start({ learnerId: 'HV', size: 10 });
  play(engine, st1.sessionId, st1.item, (_, n) => ({ correct: n % 4 !== 3, ms: 100_000 }));
  const st2 = engine.start({ learnerId: 'HV', size: 10 });
  const kinds = st2.composition.map((c) => c.code);
  assert.ok(kinds.length >= 2, `phiên 2 vẫn chỉ có ${kinds.join(',')}`);
});

test('chấm tự động: đáp án viết khác cách vẫn được công nhận', () => {
  const { engine } = rig();
  const it = [...bank.items.values()].find((i) => i.check?.equation && i.status === 'PUBLISHED' && /hoặc/.test(i.answer));
  assert.ok(it, 'cần một bài có hai nghiệm để thử');
  assert.equal(engine.grade(it.id, it.answer).correct, true);

  const roots = it.answer.match(/-?\d+/g);
  assert.equal(engine.grade(it.id, `{${roots.join('; ')}}`).correct, true, 'viết dạng tập hợp phải được nhận');
  assert.equal(engine.grade(it.id, `S = {${roots.reverse().join(', ')}}`).correct, true, 'đổi thứ tự vẫn đúng');
});

test('chấm tự động bắt được đáp án sai và nói sai ở đâu', () => {
  const { engine } = rig();
  const it = [...bank.items.values()].find((i) => i.check?.equation && i.status === 'PUBLISHED' && /hoặc/.test(i.answer));
  const r = engine.grade(it.id, 'x = 999');
  assert.equal(r.correct, false);
  assert.equal(r.method, 'ROOT_SET');
  assert.match(r.reason, /thiếu nghiệm|thừa nghiệm/);
});

test('đáp án không chấm máy được thì nói thẳng, không đoán', () => {
  const { engine } = rig();
  const it = [...bank.items.values()].find((i) => !i.check?.equation && !i.check?.expression && i.status === 'PUBLISHED')
    || [...bank.items.values()].find((i) => i.status === 'PUBLISHED');
  const r = engine.grade(it.id, 'em chứng minh bằng cách kẻ thêm đường phụ');
  assert.ok(r.correct === false || r.correct === null);
  if (r.correct === null) assert.match(r.reason, /cần giáo viên chấm/);
});

test('bài chờ chấm tay không đụng vào mức thạo', () => {
  const { engine, mastery } = rig();
  const st = engine.start({ learnerId: 'HV', size: 5 });
  const before = mastery.summary('HV').totalAttempts;
  const r = engine.answer({ sessionId: st.sessionId, itemId: st.item.itemId, answer: 'em giải bằng lời', ms: 200_000 });
  if (r.pending) {
    assert.equal(mastery.summary('HV').totalAttempts, before, 'chưa chấm mà đã tính vào mức thạo là sai');
  }
});

test('sai hai bài liên tiếp thì lùi về bài dễ hơn, hoặc nói thẳng là kho không có', () => {
  const { engine } = rig();
  const st = engine.start({ learnerId: 'HV', size: 10 });
  let cur = st.item;
  let reacted = false;
  let rescued = false;
  for (let i = 0; i < 6; i++) {
    const r = engine.answer({ sessionId: st.sessionId, itemId: cur.itemId, correct: false, ms: 200_000 });
    if (r.adapted?.some((a) => /Sai 2 bài liên tiếp/.test(a))) reacted = true;
    if (r.adapted?.some((a) => /chen một bài gỡ/.test(a))) rescued = true;
    if (r.done) break;
    cur = r.next;
  }
  assert.ok(reacted, 'sai liên tiếp mà hệ thống im lặng là bỏ rơi học viên');
  const rep = engine.get(st.sessionId);
  assert.ok(rep, 'phiên vẫn tra cứu được');
  // Có gỡ được hay không thì cũng phải ghi lại dấu vết để giáo viên thấy.
  const s = engine.sessions.get(st.sessionId);
  const flags = s.flags.filter((f) => f.kind === 'STREAK_WRONG');
  assert.ok(flags.length >= 1, 'phải ghi cờ tắc');
  for (const f of flags) assert.equal(typeof f.rescued, 'boolean');
  // Có gỡ được lần nào thì cờ phải phản ánh đúng lần đó.
  assert.equal(rescued, flags.some((f) => f.rescued),
    'lời báo trong phiên và cờ ghi lại phải khớp nhau');
});

test('khi lùi, ưu tiên bài dễ hơn cùng dạng rồi mới tới dạng tiên quyết', () => {
  const { engine } = rig();
  const { FORM_INDEX } = require('../src/curriculum/hierarchy');
  const item = [...bank.items.values()].find((i) => i.status === 'PUBLISHED' && (FORM_INDEX.get(i.formCode)?.prereq || []).length);
  assert.ok(item, 'cần một bài thuộc dạng có tiên quyết');
  const found = engine._findEasier(item, []);
  if (found) {
    assert.ok(found.item.id !== item.id);
    assert.ok(found.why.length > 10);
    const sameForm = found.item.formCode === item.formCode;
    const isPrereq = (FORM_INDEX.get(item.formCode)?.prereq || []).includes(found.item.formCode);
    assert.ok(sameForm || isPrereq, `lùi sang ${found.item.formCode} không liên quan gì tới ${item.formCode}`);
  }
});

test('đúng ba bài liên tiếp không gợi ý thì nâng độ khó', () => {
  const { engine } = rig();
  const st = engine.start({ learnerId: 'HV', size: 10 });
  let cur = st.item;
  let raised = false;
  for (let i = 0; i < 6; i++) {
    const r = engine.answer({ sessionId: st.sessionId, itemId: cur.itemId, correct: true, ms: 200_000, hintsUsed: 0 });
    if (r.adapted?.some((a) => /nâng độ khó/i.test(a))) raised = true;
    if (r.done) break;
    cur = r.next;
  }
  assert.ok(raised);
});

test('làm quá nhanh rồi sai bị ghi là đoán mò', () => {
  const { engine } = rig();
  const st = engine.start({ learnerId: 'HV', size: 6 });
  const r = engine.answer({ sessionId: st.sessionId, itemId: st.item.itemId, correct: false, ms: 1000 });
  assert.ok(r.adapted.some((a) => /đoán mò/.test(a)) || r.feedback.note.includes('rất nhanh'));
  const report = engine.finish(st.sessionId);
  assert.ok(report.rushedCount >= 1);
  assert.ok(report.flags.some((f) => f.kind === 'RUSH'));
});

test('nhận xét sau mỗi bài nêu đúng chỗ dễ nhầm, không chỉ "sai rồi"', () => {
  const { engine } = rig();
  const st = engine.start({ learnerId: 'HV', size: 6 });
  const r = engine.answer({ sessionId: st.sessionId, itemId: st.item.itemId, correct: false, ms: 200_000 });
  assert.equal(r.feedback.verdict, 'CHƯA ĐÚNG');
  assert.ok(Array.isArray(r.feedback.traps) && r.feedback.traps.length >= 1, 'phải nêu bẫy của dạng');
  assert.ok(Array.isArray(r.feedback.solutionSteps) && r.feedback.solutionSteps.length >= 1);
});

test('báo cáo cuối phiên có số liệu thật và lời khuyên cụ thể', () => {
  const { engine } = rig();
  const st = engine.start({ learnerId: 'HV', size: 8 });
  const rep = play(engine, st.sessionId, st.item, (_, n) => ({ correct: n % 3 !== 2, ms: 120_000 }));
  assert.equal(rep.ok, true);
  assert.ok(rep.answered >= 1);
  assert.ok(rep.accuracy >= 0 && rep.accuracy <= 1);
  assert.ok(rep.byForm.length >= 1);
  assert.ok(rep.nextAdvice.length >= 1);
  assert.ok(rep.masterySnapshot.totalAttempts >= rep.answered - rep.pendingManual);
});

test('phiên quá giờ thì dừng, không ép học tiếp', () => {
  const { engine } = rig();
  const st = engine.start({ learnerId: 'HV', size: 20 });
  const s = engine.sessions.get(st.sessionId);
  s.startedAt = Date.now() - 60 * 60_000;     // đã học một tiếng
  const r = engine.answer({ sessionId: st.sessionId, itemId: st.item.itemId, correct: true, ms: 100_000 });
  assert.equal(r.done, true);
  assert.equal(r.reason, 'QUÁ_GIỜ');
});

test('mỗi lượt làm bài được ghi vào nhật ký thao tác và mức thạo', () => {
  const { engine, mastery, telemetry } = rig();
  const st = engine.start({ learnerId: 'HV', size: 5 });
  play(engine, st.sessionId, st.item, () => ({ correct: true, ms: 100_000 }));
  assert.ok(mastery.summary('HV').totalAttempts >= 3);
  assert.ok(telemetry.behaviors('HV').metrics, 'phải dựng được hành vi từ nhật ký');
});

test('sai phiên, sai bài, phiên đã đóng đều bị từ chối rõ ràng', () => {
  const { engine } = rig();
  const st = engine.start({ learnerId: 'HV', size: 5 });
  assert.equal(engine.answer({ sessionId: 'KHONG-CO', correct: true }).error, 'SESSION_NOT_FOUND');
  assert.equal(engine.answer({ sessionId: st.sessionId, itemId: 'SAI-BAI', correct: true }).error, 'WRONG_ITEM');
  engine.finish(st.sessionId);
  assert.equal(engine.answer({ sessionId: st.sessionId, itemId: st.item.itemId, correct: true }).error, 'SESSION_FINISHED');
});

test('chưa có mã học viên thì không mở phiên', () => {
  const { engine } = rig();
  assert.equal(engine.start({}).error, 'MISSING_INPUT');
});

test('thiếu bài thì báo thiếu, không lặng lẽ cắt ngắn phiên', () => {
  const { engine } = rig(9);   // tầng 9 gần như chưa có bài phát hành
  const plan = engine.plan({ learnerId: 'HV', size: 10, level: 9 });
  if (plan.size < 10) {
    assert.ok(plan.shortfall > 0);
    assert.match(plan.shortfallReason, /chưa đủ bài/);
  }
});

test('Bài khôi phục từ đĩa không làm đổ phiên luyện ở lượt chấm đầu', () => {
  // Lỗi đã thật sự xảy ra: restore() dựng lại history/attempts/correct nhưng
  // bỏ quên mảng timeMs, nên bài khôi phục từ ảnh chụp làm đổ /practice/answer
  // ngay lượt chấm tự động đầu tiên — và chỉ hiện ra SAU khi khởi động lại.
  const ItemBank = require('../src/content/item-bank');
  const Bank = ItemBank.ItemBank || ItemBank;
  const bank = new Bank();
  bank.items.set('IT-THIEU-TRUONG', {
    id: 'IT-THIEU-TRUONG', formCode: 'M9.PT2.GIAI', stars: 2,
    attempts: 0, correct: 0, history: [],
    // cố ý KHÔNG có timeMs, đúng như bản ghi cũ đọc lên từ đĩa
  });
  const r = bank.recordAttempt('IT-THIEU-TRUONG', { correct: true, ms: 1200 });
  assert.notEqual(r.ok, false);
  assert.deepEqual(bank.items.get('IT-THIEU-TRUONG').timeMs, [1200]);
});
