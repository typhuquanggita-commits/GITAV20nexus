'use strict';
/**
 * CÂY TIỀN (nội bộ) VÀ CÂY GIÁ TRỊ (mặt khách hàng)
 *
 * Bộ kiểm này canh một luật KHÔNG ĐƯỢC PHÉP hỏng một lần: bảng phân loại giá
 * trị gia đình không bao giờ được lọt ra mặt khách hàng. Một lần rò rỉ là một
 * gia đình đọc thấy mình bị xếp vào "Cây chớm héo", và chuyện đó không sửa
 * lại được bằng một bản vá.
 *
 * Nên phần lớn các mục dưới đây kiểm PHÍA CHẶN, và mục nào cũng phải chứng
 * minh bức tường CÓ RĂNG — bằng cách thả một chuỗi rò rỉ thật vào và đòi nó
 * bị bắt. Một bức tường luôn trả "sạch" thì không canh gì cả.
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const Telemetry = require('../src/learner/telemetry');
const khung = require('../src/cay-tien/khung');
const PL = require('../src/cay-tien/phan-loai');
const tuong = require('../src/cay-tien/buc-tuong');
const cgt = require('../src/nha/cay-gia-tri');
const trang = require('../src/web/nha-trang');
const { VAI_INDEX } = require('../src/nha/ban-do');

const NGAY = 86400000;
const NGUOI = { ten: 'Người Thử', vaiTen: 'Phụ huynh', nhaTen: '' };

/**
 * Dựng dấu vết TẤT ĐỊNH cho một học viên: bao nhiêu buổi, bao nhiêu bài, đúng
 * bao nhiêu, im lặng mấy ngày. Không random — cùng đầu vào cho cùng nhóm.
 */
function hoc(t, id, { buoi = 10, bai = 40, dung = 32, bo = 0, imNgay = 0, phutMoiBuoi = 30, batDauTruoc = 60 } = {}) {
  const bayGio = Date.now();
  const dau = bayGio - batDauTruoc * NGAY;
  for (let i = 0; i < buoi; i++) {
    const s = { start: dau + i * NGAY, end: dau + i * NGAY + phutMoiBuoi * 60000, items: 0, correct: 0, minutes: phutMoiBuoi };
    if (!t.sessions.has(id)) t.sessions.set(id, []);
    t.sessions.get(id).push(s);
  }
  const arr = [];
  for (let i = 0; i < bai; i++) {
    arr.push({
      at: bayGio - imNgay * NGAY - (bai - i) * 60000,
      itemId: `IT-${i}`, formCode: 'M9.PT2.GIAI', level: 4, stars: 3,
      correct: i < dung, ms: 90000, speedRatio: 0.9,
      hintsUsed: 0, peeked: false, skipped: i >= bai - bo, retries: 0, thinking: { steps: 3 }, careless: false,
    });
  }
  t.attempts.set(id, arr);
  // Buổi cuối cũng phải lùi đúng số ngày im lặng, nếu không phép đo "im lặng"
  // sẽ đọc buổi học như vừa mới xong.
  if (imNgay > 0) for (const s of t.sessions.get(id)) { s.start -= imNgay * NGAY; s.end -= imNgay * NGAY; }
  return t;
}

const masGia = (thao, cham) => ({ summary: () => ({ formsTouched: cham, formsMastered: thao }) });

// ═══ BỨC TƯỜNG ═════════════════════════════════════════════════════════════

test('Bức tường bắt được chữ Cây Tiền ở mọi dạng: có dấu, không dấu, mã nhóm, HTML', () => {
  const phai = [
    'Gia đình này thuộc nhóm Cây tiền',
    'cay tien cua he thong',
    { nhom: 'CAY_CHOM_HEO' },
    'giá trị đồng hành 70/100',
    '&quot;Cây cần cứu&quot;',
    ['a', ['b', { c: 'nguy cơ rời bỏ cao' }]],
  ];
  for (const x of phai) {
    const r = tuong.soiRoRi(x);
    assert.equal(r.sach, false, `phải bắt được: ${JSON.stringify(x)}`);
    assert.ok(r.roRi[0].cum, 'phải nói rõ bắt được cụm nào');
  }
});

test('Bức tường KHÔNG bắt oan "Cây giá trị" — đó là cây của khách hàng', () => {
  for (const x of ['Cây giá trị', 'cay gia tri cua gia dinh', 'Năm tầng của Cây giá trị hệ thống tạo ra']) {
    assert.equal(tuong.soiRoRi(x).sach, true, `bắt oan: ${x}`);
  }
});

test('Chỉ vai cố vấn được vào Cây Tiền; ba vai còn lại bị chặn', () => {
  const vai = [...VAI_INDEX.keys()];
  assert.ok(vai.length >= 4, 'phải có đủ bốn vai để thử');
  for (const v of vai) {
    const g = tuong.choVao(v);
    assert.equal(g.ok, v === 'co-van', `vai ${v} vào được: ${g.ok}`);
    // Lời từ chối KHÔNG được nhắc tới Cây Tiền: nói ra là đã để lộ rằng nó tồn tại.
    if (!g.ok) assert.equal(tuong.soiRoRi(g.reason).sach, true, 'lời từ chối tự làm lộ');
  }
});

test('Chỉ tài khoản ADMIN được vào; giáo viên cũng không', () => {
  for (const r of ['ADMIN', 'TEACHER', 'PARENT', 'LEARNER', '', null, 'admin']) {
    const mong = String(r || '').toUpperCase() === 'ADMIN';
    assert.equal(tuong.choVaoTheoTaiKhoan(r).ok, mong, `vai tài khoản ${r}`);
  }
});

test('Không phiên đăng nhập thì không vào được, kể cả gọi thẳng', () => {
  const N = { accounts: { session: () => null } };
  assert.equal(tuong.choVaoYeuCau(N, { headers: {} }).ok, false);
  assert.equal(tuong.choVaoYeuCau(N, { headers: { authorization: 'Bearer gia-mao' } }).ok, false);
  assert.equal(tuong.choVaoYeuCau(null, { headers: {} }).ok, false);
});

test('Bảng từ cấm phủ HẾT tên nhóm — thêm nhóm mà quên thêm từ cấm là trượt', () => {
  for (const n of Object.values(PL.NHOM)) {
    assert.equal(tuong.soiRoRi(n.ma).sach, false, `mã nhóm ${n.ma} chưa có trong bảng từ cấm`);
    assert.equal(tuong.soiRoRi(n.ten).sach, false, `tên nhóm "${n.ten}" chưa có trong bảng từ cấm`);
  }
});

// ═══ MẶT KHÁCH HÀNG SẠCH ═══════════════════════════════════════════════════

test('Cây giá trị không chứa một chữ nào của Cây Tiền', () => {
  const r = tuong.soiRoRi(cgt.cayGiaTri());
  assert.equal(r.sach, true, JSON.stringify(r.roRi));
});

test('Trang Cây giá trị dựng ra HTML sạch, ở cả hai trạng thái có và chưa có dữ liệu', () => {
  const dayDu = cgt.tangHienTai({
    tienDoTruc: {}, mastery: { formsTouched: 10, formsMastered: 7 },
    metrics: { items: 40, sessions: 10, skipRate: 0.05, accuracy: 0.8, medianSpeedRatio: 0.9, hintRate: 0.1, peekRate: 0.05, avgThinkingSteps: 3.4 },
  });
  for (const dangO of [cgt.tangHienTai({}), dayDu]) {
    const html = trang.trangCayGiaTri(cgt.cayGiaTri(), dangO, NGUOI, 'n0nc3');
    const r = tuong.soiRoRi(html);
    assert.equal(r.sach, true, JSON.stringify(r.roRi));
    assert.match(html, /Cây giá trị/);
    assert.match(html, /noindex/, 'khu riêng phải chặn máy tìm kiếm');
    assert.ok(!/style="/.test(html), 'không được có style nội dòng');
  }
});

test('Cây giá trị không hứa điểm số — không có con số thang điểm nào', () => {
  const chu = JSON.stringify(cgt.cayGiaTri());
  for (const hua of ['1300', '1200', '1600', 'band 7', '9.0', 'cam kết đạt', 'bảo đảm đỗ']) {
    assert.equal(chu.includes(hua), false, `Cây giá trị đang hứa "${hua}"`);
  }
});

test('Chưa đủ dữ liệu thì KHÔNG đoán tầng lên cho đẹp', () => {
  const r = cgt.tangHienTai({});
  assert.equal(r.duCanCu, false);
  assert.equal(r.tang, null);
  assert.match(r.ghiChu, /Chưa đủ căn cứ/);
});

test('Năm tầng xếp đúng thứ tự và tầng nào cũng có dấu hiệu quan sát được ở nhà', () => {
  const c = cgt.cayGiaTri();
  assert.equal(c.soTang, 5);
  c.tang.forEach((t, i) => {
    assert.equal(t.thu, i + 1, 'tầng phải liên tục từ 1 đến 5');
    assert.ok(t.ten && t.ten.length >= 4, `tầng ${t.thu} thiếu tên`);
    for (const truong of ['cauHoi', 'duoc', 'dauHieu', 'heThongLam']) {
      assert.ok(t[truong] && t[truong].length > 20, `tầng ${t.thu} thiếu ${truong}`);
    }
    assert.ok(t.veTinh.length > 0, `tầng ${t.thu} chưa gắn năng lực nào`);
  });
});

// ═══ SÀNG LỌC ══════════════════════════════════════════════════════════════

test('Gia đình mới vào học KHÔNG bị chấm là giá trị thấp — xếp vào Hạt mới', () => {
  const t = hoc(new Telemetry(), 'MOI', { buoi: 2, bai: 6, dung: 2, batDauTruoc: 3 });
  const r = PL.xepNhom(t, 'MOI');
  assert.equal(r.duCanCu, false);
  assert.equal(r.nhom, 'HAT_MOI');
  assert.equal(r.giaTri, null, 'chưa đủ căn cứ thì không được trả điểm giá trị');
  assert.match(r.viLy, /KHÔNG phải nhóm giá trị thấp/);
  assert.match(PL.NHOM.HAT_MOI.viec, /không cắt bớt gì/);
});

test('Sàng lọc nói rõ THIẾU GÌ, không chỉ nói là thiếu', () => {
  const t = hoc(new Telemetry(), 'IT', { buoi: 2, bai: 6, dung: 4, batDauTruoc: 3 });
  const d = PL.dauVet(t, 'IT');
  const s = PL.duDeCham(d);
  assert.equal(s.du, false);
  assert.equal(s.thieu.length, 3, 'thiếu cả ba điều kiện thì phải liệt kê cả ba');
  for (const x of s.thieu) assert.match(x, /\d+\/\d+/, 'phải nói bằng số, không bằng tính từ');
});

// ═══ PHÂN LOẠI ═════════════════════════════════════════════════════════════

test('Đi đều và tiến thật → Cây tiền', () => {
  const t = hoc(new Telemetry(), 'A', { buoi: 26, bai: 120, dung: 100, batDauTruoc: 60, phutMoiBuoi: 35 });
  const r = PL.xepNhom(t, 'A', { mastery: masGia(8, 10) });
  assert.equal(r.duCanCu, true);
  assert.equal(r.nhom, 'CAY_TIEN', r.viLy);
});

test('Giá trị cao nhưng đang im lặng → Cây cần cứu, và đây là ưu tiên SỐ MỘT', () => {
  const t = hoc(new Telemetry(), 'B', { buoi: 26, bai: 120, dung: 100, batDauTruoc: 60, imNgay: 20, phutMoiBuoi: 35 });
  const r = PL.xepNhom(t, 'B', { mastery: masGia(8, 10) });
  assert.equal(r.nhom, 'CAY_CAN_CUU', r.viLy);
  assert.match(r.viLy, /im lặng/);
  // Ưu tiên cao hơn cả nhóm Cây tiền: một giờ dành cho gia đình sắp rời đi
  // giữ được nhiều hơn một giờ dành cho gia đình vốn đã đi đều.
  assert.ok(PL.NHOM.CAY_CAN_CUU.uuTien < PL.NHOM.CAY_TIEN.uuTien);
  assert.match(PL.NHOM.CAY_CAN_CUU.nhipCham, /48 giờ/);
});

test('Nhịp thưa và chững lại → Cây chớm héo', () => {
  const t = hoc(new Telemetry(), 'C', { buoi: 6, bai: 40, dung: 16, batDauTruoc: 60, imNgay: 18, bo: 12, phutMoiBuoi: 8 });
  const r = PL.xepNhom(t, 'C', { mastery: masGia(1, 10) });
  assert.equal(r.nhom, 'CAY_CHOM_HEO', r.viLy);
});

test('Nhóm nói về QUAN HỆ, không nói học viên giỏi hay kém', () => {
  // Học viên yếu nhưng đi đều, so với học viên giỏi đã bỏ ba tuần.
  const t = new Telemetry();
  hoc(t, 'YEU_DEU', { buoi: 26, bai: 120, dung: 66, batDauTruoc: 60, phutMoiBuoi: 35 });
  hoc(t, 'GIOI_BO', { buoi: 8, bai: 120, dung: 114, batDauTruoc: 60, imNgay: 22, phutMoiBuoi: 8 });
  const a = PL.xepNhom(t, 'YEU_DEU', { mastery: masGia(5, 10) });
  const b = PL.xepNhom(t, 'GIOI_BO', { mastery: masGia(9, 10) });
  assert.equal(PL.NHOM[a.nhom].uuTien >= 1, true);
  assert.notEqual(a.nhom, b.nhom, 'hai hoàn cảnh khác hẳn nhau phải ra hai nhóm khác nhau');
  assert.ok(b.ruiRo.diem > a.ruiRo.diem, 'người đã bỏ ba tuần phải có nguy cơ rời bỏ cao hơn');
});

test('Lý do xếp nhóm viết bằng chữ đọc được, và nói rõ đây chỉ là quan sát', () => {
  const t = hoc(new Telemetry(), 'D', { buoi: 26, bai: 120, dung: 100, batDauTruoc: 60 });
  const r = PL.xepNhom(t, 'D', { mastery: masGia(8, 10) });
  assert.match(r.viLy, /không phải dự đoán chắc chắn/);
  assert.match(r.viLy, /\d+\/100/);
});

// ═══ CẢ VƯỜN VÀ TỐI ƯU ═════════════════════════════════════════════════════

test('Biên bản vườn nêu việc gấp nhất trước, bằng số', () => {
  const t = new Telemetry();
  hoc(t, 'CUU1', { buoi: 26, bai: 120, dung: 100, batDauTruoc: 60, imNgay: 20 });
  hoc(t, 'CUU2', { buoi: 26, bai: 120, dung: 100, batDauTruoc: 60, imNgay: 20 });
  hoc(t, 'TOT', { buoi: 26, bai: 120, dung: 100, batDauTruoc: 60 });
  const v = PL.soiVuon({ telemetry: t, mastery: masGia(8, 10) });
  assert.equal(v.soGiaDinh, 3);
  assert.match(v.viecGapNhat, /2 gia đình/);
  assert.match(v.viecGapNhat, /48 giờ/);
  assert.equal(v.theoNhom[0].ma, 'CAY_CAN_CUU', 'nhóm ưu tiên cao nhất phải đứng đầu');
  assert.match(v.ghiChu, /không phải doanh thu/);
});

test('Không có gia đình nào thì nói thẳng, không trả bảng rỗng nhìn như đã xong', () => {
  const v = PL.soiVuon({ telemetry: new Telemetry() });
  assert.equal(v.soGiaDinh, 0);
  assert.match(v.viecGapNhat, /Chưa có gia đình nào/);
});

test('Chưa có sổ giờ chăm sóc thì KHÔNG ước lượng hộ', () => {
  const v = PL.soiVuon({ telemetry: new Telemetry() });
  const r = PL.toiUuDichVu(v, null);
  assert.equal(r.duCanCu, false);
  assert.equal(r.hang.length, 0);
  assert.match(r.ghiChu, /ước lượng hộ ở đây là bịa số/);
});

test('Có sổ giờ thì chỉ ra chỗ dồn giờ sai', () => {
  const t = new Telemetry();
  hoc(t, 'CUU', { buoi: 26, bai: 120, dung: 100, batDauTruoc: 60, imNgay: 20 });
  for (let i = 0; i < 4; i++) hoc(t, `TOT${i}`, { buoi: 26, bai: 120, dung: 100, batDauTruoc: 60 });
  const v = PL.soiVuon({ telemetry: t, mastery: masGia(8, 10) });
  const r = PL.toiUuDichVu(v, { CAY_TIEN: 90, CAY_CAN_CUU: 2 });
  assert.equal(r.duCanCu, true);
  assert.match(r.ketLuan, /thiếu giờ|dồn giờ/);
});

// ═══ KHUNG TÁM NĂNG LỰC ════════════════════════════════════════════════════

test('Khung tám năng lực nói thẳng năng lực nào CHƯA có dữ liệu', () => {
  const k = khung.khung();
  assert.equal(k.soNangLuc, 8);
  assert.ok(k.soThieuDuLieu > 0, 'một khung mà mọi ô đều xanh là khung chưa ai dùng thật');
  for (const n of k.nangLuc) {
    assert.ok(n.hoi && n.hoiGita, `năng lực ${n.ma} thiếu câu hỏi`);
    if (!n.coDuLieu) assert.ok(n.thieu && n.thieu.length > 20, `năng lực ${n.ma} nói thiếu mà không nói thiếu gì`);
    else assert.ok(n.nguon.length > 0, `năng lực ${n.ma} bảo có dữ liệu mà không chỉ ra nguồn`);
  }
  assert.match(k.ketLuan, /chưa có dữ liệu/);
});

test('Năng lực đo sinh lợi phải nói rõ hệ thống CHƯA có dữ liệu tiền', () => {
  const n = khung.NANG_LUC_INDEX.get('SINH_LOI');
  assert.match(n.thieu, /thanh toán/);
  assert.match(n.thieu, /không đo tiền/);
});
