'use strict';
/**
 * NGỮ LIỆU TIẾNG ANH VIẾT TAY — ĐỌC HIỂU, VIẾT LUẬN, NÓI THEO CHỦ ĐỀ
 *
 * Bốn dạng này không ghép được bằng máy, nên văn bản của chúng viết tay. Thứ
 * máy phải giữ là CHẤT LƯỢNG ĐỀ: mỗi câu hỏi chỉ được có ĐÚNG MỘT phương án
 * hợp lệ. Các mục dưới đây kiểm cả hai phía — ngữ liệu thật phải qua được, và
 * ngữ liệu hỏng phải bị chặn. Phía thứ hai mới là phía chứng minh phép đo có
 * răng; một bộ kiểm luôn trả "đạt" thì không kiểm gì cả.
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const C = require('../src/lang/en-corpus');
const { kiemTiengAnh } = require('../src/lang/en-verifier');
const { BP_DOC_VIET_NOI } = require('../src/content/blueprints/tieng-anh');
const MathVerifier = require('../src/math/verifier');
const { goNguonNgoaiNgu, LanguageScientist } = require('../src/lang/scientist');

const KHO = [
  ['y chinh', C.DOAN_Y_CHINH, (u) => ({ doan: u.doan })],
  ['suy luan', C.DOAN_SUY_LUAN, (u) => ({ doan: u.doan })],
  ['de luan', C.DE_LUAN, (u) => ({ de: u.de })],
  ['the noi', C.THE_NOI, (u) => ({ the: u.the })],
];
const ck = (kieu, u, rieng) => ({ kieu, dapAnDung: u.dung, nhieu: u.nhieu, ...rieng(u) });

// ═══ PHÍA THỨ NHẤT: NGỮ LIỆU THẬT PHẢI QUA ═════════════════════════════════

for (const [kieu, kho, rieng] of KHO) {
  test(`Mọi đơn vị ngữ liệu "${kieu}" đều qua phép đo chất lượng đề`, () => {
    assert.ok(kho.length >= 14, `kho "${kieu}" mới có ${kho.length} đơn vị`);
    for (const u of kho) {
      const r = kiemTiengAnh(ck(kieu, u, rieng), u.dung);
      assert.equal(r.dat, true, `${u.ma}: ${r.chiTiet}`);
    }
  });
}

test('Mã đơn vị ngữ liệu không trùng nhau', () => {
  const ma = KHO.flatMap(([, kho]) => kho.map((u) => u.ma));
  assert.equal(new Set(ma).size, ma.length, 'có mã đơn vị bị dùng hai lần');
});

test('Mọi bài dựng từ bốn bản thiết kế mới đều được máy chứng minh', () => {
  const v = new MathVerifier();
  let n = 0;
  for (const bp of BP_DOC_VIET_NOI) {
    for (const p of bp.space()) {
      const item = bp.render(p);
      const r = v.verifyItem(item);
      assert.equal(r.verified, true, `${bp.id} ${JSON.stringify(p)}: ${r.reason}`);
      n++;
    }
  }
  assert.equal(n, 64, `mới dựng được ${n} bài`);
});

test('Đáp án đúng rải đều bốn vị trí, không nằm lì ở A', () => {
  for (const bp of BP_DOC_VIET_NOI) {
    const viTri = new Set();
    for (const p of bp.space()) {
      const item = bp.render(p);
      const dong = item.stem.split('\n').find((d) => d.trim().startsWith(`A. `));
      viTri.add(item.stem.includes(`A. ${item.answer}`) ? 'A'
        : item.stem.includes(`B. ${item.answer}`) ? 'B'
          : item.stem.includes(`C. ${item.answer}`) ? 'C' : 'D');
      assert.ok(dong, `${bp.id} thiếu phương án A`);
    }
    assert.equal(viTri.size, 4, `${bp.id} chỉ đặt đáp án ở ${[...viTri].join('')}`);
  }
});

// ═══ PHÍA THỨ HAI: NGỮ LIỆU HỎNG PHẢI BỊ CHẶN ══════════════════════════════

test('Ý chính nằm gọn trong một câu thì bị đánh trượt — đó là chi tiết', () => {
  const u = C.DOAN_Y_CHINH[0];
  const motCau = u.nhieu.find((n) => n.loai === 'chi-tiet').y;
  const r = kiemTiengAnh({ kieu: 'y chinh', doan: u.doan, dapAnDung: motCau, nhieu: u.nhieu }, motCau);
  assert.equal(r.dat, false);
  assert.match(r.chiTiet, /chi tiết của câu|trải trên/);
});

test('Ý chính nói rộng hơn bài thì bị đánh trượt', () => {
  const u = C.DOAN_Y_CHINH[1];
  const rong = `Every ${u.dung[0].toLowerCase()}${u.dung.slice(1)}`;
  const r = kiemTiengAnh({ kieu: 'y chinh', doan: u.doan, dapAnDung: rong, nhieu: u.nhieu }, rong);
  assert.equal(r.dat, false);
  assert.match(r.chiTiet, /quá phạm vi/);
});

test('Câu suy luận mà bài đã nêu thẳng thì bị đánh trượt', () => {
  const u = C.DOAN_SUY_LUAN[0];
  const daNeu = u.nhieu.find((n) => n.loai === 'da-neu').y;
  const r = kiemTiengAnh({ kieu: 'suy luan', doan: u.doan, dapAnDung: daNeu, nhieu: u.nhieu }, daNeu);
  assert.equal(r.dat, false);
  assert.match(r.chiTiet, /nêu thẳng|bám bài/);
});

test('Đề luận khớp hai dạng câu hỏi cùng lúc thì bị chặn — đề mập mờ', () => {
  const u = C.DE_LUAN[0];
  const lai = `${u.de} Discuss both views and give your own opinion.`;
  const r = kiemTiengAnh({ kieu: 'de luan', de: lai, dapAnDung: u.dung, nhieu: u.nhieu }, u.dung);
  assert.equal(r.dat, false);
  assert.match(r.chiTiet, /hai dạng|2 dạng/);
});

test('Câu chủ đề phục vụ dạng đề khác thì bị đánh trượt', () => {
  const u = C.DE_LUAN[0];
  const lac = C.DE_LUAN.find((x) => x.dang !== u.dang).dung;
  const r = kiemTiengAnh({ kieu: 'de luan', de: u.de, dapAnDung: lac, nhieu: u.nhieu }, lac);
  assert.equal(r.dat, false);
  assert.match(r.chiTiet, /thiếu dấu hiệu bắt buộc/);
});

test('Thẻ nói thiếu một gạch đầu dòng thì bị chặn ngay', () => {
  const u = C.THE_NOI[0];
  const thieu = u.the.split('\n').slice(0, 4).join('\n');
  const r = kiemTiengAnh({ kieu: 'the noi', the: thieu, dapAnDung: u.dung, nhieu: u.nhieu }, u.dung);
  assert.equal(r.dat, false);
  assert.match(r.chiTiet, /3 gạch đầu dòng/);
});

test('Dàn ý nói bỏ sót một gạch thì không được nhận là đáp án', () => {
  const u = C.THE_NOI[0];
  const sot = u.nhieu.find((n) => n.loai === 'bo-sot').y;
  const r = kiemTiengAnh({ kieu: 'the noi', the: u.the, dapAnDung: sot, nhieu: u.nhieu }, sot);
  assert.equal(r.dat, false);
  assert.match(r.chiTiet, /chỉ chạm \d\/4/);
});

// ═══ BỘ SOÁT TIẾNG VIỆT KHÔNG ĐƯỢC CHẤM NGỮ LIỆU TIẾNG ANH ═════════════════

test('Ngữ liệu tiếng Anh bị gỡ khỏi đề trước khi chấm tiếng Việt', () => {
  const item = BP_DOC_VIET_NOI[0].render({ i: 0 });
  const conLai = goNguonNgoaiNgu(item);
  assert.ok(conLai.includes('Đọc đoạn văn sau'), 'phải giữ lại lời dẫn tiếng Việt');
  assert.ok(!conLai.includes(C.DOAN_Y_CHINH[0].doan.slice(0, 40)), 'phải gỡ đoạn văn tiếng Anh');
  assert.ok(!conLai.includes(C.DOAN_Y_CHINH[0].dung.slice(0, 40)), 'phải gỡ cả phương án tiếng Anh');
});

test('Gỡ ngữ liệu KHÔNG được nối hai câu tiếng Việt thành một câu dài', () => {
  // Bài ngữ pháp để câu nguồn trong ngoặc kép; chỗ đó đã có bộ bỏ ngoại ngữ lo
  // và nó thay cả cụm bằng một ký hiệu MANG THEO dấu chấm. Cắt trắng ở đây sẽ
  // nối hai câu lại và bịa ra lỗi "câu quá dài".
  const item = {
    stem: 'Cho câu ở thì hiện tại đơn: "He finishes the report." Viết lại câu đó.',
    check: { english: { kieu: 'thi', nguon: 'He finishes the report.' } },
  };
  assert.ok(goNguonNgoaiNgu(item).includes('"He finishes the report."'));
});

test('Sau khi gỡ ngữ liệu, đề bốn dạng mới đạt chuẩn tiếng Việt', () => {
  const L = new LanguageScientist({});
  for (const bp of BP_DOC_VIET_NOI) {
    for (const p of bp.space()) {
      const item = bp.render(p);
      const r = L.soat(goNguonNgoaiNgu(item), { lop: 9 });
      const chan = [...r.cap1ChinhTa.loi, ...r.cap2VanPhong.loi.filter((l) => l.muc === 'LOI')];
      assert.equal(chan.length, 0, `${bp.id}: ${chan.map((l) => l.moTa).join('; ')}`);
    }
  }
});
