# GITAmath Nexus V20 — Cài đặt trên Windows 64-bit

## Tự dựng lấy tệp cài trên máy Windows của mình

Nếu chưa có sẵn hai tệp `.exe`, dựng lấy trên chính máy Windows — **một lệnh,
không cần wine, không cần máy Linux**:

```cmd
:: cần Node.js 22 trở lên: https://nodejs.org
cd <thư mục chứa mã nguồn>\nexus
npm --prefix desktop install
npm run dist:win
```

Xong, hai tệp nằm ở `desktop\dist\`. Bộ dựng tự soi máy trước khi chạy và tự
kiểm tệp sau khi dựng: đúng định dạng Windows, đủ nặng, gói có đủ `src`, `ui`,
và đủ mười bốn mô-đun của ban quan hệ gia đình.

Lần đầu `npm install` tải khoảng 250 MB và mất vài phút. Lần dựng sau thì
nhanh.

---

## Hai tệp, chọn một

| Tệp | Dùng khi | Cách chạy |
|---|---|---|
| `GITAmath-Nexus-V20-20.0.0-x64.exe` | Máy dùng lâu dài, muốn có biểu tượng ngoài màn hình | Bấm đúp → cài → mở từ Start Menu |
| `GITAmath-Nexus-V20-20.0.0-portable.exe` | Thử nhanh, hoặc máy không cho cài phần mềm | Bấm đúp là chạy, không cài gì |

**Không cần cài Node.js, không cần Docker, không cần mạng.** Mọi thứ nằm trong
một tệp.

---

## Cài bản có trình cài đặt

1. Bấm đúp `GITAmath-Nexus-V20-20.0.0-x64.exe`
2. **Windows sẽ hiện màn hình xanh "Windows protected your PC"** — xem mục
   *Vì sao Windows cảnh báo* bên dưới. Bấm **More info** → **Run anyway**.
3. Chọn thư mục cài. Mặc định là
   `C:\Users\<tên bạn>\AppData\Local\Programs\GITAmath Nexus V20`
   — **nên để nguyên**. Cài vào `C:\Program Files` cũng chạy được, nhưng cần
   quyền quản trị viên.
4. Bấm **Install**. Xong sẽ có biểu tượng ngoài màn hình và trong Start Menu.

## Lần đầu mở

Ứng dụng hiện **màn hình chờ** với dòng chữ *"Đang dựng 500 trợ lý AI và nạp
kho học liệu…"*.

**Lần đầu mất khoảng 15 giây.** Đó là lúc hệ thống dựng 500 trợ lý AI, nạp 571
bài học liệu, mở tám bộ sưu tập dữ liệu và bật lịch việc nền. **Xin đừng tắt
và đừng bấm đúp lần nữa** — ứng dụng chỉ cho một bản chạy, bấm thêm không mở
thêm cửa sổ nào.

Xong thì cửa sổ chính hiện ra ở trang **Chọn nơi bạn cần vào**.

---

## Dữ liệu của bạn nằm ở đâu

```
C:\Users\<tên bạn>\AppData\Roaming\GITAmath Nexus V20\
  ├─ du-lieu\db\          kho dữ liệu: gia đình, học phí, học viên, học liệu
  ├─ du-lieu\bai-giang\   video bài giảng đã dựng
  ├─ snapshots\           ảnh chụp lui về, tự chụp mỗi 15 phút
  └─ nexus-desktop.log    nhật ký ứng dụng
```

**Dữ liệu KHÔNG nằm trong thư mục cài đặt.** Gỡ ứng dụng ra cài lại thì dữ
liệu vẫn còn nguyên. Muốn sao lưu thì chép cả thư mục trên.

Mở nhanh: menu **Hệ thống → Mở thư mục dữ liệu**.

---

## Mục quản trị quan hệ gia đình

Menu **Quan hệ gia đình** có bốn màn hình:

- **Bàn điều khiển** — sáu con số của hôm nay, việc cần làm ngay
- **Ba mươi trợ lý AI chuyên môn** — ai đang được làm gì, tới mức nào
- **Hàng chờ duyệt** — việc đang chờ người thật gật đầu
- **Bảng điểm trợ lý** — chấm trên chỉ số có nguồn đo

Bốn màn hình này **đòi tài khoản vai quản trị viên**. Lần đầu chạy, hệ thống
chưa có tài khoản nào — tạo tài khoản quản trị đầu tiên ở
**Cổng vào → Trung tâm chỉ huy**.

---

## Vì sao Windows cảnh báo "Windows protected your PC"

Vì tệp cài đặt **chưa được ký số**. Chữ ký số là một chứng thư mua từ nhà
cung cấp chứng thư (khoảng 200–400 đô la mỗi năm), gắn tên pháp nhân vào tệp
cài để Windows biết ai làm ra nó.

Đây là cảnh báo **thật và đúng**: Windows đang nói nó không biết ai làm ra tệp
này. Nói cách khác, cảnh báo ấy không phải lỗi cần vá bằng mẹo — nó biến mất
khi và chỉ khi có chữ ký số thật.

**Cách kiểm tra tệp đúng là tệp của mình:** đối chiếu mã băm SHA-256 in kèm
tệp. Nếu mã khớp thì tệp không bị ai đổi trên đường truyền.

```powershell
Get-FileHash .\GITAmath-Nexus-V20-20.0.0-x64.exe -Algorithm SHA256
```

Mã đúng của bản này:

```
4b355e1ff9216a088806bf5cb0f027392597ba0ec6d73e1c77c38fd7b3a7af3f  GITAmath-Nexus-V20-20.0.0-x64.exe
0a4ecab673074d128017bfdf5f793116c99afc2f1a75e1605ea828d09f4fa64a  GITAmath-Nexus-V20-20.0.0-portable.exe
```

---

## Khi có trục trặc

### Bấm đúp mà không thấy gì trong hơn một phút

Mở `%APPDATA%\GITAmath Nexus V20\nexus-desktop.log` và xem dòng cuối.

Nếu thấy dòng *"Lần chạy trước chết khi dựng cửa sổ — đã tắt tăng tốc phần
cứng"* thì ứng dụng **đã tự xử lý**: nó phát hiện card màn hình có vấn đề và
chuyển sang vẽ bằng phần mềm ở lần chạy này. Chậm hơn một chút nhưng chạy.

Muốn ép tắt tăng tốc phần cứng ngay từ đầu, mở Command Prompt:

```cmd
set GITA_TAT_TANG_TOC=1
"%LOCALAPPDATA%\Programs\GITAmath Nexus V20\GITAmath Nexus V20.exe"
```

### Báo cổng 9999 đã bị chiếm

Một phần mềm khác đang dùng cổng ấy. Đổi cổng:

```cmd
set PORT=9998
"%LOCALAPPDATA%\Programs\GITAmath Nexus V20\GITAmath Nexus V20.exe"
```

### Phần mềm diệt virus chặn

Một số phần mềm diệt virus nghi ngờ tệp cài chưa ký số. Thêm ngoại lệ cho thư
mục cài đặt, hoặc dùng bản chạy thẳng.

---

## Gỡ cài đặt

**Settings → Apps → GITAmath Nexus V20 → Uninstall**

Gỡ xong **dữ liệu vẫn còn** trong `%APPDATA%\GITAmath Nexus V20\`. Muốn xoá
hẳn thì xoá tay thư mục ấy — nhưng nhớ rằng trong đó có hồ sơ học tập của các
em và dữ liệu học phí của các gia đình.

---

## Yêu cầu máy

| Mục | Tối thiểu | Nên có |
|---|---|---|
| Hệ điều hành | Windows 10 64-bit | Windows 11 64-bit |
| Bộ nhớ | 4 GB | 8 GB |
| Đĩa trống | 500 MB | 2 GB |
| Mạng | **không cần** | cần nếu dùng mô hình ngôn ngữ thật |

Không có khoá mô hình ngôn ngữ thì hệ thống chạy bằng bộ giả lập **tất định**
có sẵn — mọi tính năng vẫn hoạt động, chỉ có phần sinh văn bản là câu mẫu chứ
không phải câu do mô hình viết.
