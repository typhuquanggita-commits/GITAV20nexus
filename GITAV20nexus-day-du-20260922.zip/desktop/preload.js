'use strict';
/**
 * Cầu nối an toàn giữa tiến trình chính (Electron) và giao diện web.
 * Giao diện KHÔNG được chạm vào Node. Chỉ đúng những gì liệt kê dưới đây
 * mới đi qua contextBridge — mọi thứ khác bị chặn bởi contextIsolation.
 */

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('nexusDesktop', {
  isDesktop: true,
  platform: process.platform,
  arch: process.arch,
  versions: {
    electron: process.versions.electron,
    chrome: process.versions.chrome,
    node: process.versions.node,
  },
  /** Cổng nội bộ Nexus đang nghe — giao diện dùng để gọi API. */
  port: () => ipcRenderer.invoke('nexus:port'),
  /** Thông tin bản cài đặt (phiên bản app, thư mục dữ liệu). */
  info: () => ipcRenderer.invoke('nexus:info'),
  /** Mở thư mục dữ liệu / nhật ký bằng trình quản lý tệp của Windows. */
  openDataDir: () => ipcRenderer.invoke('nexus:open-data-dir'),
  openLog: () => ipcRenderer.invoke('nexus:open-log'),
});
