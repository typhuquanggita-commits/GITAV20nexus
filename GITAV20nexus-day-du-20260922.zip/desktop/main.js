'use strict';
/**
 * GITAmath Nexus V20 — Ứng dụng máy tính Windows 64-bit.
 * Khởi chạy toàn bộ Nexus ngay trong tiến trình Electron: không cần cài Node riêng,
 * không cần mở terminal, không cần dịch vụ ngoài. Bật lên là chạy.
 */

const { app, BrowserWindow, Menu, dialog, shell, ipcMain, Tray, nativeImage } = require('electron');
const path = require('node:path');
const fs = require('node:fs');

// ── MỌI THỨ GHI XUỐNG ĐĨA PHẢI NẰM TRONG HỒ SƠ NGƯỜI DÙNG ──────────────────
//
// Bản đầu chỉ đặt SNAPSHOT_DIR và bỏ sót hai chỗ ghi còn lại. Hai chỗ ấy rơi
// về mặc định, và mặc định trên Windows hỏng theo hai cách khác nhau:
//
//   · Kho dữ liệu rơi về <thư mục cài đặt>\resources\data\db. Người dùng
//     chọn cài vào C:\Program Files — mà trình cài đặt này CHO PHÉP chọn —
//     thì thư mục ấy chỉ đọc với tài khoản thường: ứng dụng bật lên rồi không
//     lưu được một bản ghi nào. Cài vào chỗ mặc định thì ghi được, nhưng gỡ
//     ra cài lại là mất sạch dữ liệu của gia đình, vì dữ liệu nằm lẫn trong
//     thư mục chương trình.
//
//   · Thư mục bài giảng rơi về process.cwd(). Bấm đúp một biểu tượng trên
//     Windows thì thư mục làm việc KHÔNG phải thư mục chứa ứng dụng — tuỳ chỗ
//     bấm mà nó là C:\Windows\System32 hay một chỗ bất kỳ. Ghi vào đó thì
//     hoặc bị chặn, hoặc rải tệp ra một nơi không ai tìm lại được.
//
// Nên cả ba đường ghi đều trỏ về userData, và thư mục được tạo sẵn ở đây chứ
// không đợi tầng dưới tự xoay xở.
const userData = app.getPath('userData');
const thuMucDuLieu = path.join(userData, 'du-lieu');
for (const d of [thuMucDuLieu, path.join(thuMucDuLieu, 'db'), path.join(userData, 'snapshots'), path.join(thuMucDuLieu, 'bai-giang')]) {
  try { fs.mkdirSync(d, { recursive: true }); } catch { /* báo lỗi ở bước dựng Nexus */ }
}
process.env.DB_DIR = path.join(thuMucDuLieu, 'db');
process.env.SNAPSHOT_DIR = path.join(userData, 'snapshots');
process.env.LESSON_OUT_DIR = path.join(thuMucDuLieu, 'bai-giang');
process.env.PORT = process.env.PORT || '9999';
process.env.HOST = '127.0.0.1';          // chỉ nghe trên máy, không mở ra mạng
process.env.LOG_LEVEL = process.env.LOG_LEVEL || 'info';

const ROOT = path.join(__dirname, '..');

// ── TỰ TẮT TĂNG TỐC PHẦN CỨNG KHI LẦN TRƯỚC CHẾT VÌ CARD MÀN HÌNH ──────────
//
// Electron dựng một tiến trình riêng cho card màn hình. Tiến trình ấy không
// lên được thì Electron GIẾT LUÔN cả ứng dụng, với đúng một dòng trong nhật
// ký: "GPU process isn't usable. Goodbye." Người dùng chỉ thấy bấm đúp rồi
// không có gì.
//
// Chuyện này có thật trên máy tính trường học: driver card màn hình cũ, máy
// ảo không có card, máy văn phòng dùng màn hình từ xa. Bắt được ở đây lúc
// chạy thử trong môi trường không có card, và đó cũng chính là cảnh máy
// người dùng gặp.
//
// Cách vá: ghi một dấu TRƯỚC khi dựng cửa sổ, xoá dấu khi cửa sổ đã hiện.
// Lần sau thấy dấu còn nguyên thì biết lần trước chết giữa chừng, nên tắt
// tăng tốc phần cứng. Vẽ bằng phần mềm chậm hơn một chút, nhưng chạy.
const dauVeHong = path.join(app.getPath('userData'), 've-bang-card-dang-thu.dau');
let daTatTangToc = false;
try {
  if (fs.existsSync(dauVeHong)) {
    app.disableHardwareAcceleration();
    daTatTangToc = true;
  }
} catch { /* không đọc được thì cứ chạy như thường */ }

/** Cho phép ép tắt bằng biến môi trường, dành cho lúc gỡ lỗi tại chỗ. */
if (/^(1|true|yes)$/i.test(process.env.GITA_TAT_TANG_TOC || '')) {
  if (!daTatTangToc) { app.disableHardwareAcceleration(); daTatTangToc = true; }
}
let win = null;
let manHinhCho = null;
let tray = null;
let server = null;
let N = null;
let bootError = null;

function log(...a) {
  const line = `[${new Date().toISOString()}] ${a.join(' ')}\n`;
  process.stdout.write(line);
  try { fs.appendFileSync(path.join(userData, 'nexus-desktop.log'), line); } catch { /* không ghi được thì thôi */ }
}

async function startNexus() {
  const { boot, createServer } = require(path.join(ROOT, 'src', 'index.js'));
  N = await boot({ quiet: false });
  server = createServer(N);
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(Number(process.env.PORT), process.env.HOST, resolve);
  });
  const port = server.address().port;
  log(`Nexus V20 đang chạy tại http://127.0.0.1:${port}`);

  // src/index.js đã bật bộ hẹn giờ chụp ảnh và đã chụp một ảnh lúc khởi động.
  // Gọi start() lần nữa ở đây là vô hại (hàm tự bỏ qua khi bộ hẹn giờ đang
  // chạy), nhưng chụp thêm một ảnh nữa thì thừa — hai ảnh cách nhau vài giây
  // không cho thêm đường lui nào.
  N.snapshots.start();
  log(`Ảnh chụp lui về: ${N.snapshots.snapshots.length} ảnh · thư mục ${process.env.SNAPSHOT_DIR}`);
  log(`Kho dữ liệu: ${process.env.DB_DIR}`);
  if (N.crm) log(`Quan hệ gia đình: ${N.crm.status().troLy.soTroLy} trợ lý AI chuyên môn đã vào việc`);
  return port;
}

function createWindow(port) {
  win = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 680,
    backgroundColor: '#0b1020',
    show: false,
    title: 'GITAmath Nexus V20 — Trung tâm chỉ huy',
    icon: path.join(__dirname, 'build', 'icon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false,
    },
  });

  win.once('ready-to-show', () => {
    win.show();
    // Cửa sổ đã hiện thật: xoá dấu, để lần sau chạy lại với tăng tốc phần cứng.
    try { fs.rmSync(dauVeHong, { force: true }); } catch { /* bỏ qua */ }
  });
  win.loadURL(`http://127.0.0.1:${port}/ui/cong.html`);   // cổng chọn vai

  // Chặn mọi điều hướng ra ngoài máy; link ngoài mở bằng trình duyệt hệ thống.
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => {
    if (!url.startsWith(`http://127.0.0.1:${port}/`)) { e.preventDefault(); shell.openExternal(url); }
  });

  win.on('closed', () => { win = null; });
}

function buildMenu(port) {
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    {
      label: 'Hệ thống',
      submenu: [
        { label: 'Làm mới', accelerator: 'F5', click: () => win?.reload() },
        {
          label: 'Chụp ảnh hệ thống ngay',
          accelerator: 'CmdOrCtrl+S',
          click: async () => {
            const r = await N.snapshots.take({ label: 'manual-menu' });
            dialog.showMessageBox(win, { message: `Đã chụp ${r.version}`, detail: `Thời điểm: ${r.iso}`, type: 'info' });
          },
        },
        {
          label: 'Kiểm tra toàn vẹn ảnh chụp',
          click: () => {
            const v = N.snapshots.verify();
            dialog.showMessageBox(win, {
              type: v.ok ? 'info' : 'error',
              message: v.ok ? 'Chuỗi ảnh chụp nguyên vẹn' : 'PHÁT HIỆN SỬA ĐỔI',
              detail: v.ok ? `${v.snapshots} ảnh · head ${String(v.head).slice(0, 16)}` : `Vỡ tại ${v.brokenAt}`,
            });
          },
        },
        { type: 'separator' },
        { label: 'Mở thư mục dữ liệu', click: () => shell.openPath(userData) },
        { label: 'Mở nhật ký ứng dụng', click: () => shell.openPath(path.join(userData, 'nexus-desktop.log')) },
        { type: 'separator' },
        { role: 'quit', label: 'Thoát' },
      ],
    },
    {
      label: 'Cổng vào',
      submenu: [
        { label: 'Chọn vai', click: () => win?.loadURL(`http://127.0.0.1:${port}/ui/cong.html`) },
        { label: 'Góc học tập', click: () => win?.loadURL(`http://127.0.0.1:${port}/ui/hoc-vien.html`) },
        { label: 'Phòng giáo viên', click: () => win?.loadURL(`http://127.0.0.1:${port}/ui/giao-vien.html`) },
        { label: 'Hỏi trợ lý', click: () => win?.loadURL(`http://127.0.0.1:${port}/ui/tro-chuyen.html`) },
        { label: 'Sơ đồ tư duy ba chiều', click: () => win?.loadURL(`http://127.0.0.1:${port}/ui/so-do-3d.html`) },
        { label: 'Trung tâm chỉ huy', click: () => win?.loadURL(`http://127.0.0.1:${port}/ui/index.html`) },
      ],
    },
    {
      label: 'Quan hệ gia đình',
      submenu: [
        { label: 'Bàn điều khiển', click: () => win?.loadURL(`http://127.0.0.1:${port}/quan-tri/crm`) },
        { label: 'Ba mươi trợ lý AI chuyên môn', click: () => win?.loadURL(`http://127.0.0.1:${port}/quan-tri/crm/tro-ly`) },
        { label: 'Hàng chờ duyệt', click: () => win?.loadURL(`http://127.0.0.1:${port}/quan-tri/crm/duyet`) },
        { label: 'Bảng điểm trợ lý', click: () => win?.loadURL(`http://127.0.0.1:${port}/quan-tri/crm/kpi`) },
        { type: 'separator' },
        {
          label: 'Chạy bản tin sáng ngay',
          click: async () => {
            if (!N?.lichCrm) return;
            const r = await N.lichCrm.chayNgay('ban-tin-sang');
            const t = r.ok ? r.ketQua : null;
            dialog.showMessageBox(win, {
              type: r.ok ? 'info' : 'error',
              message: r.ok ? 'Bản tin sáng' : 'Không chạy được',
              detail: t
                ? t.baConSo.map((x) => `${x.ten}: ${Number(x.so).toLocaleString('vi-VN')}${x.donVi ? ' ' + x.donVi : ''}`).join('\n')
                  + '\n\n' + t.viecCanLam.map((v) => `• ${v.viec}`).join('\n')
                : String(r.loi || ''),
            });
          },
        },
      ],
    },
    {
      label: 'Chỉ huy',
      submenu: [
        { label: 'Tổng quan', click: () => win?.webContents.executeJavaScript('App.setTab("overview")') },
        { label: '500 Agent', click: () => win?.webContents.executeJavaScript('App.setTab("agents")') },
        { label: 'Tổng động viên', click: () => win?.webContents.executeJavaScript('App.setTab("mission")') },
        { label: 'Chương trình', click: () => win?.webContents.executeJavaScript('App.setTab("curriculum")') },
        { label: 'Học viên', click: () => win?.webContents.executeJavaScript('App.setTab("learner")') },
        { label: 'Bảo mật', click: () => win?.webContents.executeJavaScript('App.setTab("security")') },
        { label: 'Khôi phục', click: () => win?.webContents.executeJavaScript('App.setTab("recovery")') },
      ],
    },
    {
      label: 'Xem',
      submenu: [
        { role: 'zoomIn', label: 'Phóng to' },
        { role: 'zoomOut', label: 'Thu nhỏ' },
        { role: 'resetZoom', label: 'Cỡ gốc' },
        { type: 'separator' },
        { role: 'toggleDevTools', label: 'Công cụ nhà phát triển' },
      ],
    },
    {
      label: 'Trợ giúp',
      submenu: [
        { label: 'Mở API trong trình duyệt', click: () => shell.openExternal(`http://127.0.0.1:${port}/`) },
        { label: 'Sổ tay vận hành', click: () => shell.openPath(path.join(ROOT, 'RUNBOOK.md')) },
        {
          label: 'Về GITAmath Nexus',
          click: () => dialog.showMessageBox(win, {
            type: 'info',
            message: 'GITAmath Nexus V20',
            detail: [
              `Phiên bản: ${app.getVersion()}`,
              `Agent: ${N?.agents.length ?? 0} · Tổ: ${N?.squads.length ?? 0}`,
              `Học liệu: ${N?.bank.items.size ?? 0} bài · ${N?.seeder.coverage().filled ?? 0}/${N?.seeder.coverage().slots ?? 0} ô đã phủ`,
              `Người dùng: ${N?.accounts.status().users ?? 0} · Lớp: ${N?.org.status().classes ?? 0} · Học viên: ${N?.org.status().learners ?? 0}`,
              `Hiến pháp: ${N?.constitution.articles.length ?? 0} điều`,
              `Quan hệ gia đình: ${N?.crm ? require(path.join(ROOT, 'src', 'crm', 'so-tro-ly')).DS.length : 0} trợ lý AI chuyên môn`,
              `Dữ liệu CRM: ${N?.crm ? N.crm.kho.giaDinh.count() : 0} gia đình · ${N?.crm ? N.crm.choDuyet.dangCho().length : 0} việc chờ duyệt`,
              `Bảo vệ Super Admin: 15 tầng`,
              `Vẽ giao diện: ${daTatTangToc ? 'bằng phần mềm (đã tắt tăng tốc phần cứng)' : 'bằng card màn hình'}`,
              `Cổng nội bộ: 127.0.0.1:${port}`,
              `Dữ liệu: ${userData}`,
            ].join('\n'),
          }),
        },
      ],
    },
  ]));
}

/**
 * Màn hình chờ. Dựng bằng data URL nên không phụ thuộc vào bất cứ tệp nào —
 * kể cả khi gói cài thiếu tệp, cửa sổ này vẫn hiện được để báo cho người dùng.
 */
function moManHinhCho() {
  const chu = `<!doctype html><html lang="vi"><head><meta charset="utf-8">
<style>
  html,body{margin:0;height:100%;background:#0b1020;color:#e8ecf4;
    font-family:system-ui,'Segoe UI',Roboto,sans-serif;display:flex;
    align-items:center;justify-content:center}
  .o{text-align:center;padding:24px}
  h1{margin:0 0 6px;font-size:19px;font-weight:650;letter-spacing:.01em}
  p{margin:0;font-size:13px;opacity:.7}
  .thanh{margin:22px auto 0;width:260px;height:3px;border-radius:2px;
    background:#1d2740;overflow:hidden}
  .thanh i{display:block;height:100%;width:40%;border-radius:2px;
    background:#4b7bec;animation:ch 1.25s ease-in-out infinite}
  @keyframes ch{0%{transform:translateX(-100%)}100%{transform:translateX(260%)}}
  small{display:block;margin-top:16px;font-size:11px;opacity:.45}
</style></head><body><div class="o">
  <h1>GITAmath Nexus V20</h1>
  <p>Đang dựng 500 trợ lý AI và nạp kho học liệu…</p>
  <div class="thanh"><i></i></div>
  <small>Lần khởi động đầu mất khoảng mười lăm giây. Xin đừng tắt.</small>
</div></body></html>`;
  try {
    manHinhCho = new BrowserWindow({
      width: 460, height: 260, frame: false, resizable: false,
      backgroundColor: '#0b1020', center: true, show: true,
      skipTaskbar: false, title: 'GITAmath Nexus V20',
      webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true },
    });
    manHinhCho.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(chu)}`);
  } catch (e) {
    log('Không mở được màn hình chờ:', e.message);
  }
}

function dongManHinhCho() {
  try { if (manHinhCho && !manHinhCho.isDestroyed()) manHinhCho.close(); } catch { /* bỏ qua */ }
  manHinhCho = null;
}

function createTray(port) {
  try {
    const icoPath = path.join(__dirname, 'build', 'icon.ico');
    const img = fs.existsSync(icoPath) ? nativeImage.createFromPath(icoPath) : nativeImage.createEmpty();
    tray = new Tray(img);
    tray.setToolTip('GITAmath Nexus V20');
    tray.setContextMenu(Menu.buildFromTemplate([
      { label: 'Mở trung tâm chỉ huy', click: () => { if (!win) createWindow(port); else win.show(); } },
      { label: 'Chụp ảnh hệ thống', click: () => N?.snapshots.take({ label: 'tray' }) },
      { type: 'separator' },
      { role: 'quit', label: 'Thoát' },
    ]));
    tray.on('click', () => { if (!win) createWindow(port); else win.show(); });
  } catch (e) {
    log('Không tạo được biểu tượng khay hệ thống:', e.message);
  }
}

// Chỉ cho phép một bản đang chạy — tránh hai tiến trình tranh cùng một cổng.
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });

  app.whenReady().then(async () => {
    // MÀN HÌNH CHỜ HIỆN NGAY, TRƯỚC KHI DỰNG NEXUS.
    //
    // Đo trên máy dựng: bật hệ thống mất khoảng mười ba giây — dựng 500 trợ
    // lý AI, nạp 571 bài học liệu, mở tám bộ sưu tập dữ liệu, bật lịch việc
    // nền. Bản đầu gọi startNexus() trước rồi mới mở cửa sổ, nên suốt mười ba
    // giây ấy màn hình KHÔNG có gì. Người dùng bấm đúp, không thấy gì, bấm
    // đúp lần nữa — lần này bị khoá một-bản-đang-chạy chặn, nên vẫn không
    // thấy gì. Họ kết luận ứng dụng hỏng.
    //
    // Màn hình chờ này là HTML nhúng thẳng, không gọi ra mạng, không đợi máy
    // chủ — vì chính máy chủ là thứ đang được dựng.
    // Đặt dấu trước khi đụng tới cửa sổ đầu tiên.
    try { fs.writeFileSync(dauVeHong, String(Date.now())); } catch { /* bỏ qua */ }
    if (daTatTangToc) log('Lần chạy trước chết khi dựng cửa sổ — đã tắt tăng tốc phần cứng.');
    moManHinhCho();
    try {
      const port = await startNexus();
      dongManHinhCho();
      createWindow(port);
      buildMenu(port);
      createTray(port);
    } catch (e) {
      bootError = e;
      dongManHinhCho();
      log('KHỞI ĐỘNG THẤT BẠI:', e.stack || e.message);
      dialog.showErrorBox(
        'Không khởi động được GITAmath Nexus',
        `${e.message}\n\nNhật ký đầy đủ nằm ở:\n${path.join(userData, 'nexus-desktop.log')}`,
      );
      app.quit();
    }
  });

  app.on('window-all-closed', () => {
    // Trên Windows vẫn giữ ở khay hệ thống; đóng hẳn bằng menu Thoát.
    if (process.platform === 'darwin') return;
    if (!tray) app.quit();
  });

  app.on('activate', () => { if (!win && !bootError) createWindow(server.address().port); });

  app.on('before-quit', async (e) => {
    if (!N) return;
    e.preventDefault();
    try {
      await N.snapshots.take({ label: 'app-exit', note: 'thoát ứng dụng' });
      server?.close();
      await N.shutdown();
      log('Đã dừng an toàn.');
    } catch (err) {
      log('Lỗi khi dừng:', err.message);
    } finally {
      N = null;
      app.exit(0);
    }
  });
}

ipcMain.handle('nexus:port', () => (server ? server.address().port : null));
ipcMain.handle('nexus:info', () => ({
  appVersion: app.getVersion(),
  nexusVersion: N?.cfg.VERSION ?? null,
  agents: N?.agents.length ?? 0,
  squads: N?.squads.length ?? 0,
  articles: N?.constitution.articles.length ?? 0,
  snapshots: N?.snapshots.snapshots.length ?? 0,
  dataDir: userData,
  port: server ? server.address().port : null,
}));
ipcMain.handle('nexus:open-data-dir', () => shell.openPath(userData));
ipcMain.handle('nexus:open-log', () => shell.openPath(path.join(userData, 'nexus-desktop.log')));
