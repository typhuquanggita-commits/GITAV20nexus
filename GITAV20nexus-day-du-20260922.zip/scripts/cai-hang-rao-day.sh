#!/usr/bin/env bash
# Cài hàng rào đẩy vào MỌI kho git tìm thấy trên máy này.
#
# Móc git nằm trong .git/hooks/ — thư mục ấy KHÔNG được git theo dõi, nên nó
# không đi theo bản sao. Đó là lý do phải có kịch bản cài này: clone về một
# máy mới thì chạy lại một lệnh là hàng rào dựng lên.
set -eu
GOC="$(cd "$(dirname "$0")" && pwd)"
NGUON="$GOC/hang-rao-day.sh"
[ -f "$NGUON" ] || { echo "Không thấy $NGUON" >&2; exit 1; }

dem=0
for d in "$@"; do
  if [ -d "$d/.git" ]; then
    mkdir -p "$d/.git/hooks"
    cp "$NGUON" "$d/.git/hooks/pre-push"
    chmod +x "$d/.git/hooks/pre-push"
    echo "  đã cài: $d"
    dem=$((dem + 1))
  fi
done
echo "  ── $dem kho đã có hàng rào ──"
