#!/usr/bin/env node
'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  KIỂM THỬ TẢI — đo thật, tìm điểm gãy, không phỏng đoán
 * ═══════════════════════════════════════════════════════════════════════════
 *  Bốn kịch bản, tăng dần theo mức khó:
 *
 *   1. ĐỌC     — API chỉ đọc, đo độ trễ và thông lượng thuần
 *   2. HỌC     — mô phỏng N học viên cùng luyện tập, có ghi dữ liệu
 *   3. ĐỘI HÌNH— tổng động viên 500 agent dưới tải
 *   4. LEO THANG— tăng dần số việc đồng thời tới khi hệ gãy, ghi lại ngưỡng
 *
 *  Chạy:
 *    node scripts/load-test.js              chạy cả bốn, mức vừa
 *    node scripts/load-test.js --quick      mức nhẹ, dùng trong CI
 *    node scripts/load-test.js --heavy      mức nặng
 *    node scripts/load-test.js --only=3
 * ═══════════════════════════════════════════════════════════════════════════
 */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const argv = process.argv.slice(2);
const has = (f) => argv.includes(f);
const arg = (name, dflt) => {
  const hit = argv.find((a) => a.startsWith(`--${name}=`));
  return hit ? hit.split('=')[1] : dflt;
};

const PROFILE = has('--heavy') ? 'heavy' : has('--quick') ? 'quick' : 'normal';
const SIZES = {
  quick: { readOps: 200, learners: 10, itemsEach: 5, missionUnits: 12, rampFrom: 4, rampTo: 32, rampStep: 4 },
  normal: { readOps: 1000, learners: 40, itemsEach: 10, missionUnits: 60, rampFrom: 8, rampTo: 128, rampStep: 8 },
  heavy: { readOps: 5000, learners: 150, itemsEach: 20, missionUnits: 200, rampFrom: 16, rampTo: 512, rampStep: 16 },
}[PROFILE];

const only = arg('only', null);
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'gita-load-'));
process.env.DB_DIR = path.join(tmp, 'db');
process.env.SNAPSHOT_DIR = path.join(tmp, 'snap');
process.env.LOG_LEVEL = 'error';

const pct = (arr, p) => {
  if (!arr.length) return null;
  const s = [...arr].sort((a, b) => a - b);
  return Math.round(s[Math.min(s.length - 1, Math.floor((p / 100) * s.length))] * 100) / 100;
};
const stat = (lat) => ({
  n: lat.length,
  p50: pct(lat, 50), p95: pct(lat, 95), p99: pct(lat, 99),
  max: lat.length ? Math.round(Math.max(...lat) * 100) / 100 : null,
  avg: lat.length ? Math.round((lat.reduce((a, b) => a + b, 0) / lat.length) * 100) / 100 : null,
});

/** Chạy `total` việc với trần `concurrency` việc cùng lúc. */
async function pool(total, concurrency, fn) {
  const lat = [];
  const errors = [];
  let i = 0;
  const t0 = process.hrtime.bigint();
  const workers = Array.from({ length: Math.min(concurrency, total) }, async () => {
    while (true) {
      const my = i++;
      if (my >= total) break;
      const s = process.hrtime.bigint();
      try {
        await fn(my);
        lat.push(Number(process.hrtime.bigint() - s) / 1e6);
      } catch (e) {
        errors.push(e.message);
      }
    }
  });
  await Promise.all(workers);
  const elapsedMs = Number(process.hrtime.bigint() - t0) / 1e6;
  return {
    elapsedMs: Math.round(elapsedMs),
    throughputPerSec: Math.round((lat.length / elapsedMs) * 1000),
    errors: errors.length,
    errorSamples: [...new Set(errors)].slice(0, 3),
    latency: stat(lat),
  };
}

const results = [];
const line = (n = 78, c = '─') => console.log('  ' + c.repeat(n));

function report(name, r, extra = {}) {
  results.push({ name, ...r, ...extra });
  console.log(`  ▸ ${name}`);
  console.log(`      ${r.latency.n} việc · ${r.elapsedMs}ms · ${r.throughputPerSec}/giây`
    + ` · p50 ${r.latency.p50}ms · p95 ${r.latency.p95}ms · max ${r.latency.max}ms`
    + (r.errors ? ` · LỖI ${r.errors}` : ''));
  if (r.errorSamples?.length) console.log(`      lỗi: ${r.errorSamples.join(' | ')}`);
  for (const [k, v] of Object.entries(extra)) console.log(`      ${k}: ${v}`);
}

(async function main() {
  console.log('');
  console.log(`  GITAmath NEXUS V20 — KIỂM THỬ TẢI (${PROFILE})`);
  console.log(`  ${new Date().toISOString()} · Node ${process.version} · ${os.cpus().length} CPU`);
  line(78, '═');

  const tBoot = Date.now();
  const { boot, createServer } = require('../src/index.js');
  const N = await boot({ quiet: true });
  const bootMs = Date.now() - tBoot;
  const server = createServer(N);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  console.log(`  Khởi động ${bootMs}ms · ${N.agents.length} agent · ${N.bank.items.size} bài trong kho`);
  console.log('');

  const get = async (p) => {
    const r = await fetch(base + p);
    if (!r.ok && r.status >= 500) throw new Error(`${p} → ${r.status}`);
    await r.text();
  };
  const post = async (p, b) => {
    const r = await fetch(base + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b) });
    const j = await r.json();
    if (r.status >= 500) throw new Error(`${p} → ${r.status}`);
    return j;
  };

  // ── 1. ĐỌC ───────────────────────────────────────────────────────────────
  if (!only || only === '1') {
    const paths = ['/health', '/agents/assignment', '/curriculum/forms', '/bank/status',
      '/authoring/coverage', '/agents/kpi', '/resilience/fleet', '/constitution/articles'];
    const r = await pool(SIZES.readOps, 32, (i) => get(paths[i % paths.length]));
    report('1. API chỉ đọc', r);
  }

  // ── 2. HỌC ───────────────────────────────────────────────────────────────
  if (!only || only === '2') {
    for (let i = 0; i < SIZES.learners; i++) {
      N.profiles.register(`LOAD-${i}`, { fullName: `Học viên tải ${i}`, grade: 9 });
      N.profiles.get(`LOAD-${i}`).currentLevel = 3;
    }
    const r = await pool(SIZES.learners, 16, async (i) => {
      const id = `LOAD-${i}`;
      const st = await post('/practice/start', { learnerId: id, size: SIZES.itemsEach });
      if (!st.ok) throw new Error(st.error || 'không mở được phiên');
      let cur = st.item;
      for (let k = 0; k < SIZES.itemsEach && cur; k++) {
        const a = await post('/practice/answer', {
          sessionId: st.sessionId, itemId: cur.itemId, correct: k % 3 !== 2, ms: 60_000,
        });
        if (a.done) break;
        cur = a.next;
      }
    });
    const totalItems = SIZES.learners * SIZES.itemsEach;
    report('2. Học viên luyện tập đồng thời', r, {
      'học viên': SIZES.learners,
      'lượt làm bài': totalItems,
      'bài/giây': Math.round((totalItems / r.elapsedMs) * 1000),
    });
  }

  // ── 3. ĐỘI HÌNH 500 AGENT ────────────────────────────────────────────────
  if (!only || only === '3') {
    const t0 = Date.now();
    const m = await N.mobilization.execute({
      kind: 'CONTENT_PRODUCTION', objective: 'Kiểm thử tải: sản xuất học liệu',
      scope: { count: SIZES.missionUnits }, maxConcurrent: 32, issuedBy: 'LOADTEST',
    });
    const ms = Date.now() - t0;
    report('3. Tổng động viên 500 agent', {
      elapsedMs: ms,
      throughputPerSec: Math.round((m.unitsDone / ms) * 1000),
      errors: m.unitsFailed || 0,
      errorSamples: [],
      latency: { n: m.unitsDone, p50: null, p95: null, p99: null, max: null, avg: Math.round(ms / Math.max(1, m.unitsDone)) },
    }, {
      'agent vào việc': m.agentsEngaged,
      'khối tham gia': (m.byDivision || []).length,
      'mảnh xong': `${m.unitsDone}/${m.unitsAssigned}`,
      'không chồng chéo': m.noOverlap,
      'chồng chéo bị chặn': m.overlapsPrevented,
    });
  }

  // ── 4. LEO THANG TỚI KHI GÃY ─────────────────────────────────────────────
  if (!only || only === '4') {
    console.log('  ▸ 4. Leo thang tìm điểm gãy');
    console.log('      đồng thời | thông lượng | p95 (ms) | lỗi | từ chối vì quá tải');
    let breakPoint = null;
    let best = { conc: 0, tp: 0 };
    let peakSeen = 0;
    for (let c = SIZES.rampFrom; c <= SIZES.rampTo; c += SIZES.rampStep) {
      const before = N.capacity.status();
      const r = await pool(c * 4, c, async (i) => {
        const a = await post('/agents/dispatch', {
          type: 'vietnamese', input: `Kiểm thử tải mức ${c} việc ${i}: tóm tắt một ý ngắn.`, maxTokens: 120,
        });
        // Bị từ chối vì quá tải KHÔNG phải lỗi — đó là hệ thống tự bảo vệ.
        if (!a.ok && !['CAPACITY_LIMIT', 'NO_AGENT_AVAILABLE', 'BACKPRESSURE', 'RATE_LIMIT'].includes(a.error)) {
          throw new Error(a.error || 'lỗi lạ');
        }
      });
      const after = N.capacity.status();
      const rejected = (after.stats?.rejected ?? after.rejected ?? 0) - (before.stats?.rejected ?? before.rejected ?? 0);
      peakSeen = Math.max(peakSeen, after.global.peak ?? 0);
      console.log(`      ${String(c).padStart(9)} | ${String(r.throughputPerSec).padStart(11)} | `
        + `${String(r.latency.p95).padStart(8)} | ${String(r.errors).padStart(3)} | ${rejected}`);
      if (r.throughputPerSec > best.tp) best = { conc: c, tp: r.throughputPerSec };
      if (r.errors > 0 && !breakPoint) breakPoint = { concurrency: c, errors: r.errors, samples: r.errorSamples };
    }
    const capLimit = N.capacity.status().global.limit;
    results.push({
      name: '4. Leo thang', breakPoint, bestThroughput: best, peakInFlight: peakSeen, capacityLimit: capLimit,
      verdict: breakPoint
        ? `Gãy ở mức ${breakPoint.concurrency} việc đồng thời: ${breakPoint.samples.join('; ')}`
        : `Không gãy tới mức ${SIZES.rampTo}. Thông lượng cao nhất ${best.tp}/giây tại mức ${best.conc}.`,
    });
    console.log(`      → ${results.at(-1).verdict}`);
    console.log(`      → Đỉnh việc chạy cùng lúc ghi nhận: ${peakSeen}/${capLimit} (trần công suất).`);
    if (peakSeen < capLimit) {
      console.log(`      → Trần công suất CHƯA bị chạm. Ở chế độ ngoại tuyến mỗi việc xong trong vài mili giây`);
      console.log(`        nên nút thắt là vòng lặp sự kiện của Node, không phải bộ điều tiết công suất.`);
      console.log(`        Kịch bản 5 dưới đây ép chạm trần để kiểm tra bộ điều tiết có thật sự chặn không.`);
    }
  }

  // ── 5. ÉP CHẠM TRẦN CÔNG SUẤT ────────────────────────────────────────────
  // Ở chế độ ngoại tuyến mô hình trả lời gần như tức thì nên trần công suất
  // không bao giờ bị chạm. Chèn độ trễ giả để dựng lại đúng tình huống có
  // mô hình thật (mỗi lượt gọi vài trăm mili giây) và xem bộ điều tiết có
  // chặn đúng lúc không — nếu không chặn thì khi chạy thật sẽ vỡ quota.
  if (!only || only === '5') {
    const limit = N.capacity.status().global.limit;
    const realCall = N.llm.call.bind(N.llm);
    N.llm.call = async (req) => {
      await new Promise((r) => setTimeout(r, 120));   // giả lập độ trễ mô hình thật
      return realCall(req);
    };

    // Kịch bản trước đã tiêu hết hạn mức token của phút này. Xoá cửa sổ đếm
    // để đo ĐÚNG thứ đang muốn đo là trần số việc chạy đồng thời, chứ không
    // phải lớp bảo vệ quota token.
    const cleared = N.capacity.clearTokenWindow();
    const target = limit * 3;
    const why = {};
    let accepted = 0;
    // Đo đỉnh RIÊNG cho kịch bản này, không lẫn đỉnh của kịch bản trước.
    const peakBefore = N.capacity.status().global.peak;
    N.capacity.resetPeak?.();
    const t0 = Date.now();
    await Promise.all(Array.from({ length: target }, async (_, i) => {
      const a = await post('/agents/dispatch', {
        type: 'vietnamese', input: `Ép trần công suất, việc số ${i} của đợt kiểm thử.`, maxTokens: 100,
      });
      if (a.ok) accepted++;
      else {
        const k = a.reason ? `${a.error} (${a.reason})` : (a.error || 'LỖI_LẠ');
        why[k] = (why[k] || 0) + 1;
      }
    }));
    const ms = Date.now() - t0;
    N.llm.call = realCall;

    const peak = Math.max(N.capacity.status().global.peak, 0);
    const held = peak <= limit;
    const rejected = Object.values(why).reduce((a, b) => a + b, 0);
    console.log('  ▸ 5. Ép chạm trần công suất');
    console.log(`      ${target} việc cùng lúc (trần ${limit}) · ${ms}ms`
      + ` · đã xoá ${cleared.clearedTokens.toLocaleString('vi-VN')} token khỏi cửa sổ đếm để đo đúng trần đồng thời`);
    console.log(`      nhận ${accepted} · từ chối ${rejected} · đỉnh chạy cùng lúc ${peak}/${limit}`);
    if (rejected) {
      console.log(`      lý do từ chối: ${Object.entries(why).map(([k, v]) => `${k} ${v}`).join(' · ')}`);
      if (why.RATE_LIMIT) {
        console.log(`      → RATE_LIMIT là bộ đếm tần suất theo phút (${process.env.RATE_LIMIT_PER_MIN || 200}/phút)`);
        console.log(`        đã cạn từ kịch bản trước. Đây là lớp bảo vệ khác, không phải trần công suất.`);
      }
    }
    console.log(`      → Bộ điều tiết ${held ? 'GIỮ ĐÚNG trần' : 'ĐỂ LỌT quá trần — đây là lỗi'}`
      + ` (đỉnh trước kịch bản này: ${peakBefore}).`);
    results.push({
      name: '5. Ép chạm trần công suất', errors: held ? 0 : 1,
      peak, limit, accepted, rejected, rejectReasons: why, elapsedMs: ms,
      verdict: held
        ? `Giữ đúng trần: đỉnh ${peak} ≤ ${limit}. Việc vượt trần được xếp hàng hoặc từ chối, không tràn.`
        : `LỖI: đỉnh ${peak} vượt trần ${limit}.`,
    });
  }

  // ── Sức khoẻ sau tải ─────────────────────────────────────────────────────
  console.log('');
  const health = await (await fetch(`${base}/health`)).json();
  const fleet = N.shield.fleetReadiness();
  const audit = N.audit.verify();
  const mem = process.memoryUsage();

  line(78, '═');
  console.log('  SAU KHI CHỊU TẢI');
  console.log(`      Trạng thái     : ${health.status}`);
  console.log(`      Đội hình       : ${Math.round(fleet.readiness * 100)}% sẵn sàng (${fleet.eligible}/${fleet.total})`);
  console.log(`      Nhật ký bất biến: ${audit.ok ? 'nguyên vẹn' : 'VỠ TẠI ' + audit.brokenAt}`);
  console.log(`      Bộ nhớ         : ${Math.round(mem.heapUsed / 1048576)} MB heap / ${Math.round(mem.rss / 1048576)} MB RSS`);
  console.log(`      Hàng đợi       : ${health.queue?.waiting ?? 0} việc đang chờ`);
  console.log(`      Agent bị cách ly: ${N.shield.status().quarantined ?? 0}`);

  const problems = [];
  if (health.status === 'unhealthy') problems.push('Hệ thống không khoẻ sau tải.');
  if (!audit.ok) problems.push('Nhật ký bất biến bị vỡ — nghiêm trọng.');
  if (fleet.readiness < 0.9) problems.push(`Chỉ còn ${Math.round(fleet.readiness * 100)}% đội hình sẵn sàng.`);
  const failed = results.filter((r) => r.errors > 0);
  if (failed.length) problems.push(`${failed.length} kịch bản có lỗi thật.`);

  line(78, '═');
  console.log(problems.length ? `  KẾT LUẬN: ${problems.join(' ')}` : '  KẾT LUẬN: Chịu được tải, không mất dữ liệu, không gãy đội hình.');
  console.log('');

  server.close();
  await N.shutdown();
  try { fs.rmSync(tmp, { recursive: true, force: true }); } catch { /* bỏ qua */ }
  process.exit(problems.length ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
