#!/usr/bin/env node
'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  DỰNG BẢN CLOUDFLARE PAGES — và soi lại sản phẩm trước khi nói xong
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   node scripts/dung-ban-cloudflare.js
 *
 *  Ra thư mục cloudflare/dist/, đẩy lên bằng:
 *      npx wrangler pages deploy cloudflare/dist --project-name gitamath
 *
 *  Kịch bản này KHÔNG chỉ sinh tệp rồi báo xong. Nó soi lại chính thứ vừa
 *  sinh ra: có kịch bản lọt vào không, có đường nào gọi ra ngoài không, có
 *  câu nào không qua được luật nội dung không, và có tệp nào rỗng không.
 *
 *  Vì một trang tĩnh hỏng thì hỏng IM LẶNG — nó vẫn trả về 200.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const fs = require('node:fs');
const path = require('node:path');

const GOC = path.join(__dirname, '..');
const RA = path.join(GOC, 'cloudflare', 'dist');

const mau = { xanh: (s) => `\x1b[32m${s}\x1b[0m`, do: (s) => `\x1b[31m${s}\x1b[0m`, nhat: (s) => `\x1b[2m${s}\x1b[0m`, dam: (s) => `\x1b[1m${s}\x1b[0m` };
let hong = 0;
const dat = (t, p = '') => console.log(`  [${mau.xanh(' ĐẠT ')}] ${t}${p ? mau.nhat(` · ${p}`) : ''}`);
const truot = (t) => { hong += 1; console.log(`  [${mau.do('KHÔNG')}] ${t}`); };

(async function main() {
  console.log(mau.dam('\n  ▸ DỰNG BẢN CLOUDFLARE PAGES\n'));

  const { boot } = require('../src/index');
  const N = await boot({ quiet: true });
  const T = require('../src/tiep-thi/dung-trang-tinh');
  const TM = require('../src/tiep-thi/trang-mien');
  const BG = require('../cloudflare/nguon/_lib/bang-goc');
  const TC = require('../cloudflare/nguon/_lib/to-chuc');
  const HP = require('../cloudflare/nguon/_lib/hien-phap');
  const BP = require('../cloudflare/nguon/_lib/bo-phieu');
  const LT = require('../cloudflare/nguon/tuyen/lo-trinh');
  const ngayDung = new Date().toISOString().slice(0, 10);

  fs.rmSync(RA, { recursive: true, force: true });
  fs.mkdirSync(RA, { recursive: true });

  // ── 1. Trang giới thiệu, dựng từ số liệu THẬT ──
  const trang = N.hopNhat.soanTrang();
  trang.soLieu.phienBan = N.cfg.VERSION;
  if (!trang.mang.length) truot('Không mảng nội dung nào dựng được — kho rỗng hoàn toàn');
  else dat('Nội dung trang chủ', `${trang.mang.length} mảng · bỏ qua ${trang.boQua.length}`);

  // ── 2. Sơ đồ chương trình, dạng ảnh tĩnh ──
  const SD = require('../src/so-do-tu-duy/so-do');
  const VE = require('../src/so-do-tu-duy/ve');
  const soDo = SD.dung({ kieu: 'toan-canh' });
  // Hai khổ, hai chỗ dùng. Cả hai đều BỎ NỀN TỐI, nên bộ vẽ tự đổi sang bảng
  // màu sáng — chữ đậm, đường đậm, đọc được trên giấy trắng.
  const svg = VE.ve(soDo, { rong: 760, cao: 520, nen: false })
    .replace(/^<svg /, '<svg style="max-width:100%;height:auto" ');
  const svgLon = VE.ve(soDo, { rong: 1080, cao: 700, nen: false })
    .replace(/^<svg /, '<svg style="max-width:100%;height:auto" ');
  dat('Sơ đồ chương trình', `${soDo.thongKe.soNut} dạng · ${soDo.thongKe.soCanh} quan hệ`);

  // ── 3. Danh mục kịch bản video ──
  const danhMuc = N.xuongVideo.danhMuc();
  if (!danhMuc.ok) truot(`Danh mục video có ${danhMuc.hong.length} kịch bản hỏng`);
  else dat('Danh mục video hướng dẫn', `${danhMuc.soMan} màn × ${danhMuc.soVai} vai = ${danhMuc.soVideo}`);

  // ── 4. Dữ liệu THẬT cho từng trang ──
  const H = require('../src/curriculum/hierarchy');
  const CH = require('../src/matran/chuan');
  const cq = require('../src/api/cong-quyen');
  const { ROLES } = require('../src/security/accounts');
  const { routes } = require('../src/api/router')(N);
  const MH = require('../src/xuong-video/man-hinh');

  const theoTienTo = {};
  for (const f of H.FORMS) {
    const k = f.code.split('.')[0].replace(/[0-9]+/g, '');
    theoTienTo[k] = (theoTienTo[k] || 0) + 1;
  }
  trang.soLieu.soChuan = CH.CHUAN.length;

  const phanBo = {};
  for (const r of routes) { const m = cq.mucCua(r); phanBo[m] = (phanBo[m] || 0) + 1; }
  const nhomCong = [...new Set(routes.map((r) => r.group))]
    .map((nhom) => ({ nhom, muc: cq.mucCua({ method: 'GET', pattern: '/x', group: nhom }) }));

  // Số liệu sống của từng phần, đọc thẳng từ hệ đang chạy.
  const soChung = {
    soDang: trang.soLieu.soDang, soTang: trang.soLieu.soTang, soQuanHe: trang.soLieu.soQuanHe,
    soKiemDinh: trang.soLieu.soKiemDinh, soBay: trang.soLieu.soBay, soChuan: CH.CHUAN.length,
    soCong: routes.length, soNhomCong: nhomCong.length,
  };
  const batDau = N.placement.status();
  const loTrinh = N.roadmap.status();
  const chuKy = N.cycle90.status();
  const ket = N.vault.status();
  const soCrm = require('../src/crm/so-tro-ly').soiSo();
  const crm = {
    soTroLy: soCrm.soTroLy, soChiSo: soCrm.soChiSo, chiSoDoDuoc: soCrm.chiSoDoDuoc,
    soCap: Object.keys(require('../src/crm/so-tro-ly').CAP || {}).length,
    soMoDun: fs.readdirSync(path.join(GOC, 'src', 'crm')).filter((f) => f.endsWith('.js')).length,
  };
  const luc = { soTroLy: N.agents.length, soTo: (N.squads || []).length };

  const tep = {
    'index.html': T.trangChu(trang, { ngayDung, banSvg: svg }),
    'he-thong.html': T.trangHeThong({ ngayDung, so: soChung, batDau, loTrinh, ket, crm, luc }),
    'hanh-trinh-hoc.html': T.trangHanhTrinh({ ngayDung, batDau, loTrinh, chuKy, so: soChung }),
    'ho-so.html': T.trangHoSo({ ngayDung, crm, so: soChung }),
    'quan-tri.html': T.trangQuanTri({ ngayDung, ket, luc, so: soChung, crm }),
    'muc-luc.html': T.trangMucLuc({ ngayDung, man: MH.dungSo(N), soLieu: trang.soLieu }),
    'chuong-trinh.html': T.trangChuongTrinh({
      ngayDung, khoi: Object.values(H.BLOCKS), theoTienTo, soLieu: trang.soLieu,
    }),
    'luyen-thi.html': T.trangLuyenThi({ ngayDung, chuan: CH.CHUAN }),
    'phan-quyen.html': T.trangPhanQuyen({
      ngayDung,
      vai: Object.values(ROLES),
      mucTheoVai: Object.fromEntries(Object.entries(cq.VAI_TOI_MUC)
        .map(([v, n]) => [v, Object.keys(cq.MUC).find((k) => cq.MUC[k] === n)])),
      nhomCong, phanBo, tongCong: routes.length,
    }),
    'so-do.html': T.trangSoDo(svgLon, { ngayDung, thongKe: soDo.thongKe }),
    'video-huong-dan.html': T.trangKichBan(danhMuc, { ngayDung }),
    'so-do-chuong-trinh.svg': VE.ve(soDo, { rong: 1100, cao: 720 }),
  };
  dat('Số liệu sống của từng phần',
    `chẩn đoán ${batDau.minItems}–${batDau.maxItems} câu · lộ trình ${loTrinh.weeks} tuần · `
    + `két ${ket.layers} tầng · ${crm.soMoDun} mô-đun CRM · ${luc.soTroLy} trợ lý`);
  dat('Dữ liệu thật cho từng trang',
    `${CH.CHUAN.length} chuẩn luyện thi · ${Object.keys(H.BLOCKS).length} khối · `
    + `${Object.values(ROLES).length} vai · ${nhomCong.length} nhóm cổng · ${routes.length} cổng`);

  // ── Trang riêng cho từng phần: mỗi phần một trang web nhỏ, đầy đủ ──
  //
  // Ô chương trình dựng lại y hệt bộ gieo dữ liệu của tầng Cloudflare, nên
  // trang tĩnh và kho dữ liệu không bao giờ nói hai con số khác nhau.
  const oChuongTrinh = [];
  for (const m of BG.MON_HOC) {
    for (let lop = 1; lop <= 12; lop++) {
      for (const c of BG.CAP_DO) {
        if (c.id === 'dai-hoc' && lop < 10) continue;
        if (c.id === 'quoc-te' && lop < 6) continue;
        if (c.id === 'chuyen' && lop < 5) continue;
        oChuongTrinh.push({ id: m.id + '-l' + lop + '-' + c.id, mon_id: m.id, lop, cap_do_id: c.id });
      }
    }
  }
  // Kho bài thật: đếm từ ngân hàng câu hỏi đang chạy, không khai tay.
  const khoThat = (() => {
    try {
      const b = N.itemBank ? N.itemBank.status() : null;
      return { bai: (b && (b.total ?? b.soMuc)) || 0, chuyenDe: 0 };
    } catch (e) { return { bai: 0, chuyenDe: 0 }; }
  })();

  for (const m of BG.MON_HOC) {
    tep['mon-' + m.id + '.html'] = TM.trangMon(m,
      { capDo: BG.CAP_DO, o: oChuongTrinh, ngayDung, phuSong: {} });
  }
  for (const k of BG.KY_THI) {
    const he = CH.CHUAN_INDEX.get(k.id);
    if (!he) continue;               // TOEIC chưa có trong bảng cấu trúc gốc
    tep['thi-' + k.id + '.html'] = TM.trangKyThi(he, k,
      { ngayDung, tenNac: CH.TEN_NAC, tongCua: CH.tongCua });
  }
  for (const t of BG.TRAI) tep['trai-' + t.id + '.html'] = TM.trangTrai(t, { ngayDung });

  tep['do-nang-luc.html'] = TM.trangDoNangLuc(BP.BO,
    { ngayDung, canhBaoChung: BP.CANH_BAO_CHUNG });
  tep['lo-trinh-ca-nhan.html'] = TM.trangLoTrinh({
    ngayDung, capDo: BG.CAP_DO,
    doBang: [
      ['ti-le-dung', 'Tỉ lệ làm đúng trên số bài đã chấm được, trong phạm vi một ô chương trình.'],
      ['so-bai', 'Số bài đã làm — dùng để biết mẫu đã đủ chưa.'],
      ['diem-kiem-tra', 'Điểm cao nhất trong các lượt thi đã nộp.'],
      ['so-buoi', 'Số buổi học đã ghi nhận.'],
      ['chuan-phu', 'Tỉ lệ chuẩn kiến thức của ô đã có bài phủ tới.'],
      ['thoi-gian-giu', 'Số ngày giữ được nhịp học liên tục.'],
    ],
  });
  tep['bo-may.html'] = TM.trangBoMay({
    ngayDung, ban: TC.BAN, troLy: TC.danhSachTroLy(), tenVai: TC.TEN_VAI,
    nhiemVu: TC.NHIEM_VU.map((n) => ({ ten: n.ten, ban: n.ban,
      tieu_chuan: n.tieu_chuan, can_nguoi_duyet: n.can_nguoi_duyet })),
    quyTrinh: TC.QUY_TRINH, crmTo: TC.TO_CRM, soCrm: TC.danhSachCrm().length,
  });
  tep['hien-phap.html'] = TM.trangHienPhap(HP.ban(), { ngayDung });
  tep['kho-bai.html'] = TM.trangKhoBai({
    ngayDung, soBai: khoThat.bai, soChuyenDe: khoThat.chuyenDe,
    dichBai: 800000, dichChuyenDe: 8000, theoDang: [],
  });
  tep['tai-chinh.html'] = TM.trangTaiChinh({ ngayDung, taiKhoan: BG.TAI_KHOAN });

  dat('Trang riêng từng phần',
    `${BG.MON_HOC.length} môn · ${BG.KY_THI.filter((k) => CH.CHUAN_INDEX.get(k.id)).length} kỳ thi · `
    + `${BG.TRAI.length} trại · ${TC.BAN.length} ban · ${HP.DIEU.length} điều hiến pháp`);

  // ── Toàn bộ giao diện ứng dụng ──
  //
  // Mười màn hình của ứng dụng là tệp tĩnh thuần: HTML, JS, CSS, không một
  // đường dẫn nào ra ngoài. Cloudflare phục vụ được hết. Phần ĐỘNG mà chúng
  // gọi tới (/accounts, /practice, /tro-chuyen…) đi tiếp về máy chủ Node qua
  // ba dòng trong _redirects.
  //
  // Để chúng ở đây chứ không bỏ đi, vì bỏ đi thì bản trên Cloudflare chỉ là
  // một tờ rơi; để vào thì nó là cả phần nhìn thấy được của hệ thống, và chỉ
  // còn thiếu đúng phần phải có máy chủ.
  const UI = path.join(GOC, 'ui');
  fs.mkdirSync(path.join(RA, 'ui'), { recursive: true });
  let soUi = 0;
  for (const f of fs.readdirSync(UI)) {
    const q = path.join(UI, f);
    if (!fs.statSync(q).isFile()) continue;
    fs.copyFileSync(q, path.join(RA, 'ui', f));
    soUi += 1;
  }
  dat('Giao diện ứng dụng', `${soUi} tệp trong ui/`);

  // ── Phần động: ghép thành một tệp _worker.js ──
  //
  // Phải chạy SAU khi dựng xong phần tĩnh, vì bước dựng dọn sạch dist/.
  // Cloudflare Pages chỉ biên dịch thư mục functions/ khi triển khai bằng
  // wrangler; đường kéo thả gói nén qua bảng điều khiển thì chỉ nhận đúng
  // một tệp _worker.js ở gốc. Người dùng hệ này đi đường kéo thả, nên mã
  // phải gom lại thành một tệp.
  const { chay: ghepWorker } = require('../cloudflare/dung-worker');
  const banGhep = ghepWorker();
  dat('Phần động ghép thành một tệp',
    `_worker.js · ${banGhep.soMoDun} mô-đun · `
    + `${(fs.statSync(path.join(RA, '_worker.js')).size / 1024).toFixed(0)}KB`);

  // ── Sơ đồ ở nhiều góc nhìn, để in và để nhúng ──
  fs.mkdirSync(path.join(RA, 'so-do'), { recursive: true });
  const GOC_NHIN = [
    ['thang', 0.0, 0.0], ['mac-dinh', 0.6, 0.28], ['nghieng', 1.4, 0.45], ['ben-canh', 2.6, 0.1],
  ];
  for (const [ten, doc, ngang] of GOC_NHIN) {
    fs.writeFileSync(path.join(RA, 'so-do', `toan-canh-${ten}.svg`),
      VE.ve(soDo, { gocDoc: doc, gocNgang: ngang, rong: 1100, cao: 720 }));
  }
  fs.writeFileSync(path.join(RA, 'so-do', 'toan-canh-nen-sang.svg'),
    VE.ve(soDo, { rong: 1100, cao: 720, nen: false }));
  dat('Sơ đồ nhiều góc nhìn', `${GOC_NHIN.length + 1} tệp SVG`);

  // ── Kịch bản lời đọc từng video ──
  //
  // Tải về được, gửi thẳng cho phát thanh viên thu giọng người thật.
  fs.mkdirSync(path.join(RA, 'kich-ban'), { recursive: true });
  let soKichBan = 0;
  for (const m of danhMuc.muc) {
    const k = N.xuongVideo.xuatKichBanChu(m.man, m.vai);
    if (k.ok) { fs.writeFileSync(path.join(RA, 'kich-ban', `${m.ma}.txt`), k.chu); soKichBan += 1; }
  }
  dat('Kịch bản lời đọc', `${soKichBan} tệp .txt`);

  // ── Trang hướng dẫn, đọc được NGAY TRÊN Cloudflare sau khi tải lên ──
  //
  // Đặt trong gói chứ không chỉ để trong kho mã: người tải gói lên Cloudflare
  // có thể không phải người đọc kho mã.
  tep['huong-dan.html'] = T.trangHuongDan({ ngayDung, soUi, soKichBan, soTep: 0 });
  fs.writeFileSync(path.join(RA, 'huong-dan.html'), tep['huong-dan.html']);

  for (const [ten, chu] of Object.entries(tep)) fs.writeFileSync(path.join(RA, ten), chu);
  dat('Trang công khai', `${Object.keys(tep).filter((t) => t.endsWith('.html')).length} trang`);

  // ── 5. Cấu hình Cloudflare ──
  // Chính sách nội dung khác nhau cho hai loại trang, và phải khác:
  //   · trang tĩnh tôi dựng    — KHÔNG có kịch bản nào, nên cấm hẳn
  //   · mười màn giao diện     — CÓ kịch bản của chính mình, nên cho 'self'
  // Dùng chung một chính sách thì hoặc là nới lỏng trang tĩnh vô cớ, hoặc là
  // khoá chết cả mười màn giao diện. Bản đầu đặt script-src 'none' cho /* và
  // đúng là đã khoá chết chúng.
  fs.writeFileSync(path.join(RA, '_headers'), `/*
  X-Content-Type-Options: nosniff
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: geolocation=(), microphone=()
  X-Frame-Options: DENY
  Strict-Transport-Security: max-age=31536000; includeSubDomains

/index.html
  Content-Security-Policy: ${T.CSP}

/so-do.html
  Content-Security-Policy: ${T.CSP}

/video-huong-dan.html
  Content-Security-Policy: ${T.CSP}

/huong-dan.html
  Content-Security-Policy: ${T.CSP}

/muc-luc.html
  Content-Security-Policy: ${T.CSP}

/chuong-trinh.html
  Content-Security-Policy: ${T.CSP}

/luyen-thi.html
  Content-Security-Policy: ${T.CSP}

/phan-quyen.html
  Content-Security-Policy: ${T.CSP}

/he-thong.html
  Content-Security-Policy: ${T.CSP}

/hanh-trinh-hoc.html
  Content-Security-Policy: ${T.CSP}

/ho-so.html
  Content-Security-Policy: ${T.CSP}

/quan-tri.html
  Content-Security-Policy: ${T.CSP}

/ui/*
  Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; object-src 'none'

/kich-ban/*
  Content-Type: text/plain; charset=utf-8

/so-do/*
  Cache-Control: public, max-age=3600

/*.svg
  Cache-Control: public, max-age=3600
`);

  fs.writeFileSync(path.join(RA, '_redirects'), `# ═══════════════════════════════════════════════════════════════════════
#  LỐI TẮT CHO NGƯỜI GÕ TAY
# ═══════════════════════════════════════════════════════════════════════
#
# Trước đây tệp này có ba dòng phải mở tay để trỏ /api/* về một máy chủ
# Node chạy ở nơi khác. Nay KHÔNG CẦN nữa: toàn bộ phần động chạy ngay
# trên Cloudflare qua _worker.js ở gốc gói này.
#
# Thứ duy nhất còn phải gắn tay là kho dữ liệu D1, và gắn ở bảng điều
# khiển chứ không ở tệp này:
#   Pages → dự án → Settings → Functions → D1 database bindings
#   tên gắn kết: DB
#
# Chưa gắn D1 thì trang tĩnh vẫn mở bình thường, còn mọi đường /api/*
# trả về một câu nói rõ cách gắn. Đó là đúng, không phải lỗi.

/chuong-trinh   /so-do.html            301
/video          /video-huong-dan.html  301
/huong-dan      /huong-dan.html        301
/app            /ui/cong.html          302
/ke-toan        /ui/ke-toan.html       302
/crm            /ui/crm.html           302
/tong           /ui/bang-tong.html     302
/quan-tri-tong  /ui/bang-tong.html     302
`);

  // wrangler.toml nằm ở cloudflare/, KHÔNG nằm trong dist/ — và đó là cố ý:
  // nó là cấu hình cho lệnh wrangler chạy ở máy mình, không phải nội dung
  // trang. Để lẫn vào dist/ thì luồng tải lên của Cloudflare từ chối cả gói.
  fs.writeFileSync(path.join(GOC, 'cloudflare', 'wrangler.toml'), `name = "gitamath"
pages_build_output_dir = "dist"
compatibility_date = "${ngayDung}"

# Bản tĩnh này KHÔNG cần biến môi trường nào, và đó là cố ý: không bí mật nào
# đi lên Cloudflare thì không bí mật nào rò từ Cloudflare.
`);

  fs.writeFileSync(path.join(GOC, 'cloudflare', 'DOC-TRUOC.md'), `# Đưa GITAmath lên Cloudflare

## CHỌN ĐÚNG GÓI — đọc mục này trước

\`npm run zip\` xuất ra HAI gói, và tên của chúng nói thẳng việc:

| Tên gói | Dùng để |
|---|---|
| \`TAI-LEN-CLOUDFLARE-<ngày>.zip\` | **Gói này** — kéo thả vào ô tải lên của Cloudflare |
| \`KHONG-TAI-LEN-CLOUDFLARE--ma-nguon-<ngày>.zip\` | Mã nguồn — giải nén ở máy mình, KHÔNG tải lên |

Tải nhầm gói mã nguồn lên thì hai chuyện xảy ra: Cloudflare từ chối
\`wrangler.toml\` và dừng giữa chừng; còn nếu nó không từ chối thì toàn bộ mã
nguồn và \`.env.example\` sẽ nằm trên một trang web công khai.

Hai kịch bản \`npm run cloudflare\` và \`npm run zip\` đều soi và **từ chối
hoàn tất** nếu gói tĩnh mang một tệp thuộc sáu loại bị cấm.

## Ba cách đưa lên, chọn một

**1. Kéo thả (không cần cài gì)** — Cloudflare → Workers & Pages → Create →
Upload static files, rồi thả nguyên gói \`TAI-LEN-CLOUDFLARE-<ngày>.zip\`.

**2. Dòng lệnh, không cần tệp cấu hình:**
\`\`\`bash
npx wrangler pages deploy cloudflare/dist --project-name gitamath
\`\`\`

**3. Dòng lệnh, dùng tệp cấu hình sẵn có:**
\`\`\`bash
cd cloudflare && npx wrangler pages deploy
\`\`\`
(\`wrangler.toml\` nằm ở \`cloudflare/\`, KHÔNG nằm trong \`dist/\` — nó là cấu
hình cho lệnh chạy ở máy mình, không phải nội dung trang.)

## Cái gì lên được Cloudflare, cái gì không

Nói thẳng trước khi làm, vì đây là chỗ dễ hứa quá tay nhất.

**Lên được** (Cloudflare Pages phục vụ tệp tĩnh):

- Trang giới thiệu — dựng sẵn thành HTML, số liệu đóng băng tại ngày dựng
- Sơ đồ chương trình dạng ảnh SVG, năm góc nhìn
- ${soKichBan} kịch bản lời đọc của bộ video hướng dẫn
- **Toàn bộ ${soUi} tệp giao diện** — mười màn hình của ứng dụng

**Không lên được** — cần một máy chủ Node chạy thật:

- Đăng nhập, tài khoản, phiên làm việc
- Trợ lý trò chuyện (đọc dữ liệu học viên thật)
- Dựng video, dựng bài giảng, chụp ảnh hệ thống
- Mọi thứ ghi xuống đĩa

Lý do không phải thiếu sót của ai: Pages không chạy tiến trình lâu dài, không
có hệ tệp ghi được, và không giữ trạng thái giữa hai yêu cầu.

## Nối hai phần

1. Chạy máy chủ Node ở đâu cũng được — kể cả một máy trong văn phòng.
2. \`cloudflared tunnel --url http://localhost:9999\` đưa nó ra ngoài, không
   phải mở cổng nào trên tường lửa.
3. Trỏ một tên miền con (ví dụ \`app.gitamath.vn\`) vào đường hầm ấy.
4. Mở ba dòng trong \`dist/_redirects\`, đổi tên miền cho đúng.

Chưa mở ba dòng ấy thì mười màn giao diện **vẫn mở ra được**, chỉ là phần dữ
liệu báo chưa nối máy chủ — và chân trang nói rõ phải làm gì.

## Đếm lại sau khi tải lên

Mở \`/ban-ke.json\` trên tên miền vừa triển khai: nó liệt kê đủ số tệp và số
byte của từng tệp trong gói. Đối chiếu là biết ngay đã lên đủ chưa.

## Số liệu đóng băng

Trang tĩnh mang số liệu của **ngày dựng**, và mỗi trang in rõ ngày ấy. Số
liệu đổi thì dựng lại và đẩy lại — một lệnh.
`);
  dat('Cấu hình Cloudflare', '_headers · _redirects · wrangler.toml · DOC-TRUOC.md');

  // ── 6. SOI LẠI SẢN PHẨM ──
  console.log(mau.dam('\n  ▸ SOI SẢN PHẨM\n'));

  for (const [ten, chu] of Object.entries(tep)) {
    if (!ten.endsWith('.html')) continue;
    const loi = T.soiTrangTinh(chu, { tenTep: ten });
    if (loi.length) loi.forEach(truot); else dat(`Trang ${ten}`, `${(chu.length / 1024).toFixed(1)}KB`);
  }

  // ── Không số nào viết cứng trong lời văn ──
  const sc = T.soiSoVietCung();
  if (!sc.dat) truot(`Lời văn viết cứng con số: ${sc.bat.slice(0, 3).join(' · ')}`);
  else dat('Không số nào viết cứng trong lời văn', 'mọi con số đọc từ dữ liệu');

  // ── Mọi trang tĩnh phải có lối vào ứng dụng ──
  //
  // Lỗi có thật: trang chủ có đúng MỘT liên kết, sang sơ đồ. Mười màn giao
  // diện nằm sẵn trên máy chủ, mở được, nhưng không ai tìm thấy vì không chỗ
  // nào trỏ tới. Một trang web mà muốn dùng thì phải biết trước đường dẫn là
  // một trang web hỏng.
  const khongLoi = Object.entries(tep)
    .filter(([ten, chu]) => ten.endsWith('.html') && !chu.includes('/ui/cong.html'))
    .map(([ten]) => ten);
  if (khongLoi.length) truot(`${khongLoi.length} trang không có lối vào ứng dụng: ${khongLoi.join(', ')}`);
  else dat('Mọi trang đều có lối vào ứng dụng', `${Object.keys(tep).filter((t) => t.endsWith('.html')).length} trang`);

  // ── Đối chiếu TỪNG TỆP giao diện với kho mã ──
  //
  // Đây là phép kiểm trả lời thẳng câu hỏi "có thất lạc tệp nào không". Đếm
  // xấp xỉ hay kiểm vài tệp tiêu biểu đều không trả lời được câu ấy: thiếu
  // một tệp thì trang vẫn mở, vẫn trả 200, chỉ là mất kiểu chữ hoặc chết một
  // nút bấm — và không ai báo lỗi.
  const uiKho = fs.readdirSync(path.join(GOC, 'ui')).filter((f) => fs.statSync(path.join(GOC, 'ui', f)).isFile());
  const uiGoi = new Set(fs.readdirSync(path.join(RA, 'ui')));
  const uiThieu = uiKho.filter((f) => !uiGoi.has(f));
  if (uiThieu.length) truot(`Gói thiếu ${uiThieu.length} tệp giao diện: ${uiThieu.slice(0, 3).join(', ')}`);
  else dat('Gói mang đủ giao diện', `${uiKho.length}/${uiKho.length} tệp, không sót tệp nào`);

  // Không một tệp nào được rỗng.
  const rong = [];
  const diKhap = (d) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const q = path.join(d, e.name);
      if (e.isDirectory()) diKhap(q);
      else if (fs.statSync(q).size < 20) rong.push(path.relative(RA, q));
    }
  };
  diKhap(RA);
  if (rong.length) truot(`${rong.length} tệp rỗng: ${rong.slice(0, 3).join(', ')}`);
  else dat('Không tệp nào rỗng');

  // ── Gói này có tải lên Cloudflare được không ──
  //
  // Luồng "Upload and deploy" của Cloudflare TỪ CHỐI một số tệp — wrangler
  // cấu hình là một. Và có những tệp Cloudflare KHÔNG từ chối nhưng không
  // bao giờ được lên một trang công khai, ví dụ tệp môi trường.
  //
  // Canh ở đây, tại chỗ dist được dựng ra, chứ không chỉ lúc đóng gói: thư
  // mục sạch từ đầu thì mọi cách đóng gói về sau đều sạch.
  const CAM_LEN = [
    [/(^|\/)wrangler\.(toml|json|jsonc)$/i, 'Cloudflare coi là tệp cấu hình, không nhận làm tài sản tĩnh'],
    [/(^|\/)\.env/i, 'tệp môi trường — không bao giờ lên trang công khai'],
    [/(^|\/)node_modules\//, 'thư viện, không phải nội dung trang'],
    [/(^|\/)package(-lock)?\.json$/i, 'tệp dự án Node'],
    [/(^|\/)(src|test|scripts|desktop|bin)\//, 'mã nguồn'],
    [/\.(pem|key|p12|pfx)$/i, 'tệp khoá'],
  ];
  // Duyệt thẳng thư mục chứ không dựa vào bản kê: bản kê được ghi ra SAU mục
  // kiểm này, và một mục kiểm phụ thuộc vào thứ chưa tồn tại thì không chạy.
  const camCo = [];
  const quetCam = (d) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const q = path.join(d, e.name);
      if (e.isDirectory()) { quetCam(q); continue; }
      const duong = path.relative(RA, q).split(path.sep).join('/');
      for (const [re, vi] of CAM_LEN) if (re.test(duong)) camCo.push(`${duong} (${vi})`);
    }
  };
  quetCam(RA);
  if (camCo.length) truot(`Gói mang ${camCo.length} tệp không được lên Cloudflare: ${camCo.slice(0, 2).join(', ')}`);
  else dat('Không tệp nào bị Cloudflare từ chối', `soi ${CAM_LEN.length} loại`);

  // Không một chuỗi nào trông giống khoá.
  const NGHI_KHOA = [/sk-[A-Za-z0-9]{16,}/, /AIza[A-Za-z0-9_-]{20,}/, /gsk_[A-Za-z0-9]{20,}/,
    /-----BEGIN [A-Z ]*PRIVATE KEY-----/, /Bearer\s+[A-Za-z0-9._-]{24,}/];
  const daiDien = [];
  const quet = (d) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const q = path.join(d, e.name);
      if (e.isDirectory()) { quet(q); continue; }
      if (!/\.(html|txt|svg|json|toml|md)$/.test(e.name)) continue;
      const c = fs.readFileSync(q, 'utf8');
      for (const re of NGHI_KHOA) if (re.test(c)) daiDien.push(`${path.relative(RA, q)} (${re.source.slice(0, 20)})`);
    }
  };
  quet(RA);
  if (daiDien.length) truot(`Có chuỗi trông giống khoá: ${daiDien.slice(0, 2).join(', ')}`);
  else dat('Không chuỗi nào trông giống khoá bí mật');

  // ── Bản kê toàn gói ──
  //
  // Sau khi tải lên Cloudflare, mở /ban-ke.json là đối chiếu được ngay: gói
  // đáng lẽ có bao nhiêu tệp, và mỗi tệp bao nhiêu byte. Không có bản kê thì
  // "đã tải đủ chưa" là một câu hỏi không trả lời được.
  const ke = [];
  const keQuet = (d) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const q = path.join(d, e.name);
      if (e.isDirectory()) { keQuet(q); continue; }
      const duong = path.relative(RA, q).split(path.sep).join('/');
      if (duong === 'ban-ke.json') continue;
      ke.push({ duong, byte: fs.statSync(q).size });
    }
  };
  keQuet(RA);
  ke.sort((a, b) => a.duong.localeCompare(b.duong));
  fs.writeFileSync(path.join(RA, 'ban-ke.json'), `${JSON.stringify({
    dungLuc: new Date().toISOString(),
    phienBan: N.cfg.VERSION,
    soTep: ke.length,
    tongByte: ke.reduce((a, x) => a + x.byte, 0),
    tep: ke,
  }, null, 1)}\n`);
  dat('Bản kê toàn gói', `ban-ke.json · ${ke.length} tệp`);

  // Mọi liên kết nội bộ phải trỏ tới một tệp có thật.
  const dut = [];
  for (const [ten, chu] of Object.entries(tep)) {
    if (!ten.endsWith('.html')) continue;
    for (const m of chu.matchAll(/href="(\/[^"#]*)"/g)) {
      const d = m[1] === '/' ? 'index.html' : m[1].replace(/^\//, '');
      if (!fs.existsSync(path.join(RA, d))) dut.push(`${ten} → ${m[1]}`);
    }
  }
  // Và mười màn giao diện cũng phải tự đủ: mọi tệp chúng nạp phải nằm trong
  // gói. Đây chính là chỗ "thất lạc một tệp" xảy ra — trang mở ra trắng trơn
  // hoặc mất hẳn kiểu chữ, mà máy chủ vẫn trả 200 nên không ai báo lỗi.
  for (const f of fs.readdirSync(path.join(RA, 'ui'))) {
    if (!f.endsWith('.html')) continue;
    const c = fs.readFileSync(path.join(RA, 'ui', f), 'utf8');
    for (const m of c.matchAll(/(?:href|src)="(\/ui\/[^"#?]+)"/g)) {
      if (!fs.existsSync(path.join(RA, m[1].replace(/^\//, '')))) dut.push(`ui/${f} → ${m[1]}`);
    }
  }
  if (dut.length) truot(`Liên kết đứt: ${dut.slice(0, 3).join(', ')}`);
  else dat('Mọi liên kết nội bộ đều trỏ tới tệp có thật', `kể cả ${fs.readdirSync(path.join(RA, 'ui')).filter((f) => f.endsWith('.html')).length} màn giao diện`);

  // Và chiều ngược lại: không trang nào được nằm đó mà không ai dẫn tới.
  //
  // Phép kiểm ở trên bắt liên kết trỏ vào hư không. Phép kiểm này bắt điều
  // ngược lại, và nó mới là điều đã thật sự xảy ra một lần: dựng ra một
  // trang đầy đủ rồi quên nối vào lối đi, nên không ai mở được nó trừ khi
  // gõ đúng địa chỉ.
  const duocDan = new Set(['index.html']);
  const quetDan = (chu) => {
    for (const m of chu.matchAll(/href="(\/[^"#?]*)"/g)) {
      duocDan.add(m[1] === '/' ? 'index.html' : m[1].replace(/^\//, ''));
    }
  };
  for (const [ten, chu] of Object.entries(tep)) if (ten.endsWith('.html')) quetDan(chu);
  for (const f of fs.readdirSync(path.join(RA, 'ui'))) {
    if (f.endsWith('.html')) quetDan(fs.readFileSync(path.join(RA, 'ui', f), 'utf8'));
  }
  const moCoi = [];
  for (const f of fs.readdirSync(RA)) {
    if (f.endsWith('.html') && !duocDan.has(f)) moCoi.push(f);
  }
  for (const f of fs.readdirSync(path.join(RA, 'ui'))) {
    if (f.endsWith('.html') && !duocDan.has('ui/' + f)) moCoi.push('ui/' + f);
  }
  if (moCoi.length) truot(`Trang không ai dẫn tới: ${moCoi.join(', ')}`);
  else dat('Không trang nào mồ côi', `${duocDan.size} đường dẫn nội bộ, đều có lối vào`);


  let tong = 0;
  const demByte = (d) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const q = path.join(d, e.name);
      if (e.isDirectory()) demByte(q); else tong += fs.statSync(q).size;
    }
  };
  demByte(RA);

  await N.shutdown();

  console.log(mau.dam(`\n  ${'═'.repeat(60)}`));
  if (hong) {
    console.log(`  ${mau.do('CHƯA XONG')} — ${hong} mục không đạt. Bản dựng KHÔNG nên đẩy lên.\n`);
    process.exit(1);
  }
  console.log(`  XONG. ${mau.dam('cloudflare/dist/')} · ${(tong / 1024).toFixed(0)}KB\n`);
  console.log(`    npx wrangler pages deploy cloudflare/dist --project-name gitamath\n`);
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
