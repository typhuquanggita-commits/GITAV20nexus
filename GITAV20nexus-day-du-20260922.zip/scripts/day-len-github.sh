#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════
#  ĐẨY LÊN GITHUB — một lối duy nhất, và nó tự đếm lại trước khi gửi
# ═══════════════════════════════════════════════════════════════════════════
#
#   bash scripts/day-len-github.sh          (hoặc: npm run day-github)
#
#  Vì sao phải có kịch bản này thay vì gõ `git push`:
#
#  Kho làm việc có `origin` trỏ về một repo KHÁC với repo được phép — nó là
#  nơi bản sao này lấy về, nên không đổi được mà không làm hỏng `git pull`.
#  Bức tường pre-push chặn được cú đẩy nhầm, nhưng chặn là chuyện sau; tốt hơn
#  là có sẵn một lối ĐÚNG để không ai phải tự nghĩ ra đường đi.
#
#  Kịch bản này làm đúng bốn việc, theo đúng thứ tự, và dừng ngay khi một việc
#  không đạt:
#
#      1. Tách cây con nexus/ thành lịch sử gốc
#      2. Đồng bộ bản xuất
#      3. ĐỐI CHIẾU từng tệp giữa kho làm việc và bản xuất
#      4. Đẩy — từ bản xuất, nơi remote trỏ đúng repo được phép
#
#  Bước 3 là bước không được bỏ. Phép tách cây con im lặng bỏ qua mọi thứ nằm
#  ngoài nexus/, nên một tệp đặt nhầm chỗ sẽ biến mất khỏi bản xuất mà không
#  báo gì — và chỉ phát hiện ra khi có người clone về và thiếu mô-đun.
# ═══════════════════════════════════════════════════════════════════════════
set -euo pipefail

REPO_DUOC_PHEP="GITAmathV20nexus"
KHO_LAM_VIEC="${KHO_LAM_VIEC:-$(cd "$(dirname "$0")/../.." && pwd)}"
BAN_XUAT="${BAN_XUAT:-/home/user/nexus-moi}"
NHANH="${NHANH:-main}"

xanh() { printf '\033[32m%s\033[0m\n' "$1"; }
do_()  { printf '\033[31m%s\033[0m\n' "$1"; }
dam()  { printf '\033[1m%s\033[0m\n' "$1"; }

dam ""
dam "  ▸ ĐẨY LÊN GITHUB"
dam ""

[ -d "$KHO_LAM_VIEC/.git" ] || { do_ "  Không thấy kho làm việc: $KHO_LAM_VIEC"; exit 1; }
[ -d "$BAN_XUAT/.git" ]     || { do_ "  Không thấy bản xuất: $BAN_XUAT"; exit 1; }

# ── 0. Remote của bản xuất phải đúng repo được phép ──
url="$(git -C "$BAN_XUAT" remote get-url origin)"
ten="$(printf '%s' "$url" | tr '[:upper:]' '[:lower:]' | sed -E 's#/+$##; s#\.git$##; s#.*[/:]##')"
if [ "$ten" != "$(printf '%s' "$REPO_DUOC_PHEP" | tr '[:upper:]' '[:lower:]')" ]; then
  do_ "  Bản xuất trỏ về \"$ten\", không phải \"$REPO_DUOC_PHEP\". Dừng."
  exit 1
fi
xanh "  [ ĐẠT ] Bản xuất trỏ đúng repo · $url"

# ── 1. Không được còn thay đổi chưa ghi ──
if [ -n "$(git -C "$KHO_LAM_VIEC" status --porcelain)" ]; then
  do_ "  Kho làm việc còn thay đổi chưa ghi vào commit. Ghi xong rồi đẩy."
  git -C "$KHO_LAM_VIEC" status --short | head -10
  exit 1
fi
xanh "  [ ĐẠT ] Kho làm việc sạch"

# ── 2. Tách cây con ──
git -C "$KHO_LAM_VIEC" branch -D xuat-cuoi >/dev/null 2>&1 || true
git -C "$KHO_LAM_VIEC" subtree split --prefix=nexus -b xuat-cuoi >/dev/null 2>&1
xanh "  [ ĐẠT ] Đã tách cây con nexus/"

# ── 3. Đồng bộ bản xuất ──
git -C "$BAN_XUAT" fetch -q "$KHO_LAM_VIEC" xuat-cuoi
git -C "$BAN_XUAT" checkout -q -B "$NHANH" FETCH_HEAD
soCommit="$(git -C "$BAN_XUAT" log --oneline | wc -l | tr -d ' ')"
xanh "  [ ĐẠT ] Bản xuất đồng bộ · $soCommit commit"

# ── 4. ĐỐI CHIẾU TỪNG TỆP ──
a="$(git -C "$KHO_LAM_VIEC" ls-files | grep '^nexus/' | sed 's|^nexus/||' | sort)"
b="$(git -C "$BAN_XUAT" ls-files | sort)"
thieu="$(comm -23 <(printf '%s\n' "$a") <(printf '%s\n' "$b"))"
thua="$(comm -13 <(printf '%s\n' "$a") <(printf '%s\n' "$b"))"
if [ -n "$thieu" ] || [ -n "$thua" ]; then
  do_ "  Bản xuất KHÔNG khớp kho làm việc — dừng, không đẩy."
  [ -n "$thieu" ] && { echo "    thiếu:"; printf '%s\n' "$thieu" | head -5 | sed 's/^/      /'; }
  [ -n "$thua" ]  && { echo "    thừa:";  printf '%s\n' "$thua"  | head -5 | sed 's/^/      /'; }
  exit 1
fi
xanh "  [ ĐẠT ] Khớp từng tệp · $(printf '%s\n' "$a" | wc -l | tr -d ' ') tệp"

# ── 5. Nhắc những tệp nằm NGOÀI nexus/, vì chúng KHÔNG đi theo ──
ngoai="$(git -C "$KHO_LAM_VIEC" ls-files | grep -vc '^nexus/' || true)"
if [ "${ngoai:-0}" -gt 0 ]; then
  printf '\033[2m%s\033[0m\n' "  [ lưu ý ] $ngoai tệp nằm ngoài nexus/ nên KHÔNG có trong bản xuất."
  printf '\033[2m%s\033[0m\n' "            Muốn chúng lên GitHub thì chuyển vào nexus/ trước."
fi

# ── 6. Đẩy ──
dam ""
dam "  ▸ ĐANG ĐẨY"
dam ""
if git -C "$BAN_XUAT" push -u origin "$NHANH" 2>&1 | sed 's/^/  /'; then
  dam ""
  xanh "  XONG — $soCommit commit đã lên $REPO_DUOC_PHEP nhánh $NHANH"
  dam ""
else
  dam ""
  do_ "  Đẩy KHÔNG thành công. Mã nguồn vẫn nguyên ở $BAN_XUAT, đẩy lại được bất cứ lúc nào."
  dam ""
  exit 1
fi
