#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════
#  HÀNG RÀO ĐẨY — chỉ một repo được nhận, mọi repo khác bị chặn
# ═══════════════════════════════════════════════════════════════════════════
#
#  Đây là móc `pre-push` của git. Git gọi nó TRƯỚC khi gửi bất cứ thứ gì lên
#  mạng, và truyền vào tên remote ($1) cùng ĐƯỜNG DẪN remote ($2). Trả về khác
#  0 là git huỷ lượt đẩy.
#
#  ── VÌ SAO CẦN BỨC TƯỜNG NÀY ─────────────────────────────────────────────
#
#  Kho làm việc này có `origin` trỏ về một repo KHÁC với repo được phép. Một
#  lệnh `git push` gõ theo thói quen là đủ để đưa toàn bộ mã lên nhầm chỗ, và
#  không có bước nào hỏi lại.
#
#  Đổi `origin` thôi thì chưa đủ: ai đó thêm một remote mới, hoặc gõ thẳng
#  `git push https://…` là đi vòng qua. Móc này canh ĐƯỜNG DẪN THẬT của từng
#  lượt đẩy, nên mọi lối đều phải qua nó.
#
#  ── NÓI RÕ ĐIỀU NÓ KHÔNG LÀM ─────────────────────────────────────────────
#
#  Nó KHÔNG chống được người cố tình: `git push --no-verify` bỏ qua mọi móc,
#  và xoá tệp này đi là xong. Nó chặn CÚ NHẦM, không chặn ý định. Hai thứ khác
#  nhau, và cú nhầm mới là thứ hay xảy ra.
# ═══════════════════════════════════════════════════════════════════════════
set -u

REPO_DUOC_PHEP="GITAmathV20nexus"

ten_remote="${1:-}"
duong_dan="${2:-}"

# So không phân biệt hoa thường: GitHub nhận cả GITAmathV20nexus lẫn
# gitamathv20nexus cho cùng một repo, và cả hai đều đúng.
duong_thuong="$(printf '%s' "$duong_dan" | tr '[:upper:]' '[:lower:]')"
cho_phep_thuong="$(printf '%s' "$REPO_DUOC_PHEP" | tr '[:upper:]' '[:lower:]')"

# Lấy phần "chủ/tên-repo" ở cuối đường dẫn, bỏ đuôi .git nếu có.
ten_repo="$(printf '%s' "$duong_thuong" | sed -E 's#/+$##; s#\.git$##; s#.*[/:]##')"

if [ "$ten_repo" = "$cho_phep_thuong" ]; then
  exit 0
fi

cat >&2 <<LOI

  ╔════════════════════════════════════════════════════════════════════╗
  ║  LƯỢT ĐẨY BỊ CHẶN                                                  ║
  ╚════════════════════════════════════════════════════════════════════╝

  Chỉ repo "$REPO_DUOC_PHEP" được nhận. Lượt đẩy này đi tới chỗ khác:

      remote     : ${ten_remote:-(không tên)}
      đường dẫn  : ${duong_dan:-(trống)}
      tên repo   : ${ten_repo:-(không đọc được)}

  Đây là luật do chủ hệ thống đặt: toàn bộ tệp lên GitHub qua đúng một
  repo, nghiêm cấm các repo khác.

  Muốn đẩy đúng chỗ:

      git remote set-url origin https://github.com/<chủ>/$REPO_DUOC_PHEP
      git push -u origin <nhánh>

  Hoặc đẩy từ bản tách cây con đã dựng sẵn:

      cd /home/user/nexus-moi && git push -u origin main

LOI
exit 1
