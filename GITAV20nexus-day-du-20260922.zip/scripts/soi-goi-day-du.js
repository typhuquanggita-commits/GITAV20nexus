#!/usr/bin/env node
'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  SOI GÓI ĐẦY ĐỦ — giải nén ra một chỗ sạch rồi CHẠY THẬT
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   node scripts/soi-goi-day-du.js [thư-mục-ra]
 *
 *  ── VÌ SAO ĐẾM TỆP THÔI LÀ CHƯA ĐỦ ──────────────────────────────────────
 *
 *  Đếm tệp trả lời được câu "gói có đủ số tệp không". Nó KHÔNG trả lời được
 *  câu quan trọng hơn: "người tải gói về có chạy được không".
 *
 *  Ba kiểu thiếu mà phép đếm không thấy:
 *
 *    1. Tệp có mặt nhưng HỎNG RUỘT. Một tệp ảnh bị nén sai chế độ vẫn đếm là
 *       một tệp. Nên phải so mã băm từng tệp, không so số lượng.
 *
 *    2. Tệp KHÔNG được theo dõi mà mã lại đọc lúc chạy. Kho này từng mất
 *       nguyên tầng lưu trữ đúng kiểu ấy: một dòng .gitignore không neo vào
 *       gốc đã nuốt cả src/data/, và mọi phép đếm vẫn xanh.
 *
 *    3. Thư mục mã TẠO RA lúc chạy. data/ không nằm trong gói, và đó là
 *       đúng — nhưng chỉ đúng nếu hệ thống tự tạo được nó. Không tự tạo được
 *       thì gói này chết ngay lần chạy đầu trên máy người khác.
 *
 *  Nên bộ soi này giải nén gói ra một chỗ TRỐNG hoàn toàn, rồi chạy đủ bộ
 *  kiểm ở đó. Chạy được ở chỗ trống mới là bằng chứng.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFileSync, execSync } = require('node:child_process');

const GOC = path.join(__dirname, '..');
const RA = process.argv[2] || path.join(GOC, '..', '..');
const NGAY = new Date().toISOString().slice(0, 10).replace(/-/g, '');
const TEN = `GITAV20nexus-day-du-${NGAY}.zip`;

const mau = { x: (s) => `\x1b[32m${s}\x1b[0m`, d: (s) => `\x1b[31m${s}\x1b[0m`, n: (s) => `\x1b[2m${s}\x1b[0m`, b: (s) => `\x1b[1m${s}\x1b[0m` };
let hong = 0;
const dat = (t, p = '') => console.log(`  [${mau.x(' ĐẠT ')}] ${t}${p ? mau.n(` · ${p}`) : ''}`);
const truot = (t) => { hong += 1; console.log(`  [${mau.d('KHÔNG')}] ${t}`); };
const luuY = (t) => console.log(`  [${mau.n(' lưu ý')}] ${mau.n(t)}`);

const bam = (p) => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const chay = (lenh, cwd, phut = 8) => execSync(lenh, { cwd, encoding: 'utf8', stdio: 'pipe', timeout: phut * 60000 });

(function main() {
  console.log(mau.b('\n  ▸ SOI GÓI ĐẦY ĐỦ — GITAV20nexus\n'));

  // ── 1. Kho làm việc phải sạch ──
  const ban = execFileSync('git', ['status', '--porcelain'], { cwd: GOC, encoding: 'utf8' }).trim();
  if (ban) { truot(`Kho còn ${ban.split('\n').length} thay đổi chưa ghi — gói sẽ không khớp kho`); }
  else dat('Kho làm việc sạch');

  // ── 2. Không tệp nào chưa theo dõi mà lại không bị bỏ qua có chủ ý ──
  const chuaTheoDoi = execFileSync('git', ['status', '--porcelain'], { cwd: GOC, encoding: 'utf8' })
    .split('\n').filter((d) => d.startsWith('??')).map((d) => d.slice(3));
  if (chuaTheoDoi.length) truot(`${chuaTheoDoi.length} tệp chưa theo dõi: ${chuaTheoDoi.slice(0, 3).join(', ')}`);
  else dat('Không tệp nào bị bỏ quên ngoài vòng theo dõi');

  // ── 3. Mọi thứ .gitignore chặn phải là thứ DỰNG LẠI ĐƯỢC ──
  const BO_QUA_HOP_LE = {
    'data/': 'kho dữ liệu lúc chạy — hệ thống tự tạo khi khởi động',
    'cloudflare/dist/': 'bản dựng tĩnh — npm run cloudflare sinh lại',
    'desktop/dist/': 'bản cài Windows — npm run dist:win sinh lại',
    'desktop/node_modules/': 'thư viện — npm install sinh lại từ package-lock.json',
    'node_modules/': 'thư viện',
  };
  const biChan = execFileSync('git', ['status', '--porcelain', '--ignored=matching'], { cwd: GOC, encoding: 'utf8' })
    .split('\n').filter((d) => d.startsWith('!!')).map((d) => d.slice(3).replace(/^nexus\//, ''));
  const laChoLoi = biChan.filter((d) => !Object.keys(BO_QUA_HOP_LE).some((k) => d === k || d.startsWith(k)));
  if (laChoLoi.length) truot(`${laChoLoi.length} thứ bị .gitignore chặn mà chưa khai lý do: ${laChoLoi.slice(0, 3).join(', ')}`);
  else dat('Mọi thứ bị bỏ qua đều dựng lại được', `${biChan.length} mục, đều có lý do`);

  // ── 4. Đóng gói ──
  const zip = path.join(RA, TEN);
  fs.rmSync(zip, { force: true });
  execFileSync('git', ['archive', '--format=zip', '-o', zip, 'HEAD'], { cwd: GOC });
  const theoDoi = execFileSync('git', ['ls-files'], { cwd: GOC, encoding: 'utf8' }).split('\n').filter(Boolean);
  dat('Đã đóng gói', `${theoDoi.length} tệp · ${(fs.statSync(zip).size / 1048576).toFixed(1)}MB`);

  // ── 5. Giải nén ra chỗ TRỐNG ──
  const sach = fs.mkdtempSync(path.join(os.tmpdir(), 'soi-goi-'));
  execFileSync('unzip', ['-qq', zip, '-d', sach]);

  // ── 6. So MÃ BĂM từng tệp — bắt tệp hỏng ruột, không chỉ tệp thiếu ──
  const lech = [];
  const thieu = [];
  for (const f of theoDoi) {
    const q = path.join(sach, f);
    if (!fs.existsSync(q)) { thieu.push(f); continue; }
    if (bam(path.join(GOC, f)) !== bam(q)) lech.push(f);
  }
  if (thieu.length) truot(`Gói THIẾU ${thieu.length} tệp: ${thieu.slice(0, 3).join(', ')}`);
  else if (lech.length) truot(`${lech.length} tệp lệch nội dung: ${lech.slice(0, 3).join(', ')}`);
  else dat('Từng tệp khớp mã băm SHA-256', `${theoDoi.length}/${theoDoi.length}`);

  // Và ngược lại: gói không được mang thứ kho không có.
  const trongGoi = [];
  const di = (d, t = '') => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const q = t ? `${t}/${e.name}` : e.name;
      if (e.isDirectory()) di(path.join(d, e.name), q); else trongGoi.push(q);
    }
  };
  di(sach);
  const thua = trongGoi.filter((f) => !theoDoi.includes(f));
  if (thua.length) truot(`Gói mang ${thua.length} tệp lạ: ${thua.slice(0, 3).join(', ')}`);
  else dat('Gói không mang tệp lạ nào');

  // ── 7. Tài sản nhị phân phải nguyên vẹn ──
  const nhiPhan = theoDoi.filter((f) => /\.(png|ico|jpg|jpeg|gif|woff2?|ttf|mp3|wav|avi)$/i.test(f));
  const hongAnh = nhiPhan.filter((f) => bam(path.join(GOC, f)) !== bam(path.join(sach, f)));
  if (hongAnh.length) truot(`Tài sản nhị phân hỏng: ${hongAnh.join(', ')}`);
  else dat('Tài sản nhị phân nguyên vẹn', nhiPhan.length ? nhiPhan.join(' · ') : 'không có tệp nhị phân');

  // ── 8. Mọi tệp mã ĐỌC LÚC CHẠY phải có mặt ──
  const canLucChay = ['kich-ban-mau/nguoi-thay-cuoi-cung.txt', 'src/data/repository.js',
    'src/data/portability.js', 'package.json', 'ui/icon.png', 'desktop/package-lock.json'];
  const vang = canLucChay.filter((f) => !fs.existsSync(path.join(sach, f)));
  if (vang.length) truot(`Tệp cần lúc chạy bị thiếu: ${vang.join(', ')}`);
  else dat('Mọi tệp cần lúc chạy đều có mặt', `${canLucChay.length} tệp điểm danh`);

  // ── 9. PHÉP KIỂM QUYẾT ĐỊNH: chạy thật ở chỗ sạch ──
  console.log(mau.b('\n  ▸ CHẠY THẬT Ở CHỖ SẠCH\n'));
  luuY(`thư mục: ${sach}`);

  const buoc = [
    ['npm run verify', 'node scripts/verify.js', /KẾT QUẢ: (\d+)\/(\d+) mục đạt/, 10],
    ['npm test', 'npm test', /# pass (\d+)[\s\S]*# fail (\d+)/, 12],
  ];
  for (const [ten, lenh, mau_re, phut] of buoc) {
    try {
      const ra = chay(lenh, sach, phut);
      const m = ra.match(mau_re);
      if (!m) { truot(`${ten}: chạy xong mà không đọc được kết quả`); continue; }
      if (ten === 'npm test') {
        if (Number(m[2]) > 0) truot(`${ten}: ${m[2]} mục KHÔNG đạt`);
        else dat(ten, `${m[1]}/${m[1]} đạt`);
      } else if (m[1] !== m[2]) truot(`${ten}: ${m[1]}/${m[2]} đạt`);
      else dat(ten, `${m[1]}/${m[2]} đạt`);
    } catch (e) {
      truot(`${ten}: KHÔNG CHẠY ĐƯỢC ở chỗ sạch — ${String(e.message).split('\n')[0].slice(0, 90)}`);
    }
  }

  // ── 10. Hệ thống TỰ TẠO được kho dữ liệu khi khởi động ──
  //
  // Phải KHỞI ĐỘNG MÁY CHỦ mới trả lời được câu này. Bản đầu chỉ nhìn xem
  // data/ có xuất hiện sau khi chạy hai bộ kiểm hay không — và nó luôn đỏ,
  // vì cả hai bộ kiểm ĐỀU CỐ Ý dùng thư mục tạm để không làm bẩn cây làm
  // việc. Mục kiểm ấy đo một thứ, rồi kết luận về một thứ khác.
  //
  // Câu hỏi thật là: người tải gói về, chạy `npm start` ở một chỗ trống, có
  // lên được không. Nên hỏi đúng như thế.
  const cong = 9912;
  let may = null;
  try {
    may = require('node:child_process').spawn('node', ['src/index.js'], {
      cwd: sach, env: { ...process.env, PORT: String(cong) }, stdio: 'ignore', detached: true,
    });
    let len = false;
    for (let i = 0; i < 40 && !len; i += 1) {
      try {
        execSync(`curl -sf -o /dev/null http://127.0.0.1:${cong}/health`, { stdio: 'ignore' });
        len = true;
      } catch { execSync('sleep 0.5'); }
    }
    if (!len) truot('Máy chủ KHÔNG lên được ở chỗ sạch trong 20 giây');
    else {
      const coData = fs.existsSync(path.join(sach, 'data'));
      if (!coData) truot('Máy chủ lên được nhưng KHÔNG tạo kho dữ liệu — gói thiếu tầng lưu trữ');
      else {
        const trong = fs.readdirSync(path.join(sach, 'data'));
        dat('Máy chủ lên được ở chỗ sạch và TỰ TẠO kho dữ liệu', `data/${trong.join(', data/')}`);
      }
      // Và phải phục vụ được giao diện, không chỉ trả lời /health.
      try {
        execSync(`curl -sf -o /dev/null http://127.0.0.1:${cong}/ui/cong.html`, { stdio: 'ignore' });
        dat('Giao diện phục vụ được từ bản giải nén');
      } catch { truot('Máy chủ lên nhưng KHÔNG phục vụ được giao diện'); }
    }
  } catch (e) {
    truot(`Không khởi động được máy chủ: ${String(e.message).split('\n')[0].slice(0, 80)}`);
  } finally {
    if (may && may.pid) { try { process.kill(-may.pid, 'SIGKILL'); } catch { /* đã tắt */ } }
  }

  fs.rmSync(sach, { recursive: true, force: true });

  console.log(mau.b(`\n  ${'═'.repeat(64)}`));
  if (hong) { console.log(`  ${mau.d('CHƯA XONG')} — ${hong} mục không đạt. KHÔNG nên đẩy gói này.\n`); process.exit(1); }
  console.log(`  ${mau.x('TOÀN BỘ ĐẠT')} — gói giải nén ở chỗ trống và chạy được đủ bộ kiểm.\n`);
  console.log(`    ${zip}\n`);
  process.exit(0);
})();
