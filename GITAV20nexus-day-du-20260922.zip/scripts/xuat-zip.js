#!/usr/bin/env node
'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  XUẤT GÓI .ZIP — và ĐẾM LẠI để không thất lạc tệp nào
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   node scripts/xuat-zip.js [thư-mục-ra]
 *
 *  Xuất hai gói, vì chúng dùng cho hai việc khác nhau:
 *
 *    gitamath-cloudflare-<ngày>.zip   bản TĨNH đã dựng — thả thẳng vào
 *                                     Cloudflare Pages
 *    gitamath-ma-nguon-<ngày>.zip     toàn bộ mã nguồn — để dựng lại, để
 *                                     chạy máy chủ, để sửa
 *
 *  ── VÌ SAO PHẢI ĐẾM LẠI ─────────────────────────────────────────────────
 *
 *  Một gói nén thiếu tệp KHÔNG báo lỗi. Nó mở ra bình thường, chỉ là khi chạy
 *  thì thiếu một mô-đun — và lúc ấy đã ở trên máy người khác. Kho này từng
 *  mất nguyên tầng dữ liệu đúng theo kiểu ấy: một dòng trong .gitignore không
 *  neo vào gốc đã nuốt cả src/data/.
 *
 *  Nên gói xuất xong thì MỞ LẠI, liệt kê, và đối chiếu từng đường dẫn với
 *  danh sách nguồn. Thiếu một tệp là thoát với mã 1.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const fs = require('node:fs');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

const GOC = path.join(__dirname, '..');
const RA = process.argv[2] || path.join(GOC, '..', '..');
const NGAY = new Date().toISOString().slice(0, 10).replace(/-/g, '');

/**
 * TÊN GÓI PHẢI TỰ NÓI NÓ DÙNG ĐỂ LÀM GÌ.
 *
 * Bản đầu đặt tên "gitamath-cloudflare-<ngày>.zip" và "gitamath-ma-nguon-
 * <ngày>.zip". Hai tên ấy phân biệt được khi đọc kỹ, nhưng lúc đang đứng
 * trước màn hình tải lên thì người ta chọn theo TÊN NHÌN LƯỚT — và đã chọn
 * nhầm gói mã nguồn thật.
 *
 * Hậu quả của cú nhầm ấy không nhỏ: Cloudflare từ chối wrangler.toml nên
 * dừng lại, nhưng nếu nó không từ chối thì toàn bộ mã nguồn VÀ .env.example
 * đã lên một trang web công khai.
 *
 * Nên tên mới nói thẳng việc: một gói để TẢI LÊN, một gói KHÔNG.
 */
const TEN_CF = `TAI-LEN-CLOUDFLARE-${NGAY}.zip`;
const TEN_SRC = `KHONG-TAI-LEN-CLOUDFLARE--ma-nguon-${NGAY}.zip`;

/**
 * Những thứ Cloudflare TỪ CHỐI trong luồng "Upload and deploy", hoặc những
 * thứ không bao giờ được lên một trang công khai.
 *
 * Mục kiểm này canh gói Cloudflare, và nó là mục kiểm quan trọng nhất ở đây:
 * một tệp lọt vào thì hoặc là bản triển khai dừng giữa chừng, hoặc là — tệ
 * hơn nhiều — nó lên web và nằm đó cho ai cũng tải về.
 */
const CLOUDFLARE_TU_CHOI = [
  { re: /(^|\/)wrangler\.(toml|json|jsonc)$/i, vi: 'Cloudflare coi đây là tệp cấu hình, không nhận làm tài sản tĩnh' },
  { re: /(^|\/)\.env/i, vi: 'Tệp môi trường — không bao giờ được lên một trang công khai' },
  { re: /(^|\/)node_modules\//, vi: 'Thư viện, không phải nội dung trang' },
  { re: /(^|\/)\.git(\/|$)/, vi: 'Kho git — chứa toàn bộ lịch sử' },
  { re: /(^|\/)package(-lock)?\.json$/i, vi: 'Tệp dự án Node, không phải nội dung trang' },
  { re: /(^|\/)(src|test|scripts|desktop|bin)\//, vi: 'Mã nguồn — không thuộc về một trang tĩnh công khai' },
  { re: /\.(pem|key|p12|pfx)$/i, vi: 'Tệp khoá' },
];

const mau = { xanh: (s) => `\x1b[32m${s}\x1b[0m`, do: (s) => `\x1b[31m${s}\x1b[0m`, nhat: (s) => `\x1b[2m${s}\x1b[0m`, dam: (s) => `\x1b[1m${s}\x1b[0m` };
let hong = 0;
const dat = (t, p = '') => console.log(`  [${mau.xanh(' ĐẠT ')}] ${t}${p ? mau.nhat(` · ${p}`) : ''}`);
const truot = (t) => { hong += 1; console.log(`  [${mau.do('KHÔNG')}] ${t}`); };

/** Liệt kê tệp trong một gói .zip đã xuất. */
function trongZip(duong) {
  const ra = execFileSync('unzip', ['-Z1', duong], { encoding: 'utf8' });
  return ra.split('\n').map((s) => s.trim()).filter((s) => s && !s.endsWith('/'));
}

function diKhap(goc, bo = () => false, tien = '') {
  const ra = [];
  for (const e of fs.readdirSync(path.join(goc, tien), { withFileTypes: true })) {
    const q = tien ? `${tien}/${e.name}` : e.name;
    if (bo(q)) continue;
    if (e.isDirectory()) ra.push(...diKhap(goc, bo, q));
    else ra.push(q);
  }
  return ra;
}

console.log(mau.dam('\n  ▸ XUẤT GÓI .ZIP\n'));

// ── 1. Bản tĩnh cho Cloudflare ──
const dist = path.join(GOC, 'cloudflare', 'dist');
const zipCf = path.join(RA, TEN_CF);
if (!fs.existsSync(dist)) {
  truot('Chưa có cloudflare/dist — chạy `node scripts/dung-ban-cloudflare.js` trước');
} else {
  const nguon = diKhap(dist);
  fs.rmSync(zipCf, { force: true });
  execFileSync('zip', ['-rq', zipCf, '.'], { cwd: dist });
  const trong = new Set(trongZip(zipCf));
  const thieu = nguon.filter((f) => !trong.has(f));
  if (thieu.length) truot(`Gói Cloudflare thiếu ${thieu.length} tệp: ${thieu.slice(0, 3).join(', ')}`);
  else dat('Gói Cloudflare', `${nguon.length} tệp · ${(fs.statSync(zipCf).size / 1024).toFixed(0)}KB`);
  // Những tệp BẮT BUỘC phải có, nếu không Cloudflare phục vụ sai.
  for (const can of ['index.html', 'huong-dan.html', '_headers', '_redirects', 'ban-ke.json']) {
    if (!trong.has(can)) truot(`Gói Cloudflare thiếu ${can} — Cloudflare sẽ phục vụ sai`);
  }
  // Toàn bộ giao diện phải nằm trong gói. Đây là phép đếm trả lời thẳng câu
  // hỏi "có thất lạc tệp nào không".
  const uiKho = fs.readdirSync(path.join(GOC, 'ui'))
    .filter((f) => fs.statSync(path.join(GOC, 'ui', f)).isFile());
  const uiVang = uiKho.filter((f) => !trong.has(`ui/${f}`));
  if (uiVang.length) truot(`Gói Cloudflare thiếu ${uiVang.length} tệp giao diện: ${uiVang.slice(0, 3).join(', ')}`);
  else dat('Gói Cloudflare mang đủ giao diện', `${uiKho.length} tệp trong ui/`);

  // ── Mục kiểm quan trọng nhất: gói này có tải lên được không, và tải lên
  //    rồi thì có lộ gì không ──
  const cam = [];
  for (const f of nguon) {
    for (const c of CLOUDFLARE_TU_CHOI) if (c.re.test(f)) cam.push(`${f} — ${c.vi}`);
  }
  if (cam.length) truot(`Gói Cloudflare mang ${cam.length} tệp không được phép: ${cam.slice(0, 2).join(' · ')}`);
  else dat('Gói Cloudflare không mang tệp nào bị từ chối', `soi ${CLOUDFLARE_TU_CHOI.length} loại`);

  // Và đối chiếu với BẢN KÊ mà chính bản dựng đã ghi ra — hai nguồn độc lập
  // cùng nói một con số thì con số ấy mới đáng tin.
  const ke = JSON.parse(fs.readFileSync(path.join(dist, 'ban-ke.json'), 'utf8'));
  const keThieu = ke.tep.filter((x) => !trong.has(x.duong));
  if (keThieu.length) truot(`Gói lệch bản kê ${keThieu.length} tệp: ${keThieu.slice(0, 3).map((x) => x.duong).join(', ')}`);
  else dat('Gói khớp bản kê', `${ke.soTep} tệp · ${(ke.tongByte / 1024).toFixed(0)}KB`);
}

// ── 2. Mã nguồn ──
// Nguồn sự thật là DANH SÁCH GIT, không phải cây thư mục trên đĩa: thứ nằm
// trên đĩa mà git không theo dõi thì clone sạch cũng không có, nên đem nó vào
// gói là giấu đi một lỗi thay vì sửa.
const theoDoi = execFileSync('git', ['ls-files'], { cwd: GOC, encoding: 'utf8' })
  .split('\n').map((s) => s.trim()).filter(Boolean);
const zipSrc = path.join(RA, TEN_SRC);
fs.rmSync(zipSrc, { force: true });
execFileSync('git', ['archive', '--format=zip', '-o', zipSrc, 'HEAD'], { cwd: GOC });
// Dán một lời dặn vào GỐC gói mã nguồn. Ai mở gói ra là thấy ngay dòng đầu
// tiên, trước khi kịp kéo cả thư mục vào ô tải lên.
const dan = path.join(require('node:os').tmpdir(), 'DOC-TRUOC--GOI-NAY-KHONG-TAI-LEN-CLOUDFLARE.txt');
fs.writeFileSync(dan, `GÓI NÀY KHÔNG PHẢI GÓI ĐỂ TẢI LÊN CLOUDFLARE.

Đây là MÃ NGUỒN. Nó chứa src/, test/, scripts/, .env.example và wrangler.toml.

Tải nó lên Cloudflare thì hai chuyện xảy ra:
  1. Cloudflare từ chối wrangler.toml và dừng giữa chừng.
  2. Nếu nó không từ chối, toàn bộ mã nguồn và .env.example sẽ nằm trên một
     trang web công khai cho bất kỳ ai tải về.

GÓI ĐỂ TẢI LÊN CLOUDFLARE có tên bắt đầu bằng ${'TAI-LEN-CLOUDFLARE'}.

Dùng gói này để làm gì:
  - Giải nén ra, chạy \`npm start\` để có máy chủ dữ liệu
  - Chạy \`npm run cloudflare\` để dựng lại gói tĩnh
  - Chạy \`npm run zip\` để xuất lại cả hai gói
`);
execFileSync('zip', ['-qj', zipSrc, dan]);
fs.rmSync(dan, { force: true });

const trongSrc = new Set(trongZip(zipSrc));
const thieuSrc = theoDoi.filter((f) => !trongSrc.has(f));
if (!trongSrc.has('DOC-TRUOC--GOI-NAY-KHONG-TAI-LEN-CLOUDFLARE.txt')) truot('Gói mã nguồn thiếu lời dặn ở gốc');
if (thieuSrc.length) truot(`Gói mã nguồn thiếu ${thieuSrc.length} tệp: ${thieuSrc.slice(0, 3).join(', ')}`);
else dat('Gói mã nguồn', `${theoDoi.length} tệp · ${(fs.statSync(zipSrc).size / 1048576).toFixed(1)}MB`);

// Những mô-đun mới nhất PHẢI có mặt — đây là chỗ đã từng mất nguyên một tầng.
const CAN_CO = ['src/tro-chuyen/dieu-phoi.js', 'src/tiep-thi/dieu-phoi.js',
  'src/xuong-video/xuong.js', 'src/so-do-tu-duy/so-do.js', 'src/an-toan/khuon-mat.js',
  'src/crm/dieu-phoi.js', 'src/data/repository.js', 'ui/tro-chuyen.js',
  'scripts/dung-ban-cloudflare.js', 'cloudflare/wrangler.toml'];
const vang = CAN_CO.filter((f) => !trongSrc.has(f));
if (vang.length) truot(`Gói mã nguồn thiếu mô-đun: ${vang.join(', ')}`);
else dat('Mọi mô-đun mới đều có trong gói', `${CAN_CO.length} tệp điểm danh`);

// Và gói mã nguồn KHÔNG được mang theo bí mật.
const tmp = fs.mkdtempSync(path.join(require('node:os').tmpdir(), 'soi-zip-'));
execFileSync('unzip', ['-qq', zipSrc, '-d', tmp]);
const NGHI = [/sk-[A-Za-z0-9]{16,}/, /AIza[A-Za-z0-9_-]{20,}/, /gsk_[A-Za-z0-9]{20,}/,
  /-----BEGIN [A-Z ]*PRIVATE KEY-----/];
const banh = [];
for (const f of diKhap(tmp)) {
  if (!/\.(js|json|md|txt|toml|yml|yaml|sh|example)$/.test(f)) continue;
  const c = fs.readFileSync(path.join(tmp, f), 'utf8');
  for (const re of NGHI) if (re.test(c)) banh.push(f);
}
fs.rmSync(tmp, { recursive: true, force: true });
if (banh.length) truot(`Gói mã nguồn mang theo chuỗi giống khoá: ${[...new Set(banh)].slice(0, 2).join(', ')}`);
else dat('Gói mã nguồn không mang bí mật nào');

console.log(mau.dam(`\n  ${'═'.repeat(60)}`));
if (hong) { console.log(`  ${mau.do('CHƯA XONG')} — ${hong} mục không đạt.\n`); process.exit(1); }
console.log('  XONG.\n');
console.log(`    ${zipCf}`);
console.log(`    ${zipSrc}\n`);
process.exit(0);
